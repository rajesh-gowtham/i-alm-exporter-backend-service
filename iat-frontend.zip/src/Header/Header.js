import React, { useState, useRef, useEffect } from "react";
import { useLocation } from 'react-router-dom';
import { BsArrowRight } from 'react-icons/bs';
import { HiOutlineSearch } from 'react-icons/hi';
import Notification from "./Notification";
import Signout from "./Signout";
import '../CSS/MainHeader.css';
import { capitalizeString } from "../CommonUtils/getLocalizeFunction";
import { ColorConstants } from "../Constants/ColorConstants";
import userImg from '../Images/userImg.png';
import { BrowserView, MobileView, isBrowser, isMobile } from 'react-device-detect';
//SCREEN ID -3073
const Header = (props) => {

    const [isNotification, setIsNotification] = useState(false);
    const [isSignout, setIsSignout] = useState(false);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [isDashBoard] = useState(window.localStorage.getItem("navpath"));
    const ref = useRef(null);

    const handleClickOutside = (event) => {
        if (ref.current && !ref.current.contains(event.target)) {
            setIsSignout(false);
            setIsNotification(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, []);

    const KEY_NAME_ESC = 'Escape';
    const KEY_EVENT_TYPE = 'keyup';

    const handleEscKey = (event) => {
        if (event.key === KEY_NAME_ESC) {
            setIsSignout(false);
            setIsNotification(false);
        }
    };

    useEffect(() => {
        document.addEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        return () => {
            document.removeEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        };
    }, [handleEscKey]);

    const onClickMenuIcon = () => {
        props.setToggle(!(props.toggle))
    };

    const HandleNotification = () => {
        setIsNotification(current => !current);
        setIsSignout(false);
    };

    const HandleSignout = () => {
        setIsSignout(current => !current);
        setIsNotification(false);
    };

    // useEffect(() => {
    //     // Find the index after "http://localhost:8282/"
    //     const startIndex = window.location.href.indexOf("http://localhost:8282/") + "http://localhost:8282/".length;

    //     // Find the index of the next '/'
    //     const nextSlashIndex = window.location.href.indexOf('/', startIndex);

    //     // Extract the substring from startIndex until the next '/'
    //     const nextWord = window.location.href.substring(startIndex, nextSlashIndex !== -1 ? nextSlashIndex : undefined);

    //     console.log('navvvvvvvvvv>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', nextWord, window.localStorage.getItem("RoleName"))

    //     if (nextWord == 'privilages' || nextWord == 'Roles' || nextWord == 'users') {
    //         setModuleName('Security')
    //     }
    //     else if (nextWord == 'fields_columns' || nextWord == 'transactions' || nextWord == 'Settings') {
    //         setModuleName('Settings')
    //     }
    //     else if (nextWord == 'streamgroup' || nextWord == 'systemreference') {
    //         setModuleName('Others')
    //     }
    //     else if (nextWord == 'dashboard') {
    //         setModuleName('')
    //     }

    // }, [window.location.href])

    return (
        <>
            <div class="max-lg:px-0 max-lg:py-0  px-3 py-1 flex flex-row max-lg:justify-start justify-between items-center max-lg:h-10 h-20 text-sm font-normal border-b-[1px]">
                <div class='flex items-center ml-1 '>
                    <div>
                        <div onClick={onClickMenuIcon} class="flex justify-end  pl-2 cursor-pointer">
                            {props.toggle ?
                                < BsArrowRight color={ColorConstants.Icon.sidebarMenu} size={24} class="max-lg:h-4" />
                                :
                                <div class="space-y-1.5 group max-lg:h-4">
                                    <span class="block w-5 h-0.5 rounded group-hover:w-7 bg-[#3a7afe] ease-in delay-100 duration-200"></span>
                                    <span class="block w-7 h-0.5 rounded bg-[#3a7afe]"></span>
                                    <span class="block w-6 h-0.5 rounded group-hover:w-7 bg-[#3a7afe] ease-in delay-100 duration-200"></span>
                                </div>
                            }
                            {isDashBoard == "dashboard" ? null :
                                <div className="text-black text-[28px] pl-4 font-semibold">{props.moduleName}</div>
                            }

                        </div>

                    </div>
                    {isDashBoard == "dashboard" ?
                        <div class='max-lg:w-18 max-w-md ml-7 '>
                            <div class="relative flex items-center w-full h-10 rounded-lg  bg-[#ebeef6] overflow-hidden">
                                <div class="grid place-items-center max-lg:w-10 max-lg:h-6 h-full w-12 text-[#181c32]">
                                    <HiOutlineSearch size={20} />
                                </div>
                                <input
                                    class="peer bg-[#ebeef6] max-lg:w-14 max-lg:h-6 h-full w-full outline-none text-sm text-[#181c32] placeholder-[#181c32] pr-2"
                                    type="text"
                                    id="search"
                                    onChange={(e) => { props.setName(e.target.value) }}
                                    placeholder="Search..." />
                            </div>
                        </div>
                        : null}
                </div>

                <div ref={ref} class="flex max-lg:mr-16 max-lg:px-8">
                    <div class="flex items-center space-x-4 max-lg:pr-[20px] md:pr-10">
                        <div ref={ref} class="flex items-center">
                            <nav class="flex justify-center items-center max-lg:w-6 max-lg:h-6 w-10 h-10 mr-2  bg-[#ebeef6] relative rounded cursor-pointer" onClick={HandleNotification}>
                                <span class="absolute left-6 max-lg:top-0 top-2   flex justify-center items-center h-[6px] w-[6px]">
                                    <span class="animate-ping absolute inline-flex h-4 w-4 rounded-full bg-sky-400 opacity-75"></span>
                                    <span class=" inline-flex rounded-full h-[6px] w-[6px] bg-sky-500"></span>
                                </span>
                                <svg id="icon-user" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#464a53" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" ></path>
                                    <path d="M13.73 21a2 2 0 0 1-3.46 0" ></path>
                                </svg>
                            </nav>
                            <div onClick={HandleSignout} class="cursor-pointer relative inline-flex items-center justify-center mr-2 p-2 max-lg:p-0 max-lg:w-6 max-lg:h-6 w-10 h-10 overflow-hidden bg-[#ebeef6] rounded-md">
                                <img src={userImg} alt='user' />
                            </div>
                            <div class="text-[#89879f] cursor-pointer " onClick={HandleSignout}>
                                <span class="max-lg:mob-txt-sm text-base" >Hey,
                                    <strong class="text-[#181c32] max-lg:mob-txt-sm  md:font-black ml-[3px]">{capitalizeString(window.localStorage.getItem("LoginUserName"))}</strong>
                                </span><br />
                                <small class="max-lg:mob-txt-sm md:text-[13px] lg:text-[13px] font-light leading-tight	"> <span class='font-medium'>{capitalizeString(window.localStorage.getItem("RoleName"))}</span></small>
                            </div>
                            {isNotification ?
                                <div className='DropdownBox z-10'>
                                    <Notification />
                                </div>
                                : null}
                        </div>
                        {isSignout &&
                            <div className='DropdownBox z-10'>
                                <Signout />
                            </div>
                        }

                    </div>
                </div>
            </div>
        </>
    )
}
export default Header;



