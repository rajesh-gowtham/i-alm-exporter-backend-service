import React, { useState, useRef, useEffect } from "react";
import { BsArrowRight } from 'react-icons/bs';
import { HiOutlineSearch } from 'react-icons/hi';
import Notification from "./Notification";
import Signout from "./Signout";
import '../CSS/MainHeader.css';
import { capitalizeString } from "../CommonUtils/getLocalizeFunction";
import { ColorConstants } from "../Constants/ColorConstants";
import userImg from '../Images/userImg.png';
import MobSignout from "./MobSignout";
import MobNotification from "./MobNotification";
import icatSidebar from "../Images/icatSidebar.png";
import { BrowserView, MobileView, isBrowser, isMobile } from 'react-device-detect';
//SCREEN ID -3073
const MobHeader = (props) => {

    const [isNotification, setIsNotification] = useState(false);
    const [isSignout, setIsSignout] = useState(false);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [isDashBoard] = useState(window.localStorage.getItem("navpath"));
    const ref = useRef(null);

    const handleClickOutside = (event) => {
        if (ref.current && !ref.current.contains(event.target)) {
            setIsSignout(false);
            setIsNotification(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, []);

    const KEY_NAME_ESC = 'Escape';
    const KEY_EVENT_TYPE = 'keyup';

    const handleEscKey = (event) => {
        if (event.key === KEY_NAME_ESC) {
            setIsSignout(false);
            setIsNotification(false);
        }
    };

    useEffect(() => {
        document.addEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        return () => {
            document.removeEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        };
    }, [handleEscKey]);



    const Onchange_Logout = () => {
        if (isSignout) {
            setIsSignout(false)
        } else {
            setIsSignout(true)
        }
        if (isNotification) {
            setIsNotification(false)
        }
    };

    const Onchange_Notication = () => {
        if (isNotification) {
            setIsNotification(false)
        } else {
            setIsNotification(true)
        }
        if (isSignout) {
            setIsSignout(false)
        }
    };
    const onClickMenuIcon = () => {
        props.setToggle(!(props.toggle))
    };

    const HandleNotification = () => {
        setIsNotification(current => !current);
        setIsSignout(false);
    };

    const HandleSignout = () => {
        setIsSignout(current => !current);
        setIsNotification(false);
    };

    return (
        <>
            <header>
                <nav class="bg-white border-gray-200  dark:bg-gray-800">
                    <div class="flex  justify-between  max-w-screen-xl">

                        <div class="flex items-center">
                            {props.toggle &&
                                <div onClick={onClickMenuIcon} class='max-lg:h-10 h-20 p-1 w-[50px] border-b-[1px] bg-[#3a7afe]'>
                                    <div class='flex items-center justify-center h-[100%]'>
                                        <img src={icatSidebar} class=" h-8 w-8 "></img>
                                    </div>
                                </div>
                            }
                            <div onClick={onClickMenuIcon} class="flex items-center pl-2 cursor-pointer">
                                {props.toggle ?
                                    < BsArrowRight color={ColorConstants.Icon.sidebarMenu} size={22}  />
                                    :
                                    <div class="space-y-1.5 group ">
                                        <span class="block w-4 h-0.5 rounded group-hover:w-7 bg-[#3a7afe] ease-in delay-100 duration-200"></span>
                                        <span class="block w-6 h-0.5 rounded bg-[#3a7afe]"></span>
                                        <span class="block w-5 h-0.5 rounded group-hover:w-7 bg-[#3a7afe] ease-in delay-100 duration-200"></span>
                                    </div>
                                }
                            </div>
                        </div>
                        <div class="flex items-center lg:order-2">
                            <a href="#" class="text-gray-800 dark:text-white hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 dark:hover:bg-gray-700 focus:outline-none dark:focus:ring-gray-800" onClick={Onchange_Logout}>
                                <nav class="flex justify-center items-center max-lg:w-6 max-lg:h-6 w-10 h-10  bg-[#ebeef6] relative rounded cursor-pointer" onClick={HandleNotification}>
                                    <span class="absolute left-6 max-lg:top-0 top-2   flex justify-center items-center h-[6px] w-[6px]">
                                        <span class="animate-ping absolute inline-flex h-4 w-4 rounded-full bg-[#ed5f13] opacity-75"></span>
                                        <span class=" inline-flex rounded-full h-[6px] w-[6px]  bg-[#f77f3e]"></span>
                                    </span>
                                    <svg id="icon-user" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="#206ae8" stroke="#464a53" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" ></path>
                                        <path d="M13.73 21a2 2 0 0 1-3.46 0" ></path>
                                    </svg>
                                </nav>
                            </a>
                            <a href="#" class="text-gray-800 bg-gray-100 dark:text-white hover:bg-gray-50 focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 dark:hover:bg-gray-700 focus:outline-none dark:focus:ring-gray-800" onClick={HandleSignout}>Hey,{capitalizeString(window.localStorage.getItem("LoginUserName"))}</a>
                            <button data-collapse-toggle="mobile-menu-2" type="button" class="inline-flex items-center p-2 ml-1 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="mobile-menu-2" aria-expanded="false">
                            </button>
                        </div>

                    </div>
                </nav>

                {isSignout &&
                    <div className='DropdownBox z-10'>
                        <MobSignout
                            Onchange_Logout={Onchange_Logout}
                        />
                    </div>
                }
                {isNotification ?
                    <div className='DropdownBox z-10'>
                        <MobNotification
                            Onchange_Notication={Onchange_Notication}
                        />
                    </div>
                    : null}
            </header>
        </>
    )
}
export default MobHeader;



