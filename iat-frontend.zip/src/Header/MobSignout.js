import React, { useState, useEffect } from "react";
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../CSS/Model.css';
import { getControlsConstants } from "../CommonUtils/getlocalizeData";
import userimg from '../Images/userImg.png';
import { capitalizeString } from "../CommonUtils/getLocalizeFunction";
const localControlsConstant = getControlsConstants();
//SCREEN ID -3075
const MobSignout = (props) => {
  const [isOpen, setIsOpen] = React.useState(true)
  const [isSIgnout, setIsSignout] = useState(false);
  const [Org, setOrg] = React.useState()
  useEffect(() => {
    //GetOrgNamebyID
    setOrg(window.localStorage.getItem("OrganizationName"));
  }, []);
  const toggleDrawer = () => {
    setIsOpen((prevState) => !prevState)
  }
  const LogOffYes = () => {
    window.localStorage.removeItem('uid')
    window.localStorage.removeItem('useremail')
    window.localStorage.removeItem('stsTokenManager')
    window.localStorage.removeItem('lastLoginAt')
    window.localStorage.removeItem('MasterBizUitKey')
    window.localStorage.removeItem('OrganizationName')
    window.localStorage.removeItem('Auth Token')
    window.localStorage.removeItem('user Details')
    window.localStorage.removeItem('LoginUserName')
    window.localStorage.removeItem('navpath')
    window.localStorage.removeItem('RoleName');
    window.localStorage.removeItem('RoleGkey');
    window.localStorage.removeItem('expirationTime');
    window.location = '/'
  }
  const handleSignout = () => {
    setIsSignout(true);
  }
  const handleClose = () => {
    setIsSignout(false);
  }
  return (
    <div>
      <div class="relative z-10" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
        <div class="fixed inset-0 overflow-hidden">
          <div class="absolute inset-0 overflow-hidden">
            <div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <div class="pointer-events-auto w-screen max-w-md">
                <div class="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
                  <div class="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
                    <div class="flex items-start justify-between">
                      <h2 class="text-lg font-medium text-gray-900" id="slide-over-title">{window.localStorage.getItem("LoginUserName")}</h2>
                      <div class="ml-3 flex h-7 items-center">
                        <button type="button" class="-m-2 p-2 text-gray-400 hover:text-gray-500" onClick={props.Onchange_Logout}>
                          <span class="sr-only">Close panel</span>
                          <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div class="mt-4">
                      <div class="flow-root">
                        <ul class="space-y-3 dark:text-white">
                          <li>
                            <div class="flex  transform transition-colors duration-200 border-r-4 border-transparent hover:border-indigo-700">
                              <div class=" mt-1 text-[#089de3] text-xs ">
                                Organization:<span class="text-black"><span class="pl-2">{window.localStorage.getItem("OrganizationName")}</span></span>
                              </div>
                            </div>
                          </li>
                          <hr class="dark:border-gray-700" />
                          <li class="font-sm cursor-pointer">
                            <div class="flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-indigo-700">
                              <div class="mr-3">
                                <svg class="w-[20px] h-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                              </div>
                              Manage Account
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="border-t border-gray-200 px-4 py-6 sm:px-6">
                    <div class="flex justify-between text-base font-medium text-gray-900">
                      <ul>
                        <li class="font-sm cursor-pointer" onClick={handleSignout}>
                          <div class="flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-red-600">
                            <div class="mr-3 text-red-600">
                              <svg class="w-[20px] h-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                            </div>
                            Logout
                          </div>
                        </li>
                      </ul>
                    </div>
                    <div class="mt-6">
                      <p>{window.localStorage.getItem("LoginUserName") + "'s "}user profile</p>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {isSIgnout == true &&
        <div class="max-lg:p-10">
          <ReactDialogBox
            closeBox={handleClose}
            modalWidth={localControlsConstant.Model.modalWidth}
            headerBackgroundColor={localControlsConstant.Model.headerbg}
            headerTextColor={localControlsConstant.Model.bodybg}
            headerHeight={localControlsConstant.Model.headerheight}
            closeButtonColor={localControlsConstant.Model.closebtncolor}
            bodyBackgroundColor={localControlsConstant.Model.bodybg}
            bodyTextColor={localControlsConstant.Model.bodytextcolor}
            headerText={localControlsConstant.Model.modelConfirm}
          >
            <div>
              <div class='flex items-center h-16 pl-7 max-lg:h-8 max-lg:pl-2'>
                <h1>Are you sure you want to logout?</h1>
              </div>
              <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                  onClick={LogOffYes} >Yes</button>
                <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                  onClick={handleClose}>Cancel
                </button>
              </div>

            </div>
          </ReactDialogBox>
        </div>
      }
    </div>
  )
}

export default MobSignout;