import React from 'react';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import { HiPlus } from "react-icons/hi";
import { VscListTree } from "react-icons/vsc";
import { Link } from 'react-router-dom';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { AllScenarioGrid, ScenariosByStream } from './SequenceGrids';
import { ReactDialogBox } from 'react-js-dialog-box';
import ReferenceService from '../../Services/ReferenceService';
import StreamService from '../../Services/StreamService';
import FormScenario from './FormScenario';
import { toast, ToastContainer } from 'react-toastify';
import _ from 'lodash';
import { getlocalizeData } from '../../CommonUtils/getlocalizeData';
import EditScenario from './EditScenario';
import ViewSequence_DataSet from './ViewSequence_Dataset';
import { HiOutlineSearch } from 'react-icons/hi';
import { HiQueueList } from 'react-icons/hi2';
import ScenarioService from '../../Services/ScenarioService';
import SequenceService from '../../Services/SequenceService';
import ColumnServices from '../../Services/ColumnServices';

const localConstant = getlocalizeData();

class Scenario extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isGridView: true,
            addScenarioFlag: false,
            editScenarioFlag: false,
            deleteScenarioFlag: false,
            ScenarioformFlag: true,
            arrangeSequenceFlag: false,
            dataSetFlag: false,
            deleteData: '',
            modelheader: '',
            applyTo_Options: [],
            streamOptions: [],
            records: {},
            navPath: ['Scenario'],
            scenarioData: [],
            allSequenceData: [],
            allColumnsData: [],
            errors: {
                displayName: '',
                longName: '',
                stream: '',
                description: ''
            },
        }
        this.streamRef = React.createRef();
    };

    async componentDidMount() {
        await this.LoadStreamSelectField();
        await this.LoadApplyToSelectField();
        await this.getScenarioByOrg();
        await this.getSequencesByOrg();
        await this.getFieldColumnsByOrg();
    };

    getScenarioByOrg = async () => {
        try {
            const response = await ScenarioService.GetScenariosByOrg();
            console.log("response ", response.data);
            const tempScenario = response.data.scenarios;
            const sequenceData = response.data.sce_seqs;
            const datasetData = response.data.sce_auts;
            const scenarioData = tempScenario.map(item => ({
                ...item,
                scen_seqs: sequenceData.filter(obj => obj.scenario_key === item.gkey),
                scen_auts: datasetData.filter(obj => obj.scenario_key === item.gkey)
            }));
            this.setState({
                scenarioData: scenarioData,
            })

            console.log('>>>>>>>>>>>.final scenarioData', scenarioData)

            if (response.status == 200) {
                const options = this.state.streamOptions;
                const groupByStream = _.groupBy(scenarioData, "Stream_gkey");
                const tempGroupByStream = {};
                options.forEach((item) => {
                    const { value, label } = item;
                    tempGroupByStream[label] = groupByStream[value];
                });
                this.setState({
                    groupByStream: tempGroupByStream,
                })

                console.log('>>>>>>>>>>>>> final groupByStream', tempGroupByStream)

            } else {
                console.error(" Error in GetAllTestUsersByOrg ")
            }
        } catch (error) {
            console.error(error)
        }
    };

    getSequencesByOrg = async () => {
        SequenceService.GetSequenceByOrg().
            then(
                response => {
                    this.setState({
                        allSequenceData: response.data,
                    })
                    console.log('getSequencesByOrg', response.data)
                }
            );
    };

    getFieldColumnsByOrg = async () => {
        ColumnServices.GetColumnsByOrg().
            then(
                response => {
                    this.setState({
                        allColumnsData: response.data
                    })
                    console.log('getFieldColumnsByOrg', response)
                }
            );
    };

    LoadApplyToSelectField = async () => {
        ReferenceService.getReferenceByOrg().then(
            response => {
                const options = response.data.map((datas, index) => (
                    {
                        "value": datas.gkey,
                        "label": datas["Value"]
                    }
                ))
                this.setState({
                    applyTo_Options: options
                })
            }
        );
    };

    LoadStreamSelectField = async () => {
        try {
            const response = await StreamService.getStreamByOrg()
            const options = response.data.map(datas => (
                {
                    "value": datas.gkey,
                    "label": datas["name"]
                }
            ))
            this.setState({
                streamOptions: options,
            })
            return options;
        } catch (error) {
            console.log('errr', error)
        }
    };

    addEditScenario_Open = (e, item) => {
        if (item === undefined || item === null) {
            this.setState({
                addScenarioFlag: true,
                ScenarioformFlag: false,
                editScenarioFlag: false,
                records: {
                    displayName: "",
                    description: "",
                    longName: "",
                    Stream_gkey: "",
                },
                navPath: ['Scenario', 'Add Scenario'],
            })
        }
        else {
            this.setState({
                editScenarioFlag: true,
                ScenarioformFlag: false,
                addScenarioFlag: false,
                records: item,
                navPath: ['Scenario', 'Edit Scenario'],
            })
        }
        this.setState({
            errors: {
                description: "",
                stream: "",
                displayName: "",
                longName: ""
            }
        })
    };

    viewSequence_DataSet_Open = (e, item) => {
        this.setState({
            ScenarioformFlag: false,
            records: item,
            navPath: ['Scenario', 'View Scenario']
        })
    };

    deleteScenario_Open = (item) => {
        console.log('dele', item)
        if (item.scen_seqs.length > 0 || item.scen_auts.length > 0) {
            toast.error('Remove all Sequences and DataSets Before Delete the scenario !')
            return
        }


        this.setState({
            deleteScenarioFlag: true,
            modelHeader: " Delete Scenario",
            deleteData: item
        })
    };

    backToMainScreen = async (e) => {
        this.setState({
            ScenarioformFlag: true,
            addScenarioFlag: false,
            editScenarioFlag: false,
            deleteScenarioFlag: false,
            arrangeSequenceFlag: false,
            dataSetFlag: false,
            navPath: ['Scenario']
        })
        await this.getScenarioByOrg();
    };

    AddEditScenario_OnChange = (e, obj) => {
        if (e == null)
            return;
        let name, value;
        let errors = this.state.errors;
        if (e.target == undefined) {
            name = obj.name;
            value = e.value;
            errors[name] = "";
        } else {
            name = e.target.name;
            value = e.target.value;
        }
        // console.log("name ", name, "value", value)
        this.setState(prevState => ({
            records: {
                ...prevState.records,
                [name]: value,
            }
        }))
        switch (name) {
            case 'displayName':
                errors.displayName =
                    value.length < 1
                        ? "Display name can't be empty ! "
                        : '';
                break;
            case 'longName':
                errors.longName =
                    value.length < 1
                        ? "Long name can't be empty ! "
                        : '';
                break;
            case 'Stream_gkey':
                errors.stream =
                    value.length < 1
                        ? "Stream  can't be empty ! "
                        : '';
                break;
            default:
                break;
        }

    };

    addScenario_onClick = async (e) => {
        e.preventDefault();
        let records = this.state.records;
        const isValid = this.validateAllfields(records);
        if (isValid) {
            e.currentTarget.disabled = true;
            records["MasterBizUitKey"] = localStorage.getItem("MasterBizUitKey")
            try {
                const response = await ScenarioService.CreateScenarioByOrg(records);
                if (response.status === 201 || response.status === 200) {
                    toast.success("Scenario Added Successfully!");
                    // this.getScenarioByOrg();
                    this.backToMainScreen();
                }
            } catch (error) {
                console.error(" err ", error)
            }
        }
        else {
            console.log("In valid", records)
        }
    };

    editScenario_onClick = async (e) => {
        e.preventDefault();
        let records = this.state.records;
        const isValid = this.validateAllfields(records);
        console.log('records', records)
        if (isValid) {
            e.currentTarget.disabled = true;
            try {
                const response = await ScenarioService.UpdateScenarioByOrg(records);
                console.log('response gkey', response)
                if (response.status === 201 || response.status === 200) {
                    toast.success("Scenario updated Successfully!");
                    this.getScenarioByOrg();
                }
            } catch (error) {
                console.error('error', error)
            }
        } else {
            console.log("In valid", records)
        }
    };

    validateAllfields(records) {
        if (records.displayName == undefined || records.displayName == "" || this.state.errors.displayName != "") {
            let err = records.displayName == undefined || records.displayName == "" ? ' Please enter display name  ' : this.state.errors.displayName;
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    displayName: err
                },
            }));
            return false;
        }
        if (records.longName == undefined || records.longName == "" || this.state.errors.longName != "") {
            let err = records.longName == undefined || records.longName == "" ? ' Please enter long name  ' : this.state.errors.longName;
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    longName: err
                },
            }));
            return false;
        }
        if (records.Stream_gkey == undefined || records.Stream_gkey == "" || this.state.errors.stream != "") {
            let err = records.Stream_gkey == undefined || records.Stream_gkey == "" ? ' Please enter Stream name  ' : this.state.errors.stream;
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    stream: err
                },
            }));
            return false;
        }
        return true;
    };

    deleteScenario_OnClick = async () => {
        try {
            const response = await ScenarioService.DeleteScenarioByOrg(this.state.deleteData.gkey)
            console.log(response)
            if (response.status == 200 || response.status == 200) {
                toast.success('Scenario Deleted Successfully');
                this.backToMainScreen();
            }
        } catch (error) {
            console.error("error ", error)
        }

    };

    manageSequence_onClick = async (event, gridApi) => {
        const scenario_gkey = this.state.records.gkey;
        const selectedData = gridApi.getSelectedRows();
        const ManageSequenceData = selectedData.map(value => (
            { scenario_key: scenario_gkey, sequence_gkey: value.gkey }
        ))
        event.currentTarget.disabled = true;
        try {
            if (selectedData.length == 0) {
                const response = await ScenarioService.DeletemapScenarioSequence(scenario_gkey)
                console.log("response ", response)
                if (response.status == 200 || response.status == 201) {
                    await this.getScenarioByOrg();
                    toast.success('Manage Sequence data removed successfully !')
                }
            } else if (selectedData.length > 0) {
                const response = await ScenarioService.Update_map_scenario_sequence(ManageSequenceData)
                console.log("response ", response)
                if (response.status == 200 || response.status == 201) {
                    await this.getScenarioByOrg();
                    toast.success('Manage Sequence added / updated successfully!');
                }
            }
            await this.editRecordUpdate(scenario_gkey)
        } catch (error) {
            event.currentTarget.disabled = false;
            console.error('error', error)
        }
    };

    manageDataset_onClick = async (event, gridApi) => {
        const scenario_gkey = this.state.records.gkey;
        const selectedData = gridApi.getSelectedRows();
        const ManageDatasetData = selectedData.map(value => (
            { scenario_key: scenario_gkey, aut_app_gkey: value.gkey }
        ))
        event.currentTarget.disabled = true;
        try {
            if (selectedData.length == 0) {
                const response = await ScenarioService.Deletemap_autapp_scenario(scenario_gkey)
                if (response.status == 200 || response.status == 201) {
                    await this.getScenarioByOrg();
                    toast.success('Manage dataset records removed successfully !')
                }
            } else if (selectedData.length > 0) {
                const response = await ScenarioService.Updatemap_autapp_scenarios(ManageDatasetData)
                if (response.status == 200 || response.status == 201) {
                    toast.success('Manage dataset records added / updated successfully!');
                    await this.getScenarioByOrg();
                }
            }
            await this.editRecordUpdate(scenario_gkey)
        } catch (error) {
            console.error('error', error)
        }
    };

    arrangeSequence_onClick = async (event, gridApi) => {
        if (gridApi) {
            const updatedRowOrder = [];
            gridApi.forEachNodeAfterFilterAndSort((node) => {
                updatedRowOrder.push(node.data);
            });

            const scenario_gkey = this.state.records.gkey;
            const ManageSequenceData = updatedRowOrder.map(value => (
                { scenario_key: scenario_gkey, sequence_gkey: value.gkey }
            ))
            event.currentTarget.disabled = true;
            console.log('updatedRowOrder', ManageSequenceData)
            const response = await ScenarioService.Update_map_scenario_sequence(ManageSequenceData)
            if (response.status == 200 || response.status == 201) {
                toast.success('Sequence arranged successfully!');
                await this.getScenarioByOrg();
            }
        }
    };

    editRecordUpdate = async (scenario_gkey) => {
        await this.getScenarioByOrg();
        const updatedRec = this.state.scenarioData.find(value => value.gkey === scenario_gkey);
        this.setState({ records: updatedRec });
    };

    reset_onClick = (e) => {
        e.preventDefault();

        this.setState(prevState => ({
            records: {
                ...prevState.records,
                displayName: '',
                longName: '',
                Stream_gkey: '',
                description: ''
            },
            errors: {
                displayName: '',
                longName: '',
                stream: '',
            },
        })
        )
        this.streamRef.current.clearValue();
    };

    onFilterTextBoxChanged = () => {
        let filterValue = document.getElementById('filter-text-box').value;
        this.setState({
            filterValue: filterValue
        })
    };

    render() {

        return (
            <AuthCommonLayout editScenarioFlag={this.state.editScenarioFlag}>
                <div>

                    <div id='screenHeader'>
                        <div id='Header' class='w-full flex justify-between items-center py-4 px-3  border-b-[1.5px] border-[#00000028]'>
                            <nav className='flex items-center space-x-1'>
                                <Link to="/dashboard/organization/:organization/Role/:Role" >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <g clip-path="url(#clip0_287_8398)">
                                            <path d="M22.4733 11.5266L12.4733 1.52663C12.3484 1.40246 12.1795 1.33276 12.0034 1.33276C11.8272 1.33276 11.6583 1.40246 11.5334 1.52663L1.53335 11.5266C1.42413 11.6542 1.36706 11.8182 1.37354 11.986C1.38002 12.1538 1.44958 12.3129 1.56831 12.4317C1.68704 12.5504 1.8462 12.62 2.01398 12.6264C2.18177 12.6329 2.34582 12.5758 2.47335 12.4666L12 2.93996L21.5267 12.4733C21.6542 12.5825 21.8183 12.6396 21.9861 12.6331C22.1538 12.6266 22.313 12.5571 22.4317 12.4383C22.5505 12.3196 22.62 12.1604 22.6265 11.9927C22.633 11.8249 22.5759 11.6608 22.4667 11.5333L22.4733 11.5266Z" fill="#6C7178" />
                                            <path d="M18.6667 21.3334H15.3333V14.6668H8.66667V21.3334H5.33333V12.0001L4 13.3334V21.3334C4 21.687 4.14048 22.0262 4.39052 22.2762C4.64057 22.5263 4.97971 22.6668 5.33333 22.6668H10V16.0001H14V22.6668H18.6667C19.0203 22.6668 19.3594 22.5263 19.6095 22.2762C19.8595 22.0262 20 21.687 20 21.3334V13.1734L18.6667 11.8401V21.3334Z" fill="#6C7178" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_287_8398">
                                                <rect width="24" height="24" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </Link>
                                {this.state.navPath.map((item, index) =>
                                    <nav className='flex items-center space-x-1'>
                                        <span className='mt-[2px]'>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64237 1.7263L11.4368 7.5311C11.4889 7.58094 11.5303 7.64094 11.5584 7.7074C11.5865 7.77386 11.6006 7.84536 11.6 7.9175C11.6002 8.06638 11.5415 8.2093 11.4368 8.3151C9.34077 10.3599 7.32077 12.3335 5.37677 14.2359C5.27677 14.3295 4.87677 14.5623 4.56797 14.2167C4.25917 13.8703 4.44637 13.5687 4.56797 13.4439L10.2224 7.9175L4.82477 2.5103C4.62797 2.2391 4.64397 1.9887 4.87277 1.7591C5.10157 1.5295 5.35837 1.5183 5.64237 1.7263Z" fill="#CDD2DA" />
                                            </svg>
                                        </span>
                                        <nav onClick={this.state.navPath.length - 1 == index ? null : this.backToMainScreen}>
                                            <h1 className={`font-roboto ${this.state.navPath.length - 1 == index ? 'text-page-header-2xl text-page-header' : 'text-[17px] cursor-pointer font-normal text-zinc-500'}`}>{item}</h1>
                                        </nav>
                                    </nav>
                                )
                                }
                            </nav>
                            {this.state.ScenarioformFlag ?
                                <div className='flex items-center'>
                                    <div id="scenario-search">
                                        {this.state.isGridView ?
                                            <div class="relative mr-5 rounded-md border border-black border-opacity-5 flex items-center h-8 bg-search-bg overflow-hidden">
                                                <div class="grid place-items-center h-full w-12 text-search-text">
                                                    <HiOutlineSearch color='#0000004D' size={24} />
                                                </div>
                                                <input
                                                    id="filter-text-box"
                                                    onInput={this.onFilterTextBoxChanged}
                                                    class="peer text-search-text bg-search-bg h-full w-full max-sm:w-[100px] outline-none text-search-text-size placeholder-[#0000004D]  placeholder:text-xs placeholder:font-normal pr-2"
                                                    type="text"
                                                    placeholder="Search..." />
                                            </div>
                                            : null}
                                    </div>

                                    <span onClick={() => { this.setState({ isGridView: true }) }} className={`border ${this.state.isGridView ? 'border-blue-800' : 'border-transparent'} rounded-[3px] cursor-pointer p-1`}>
                                        <HiQueueList size={22} color={this.state.isGridView ? '#1F52A3' : '#0000004D'} />
                                    </span>
                                    <span onClick={() => { this.setState({ isGridView: false }) }} className={`border ${this.state.isGridView ? 'border-transparent' : 'border-blue-800'} rounded-[3px] cursor-pointer p-1 `}>
                                        <VscListTree size={24} color={this.state.isGridView ? '#0000004D' : '#1F52A3'} />
                                    </span>

                                </div>
                                : null}
                        </div>
                    </div>

                    <div id='screenBody'>
                        {this.state.ScenarioformFlag ?
                            <div>
                                {this.state.isGridView ?
                                    <AllScenarioGrid
                                        scenarioData={this.state.scenarioData}
                                        isGridView={this.state.isGridView}
                                        applyTo_Options={this.state.applyTo_Options}
                                        streamOptions={this.state.streamOptions}
                                        filterValue={this.state.filterValue}
                                        addEditScenario_Open={this.addEditScenario_Open}
                                        deleteScenario_Open={this.deleteScenario_Open}
                                        viewSequence_DataSet_Open={this.viewSequence_DataSet_Open}
                                    />
                                    :
                                    <ScenariosByStream
                                        scenarioData={this.state.groupByStream}
                                        streamOptions={this.state.streamOptions}
                                        streamList={this.state.streamList}
                                        isGridView={this.state.isGridView}
                                        applyTo_Options={this.state.applyTo_Options}
                                        addEditScenario_Open={this.addEditScenario_Open}
                                        deleteScenario_Open={this.deleteScenario_Open}
                                        viewSequence_DataSet_Open={this.viewSequence_DataSet_Open}
                                    />
                                }
                                <div className="fixed bottom-6 right-10"  >
                                    <button onClick={(e) => this.addEditScenario_Open(e)} class={ControlsConstants.ToolTip.addbutton}>
                                        <HiPlus className={ControlsConstants.ToolTip.iconsize} aria-hidden="true" />
                                        <div class={ControlsConstants.ToolTip.tooltipGroup}>
                                            <span class={ControlsConstants.ToolTip.tooltiptext}>{localConstant.SCENARIO.ADD_SCENARIO}</span>
                                            <div class={ControlsConstants.ToolTip.tooltipArrow}></div>
                                        </div>
                                    </button>
                                </div>
                            </div>
                            :
                            <div id="ScenarioForm" className='w-[100%] flex flex-col'>
                                {this.state.addScenarioFlag || this.state.editScenarioFlag ?
                                    this.state.addScenarioFlag ?
                                        <div className='w-[60%]  mt-5'>
                                            <FormScenario
                                                onValueOnChange={this.AddEditScenario_OnChange}
                                                records={this.state.records}
                                                errors={this.state.errors}
                                                streamOptions={this.state.streamOptions}
                                                streamRef={this.streamRef}
                                                addScenario_onClick={this.addScenario_onClick}
                                                reset_onClick={this.reset_onClick}
                                                addScenarioFlag={this.state.addScenarioFlag}
                                            />
                                            {/* <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pb-0 p-4 rounded-b-md space-x-5">
                                                <button type="button" onClick={this.addScenario_onClick} className={ControlsConstants.Buttons.btnPrimaryBlue} >Add</button>
                                                <button type="button" onClick={this.reset_onClick} className={ControlsConstants.Buttons.btnresetempty} data-bs-dismiss="modal" >Reset</button>
                                            </div> */}
                                        </div>
                                        :
                                        <EditScenario
                                            allSequenceData={this.state.allSequenceData}
                                            allColumnsData={this.state.allColumnsData}
                                            onValueOnChange={this.AddEditScenario_OnChange}
                                            editScenario_onClick={this.editScenario_onClick}
                                            reset_onClick={this.reset_onClick}
                                            records={this.state.records}
                                            errors={this.state.errors}
                                            streamOptions={this.state.streamOptions}
                                            applyTo_Options={this.state.applyTo_Options}
                                            manageSequence_onClick={this.manageSequence_onClick}
                                            manageDataset_onClick={this.manageDataset_onClick}
                                            streamRef={this.streamRef}
                                            backToScenario_onClick={this.backToMainScreen}
                                            addScenarioFlag={this.state.addScenarioFlag}
                                        />
                                    : <ViewSequence_DataSet
                                        allSequenceData={this.state.allSequenceData}
                                        allColumnsData={this.state.allColumnsData}
                                        records={this.state.records}
                                        scenarioDatasetData={this.state.scenarioDatasetData}
                                        streamOptions={this.state.streamOptions}
                                        applyTo_Options={this.state.applyTo_Options}
                                        arrangeSequence_onClick={this.arrangeSequence_onClick}
                                        backToScenario_onClick={this.backToMainScreen}
                                    />
                                }

                            </div>
                        }

                        {this.state.deleteScenarioFlag ?
                            <ReactDialogBox
                                closeBox={this.backToMainScreen}
                                modalWidth='30vw'
                                headerBackgroundColor={ControlsConstants.Model.headerbg}
                                headerTextColor={ControlsConstants.Model.bodybg}
                                headerHeight={ControlsConstants.Model.headerheight}
                                closeButtonColor={ControlsConstants.Model.closebtncolor}
                                bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                headerText={this.state.modelHeader}
                            >
                                <div class='flex items-center h-16 pl-7'>
                                    <div>{localConstant.SCENARIO.DELETE_CONTENT} <span class='text-delete-user-text'> {this.state.deleteData.displayName}</span>?</div>
                                </div>
                                <div className="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end mt-2 pb-0 p-4 border-t border-gray-200 rounded-b-md">
                                    <button type="button" className={ControlsConstants.Buttons.btnPrimary}
                                        onClick={this.deleteScenario_OnClick}>{localConstant.COMMON_CONST.DELETE}</button>
                                    <button type="button" className={ControlsConstants.Buttons.btnSecondary}
                                        onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                                </div>
                            </ReactDialogBox>
                            : null
                        }
                        <ToastContainer limit={2} />
                    </div>
                </div>
            </AuthCommonLayout >
        )
    }
}


export default Scenario;



