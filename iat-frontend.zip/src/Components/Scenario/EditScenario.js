import React from 'react';
import editScenarioicon from '../../Images/editScenarioIcon.svg';
import manageSequenceicon from '../../Images/managesequenceicon.svg';
import manageDataseticon from '../../Images/manageDataset.svg';
import { ManageDataSet, ManageSequence } from './SequenceGrids';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import FormScenario from './FormScenario';
import { BsArrowBarLeft, BsArrowLeft, BsDot } from 'react-icons/bs';


class EditScenario extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            editDataFlag: 'scenario',
            isEditExpand: true,
        }
    }

    manageData = {
        scenario: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
        manageSequence: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
        manageDataset: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
    };

    editDataBtn = (flag) => {
        this.setState({ editDataFlag: flag });
    };

    render() {
        const { editDataFlag } = this.state;
        return (

            <div className=''>
                <div className='flex h-[71.5vh] '>
                    {this.state.isEditExpand ?
                        <div className='bg-slate-200 w-[30%] ease-out delay-300'>
                            <div className='flex items-center justify-between py-4 pr-3 pl-7 shadow-sm text-black text-opacity-50 text-xl font-semibold'>
                                <span>Scenario</span>
                                <span onClick={() => { this.setState({ isEditExpand: false }) }} className='cursor-pointer'><BsArrowLeft size={20} color='blue' /></span>
                            </div>
                            <div className="pl-5 pt-1">
                                <div onClick={() => this.editDataBtn('scenario')} className={`flex items-center cursor-pointer space-x-1  text-[#1F52A3] text-lg font-medium px-[10px] py-[6px] ${this.state.editDataFlag === 'scenario' ? ' ' : ''} p-[10px]`}>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 10 10" fill="none">
                                            <path d="M6.70814 1.60006C6.93258 1.37571 7.23695 1.2497 7.5543 1.24976C7.87165 1.24981 8.17597 1.37594 8.40033 1.60038C8.62468 1.82482 8.75069 2.12919 8.75064 2.44653C8.75058 2.76388 8.62445 3.06821 8.40001 3.29256L7.94189 3.75131L6.24939 2.05881L6.70814 1.60069V1.60006ZM5.80814 2.50069L2.08564 6.22194C1.97265 6.33501 1.88749 6.47281 1.83689 6.62444L1.26564 8.33881C1.24723 8.39386 1.24452 8.45295 1.25781 8.50945C1.2711 8.56595 1.29986 8.61763 1.34087 8.65871C1.38188 8.69978 1.43351 8.72862 1.49 8.742C1.54648 8.75538 1.60556 8.75276 1.66064 8.73444L3.37502 8.16256C3.52689 8.11256 3.66439 8.02694 3.77752 7.91381L7.50002 4.19319L5.80752 2.50006L5.80814 2.50069Z" fill="#1F52A3" />
                                        </svg>
                                    </span>
                                    <span > Edit Scenario</span>
                                </div>
                                <div className="text-zinc-500 text-[12px] font-normal  pl-2 space-y-3 pt-2 ">
                                    <div onClick={() => this.editDataBtn('manageSequence')} className={`flex cursor-pointer space-x-1 items-center px-[10px]  ${this.state.editDataFlag === 'manageSequence' ? ' ' : ''} pl-[25px]`}>
                                        <span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 5 6" fill="none">
                                                <circle cx="2.5" cy="3" r="2.5" fill="black" fill-opacity="0.5" />
                                            </svg>
                                        </span>
                                        <span>Manage Sequence</span>
                                    </div>
                                    <div onClick={() => this.editDataBtn('manageDataset')} className={`flex cursor-pointer space-x-1 items-center px-[10px] ${this.state.editDataFlag === 'manageDataset' ? ' ' : ''} pl-[25px]`}>
                                        <span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 5 6" fill="none">
                                                <circle cx="2.5" cy="3" r="2.5" fill="black" fill-opacity="0.5" />
                                            </svg>
                                        </span>
                                        <span>Manage DataSet</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        :
                        <div onClick={() => { this.setState({ isEditExpand: true }) }} className='w-[36px] h-[34px] ml-4 mt-5 bg-white cursor-pointer rounded-sm border border-black border-opacity-10 hover:bg-gray-50 flex items-center'>
                            <span className='ml-1'>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 12 8" fill="none">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M7.35117 0.661862C7.5813 0.446046 7.95441 0.446046 8.18455 0.661862L11.3274 3.60923C11.5575 3.82505 11.5575 4.17495 11.3274 4.39077L8.18455 7.33814C7.95441 7.55395 7.5813 7.55395 7.35117 7.33814C7.12104 7.12232 7.12104 6.77241 7.35117 6.5566L9.48805 4.55263H1.08929C0.763832 4.55263 0.5 4.30521 0.5 4C0.5 3.69479 0.763832 3.44737 1.08929 3.44737H9.48805L7.35117 1.4434C7.12104 1.22759 7.12104 0.877678 7.35117 0.661862Z" fill="#4676B4" />
                                </svg>
                            </span>
                        </div>
                    }

                    <div className='px-10 pt-4 w-full'>
                        {this.state.editDataFlag === 'scenario' &&
                            <div className='w-[80%]'>
                                <FormScenario
                                    onValueOnChange={this.props.onValueOnChange}
                                    records={this.props.records}
                                    errors={this.props.errors}
                                    Header={this.props.modelheader}
                                    streamOptions={this.props.streamOptions}
                                    streamRef={this.props.streamRef}
                                    editScenario_onClick={this.props.editScenario_onClick}
                                    reset_onClick={this.props.reset_onClick}
                                    addScenarioFlag={this.props.addScenarioFlag}
                                />
                            </div>
                        }

                        {this.state.editDataFlag === 'manageSequence' &&
                            <div className='w-[80%]'>
                                <ManageSequence
                                    allSequenceData={this.props.allSequenceData}
                                    records={this.props.records}
                                    ref={this.props.ref}
                                    applyTo_Options={this.props.applyTo_Options}
                                    manageSequence_onClick={this.props.manageSequence_onClick}
                                    backToScenario_onClick={this.props.backToScenario_onClick}
                                />
                            </div>
                        }
                        {this.state.editDataFlag === 'manageDataset' &&
                            <div className='w-[80%]'>
                                <ManageDataSet
                                    allColumnsData={this.props.allColumnsData}
                                    records={this.props.records}
                                    manageDataset_onClick={this.props.manageDataset_onClick}
                                    backToScenario_onClick={this.props.backToScenario_onClick}
                                />
                            </div>
                        }
                    </div>

                </div>
            </div>
        )
    }
}

export default EditScenario;


