import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { AgGridReact } from "ag-grid-react";
import { HiChevronDoubleDown, HiChevronDoubleUp, HiChevronDown, HiChevronRight, HiOutlineSearch } from "react-icons/hi";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, EyeLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import { GridConstants } from '../../Constants/GridConstants';

const gridLocalConstants = GridConstants.AGGrid.Secondary_Grid;

export const AllScenarioGrid = (props) => {

    const columnDefs = [
        // {
        //     headerName: "ID", minWidth: 120, suppressMovable: true, flex: 1,
        //     cellRenderer: (params) => {
        //         const id = `300${params.rowIndex + 1}`.slice(-4);
        //         return <span className=' text-blue-600 cursor-pointer underline underline-offset-1' onClick={(e) => props.addEditScenario_Open(e, params.data)}> {'SC' + id}</span>
        //     },
        // },
        {
            headerName: "Display Name", field: "displayName", suppressMovable: true, minWidth: 150, flex: 2,
            cellRenderer: (params) => {
                return <span className=' text-blue-600 cursor-pointer ' onClick={(e) => props.addEditScenario_Open(e, params.data)}>{params.value}</span>
            },
        },
        { headerName: "Long Name", field: "longName", suppressMovable: true, minWidth: 200, flex: 2, },
        {
            headerName: "Stream", field: "Stream_gkey", suppressMovable: true, minWidth: 200, flex: 2,
            cellRenderer: (params) => {
                let result = props.streamOptions.find(({ value }) => value === params.value);
                return result.label
            }
        },
        {
            headerName: "Action", field: "Action", suppressMovable: true, minWidth: 150, flex: 1,
            cellRendererFramework: (params) =>
                <div class='flex w-full h-full items-center space-x-4'>
                    <button onClick={(e) => props.viewSequence_DataSet_Open(e, params.data)} >
                        <EyeLogo />
                    </button>
                    <button onClick={(e) => props.addEditScenario_Open(e, params.data)}>
                        <EditLogo />
                    </button>
                    <button onClick={() => props.deleteScenario_Open(params.data)} >
                        <TrashLogo />
                    </button>
                </div>
        }
    ];

    return (
        <div id="AGGrid">
            <div id='CustomAgGrid'>
                <CustomAgGrid
                    rowData={props.scenarioData}
                    columnDefs={columnDefs}
                    onGridReady={() => { console.log('eee') }}
                    filterValue={props.filterValue}
                />
            </div>
        </div>
    )
};

export const ScenariosByStream = (props) => {

    const groupByStream = props.scenarioData;
    const [groupFlags, setGroupFlags] = useState([]);

    const closeListPanel = (e, index) => {
        e.preventDefault();
        const updatedGroupFlags = [...groupFlags];
        updatedGroupFlags[index] = false;
        setGroupFlags(updatedGroupFlags);
    };

    const openListPanel = (e, index) => {
        e.preventDefault();
        let updatedGroupFlags = [];
        for (let i = 0; i <= index; i++) {
            i === index ? updatedGroupFlags[i] = true : updatedGroupFlags[i] = false
        }
        setGroupFlags(updatedGroupFlags);
    };

    return (
        <div className="font-roboto text-lg flex flex-col p-7 ">
            {/* {Object.keys(groupByStream).map((stream, ind) =>
                <div key={ind} className="flex justify-center pt-2 h-4/5">
                    <div className=" w-full bg-transparent font-[12px]">
                        <div className='bg-white border-b-[1px] p-1 py-2 '>
                            <div className="flex justify-between font-roboto font-bold text-[17px] text-[#89879fd3]">
                                <div className="flex items-center mx-4  rounded cursor-pointer" >
                                    {groupFlags[ind] ?
                                        <HiChevronDown size={22} color='#89879fd3' onClick={(e) => closeListPanel(e, ind)} />
                                        :
                                        <HiChevronRight size={22} color='#89879fd3' onClick={(e) => openListPanel(e, ind)} />
                                    }
                                    <span className='ml-3 mr-1'>{stream}</span>
                                    <span className='text-sm'>({groupByStream[stream].length})</span>
                                </div>
                            </div>
                        </div>
                        <div >
                            {(groupFlags[ind]) ?
                                <AllScenarioGrid
                                    scenarioData={groupByStream[stream]}
                                    addEditScenario_Open={props.addEditScenario_Open}
                                    isGridView={props.isGridView}
                                    applyTo_Options={props.applyTo_Options}
                                    deleteScenario_Open={props.deleteScenario_Open}
                                    streamOptions={props.streamOptions}
                                    dataSetOpen={props.dataSetOpen}
                                    viewSequence_DataSet_Open={props.viewSequence_DataSet_Open}
                                />
                                :
                                null
                            }
                        </div>
                    </div>
                </div>
            )} */}
            {Object.keys(groupByStream).map((stream, ind) => (
                <div className="pt-2 h-4/5 w-full border-2px border-solid "  >
                    <div className="flex justify-center">
                        <div className="p-1 mb-2 w-full bg-transparent">
                            <div className={(!groupFlags[ind]) ? ' border-[4px] solid  border-[#33658A]  rounded-md font-[12px]   ' : 'border-[4px] solid  border-[#33658A]  rounded-md font-[12px]'}>
                                <div className='bg-[#33658A] p-2  '>
                                    <div className="flex justify-between items-center  gap-2 text-slate-50">
                                        <span className="flex items-center">
                                            {groupFlags[ind] ?
                                                <span id="arrowShadow">
                                                    < HiChevronDoubleUp size={20} onClick={(e) => closeListPanel(e, ind)} />
                                                </span> :

                                                <span id="arrowShadow">
                                                    <HiChevronDoubleDown size={20} onClick={(e) => openListPanel(e, ind)} />
                                                </span>
                                            }
                                            <span className='ml-3 mr-1'>{stream}</span>
                                            <span className='text-sm'>({groupByStream[stream].length})</span>
                                        </span>

                                    </div>
                                </div>
                                <div>
                                    {(groupFlags[ind]) ?
                                        <div className='pb-3 bg-[#f6fcfd]' >
                                            <AllScenarioGrid
                                                scenarioData={groupByStream[stream]}
                                                addEditScenario_Open={props.addEditScenario_Open}
                                                isGridView={props.isGridView}
                                                applyTo_Options={props.applyTo_Options}
                                                deleteScenario_Open={props.deleteScenario_Open}
                                                streamOptions={props.streamOptions}
                                                dataSetOpen={props.dataSetOpen}
                                                viewSequence_DataSet_Open={props.viewSequence_DataSet_Open}
                                            />
                                        </div>
                                        : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export const ArrangeSequence = (props) => {
    const allSequenceData = props.allSequenceData;
    const scenarioSequenceData = props.records.scen_seqs;
    const gridApiRef = useRef(null);
    const [gridApi, setGridApi] = useState();
    const [rowData, setRowData] = useState();
    const [columnDefs] = useState([
        {
            headerName: "Label", field: 'lable', rowDrag: true, suppressMovable: true, flex: 2,
        },
        {
            headerName: "Apply To", field: "aut_app_gkey", suppressMovable: true, flex: 2,
            cellRenderer: (params) => {
                const result = props.applyTo_Options.find(({ value }) => value === params.value);
                return result.label
            }
        },
        {
            headerName: "Parameterizable", field: 'Parameterizable', flex: 2, suppressMovable: true,
            // singleClickEdit: true,
            // editable: (params) => params.data.Parameterizable !== false,
            cellRenderer: (params) => {
                const paramValue = params.data.Parameterizable;
                return (
                    <div className="flex items-center justify-around cursor-pointer">
                        <div className="overflow-clip">{paramValue === false || paramValue === 'false' ? "-" : paramValue == ""
                            ?
                            <span class='text-red-400'>Error</span> : paramValue}
                        </div>
                        {/* {paramValue === false ? null : paramValue == "" ?
                            <div className="w-1/3"><BiError color='red' size={15} /></div>
                            :
                            <div className="w-1/3"><BiEditAlt color='blue' size={15} /></div>
                        } */}
                    </div>
                )
            }
        },
    ]);

    useEffect(() => {
        let tempRowData = [];
        scenarioSequenceData.map(item => (
            allSequenceData.map(value => {
                if (value.gkey == item.sequence_gkey) {
                    tempRowData.push(value);
                }
            })));
        setRowData(tempRowData);
    }, []);

    const onGridReady = useCallback((params) => {
        const gridApi = params.api;
        gridApiRef.current = gridApi;
        setGridApi(gridApiRef.current);
    }, []);

    return (
        <>
            <div class="bg-white  ">
                <div className='bg-white rounded'>
                    <div className="ag-theme-alpine h-[50vh]  rounded" id="secondaryGridBorder"  >
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            headerHeight={35}
                            animateRows={true}
                            defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
                            rowDragManaged={true}
                            rowDragMultiRow={true}
                            onGridReady={onGridReady}
                            rowHeight={35}
                            // getRowStyle={getRowStyle}
                            pagination={false}
                            rowSelection={'multiple'}
                            gridOptions={gridLocalConstants.gridOptions}
                            suppressRowClickSelection={true}
                            suppressRowHoverHighlight={true}
                            overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                            overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                        />
                    </div>
                </div>
                <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pt-5  rounded-b-md space-x-3">
                    <button type="button" onClick={(e) => { props.arrangeSequence_onClick(e, gridApi) }}
                        className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                    <button type="button" onClick={props.backToScenario_onClick}
                        className={ControlsConstants.Buttons.btnSecondary} >CANCEL</button>
                </div>
            </div>
        </>
    );
};

export const ManageSequence = (props) => {
    const [gridApi, setGridApi] = useState()
    const rowData = props.allSequenceData;
    const scenarioSequenceData = props.records.scen_seqs;
    const [columnDefs] = useState([
        {
            field: '', width: 50, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true,
        },
        {
            headerName: "Label", field: "lable", suppressMovable: true, flex: 1,
        },
        {
            field: 'Parameterizable', flex: 1, suppressMovable: true,//singleClickEdit: true,
            // editable: (params) => params.data.Parameterizable !== false,
            cellRenderer: (params) => {
                return (
                    <span className=' justify-center '>{params.data.Parameterizable === false || params.data.Parameterizable === 'false' ? "-" : params.data.Parameterizable}</span>
                )
            }
        },
        {
            headerName: "Apply To", field: "aut_app_gkey", suppressMovable: true, flex: 1,
            cellRenderer: (params) => {
                const result = props.applyTo_Options.find(({ value }) => value === params.value);
                return result.label
            }
        },
    ]);

    const onGridReady = (params) => {
        setGridApi(params.api);
        const seqGkeys = scenarioSequenceData == undefined ? [] : scenarioSequenceData.map(item => item.sequence_gkey);
        params.api.forEachLeafNode((node) => {
            if (seqGkeys.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    return (

        <div class="bg-white ">
            <div className='bg-white rounded'>
                <div className="ag-theme-alpine h-[35vh]  rounded" id="secondaryGridBorder"  >
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        animateRows={true}
                        defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
                        headerHeight={35}
                        rowHeight={35}
                        pagination={false}
                        rowSelection={'multiple'}
                        gridOptions={gridLocalConstants.gridOptions}
                        suppressRowClickSelection={true}
                        onGridReady={onGridReady}
                        // getRowStyle={getRowStyle}
                        suppressRowHoverHighlight={true}
                        overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center mt-5  rounded-b-md space-x-3">
                <button type="button" onClick={(e) => { props.manageSequence_onClick(e, gridApi) }}
                    className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                <button type="button" onClick={props.backToScenario_onClick}
                    className={ControlsConstants.Buttons.btnSecondary}  >CANCEL</button>
            </div>
        </div>
    );

};

export const ViewDataSet = (props) => {

    const allColumnsData = props.allColumnsData;
    const scenarioDatasetData = props.records.scen_auts;
    const [rowData, setRowData] = useState();
    const [columnDefs] = useState([
        {
            headerName: 'Label', field: 'shortName', flex: 2, suppressMovable: true,
        },
        {
            headerName: 'Display Name', field: 'displayName', flex: 2, suppressMovable: true,
        },
        {
            headerName: "control", field: "control", flex: 1, suppressMovable: true,
        }
    ]);

    useEffect(() => {
        let tempRowData = [];
        allColumnsData.map(item => (
            scenarioDatasetData.map(value => {
                if (item.gkey == value.aut_app_gkey) {
                    tempRowData.push(item);
                }
            })))
        setRowData(tempRowData)
    }, []);

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (
        <>
            <div class="bg-white">
                <div className='bg-white rounded'>
                    <div className="ag-theme-alpine h-[50vh] rounded" id="secondaryGridBorder"  >
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            animateRows={true}
                            defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
                            headerHeight={35}
                            rowHeight={35}
                            pagination={false}
                            rowSelection={'multiple'}
                            gridOptions={gridLocalConstants.gridOptions}
                            // getRowStyle={getRowStyle}
                            suppressRowClickSelection={true}
                            suppressRowHoverHighlight={true}
                            overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                            overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                        />
                    </div>
                </div>
                <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center mt-5  rounded-b-md space-x-5">
                    <span className='text-md text-black font-semibold'>Total Dataset Records: {scenarioDatasetData.length}</span>
                </div>
            </div>
        </>
    );
};

export function ManageDataSet(props) {

    const [gridApi, setGridApi] = useState()
    //Get Data from Redux
    const rowData = props.allColumnsData;
    const scenarioDatasetData = props.records.scen_auts;
    const [columnDefs] = useState([
        {
            headerName: 'Short Name', field: 'shortName', suppressMovable: true, flex: 2, headerCheckboxSelectionFilteredOnly: true, headerCheckboxSelection: true,
            checkboxSelection: true,
        },
        { headerName: 'Display Name', field: 'displayName', flex: 2, suppressMovable: true, },
        { headerName: 'Control', field: 'control', flex: 2, suppressMovable: true, },

    ]);

    const onGridReady = (params) => {
        setGridApi(params.api);
        const dataSetGkeys = scenarioDatasetData?.map(item => item.aut_app_gkey);
        params.api.forEachLeafNode((node) => {
            if (dataSetGkeys.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (
        <div class="bg-white ">
            <div className='bg-white rounded'>
                <div className="ag-theme-alpine h-[35vh]  rounded" id="secondaryGridBorder"  >
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
                        animateRows={true}
                        headerHeight={35}
                        rowHeight={35}
                        pagination={false}
                        rowSelection={'multiple'}
                        gridOptions={gridLocalConstants.gridOptions}
                        onGridReady={onGridReady}
                        suppressRowClickSelection={true}
                        suppressRowHoverHighlight={true}
                        // getRowStyle={getRowStyle}
                        overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className=" modal-footer  flex flex-shrink-0 flex-wrap items-center justify-center  mt-5 rounded-b-md space-x-3">
                <button type="button" onClick={(e) => { props.manageDataset_onClick(e, gridApi) }}
                    className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                <button type="button" onClick={props.backToScenario_onClick}
                    className={ControlsConstants.Buttons.btnSecondary} >CANCEL</button>
            </div>
        </div>
    );
};

//     const rowDatas = [
//         { userName: 'Aravind', selected: true },
//         { userName: 'Ivan Lendil', selected: true },
//         { userName: 'Akash', selected: true },
//         { userName: 'Naveen Kumar', selected: true },
//         { userName: 'Gokul', selected: true },
//         { userName: 'Mubarak', selected: false },
//         { userName: 'Rajesh', selected: false },
//         { userName: 'Nagarasu', selected: false },

//     ]
//     const gridApiRef = useRef(null);
//     const [userData, setUserData] = useState();
//     const [assignUsers, setAssignUsers] = useState('selectedUsers')
//     const [gridApi, setGridApi] = useState();
//     const [columnDefs] = useState([
//         {
//             headerName: 'User Name', field: 'userName', flex: 3, suppressMovable: true,
//         },

//         {
//             field: '', minWidth: 80, flex: 1, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true,
//         }


//     ]);


//     useEffect(() => {
//         let tempUserData = [];
//         rowDatas.map((val) => {
//             if (val.selected === true) tempUserData.push(val)
//         })
//         setUserData(tempUserData);
//     }, []);


//     const assignUsersToggle = (e) => {
//         let toggleValue = e.target.value;
//         setAssignUsers(toggleValue)
//         if (toggleValue == 'allUsers') {
//             gridApi.setRowData(rowDatas);
//         } else {
//             let tempUserData = [];
//             rowDatas.map((val) => {
//                 if (val.selected === true) tempUserData.push(val)
//             })
//             gridApi.setRowData(tempUserData);

//         }
//         gridApi.forEachLeafNode((node) => {
//             node.setSelected(node.data.selected);
//         });
//     }

//     const onGridReady = (params) => {
//         setGridApi(params.api)
//         params.api.forEachLeafNode((node) => {
//             node.setSelected(node.data.selected);
//         });
//     };

//     const onFilterTextBoxChanged = () => {
//         gridApi.Refcurrent.api.setQuickFilter(
//             document.getElementById('filter-text-box').value
//         );
//     };

//     return (
//         <>
//             <div className="flex  justify-around text-black font-roboto font-[600] items-center  my-3">
//                 <div className={`flex items-center p-2 rounded w-[40%] border-2 ${assignUsers == 'selectedUsers' ? ' border-blue-400' : ' bg-gray-100  border-transparent'}`}>
//                     <input type="radio" id="selectedUsers" name="assignUsers" checked={assignUsers == 'selectedUsers' && true} value="selectedUsers" onClick={(e) => assignUsersToggle(e)} />
//                     <label for="selectedUsers" className=" ml-2 text-sm">Selected Users {'(5)'}</label>
//                 </div>
//                 <div className={`flex items-center p-2 rounded w-[40%] border-2 ${assignUsers == 'allUsers' ? ' border-blue-400' : 'bg-gray-100  border-transparent'}`}>
//                     <input type="radio" id="allUsers" name="assignUsers" checked={assignUsers == 'allUsers' && true} value="allUsers" onClick={(e) => assignUsersToggle(e)} />
//                     <label for="allUsers" className=" ml-2 text-sm">All Users {'(8)'}</label>
//                 </div>
//             </div>

//             <div class=" p-2 h-[50vh] ">
//                 <div class='flex justify-end mb-1'>
//                     <div id="manage-priv-search">
//                         <div class="relative  flex items-center  h-8 rounded-lg border-2 border-gray- w-full bg-white overflow-hidden">
//                             <div class="grid place-items-center h-full w-12 text-search-text">
//                                 <HiOutlineSearch size={localControlsConstant.Icon.search.size} />
//                             </div>
//                             <input
//                                 id="filter-text-box"
//                                 onInput={onFilterTextBoxChanged}
//                                 class="peer text-search-text bg-white h-full w-full max-sm:w-[100px] outline-none text-search-text-size placeholder-search-text  pr-2"
//                                 type="text"
//                                 placeholder="Search..." />
//                         </div>
//                     </div>
//                 </div>
//                 {/* <div className='text-[12px] font-semibold text-blue-600 space-x-5 text-end py-1'>
//                     <span className='cursor-pointer'>Select All</span>
//                     <span className='cursor-pointer'>Deselect All</span>
//                 </div> */}
//                 <div className='bg-white rounded'>
//                     <div className="ag-theme-alpine h-[40vh] p-2  rounded" id="secondaryGrid"  >
//                         <AgGridReact
//                             rowData={userData}
//                             columnDefs={columnDefs}
//                             defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
//                             animateRows={true}
//                             ref={gridApiRef}
//                             headerHeight={35}
//                             rowHeight={35}
//                             pagination={false}
//                             rowSelection={'multiple'}
//                             gridOptions={gridLocalConstants.gridOptions}
//                             onGridReady={onGridReady}
//                             suppressRowClickSelection={true}
//                             suppressRowHoverHighlight={true}
//                             overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
//                             overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
//                         />
//                     </div>
//                 </div>
//                 <div className="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end shadow-[0px_2px_1px_#3c40434c_inset] pb-0 p-4   rounded-b-md">
//                     {assignUsers == 'allUsers' &&
//                         <button type="button" className={ControlsConstants.Buttons.btnSecondary}>Update</button>
//                     }
//                 </div>
//             </div>
//         </>
//     );
// };


