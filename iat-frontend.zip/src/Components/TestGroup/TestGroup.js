import React from "react";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { HiChevronDoubleDown, HiChevronDoubleUp, HiOutlineSearch } from "react-icons/hi";
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { HiPlus } from "react-icons/hi";
import { HiOutlineTrash } from "react-icons/hi";
import { MdOutlineModeEditOutline } from "react-icons/md";
import FormTestGroup from "./FormTestGroup";
import { ReactDialogBox } from "react-js-dialog-box";
import _, { isArray } from "lodash";
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { ToastContainer, toast } from "react-toastify";
import { ManageScenarios, Scenarios } from "./ScenarioGrids";
import StreamService from '../../Services/StreamService';
import UserService from "../../Services/UserService";
import TestGroupService from "../../Services/TestGroupService";
import ScenarioService from "../../Services/ScenarioService";
import noRecordsImg from '../../Images/norecords.svg';
import ComponentHeader from "../../CommonUtils/ComponentHeader";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3076
class TestGroup extends React.Component {

    constructor() {
        super()
        this.state = {
            groupFlag: [],
            addGroupFlag: false,
            editGroupFlag: false,
            deleteGroupFlag: false,
            addScenariosFlag: false,
            modelheader: '',
            deleteData: {},
            records: {},
            streamData: [],
            allScenarioData: [],
            selectedGroup: {},
            groupScenarioData: [],
            errors: {
                lable: '',
            },
            rowData: []
        }
    };

    componentDidMount() {
        this.GetAllGroupsByOrg();
        this.GetAllTestUsersByOrg();
        this.LoadStreamData();
        this.getScenarioByOrg();
    }

    GetAllGroupsByOrg = async () => {
        const response = await TestGroupService.GetGroupByOrg();
        console.log('>>>>>>>>>>>group response', response.data)
        const groupData = _.map(response.data.GroupMap, item => ({
            gkey: item.Group.gkey,
            lable: item.Group.lable,
            description: item.Group.description,
            UserMapGroupGKey: item.Users,
            group_scenarios: response.data.group_scenario.filter(obj => obj.group_gkey === item.Group.gkey),
        }));
        console.log('>>>>>>>>>>>group groupData final', groupData)
        this.setState({ rowData: groupData })
    }

    GetAllTestUsersByOrg = async () => {
        try {
            const res = await UserService.AllUsersbyOrg(localStorage.getItem("MasterBizUitKey"));
            if (res.status == 200) {
                const modifiedUserData = res.data.map(user => {
                    const { firstName, lastName } = user;
                    const userName = `${firstName} ${lastName}`;
                    return { ...user, userName };
                });
                this.setState({ allUsers: modifiedUserData })
            } else {
                console.error(" Error in GetAllTestUsersByOrg ")
            }
        } catch (error) {
            console.error(error)
        }
    }

    LoadStreamData = async () => {
        try {
            const response = await StreamService.getStreamByOrg()
            const options = response.data.map(datas => (
                {
                    "value": datas.gkey,
                    "label": datas["name"]
                }
            ))
            this.setState({
                streamData: options,
            })
            console.log(options)
        } catch (error) {
            console.log('errr', error)
        }
    };

    getScenarioByOrg = async () => {
        try {
            const response = await ScenarioService.GetScenariosByOrg();
            if (response.status == 200) {
                this.setState({
                    allScenarioData: response.data.scenarios,
                })
            } else {
            }
        } catch (error) {
            console.error(error)
        }
    }

    closeListPanel = (e, index) => {
        e.preventDefault();
        let groupFlags = this.state.groupFlag;
        let item = { ...groupFlags[index] };
        item = false;
        groupFlags[index] = item;
        this.setState({
            groupFlag: groupFlags,
            isSearchClicked: false
        })
    };

    openListPanel = (e, index, item) => {
        e.preventDefault();
        let groupFlags = [];
        for (let i = 0; i <= index; i++) {
            i === index ? groupFlags[i] = true : groupFlags[i] = false
        }
        this.setState({
            groupFlag: groupFlags,
            selectedGroup: item,
            groupScenarioData: item.group_scenarios
        })
    };

    addScenariosOpen = (e, group) => {
        e.preventDefault();
        this.setState({
            addScenariosFlag: true,
            modelheader: 'Manage Sceanrio',
            lable: group
        })
    };

    addEditGroupOpen = (e, item) => {
        if (item == undefined || item == null) {
            this.setState({
                addGroupFlag: true,
                editGroupFlag: false,
                modelheader: 'Add TestGoup',
                records: { lable: '', UserMapGroupGKey: [], description: '' },
                errors: {
                    lable: ''
                },
            })
        } else {
            let data = item;
            this.setState({
                editGroupFlag: true,
                addGroupFlag: false,
                modelheader: 'Edit TestGoup',
                records: data,
                editIndex: item.index,
                errors: {
                    lable: '',
                },
            })
        }
    };

    onValueOnChange = (e) => {
        let name, value, errors = this.state.errors;

        if (isArray(e)) {
            name = "UserMapGroupGKey";
            value = e;
        } else {
            e.preventDefault();
            name = e.target.name;
            value = e.target.value;
        }
        this.setState(prevState => ({
            records: {
                ...prevState.records,
                [name]: value,
            }
        })
        )
        switch (name) {
            case 'lable':
                errors.lable = value.length < 1
                    ? "Group Name can't be empty ! "
                    : ''
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    };

    validateAllFields = (records) => {
        if (records.lable == "" || records.lable == null || records.lable == undefined || this.state.errors.lable != "") {
            let err = records.lable == undefined || records.lable == "" ? "Please Enter Group Name" : this.state.errors.lable;
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    lable: err
                },
            }));
            console.log("err", err)
            return false;
        }
        return true;
    };

    onAddGroupOn_Click = async (e) => {
        let records = this.state.records;
        const isValid = this.validateAllFields(records)
        if (isValid) {
            records["MasterBizUitKey"] = localStorage.getItem("MasterBizUitKey")
            // records["UserMapGroupGKey"] = records["UserMapGroupGKey"].map(user => user.gkey);
            console.log("Valid Records ", records);
            try {
                e.currentTarget.disabled = true;
                const response = await TestGroupService.CreateGroupByOrg(records);
                if (response.status == 201 || response.status == 200) {
                    toast.success('Group added successfully!');
                    this.GetAllGroupsByOrg();
                    this.backToMainScreen();
                }
            } catch (error) {
                toast.error(error)
            }
        }
        else {
            console.log(" not valid ", records)
        }
    };

    onEditGroupOn_Click = async (e) => {
        let records = this.state.records;
        const isValid = this.validateAllFields(records)
        if (isValid) {
            console.log(" raw records ", records)
            records["MasterBizUitKey"] = localStorage.getItem("MasterBizUitKey")
            // records["UserMapGroupGKey"] = records["UserMapGroupGKey"].map(user => user.gkey);
            console.log(" records ", records)
            try {
                e.currentTarget.disabled = true;
                const response = await TestGroupService.UpdateGroupByOrg(records);
                console.log(response)
                if (response.status == 201 || response.status == 200) {
                    toast.success('Group edited successfully!')
                    this.GetAllGroupsByOrg();
                    this.backToMainScreen();
                }
            } catch (error) {
                toast.error(error)
            }
        }
        else {
            console.log(" not valid ", records)
        }

    };

    deleteGroupOpen = (e, item, rows) => {
        if (rows > 0) {
            toast.error("Remove all the Scenarios Before Delete the Group !")
            return;
        }
        this.setState({
            deleteGroupFlag: true,
            deleteData: item
        })
    };

    deleteGroupOn_Click = async () => {
        try {
            const response = await TestGroupService.DeleteGroupByOrg(this.state.deleteData["gkey"]);
            if (response.status == 200 || response.status == 200) {
                toast.success('Group Deleted Successfully');
                this.GetAllGroupsByOrg();
                this.backToMainScreen();
            }
        } catch (error) {
            console.error(error)
        }
    };

    ManageScenario_onClick = async (event, gridApi) => {
        let group_gkey = this.state.selectedGroup.gkey;
        let selectedData = gridApi.getSelectedRows();
        let ManageScenarioData = selectedData.map(value => (
            { group_gkey: group_gkey, scenario_key: value.gkey }
        ))
        event.currentTarget.disabled = true;
        try {
            if (selectedData.length == 0) {
                const response = await TestGroupService.DeleteGroupScenariosByGroupGkey(group_gkey)
                if (response.status == 200 || response.status == 201) {
                    toast.success('Manage scenario records removed successfully !')
                    await this.GetAllGroupsByOrg();
                    this.backToMainScreen();
                }
            } else if (selectedData.length > 0) {
                const response = await TestGroupService.UpdateMapScenarioByGroup(ManageScenarioData)
                if (response.status == 200 || response.status == 201) {
                    toast.success('Manage scenario records updated successfully!');
                    await this.GetAllGroupsByOrg();
                    this.backToMainScreen();
                }
            }
            this.updateGroupScenario(group_gkey);
        } catch (error) {
            console.error('error', error)
        }
    };

    updateGroupScenario = async (group_gkey) => {
        await this.GetAllGroupsByOrg();
        const updatedRec = this.state.rowData.find(value => value.gkey === group_gkey);
        this.setState({ groupScenarioData: updatedRec.group_scenarios });
    };

    backToMainScreen = () => {
        this.setState({
            addGroupFlag: false,
            editGroupFlag: false,
            deleteGroupFlag: false,
            addScenariosFlag: false,
        })
    };
    onFilterTextBoxChanged = (e) => {
        this.setState({
            filterValue: e.target.value
        })
    };
    render() {
        const rows = this.state.rowData;
        return (
            <AuthCommonLayout>
                <div>
                    <div id='screenHeader'>
                        <ComponentHeader
                            isSearchable={false}
                            path={['Group']}
                            backToParentClass={this.backToMainScreen}
                        // onFilterTextBoxChanged={() => console.log()}
                        />
                    </div>

                    <div className='screenBody px-[15px] py-[20px] '>
                        {rows.map((item, index) => (
                            <div className="pt-2 h-4/5 w-full border-2px border-solid "  >
                                <div className="flex justify-center">
                                    <div className="p-1 mb-2 w-[88%] bg-transparent">
                                        <div className={(!this.state.groupFlag[index]) ? ' border-[4px] solid  border-[#33658A]  rounded-md font-[12px]   ' : 'border-[4px] solid  border-[#33658A]  rounded-md font-[12px] '}>
                                            <div className='bg-[#33658A] p-2  '>
                                                <div className="flex justify-between items-center  gap-2 text-slate-50">
                                                    <span className="flex items-center">
                                                        {(this.state.groupFlag[index]) ?
                                                            <span id="arrowShadow">
                                                                < HiChevronDoubleUp size={20} onClick={(e) => this.closeListPanel(e, index)} />
                                                            </span> :

                                                            <span id="arrowShadow">
                                                                <HiChevronDoubleDown size={20} onClick={(e) => this.openListPanel(e, index, item)} />
                                                            </span>
                                                        }
                                                        <p className="ml-2">{item.lable + " (" + item.group_scenarios.length + ")"}</p>

                                                    </span>
                                                    <span className="flex items-center">
                                                        {(this.state.groupFlag[index]) ?

                                                            this.state.isSearchClicked ?
                                                                <div class="relative max-w-[200px] flex items-center  h-[28px] rounded-lg  bg-white overflow-hidden mr-3">
                                                                    <div class="grid place-items-center h-full w-12 text-search-text">
                                                                        <HiOutlineSearch size={ControlsConstants.Icon.search.size} />
                                                                    </div>
                                                                    <input
                                                                        id="filter-text"
                                                                        onChange={this.onFilterTextBoxChanged}
                                                                        class="peer text-search-text bg-white h-full w-full outline-none text-search-text-size placeholder-search-text  pr-2"
                                                                        type="text"
                                                                        placeholder="Search..."
                                                                        autoFocus
                                                                    />
                                                                </div>
                                                                :
                                                                <span className=" p-[2px] mx-1 border-2 border-transparent cursor-pointer rounded hover:border-[#ffffffd2]" onClick={() => { this.setState({ isSearchClicked: true }) }}>
                                                                    <HiOutlineSearch color='white' size={20} />
                                                                </span>

                                                            : null
                                                        }
                                                        <span className=" p-[2px] mx-1 border-2 border-transparent cursor-pointer rounded hover:border-[#ffffffd2]" onClick={(e) => this.addEditGroupOpen(e, item)}>
                                                            <MdOutlineModeEditOutline color='white' size={20} />
                                                        </span>
                                                        <span className="p-[2px] mx-1 border-2 border-transparent cursor-pointer rounded hover:border-[#ffffffd2]" onClick={(e) => this.deleteGroupOpen(e, item, item.group_scenarios.length)}>
                                                            <HiOutlineTrash color={'white'} size={20} />
                                                        </span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div>
                                                {(this.state.groupFlag[index]) ?
                                                    <div >
                                                        <Scenarios
                                                            allScenarioData={this.state.allScenarioData}
                                                            groupScenarioData={this.state.groupScenarioData}
                                                            addScenariosOpen={(e) => this.addScenariosOpen(e, item.lable)}
                                                            group={item.lable}
                                                            modelheader={this.state.modelheader}
                                                            streamData={this.state.streamData}
                                                            filterValue={this.state.filterValue}
                                                        />
                                                    </div>
                                                    : null}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}

                        {this.state.rowData.length == 0 ?
                            < div class=" w-full flex flex-col justify-center items-center">
                                <div><img src={noRecordsImg} height='500' width='200' /></div>
                                <div className="text-gray-600 font-semibold text-md my-2"> No records found! </div>
                            </div> : null
                        }

                        <div className="fixed bottom-6 right-10"  >
                            <button onClick={(e) => this.addEditGroupOpen(e)} class={ControlsConstants.ToolTip.addbutton}>
                                <HiPlus className={ControlsConstants.ToolTip.iconsize} aria-hidden="true" />
                                <div class={ControlsConstants.ToolTip.tooltipGroup}>
                                    <span class={ControlsConstants.ToolTip.tooltiptext}>{localConstant.GROUP.ADD_GROUP}</span>
                                    <div class={ControlsConstants.ToolTip.tooltipArrow}></div>
                                </div>
                            </button>
                        </div>


                        {this.state.addGroupFlag || this.state.editGroupFlag ?
                            <div>
                                <ReactDialogBox
                                    closeBox={(e) => this.backToMainScreen(e)}
                                    modalWidth={'35vw'}
                                    headerBackgroundColor={ControlsConstants.Model.headerbg}
                                    headerTextColor={ControlsConstants.Model.bodybg}
                                    headerHeight={ControlsConstants.Model.headerheight}
                                    closeButtonColor={ControlsConstants.Model.closebtncolor}
                                    bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                    bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                    headerText={this.state.modelheader}
                                >
                                    <div>
                                        <div className="space-y-0 ">
                                            <FormTestGroup
                                                errors={this.state.errors}
                                                records={this.state.records}
                                                onValueOnChange={this.onValueOnChange}
                                                addGroupFlag={this.state.addGroupFlag}
                                                allUsers={this.state.allUsers}
                                                onAddGroupOn_Click={this.onAddGroupOn_Click}
                                                onEditGroupOn_Click={this.onEditGroupOn_Click}
                                                dialogBoxClose={this.backToMainScreen}
                                            />
                                        </div>
                                        {/* <div className="modal-footer flex flex-shrink-0 flex-wrap space-x-3 items-center justify-end mt-2 pb-0 p-4 border-t border-gray-200 rounded-b-md">
                                        {
                                            this.state.addGroupFlag ?
                                                <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={this.onAddGroupOn_Click} >{localConstant.COMMON_CONST.ADD}</button>
                                                :
                                                <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={this.onEditGroupOn_Click} >{localConstant.COMMON_CONST.UPDATE}</button>
                                        }
                                        <button type="button" className={ControlsConstants.Buttons.btnSecondary} data-bs-dismiss="modal" onClick={(e) => this.dialogBoxClose(e)}>{localConstant.COMMON_CONST.CANCEL}</button>
                                    </div> */}
                                    </div>
                                </ReactDialogBox>
                            </div>
                            : null
                        }


                        {this.state.deleteGroupFlag ?
                            <div>
                                <ReactDialogBox
                                    closeBox={this.backToMainScreen}
                                    modalWidth={localControlsConstant.Model.modalWidth}
                                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                                    headerTextColor={localControlsConstant.Model.bodybg}
                                    headerHeight={localControlsConstant.Model.headerheight}
                                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                    //   bodyHeight='150px'
                                    headerText='Delete TestGroup'
                                >
                                    <div>
                                        <div class='flex items-center h-16 pl-7'>
                                            <h1>{localConstant.GROUP.DDELETE_GROUP_CONTENT}<span class='text-delete-user-text'>{this.state.deleteData["lable"]}</span>?</h1>
                                        </div>
                                        <div class="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                                            <button type="button" class={localControlsConstant.Buttons.btnPrimary} onClick={this.deleteGroupOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                                            <button type="button" class={localControlsConstant.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                                        </div>
                                    </div>
                                </ReactDialogBox>
                            </div>
                            : null
                        }

                        {this.state.addScenariosFlag ?
                            <div>
                                <ReactDialogBox
                                    closeBox={(e) => this.backToMainScreen(e)}
                                    modalWidth={'35vw'}
                                    headerBackgroundColor={ControlsConstants.Model.headerbg}
                                    headerTextColor={ControlsConstants.Model.bodybg}
                                    headerHeight={ControlsConstants.Model.headerheight}
                                    closeButtonColor={ControlsConstants.Model.closebtncolor}
                                    bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                    bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                    headerText={this.state.modelheader}
                                >
                                    <div>
                                        <div className="space-y-0 ">
                                            <ManageScenarios
                                                allScenarioData={this.state.allScenarioData}
                                                groupScenarioData={this.state.groupScenarioData}
                                                group={this.state.lable}
                                                streamData={this.state.streamData}
                                                dialogBoxClose={this.backToMainScreen}
                                                ManageScenario_onClick={this.ManageScenario_onClick}
                                            />
                                        </div>
                                    </div>
                                </ReactDialogBox>
                            </div>
                            : null
                        }

                        <ToastContainer />
                    </div>

                </div>
            </AuthCommonLayout >
        );
    }
}

export default TestGroup;