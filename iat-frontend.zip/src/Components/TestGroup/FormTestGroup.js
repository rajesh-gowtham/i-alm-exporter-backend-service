import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ControlsConstants } from '../../Constants/ControlsConstants'
import { getlocalizeData } from '../../CommonUtils/getlocalizeData';
import { HiOutlineSearch } from 'react-icons/hi';
import { MdAdd } from 'react-icons/md';
import _ from 'lodash';
import { AgGridReact } from 'ag-grid-react';

const localConstant = getlocalizeData();

//SCREEN ID -3077
const FormTestGroup = (props) => {
    const { records, errors } = props;
    const borderRed = ControlsConstants.TextBox.textboxRed;
    const borderGrey = ControlsConstants.TextBox.textbox;
    const [assignUsers, setAssignUsers] = useState(false);
    const [selectedUsers, setSelectedUsers] = useState(props.records.UserMapGroupGKey);

    const assignUsersOnClick = (data) => {
        const selectedUserGkeys = data.map(user => user.gkey);
        console.log(" selectedUserGkeys ", selectedUserGkeys);
        setSelectedUsers(selectedUserGkeys);
        setAssignUsers(false);
        props.onValueOnChange(selectedUserGkeys);
    };

    return (
        <div className=' px-4 py-1' >
            <form class="font-[Verdana]">
                {!assignUsers ?
                    <>
                        <div class=" mb-2">
                            <label class={ControlsConstants.label.label14} for="group">{localConstant.GROUP.GROUP}</label>
                            <input
                                type="text"
                                name="lable"
                                id="label"
                                class={errors.lable.length > 0 ? borderRed : borderGrey}
                                placeholder="Enter group name "
                                value={records.lable}
                                onChange={props.onValueOnChange}
                            />
                            {errors.lable.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.lable}</span>
                            }
                        </div>
                        <div class=" mb-2">
                            <label class={ControlsConstants.label.label14} for="description" >{localConstant.GROUP.DESCRIPTION}</label>
                            <textarea
                                type="text"
                                name="description"
                                id="description"
                                onChange={props.onValueOnChange}
                                value={records.description}
                                class={ControlsConstants.TextBox.textarea + 'h-[75px]'}
                                placeholder=" Enter description "
                                required
                            />
                        </div>

                        <div className='flex items-center space-x-5'>
                            <div onClick={() => { setAssignUsers(true) }} className="flex w-1/3 bg-[#26C396] py-2 items-center text-white text-xs rounded-lg pl-3 pr-5 space-x-2 cursor-pointer">
                                <MdAdd size={18} color="#fff" />
                                <div>{props.addGroupFlag ? " Assign Users " : " Manage Users"}</div>
                            </div>
                            <div className='font-semibold text-sm'>
                                {selectedUsers.length} users assigned
                            </div>
                        </div>

                        <div className="modal-footer flex flex-shrink-0 flex-wrap space-x-3 items-center justify-end mt-2 pb-0 p-4 border-t border-gray-200 rounded-b-md">
                            {
                                props.addGroupFlag ?
                                    <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={props.onAddGroupOn_Click} >{localConstant.COMMON_CONST.ADD}</button>
                                    :
                                    <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={props.onEditGroupOn_Click} >{localConstant.COMMON_CONST.UPDATE}</button>
                            }
                            <button type="button" className={ControlsConstants.Buttons.btnSecondary} onClick={props.dialogBoxClose}>{localConstant.COMMON_CONST.CANCEL}</button>
                        </div>
                    </>
                    :
                    <AssignUsers
                        assignUsersOnClick={assignUsersOnClick}
                        setAssignUsers={setAssignUsers}
                        allUsers={props.allUsers}
                        selectedUsers={props.records.UserMapGroupGKey} />
                }
            </form>
        </div>
    )
}
export default FormTestGroup;

const AssignUsers = (props) => {
    let dialogStyles = {
        // width: '500px',
        // maxWidth: '100%',
        margin: '0 auto',
        position: 'fixed',
        left: '50%',
        top: '45%',
        transform: 'translate(-50%,-50%)',
        zIndex: '80',
        backgroundColor: '#fff',
        padding: '10px 0px 15px',
        borderRadius: '8px',
        display: 'flex',
        flexDirection: 'column',
    };
    const [selectedUsers, setUsers] = useState(props.selectedUsers)
    const [rowData, setRowData] = useState(props.allUsers);
    // const [isCheckBox, setIsCheckBox] = useState(false);

    const [gridApi, setGridApi] = useState()
    const gridApiRef = useRef(null); // Reference to the grid API

    const [columnDefs] = useState([
        {
            headerCheckboxSelectionFilteredOnly: true, headerCheckboxSelection: true,
            checkboxSelection: true, width: 80
        },
        {
            field: 'email', headerName: 'Email', suppressMovable: true, flex: 1
        }
    ]);
    // get and store only user Gkeys
    useEffect(() => {
        const userGkeys = props.selectedUsers.map(user => user.user_key == undefined ? user : user.user_key)
        setUsers(userGkeys);
    }, [props.selectedUsers])

    // Sort assigned users at top
    useEffect(() => {
        let assigned = [], unAssigned = [];
        props.allUsers.map(item => {
            const userGkeys = props.selectedUsers.map(user => user.user_key == undefined ? user : user.user_key)
            if (userGkeys.includes(item.gkey)) {
                assigned.push(item)
            }
            else
                unAssigned.push(item)
        })
        setRowData([...assigned, ...unAssigned])
    }, [])

    // function for checkBox indetermine hyphen and multicheckbox
    // useEffect(() => {
    //     const checkbox = document.getElementById("MultiCheck");
    //     checkbox.indeterminate = selectedUsers.length > 0 ? selectedUsers.length == props.allUsers.length ? false : true : false
    // }, [selectedUsers])

    const onRemoveOn_Click = (e, gkey) => {
        e?.preventDefault();
        setUsers((prev) => {
            return [
                ...prev.filter(userGkey => userGkey !== gkey)
            ]
        })
    };

    const onAddOn_Click = (e, gkey) => {
        e?.preventDefault();
        setUsers([...selectedUsers, gkey]);
    };

    const onSingleCheckSelction = (e, gkey) => {
        // e.preventDefault();
        if (e.target.checked)
            onAddOn_Click(undefined, gkey)
        else
            onRemoveOn_Click(undefined, gkey)
    };

    const onMultiCheckSelction = (e) => {
        // e.preventDefault();
        const selectedUsers = props.allUsers.map(user => user.gkey);
        if (e.target.checked)
            setUsers(selectedUsers);
        else
            setUsers([])
    };

    const handleSearch = (event) => {
        const value = event.target.value;
        const filteredDatas = props.allUsers.filter(
            item => item.userName.toLowerCase().includes(value.toLowerCase())
        );
        setRowData(filteredDatas)
    };

    const getInitialLetters = (name) => {
        return name.split(' ').slice(0, 2).map((name) => name[0]).join('')
    };

    const onCancelOnclick = (e) => {
        e.preventDefault();
        props.setAssignUsers(prev => !prev)
    };

    const onGridReady = (params) => {
        setGridApi(params.api)
        gridApiRef.current = params.api;
        const userIds = selectedUsers == undefined ? [] : selectedUsers.map(user => user.gkey == undefined ? user : user.gkey);

        console.log('userIds ', userIds)

        params.api.forEachLeafNode((node) => {
            if (userIds.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    const onFilterTextBoxChanged = useCallback(() => {
        gridApiRef.current.setQuickFilter(
            document.getElementById('filter-text').value
        );
        let showRowCount = gridApiRef.current.getDisplayedRowCount()
        if (showRowCount === 0) {
            gridApiRef.current.showNoRowsOverlay();
            document.querySelector('#noMatchData').innerHTML = 'No matching records found!';
        } else {
            gridApiRef.current.hideOverlay();
        }
    }, []);

    return (
        <div className=" absolute top-0 left-0 z-50  h-[100vh] font-roboto">
            <div id='loginAnimate' className='w-[35vw]' style={dialogStyles}>
                <div className='header'>
                    <div>
                        <div className="text-center text-black text-xl font-semibold pt-4">Assign User</div>
                        <div className="text-black text-center text-opacity-50 text-[16px] font-normal pt-2.5">User existing team members or add new ones.</div>
                        <div className='w-full flex items-center justify-center'>
                            <div class="relative rounded-md border  border-black border-opacity-5 mt-3  w-[85%] flex items-center h-10 bg-white overflow-hidden">
                                <div class="grid place-items-center h-full w-12 text-search-text">
                                    <HiOutlineSearch color='#0000004D' size={24} />
                                </div>
                                <input
                                    id="filter-text-box"
                                    // onInput={props.onFilterTextBoxChanged}
                                    class="peer text-search-text bg-white h-full w-full max-sm:w-[100px] outline-none text-search-text-size placeholder-[#0000004D]  placeholder:text-md placeholder:font-normal pr-2"
                                    type="text"
                                    // value={searchTerm}
                                    onChange={handleSearch}
                                    placeholder="Search..." />
                            </div>
                        </div>

                    </div>
                    <div className="overflow-y-scroll overflow-x-clip px-2  z-0  ">
                        <div className='bg-white rounded'>
                            <div className="ag-theme-alpine h-[40vh] p-4 rounded" id="secondaryGridBorder"  >
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    domLayout='normal'
                                    cacheQuickFilter={true}
                                    animateRows={true}
                                    groupDisplayType={'multipleColumns'}
                                    rowSelection={"multiple"}
                                    headerHeight={35}
                                    rowHeight={35}
                                    suppressRowClickSelection={true}
                                    suppressRowHoverHighlight={true}
                                    pagination={false}
                                    onGridReady={onGridReady}
                                    overlayNoRowsTemplate={'<span id="noMatchData" class="ag-overlay-loading-center "> No Records Found ! </span>'}
                                    overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex justify-center space-x-7 py-4">
                    <button class='px-10 bg-blue-800 hover:bg-blue-700 hover:bo rounded-md shadow border border-blue-800 text-white text-base font-medium' onClick={() => { props.assignUsersOnClick(gridApiRef.current.getSelectedRows()) }}> Save  </button>
                    <button class='py-2 px-8 shadow border  hover:bg-[#e6e3e35d] border-gray-300 rounded-md text-zinc-500 text-base font-medium ' onClick={(e) => { onCancelOnclick(e) }}> Cancel </button>
                </div>
            </div>
        </div>
    )
};

