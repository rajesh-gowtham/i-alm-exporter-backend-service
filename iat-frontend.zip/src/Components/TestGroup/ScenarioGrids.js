import React, { useState, useRef, useCallback, useMemo, useEffect } from 'react';
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { AgGridReact } from "ag-grid-react";
import { HiOutlineSearch } from "react-icons/hi";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { getlocalizeData } from '../../CommonUtils/getlocalizeData';
import { GridConstants } from '../../Constants/GridConstants';

const localConstant = getlocalizeData();
const gridLocalConstants = GridConstants.AGGrid.Secondary_Grid;

export function Scenarios(props) {
    const gridRef = useRef(); // Reference to the grid API
    const [rowData, setRowData] = useState();
    const [gridApi, setGridApi] = useState();
    const [columnDefs] = useState([
        // {
        //     headerName: "ID", field: "id", suppressMovable: true, width: 150,
        //     cellRenderer: (params) => {
        //         const id = `300${params.rowIndex + 1}`.slice(-4);
        //         return "SC" + id
        //     },
        // },
        { field: 'displayName', flex: 2, suppressMovable: true, headerName: 'Display Name', },
        { field: 'longName', flex: 2, suppressMovable: true, headerName: 'Long Name', },
        { field: 'Stream_Value', flex: 2, suppressMovable: true, headerName: 'Stream_Value', },
        // {
        //     headerName: "Stream", field: "Stream_gkey", flex: 1,
        //     cellRenderer: (params) => {
        //         const result = props.streamData.find(({ value }) => value === params.value);
        //         return result.label
        //     }
        // },

    ]);

    useEffect(() => {
        let tempRowData = [];
        props.groupScenarioData.map(item => (
            props.allScenarioData.map(scenarios => {
                if (scenarios.gkey == item.scenario_key) {
                    const result = props.streamData.find(({ value }) => value === scenarios.Stream_gkey);
                    scenarios["Stream_Value"] = result.label;
                    tempRowData.push(scenarios);
                }
            })));
        setRowData(tempRowData);
    }, [props.groupScenarioData])


    useEffect(() => {
        if (props.filterValue !== undefined) {
            streamData()
        }
    }, [props.filterValue])

    const streamData = useCallback(async () => {
        console.log(" stream ", props.filterValue);
        try {
            gridRef.current.api.setQuickFilter(
                props.filterValue
            );

            let showRowCount = gridApi.getDisplayedRowCount()

            console.log(" count ", showRowCount);

            if (showRowCount === 0) {
                gridApi.showNoRowsOverlay();
                document.querySelector('#noMatchData').innerHTML = 'No matching records found!';
            } else {
                gridApi.hideOverlay();
            }
        } catch (error) {
            console.error(error)
        }
    })

    const onGridReady = (params) => {
        setGridApi(params.api);
    };

    return (
        <div className='p-2 bg-[#f6fcfd]  rounded   ' >
            <div className='bg-[#f6fcfd] rounded'>
                <div className="ag-theme-alpine h-[40vh] p-4 rounded" id="secondaryGrid"  >
                    <AgGridReact
                        ref={gridRef}
                        rowData={rowData}
                        columnDefs={columnDefs}
                        cacheQuickFilter={true}
                        animateRows={true}
                         defaultColDef={gridLocalConstants.defaultColDef}
                        headerHeight={35}
                        rowHeight={35}
                        pagination={false}
                        rowSelection={'multiple'}
                        gridOptions={gridLocalConstants.gridOptions}
                        suppressRowClickSelection={true}
                        suppressRowHoverHighlight={true}
                        onGridReady={onGridReady}
                        overlayNoRowsTemplate={'<span id="noMatchData" class="ag-overlay-loading-center "> No Records Found ! </span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className="flex  justify-end mt-2 px-4">
                <button className={ControlsConstants.Buttons.btnPrimary + ' h-8  mr-2 '} onClick={(e) => props.addScenariosOpen(e, props.group)} > {localConstant.GROUP.SCENARIOS} </button>
            </div>
        </div>
    );
};

export function ManageScenarios(props) {
    const [gridApi, setGridApi] = useState()
    const gridApiRef = useRef(null); // Reference to the grid API
    const gridRef = useRef(); // Reference to the grid API      // Optional - for accessing Grid's API

    const rowData = props.allScenarioData;
    const groupScenarioData = props.groupScenarioData;
    const [columnDefs] = useState([
        {
            field: 'displayName', headerName: 'Scenario Name', suppressMovable: true, flex: 3, headerCheckboxSelectionFilteredOnly: true, headerCheckboxSelection: true,
            checkboxSelection: true,
        },
        {
            headerName: "Stream", field: "Stream_gkey", suppressMovable: true, flex: 2,
            cellRenderer: (params) => {
                let result = props.streamData.find(({ value }) => value === params.value);
                return result.label
            }
        },
    ]);

    const onFilterTextBoxChanged = useCallback(() => {
        gridApiRef.current.setQuickFilter(
            document.getElementById('filter-text').value
        );
        let showRowCount = gridApiRef.current.getDisplayedRowCount()
        if (showRowCount === 0) {
            gridApiRef.current.showNoRowsOverlay();
            document.querySelector('#noMatchData').innerHTML = 'No matching records found!';
        } else {
            gridApiRef.current.hideOverlay();
        }
    }, []);

    const onGridReady = (params) => {
        setGridApi(params.api)
        gridApiRef.current = params.api;
        const scenarioId = groupScenarioData == undefined ? [] : groupScenarioData.map(item => item.scenario_key);
        console.log('scenarioId', scenarioId)
        params.api.forEachLeafNode((node) => {
            if (scenarioId.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    return (
        <div class="p-4  bg-[#ebeef6]" >
            <div id="Sequences-search" className='flex justify-end'>
                <div class="relative max-w-[200px] flex items-center  h-8 rounded-lg  bg-white overflow-hidden mb-3 ">
                    <div class="grid place-items-center h-full w-12 text-search-text">
                        <HiOutlineSearch size={ControlsConstants.Icon.search.size} />
                    </div>
                    <input
                        id="filter-text"
                        onInput={onFilterTextBoxChanged}
                        class="peer text-search-text bg-white h-full w-full outline-none text-search-text-size placeholder-search-text  pr-2"
                        type="text"
                        autoFocus
                        placeholder="Search..."
                    />
                </div>
            </div>
            <div className='bg-white rounded'>
                <div className="ag-theme-alpine h-[45vh] p-4 rounded" id="secondaryGridBorder"  >
                    <AgGridReact
                        rowData={rowData}
                        ref={gridRef}
                        columnDefs={columnDefs}
                        domLayout='normal'
                        cacheQuickFilter={true}
                        animateRows={true}
                        defaultColDef={gridLocalConstants.defaultColDef}
                        groupDisplayType={'multipleColumns'}
                        rowSelection={"multiple"}
                        headerHeight={35}
                        rowHeight={35}
                        gridOptions={gridLocalConstants.gridOptions}
                        suppressRowClickSelection={true}
                        suppressRowHoverHighlight={true}
                        pagination={false}
                        onGridReady={onGridReady}
                        overlayNoRowsTemplate={'<span id="noMatchData" class="ag-overlay-loading-center "> No Records Found ! </span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center  justify-center mt-5  rounded-b-md space-x-3">
                <button type="button" onClick={(e) => { props.ManageScenario_onClick(e, gridApi) }} className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                <button type="button" onClick={props.dialogBoxClose} className={ControlsConstants.Buttons.btnSecondary} >CANCEL</button>
            </div>
        </div>
    );
}






