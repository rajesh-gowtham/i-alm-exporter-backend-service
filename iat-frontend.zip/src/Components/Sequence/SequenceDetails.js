import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { HiPlus } from 'react-icons/hi';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import 'react-toastify/dist/ReactToastify.css';
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import { HiOutlineExclamationCircle } from 'react-icons/hi';
import { FaClone, FaRegClone } from 'react-icons/fa';
import FormSequence from './FormSequence';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { connect } from 'react-redux';
import ReferenceService from '../../Services/ReferenceService';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';
import SequenceService from '../../Services/SequenceService';
import _ from 'lodash';
import { IoCopyOutline } from 'react-icons/io5'

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();
//SCREEN ID -3007`
class SequenceDetails extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      SequenceformFlag: true,
      addSequenceFlag: false,
      editSequenceFlag: false,
      deleteSequenceFlag: false,
      cloneSequenceFlag: false,
      deleteData: {},
      cloneData: {},
      records: {},
      errors: {},
      modelheader: '',
      groupSelect: [],
      navPath: ['Sequence'],
      columnDefs: [
        {
          headerName: "Label", field: "lable", flex: 2
        },
        { headerName: "Description", field: "description", flex: 2 },
        {
          field: 'Parameterizable', flex: 2,
          singleClickEdit: true,
          editable: (params) => params.data.Parameterizable !== 'false' & params.data.Parameterizable !== false,
          cellRenderer: (params) => {
            if (params.value) {
              return <span>{params.value === 'false' || params.value === false ? "" : params.value} </span>
            }
            else {
              return <div className='flex items-center h-full space-x-2'><span className='text-xs text-red-400'>Please Enter Value </span><HiOutlineExclamationCircle size={20} color='#f87171' /></div>
            }
          }
        },
        {
          headerName: "Apply To", field: "Apply_To", flex: 2,
          cellRenderer: (params) => {
            let result = this.state.groupSelect.filter(option =>
              option.value === params.data.Apply_To)
            if (result.length != 0) {
              return result.at(0).label
            }
          }
        },
        {
          headerName: "Action", flex: 1, minWidth: 160,
          cellRendererFramework: (params) =>

            <div class='flex w-full h-full items-center space-x-4'>
              <button onClick={() => this.cloneSequenceOpen(params)} >
                {/* < FaRegClone size={20} color='#EC842A' /> */}
                {/* <svg fill="#EC842A" height="20px" width="20px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xmlSpace="preserve">
                  <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                  <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                  <g id="SVGRepo_iconCarrier">
                    <g id="Text-files">
                      <path d="M53.9791489,9.1429005H50.010849c-0.0826988,0-0.1562004,0.0283995-0.2331009,0.0469999V5.0228 C49.7777481,2.253,47.4731483,0,44.6398468,0h-34.422596C7.3839517,0,5.0793519,2.253,5.0793519,5.0228v46.8432999 c0,2.7697983,2.3045998,5.0228004,5.1378999,5.0228004h6.0367002v2.2678986C16.253952,61.8274002,18.4702511,64,21.1954517,64 h32.783699c2.7252007,0,4.9414978-2.1725998,4.9414978-4.8432007V13.9861002 C58.9206467,11.3155003,56.7043495,9.1429005,53.9791489,9.1429005z M7.1110516,51.8661003V5.0228 c0-1.6487999,1.3938999-2.9909999,3.1062002-2.9909999h34.422596c1.7123032,0,3.1062012,1.3422,3.1062012,2.9909999v46.8432999 c0,1.6487999-1.393898,2.9911003-3.1062012,2.9911003h-34.422596C8.5049515,54.8572006,7.1110516,53.5149002,7.1110516,51.8661003z M56.8888474,59.1567993c0,1.550602-1.3055,2.8115005-2.9096985,2.8115005h-32.783699 c-1.6042004,0-2.9097996-1.2608986-2.9097996-2.8115005v-2.2678986h26.3541946 c2.8333015,0,5.1379013-2.2530022,5.1379013-5.0228004V11.1275997c0.0769005,0.0186005,0.1504021,0.0469999,0.2331009,0.0469999 h3.9682999c1.6041985,0,2.9096985,1.2609005,2.9096985,2.8115005V59.1567993z"></path> <path d="M38.6031494,13.2063999H16.253952c-0.5615005,0-1.0159006,0.4542999-1.0159006,1.0158005 c0,0.5615997,0.4544001,1.0158997,1.0159006,1.0158997h22.3491974c0.5615005,0,1.0158997-0.4542999,1.0158997-1.0158997 C39.6190491,13.6606998,39.16465,13.2063999,38.6031494,13.2063999z"></path> <path d="M38.6031494,21.3334007H16.253952c-0.5615005,0-1.0159006,0.4542999-1.0159006,1.0157986 c0,0.5615005,0.4544001,1.0159016,1.0159006,1.0159016h22.3491974c0.5615005,0,1.0158997-0.454401,1.0158997-1.0159016 C39.6190491,21.7877007,39.16465,21.3334007,38.6031494,21.3334007z"></path>
                      <path d="M38.6031494,29.4603004H16.253952c-0.5615005,0-1.0159006,0.4543991-1.0159006,1.0158997 s0.4544001,1.0158997,1.0159006,1.0158997h22.3491974c0.5615005,0,1.0158997-0.4543991,1.0158997-1.0158997 S39.16465,29.4603004,38.6031494,29.4603004z"></path>
                      <path d="M28.4444485,37.5872993H16.253952c-0.5615005,0-1.0159006,0.4543991-1.0159006,1.0158997 s0.4544001,1.0158997,1.0159006,1.0158997h12.1904964c0.5615025,0,1.0158005-0.4543991,1.0158005-1.0158997 S29.0059509,37.5872993,28.4444485,37.5872993z"></path>
                    </g>
                  </g>
                </svg> */}
                <IoCopyOutline size={20} color='#EC842A' />

              </button>
              <button onClick={(e) => this.addEditSequenceOpen(e, params)}>
                <EditLogo />
              </button>
              <button onClick={() => this.deleteSequenceOpen(params)} >
                <TrashLogo />
              </button>
            </div>
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: [],
    };
    this.gridRef = React.createRef();
  };

  componentDidMount() {
    this.getSequencesByOrg();
    this.LoadGroupField();
  };

  getSequencesByOrg() {
    SequenceService.GetSequenceByOrg().
      then(
        response => {
          const updatedData = response.data.map(item => {
            const { aut_app_gkey, ...rest } = item;
            return { Apply_To: aut_app_gkey, ...rest };
          });
          console.log(" 1", updatedData)
          this.setState({
            rowData: updatedData
          })
          console.log('getSequencesByOrg', response)
        }

      );

    this.LoadGroupField();
  };

  LoadGroupField = () => {
    ReferenceService.getReferenceByOrg().
      then(
        response => {
          const options = response.data.map((datas, index) => (
            {
              "value": datas.gkey,
              "label": datas["Value"]
            }))
          this.setState({
            groupSelect: options
          })
          console.log('ref Options', options)
        }
      );
  };

  addEditSequenceOpen = (e, item) => {
    if (item == undefined || item == null) {
      this.setState({
        addSequenceFlag: true,
        SequenceformFlag: false,
        editSequenceFlag: false,
        modelheader: 'Add Sequence',
        records: { lable: '', Apply_To: '', description: '', Parameterizable: false },
        navPath: ['Sequence', 'Add Sequence'],
      })
    }
    else {
      this.setState({
        editSequenceFlag: true,
        SequenceformFlag: false,
        addSequenceFlag: false,
        modelheader: 'Edit Sequence',
        records: item.data,
        navPath: ['Sequence', 'Edit Sequence'],
      })
    }
    this.setState({
      errors: {
        lable: '',
        Apply_To: '',
        Parameterizable: '',
      }
    })
  };

  onValueOnChange = (e, obj) => {
    if (e == null)
      return;
    let name, value;
    let errors = this.state.errors;
    if (e.target == undefined) {
      name = obj.name;
      value = e.value;
      errors[name] = "";
    } else if (e.target.type == "checkbox") {
      name = "Parameterizable";
      // value = e.target.checked ? obj : '';
      value = e.target.checked;
    } else {
      name = e.target.name;
      value = e.target.value;
    }
    this.setState(prevState => ({
      records: {
        ...prevState.records,
        [name]: value,
      }
    }))

    switch (name) {
      case 'lable':
        errors.lable =
          value.length < 1
            ? "Label can't be empty ! "
            : '';
        break;
      case 'Apply_To':
        errors.Apply_To =
          value.length < 1
            ? "Group name can't be empty ! "
            : '';
        break;
      case 'Parameterizable':
        if (value !== false) {
          errors.Parameterizable =
            value.length < 1
              ? "Parameterizable can't be empty ! "
              : '';
          break;
        } else {
          errors.Parameterizable = ''
        }
      default:
        break;
    }
  };

  addSequenceOn_Click = (event) => {
    event.preventDefault();
    let records = this.state.records;
    const isValid = this.validateAllfields(records);
    if (isValid) {
      records["MasterBizUitKey"] = localStorage.getItem("MasterBizUitKey")
      records["Parameterizable"] = records.Parameterizable + "";
      console.log(isValid, ' valid records', records);
      event.currentTarget.disabled = true;
      SequenceService.CreateSequenceByOrg(records).
        then(
          response => {
            if (response.status === 201 || response.status === 200) {
              toast.success("Sequence Added Successfully!");
              this.getSequencesByOrg();
              this.backToMainScreen();
            }
          }
        );
    } else {
      console.log(records, "In valid")
    }
  };

  editSequenceOn_Click = (e) => {
    e.preventDefault();
    const records = this.state.records;
    const isValid = this.validateAllfields(records);
    console.log(isValid, ' valid records', records);
    if (isValid) {
      console.log(isValid, ' valid records', records);
      records["Parameterizable"] = records.Parameterizable + "";
      e.currentTarget.disabled = true;
      SequenceService.UpdateSequenceByOrg(records).
        then(
          response => {
            if (response.status == 200 || response.status == 201) {

              toast.success("Sequence Updated Successfully")
              this.getSequencesByOrg();
              this.backToMainScreen();
              this.onGridReady();
            } else {
              toast.error("Sequence Updated Failed")
            }
          }
        );
    }
    else {
      console.log("In valid Data ", records)
    }
  };

  validateAllfields(records) {
    if (records.lable == undefined || records.lable == "" || this.state.errors.lable != "") {
      let err = records.lable == undefined || records.lable == "" ? ' Please enter SequenceName  ' : this.state.errors.lable;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          lable: err
        },
      }));
      return false;
    }
    if (records.Apply_To == undefined || records.Apply_To == "" || this.state.errors.Apply_To != "") {
      let err = records.Apply_To == undefined || records.Apply_To == "" ? ' Please Select Group name  ' : this.state.errors.Apply_To;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          Apply_To: err
        },
      }));
      return false;
    }
    if (records.Parameterizable !== false) {
      if (records.Parameterizable == undefined || records.Parameterizable == "" || records.Parameterizable == true || this.state.errors.Parameterizable != "") {
        let err = records.Parameterizable == undefined || records.Parameterizable == true || records.Parameterizable == "" ? ' Please enter parameterizable value  ' : this.state.errors.Parameterizable;
        this.setState(prevState => ({
          errors: {
            ...prevState.errors,
            Parameterizable: err
          },
        }));
        return false;
      }
    }
    return true;
  };

  resetOn_Click = (e) => {
    e.preventDefault();
    this.setState(prevState => ({
      records: {
        ...prevState.records,
        lable: '',
        Apply_To: '',
        description: '',
        Parameterizable: false
      },
      errors: {
        lable: '',
        Apply_To: '',
        Parameterizable: '',
      },
    }))
  };

  deleteSequenceOpen = (params) => {
    this.setState({
      deleteSequenceFlag: true,
      deleteData: params.data
    })
  };

  deleteSequenceOn_Click = () => {
    SequenceService.DeleteSequenceByOrg(this.state.deleteData["gkey"]).
      then(
        response => {
          if (response.status === 200 || response.status === 201) {
            toast.success("Sequences Deleted Successfully!");
            this.getSequencesByOrg();
            this.setState({
              deleteSequenceFlag: false
            })
          }
        }
      );
  };

  cloneSequenceOpen = (params) => {
    this.setState({
      cloneSequenceFlag: true,
      cloneData: params.data
    })
  };

  cloneSequence_Onclick = () => {
    let DataArray = this.state.rowData;
    let cloneData = this.state.cloneData;
    let cloneLabel = cloneData.lable + ' (1)';
    let count = 1;
    while (DataArray.some((item) => item.lable === cloneLabel)) {
      cloneLabel = cloneData.lable + ` (${count})`;
      count++;
    }

    const clonedData = {
      lable: cloneLabel,
      Apply_To: cloneData.Apply_To,
      description: cloneData.description,
      Parameterizable: cloneData.Parameterizable + '',
      MasterBizUitKey: localStorage.getItem("MasterBizUitKey"),
    };

    SequenceService.CreateSequenceByOrg(clonedData).
      then(
        response => {
          if (response.status === 201 || response.status === 200) {
            toast.success("Sequence Cloned Successfully!");
            this.getSequencesByOrg();
            this.backToMainScreen();
          }
        }
      );
  };

  backToMainScreen = (e) => {
    this.setState({
      SequenceformFlag: true,
      editSequenceFlag: false,
      addSequenceFlag: false,
      deleteSequenceFlag: false,
      cloneSequenceFlag: false,
      navPath: ['Sequence'],
    })
  };

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })
  };

  onCellValueChanged = (params) => {
    let changedData = params.data;
    if (params.value !== "")
      console.log("changedData  ", changedData)
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  render() {
    return (
      <AuthCommonLayout>
        <div>
          <div id='screenHeader'>
            <ComponentHeader
              isSearchable={this.state.SequenceformFlag}
              path={this.state.navPath}
              backToParentClass={this.backToMainScreen}
              onFilterTextBoxChanged={this.onFilterTextBoxChanged}
            />
          </div>

          <div id='screenBody'>

            {this.state.SequenceformFlag ?
              <div id="AGGrid">
                <div id='CustomAgGrid'>
                  <CustomAgGrid
                    rowData={this.state.rowData}
                    columnDefs={this.state.columnDefs}
                    onGridReady={this.onGridReady}
                    filterValue={this.state.filterValue}
                    onCellValueChanged={this.onCellValueChanged}
                  />
                </div>
                <div className="fixed bottom-6 right-10"  >
                  <button onClick={this.addEditSequenceOpen} class={localControlsConstant.ToolTip.addbutton}>
                    <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
                    <div class={localControlsConstant.ToolTip.tooltipGroup}>
                      <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.SEQUENCES.ADD_SEQUENCE}</span>
                      <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
                    </div>
                  </button>
                </div>
              </div>
              :
              <div id="SequenceForm" className='w-[100%] flex flex-col'>
                {this.state.addSequenceFlag || this.state.editSequenceFlag ?
                  <div className='w-[60%]  mt-5'>
                    <FormSequence
                      onValueOnChange={this.onValueOnChange}
                      records={this.state.records}
                      errors={this.state.errors}
                      Header={this.state.modelheader}
                      groupSelect={this.state.groupSelect}
                      addSequenceFlag={this.state.addSequenceFlag}
                      addSequenceOn_Click={this.addSequenceOn_Click}
                      editSequenceOn_Click={this.editSequenceOn_Click}
                      resetOn_Click={this.resetOn_Click}
                    />
                    {/* <div className="  modal-footer space-x-3 flex flex-shrink-0 flex-wrap items-center justify-end mt-2 pb-0 p-4 border-t border-gray-200 rounded-b-md">
                      {
                        this.state.addSequenceFlag ?
                          <button type="button" className={localControlsConstant.Buttons.btnPrimary} onClick={this.addSequenceOn_Click} >{localConstant.COMMON_CONST.ADD}</button>
                          :
                          <button type="button" className={localControlsConstant.Buttons.btnPrimary} onClick={this.editSequenceOn_Click} >{localConstant.COMMON_CONST.UPDATE}</button>
                      }
                      <button type="button" className={ControlsConstants.Buttons.btnSecondary} onClick={(e) => this.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                    </div> */}
                  </div>
                  : null
                }
              </div>
            }

            {this.state.deleteSequenceFlag ?
              <div>
                <ReactDialogBox
                  closeBox={this.backToMainScreen}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  //   bodyHeight='150px'
                  headerText='Delete Sequence'
                >
                  <div>
                    <div class='flex items-center h-16 pl-7'>
                      <h1>{localConstant.SEQUENCES.DELETE_SEQUENCES_CONTENT} <span class='text-delete-user-text'> {this.state.deleteData["lable"]}</span>?</h1>
                    </div>
                    <div class="modal-footer space-x-3 flex flex-shrink-0 flex-wrap items-center justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary} onClick={this.deleteSequenceOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
              : null
            }

            {this.state.cloneSequenceFlag ?
              <div>
                <ReactDialogBox
                  closeBox={this.backToMainScreen}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  //   bodyHeight='150px'
                  headerText='Clone Sequence'
                >
                  <div>
                    <div class='flex items-center h-16 pl-7'>
                      <h1>{localConstant.SEQUENCES.CLONE_SEQUENCE_CONTENT} <span class='text-delete-user-text'>{this.state.cloneData["lable"]}</span>?</h1>
                    </div>
                    <div class="modal-footer space-x-3 flex flex-shrink-0 flex-wrap items-center justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary} onClick={() => this.cloneSequence_Onclick()}>{localConstant.COMMON_CONST.YES}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
              : null
            }
            <ToastContainer limit={2} autoClose={2000} />
          </div>
        </div >
      </AuthCommonLayout>
    )
  }
}



export default SequenceDetails;
