import React from "react";
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
//SCREEN ID -3005

const FormSequence = (props) => {
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const { records, errors } = props;
    console.log(" props ", props)
    return (
        <div>
            <div class=" gap-3 mt-2">
                <form class="font-[Verdana]">
                    <div class="flex items-center mb-5">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="lable" class={localControlsConstant.label.label14}>{localConstant.SEQUENCES.LABEL}</label>
                        </span>
                        <span class='flex-[2]'>
                            <input
                                class={errors.lable.length > 0 ? borderRed : borderGrey}
                                type="text"
                                placeholder="Enter Sequence name"
                                name="lable"
                                value={records.lable}
                                onChange={props.onValueOnChange}
                            />
                            {errors.lable.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.lable}</span>
                            }
                        </span>
                    </div>
                    <div class="flex items-center mb-5">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="Apply_To" class={localControlsConstant.label.label14}>{localConstant.SEQUENCES.APPLIE_TO}</label>
                        </span>
                        <span class='flex-[2]'>
                            <Select
                                name="Apply_To"
                                onChange={props.onValueOnChange}
                                options={props.groupSelect}
                                value={
                                    props.groupSelect.filter(option =>
                                        option.value === props.records.Apply_To)
                                }
                                styles={errors.Apply_To.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                            />
                            {errors.Apply_To.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.Apply_To}</span>
                            }
                        </span>
                    </div>
                    <div class="flex items-center mb-5">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="description" class={localControlsConstant.label.label14}>{localConstant.SEQUENCES.DESCRIPTION}</label>
                        </span>
                        <span class='flex-[2]'>
                            <textarea
                                class={ControlsConstants.TextBox.textarea + 'h-[75px]'}
                                type="text"
                                placeholder="Enter Description"
                                name="description"
                                value={records.description}
                                onChange={props.onValueOnChange}
                            />
                        </span>
                    </div>
                    <div class="flex items-center mb-5">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="Parameterizable" class={localControlsConstant.label.label14}>{localConstant.SEQUENCES.PARAMETERIZABLE}</label>
                        </span>
                        <span class='flex-[2] flex flex-col items-stretch'>
                            <div className="flex">
                                <div class="inline-flex items-center">
                                    <label
                                        class="relative flex cursor-pointer items-center rounded-full ml-1 mr-4"
                                        for="Parameterizable"
                                        data-ripple-dark="true"
                                    >
                                        <input
                                            type="checkbox"
                                            class="before:content[''] peer relative h-7 w-7 my-1 cursor-pointer appearance-none rounded-md border-2 border-[#cecef8] transition-all before:absolute before:top-2/4 before:left-2/4 before:block before:h-12 before:w-12 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-blue-gray-500 before:opacity-0 before:transition-opacity  checked:border-[#cecef8] checked:bg-blue-500 checked:before:bg-blue-500 hover:before:opacity-10"
                                            id="Parameterizable"
                                            name="Parameterizable"
                                            onChange={props.onValueOnChange}
                                            checked={records.Parameterizable !== false & records.Parameterizable !== "false"}
                                        />
                                        <div class="pointer-events-none absolute top-2/4 left-2/4 -translate-y-2/4 -translate-x-2/4 text-white opacity-0 transition-opacity peer-checked:opacity-100">
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                class="h-5 w-5"
                                                viewBox="0 0 20 20"
                                                fill="currentColor"
                                                stroke="currentColor"
                                                stroke-width="1"
                                            >
                                                <path
                                                    fill-rule="evenodd"
                                                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                                    clip-rule="evenodd"
                                                ></path>
                                            </svg>
                                        </div>
                                    </label>

                                </div>
                                {records.Parameterizable === false || records.Parameterizable === "false" ? null :
                                    <span class='flex-[2]'>
                                        <input
                                            class={errors.Parameterizable.length > 0 ? borderRed : borderGrey}
                                            type="text"
                                            placeholder="Enter Parameter value"
                                            name="Parameterizable"
                                            value={records.Parameterizable === true ? "" : records.Parameterizable}
                                            onChange={props.onValueOnChange}
                                        />

                                    </span>
                                }
                            </div>
                            <div className="self-center">
                                {errors.Parameterizable.length > 0 &&
                                    <span class='text-error-red text-[11px]'>{errors.Parameterizable}</span>
                                }
                            </div>
                        </span>
                    </div>

                    <div class="flex items-center  mt-[35px]">
                        <span class='flex-1 text-right mr-[30px]'>
                        </span>
                        <span class='flex-[2]'>
                            <div className=" flex-[2] modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pb-0  rounded-b-md space-x-3">
                                    {props.addSequenceFlag ?
                                            <button type="button" className={localControlsConstant.Buttons.btnPrimary} onClick={props.addSequenceOn_Click} >{localConstant.COMMON_CONST.ADD}</button>
                                            :
                                            <button type="button" className={localControlsConstant.Buttons.btnPrimary} onClick={props.editSequenceOn_Click} >{localConstant.COMMON_CONST.UPDATE}</button>
                                    }
                                    <button type="button" className={ControlsConstants.Buttons.btnSecondary} onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                            </div>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default FormSequence;

