import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3070
const AddStream = (props) => {
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    console.log('AddStream', props.errors.name.length)
    return (
        <div className="mt-3 ">
            {/* RESPONSIVE START */}
            <form class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg">
                <div class="grow-1 d-inline-block position-relative mb-3">
                    <label class={localControlsConstant.label.label14} for="inline-full-name">
                        {localConstant.STREAMS.HEADER}
                    </label>
                    <input
                        // class={props.newStreamData == undefined ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}       
                        class={props.errors.name.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                        type="text"
                        placeholder="Enter Stream Name"
                        name="name"
                        value={props.newStreamData == undefined ? "" : props.newStreamData.name}
                        onChange={props.addStreamOnChange}
                    />
                    {props.errors.name.length > 0 &&
                        <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.name}</span>
                    }
                </div>
                <div class="grow-1 d-inline-block position-relative mb-3">
                    <label class={localControlsConstant.label.label14} for="inline-full-name">
                        {localConstant.STREAMS.DESCRIPTION}
                    </label>
                    <textarea
                        class={localControlsConstant.Responsive.textboxResponsive.textarea}
                        type="textarea"
                        placeholder="Enter Description"
                        onChange={props.addStreamOnChange}
                        name="description"
                        value={props.newStreamData == undefined ? "" : props.newStreamData.description}
                    />
                </div>
                <div class='flex items-center space-x-3 py-2 max-lg:justify-center justify-end border-t border-footer-border rounded-b-md'>
                    <button class={localControlsConstant.Buttons.btnPrimary} type="button"
                        onClick={(e) => props.addStreamOn_Click(e)}>{localConstant.COMMON_CONST.ADD}</button>
                    <button class={localControlsConstant.Buttons.btnSecondary} type="button"
                        onClick={(e) => props.reset_onClick(e)}>{localConstant.COMMON_CONST.RESET}</button>
                </div>
            </form>
            {/* RESPONSIVE END */}
        </div>
    )
}
export default AddStream;
