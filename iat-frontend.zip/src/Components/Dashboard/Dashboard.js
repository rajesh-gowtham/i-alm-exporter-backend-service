import React from "react";
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { getlocalizeGridData } from "../../CommonUtils/getlocalizeData";
import { connect } from 'react-redux';
import DashBoardDetails from "./DashBoardDetails";
import ResponsiveDash from "./ResponsiveDash";
const localConstantAGGrid = getlocalizeGridData();
//SCREEN ID -3025
class Dashboard extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            UserRole: window.localStorage.getItem("RoleName"),
        }
    }
    componentDidMount() {
        //  alert(window.localStorage.getItem("RoleName"))
    }
    render() {
        return (
            <AuthCommonLayout>
                <DashBoardDetails />
            </AuthCommonLayout>
        );
    };
};
export default connect()(Dashboard);
