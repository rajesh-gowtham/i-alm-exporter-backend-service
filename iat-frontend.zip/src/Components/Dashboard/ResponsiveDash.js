import React from "react";
import { GoDatabase, GoDotFill } from "react-icons/go";
import { TbRefresh } from "react-icons/tb";
import { getlocalizeGridData } from "../../CommonUtils/getlocalizeData";
import { AgGridReact } from "ag-grid-react";
import ReactApexChart from "react-apexcharts";
import GaugeChart from "react-gauge-chart";
import { connect } from 'react-redux';
import '../../CSS/Dashboard.css';
const localConstantAGGrid = getlocalizeGridData();
//SCREEN ID -3025
class ResponsiveDash extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            UserRole: window.localStorage.getItem("RoleName"),
        }
    }
    render() {
        const UserChart = {
            options: {
                legend: {
                    show: false
                },
                plotOptions: {
                    bar: {
                        distributed: true
                    }
                },
                chart: {
                    id: 'column-chart'
                },
                toolbar: {
                    show: false
                },
                xaxis: {
                    categories: ['Acive', 'In Active', 'Created']
                },
                colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0']
            },
            series: [
                {
                    name: '',
                    data: [6, 3, 2]
                }
            ]
        };
        const ScenarioChart = {
            Series: [3, 2, 2],
            Options: {
                dataLabels: {
                    enabled: false
                },
                labels: ["WS ", "LS", "HK"],
                chart: { type: 'donut', },
                responsive: [{
                    breakpoint: 480,
                    options: {
                        chart: { width: 200 },
                        legend: { position: 'bottom' }
                    }
                }],
                plotOptions: {
                    pie: {
                        //   size: '100%' 
                        expandOnClick: false,

                        donut: {
                            size: '65%',
                            background: 'transparent',
                            labels: {
                                show: true,
                                name: {
                                    show: false,
                                    fontSize: '22px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 600,
                                    color: "black",
                                    offsetY: -10,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                value: {
                                    show: false,
                                    fontSize: '16px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 400,
                                    color: "black",
                                    offsetY: 16,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                total: {
                                    show: false,
                                    showAlways: false,
                                    label: 'Totalss',
                                    fontSize: '16px',
                                    fontFamily: 'Roboto, sans-serif',
                                    fontWeight: 600,
                                    color: '#373d3f',
                                    formatter: function (w) {
                                        return w.globals.seriesTotals.reduce((a, b) => {
                                            return a + b
                                        }, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
        const GroupChart = {
            options: {
                legend: {
                    show: false
                },
                plotOptions: {
                    bar: {
                        distributed: true
                    }
                },
                chart: {
                    id: 'column-chart'
                },
                toolbar: {
                    show: false
                },
                xaxis: {
                    categories: ['Regression', 'Sanity']
                },
                colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0']
            },
            series: [
                {
                    name: '',
                    data: [5, 2]
                }
            ]
        };

        const { UserRole } = this.state;

        return (
         <div>
            <div class="bg-gray-900 min-h-screen flex items-center justify-center">
  <div class="bg-gray-800 flex-1 flex flex-col space-y-5 lg:space-y-0 lg:flex-row lg:space-x-10 max-w-6xl sm:p-6 sm:my-2 sm:mx-4 sm:rounded-2xl">
    {/* <!-- Navigation --> */}
    <div class="bg-gray-900 px-2 lg:px-4 py-2 lg:py-10 sm:rounded-xl flex lg:flex-col justify-between">
      <nav class="flex items-center flex-row space-x-2 lg:space-x-0 lg:flex-col lg:space-y-2">
        <a class="text-white/50 p-4 inline-flex justify-center rounded-md hover:bg-gray-800 hover:text-white smooth-hover" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 sm:h-6 sm:w-6" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
          </svg>
        </a>
        {/* <!-- Active: bg-gray-800 text-white, Not active: text-white/50 --> */}
        <a class="bg-gray-800 text-white p-4 inline-flex justify-center rounded-md" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 sm:h-6 sm:w-6" viewBox="0 0 20 20" fill="currentColor">
            <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
          </svg>
        </a>
        <a class="text-white/50 p-4 inline-flex justify-center rounded-md hover:bg-gray-800 hover:text-white smooth-hover" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 sm:h-6 sm:w-6" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd" />
          </svg>
        </a>
      </nav>
      <div class="flex items-center flex-row space-x-2 lg:space-x-0 lg:flex-col lg:space-y-2">
        <a class="text-white/50 p-4 inline-flex justify-center rounded-md hover:bg-gray-800 hover:text-white smooth-hover" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 sm:h-6 sm:w-6" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd" />
          </svg>
        </a>
        <a class="text-white/50 p-4 inline-flex justify-center rounded-md hover:bg-gray-800 hover:text-white smooth-hover" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 sm:h-6 sm:w-6" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M3 3a1 1 0 011 1v12a1 1 0 11-2 0V4a1 1 0 011-1zm7.707 3.293a1 1 0 010 1.414L9.414 9H17a1 1 0 110 2H9.414l1.293 1.293a1 1 0 01-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0z" clip-rule="evenodd" />
          </svg>
        </a>
      </div>
    </div>
    {/* <!-- Content --> */}
    <div class="flex-1 px-2 sm:px-0">
      <div class="flex justify-between items-center">
        <h3 class="text-3xl font-extralight text-white/50">Groups</h3>
        <div class="inline-flex items-center space-x-2">
          <a class="bg-gray-900 text-white/50 p-2 rounded-md hover:text-white smooth-hover" href="#">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
          </a>
          <a class="bg-gray-900 text-white/50 p-2 rounded-md hover:text-white smooth-hover" href="#">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
            </svg>
          </a>
        </div>
      </div>
      <div class="mb-10 sm:mb-0 mt-10 grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <div class="group bg-gray-900/30 py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/40 hover:smooth-hover">
          <a class="bg-gray-900/70 text-white/50 group-hover:text-white group-hover:smooth-hover flex w-20 h-20 rounded-full items-center justify-center" href="#">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </a>
          <a class="text-white/50 group-hover:text-white group-hover:smooth-hover text-center" href="#">Create group</a>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1547592180-85f173990554?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80" alt="cuisine" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Cuisine</h4>
          <p class="text-white/50">55 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">22 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1171&q=80" alt="art" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Art</h4>
          <p class="text-white/50">132 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">4 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1560419015-7c427e8ae5ba?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" alt="gaming" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Gaming</h4>
          <p class="text-white/50">207 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">0 Online <span class="ml-2 w-2 h-2 block bg-red-400 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1159&q=80" alt="cinema" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">cinema</h4>
          <p class="text-white/50">105 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">12 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1484704849700-f032a568e944?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80" alt="song" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Song</h4>
          <p class="text-white/50">67 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">3 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80" alt="code" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Code</h4>
          <p class="text-white/50">83 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">43 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
        <div class="relative group bg-gray-900 py-10 sm:py-20 px-4 flex flex-col space-y-2 items-center cursor-pointer rounded-md hover:bg-gray-900/80 hover:smooth-hover">
          <img class="w-20 h-20 object-cover object-center rounded-full" src="https://images.unsplash.com/photo-1533147670608-2a2f9775d3a4?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80" alt="dancing" />
          <h4 class="text-white text-2xl font-bold capitalize text-center">Dancing</h4>
          <p class="text-white/50">108 members</p>
          <p class="absolute top-2 text-white/20 inline-flex items-center text-xs">86 Online <span class="ml-2 w-2 h-2 block bg-green-500 rounded-full group-hover:animate-pulse"></span></p>
        </div>
      </div>
    </div>
  </div>
</div>
         </div>
        );
    };
};
export default connect()(ResponsiveDash);


export const USERACTIVITY = ({ Header, value }) => {

    return (
        <>
            <div className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header} </div>
            <div className="flex justify-center pt-4  ">
                <div class="self-center">
                    <div className="gauge-container" style={{ width: '180px' }}>
                        <GaugeChart
                            id="gauge-chart"
                            nrOfLevels={2}
                            arcWidth={0.14}
                            percent={value * 0.01}
                            textColor="white"
                            text="disable"
                            needleColor="blue"
                            needleBaseColor="gray"
                            startColor="#3f51b5"
                            endColor="#ff9800"
                            arcPadding={0.00}
                            cornerRadius={0}
                            // formatTextValue={value => value * 1}
                            minValue={0}
                            maxValue={100}
                            hideText={true}
                        // needleBaseColor={'#000'}
                        // needleColor={'#f00'}
                        // needleBaseRadius={0}
                        // needleLength={2}
                        // arcPadding={0.02}
                        // cornerRadius={3}
                        // textColor={'#000'}

                        />
                    </div>
                    <div className="flex justify-around text-start text-sm">
                        <span className="text-[#13bf1b]  ">Low</span>
                        <span className="text-blue-800 text-xs font-semibold ">{value}GB</span>
                        <span className="text-[#f33819]">High</span>
                    </div>
                </div>
            </div>
        </>
    )
}

export const CLOUDUTILIZATION = ({ Header, value }) => {
    return (
        <>
            <div className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header} </div>
            <div className="flex justify-around mt-4">
                <GoDatabase color="#feb019" size={60} />
                <div class=" text-[#252422] text-base font-roboto font-medium">
                    <div className="text-right self-end">Capacity</div>
                    <div class=" text-[#252422] font-roboto font-medium text-lg">{value}GB/80GB</div>
                </div>
            </div>
            <div className="flex border-t-[1px] pt-1 space-x-2 mt-4 mx-4 border-[#a49e93] text-[#a49e93] text-base items-center text-center ">
                <TbRefresh color="#a49e93" size={30} />
                <div>Updated Now</div>
            </div>
        </>
    )
}

export const TOTALBARCHART = ({ Header, options, series }) => {
    return (
        <>
            <span className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header}<span class="text-blue-600 text-xl">/11</span></span>
            <div id="ActiveUserChart " className="flex-1 mb-1">
                <ReactApexChart options={options} series={series} type="bar" />
            </div>
        </>
    )
}

export const TOTALSCENARIOS = ({ Header, options, series }) => {
    return (
        <>
            <span className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header} <span class="text-blue-600 text-xl">/07</span></span>
            <div id='scenariosChart' className="flex-1 mt-2">
                <ReactApexChart options={options} series={series} type="donut" />
            </div>

        </>
    )
}

export const TIMELINE = () => {
    return (
        <div class="mt-1">
            <h1 class="text-xl text-center font-semibold mb-3 text-black">Timeline</h1>
            <div class="container">
                <div class="flex flex-col md:grid grid-cols-12 text-gray-50">

                    <div class="flex md:contents">
                        <div class="col-start-2 col-end-4 mr-10 md:mx-auto relative">
                            <div class="h-full w-[2px] flex items-center justify-center">
                                <div class="h-full w-1 bg-gray-300 pointer-events-none"></div>
                            </div>

                            <div class="w-6 h-6 absolute top-1/2 -mt-3 -ml-[11px] bg-white rounded-full flex items-center justify-center border-2 border-[#a2c0fa] shadow text-center">
                                <span><GoDotFill color='#3a7afe' size={20} /></span>
                            </div>
                        </div>
                        <div id='timelinearrow1' class="h-[70px] relative border-l-4 border-l-[#3a7afe] col-start-4 col-end-12 px-2 pl-3  my-4 mr-auto  w-full">
                            <h3 class="font-semibold text-sm mb-1 text-[#89879f]">1 hour ago</h3>
                            <p class=" text-sm  w-full text-[#3d4465] font-medium">
                                Aravindh has tested regression testing <span className="text-blue-500 font-semibold">Passed</span>
                            </p>
                        </div>
                    </div>
                    <div class="flex md:contents">
                        <div class="col-start-2 col-end-4 mr-10 md:mx-auto relative">
                            <div class="h-full w-[2px] flex items-center justify-center">
                                <div class="h-full w-1 bg-gray-300 pointer-events-none"></div>
                            </div>

                            <div class="w-6 h-6 absolute top-1/2 -mt-3 -ml-[11px] bg-white rounded-full flex items-center justify-center border-2 border-[#a7dff3] shadow text-center">
                                <span><GoDotFill color='#00afef' size={20} /></span>
                            </div>
                        </div>
                        <div id='timelinearrow2' class="h-[70px] relative border-l-4 border-l-[#00afef] col-start-4 col-end-12 px-2 pl-3  my-4 mr-auto  w-full">
                            <h3 class="font-semibold text-sm mb-1 text-[#89879f]">1 day ago</h3>
                            <p class="text-sm w-full text-[#3d4465] font-medium">
                                Ivan lendil has tested sanity testing <span className="text-blue-500 font-semibold">passed</span>
                            </p>
                        </div>
                    </div>
                    <div class="flex md:contents">
                        <div class="col-start-2 col-end-4 mr-10 md:mx-auto relative">
                            <div class="h-full w-[2px] flex items-center justify-center">
                                <div class="h-full w-1 bg-gray-300 pointer-events-none"></div>
                            </div>
                            <div class="w-6 h-6 absolute top-1/2 -mt-3 -ml-[11px] bg-white rounded-full flex items-center justify-center border-2 border-[#f5a1aa] shadow text-center">
                                <span><GoDotFill color='#f25767' size={20} /></span>
                            </div>
                        </div>
                        <div id='timelinearrow3' class="h-[70px] relative border-l-4 border-l-[#f25767] col-start-4 col-end-12 px-2 pl-3  my-4 mr-auto  w-full">
                            <h3 class="font-semibold text-sm mb-1 text-[#89879f]">2 days ago</h3>
                            <p class=" text-sm  w-full text-[#3d4465] font-medium">
                                Aravindh has tested integration testing <span className="text-[#f25767] font-semibold">Failed</span>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export const EXE_HISTORY = () => {
    const rowData = [
        { name: "Aravindh", orderid: "#756", role: "Tester", date: "06-04-2023/11:07 AM", status: 'Passed' },
        { name: "Ivan Lendil", orderid: "#757", role: "Analyst", date: "06-04-2023/09:54 AM", status: 'Aborted' },
        { name: "Akash", orderid: "#786", role: "Tester", date: "06-04-2023/08:30 AM", status: 'Failed' },
        { name: "Naveen ", orderid: "#758", role: "Tester", date: "05-04-2023/04:04 PM", status: 'Passed' },
        { name: "Naveen ", orderid: "#758", role: "Tester", date: "05-04-202301:20 PM", status: 'Passed' }
    ];
    const columnDefs = [
        { headerName: "USER ID", field: "orderid", width: '90' },
        {
            headerName: "NAME", field: "name", flex: 2,
            cellStyle: { color: '#212845', fontWeight: '400' }
        },
        { headerName: "ROLE", field: "role", flex: 2 },
        { headerName: "DATE", field: "date", flex: 2 },
        {
            headerName: "EXE. STATUS", field: "status", flex: 2,

            cellRenderer: (params) => {
                if (params.value == "Passed") {
                    return <span class="text-[#13bf1b] bg-[#13bf1b26] text-xs py-[3px] px-2 rounded ">Completed</span>;
                }
                else if (params.value == "Failed") {
                    return <span class="text-[#f33819] bg-[#f3381926] text-xs py-[3px] px-2 rounded ">Failed</span>;
                }
                else
                    return <span class="text-orange-100 bg-[#ec842e] text-xs py-[3px] px-2 rounded ">Aborted</span>;
            }
        }
    ];
    return (
        <div>
            <h1 class="text-lg text-left ml-5 p-2 font-semibold font-roboto mt-1  text-black">Recent Execution History</h1>
            <div className="ag-theme-alpine relative p-2">
                <AgGridReact
                    rowData={rowData} // Row Data for Rows
                    columnDefs={columnDefs} // Column Defs for Columns
                    animateRows={true} // Optional - set to 'true' to have rows animate when sorted
                    suppressMenuHide={true}
                    rowSelection='multiple' // Options - allows click selection of rows
                    sideBar={'filters'}
                    pagination={false}
                    rowHeight={localConstantAGGrid.AGGrid.RowHeight}
                    cacheQuickFilter={true}
                    domLayout='autoHeight'
                    gridOptions={localConstantAGGrid.AGGrid.gridOptions}
                    suppressRowClickSelection={true}
                    suppressRowHoverHighlight={true}
                />
            </div>
        </div>
    )
}