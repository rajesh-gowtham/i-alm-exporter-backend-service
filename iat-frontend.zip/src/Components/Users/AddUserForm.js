import React from "react";
import Select from 'react-select';
import { AiOutlineEyeInvisible, AiOutlineEye } from 'react-icons/ai';
import 'react-toastify/dist/ReactToastify.css';
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { digitsRegExp, specialCharRegExp, validEmailRegex } from "../../CommonUtils/getLocalizeFunction";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
let records = {};

//SCREEN ID -3001
class AddUserForm extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            passwordEye: false,
            confirmEye: false,
            isError: {
                organisation: false,
                firstname: false,
                email: false,
                role: false,
                password: false,
                confirmpassword: false
            },
            errors: {
                email: '',
                firstname: '',
                password: '',
                confirmpassword: '',
                role: '',
                organisation: ''
            }
        }
        this.orgSelecRef = React.createRef();
        this.roleSelectRef = React.createRef();
    }

    componentDidMount() {
        records = {};
    };

    // Added by Rajesh after Validatingg....07/03/2023
    handleOnChange = (e, obj) => {
        try {
            e.preventDefault();
        } catch (error) {
            if (e == null)
                return;
        }
        let name, value;
        let errors = this.state.errors;
        if (e.target == undefined) {
            name = obj.name;
            value = e.value;
            records[name] = value.trim();
            errors[name] = "";
        }
        else {
            name = e.target.name;
            value = e.target.value;
            records[name] = value.trim();
        }

        // console.log('new', name, value)
        const digitRegExp = digitsRegExp(value);
        const splCharRegExp = specialCharRegExp(value);
        switch (name) {
            case 'firstname':
                if (value == undefined || value == "") {
                    errors.firstname = "First Name cant't be empty"
                } else if (digitRegExp || splCharRegExp) {
                    errors.firstname = "Special Charecter & digits Not allow here "
                } else {
                    errors.firstname = ''
                }

                break;

            case 'email':
                errors.email =
                    validEmailRegex(value)
                        ? ''
                        : 'Email is not valid!';
                break;
            case 'password':
                let passError = this.passworValiadte(value);
                errors.password = passError.length == 0 ? passError : '@@' + passError;
                break;
            case 'confirmpassword':
                errors.confirmpassword =
                    value == records.password
                        ? ''
                        : 'Confirm password not match !';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    };

    handleOnAddClick = (e) => {
        e.preventDefault();
        if (this.isValidForm()) {
            var NewUserdetails = [{
                gkey: records.organisation,
                firstName: records.firstname,
                lastName: records.lastname ? records.lastname : '',
                email: records.email,
                status: true,
                role: records.role
            }];
            return records;
        };
    };

    passworValiadte = (value) => {
        let passwordError;
        const uppercaseRegExp = /(?=.*?[A-Z])/.test(value);
        const lowercaseRegExp = /(?=.*?[a-z])/.test(value);
        const digitRegExp = /(?=.*?[0-9])/.test(value);
        const splCharRegExp = /(?=.*?[#?!@$%^&*-])/.test(value);
        const lengthRegExp = value.length > 7 && value.length < 16;

        if (uppercaseRegExp && lowercaseRegExp && digitRegExp && splCharRegExp && lengthRegExp) {
            passwordError = ("");
        } else {
            passwordError = ("A minimum 8 characters password contains a combination of uppercase, lowercase, special character and number is required.");
        }
        return passwordError;
    };

    isValidForm() {
        let isValid = true
        if (records.organisation == undefined) {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    organisation: ' Please Select Organisation '      // update the value of specific key
                },
                isError: {
                    ...prevState.isError,
                    organisation: true
                },
            }));
            isValid = false
            return;
        }
        if (records.firstname == undefined || records.firstname == "" || this.state.errors.firstname != "") {
            let err = records.firstname == undefined || records.firstname == "" ? ' Please enter firstname  ' : this.state.errors.firstname;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    firstname: err                   // update the value of specific key                                                      
                },
                isError: {
                    ...prevState.isError,
                    firstname: true
                },
            }));
            isValid = false
            return;
        }
        if (records.email == undefined || records.email == "" || this.state.errors.email) {
            let err = records.email == undefined || records.email == "" ? ' Please enter email  ' : this.state.errors.email;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    email: err                    // update the value of specific key                                                      
                },
                isError: {
                    ...prevState.isError,
                    email: true
                },
            }));
            isValid = false
            return;
        }
        if (records.role == undefined) {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    role: ' Please Select Role  '                    // update the value of specific key                                                      
                },
                isError: {
                    ...prevState.isError,
                    role: true
                },
            }));
            isValid = false
            return;
        }
        if (records.password == undefined || records.password == "" || this.state.errors.password) {
            // let err = passworValiadte(records)
            let err = records.password == undefined || records.password == "" ? ' Please enter password  ' : this.state.errors.password;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    password: err                    // update the value of specific key                                                      
                },
                isError: {
                    ...prevState.isError,
                    password: true
                },
            }));
            isValid = false
            return;
        }
        if (records.confirmpassword == undefined || records.confirmpassword == "" || this.state.errors.confirmpassword) {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    confirmpassword: ' Please enter valid confirmpassword  '   // update the value of specific key                                                      
                },
                isError: {
                    ...prevState.isError,
                    confirmpassword: true
                },
            }));
            isValid = false
            return;
        }
        return isValid;
    };

    resetOnClick = (e) => {
        e.preventDefault();
        Array.from(document.querySelectorAll("input")).forEach(
            input => (input.value = "")
        );
        this.orgSelecRef.current.clearValue() //Clear React select selected Option Organisation & Roles
        this.roleSelectRef.current.clearValue() //Clear React select selected Option Organisation & Roles
        records = {};
        this.setState({
            errors: {
                email: '',
                firstname: '',
                password: '',
                confirmpassword: '',
                role: '',
                organisation: ''
            }
        })
        //Clear User Records 
        // document.getElementById("addUserForm").reset({});  // Clear All the HTML inputs 
    };

    onPasswordEyeClick = (e) => {
        e.preventDefault();
        const password = document.querySelector('#password');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        if (type === "password") {
            this.setState({
                passwordEye: false,
            })
        } else {
            this.setState({
                passwordEye: true,
            })
        }
    };

    render() {
        const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
        const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
        const borderRed = localControlsConstant.TextBox.textboxRed;
        const borderGrey = localControlsConstant.TextBox.textbox;
        const { errors, isError } = this.state;

        return (
            <div>
                <form id='addUserForm' class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg">
                    <div class="d-inline-block position-relative mb-1">
                        <label for="organisation" class={localControlsConstant.label.label14}>{localConstant.USERS.ORG_NAME}</label><br />
                        <Select
                            name="organisation"
                            id="organisation"
                            ref={this.roleSelectRef}
                            options={this.props.allOrgOptions}
                            styles={isError.organisation ? errors.organisation.length > 0 ? dropDownStylesRed : dropDownStylesGrey : dropDownStylesGrey}
                            placeholder={<div className="select-placeholder-text">Select Organisation</div>}
                            onChange={this.handleOnChange} />
                        {isError.organisation ? errors.organisation.length > 0 &&
                            <span id='isError' class='text-error-red text-[11px]'>{errors.organisation}</span>
                            : null}
                    </div>
                    <div class="d-inline-block position-relative mb-1">
                        <label for="firstname" class={localControlsConstant.label.label14}>{localConstant.USERS.FIRST_NAME}</label><br />
                        <input
                            class={isError.firstname ? errors.firstname.length > 0 ? borderRed : borderGrey : borderGrey}
                            type="text"
                            name="firstname"
                            id="firstname"
                            placeholder="Enter first name"
                            onChange={this.handleOnChange}
                        />
                        {errors.firstname.length > 0 ?
                            <span id='isError' class='text-error-red text-[11px]'>{errors.firstname}</span>
                            : null}
                    </div>
                    <div class="d-inline-block position-relative mb-1">
                        <label for="lastname" class={localControlsConstant.label.label14}>{localConstant.USERS.LAST_NAME}</label><br />
                        <input
                            class={localControlsConstant.TextBox.textbox}
                            type="text"
                            name="lastname"
                            id="lastname"
                            placeholder="Enter last name"
                            onChange={this.handleOnChange}
                        />
                    </div>
                    <div class="d-inline-block position-relative mb-1 ">
                        <label for="email" class={localControlsConstant.label.label14}>{localConstant.USERS.EMAIL_ADDRESS}</label><br />
                        <input
                            class={isError.email ? errors.email.length > 0 ? borderRed : borderGrey : borderGrey}
                            type="email"
                            name="email"
                            id="email"
                            placeholder="Enter email addres"
                            onChange={this.handleOnChange}
                        />
                        {errors.email.length > 0 &&
                            <span class='text-error-red text-[11px]'>{errors.email}</span>
                        }
                    </div>
                    <div class=" d-inline-block position-relative mb-1">
                        <label for="role" class={localControlsConstant.label.label14}>{localConstant.USERS.ROLE}</label><br />
                        <Select
                            styles={isError.role ? errors.role.length > 0 ? dropDownStylesRed : dropDownStylesGrey : dropDownStylesGrey}
                            name='role'
                            isSearchable={false}
                            placeholder={<div className="select-placeholder-text">Select Role</div>}
                            options={this.props.rolesOptions}
                            ref={this.orgSelecRef}
                            onChange={this.handleOnChange}
                        />
                        {isError.role && errors.role.length > 0 &&
                            <span id='isError' class='text-error-red text-[11px]'>{errors.role}</span>
                        }
                    </div>
                    <div class="d-inline-block position-relative mb-1">
                        <label for="password" class={localControlsConstant.label.label14}>{localConstant.USERS.CREATE_PASSWORD}</label><br />
                        <div class="w-full relative  h-[35px] items-center rounded-md ">
                            <input
                                class={isError.password ? errors.password.length > 0 ? borderRed : borderGrey : borderGrey}
                                type="password"
                                name="password"
                                id="password"
                                placeholder="***Password***"
                                autoComplete="new-password"
                                onChange={this.handleOnChange}
                            />
                            <div class=" absolute inset-y-0 right-0 flex items-center px-3 pt-0 ">
                                {this.state.passwordEye ? <AiOutlineEye onMouseUp={(e) => this.onPasswordEyeClick(e)} />
                                    : <AiOutlineEyeInvisible onMouseUp={(e) => this.onPasswordEyeClick(e)} />}
                            </div>
                        </div>
                        {isError.password && errors.password.length > 0 &&
                            <span id='isError' class='text-error-red text-[11px]'>
                                {errors.password.split('@@').map((item, index) =>
                                    item.split("#").map((text, id) => { return id === 0 && index == 0 ? <span key={id}>{text + ''}</span> : <span key={id}>{text}</span> }))
                                }
                            </span>
                        }
                    </div>
                    <div class=" d-inline-block position-relative mb-1">
                        <label for="confirmPassword" class={localControlsConstant.label.label14}>{localConstant.USERS.CONFIRM_PASSWORD}</label><br />
                        <div class="flex flex-wrap w-full relative h-12  items-center rounded-md   ">
                            <input
                                class={this.state.isError.confirmpassword ? errors.confirmpassword.length > 0 ? borderRed : borderGrey : borderGrey}
                                type="password"
                                name='confirmpassword'
                                onChange={this.handleOnChange}
                                placeholder="Confirm Password"
                            />
                        </div>
                        {isError.confirmpassword && errors.confirmpassword.length > 0 &&
                            <span id='isError' class='text-error-red text-[11px]'>{errors.confirmpassword}</span>
                        }
                    </div>
                    <div class="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end space-x-3 mt-2 pb-0 p-4 pr-1 border-t border-footer-border rounded-b-md">
                        <button type="submit" onClick={(e) => { this.props.AddUserOnClick(e, this.handleOnAddClick(e)) }}
                            class={localControlsConstant.Buttons.btnPrimary}>{localConstant.COMMON_CONST.ADD}</button>
                        <button type="cancel" onClick={this.resetOnClick} class={localControlsConstant.Buttons.btnSecondary} >{localConstant.COMMON_CONST.RESET}</button>
                    </div>
                </form>
            </div>
        )
    }
}
export default AddUserForm;

