import React from "react";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import Select from 'react-select';
import { digitsRegExp, specialCharRegExp, validEmailRegex } from "../../CommonUtils/getLocalizeFunction";
import { getlocalizeData } from "../../CommonUtils/getlocalizeData";

const localConstant = getlocalizeData();
let records = {};

//SCREEN ID -3000
class EditUserForm extends React.Component {
    constructor(props) {
        console.log("props.userData " + JSON.stringify(props.userData))
        super();
        this.state = {
            SelectedUserData: props.userData,
            errors: {
                email: '',
                firstName: '',
                role: '',
                organisation: ''
            }
        }
        this.roleSelectRef = React.createRef();
    }

    componentDidMount() {
        records = {};
        records["organisation"] = window.localStorage.getItem("OrganizationName");
        records["email"] = this.state.SelectedUserData["email"];
        records["firstName"] = this.state.SelectedUserData["firstName"]
        records["lastName"] = this.state.SelectedUserData["lastName"]
        records["status"] = this.state.SelectedUserData["status"]
        records["gkey"] = this.state.SelectedUserData["gkey"]
        records["role"] = this.state.SelectedUserData["role"]
        records["rolegkey"] = this.state.SelectedUserData["rolegkey"]
        records["argo_User_key"] = this.state.SelectedUserData["argo_User_key"]

        this.setState({ SelectedUserData: records })
    };

    handleOnChange = (e, obj) => {
        try {
            e.preventDefault();
        }
        catch (error) {
            if (e == null)
                return;
        }
        let name, value;
        let errors = this.state.errors;
        if (e.target == undefined) {

            name = obj.name;
            value = e.value;
            records[name] = value.trim();
            errors[name] = "";
        }
        else {
            name = e.target.name;
            value = e.target.value;
            records[name] = value.trim();
        }
        const digitRegExp = digitsRegExp(value);
        const splCharRegExp = specialCharRegExp(value);
        switch (name) {
            case 'firstName':
                if (value == undefined || value == "") {
                    errors.firstname = "First Name cant't be empty"
                } else if (digitRegExp || splCharRegExp) {
                    errors.firstname = "Special Charecter & digits Not allow here "
                } else {
                    errors.firstname = ''
                }
                break;
            case 'email':
                errors.email =
                    validEmailRegex(value)
                        ? ''
                        : 'Email is not valid!';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
        console.log("records[role] :" + records["role"])
    };

    isValidForm() {
        let isValid = true
        if (records.organisation == undefined) {
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    organisation: ' Please Select Organisation '
                },
            }));
            return isValid = false;
        }
        if (records.firstName == undefined || records.firstName == "" || this.state.errors.firstName != "") {
            let err = records.firstName == undefined || records.firstName == "" ?
                ' Please enter firstName  ' : this.state.errors.firstName;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    firstName: err                   // update the value of specific key                                                      
                },
            }));
            return isValid = false;
        }
        if (records.email == undefined || records.email == "" || this.state.errors.email) {
            let err = records.email == undefined || records.email == ""
                ? ' Please enter email  ' : this.state.errors.email;
            this.setState(prevState => ({
                errors: {
                    ...prevState.errors,
                    email: err
                },
            }));
            return isValid = false;
        }
        if (records.role == undefined) {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    role: ' Please Select Role  '                    // update the value of specific key                                                      
                },
            }));
            return isValid = false;
        }
        return isValid;
    };

    handleClear = (e) => {
        e.preventDefault();
        this.roleSelectRef.current.clearValue();
        // records.email = ""
        records.firstName = ""
        records.lastName = ""
        records.role = ""
        records.rolegkey = ""
        records.argo_User_key = ""
        this.setState({
            SelectedUserData: records,
            errors: {
                email: '',
                firstName: '',
                role: '',
                organisation: ''
            }
        })
    };

    render() {
        const borderRed = ControlsConstants.TextBox.textboxRed;
        const borderGrey = ControlsConstants.TextBox.textbox;
        const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
        const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
        const { errors } = this.state;
        const { organisation, firstName, lastName, email, role } = this.state.SelectedUserData;
        return (
            <>
                <div >
                    <form class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg">
                        <div class="flex  flex-col justify-between my-[5px]">
                            <div class="d-inline-block position-relative mb-1">
                                <label for="org" class={ControlsConstants.label.label14}>{localConstant.USERS.ORG_NAME}</label><br />
                                <Select options={this.props.allOrgOptions}
                                    styles={dropDownStylesGrey}
                                    value={{ label: organisation, value: organisation }}
                                    //onChange={e => this.dropdownOnOrg(e)}
                                    isDisabled={true}
                                />
                            </div>
                            <div class="grow-1 d-inline-block position-relative mb-1">
                                <label for="firstName" class={ControlsConstants.label.label14}>{localConstant.USERS.FIRST_NAME}</label><br />
                                <input
                                    class={errors.firstName.length > 0 ? borderRed : borderGrey}
                                    type="text"
                                    placeholder="Enter first name"
                                    name="firstName"
                                    value={firstName}
                                    onChange={(e) => { this.handleOnChange(e) }}
                                />
                                {
                                    errors.firstName.length > 0 &&
                                    <span class='text-error-red text-[11px]'>{errors.firstName}</span>
                                }
                            </div>
                            <div class="d-inline-block position-relative mb-1">
                                <label for="lastName" class={ControlsConstants.label.label14}>{localConstant.USERS.LAST_NAME}</label><br />
                                <input
                                    class={ControlsConstants.TextBox.textbox}
                                    type="text"
                                    placeholder="Enter last name"
                                    name="lastName"
                                    Value={lastName}
                                    onChange={(e) => { this.handleOnChange(e) }}
                                />
                            </div>
                        </div>
                        <div class="flex flex-col text-[12px]  justify-between">
                            <div class="d-inline-block position-relative mb-1 ">
                                <label for="email" class={ControlsConstants.label.label14}>{localConstant.USERS.EMAIL_ADDRESS}</label><br />
                                <input
                                    class={errors.email.length > 0 ? borderRed : borderGrey}
                                    type="email"
                                    placeholder="Enter email addres"
                                    name="email"
                                    Value={email}
                                    onChange={(e) => { this.handleOnChange(e) }}
                                    disabled={true}
                                />
                                {
                                    errors.email.length > 0 &&
                                    <span class='text-error-red text-[11px]'>{errors.email}</span>
                                }

                            </div>
                            <div class=" d-inline-block position-relative mb-1">
                                <label for="role" class={ControlsConstants.label.label14}>{localConstant.USERS.ROLE}</label><br />
                                <Select
                                    styles={errors.role.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                                    name='rolegkey'
                                    placeholder={<div className="select-placeholder-text">Select Role</div>}
                                    options={this.props.rolesOptions}
                                    defaultValue={{ label: role, value: role }}
                                    onChange={this.handleOnChange}
                                    ref={this.roleSelectRef}
                                />
                                {errors.role.length > 0 &&
                                    <span class='text-error-red text-[11px]'>{errors.role}</span>
                                }
                            </div>
                        </div>
                        <div class="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end mt-2 pb-0 p-4 pr-1 border-t border-footer-border rounded-b-md">
                            <button type="submit" onClick={(e) => this.props.editUserOnClick(e, records, this.isValidForm())}
                                class={ControlsConstants.Buttons.btnPrimary}>{localConstant.COMMON_CONST.UPDATE}</button>
                            <button type="submit" onClick={(e) => this.handleClear(e)}
                                class={ControlsConstants.Buttons.btnSecondary}>{localConstant.COMMON_CONST.RESET}</button>
                        </div>
                    </form>
                </div>
            </>
        )
    }
}

export default EditUserForm;