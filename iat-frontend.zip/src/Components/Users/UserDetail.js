import React, { useState, useEffect, useCallback } from 'react';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { GoDotFill } from 'react-icons/go';
import { HiPlus } from 'react-icons/hi';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import AddUserForm from './AddUserForm';
import EditUserForm from './EditUserForm'
import { ControlsConstants } from '../../Constants/ControlsConstants';
import UserService from '../../Services/UserService';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import OrganizationService from '../../Services/OrganizationService';
import Argo_Users_roles_detailsService from '../../Services/Argo_Users_roles_detailsService';
import RoleService from '../../Services/RoleService';
import { createUserWithEmailAndPassword, getAuth, sendEmailVerification } from 'firebase/auth';
import { auth } from '../../firebase/firebase';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
let allOrgOptions = [], rolesOptions = [];
//SCREEN ID -3003
const UserDetail = (props) => {

  const [formHeader, setFormHeader] = useState('');      // dialog box header name 
  const [isEditUser, setIsEditUser] = useState(false);   //flag for open Edit user form
  const [isAddUser, setIsAddUser] = useState(false);        //flag for open Add user user form
  const [isDeleteUser, setIsDeleteUser] = useState(false); //flag for open delete user form
  const [deleteUserData, setDeleteUserData] = useState({});    //set delete user name
  const [editUserData, setEditUserData] = useState({});          //  set user data for Edit user form
  const [rowData, setRowData] = useState([]);          // Set rowData to Array of Objects, one Object per Row
  const [filterValue, setFilterValue] = useState();
  const [navPath, setNavPath] = useState(['Users'])        // Set rowData to Array of Objects, one Object per Row
  // Each Column Definition results in one Column.
  const [columnDefs] = useState([
    // {
    //   field: '', width: 50, headerCheckboxSelection: true, checkboxSelection: true
    // },
    // {
    //   headerName: "ID", suppressMovable: true, width: 120,
    //   cellRenderer: (params) => {
    //     const id = `300${params.rowIndex + 1}`.slice(-4);
    //     return <span className=' text-blue-600 cursor-pointer' onClick={() => editUserOpen(params)}> {'U' + id}</span>
    //   },
    // },
    {
      headerName: "Name", field: "username", suppressMovable: true, flex: 1,
      cellRenderer: (params) => {
        return <span className=' text-blue-600 cursor-pointer' onClick={() => editUserOpen(params)}> {params.value}</span>
      },

    },
    { headerName: "E-Mail", field: "email", suppressMovable: true, flex: 2 },
    {
      headerName: "Status", field: "status", suppressMovable: true, flex: 1,
      cellRenderer: (params) => {
        if (params.node.rowIndex == 4) {
          return <span class="text-[#f33819] bg-[#f3381926] text-xs py-[3px] px-2 rounded ">In Active</span>
          // <span class="flex items-center justify-items-center grow text-[#f04949]"><GoDotFill size={18} /><span class="text-[#89879f]">In Active</span></span>;
        } else
          return <span class="text-[#13bf1b] bg-[#13bf1b26] text-xs py-[3px] px-2 rounded ">Active</span>
        //  <span class="flex items-center justify-items-center grow text-[#10ca93]"><GoDotFill size={18} /><span class="text-[#89879f]">Active</span></span>
      }
    },
    {
      headerName: "Action", field: "Action", suppressMovable: true, flex: 1,
      cellRendererFramework: (params) =>
        <div class='flex w-full h-full items-center space-x-4'>
          <button onClick={() => editUserOpen(params)}><EditLogo /></button>
          <button onClick={() => deleteUserOpen(params)} >< TrashLogo /></button>
        </div>
    }
  ]);

  //LOADE USER DATA AND ROLE'S , ORGANISATIONS
  useEffect(() => {
    GetAllUserByOrg();
    GetAllRoleOrgOptions();
  }, []);

  const GetAllUserByOrg = async () => {
    const orgKey = window.localStorage.getItem("MasterBizUitKey");
    const response = await UserService.AllUsersbyOrg(orgKey);
    console.log('user data ', response, orgKey)
    const userList = response.data.map(user => {
      const { firstName, lastName, email, gkey, status, firebaseid } = user;
      return {
        username: `${firstName} ${lastName}`,
        firstName: firstName,
        lastName: lastName,
        email,
        gkey,
        role: "", // Backend role not implemented yet
        status: status ? "Active" : "Inactive",
        firebaseid: firebaseid
      };
    });
    setRowData(userList);
  };

  //Use Effect for Org and Role Option Added By Rajesh 16/03/
  const GetAllRoleOrgOptions = useCallback(() => {
    allOrgOptions = [];
    rolesOptions = [];
    // Get ALL ROLES
    //getRoleByOrg RoleService   
    RoleService.getRoleByOrg().
      then(
        response => {
          //alert(JSON.stringify(response.data))
          response.data.map((datas, index) => (
            rolesOptions[index] = {
              label: datas.name,
              value: datas.gkey,
              // gkey:datas.gkey
            }
          )
          )
        }
      );
    OrganizationService.GetAllOrg().
      then(
        response => {
          response.data.map((datas, index) => (
            allOrgOptions[index] = {
              label: datas.name,
              value: datas.gkey,
              // gkey:datas.gkey
            }
          )
          )
        }
      );
  });

  //Added By Rajesh 16/03/2023 For create Firebass Credential And user Creation 
  const CreateUserAndLogins = async (email, password, userRecord) => {
    createUserWithEmailAndPassword(auth, email, password)
      .then(res => {
        console.log(JSON.stringify(res.user))
        console.log(JSON.stringify(res.user.uid))
        //   auth.user.sendEmailVerification();
        auth.signOut();
        // Create user 
        UserService.CreateUsersbyOrg(userRecord, res.user.uid).
          then(
            response => {
              if (response.status == 201) {
                setIsAddUser(false);
                toast.success("User Added Successfully ");
                // Added By Mubarakk 24-04-2023  Email Vefication
                // res.user.sendEmailVerification();
                // auth.signOut();
                GetAllUserByOrg();
              }
            }
          ).catch((error) => {
            const errorCode = error.code;
            toast.error(errorCode);
          });
      })
      .catch(error => {
        switch (error.code) {
          case 'auth/email-already-in-use':
            toast.error(`Email address already in use.`);
            break;
          case 'auth/invalid-email':
            toast.error(`Email address ${email} is invalid.`);
            break;
          case 'auth/operation-not-allowed':
            toast.error(`Error during sign up.`);
            break;
          case 'auth/weak-password':
            toast.error('Password is not strong enough. Add additional characters including special characters and numbers.');
            break;
          default:
            toast.error(error.message);
            break;
        }
      });
  }

  const addUSerOpen = () => {
    setIsAddUser(true);
    setFormHeader('Add User');
  };

  const AddUserOnClick = (event, records) => {
    event.preventDefault();
    console.log('AddUserOnClick', records)
    if (records) {
      var NewUserdetails = {
        gkey: records.organisation,
        firstName: records.firstname,
        lastName: records.lastname ? records.lastname : '',
        email: records.email,
        status: true,
        role: records.role,
        firebaseid: ''
      };
      console.log('add user NewUserdetails', NewUserdetails)
      CreateUserAndLogins(records.email, records.password, NewUserdetails)
    }
  };

  const editUserOpen = (event) => {
    //{"id":2,"username":"Mubarak Ali","email":"mubarakali@igosolutions.eu","status":"Active","gkey":"6422bf1ad37f3220741c8c58","role":"Admin"}
    //RoleGkey
    setFormHeader('Edit User');
    // setIsEditUser(true);
    Argo_Users_roles_detailsService.GetRoleDetailsByUserGkey(event.data.gkey).
      then(
        response => {
          let EditUserDetails = {
            id: event.data.id,
            firstName: event.data.firstName,
            lastName: event.data.lastName,
            email: event.data.email,
            status: event.data.status,
            gkey: event.data.gkey,
            role: '',
            rolegkey: '',
            argo_User_key: ''
          }
          EditUserDetails.rolegkey = response.data.RoleGkey
          EditUserDetails.role = response.data.RoleName
          EditUserDetails.argo_User_key = response.data.argo_Users_rolesgkey
          //argo_Users_rolesgkey
          console.log("edit  ", (EditUserDetails))
          setEditUserData(EditUserDetails);
          setIsEditUser(true);
        }
      );
  };

  const editUserOnClick = (event, records, isDataValid) => {
    event.preventDefault();
    const UpdatedUserData = [];
    UpdatedUserData.push(records)
    if (isDataValid) {
      console.log("UpdatedUserData>>" + JSON.stringify(UpdatedUserData))
      UserService.UpdateUsersbyOrg(UpdatedUserData).
        then(
          response => {
            if (response.status == 200) {
              toast.success(response.data.firstName + " Updated Successflly ! ");
              GetAllUserByOrg();
              setIsEditUser(false);
            }
          }
        );
    }
  };

  const deleteUserOpen = (event) => {
    setDeleteUserData({ username: event.data.username, gkey: event.data.gkey, firebaseid: event.data.firebaseid });
    setIsDeleteUser(true)
  };

  const deleteUserOnClick = (event) => {
    console.log(deleteUserData)
    UserService.DeleteUserByOrg(deleteUserData.gkey)
      .then(
        response => {
          console.log('deleteuseer', response.data)
          if (response.status === 200) {
            let addUsername = response.data.firstName;
            toast.success((addUsername + " User Deleted Successfully!"));
            GetAllUserByOrg();
          }
        }
      );
    setIsDeleteUser(false)
  };

  const onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    setFilterValue(filterValue)
  };

  const backToMainScreen = (e) => {
    setNavPath(['Privileges'])
  };

  const popUpFormClose = () => {
    setIsAddUser(false);
    setIsEditUser(false);
    setIsDeleteUser(false)
    GetAllUserByOrg();
  };

  return (
    <AuthCommonLayout>
      <div>

        <div id='screenHeader'>
          <ComponentHeader
            isSearchable={true}
            path={navPath}
            backToParentClass={backToMainScreen}
            onFilterTextBoxChanged={onFilterTextBoxChanged}
          />
        </div>

        <div className='screenBody'>

          <div id='CustomAgGrid'>
            <CustomAgGrid
              rowData={rowData}
              columnDefs={columnDefs}
              onGridReady={() => { console.log(" ongrid ready USER") }}
              filterValue={filterValue}
            />
          </div>

          <div className="fixed bottom-6 right-10"  >
            <button onClick={addUSerOpen} class={localControlsConstant.ToolTip.addbutton}>
              <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
              <div class={localControlsConstant.ToolTip.tooltipGroup}>
                <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.USERS.ADD_USER}</span>
                <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
              </div>
            </button>
          </div>

          {isAddUser || isEditUser ?
            <ReactDialogBox
              closeBox={popUpFormClose}
              modalWidth={localControlsConstant.Model.modalWidthUser}
              headerBackgroundColor={ControlsConstants.Model.headerbg}
              headerTextColor={localControlsConstant.Model.bodybg}
              headerHeight={localControlsConstant.Model.headerheight}
              closeButtonColor={localControlsConstant.Model.closebtncolor}
              bodyBackgroundColor={localControlsConstant.Model.bodybg}
              bodyTextColor={localControlsConstant.Model.bodytextcolor}
              headerText={formHeader}
            >
              {isAddUser ?
                <AddUserForm
                  allOrgOptions={allOrgOptions}
                  rolesOptions={rolesOptions}
                  AddUserOnClick={AddUserOnClick} />
                :
                <EditUserForm
                  userData={editUserData}
                  allOrgOptions={allOrgOptions}
                  rolesOptions={rolesOptions}
                  editUserOnClick={editUserOnClick} />
              }
            </ReactDialogBox>
            : null}

          {isDeleteUser ?
            <div>
              <ReactDialogBox
                closeBox={popUpFormClose}
                modalWidth={localControlsConstant.Model.modalWidth}
                headerBackgroundColor={localControlsConstant.Model.headerbg}
                headerTextColor={localControlsConstant.Model.bodybg}
                headerHeight={localControlsConstant.Model.headerheight}
                closeButtonColor={localControlsConstant.Model.closebtncolor}
                bodyBackgroundColor={localControlsConstant.Model.bodybg}
                bodyTextColor={localControlsConstant.Model.bodytextcolor}
                headerText='Delete User'
              >
                <div>
                  <div class='flex items-center h-16 pl-7'>
                    <h1>{localConstant.USERS.DELETE_USER_CONTENT} <span class='text-delete-user-text'>{deleteUserData.username}</span>?</h1>
                  </div>
                  <div class="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                    <button type="button" class={ControlsConstants.Buttons.btnPrimary} onClick={deleteUserOnClick}>{localConstant.COMMON_CONST.DELETE}</button>
                    <button type="button" class={ControlsConstants.Buttons.btnSecondary} onClick={popUpFormClose}>{localConstant.COMMON_CONST.CANCEL}</button>
                  </div>
                </div>
              </ReactDialogBox>
            </div>
            : null
          }
          <ToastContainer limit={1} />
        </div>
      </div>
    </AuthCommonLayout>
  );
};
export default UserDetail;