import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();
var ControlOptions = [{ label: 'Edit', value: 'Edit' }, { label: 'Text', value: 'Text' }, { label: 'List', value: 'List' }]

//SCREEN ID -3023
const EditTransaction_Columns = (props) => {
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    return (
        <div>
            <form class="flex font-[Verdana] flex-col mt-7 mx-5 rounded-b-lg">
                <div class="flex items-center mb-5">
                    <span class='flex-1'>
                        <label for="shortName" class={localControlsConstant.label.label14}>{localConstant.TRANSACTION_RECORDS.LABEL}</label>
                    </span>
                    <span class='flex-[2]'>
                        <input
                            class={props.errors.shortName.length > 0 ? borderRed : borderGrey}
                            type="text"
                            placeholder="Enter label name"
                            name="shortName"
                            value={props.editTransactionData.shortName}
                            onChange={props.editTransactionColumn_OnChange}
                        >
                        </input>
                        {props.errors.shortName.length > 0 ?
                            <span id='isError' class='text-error-red text-[11px]'>{props.errors.shortName}</span>
                            : null}
                    </span>
                </div>
                <div class="flex items-center mb-5">
                    <span class='flex-1'>
                        <label for="displayName" class={localControlsConstant.label.label14}> {localConstant.TRANSACTION_RECORDS.DISPLAY_NAME}</label>
                    </span>
                    <span class='flex-[2]'>
                        <input
                            class={props.errors.displayName.length > 0 ? borderRed : borderGrey}
                            type="text"
                            placeholder="Enter display name"
                            name="displayName"
                            value={props.editTransactionData.displayName}
                            onChange={props.editTransactionColumn_OnChange}
                        >
                        </input>
                        {props.errors.displayName.length > 0 ?
                            <span id='isError' class='text-error-red text-[11px]'>{props.errors.displayName}</span>
                            : null}
                    </span>
                </div>
                <div class="flex items-center mb-5">
                    <span class='flex-1'>
                        <label for="control" class={localControlsConstant.label.label14}> {localConstant.TRANSACTION_RECORDS.CONTROL} </label>
                    </span>
                    <span class='flex-[2]'>
                        <Select
                            options={ControlOptions}
                            name="control"
                            value={{ label: props.editTransactionData.control, value: props.editTransactionData.control }}
                            onChange={props.editTransactionColumn_OnChange}
                            styles={props.errors.control.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                        />
                        {props.errors.control.length > 0 ?
                            <span id='isError' class='text-error-red text-[11px]'>{props.errors.control}</span>
                            : null}
                    </span>
                </div>
                <div class="flex items-center mb-5">
                    <span class='flex-1'>
                        <label for="Applie_To" class={localControlsConstant.label.label14}>{localConstant.TRANSACTION_RECORDS.GROUP}</label>
                    </span>
                    <span class='flex-[2]'>
                        <Select
                            options={props.groupselect}
                            value={
                                props.groupselect.filter(option =>
                                    option.value === props.editTransactionData.Applie_To)
                            }
                            onChange={props.editTransactionColumn_OnChange}
                            name="Applie_To"
                            styles={props.errors.group.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                        />
                        {props.errors.group.length > 0 ?
                            <span id='isError' class='text-error-red text-[11px]'>{props.errors.group}</span>
                            : null}
                    </span>
                </div>
                <div class="modal-footer space-x-3 flex flex-shrink-0 flex-wrap items-center justify-end mt-2 pb-0 p-4 pr-1 border-t border-footer-border rounded-b-md">
                    <button type="submit" class={localControlsConstant.Buttons.btnPrimary}
                        onClick={(e) => props.editFields_Columns_Click(e)}>{localConstant.COMMON_CONST.UPDATE}</button>
                    <button type="submit" class={localControlsConstant.Buttons.btnSecondary}
                        onClick={(e) => props.editTransactionRowClose(e)}>{localConstant.COMMON_CONST.CANCEL}</button>
                </div>
            </form>
        </div>
    )
}
export default EditTransaction_Columns;

