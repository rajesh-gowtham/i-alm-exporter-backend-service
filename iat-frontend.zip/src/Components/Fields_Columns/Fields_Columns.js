import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import EditFields_Columnss from './EditFields_Columns';
import AddFields_Columnss from './AddFields_Columns';
import ColumnServices from '../../Services/ColumnServices';
import StreamService from '../../Services/StreamService';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import '../../CSS/columnAdd.css';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import ManualIcon from '../../Images/manualIcon.png';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';
import { TbKeyboard } from 'react-icons/tb';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//Manual / Browse Mode Only Added By Mubarak Ali
//SCREEN ID -3022
class Fields_Columns extends React.Component {
  constructor() {
    super()
    this.state = {
      fieldColumnFlag: true,
      addColumnsFlag: false,
      addExcelColFlag: false,
      editColumnFlag: false,
      deleteColumnFlag: false,
      deleteData: {},
      editdetails: {},
      groupselect: [],
      navPath: ['Columns'],
      errors: {
        shortName: '',
        displayName: '',
        control: '',
        group: ''
      },
      newColumnData: {},
      columnDefs: [
        // {
        //   headerName: "ID", field: "gkey", suppressMovable: true, minWidth: 120, flex: 1,
        //   cellRenderer: (params) => {
        //     const id = `300${params.rowIndex + 1}`.slice(-4);
        //     return <span className=' text-blue-600 cursor-pointer' onClick={() => this.editColumnOpen(params)}> {'C' + id}</span>
        //   }
        // },
        {
          headerName: "Label", field: "shortName", suppressMovable: true, minWidth: 150, flex: 2,
          cellRenderer: (params) => {
            return <span className=' text-blue-600 cursor-pointer' onClick={() => this.editColumnOpen(params)}> {params.value}</span>
          }
        },
        { headerName: "Display Name", field: "displayName", suppressMovable: true, minWidth: 150, flex: 2 },
        { headerName: "Control", field: "control", suppressMovable: true, minWidth: 150, flex: 2 },
        {
          headerName: "Action", field: "Action", suppressMovable: true, minWidth: 120, flex: 1,
          cellRendererFramework: (params) =>
            <div class='flex w-full h-full items-center space-x-4'>
              <button onClick={() => this.editColumnOpen(params)}><EditLogo /></button>
              <button onClick={() => this.deleteColumnOpen(params)} >< TrashLogo /></button>
            </div>
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: [],
      validXlDatas: [],
    };
    this.controlSelect = React.createRef();
    this.groupSelect = React.createRef();
    this.addColumn_OnClick = this.addColumn_OnClick.bind(this);
    this.addColumn_OnChange = this.addColumn_OnChange.bind(this);
  }

  componentDidMount() {
    this.LoadColumnGrid();
    this.LoadGropField();
  };

  deleteColumnOn_Click = (event) => {
    event.currentTarget.disabled = true;
    ColumnServices.DeleteColumnByOrg(this.state.deleteData["gkey"]).
      then(
        response => {
          if (response.status === 200) {
            toast.success("Column Deleted Successfully!");
            this.LoadColumnGrid();
            this.deleteColumnClose();
          }
        }
      );
  };

  LoadColumnGrid() {
    ColumnServices.GetColumnsByOrg().
      then(
        response => {
          this.setState({
            rowData: response.data
          })
        }
      );
  };

  LoadGropField = () => {
    StreamService.getStreamByOrg().
      then(
        response => {
          const options = response.data.map((datas, index) => (
            {
              "value": datas.gkey,
              "label": response.data[index]["name"],
            }))
          this.setState({
            groupselect: options
          })
        }
      );
  };

  addExcelColumnOpen = () => {
    this.setState({
      addColumnsFlag: true,
      addExcelColFlag: true,
      fieldColumnFlag: false,
      navPath: ['Columns', 'Add Excel Columns']
    })
  }

  addManualColumnOpen = () => {
    this.setState({
      addColumnsFlag: true,
      addExcelColFlag: false,
      fieldColumnFlag: false,
      newColumnData: {
        shortName: '',
        displayName: '',
        control: '',
        Applie_To: ''
      },
      navPath: ['Columns', 'Add Manual Column'],
      errors: {
        shortName: '',
        displayName: '',
        control: '',
        group: ''
      },
    })
  }

  addColumn_OnChange = (e, obj) => {
    try {
      e.preventDefault();
    } catch (error) {
      if (e == null)
        return;
    }
    let name, value;
    let errors = this.state.errors;
    if (e.target == undefined) {
      name = obj.name;
      value = e.value;
      errors[name] = "";
    }
    else {
      name = e.target.name;
      value = e.target.value.trim();
    }

    this.setState(prevState => ({
      newColumnData: {
        ...prevState.newColumnData,
        [name]: value,
      }
    }))

    switch (name) {
      case 'shortName':
        errors.shortName =
          value.length < 1
            ? "Label name can't be empty ! "
            : '';
        break;
      case 'displayName':
        errors.displayName =
          value.length < 1
            ? "Display name can't be empty ! "
            : '';
        break;
      case 'control':
        errors.control =
          value.length < 1
            ? "Control name can't be empty ! "
            : '';
        break;
      case 'Applie_To':
        errors.group =
          value.length < 1
            ? "Group name can't be empty ! "
            : '';
        break;
      default:
        break;
    }
  };

  addColumn_OnClick = event => {
    event.preventDefault();
    let newColumnData = this.state.newColumnData
    newColumnData["MasterBizUitKey"] = window.localStorage.getItem("MasterBizUitKey");
    newColumnData["value"] = 'N/A';
    newColumnData["Mode"] = 'Manual';
    console.log('newColumnData', newColumnData)
    if (this.validateAllData(newColumnData)) {
      for (var i = 0; i < this.state.rowData.length; i++) {
        if (this.state.rowData[i].shortName.toUpperCase() == newColumnData.shortName.toUpperCase()) {
          toast.error("Lable Already exist!");
          return;
        }
      }
      event.currentTarget.disabled = true;
      ColumnServices.CreateColumnByOrg(newColumnData).
        then(
          response => {
            if (response.status === 201 || response.status === 200) {
              toast.success("Columns Added Successfully!");
              this.LoadColumnGrid();
              this.backToMainScreen(event);
            }
          }
        )
    }
  };

  editColumnOpen = (event) => {
    console.log('editColumnOpen', event.data)
    this.setState({
      editColumnFlag: true,
      fieldColumnFlag: false,
      errors: {
        shortName: '',
        displayName: '',
        control: '',
        group: ''
      },
      editdetails: event.data,
      navPath: ['Columns', 'Edit Column']
    })
  }

  editColumn_OnChange = (e, obj) => {
    try {
      e.preventDefault();
    } catch (error) {
      if (e == null)
        return;
    }
    let name, value;
    let errors = this.state.errors;
    if (e.target == undefined) {
      name = obj.name;
      value = e.value;
      errors[name] = "";
    }
    else {
      name = e.target.name;
      value = e.target.value.trim();
    }

    this.setState(prevState => ({
      editdetails: {
        ...prevState.editdetails,
        [name]: value,
      }
    }))

    switch (name) {
      case 'shortName':
        errors.shortName =
          value.length < 1
            ? "Label name can't be empty ! "
            : '';
        break;
      case 'displayName':
        errors.displayName =
          value.length < 1
            ? "Display name can't be empty ! "
            : '';
        break;
      case 'control':
        errors.control =
          value.length < 1
            ? "Control name can't be empty ! "
            : '';
        break;
      case 'Applie_To':
        errors.group =
          value.length < 1
            ? "Group name can't be empty ! "
            : '';
        break;
      default:
        break;
    }
    this.setState({ errors, [name]: value });
  };

  editColumns_OnClick = event => {
    let updatedData = this.state.editdetails;
    console.log('updatedData', updatedData)
    event.preventDefault();
    if (this.validateAllData(updatedData)) {
      for (var i = 0; i < this.state.rowData.length; i++) {
        if (this.state.rowData[i].shortName.toUpperCase() == updatedData.shortName.toUpperCase()) {
          toast.error("Lable Already exist!");
          return;
        }
      }
      event.currentTarget.disabled = true;
      ColumnServices.UpdateColumnByOrg(updatedData).then(
        response => {
          if (response.status == 200 || response.status == 201) {
            toast.success("Column Updated Successfully")
            this.LoadColumnGrid();
            this.setState({
              editColumnFlag: false
              , fieldColumnFlag: true
            })
          } else {
            toast.error("Column Updated Failed")
          }
        }
      ).catch(err =>
        console.log(err)
      )
    }
  };

  validateAllData(records) {
    if (records.shortName == undefined || records.shortName == "" || this.state.errors.shortName != "") {
      let err = records.shortName == undefined || records.shortName == "" ? ' Please Enter Label Name  ' : this.state.errors.shortName;
      this.setState(prevState => ({
        errors: {                            // object that we want to update
          ...prevState.errors,               // keep all other key-value pairs
          shortName: err                   // update the value of specific key                                                      
        },
      }));
      return false;
    }
    if (records.displayName == undefined || records.displayName == "" || this.state.errors.displayName) {
      let err = records.displayName == undefined || records.displayName == "" ? ' Please Enter Display Name  ' : this.state.errors.displayName;
      this.setState(prevState => ({
        errors: {                              // object that we want to update
          ...prevState.errors,                 // keep all other key-value pairs
          displayName: err                    // update the value of specific key                                                      
        },
      }));
      return false;
    }
    if (records.control == undefined || records.control == '') {
      this.setState(prevState => ({
        errors: {                                   // object that we want to update
          ...prevState.errors,                        // keep all other key-value pairs
          control: ' Please Select Control Name '     // update the value of specific key
        },

      }));
      return false;
    }
    if (records.Applie_To == undefined || records.Applie_To == '') {
      this.setState(prevState => ({
        errors: {                               // object that we want to update
          ...prevState.errors,                     // keep all other key-value pairs
          group: ' Please Select Group Name '      // update the value of specific key
        },
      }));
      return false;
    }
    return true;
  };

  resetOn_Click = (e) => {
    // e.preventDefault();
    this.setState({
      newColumnData: {
        shortName: '',
        displayName: '',
        control: '',
        Applie_To: ''
      },
      errors: {
        shortName: '',
        displayName: '',
        control: '',
        group: ''
      }
    })

    if (this.state.editColumnFlag) {
      this.setState(prev => ({
        editdetails: {
          ...prev.editdetails,
          shortName: "",
          displayName: "",
          control: "",
          Applie_To: ""
        }
      }))
    }
    this.controlSelect.current.clearValue();
    this.groupSelect.current.clearValue();
  };

  deleteColumnOpen = (event) => {
    this.setState({
      deleteColumnFlag: true,
      deleteData: event.data
    })
  };

  deleteColumnClose = () => {
    this.setState({
      deleteColumnFlag: false
    })
  };

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  backToMainScreen = (event) => {
    this.setState({
      fieldColumnFlag: true,
      addColumnsFlag: false,
      deleteColumnFlag: false,
      editColumnFlag: false,
      navPath: ['Columns']
    })
    this.LoadColumnGrid();
  };

  render() {
    return (
      <AuthCommonLayout>
        <div >
          <div className='screenHeader'>
            <ComponentHeader
              isSearchable={this.state.fieldColumnFlag}
              path={this.state.navPath}
              backToParentClass={this.backToMainScreen}
              onFilterTextBoxChanged={this.onFilterTextBoxChanged}
            />
          </div>

          <div className='screenBody'>
            {this.state.fieldColumnFlag &&
              <div >
                <div id='CustomAgGrid'>
                  <CustomAgGrid
                    rowData={this.state.rowData}
                    columnDefs={this.state.columnDefs}
                    onGridReady={this.onGridReady}
                    filterValue={this.state.filterValue}
                  />
                </div>
                <div className="plus-animate font-roboto ">
                  <div class="btnGroup btnContainer">
                    <div class="btnGroup btnContent">
                      <p class="group inline-block" onClick={this.addExcelColumnOpen}>
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                          width="34" height="34"
                          viewBox="0 0 48 48">
                          <path fill="#4CAF50" d="M41,10H25v28h16c0.553,0,1-0.447,1-1V11C42,10.447,41.553,10,41,10z"></path><path fill="#FFF" d="M32 15H39V18H32zM32 25H39V28H32zM32 30H39V33H32zM32 20H39V23H32zM25 15H30V18H25zM25 25H30V28H25zM25 30H30V33H25zM25 20H30V23H25z"></path><path fill="#2E7D32" d="M27 42L6 38 6 10 27 6z"></path><path fill="#FFF" d="M19.129,31l-2.411-4.561c-0.092-0.171-0.186-0.483-0.284-0.938h-0.037c-0.046,0.215-0.154,0.541-0.324,0.979L13.652,31H9.895l4.462-7.001L10.274,17h3.837l2.001,4.196c0.156,0.331,0.296,0.725,0.42,1.179h0.04c0.078-0.271,0.224-0.68,0.439-1.22L19.237,17h3.515l-4.199,6.939l4.316,7.059h-3.74V31z"></path>
                        </svg>
                        <span class="hidden group-hover:block absolute bg-gray-900 text-white text-xs rounded-lg py-2 px-3 -ml-36">Excel Import</span>
                      </p>
                      <p class="group inline-block" onClick={this.addManualColumnOpen}>
                        {/* <img src={ManualIcon} width={32} height={32} alt='Manual Icon' /> */}
                        <TbKeyboard size={26} color='#000' />
                        <span class="hidden group-hover:block absolute bg-gray-900 text-white text-xs rounded-lg py-2 px-3 -ml-40">Manual Entry</span>
                      </p>
                    </div>
                    <div class="btnGroup btn">
                      <p>+</p>
                    </div>
                  </div>
                </div>

              </div>

            }

            {this.state.addColumnsFlag || this.state.editColumnFlag ?
              <div id="Fields_ColumnsForm">
                {this.state.addColumnsFlag ?
                  <AddFields_Columnss
                    addExcelColFlag={this.state.addExcelColFlag}
                    groupselect={this.state.groupselect}
                    addColumn_OnChange={this.addColumn_OnChange}
                    addColumn_OnClick={this.addColumn_OnClick}
                    resetOn_Click={this.resetOn_Click}
                    errors={this.state.errors}
                    newColumnData={this.state.newColumnData}
                    controlSelect={this.controlSelect}
                    groupSelect={this.groupSelect}
                  />
                  :
                  <EditFields_Columnss
                    groupselect={this.state.groupselect}
                    columnEditData={this.state.editdetails}
                    editColumn_OnChange={this.editColumn_OnChange}
                    editColumns_OnClick={this.editColumns_OnClick}
                    resetOn_Click={this.resetOn_Click}
                    errors={this.state.errors}
                    controlSelect={this.controlSelect}
                    groupSelect={this.groupSelect}
                  />
                }
              </div>
              : null}

            {this.state.deleteColumnFlag &&
              <div>
                <ReactDialogBox
                  closeBox={this.deleteColumnClose}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  // bodyHeight='150px'
                  headerText='Delete Column'
                >
                  <div>
                    <div class='flex  items-center h-16 pl-7'>
                      <h1>{localConstant.FIELD_COLUMNS.DELETE_COLUMN_CONTENT} <span class='text-delete-user-text'>{this.state.deleteData["displayName"]}</span>?</h1>
                    </div>
                    <div class="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary}
                        onClick={this.deleteColumnOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary}
                        onClick={this.deleteColumnClose}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
            }
            <ToastContainer limit={2} autoClose={2000} />
          </div>

        </div>
      </AuthCommonLayout>
    )
  }
}

export default Fields_Columns;