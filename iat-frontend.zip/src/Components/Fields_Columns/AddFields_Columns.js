import { MdCloudUpload } from "react-icons/md";
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import { VscWarning } from "react-icons/vsc";
import noFileSelected from '../../Images/Nofile.png';
import { useState } from "react";
import { read, utils } from "xlsx";
import { toast } from "react-toastify";
import ColumnServices from "../../Services/ColumnServices";
import { InsetBulkColumn } from "../../CommonUtils/UtilColumn";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { BrowserView, MobileView, isBrowser, isMobile } from 'react-device-detect';

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();
var CreateSettings = [{ MasterBizUitKey: window.localStorage.getItem("MasterBizUitKey"), Name: '', value1: '', value2: '', Description: '', status: true }];
var FieldOptions = [{ label: 'Text', value: 'Text' }, { label: 'List', value: 'List' }]

//SCREEN ID -3024
const AddFields_Columns = (props) => {
    const [fileStatus, setFileStatus] = useState(false)
    const [selecFileName, setFileName] = useState()
    const [counts, setcounts] = useState({ valids: 0, invalids: 0, total: 0 })
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;

    const toPercentage = (row) => {
        const total = counts.total;
        let result = Math.round((row / total) * 100) //.toFixed(2);
        if (isNaN(result)) {
            return 0;
        }
        return result;
    };

    const onHandleClick = (event) => {
        event.target.value = null;
        setFileName('')
        setcounts({
            ...counts,
            valids: 0,
            invalids: 0,
            total: 0
        });
        window.addEventListener('focus', handleFocusBack);
    };

    const handleFocusBack = () => {
        setFileStatus(false)
        window.removeEventListener('focus', handleFocusBack);
    };

    //Added by rajesh to handle Drag files anfd Browse file and validate to and insert into column and transaction Table
    const handleImport = ($event) => {
        $event.preventDefault();
        // to restric other file types except excel files
        const isDrop = $event.type + "".toLowerCase() === "drop";
        const files = isDrop ? $event.dataTransfer.files : $event.target.files;
        const file = isDrop ? $event.dataTransfer.files[0] : $event.target.files[0];
        const fileName = isDrop ? $event.dataTransfer.files[0].name : $event.target.files[0].name;
        // console.log(" file", files, " fileName", fileName)
        if (!(file.type === 'application/vnd.ms-excel' || file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
            toast.error('Invalid File Type!');
            return;
        }
        setFileStatus(true);
        window.removeEventListener('focus', handleFocusBack); // to find when click cancel or X fialog of file browse
        if (files.length) {
            const file = files[0];
            const reader = new FileReader();
            reader.onload = ($event) => {
                const wb = read($event.target.result);
                const sheets = wb.SheetNames;
                if (sheets.length > 0) {
                    const rows = utils.sheet_to_json(wb.Sheets[sheets[0]]);
                    let tempAllTransData = [];
                    let ValidDatas = [];
                    rows.map((item) => {
                        let Columns = { shortName: "", displayName: "", control: "", Applie_To: "", mode: "", value: "", status: "", updatedBy: "", bizunit_gkey: "" };
                        let rowDummy;
                        Columns.shortName = item["Label"] == undefined ? (rowDummy = "N/A") : item["Label"];
                        Columns.displayName = item["Display Name"] == undefined ? (rowDummy = "N/A") : item["Display Name"];
                        Columns.control = item["Control"] == undefined ? (rowDummy = "N/A") : item["Control"];
                        Columns.Applie_To = item["Group"] == undefined ? (rowDummy = "N/A") : GetStreamsGkeyByName(item["Group"]) == undefined ? (rowDummy = "N/A") : GetStreamsGkeyByName(item["Group"])["value"];
                        Columns.mode = "Browse";
                        Columns.value = "N/A";
                        Columns.status = rowDummy == undefined ? "success" : "failed";
                        Columns.updatedBy = window.localStorage.getItem("LoginUserName");
                        Columns.bizunit_gkey = window.localStorage.getItem("MasterBizUitKey");

                        if (!rowDummy) {
                            ValidDatas.push(Columns);
                        }
                        tempAllTransData.push(Columns);
                    });
                    //insert valid column data into field columns
                    if (ValidDatas.length > 0) {
                        // console.log("Valid Records", ValidDatas);
                        InsetBulkColumn(ValidDatas);
                    }
                    if (tempAllTransData.length > 0) {
                        //insert all excel data into transaction table(valid and invalid)
                        ExportTransactionColumnByOrg(tempAllTransData);
                    }
                    // console.log("all excel trans records ", tempAllTransData);
                    setcounts({
                        ...counts,
                        valids: ValidDatas.length,
                        invalids: tempAllTransData.length - ValidDatas.length,
                        total: tempAllTransData.length
                    });
                }
            }
            setFileName(fileName)
            reader.readAsArrayBuffer(file);
        }
    };

    function GetStreamsGkeyByName(StreamName) {
        let StreamKey = props.groupselect.find((product) => product.label === StreamName);
        return StreamKey;
    };

    async function ExportTransactionColumnByOrg(tempAllTransData) {
        try {
            // console.log('tempAllTransData :', (tempAllTransData))
            const response = await ColumnServices.ExportTransactionColumnByOrg(tempAllTransData);
            if (response.status === 200 || response.status === 201) {
                toast.success("Transaction added successfully")
            }
        } catch (error) {
            console.error(error);
            toast.error("An error occurred while adding transaction");
        }
    };

    return (

        <div>
            {props.addExcelColFlag ?
                <div class="flex  bg-white bg-opacity-60">
                    <div class="extraOutline  bg-white w-full  bg-whtie rounded-lg">
                        <div class="flex max-lg:flex-col mx-10  max-lg:mx-4 max-lg:pr-4">
                            <div onDrop={handleImport} onDragOver={(e) => { e.preventDefault() }} class=" w-1/2 m-10 max-lg:w-full max-lg:m-4 min-h-[200px]  max-lg:h-[100px] p-10 max-lg:p-4 h-[50vh] flex flex-col items-center justify-center max-lg:justify-center file_upload box bg-gray-50  border-[5px]  border-dashed  border-gray-300 rounded-2xl">
                                <div class="flex justify-center">
                                    <BrowserView><MdCloudUpload size={60} color="#00e2e9" /></BrowserView>
                                    <MobileView><MdCloudUpload size={30} color="#00e2e9" /></MobileView>
                                </div>
                                <div class="input_field flex flex-col text-center" >
                                    <div class="title text-indigo-500 text-2xl  max-lg:text-mob-txt-sm">{localConstant.FIELD_COLUMNS.DRAG_UPLOAD} <div class="text-lg max-lg:text-mob-txt-sm8px">Or</div> </div>
                                    <label>
                                        <input
                                            class="text-sm cursor-pointer w-36 max-lg:w-12 hidden" type="file" multiple
                                            onChange={handleImport}
                                            onClick={onHandleClick}
                                            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                        />
                                        <div class="text  text-[#00e2e9] border-[2px] border-[#00e2e9] rounded-lg font-semibold max-lg:text-mob-txt-sm8px max-lg:px-0 cursor-pointer  p-1 px-3 hover:bg-[#00e2e9] hover:text-[#fff]">{localConstant.FIELD_COLUMNS.BROWSE}</div>
                                    </label>
                                    <span class="text-gray-300 text-sm max-lg:text-mob-txt-sm8px">{localConstant.FIELD_COLUMNS.SUPPORT_FILETYPE}<span class="text-gray-500  text-xs max-lg:text-mob-txt-sm8px">{localConstant.FIELD_COLUMNS.FILE_FORMAT}</span></span>
                                </div>
                            </div>
                            <div class=" Progress w-1/2 m-10  max-lg:w-full max-lg:m-1 max-lg:py-4">
                                {fileStatus ?
                                    <div className="flex flex-col justify-around h-full">
                                        <h1 class='text-lg max-lg:text-mob-txt-sm font-semibold text-center text-green-400'><span className=" text-black">{localConstant.FIELD_COLUMNS.FILE_CHOSEN} </span> {selecFileName}</h1>
                                        <h1 class='text-lg  max-lg:text-mob-txt-sm font-semibold text-center '>{localConstant.FIELD_COLUMNS.TOTAL_RECORDS} {counts.total}</h1>
                                        <div className="w-full  pb-14 space-y-6">
                                            <div>
                                                <div id="validBar" class="flex items-end max-lg:justify-start justify-between mb-1 text-base font-medium max-lg:text-mob-txt-sm">
                                                    <div class="flex items-center space-x-2">
                                                        <IoMdCheckmarkCircleOutline size={20} color="#00e2e9" />
                                                        <h3 class=" max-lg:text-mob-txt-sm8px">{localConstant.FIELD_COLUMNS.VALID_RECORDS}</h3>
                                                    </div>
                                                    <div class="text-right text-sm font-medium pr-2 max-lg:text-mob-txt-sm8px">
                                                        {counts.valids + " Of " + counts.total}
                                                    </div>
                                                </div>
                                                <div class="flex ml-6 w-9/10 max-lg:ml-3 max-lg:h-2 h-4 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700">
                                                    <div class="flex flex-col justify-center overflow-hidden bg-[#00e2e9] ease-linear  duration-500 text-xs text-white text-center" style={{ width: toPercentage(counts.valids) + "%" }} >{toPercentage(counts.valids)}%</div>
                                                </div>
                                            </div>
                                            <div>
                                                <div id="inValidBar" class="flex items-end justify-between mb-1 text-base font-medium max-lg:text-mob-txt-sm">
                                                    <div class="flex items-center space-x-2">
                                                        <VscWarning size={20} color="#f0004d" />
                                                        <h3 class=" max-lg:text-mob-txt-sm8px">{localConstant.FIELD_COLUMNS.INVALID_RECORDS}</h3>
                                                    </div>
                                                    <div class="text-right text-sm font-medium pr-2 max-lg:text-mob-txt-sm8px">
                                                        {counts.invalids + " Of " + counts.total}
                                                    </div>
                                                </div>
                                                <div class="flex ml-6 w-9/10 h-4 max-lg:ml-3  max-lg:h-2 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700">
                                                    <div class="flex flex-col justify-center overflow-hidden bg-[#f0004d] ease-linear duration-500 text-xs text-white text-center" style={{ width: toPercentage(counts.invalids) + "%" }} >{toPercentage(counts.invalids)}%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    :
                                    <ul id="No_File_Selected" class="flex flex-1 flex-wrap -m-1 justify-center">
                                        <li id="empty" class="h-full w-full text-center flex flex-col justify-center items-center">
                                            <img class="mx-auto w-64 max-lg:w-32" src={noFileSelected} alt="no data" />
                                            <span class="text-small text-gray-500 max-lg:text-mob-txt-sm">{localConstant.FIELD_COLUMNS.NO_FILE_SELECTED}</span>
                                        </li>
                                    </ul>
                                }
                            </div>
                        </div>
                    </div>
                </div>
                :
                <div class="AddManualColumn mt-5 ml-5 ">
                    {/* RESPONSIVE START */}
                    <form class="w-full max-w-sm  max-lg:max-w-sm">
                        <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                            <div class="md:w-1/3">
                                <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                                    {localConstant.FIELD_COLUMNS.LABEL}
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <input
                                    class={props.errors.shortName.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                                    type="text"
                                    placeholder="Enter value"
                                    name="shortName"
                                    onChange={props.addColumn_OnChange}
                                    value={props.newColumnData == undefined ? "" : props.newColumnData.shortName}
                                />
                                {props.errors.shortName.length > 0 ?
                                    <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.shortName}</span>
                                    : null}
                            </div>
                        </div>

                        <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                            <div class="md:w-1/3">
                                <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                                    {localConstant.FIELD_COLUMNS.DISPLAY_NAME}
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <input
                                    class={props.errors.displayName.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                                    type="text"
                                    placeholder="Enter setting name"
                                    name="displayName"
                                    value={props.newColumnData == undefined ? "" : props.newColumnData.displayName}
                                    onChange={props.addColumn_OnChange}
                                />
                                {props.errors.displayName.length > 0 ?
                                    <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.displayName}</span>
                                    : null}
                            </div>
                        </div>

                        <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                            <div class="md:w-1/3">
                                <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                                    {localConstant.FIELD_COLUMNS.CONTROL}
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <Select
                                    ref={props.controlSelect}
                                    onChange={props.addColumn_OnChange}
                                    name="control"
                                    options={FieldOptions}
                                    styles={props.errors.control.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                                />
                                {props.errors.control.length > 0 ?
                                    <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.control}</span>
                                    : null}
                            </div>
                        </div>
                        <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                            <div class="md:w-1/3">
                                <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                                    {localConstant.FIELD_COLUMNS.GROUP}
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <Select
                                    name="Applie_To"
                                    ref={props.groupSelect}
                                    onChange={props.addColumn_OnChange}
                                    options={props.groupselect}
                                    styles={props.errors.group.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                                />
                                {props.errors.group.length > 0 ?
                                    <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.group}</span>
                                    : null}
                            </div>
                        </div>
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={(e) => props.addColumn_OnClick(e)}>{localConstant.COMMON_CONST.ADD}</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                        </div>
                    </form>
                    {/* RESPONSIVE END */}
                </div>
            }
        </div>
    )
}
export default AddFields_Columns;