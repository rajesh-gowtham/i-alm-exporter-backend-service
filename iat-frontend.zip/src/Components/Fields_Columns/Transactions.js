import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'react-js-dialog-box/dist/index.css';
import ColumnServices from '../../Services/ColumnServices';
import Transaction_Records from './Transaction_Records';
import '../../CSS/Model.css';
import _, { chain } from 'lodash'
import { getlocalizeData, getControlsConstants, } from "../../CommonUtils/getlocalizeData";
import moment from 'moment/moment';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//Manual / Browse Mode Only Added By Mubarak Ali
//SCREEN ID -3066
class Transactions extends React.Component {
  constructor() {
    super()
    this.state = {
      transactionFlag: true,
      GroupColumnData: [],
      StreamData: [],
      GroupData: [],
      rowIndex: 0,
      invalidData: [],
      navPath:['Transactions'],
      columnDefs: [
        // {
        //   field: 'Id', minWidth: 120, flex: 1, suppressMovable: true, headerName: 'ID', cellClass: "ag-center-cell",
        //   cellRenderer: (params) => {
        //     const id = `35100${params.rowIndex + 1}`.slice(-7);
        //     return <span className=' text-blue-600 cursor-pointer' onClick={() => this.transDetailsOnClick(params.data, params)}> {id}</span>
        //   },
        // },
        { field: 'user', minWidth: 150, flex: 2, suppressMovable: true, headerName: 'Uploaded By', cellClass: "ag-center-cell" },
        {
          field: 'createdAt', minWidth: 150, flex: 2, suppressMovable: true, headerName: 'Uploaded Date',
          cellRenderer: (params) => {
            let DateandTime = params.data.createdAt;
            // const date = moment(DateandTime).format('YYYY-MM-DD HH:MM:ss')
            const date = moment.utc(DateandTime).local().format("YYYY MM DD, HH:mm:ss")
            return (
              <div className='flex  text-xs items-center  h-full'>
                <span className='text-[13px] font-semibold mr-2'>{date}</span>
              </div>
            )
          }
        },
        {
          field: 'status', headerName: 'Status', minWidth: 100, suppressMovable: true, flex: 1, cellClass: "ag-center-cell",
          cellRenderer: (params) => {
            if (params.value == 'success') {
              return <span class="text-[#13bf1b] text-center font-semibold text-sm ">SUCCESS</span>;
            }
            else {
              return <span class="text-[#f33819]  text-sm font-semibold ">FAILED</span>;
            }
          }
        },
        {
          headerName: "Notes", minWidth: 150, suppressMovable: true, flex: 1,
          cellRenderer: (params) => {
            return (
              <div className='flex  items-center h-full'>
                <span className='hover:underline hover:underline-offset-2 py-2 text-blue-600 text-xs font-semibold whitespace-normal text-center' onClick={() => this.transDetailsOnClick(params.data, params)}> Click here for more details..</span>
              </div>
            )
          }
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: '',
    };
  };

  componentDidMount() {
    this.GroupColumnGrid();
  };

  async GroupColumnGrid() {
    try {
      const response = await ColumnServices.GetTransactionColumnsByOrg();
      let ColumnsData = response.data;
      for (var i = 0; i < ColumnsData.length; i++) {
        if (ColumnsData[i]["shortName"] == "N/A") {
          ColumnsData[i]["shortName"] = "";
        }
        if (ColumnsData[i]["displayName"] == "N/A") {
          ColumnsData[i]["displayName"] = "";
        }
        if (ColumnsData[i]["control"] == "N/A") {
          ColumnsData[i]["control"] = "";
        }
      }
      // console.log("ColumnsData  >>>><<<<>: ", (ColumnsData))
      //added by rajesh
      //for Creating rowData for transaction history {user:"name" , status:"error" , 2023-04-25T09:59:09.804Z:[{allrecords}]}
      const tempGridData = chain(ColumnsData).groupBy("createdAt")
        .map(data => ({
          user: data[0].updatedBy,
          status: data.find(obj => obj.status === "failed") ? "failed" : "success",
          createdAt: data[0].createdAt,
          [data[0].createdAt]: data.map(({ order, ...o }) => o)
        }))
        .value();
      // console.log("tempGridData ", tempGridData);
      this.setState({
        rowData: tempGridData,
      })
    } catch (error) {
      console.log(error);
      // Handle error here
    }
  };

  // add by nagarasu
  transDetailsOnClick = (data, param) => {
    let tempInValidDataRecords = [];
    console.log('Clicked Det ', data[data.createdAt])
    data[data.createdAt].map((item, index) => {
      if (data[data.createdAt][index]['status'] == 'failed')
        tempInValidDataRecords.push(data[data.createdAt][index]);
    }
    )
    this.setState({
      transactionFlag: !this.state.transactionFlag,
      GroupColumnData: data[data.createdAt],
      rowIndex: (param.rowIndex + 1),
      invalidData: tempInValidDataRecords,
      navPath:['Transactions','Transaction Records'],
    })
  };

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  addButtonsReveal = () => {
    this.setState({
      addColumnbutton: !this.state.addColumnbutton
    })
  };

  backToMainScreen = () => {
    this.setState({
      transactionFlag: !this.state.transactionFlag,
      navPath:['Transactions']
    })
    this.GroupColumnGrid();
  };

  render() {
    return (
        <AuthCommonLayout>
          <div>
            <div className='screenHeader'>
              <ComponentHeader
                isSearchable={this.state.transactionFlag}
                path={this.state.navPath}
                backToParentClass={this.backToMainScreen}
                onFilterTextBoxChanged={this.onFilterTextBoxChanged}
              />
            </div>
            <div className='screenBody'>
              {this.state.transactionFlag ?
                <div id='CustomAgGrid'>
                  <CustomAgGrid
                    rowData={this.state.rowData}
                    columnDefs={this.state.columnDefs}
                    onGridReady={this.onGridReady}
                    filterValue={this.state.filterValue}
                  />
                </div>
                :
                <Transaction_Records
                  RowData={this.state.GroupColumnData}
                  selectedRowIndex={this.state.rowIndex}
                  inValidData={this.state.invalidData}
                  transactionBackClick={this.backToMainScreen}
                />
              }
            </div>
          </div>
          <ToastContainer limit={2} autoClose={3000} />
        </AuthCommonLayout>
    )
  }
}
export default Transactions;






