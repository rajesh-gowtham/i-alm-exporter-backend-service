import React, {useState}from "react";
import igologo from '../../Images/igologo.png';
import '../../CSS/LandingPage.css';
import { LandingConstants } from "../../Constants/LandingConstants";

//SCREEN ID -3016
const Header = () => {
  const [showMenu, setShowMenu] = useState(false);
  return (
    <div class="min-h-[10vh]  z-10 py-2 container flex flex-wrap items-center justify-between mx-auto">
      <a href="/" class="flex items-center">
        <img src={igologo} class="max-lg:h-10 max-lg:w-18 max-lg:pl-2 h-12 w-18" />
      </a>
      <button onClick={()=> setShowMenu(!showMenu)} data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 ml-3 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
        <span class="sr-only">Open main menu</span>
        <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
      </button>
      <div class={`${ showMenu? 'block': 'hidden'} w-full md:block md:w-auto`} id="navbar-default">
        <ul class="flex items-center justify-center flex-col  border border-gray-100 rounded-lg md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md: dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
          <li>
            <a href="/" class="font-display max-w-sm text-lg leading-tight px-3 ">
              <span class="ease-in delay-100 font-teko hover:text-orange-500 duration-300 uppercase text-[#1f52a3] link-underline link-underline-black">{LandingConstants.NAVBAR.HOME}</span>
            </a>
          </li>
          <li>
            <a href="/About" class="font-display max-w-sm text-lg  leading-tight px-3">
              <span class=" ease-in delay-100 font-teko hover:text-orange-500 duration-300 uppercase text-[#1f52a3] link-underline link-underline-black font-medium ">{LandingConstants.NAVBAR.ABOUT}</span>
            </a>
          </li>
          <li>
            <a href="/login" class="font-display max-w-sm text-lg  leading-tight px-3">
              <span class="ease-in delay-100 font-teko hover:text-orange-500 duration-300 uppercase text-[#1f52a3] link-underline link-underline-black">{LandingConstants.NAVBAR.SIGN_IN}</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  )
}
export default Header;