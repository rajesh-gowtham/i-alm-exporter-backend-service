import React from "react";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";

const localConstants = getlocalizeData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3067
const EditPrivilegeForm = (props) => {
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    return (
            <div className="mt-3">
                <form class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg">
                    <div class="grow-1 d-inline-block position-relative mb-3">
                        <label for="firstName" class={ControlsConstants.label.label14}>{localConstants.PRIVILEGES.PRIVILEGE_NAME}</label><br />
                        <input
                            class={props.error.length > 0 ? borderRed : borderGrey}
                            type="text"
                            placeholder="Enter privilege name"
                            name="Privilege_Name"
                            value={props.privilegeData.Privilege_Name}
                            onChange={props.editPrivilegeOnChange}
                        />
                        {props.error.length > 0 &&
                            <span class='text-error-red text-[11px]'>{props.error}</span>
                        }
                    </div>
                    <div class="grow-1 d-inline-block position-relative mb-3">
                        <label for="module" class={ControlsConstants.label.label14}>{localConstants.PRIVILEGES.MODULE}</label><br />
                        <input
                            class={borderGrey}
                            type="text"
                            placeholder="Enter module name"
                            name="module_name"
                            value={props.privilegeData.module_name}
                            disabled
                            onChange={props.editPrivilegeOnChange}
                        />
                    </div>
                    <div class="flex items-center space-x-3 py-2 max-lg:justify-center justify-end border-t border-footer-border rounded-b-md">
                        <button type="submit" class={ControlsConstants.Buttons.btnPrimary} onClick={(e) => props.editPrivilegeOn_Click(e)}>{localConstants.COMMON_CONST.UPDATE}</button>
                        <button type="submit" class={ControlsConstants.Buttons.btnSecondary} onClick={(e) => props.resetOn_Click(e)} >{localConstants.COMMON_CONST.RESET}</button>
                    </div>
                </form>
            </div>
    )
};

export default EditPrivilegeForm;