import React from "react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { AgGridReact } from 'ag-grid-react';
import Store from "../../Redux/Store";
import '../../CSS/AgGrid.css';
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { HiOutlineSearch } from "react-icons/hi";
import { GridConstants } from "../../Constants/GridConstants";

const localControlsConstant = getControlsConstants();
const gridLocalConstants = GridConstants.AGGrid.Secondary_Grid;
// never changes, so we can use useMemo

//SCREEN ID -3013
class ManagePrivilages extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      roleDetails: props.role,
      rowData: Store.getState().allPrivileges,
      columnDefs: [
        {
          field: 'Privilege_Name', headerName: 'Privilege', suppressMovable: true, minWidth: 150, flex: 1, headerCheckboxSelectionFilteredOnly: true, headerCheckboxSelection: true,
          checkboxSelection: true,
          filterParams: {
            applyMiniFilterWhileTyping: true,
          },
        },
        { field: 'module_name', headerName: 'Module', suppressMovable: true, minWidth: 150, flex: 1, },
      ],
    }
  };

  componentDidMount() {
    this.GetPrivilegesByOrg()
  };

  GetPrivilegesByOrg = async () => {
    try {
      // const privilagesdata = await GetAllPrivilages();
      // console.log('returnData', privilagesdata);
      // Do something with the privilagesdata array 
      this.setState({
        rowData: Store.getState().allPrivileges,
      })
    } catch (error) {
      console.error(error);
      // Handle the error 
    }
  };

  //function call from parent class( Roles Details ) to update and add privileges 
  getSelectedRowData = () => {
    let selectedData = this.gridApi.getSelectedRows(),
      role = this.state.roleDetails;
    return [selectedData, role];
  };

  onFilterTextBoxChanged = () => {
    this.gridApi.setQuickFilter(
      document.getElementById('filter-text-box').value
    );
    let showRowCount = this.gridApi.getDisplayedRowCount()

    if (showRowCount === 0) {
      this.gridApi.showNoRowsOverlay();
      document.querySelector('#noMatchData').innerHTML = 'No matching records found!';
    } else {
      this.gridApi.hideOverlay();
    }
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    //---> Code for select default checked items  using id \
    let privilegsDatas = Store.getState().privilegedata.privilege[this.state.roleDetails.name];
    let privilegesId = [];
    // select the default values 
    privilegsDatas.map(item => { privilegesId.push(item.gkey) });
    console.log('privilegsDatas.map(item => { privilegesId.push(item.gkey) });',privilegsDatas.map(item => { privilegesId.push(item.gkey) }))
    this.gridApi.forEachLeafNode((node) => {
      if (privilegesId.includes(node.data.gkey)) {
        node.setSelected(true);
      }
    });
  };

  // getRowStyle = params => {
  //   if (params.node.rowIndex % 2 === 0) {
  //       return { background: 'white' };
  //   }else{
  //       return { background: '#fafafa' };
  //   }
  // };

  render() {
    return (
      <div class="p-4   bg-[#ebeef6]">
        <div class='flex justify-between mb-1'>
          <h1 class="text-page-header-2xl text-page-header  pb-1 font-bold"></h1>
          <div id="manage-priv-search">
            <div class="relative max-w-[200px] flex items-center  h-8 rounded-lg  bg-white overflow-hidden">
              <div class="grid place-items-center h-full w-12 text-search-text">
                <HiOutlineSearch size={localControlsConstant.Icon.search.size} />
              </div>
              <input
                id="filter-text-box"
                onInput={this.onFilterTextBoxChanged}
                class="peer text-search-text bg-white h-full w-full  outline-none text-search-text-size placeholder-search-text  pr-2"
                type="text"
                placeholder="Search..." />
            </div>
          </div>
        </div>
        <div className='bg-white rounded'>
          <div className="ag-theme-alpine h-[45vh] p-4 rounded" Id="secondaryGridBorder"  >
            <AgGridReact
              rowData={this.state.rowData}
              columnDefs={this.state.columnDefs}
              defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
              animateRows="true"
              groupDisplayType={'multipleColumns'}
              rowSelection={"multiple"}
              onGridReady={this.onGridReady}
              // getRowStyle={this.getRowStyle}
              cacheQuickFilter={true}
              headerHeight={35}
              rowHeight={35}
              gridOptions={gridLocalConstants.gridOptions}
              suppressRowClickSelection={true}
              suppressRowHoverHighlight={true}
               overlayNoRowsTemplate={'<span id="noMatchData" class="ag-overlay-loading-center "> No Records Found ! </span>'}
              overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
            />
          </div>
        </div>
      </div>
    );
  }
}
export default ManagePrivilages;