import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
var FieldOptions = [{ label: 'Text', value: 'Text' }, { label: 'List', value: 'List' }];

//SCREEN ID -3028
const AddAUTReferenceSystem = (props) => {
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    return (
        <div className="mt-5">
            {/* <div class='flex justify-center mb-5 w-full max-w-sm max-lg:max-w-sm'>
                <h1 class={localControlsConstant.Responsive.textboxResponsive.text_header}>{localConstant.AUT_REFERENCE.ADD_REFERENCE}</h1>
            </div> */}
            {/* RESPONSIVE START */}
            <form class="w-full max-w-sm  max-lg:max-w-sm">
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.AUT_REFERENCE.IDENTIFIER}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.Value.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            id="inline-full-name" type="text"
                            placeholder="Enter Identifier"
                            name="Value"
                            value={props.newAUTRefData == undefined ? "" : props.newAUTRefData.Value}
                            onChange={props.addAUTRefOnChange}
                        />
                        {props.errors.Value.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.Value}</span>
                        }
                    </div>
                </div>
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-password">
                            {localConstant.AUT_REFERENCE.TYPE}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <Select
                            onChange={props.addAUTRefOnChange}
                            name="type"
                            ref={props.typeSelect}
                            options={FieldOptions}
                            styles={props.errors.type.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                        />
                        {props.errors.type.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.type}</span>
                        }
                    </div>
                </div>
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.AUT_REFERENCE.DESCRIPTION}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <textarea
                            class={localControlsConstant.Responsive.textboxResponsive.textarea}
                            type="textarea"
                            placeholder="Enter Description"
                            name="description"
                            value={props.newAUTRefData == undefined ? "" : props.newAUTRefData.description}
                            onChange={props.addAUTRefOnChange}
                        />
                    </div>
                </div>
                <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                        onClick={(e) => props.addAUTRefOn_Click(e)}>{localConstant.COMMON_CONST.ADD}</button>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                        onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                </div>
            </form>
            {/* RESPONSIVE END */}
        </div>
    )
}
export default AddAUTReferenceSystem;

