import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
var ControlOptions = [{ label: 'Text', value: 'Text' }, { label: 'List', value: 'List' }];

//SCREEN ID -3026
const EditAUTReferenceSystem = (props) => {
    const dropDownStylesRed = localControlsConstant.Select.dropDownStylesRed;
    const dropDownStylesGrey = localControlsConstant.Select.dropDownStyles;
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    return (
        <div className="mt-5">
            {/* <div class='flex justify-center mb-5 w-full max-w-sm  max-lg:max-w-sm'>
                <h1 class={localControlsConstant.Responsive.textboxResponsive.text_header}>{localConstant.AUT_REFERENCE.EDIT_REFERENCE}({props.editRefData.gkey.toString().substring(0, 7)})</h1>
            </div> */}

            {/* RESPONSIVE START */}
            <form class="w-full max-w-sm  max-lg:max-w-sm">
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.AUT_REFERENCE.IDENTIFIER}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.Value.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter Identifier "
                            name="Value"
                            value={props.editRefData.Value}
                            onChange={props.editRefOn_Change}
                        />
                        {props.errors.Value.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.Value}</span>
                        }
                    </div>
                </div>
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-password">
                            {localConstant.AUT_REFERENCE.TYPE}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <Select
                            options={ControlOptions}
                            styles={props.errors.type.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                            name="type"
                            value={{ label: props.editRefData.type, value: props.editRefData.type }}
                            onChange={props.editRefOn_Change}
                            ref={props.typeSelect}
                        />
                        {props.errors.type.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.type}</span>
                        }
                    </div>
                </div>
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.AUT_REFERENCE.DESCRIPTION}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <textarea
                            class={localControlsConstant.Responsive.textboxResponsive.textarea}
                            type="textarea"
                            name="description"
                            placeholder='Enter Description '
                            value={props.editRefData.description}
                            onChange={props.editRefOn_Change}
                        />
                    </div>
                </div>
                <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                        onClick={(e) => props.editRefOn_Click(e)}>{localConstant.COMMON_CONST.UPDATE}</button>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                        onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                </div>
            </form>
            {/* RESPONSIVE END */}

        </div>
    )
}
export default EditAUTReferenceSystem;

