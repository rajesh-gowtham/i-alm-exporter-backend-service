import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { HiPlus } from 'react-icons/hi';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ReferenceService from '../../Services/ReferenceService';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import EditAUTReferenceSystem from './EditAUTReferenceSystem';
import AddAUTReferenceSystem from './AddAUTReferenceSystem';
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3027
class AUTReferenceSystem extends React.Component {
  constructor() {
    super()
    this.state = {
      AUTRefFormFlag: true,
      addAUTRefFormFlag: false,
      editAUTRefFormFlag: false,
      deleteAUTRefFormFlag: false,
      selecteddeleteindex: 0,
      editdetails: '',
      newAUTRefData: {},
      navPath: ['Reference and system'],
      errors: {
        Value: '',
        type: ''
      },
      columnDefs: [
        // {
        //   headerName: "ID", field: "gkey", suppressMovable: true, minWidth: 100, flex: 1,
        //   cellRenderer: (params) => {
        //     const id = `300${params.rowIndex + 1}`.slice(-4);
        //     return <span className=' text-blue-600 cursor-pointer' onClick={(e) => this.add_edit_AUTRefOpen(e,params)}> {'R' + id}</span>
        //   }
        // },
        {
          headerName: "Identifier", field: "Value", suppressMovable: true, minWidth: 120, flex: 2,
          cellRenderer: (params) => {
            return <span className=' text-blue-600 cursor-pointer' onClick={(e) => this.add_edit_AUTRefOpen(e, params)}> {params.value}</span>
          }
        },
        { headerName: "Type", field: "type", suppressMovable: true, minWidth: 100, flex: 2, },
        { headerName: "Description", field: "description", suppressMovable: true, minWidth: 120, flex: 2, },
        {
          headerName: "Action", field: "Active", suppressMovable: true, minWidth: 100, flex: 1,
          cellRendererFramework: (params) =>
            <div class='flex w-full h-full items-center space-x-4'>
              <button onClick={(e) => this.add_edit_AUTRefOpen(e, params)}><EditLogo /></button>
              <button onClick={() => this.deleteAUTRefOpen(params)} >< TrashLogo /></button>
            </div>
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: [],
    };
    this.typeSelect = React.createRef();
    this.addAUTRefOnChange = this.addAUTRefOnChange.bind(this);
    this.addAUTRefOn_Click = this.addAUTRefOn_Click.bind(this);
  }

  componentDidMount() {
    this.getAUTRefsByOrg();
  };

  getAUTRefsByOrg() {
    ReferenceService.getReferenceByOrg().
      then(
        response => {
          this.setState({
            rowData: response.data
          })
          // console.log('getAUTRefsByOrg', response.data)
        }
      );
  };

  add_edit_AUTRefOpen = (e, params) => {
    if (params == undefined || params == null) {
      this.setState({
        AUTRefFormFlag: false,
        addAUTRefFormFlag: true,
        navPath: ['Reference and system', 'Add Reference'],
        newAUTRefData: {
          Value: '',
          type: '',
          description: ''
        },
        errors: {
          Value: '',
          type: '',
        }
      })
    } else {
      this.setState({
        AUTRefFormFlag: false,
        editAUTRefFormFlag: true,
        navPath: ['Reference and system', 'Edit Reference'],
        editdetails: params.data,
        errors: {
          Value: '',
          type: '',
        }
      })
    }
  };

  addAUTRefOnChange = (e, obj) => {
    try {
      e.preventDefault();
    } catch (error) {
      if (e == null)
        return;
    }
    let name, value;
    let errors = this.state.errors;
    if (e.target == undefined) {
      name = obj.name;
      value = e.value;
      errors[name] = "";
    }
    else {
      name = e.target.name;
      value = e.target.value.trim();
    }
    this.setState(prevState => ({
      newAUTRefData: {
        ...prevState.newAUTRefData,
        [name]: value,
      }
    }))
    switch (name) {
      case 'type':
        errors.type =
          value.length < 1
            ? "type Name can't be empty ! "
            : '';
        break;
      case 'Value':
        errors.Value =
          value.length < 1
            ? "Identifier can't be empty ! "
            : '';
        break;
      default:
        break;
    }
    this.setState({ errors, [name]: value });
  };

  addAUTRefOn_Click = (event) => {
    event.preventDefault();
    let newAUTRefData = this.state.newAUTRefData;
    newAUTRefData['MasterBizUitKey'] = window.localStorage.getItem("MasterBizUitKey");
    newAUTRefData['status'] = 'true';
    if (this.validateAllfields(newAUTRefData)) {
      for (var i = 0; i < this.state.rowData.length; i++) {
        if (this.state.rowData[i].Value.toUpperCase() == newAUTRefData.Value.toUpperCase()) {
          toast.error("Already exist!");
          return;
        }
      }
      event.currentTarget.disabled = true;
      ReferenceService.CreateReferenceByOrg(newAUTRefData).
        then(
          response => {
            if (response.status === 201 || response.status === 200) {
              toast.success("Reference Added Successfully!");
              this.getAUTRefsByOrg();
              this.backToMainScreen();
            } else {
              event.currentTarget.disabled = false;
            }
          }
        );
    }
  };

  editRefOn_Change = (e, obj) => {
    try {
      e.preventDefault();
    } catch (error) {
      if (e == null)
        return;
    }
    let name, value;
    let errors = this.state.errors;
    if (e.target == undefined) {
      name = obj.name;
      value = e.value;
      errors[name] = "";
    }
    else {
      name = e.target.name;
      value = e.target.value.trim();
    }
    this.setState(prevState => ({
      editdetails: {
        ...prevState.editdetails,
        [name]: value,
      }
    })
    )
    switch (name) {
      case 'type':
        errors.type =
          value.length < 1
            ? "type Name can't be empty ! "
            : '';
        break;
      case 'Value':
        errors.Value =
          value.length < 1
            ? "identifier can't be empty ! "
            : '';
        break;
      default:
        break;
    }
    this.setState({ errors, [name]: value });
  };

  editRefOn_Click = (e) => {
    let records = this.state.editdetails;
    console.log('validateAllfields', this.state.editdetails)
    e.preventDefault();
    if (!this.validateAllfields(records)) {
      // console.log("In VAlid DATA", records)
      return
    }
    e.currentTarget.disabled = true;
    ReferenceService.UpdateReferenceByOrg(records).
      then(
        response => {
          if (response.status == 200) {
            toast.success(records.Value + "  Updated Successfully ! ");
            this.getAUTRefsByOrg();
            this.backToMainScreen();
          } else {
            e.currentTarget.disabled = false;
          }
        }
      );

  };

  validateAllfields(records) {
    if (records.Value == undefined || records.Value == "" || this.state.errors.Value != "") {
      let err = records.Value == undefined || records.Value == "" ? ' Please enter Identifier  ' : this.state.errors.Value;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          Value: err
        },
      }));
      return false;
    }
    if (records.type == undefined || records.type == "" || this.state.errors.type != "") {
      let err = records.type == undefined || records.type == "" ? ' Please Select Type  ' : this.state.errors.type;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          type: err
        },
      }));
      return false;
    }
    return true;
  };

  deleteAUTRefOpen = (event) => {
    this.setState({
      deleteAUTRefFormFlag: true,
      selecteddeleteindex: event.rowIndex
    })
  };

  deleteAUTRefOn_Click = (e) => {
    //DeleteSettingsByOrg
    // console.log(" event.currentTarget.disabled = true")
    e.currentTarget.disabled = true;
    ReferenceService.DeleteReferenceByOrg(this.state.rowData[this.state.selecteddeleteindex]["gkey"]).
      then(
        response => {
          this.setState({
            deleteAUTRefFormFlag: false
          })
          if (response.status === 200) {
            toast.success("Reference Deleted Successfully!");
            this.getAUTRefsByOrg();
            this.backToMainScreen();
          }
        }
      );
  };

  resetOn_Click = (e) => {
    e.preventDefault();
    this.setState({
      newAUTRefData: {
        Value: '',
        type: '',
        description: ''
      },
      errors: {
        type: '',
        Value: '',
      },
    })
    if (this.state.editdetails.length != 0) {
      this.setState(prevState => ({
        editdetails: {
          ...prevState.editdetails,
          Value: '',
          type: '',
          description: ''
        }
      })
      )
    }
    this.typeSelect.current.clearValue()
  };

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  backToMainScreen = () => {
    this.setState({
      AUTRefFormFlag: true,
      addAUTRefFormFlag: false,
      editAUTRefFormFlag: false,
      deleteAUTRefFormFlag: false,
      navPath: ['Reference and system']
    })
  }

  render() {
    return (
      <AuthCommonLayout>
        <div>
          <div className='screenHeader'>
            <ComponentHeader
              isSearchable={this.state.AUTRefFormFlag}
              path={this.state.navPath}
              backToParentClass={this.backToMainScreen}
              onFilterTextBoxChanged={this.onFilterTextBoxChanged}
            />
          </div>
          <div className='screenBody'>
            <div class="max-lg:px-4 max-lg:py-1">
              {this.state.AUTRefFormFlag ?
                <div>

                  <div id='CustomAgGrid'>
                    <CustomAgGrid
                      rowData={this.state.rowData}
                      columnDefs={this.state.columnDefs}
                      onGridReady={this.onGridReady}
                      filterValue={this.state.filterValue}
                    />
                  </div>

                  <div className="fixed bottom-6 right-10"  >
                    <button onClick={this.add_edit_AUTRefOpen} class={localControlsConstant.ToolTip.addbutton}>
                      <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
                      <div class={localControlsConstant.ToolTip.tooltipGroup}>
                        <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.AUT_REFERENCE.ADD_REFERENCE}</span>
                        <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
                      </div>
                    </button>
                  </div>

                </div>
                :
                <div>
                  {this.state.addAUTRefFormFlag || this.state.editAUTRefFormFlag ?
                    <div>
                      {this.state.addAUTRefFormFlag ?
                        < AddAUTReferenceSystem
                          addAUTRefOnChange={this.addAUTRefOnChange}
                          addAUTRefOn_Click={this.addAUTRefOn_Click}
                          newAUTRefData={this.state.newAUTRefData}
                          errors={this.state.errors}
                          resetOn_Click={this.resetOn_Click}
                          typeSelect={this.typeSelect}
                        />
                        :
                        <EditAUTReferenceSystem
                          editRefData={this.state.editdetails}
                          errors={this.state.errors}
                          editRefOn_Change={this.editRefOn_Change}
                          editRefOn_Click={this.editRefOn_Click}
                          resetOn_Click={this.resetOn_Click}
                          typeSelect={this.typeSelect}
                        />}
                    </div>
                    : null
                  }
                </div>
              }
            </div>
            {this.state.deleteAUTRefFormFlag ?
              <div>
                <ReactDialogBox
                  closeBox={this.backToMainScreen}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  //   bodyHeight='150px'
                  headerText='Delete Reference'
                >
                  <div>
                    <div class='flex items-center h-16 pl-7'>
                      <h1>{localConstant.AUT_REFERENCE.DELETE_REFERENCE_CONTENT} <span class='text-delete-user-text'> {this.state.rowData[this.state.selecteddeleteindex]["Value"]}</span>?</h1>
                    </div>
                    <div class="modal-footer flex flex-shrink-0 flex-wrap space-x-3 items-center justify-end pb-0 p-4 border-tbtnPrimary border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary} onClick={this.deleteAUTRefOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
              : null
            }
            <ToastContainer limit={2} autoClose={2000} />
          </div>
        </div>
      </AuthCommonLayout>
    )
  }
}
export default AUTReferenceSystem;
