import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3006
const EditSettings = (props) => {
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    return (
        <div className="mt-5">
            {/* <div class='flex justify-center mb-5 w-full max-w-sm  max-lg:max-w-sm'>
                <h1 class={localControlsConstant.Responsive.textboxResponsive.text_header}>{localConstant.SETTINGS.EDIT_SETTING}({props.settingdetails.gkey.toString().substring(0, 7)})</h1>
            </div> */}

            {/* RESPONSIVE START */}
            <form class="w-full max-w-sm  max-lg:max-w-sm">
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.SETTINGS.SETTING_NAME}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.SettingName.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter setting name"
                            name="Name"
                            value={props.settingdetails.Name}
                            onChange={props.editSettingOn_Change}

                        />
                        {props.errors.SettingName.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.SettingName}</span>
                        }
                    </div>
                </div>

                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.SETTINGS.VALUE_1}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.Value1.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter Value1"
                            name="Value1"
                            value={props.settingdetails.Value1}
                            onChange={props.editSettingOn_Change}
                        />
                        {props.errors.Value1.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.Value1}</span>
                        }
                    </div>
                </div>

                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.SETTINGS.VALUE_2}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.Value2.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter Value2"
                            name="Value2"
                            value={props.settingdetails.Value2}
                            onChange={props.editSettingOn_Change}
                        />
                        {props.errors.Value2.length > 0 &&
                            <span class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.Value2}</span>
                        }
                    </div>
                </div>

                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.SETTINGS.DESCRIPTION}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <textarea
                            class={localControlsConstant.Responsive.textboxResponsive.textarea}
                            type="textarea"
                            placeholder="Enter Description"
                            value={props.settingdetails.Description}
                            onChange={props.editSettingOn_Change}
                            name="Description"
                        />
                    </div>
                </div>
                <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                        onClick={(e) => props.editSettingOn_Click(e)}>{localConstant.COMMON_CONST.UPDATE}</button>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                        onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                </div>
            </form>
            {/* RESPONSIVE END */}
        </div>
    )
}
export default EditSettings;

