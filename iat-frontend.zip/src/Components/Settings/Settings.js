import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { GoDotFill } from 'react-icons/go';
import { HiPlus } from 'react-icons/hi';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import 'react-toastify/dist/ReactToastify.css';
import EditSettings from './EditSettings';
import AddSettings from './AddSettings';
import SettingsService from '../../Services/SettingsService';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3007
class Settings extends React.Component {
  constructor() {
    super()
    this.state = {
      settingform: true,
      addsetting: false,
      editSetting: false,
      IsDeleteSettings: false,
      selecteddeleteindex: '',
      editDetails: '',
      newSettingData: {},
      navPath: ['Settings'],
      errors: {
        SettingName: '',
        Value1: '',
        Value2: '',
      },
      columnDefs: [
        // {
        //   headerName: "ID", field: "gkey", suppressMovable: true, minWidth: 120, flex: 1,
        //   cellRenderer: (params) => {
        //     const id = `300${params.rowIndex + 1}`.slice(-4);
        //     return <span className=' text-blue-600 cursor-pointer' onClick={(e) => this.add_Edit_SettingOpen(e,params)}> {'S' + id}</span>
        //   }
        // },
        { headerName: "Name", field: "Name", suppressMovable: true, minWidth: 150, flex: 2,
        cellRenderer: (params) => {
          return <span className=' text-blue-600 cursor-pointer' onClick={(e) => this.add_Edit_SettingOpen(e,params)}> {params.value}</span>
        } },
        { headerName: "Value 1", field: "Value1", suppressMovable: true, minWidth: 130, flex: 2, },
        { headerName: "Value 2", field: "Value2", suppressMovable: true, minWidth: 130, flex: 2, },
        {
          headerName: "Status", field: "status", minWidth: 100, suppressMovable: true, flex: 1,
          cellRendererFramework: (params) =>
            <span class="flex items-center justify-items-center grow text-green-500"><GoDotFill /><span class="text-black">Active</span></span>
        },
        {
          headerName: "Action", field: "Action", minWidth: 100, suppressMovable: true, flex: 1,
          cellRendererFramework: (params) =>
            <div class='flex w-full h-full items-center space-x-4'>
              <button onClick={(e) => this.add_Edit_SettingOpen(e, params)}><EditLogo /></button>
              <button onClick={() => this.deleteStreamOpen(params)} >< TrashLogo /></button>
            </div>
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: [],
    };
    this.gridRef = React.createRef();
    this.addSettingOnChange = this.addSettingOnChange.bind(this);
    this.addSettingOn_Click = this.addSettingOn_Click.bind(this);
  };

  componentDidMount() {
    this.getSettingsByOrg();
  };

  getSettingsByOrg() {
    SettingsService.getSettingsByOrg().
      then(
        response => {
          this.setState({
            rowData: response.data,
          })
        }
      );
  };

  add_Edit_SettingOpen = (event, params) => {
    if (params == undefined || params == null) {
      this.setState({
        settingform: false,
        addsetting: true,
        newSettingData: {
          Name: '',
          Value1: '',
          Value2: '',
          Description: ''
        },
        errors: {
          SettingName: '',
          Value1: '',
          Value2: '',
        },
        navPath: ['Settings', 'Add Setting']
      })
    } else {
      this.setState({
        settingform: false,
        editSetting: true,
        editDetails: params.data,
        navPath: ['Settings', 'Edit Setting'],
        errors: {
          SettingName: '',
          Value1: '',
          Value2: '',
        },
      })
    }
  };

  addSettingOnChange(e) {
    let name = e.target.name.trim();
    let value = e.target.value.trim();
    let errors = this.state.errors;
    this.setState(prevState => ({
      newSettingData: {
        ...prevState.newSettingData,
        [name]: value,
      }
    }))
    switch (name) {
      case 'Name':
        errors.SettingName =
          value.length < 1
            ? "Setting Name can't be empty ! "
            : '';
        break;
      case 'Value1':
        errors.Value1 =
          value.length < 1
            ? "Value1 can't be empty ! "
            : '';
        break;
      case 'Value2':
        errors.Value2 =
          value.length < 1
            ? "Value2 can't be empty ! "
            : '';
        break;
      default:
        break;
    }
  };

  addSettingOn_Click = event => {
    event.preventDefault();
    let newSettingData = this.state.newSettingData;
    newSettingData["MasterBizUitKey"] = window.localStorage.getItem("MasterBizUitKey");
    newSettingData["status"] = true;
    console.log('newSettingData', newSettingData)
    console.log('newSettingData', this.validateAllfields(newSettingData))

    if (this.validateAllfields(newSettingData)) {
      for (var i = 0; i < this.state.rowData.length; i++) {
        if (this.state.rowData[i].Name.toUpperCase() == newSettingData.Name.toUpperCase()) {
          toast.error("Name Already exist!");
          return;
        }
      }
      event.currentTarget.disabled = true;
      SettingsService.CreateSettingsByOrg(newSettingData).
        then(
          response => {
            //toast.error(errorCode);
            if (response.status === 201 || response.status === 200) {
              toast.success("Settings Added Successfully!");
              this.getSettingsByOrg();
              this.backToMainScreen();
            }
          }
        );
    }
  };

  editSettingOn_Change = (e) => {
    e.preventDefault();
    let name = e.target.name.trim();
    let value = e.target.value.trim();
    this.setState(prevState => ({
      editDetails: {
        ...prevState.editDetails,
        [name]: value,
      }
    }))
    let errors = this.state.errors;
    switch (name) {
      case 'Name':
        errors.SettingName =
          value.length < 1
            ? "Setting Name can't be empty ! "
            : '';
        break;
      case 'Value1':
        errors.Value1 =
          value.length < 1
            ? "Value1 can't be empty ! "
            : '';
        break;
      case 'Value2':
        errors.Value2 =
          value.length < 1
            ? "Value2 can't be empty ! "
            : '';
        break;
      default:
        break;
    }
    this.setState({ errors, [name]: value });
  };

  editSettingOn_Click = (e) => {
    e.preventDefault();
    console.log('editSettingOn_Click', this.state.editDetails)
    const isValid = this.validateAllfields(this.state.editDetails);
    if (isValid) {
      e.currentTarget.disabled = true;
      SettingsService.UpdateSettingsByOrg(this.state.editDetails).
        then(
          response => {
            if (response.status == 200 || response.status == 201) {
              toast.success("Setting Updated Successfully")
              this.getSettingsByOrg();
              this.backToMainScreen();
            } else {
              e.currentTarget.disabled = false;
              toast.error("Setting Updated Failed")
            }
          }
        );
    }
    else {
      console.log("In valid Data ", this.state.editDetails)
    }
  };

  deleteStreamOpen = (event) => {
    //DeleteSettingsByOrg
    this.setState({
      IsDeleteSettings: true,
      selecteddeleteindex: event.rowIndex
    })
  };

  deleteSettingOn_Click = (event) => {
    event.currentTarget.disabled = true;
    SettingsService.DeleteSettingsByOrg(this.state.rowData[this.state.selecteddeleteindex]["gkey"]).
      then(
        response => {
          if (response.status === 200 || response.status === 201) {
            this.setState({
              IsDeleteSettings: false
            })
            toast.success("Settings Deleted Successfully!");
            this.getSettingsByOrg();
            this.backToMainScreen();
          } else {
            event.currentTarget.disabled = false;
          }
        }
      );
  };

  deleteSettingClose = () => {
    this.setState({
      IsDeleteSettings: false
    })
  };

  resetOn_Click = (e) => {
    e.preventDefault();
    this.setState({
      newSettingData: {
        Name: '',
        Value1: '',
        Value2: '',
        Description: ''
      },
      errors: {
        SettingName: '',
        Value1: '',
        Value2: '',
        Description: ''
      },
    })
    if (this.state.editSetting) {
      this.setState(prevState => ({
        editDetails: {
          ...prevState.editDetails,
          Name: '',
          Value1: '',
          Value2: '',
          Description: ''
        }
      }))
    }
  };

  validateAllfields(records) {
    if (records.Name == undefined || records.Name == "" || this.state.errors.SettingName != "") {
      let err = records.Name == undefined || records.Name == "" ? ' Please enter SettingName  ' : this.state.errors.SettingName;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          SettingName: err
        },
      }));
      return false;
    }
    if (records.Value1 == undefined || records.Value1 == "" || this.state.errors.Value1 != "") {
      let err = records.Value1 == undefined || records.Value1 == "" ? ' Please enter Value1  ' : this.state.errors.Value1;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          Value1: err
        },
      }));
      return false;
    }
    if (records.Value2 == undefined || records.Value2 == "" || this.state.errors.Value2 != "") {
      let err = records.Value2 == undefined || records.Value2 == "" ? ' Please enter Value2  ' : this.state.errors.Value2;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          Value2: err
        },
      }));
      return false;
    }
    return true;
  };

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })

  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  backToMainScreen = () => {
    this.setState({
      settingform: true,
      addsetting: false,
      editSetting: false,
      navPath: ['Settings']
    })
  }

  render() {
    return (

      <AuthCommonLayout>
        <div>

          <div className='screenHeader'>
            <ComponentHeader
              isSearchable={this.state.settingform}
              path={this.state.navPath}
              backToParentClass={this.backToMainScreen}
              onFilterTextBoxChanged={this.onFilterTextBoxChanged}
            />
          </div>

          <div className='screenBody'>
            {this.state.settingform ?
              <div id="AGGrid">
                <div id='CustomAgGrid'>
                  <CustomAgGrid
                    rowData={this.state.rowData}
                    columnDefs={this.state.columnDefs}
                    onGridReady={this.onGridReady}
                    filterValue={this.state.filterValue}
                  />
                </div>

                <div className="fixed bottom-6 right-10"  >
                  <button onClick={this.add_Edit_SettingOpen} class={localControlsConstant.ToolTip.addbutton}>
                    <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
                    <div class={localControlsConstant.ToolTip.tooltipGroup}>
                      <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.SETTINGS.ADD_SETTING}</span>
                      <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
                    </div>
                  </button>
                </div>
              </div>
              :
              <div id="SettingForm">
                {this.state.addsetting || this.state.editSetting ?
                  <div>
                    {this.state.addsetting ?
                      <AddSettings
                        addSettingOnChange={this.addSettingOnChange}
                        addSettingOn_Click={this.addSettingOn_Click}
                        newSettingData={this.state.newSettingData}
                        errors={this.state.errors}
                        resetOn_Click={this.resetOn_Click}
                      /> :
                      <EditSettings
                        settingdetails={this.state.editDetails}
                        editSettingOn_Change={this.editSettingOn_Change}
                        errors={this.state.errors}
                        editSettingOn_Click={this.editSettingOn_Click}
                        resetOn_Click={this.resetOn_Click}
                      />
                    }
                  </div>
                  : null
                }
              </div>
            }
            {this.state.IsDeleteSettings ?
              <div>
                <ReactDialogBox
                  closeBox={this.deleteSettingClose}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  //   bodyHeight='150px'
                  headerText='Delete Setting'
                >
                  <div>
                    <div class='flex items-center h-16 pl-7'>
                      <h1>{localConstant.SETTINGS.DELETE_SETTINGS_CONTENT} <span class='text-delete-user-text'>{this.state.rowData[this.state.selecteddeleteindex]["Name"]}</span>?</h1>
                    </div>
                    <div class="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary}
                        onClick={this.deleteSettingOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary}
                        onClick={this.deleteSettingClose}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
              : null
            }
            <ToastContainer limit={2} autoClose={2000} />
          </div>
        </div>
      </AuthCommonLayout>
    )
  }
}
export default Settings;
