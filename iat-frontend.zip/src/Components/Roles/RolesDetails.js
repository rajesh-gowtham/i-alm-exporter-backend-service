import React, { useMemo, useState } from "react";
import { HiChevronDoubleDown, HiChevronDoubleUp, HiOutlineTrash } from "react-icons/hi";
import { HiPlus } from "react-icons/hi";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { ColorConstants } from "../../Constants/ColorConstants";
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import { AgGridReact } from 'ag-grid-react';
import ManagePrivilages from "../Privilages/ManagePrivilages";
import AddRole from "./AddRole";
import { connect } from 'react-redux';
import Store, { GetPrivilegesByStore } from "../../Redux/Store";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import EditRole from "./EditRole";
import RoleService from "../../Services/RoleService";
import Argo_roles_privilegeService from "../../Services/Argo_roles_privilegeService";
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { addRolePrivilage } from "../../Redux/action";
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { MdOutlineModeEditOutline } from "react-icons/md";
import ComponentHeader from "../../CommonUtils/ComponentHeader";
import { GridConstants } from "../../Constants/GridConstants";

const gridLocalConstants = GridConstants.AGGrid.Secondary_Grid;

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();

//SCREEN ID -3008
class RolesDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            addPrevilagesFlag: false,
            addRoleFlag: false,
            editRoleFlag: false,
            deleteRoleFlag: false,
            availablerole: [],
            roleflag: [],
            modelheader: '',
            records: {},
            error: ''
        }
        this.managePrivRef = React.createRef();
    };

    componentDidMount() {
        this.GetRolesByOrg();
    }

    async GetRolesByOrg() {
        const allPrivileges = await GetPrivilegesByStore();
        Argo_roles_privilegeService.GetPrivilageToRole()
            .then(response => {
                console.log(" response ", response)
                const { Roles, Argo_roles_Details } = response.data
                let rolesPrivlege = {};
                Object.keys(Argo_roles_Details).map(role => {
                    let rolePrivTemp = [];
                    Argo_roles_Details[role].map((item) => {
                        allPrivileges.map((privilege) => {
                            if (item.Privileges_Gkey == privilege.gkey) {
                                rolePrivTemp.push(privilege)
                            }
                        })
                    })
                    rolesPrivlege[role] = rolePrivTemp;
                })
                this.props.dispatch(addRolePrivilage(rolesPrivlege));
                this.setState({ availablerole: Roles })
            })
    }

    closeListPanel = (e, index) => {
        e.preventDefault();
        let roleflags = this.state.roleflag;
        let item = { ...roleflags[index] };
        item = false;
        roleflags[index] = item;
        this.setState({
            roleflag: roleflags
        })
    };

    openListPanel = (e, index) => {
        e.preventDefault();
        let roleflags = this.state.roleflag;
        let item = { ...roleflags[index] };
        item = true;
        roleflags[index] = item;
        this.setState({
            roleflag: roleflags
        })
    };

    //funtiom to open add mange privileges form 
    addPrivilagesOpen(e, role) {
        e.preventDefault();
        this.setState({
            addPrevilagesFlag: true,
            role: role,
            modelheader: 'Manage Privileges'
        })
    };

    SetPrivilegeToRole = (SelectedData) => {
        Argo_roles_privilegeService.CreateManyPrivilegeByRole(SelectedData).then(response => {
            if (response.status === 200 || response.status === 201) {
                toast.success("Privilege Added Successfully")
                this.GetRolesByOrg();
            }
        });
    };

    // handling  Manage Priviliges Changes  
    updateManagePrivilegesOn_Click = (event) => {
        event.preventDefault();
        let [selectedData, role] = this.managePrivRef.current.getSelectedRowData(event);
        let newSelectedRecords = [];
        selectedData.map(item => {
            let records = {
                Role_Gkey: role.gkey,
                roleName: role.name,
                Privilege_Name: item.Privilege_Name,
                Privileges_Gkey: item.gkey
            }
            newSelectedRecords.push(records)
        })
        // console.log("Selected Privilage ", selectedData)
        if (selectedData.length === 0) {
            console.log("Privilage role name ", role.name)
            console.log("Privilage role gkey ", role.gkey)
            Argo_roles_privilegeService.DeletPrivilageToRoleByGkey(role.gkey).
                then(response => {
                    console.log(" res ", response.data)
                    if (response.status === 200 || response.status === 201) {
                        toast.success("Privilege Removed Successfully");
                        this.GetRolesByOrg();
                    }
                });
        } else {
            this.SetPrivilegeToRole(newSelectedRecords);
        }
        this.setState({ addPrevilagesFlag: false });
    };

    //funtiom to open add role form 
    addRoleOpen = (e) => {
        e.preventDefault();
        this.setState({
            addRoleFlag: true,
            modelheader: 'Add Role',
            records: { role: '', description: '' },
            error: ''
        })
    };

    handleOnChange = (e) => {
        e.preventDefault();
        const name = e.target.name;
        const value = e.target.value;
        let error = this.state.error;
        this.setState(prevState => ({
            records: {
                ...prevState.records,
                [name]: value,
            }
        })
        )
        switch (name) {
            case 'role':
                error = value.length < 1
                    ? "Role Name can't be empty ! "
                    : ''
                break;
            case 'name':
                error = value.length < 1
                    ? "Role Name can't be empty ! "
                    : ''
                break;
            default:
                break;
        }
        this.setState({ error: error });
    }

    // Accessing child -->  Add new Role form
    addRoleOn_Click = (event) => {
        event.preventDefault();
        const records = this.state.records;
        const isValid = this.validateAllFields(records)
        if (isValid) {
            const roleName = records.role.trim();
            const result = this.state.availablerole.findIndex(item => roleName.toLowerCase() === item.name.toLowerCase());
            if (result !== -1) {
                toast.error("Role name Already Exist !! ")
                return;
            }
            event.currentTarget.disabled = true;
            RoleService.CreateRoleByOrg(records).
                then(
                    response => {
                        if (response.status == 201) {
                            toast.success("Role Added Successfully");
                            this.GetRolesByOrg();
                            this.setState({ addRoleFlag: false });
                        } else {
                            toast.error(response.data);
                        }
                    }
                );
        }
    };

    editRoleOpen = (e, roleDet) => {
        e.preventDefault();
        console.log(" role ", roleDet)
        let role = roleDet.name;
        if (role == "Admin" || role == "Analyst" || role == "Tester") {
            toast.warning(role + " Can't be Edited ! ")
            return;
        }
        this.setState({
            editRoleFlag: true,
            records: roleDet,
            modelheader: 'Edit Role'
        })
    };

    editRoleOn_Click = (event) => {
        event.preventDefault();
        const records = this.state.records;
        const isValid = this.validateEditFields(records);
        const roleName = records.name.trim();
        const result = this.state.availablerole.findIndex(item => roleName.toLowerCase() == item.name.toLowerCase());
        // add by nagarasu
        // if (this.state.records.name.toLowerCase() != roleName.toLowerCase()) {
        if (result !== -1) {
            toast.error("Role name Already Exist !! ")
            return;
        }
        //  }
        if (isValid) {
            event.currentTarget.disabled = true;
            RoleService.UpdateRoleByOrg(records).then(response => {
                if (response.status === 200 || response.status === 201) {
                    toast.success("Role Updated Successfully")
                    this.GetRolesByOrg();
                }
            });
            this.setState({ editRoleFlag: false });
        }
    };

    validateAllFields = (records) => {
        if (records.role.length != 0 && records.role.trim().length == 0) {
            records.role = records.role.trim();
            this.setState({ error: "Space can't be taken as a Role Name" })
            return;
        }

        if (records.role == "" || records.role == null || records.role == undefined || this.state.error != "") {
            let err = records.role == undefined || records.role == "" ? "Please Enter Role Name" : this.state.error;
            this.setState({
                error: err
            });
            return false;
        }
        return true;
    };

    validateEditFields = (records) => {
        if (records.name.length != 0 && records.name.trim().length == 0) {
            records.name = records.name.trim();
            this.setState({ error: "Space can't be taken as a Role Name" })
            return;
        }
        if (records.name == "" || records.name == null || records.name == undefined || this.state.error != "") {
            let err = records.name == undefined || records.nameF == "" ? "Please Enter Role Name" : this.state.error;
            this.setState({
                error: err
            });
            return false;
        }
        return true;
    };

    deleteRoleOpen = (e, roleDet) => {
        e.preventDefault();
        let role = roleDet.name;
        if (role == "Admin" || role == "Analyst" || role == "Tester") {
            toast.warning(role + " Can't be Deleted ! ")
            return;
        }
        this.setState({
            role: role,
            roleDet: roleDet,
            deleteRoleFlag: true,
        })
    };

    deleteRoleOn_Click = (e) => {
        e.currentTarget.disabled = true;
        RoleService.DeleteRoleByOrg(this.state.roleDet.gkey).
            then(
                respons => {
                    if (respons.status == 200 || respons.status == 201) {
                        this.GetRolesByOrg();
                        console.log(" respons.data ", respons)
                        if (respons.data != null || respons.data != '' || respons.data != undefined) {
                            respons.data == 'Role Exist with User' ? toast.warning(respons.data) : toast.success(respons.data)
                        }
                        else {
                            toast.warning('406-Not Acceptable')
                        }
                        this.backToMainScreen()
                    }
                }
            );

    };

    backToMainScreen = (e) => {
        this.setState({
            addPrevilagesFlag: false,
            addRoleFlag: false,
            editRoleFlag: false,
            deleteRoleFlag: false,
        })
    };

    render() {
        var rows = this.state.availablerole;
        return (
            <AuthCommonLayout>
                <div className='pb-7'>

                    <div id='screenHeader'>
                        <ComponentHeader
                            isSearchable={false}
                            path={["User's Roles"]}
                            backToParentClass={this.backToMainScreen}
                            onFilterTextBoxChanged={() => { console.log() }}
                        />
                    </div>

                    <div className="screenBody px-[15px] py-[20px]">
                        {rows.map((item, index) => (
                            <div>
                                <div className="pt-2 h-4/5 w-full border-2px border-solid "  >
                                    <div className="flex justify-center">
                                        <div className="p-1 mb-2 w-[88%] bg-transparent">
                                            <div className={ColorConstants.RoleHeader.HederBoder}>
                                                <h3 className={ColorConstants.RoleHeader.Orange}>
                                                    <div className="flex justify-between  items-center gap-2 text-slate-50">
                                                        <span className="flex">
                                                            {(this.state.roleflag[index]) ?
                                                                <span id="arrowShadow">
                                                                    <HiChevronDoubleUp size={20} onClick={(e) => this.closeListPanel(e, index)} />
                                                                </span>
                                                                :
                                                                <span id="arrowShadow">
                                                                    <HiChevronDoubleDown size={20} onClick={(e) => this.openListPanel(e, index)} />
                                                                </span>
                                                            }
                                                            <p className="ml-2">{item.name}</p>
                                                        </span>
                                                        {index > 2 ?
                                                            <span className="flex">
                                                                <span className="p-[2px] border-2 border-transparent cursor-pointer rounded hover:border-[#ffffffd2]" onClick={(e) => this.editRoleOpen(e, item)}>
                                                                    <MdOutlineModeEditOutline color={'white'} size={20} />
                                                                </span>
                                                                <span className="p-[2px] border-2 border-transparent cursor-pointer rounded hover:border-[#ffffffd2]" onClick={(e) => this.deleteRoleOpen(e, item)}>
                                                                    <HiOutlineTrash color={'white'} size={20} />
                                                                </span>
                                                            </span>
                                                            :
                                                            null
                                                        }
                                                    </div>
                                                </h3>
                                                <div >
                                                    {(this.state.roleflag[index]) ?
                                                        <div className=" bg-[#ebeef6] p-5 text-black">
                                                            <RoleDataGrid Role={item.name} />
                                                            <div className="flex  justify-end mt-2">
                                                                <button className={ControlsConstants.Buttons.btnPrimary + ' h-8 ml-2 '} onClick={(e) => this.addPrivilagesOpen(e, item)} >{localConstant.ROLE.PRIVILEGES}</button>
                                                            </div>
                                                        </div>
                                                        : null}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}

                        <div className="fixed bottom-6 right-10">
                            <button onClick={(e) => this.addRoleOpen(e)} class={localControlsConstant.ToolTip.addbutton}>
                                <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
                                <div class={localControlsConstant.ToolTip.tooltipGroup}>
                                    <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.ROLE.ADD_ROLE}</span>
                                    <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
                                </div>
                            </button>
                        </div>

                        {this.state.addRoleFlag || this.state.editRoleFlag ?
                            <div>
                                <ReactDialogBox
                                    closeBox={(e) => this.backToMainScreen(e)}
                                    modalWidth={ControlsConstants.Model.modalWidth}
                                    headerBackgroundColor={ControlsConstants.Model.headerbg}
                                    headerTextColor={ControlsConstants.Model.bodybg}
                                    headerHeight={ControlsConstants.Model.headerheight}
                                    closeButtonColor={ControlsConstants.Model.closebtncolor}
                                    bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                    bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                    headerText={this.state.modelheader}
                                >
                                    {this.state.addRoleFlag ?
                                        <AddRole
                                            records={this.state.records}
                                            error={this.state.error}
                                            handleOnChange={this.handleOnChange}
                                            addRoleOn_Click={this.addRoleOn_Click}
                                            dialogBoxClose={this.backToMainScreen}
                                        />
                                        :
                                        <EditRole
                                            records={this.state.records}
                                            error={this.state.error}
                                            handleOnChange={this.handleOnChange}
                                            onEditRole_ClickSave={this.editRoleOn_Click}
                                            dialogBoxClose={this.backToMainScreen}
                                        />
                                    }
                                </ReactDialogBox>
                            </div>
                            : null
                        }

                        {this.state.addPrevilagesFlag &&
                            <div>
                                <ReactDialogBox
                                    closeBox={(e) => this.backToMainScreen(e)}
                                    modalWidth={ControlsConstants.Model.modalWidth}
                                    headerBackgroundColor={ControlsConstants.Model.headerbg}
                                    headerTextColor={ControlsConstants.Model.bodybg}
                                    headerHeight={ControlsConstants.Model.headerheight}
                                    closeButtonColor={ControlsConstants.Model.closebtncolor}
                                    bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                    bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                    headerText={this.state.modelheader}
                                >
                                    <div>
                                        <div className="space-y-0 ">
                                            <ManagePrivilages role={this.state.role} ref={this.managePrivRef} />
                                        </div>
                                        <div className="modal-footer flex flex-shrink-0 space-x-3 flex-wrap items-center justify-end mt-2 pb-0 p-4 border-t border-gray-200 rounded-b-md">
                                            <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={this.updateManagePrivilegesOn_Click} >{localConstant.COMMON_CONST.UPDATE}</button>
                                            <button type="button" className={ControlsConstants.Buttons.btnSecondary} onClick={(e) => this.backToMainScreen(e)}>{localConstant.COMMON_CONST.CANCEL}</button>
                                        </div>
                                    </div>
                                </ReactDialogBox>
                            </div>
                        }

                        {this.state.deleteRoleFlag &&
                            <div>
                                <ReactDialogBox
                                    closeBox={this.backToMainScreen}
                                    modalWidth={ControlsConstants.Model.modalWidth}
                                    headerBackgroundColor={ControlsConstants.Model.headerbg}
                                    headerTextColor={ControlsConstants.Model.bodybg}
                                    headerHeight={ControlsConstants.Model.headerheight}
                                    closeButtonColor={ControlsConstants.Model.closebtncolor}
                                    bodyBackgroundColor={ControlsConstants.Model.bodybg}
                                    bodyTextColor={ControlsConstants.Model.bodytextcolor}
                                    //   bodyHeight='150px'
                                    headerText='Delete Role'
                                >
                                    <div>
                                        <div className='flex items-center h-16 pl-7'>
                                            <h1>{localConstant.ROLE.DELETE_ROLE_CONTENT}<span className='text-delete-user-text text-[18px] font-semibold'>{this.state.role}</span>?</h1>
                                        </div>
                                        <div className="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                                            <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={this.deleteRoleOn_Click}>{localConstant.COMMON_CONST.YES}</button>
                                            <button type="button" className={ControlsConstants.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.CANCEL}</button>
                                        </div>
                                    </div>
                                </ReactDialogBox>
                            </div>
                        }
                        <ToastContainer limit={2} autoClose={2000} />
                    </div>
                </div>

            </AuthCommonLayout>
        );
    };
};

function mapStateToProps(state) {
    return {
        privileges: state.allPrivileges
    }
}
export default connect(mapStateToProps)(RolesDetails);


function RoleDataGrid(props) {

    //Get Data from Redux
    const PrivilagerowData = Store.getState();
    const rowData = PrivilagerowData["privilegedata"]["privilege"][props.Role];
    const [columnDefs] = useState([
        // {
        //     field: 'Id', headerName: 'ID', suppressMovable: true, minWidth: 100, flex: 1,
        //     cellRenderer: (params) => {
        //         const id = `300${params.rowIndex + 1}`.slice(-4);
        //         return <a href="#" target="_parent" className=' text-blue-600' onClick={() => this.editHandleClick(params)}> {'P' + id}</a>
        //     },
        // },
        { field: 'module_name', headerName: 'Module', suppressMovable: true, minWidth: 150, flex: 1, },
        { field: 'Privilege_Name', headerName: 'Privilege', suppressMovable: true, minWidth: 130, flex: 1, },
    ]);

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     }else{
    //         return { background: '#fafafa' };
    //     }
    //   };

    return (
        <div className='bg-white rounded'>
            <div className="ag-theme-alpine h-[40vh] p-4 rounded" Id="secondaryGridBorder"  >
                <AgGridReact
                    rowData={rowData}
                    columnDefs={columnDefs}
                    animateRows={true}
                    defaultColDef={gridLocalConstants.gridOptions.defaultColDef}
                    headerHeight={35}
                    rowHeight={35}
                    pagination={false}
                    rowSelection={'multiple'}
                    // getRowStyle={getRowStyle}
                    gridOptions={gridLocalConstants.gridOptions}
                    suppressRowClickSelection={true}
                    suppressRowHoverHighlight={true}
                    verlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                    overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                />
            </div>
        </div>
    );
}
