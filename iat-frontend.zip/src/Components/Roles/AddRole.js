import React from 'react';
import 'react-js-dialog-box/dist/index.css';
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { digitsRegExp, specialCharRegExp } from '../../CommonUtils/getLocalizeFunction';
import { getlocalizeData, getControlsConstants } from '../../CommonUtils/getlocalizeData';

const localConstants = getlocalizeData();
const localControlsConstant = getControlsConstants();
//SCREEN ID -3011
const AddRole = (props) => {
  const borderRed = localControlsConstant.TextBox.textboxRed;
  const borderGrey = localControlsConstant.TextBox.textbox;
  return (
    <div className="mt-3">
      <form id='addRoleForm' class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg">
        <div class=" d-inline-block position-relative mb-3">
          <label for="role" class={ControlsConstants.label.label14}>{localConstants.ROLE.ROLE_NAME}</label>
          <br />
          <input
            class={props.error.length > 0 ? borderRed : borderGrey}
            type="text"
            placeholder="Enter Role Name"
            name="role"
            value={props.records.role}
            onChange={props.handleOnChange}
          />
          {props.error.length > 0 &&
            <span id='format' class='text-error-red text-[12px] ml-4'>{props.error}</span>
          }
        </div>
        <div class=" d-inline-block position-relative mb-3">
          <label for="descripton" class={ControlsConstants.label.label14}>{localConstants.ROLE.DESCRIPTION}</label><br />
          <textarea
            class={ControlsConstants.TextBox.textarea}
            type="textarea"
            placeholder="Enter Description"
            name="description"
            onChange={props.handleOnChange} >
          </textarea>
        </div>
        <div class="flex items-center space-x-3 py-2 max-lg:justify-center justify-end border-t border-footer-border rounded-b-md">
          <button type="button" className={ControlsConstants.Buttons.btnPrimary} onClick={props.addRoleOn_Click} >{localConstants.COMMON_CONST.ADD}</button>
          <button type="button" class={ControlsConstants.Buttons.btnSecondary} onClick={props.dialogBoxClose} >{localConstants.COMMON_CONST.CANCEL}</button>
        </div>
      </form>
    </div >
  )
};
export default AddRole;
