import React from "react";
import { Link } from 'react-router-dom';
import { ControlsConstants } from '../Constants/ControlsConstants';
import { getlocalizeData } from "../CommonUtils/getlocalizeData";
import Footer from "../Components/LandingPage/Footer";
const localConstant = getlocalizeData();
const localControlConstant = ControlsConstants;
//SCREEN ID -3029
class FileNotFound extends React.Component {

  render() {
    return (

      <div>
        <div class="bg-gradient-to-r from-purple-300 to-blue-200">
          <div class="w-9/12 m-auto py-16 max-lg:py-4 min-h-screen flex items-center justify-center">
            <div class="bg-white shadow overflow-hidden sm:rounded-lg pb-8">
              <div class="border-t border-gray-200 text-center pt-8 max-lg:pt-4">
                <h1 class="md:text-9xl max-lg:mob-txt-10xl font-bold text-blue-800"><span class="text-orange-500">4</span>04</h1>
                <h1 class="md:text-6xl max-lg:mob-txt-lg font-medium py-8"><span class="text-orange-600">oops!</span>{localConstant.FILE_NOT_FOUND.NOT_FOUND}</h1>
                <p class="md:text-2xl pb-8 px-12 font-medium max-lg:mob-txt-sm">{localConstant.FILE_NOT_FOUND.NOT_DESC}</p>

                <div class='modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pt-5  rounded-b-md space-x-3'>
                  <button class={localControlConstant.Buttons.btnPrimary}>
                    <Link to='/login'>
                      {localConstant.FILE_NOT_FOUND.LOGIN}
                    </Link>
                  </button>
                  <button class={localControlConstant.Buttons.btnSecondary}>
                    {localConstant.FILE_NOT_FOUND.CONTACT}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>

      </div>
    )
  }
}

export default FileNotFound;