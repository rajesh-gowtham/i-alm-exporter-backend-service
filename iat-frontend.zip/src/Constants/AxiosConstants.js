    //SCREEN ID -3054
    export const AxiosConstants = {
        AxiosBase:{
            // ApiBaseUrl:'http://10.1.1.154:8281/icats/v1/',
            // ApiBaseUrl:process.env.REACT_APP_BACKEND_API+'/', //  added by RAJESH 16-08-23 BACKEND API
            ApiBaseUrl:'http://localhost:8281/icats/v1/', //  added by RAJESH 16-08-23 BACKEND API
            userToken:window.localStorage.getItem("Auth Token"),
            userdetaile:window.localStorage.getItem("user Details"),
            MasterBizUitKey:window.localStorage.getItem("MasterBizUitKey"),
            RoleName:window.localStorage.getItem("RoleName"),
            OrganizationName:window.localStorage.getItem("OrganizationName")
        },  
    };
