//SCREEN ID -3055
export const ColorConstants = {
    RoleHeader: {
        Orange: 'bg-[#33658A] p-2 ',
        HederBoder: 'border-2 solid  border-[#33658A]  rounded-md font-[12px]',
        HederBoderColumn: 'border-8 solid  border-[#33658A]  rounded-md font-[14px]',
    },
    Colors: {
        Skyblue: '#33658A',
        blue: '#089de3',
        Orange: '#F26419',
    },
    Icon: {
        search: 'grey',
        sidebarMenu: '#3a7afe',
        editLogoBlue: "#1f52a3",
        editLogoWhite: "white",
        deleteLogoRed: "#ff4500",
    }
};