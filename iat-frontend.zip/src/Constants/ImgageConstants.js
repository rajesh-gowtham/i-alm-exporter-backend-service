//SCREEN ID -3060
export const ImgageConstants = {
    imagepath: {
        icatswithname: '../Images/icatslogoname.png'
    },
};
