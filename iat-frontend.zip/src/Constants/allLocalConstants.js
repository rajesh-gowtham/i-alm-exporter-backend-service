//SCREEN ID -3063
export const allLocalConstants = {

    COMMON_CONST: {
        RESET: 'RESET',
        CANCEL: 'CANCEL',
        ADD: 'ADD',
        UPDATE: 'UPDATE',
        DELETE: 'DELETE',
        SAVE: 'SAVE',
        YES: 'YES',
        NO: 'NO'
    },
    LOGIN: {
        EMAIL: 'Email',
        PASSWORD: 'Password',
        FORGET_PASSWORD: 'Forget Password?',
        BTN_LOGIN: 'Log In',
        COPY_RIGHTS_1: 'Copyright © 2023',
        COPY_RIGHTS_2: 'igo solutions Pvt. Ltd.',
        RESET_PASSWORD_CONTENT: ' To reset your password, enter your email below and submit. An email will be sent to you with instructions about how to complete the process.'
    },
    FILE_NOT_FOUND: {
        LOGIN: 'login',
        CONTACT: 'Contact',
        CODE: '404',
        NOT_FOUND: 'Page not found',
        NOT_DESC: 'Oops! The page you are looking for does not exist. It might have been moved or deleted.'
    },
    MAIN_NAV_BAR: {
        NOTIFICATION: 'Notification',
        LOG_OUT: 'Log out'
    },
    PRIVILEGES: {
        HEADER: 'Privileges',
        DISABLE_PRIVILEGE_CONTENT: 'Are you sure you want to disable',
        PRIVILEGE_NAME: 'Privilege Name',
        MODULE: 'Module',
    },
    USERS: {
        HEADER: 'Users',
        ADD_USER: 'Add User',
        DELETE_USER_CONTENT: 'Are you sure you want to delete',
        ORG_NAME: 'Organization: ',
        FIRST_NAME: 'First Name:',
        LAST_NAME: 'Last Name:',
        EMAIL_ADDRESS: 'Email Address:',
        ROLE: 'Role:',
        CREATE_PASSWORD: 'Password:',
        CONFIRM_PASSWORD: 'Confirm Password:',
    },
    ROLE: {
        HEADER: "User's Roles",
        ADD_ROLE: 'Add Role',
        DELETE_ROLE_CONTENT: 'Are you sure you want to delete ',
        PRIVILEGES: 'PRIVILEGES',
        ROLE_NAME: 'Role Name',
        DESCRIPTION: "Description"
    },
    FIELD_COLUMNS: {
        HEADER: 'Columns',
        ADD_COLUMN: 'Add Columns',
        EDIT_COLUMN: 'Edit Columns',
        EXCEL_IMPORT: 'Excel Import',
        MANUAL_IMPORT: 'Manual Import',
        DELETE_COLUMN_CONTENT: 'Are you sure you want to delete',
        DRAG_UPLOAD: 'Drag Files to Upload',
        BROWSE: 'Browse',
        SUPPORT_FILETYPE: 'Supported file types:',
        FILE_FORMAT: 'XLS,XLSX',
        FILE_CHOSEN: 'File Chosen:-',
        TOTAL_RECORDS: 'Total Records:-',
        VALID_RECORDS: 'Valid Records',
        INVALID_RECORDS: 'Invalid Records',
        NO_FILE_SELECTED: 'No files selected',
        LABEL: 'Label',
        DISPLAY_NAME: 'Display Name',
        CONTROL: 'Control',
        GROUP: 'Group',
    },
    TRANSACTIONS: {
        HEADER: 'Transactions'
    },
    TRANSACTION_RECORDS: {
        HEADER: 'Transaction Records',
        LABEL: 'Label',
        DISPLAY_NAME: 'Display Name',
        CONTROL: 'Control',
        GROUP: 'Group',
    },
    SETTINGS: {
        HEADER: 'Settings',
        ADD_SETTING: 'Add Setting',
        EDIT_SETTING: 'Edit Setting',
        DELETE_SETTINGS_CONTENT: 'Are you sure you want to delete',
        SETTING_NAME: 'Setting Name',
        VALUE_1: "Value 1",
        VALUE_2: " Value 2",
        DESCRIPTION: "Description"
    },
    STREAMS: {
        HEADER:'Streams',
        ADD_STREAM: 'Add Stream',
        EDIT_STREAM: 'Edit Stream',
        DELETE_STREAMS_CONTENT:'Are you sure you want to delete',
        STREAM_NAME:'Stream Name',
        DESCRIPTION:'Description'
    },
    AUT_REFERENCE: {
        HEADER:'Reference and system',
        ADD_REFERENCE: 'Add Reference',
        EDIT_REFERENCE: 'Edit Reference',
        DELETE_REFERENCE_CONTENT:'Are you sure you want to delete',
        IDENTIFIER:'Identifier',
        TYPE:'Type',
        DESCRIPTION:'Description'
    },

    GROUP: {
        HEADER: "GROUP ",
        ADD_GROUP: 'Add Group',
        DDELETE_GROUP_CONTENT: 'Are you sure you want to delete ',
        SCENARIOS: 'SCENARIOS',
        GROUP: 'Group',
        DESCRIPTION: 'Description'
    },
    SCENARIO: {
        HEADER: 'Scenarios',
        GRID_VIEW: 'Grid view',
        TREE_VIEW: 'Tree view (Stream)',
        DELETE_CONTENT: 'Are you sure you want to delete',
        ADD_SCENARIO: 'Add scenario',
        DISPLAY_NAME: 'Display Name',
        LONG_NAME: 'Long Name',
        STREAM: 'Stream',
        DESCRIPTION: 'Description',
    },
    SEQUENCES: {
        HEADER: 'Sequence',
        ADD_SEQUENCE: 'Add Sequence',
        DELETE_SEQUENCES_CONTENT: 'Are you sure you want to delete',
        CLONE_SEQUENCE_CONTENT: 'Are you sure you want to Clone',
        LABEL: 'Label',
        APPLIE_TO: 'Applie To',
        DESCRIPTION: 'Description',
        PARAMETERIZABLE: 'Parameterizable',
    },

};
