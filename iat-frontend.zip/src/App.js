import React, {useState,useEffect} from 'react';
import { Provider } from "react-redux";
import Store from './Redux/Store';
import Users from './Components/Users/UserDetail';
import Login from './Components/Login/Login';
import LandingPage from './Components/LandingPage/LandingPage';
import About from './Components/LandingPage/About';
import Roles from './Components/Roles/RolesDetails'
import FileNotFound from './404/FileNotFound';
import ErrorBoundary from './404/ErrorBoundary';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Settings from './Components/Settings/Settings';
import Privilages from './Components/Privilages/Privilages ';
import Fields_Columns from './Components/Fields_Columns/Fields_Columns';
import AUTReferenceSystem from './Components/AUT_Reference_system/AUTReferenceSystem';
import StreamGroup from './Components/Stream/StreamGroup';
import Dashboard from './Components/Dashboard/Dashboard';
import Transactions from './Components/Fields_Columns/Transactions';
import TestGroup from './Components/TestGroup/TestGroup';
import SequenceDetails from './Components/Sequence/SequenceDetails';
import Scenario from './Components/Scenario/Scenario';

//SCREEN ID -3046
function App() {
  const [isLoading, setLoading] = useState(true);

  function fakeRequest() {
    return new Promise(resolve => setTimeout(() => resolve(), 1000));
  }

  useEffect(() => {
    fakeRequest().then(() => {
      const el = document.querySelector(".loader-container");
      if (el) {
        el.remove();
        setLoading(!isLoading);
      }
    });
  }, []);

  if (isLoading) {
    return null;
  }


  return (
    <div>
      <React.StrictMode>
        <Provider store={Store}>
          <BrowserRouter>
            <Routes>
              <Route path='/' element={<LandingPage />} />
              <Route path='/About' element={<About />} />
              <Route path='login' element={<Login />} />
              <Route path='dashboard/organization/:organization/Role/:Role' element={<Dashboard />} />
              <Route path='404' element={<FileNotFound />} /> 
              <Route path='ErrorBoundary' element={<ErrorBoundary />} />
              <Route path="*" element={<Navigate to="/404" />} />

              
                  <Route path='users/organization/:organization' element={<Users />} />
                  <Route path='roles/' element={<Roles />} />
                  <Route path='settings/' element={<Settings />} />
                  <Route path='privilages/' element={<Privilages />} />
                  <Route path='fields_columns/' element={<Fields_Columns />} />
                  <Route path='transactions/' element={<Transactions />} />
                  <Route path='systemreference/' element={<AUTReferenceSystem />} />
                  <Route path='streamgroup/' element={<StreamGroup />} />
              
            </Routes>
          </BrowserRouter>
        </Provider>
      </React.StrictMode>
    </div>
  );
}

export default App;
