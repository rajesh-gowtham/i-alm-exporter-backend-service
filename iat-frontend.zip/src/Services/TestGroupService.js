import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3036
class TestGroupService {
  CreateGroupByOrg(Groupdata) {
    return axios.post(baseAPIURL + "CreategroupByOrg/", {
      content: Groupdata,
      submittedBy: userdetaile
    });
  }
  UpdateGroupByOrg(Groupdata) {
    return axios.put(baseAPIURL + "UpdategroupByGkey/", {
      content: Groupdata,
      submittedBy: userdetaile
    });
  }

  GetGroupByOrg() {
    return axios.get(baseAPIURL + "GetgroupbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteGroupByOrg(gkey) {
    return axios.delete(baseAPIURL + "Deletegroup/gkey/" + gkey + "/token/" + userToken)
  }

  UpdateMapScenarioByGroup(data) {
    return axios.put(baseAPIURL + "UpdateMapScenarioByGroup/", {
      content: data,
      submittedBy: userdetaile
    });
  }

  DeleteGroupScenariosByGroupGkey(gkey){
    return axios.delete(baseAPIURL + "DelteMapScenarioByGroup/groupkey/" + gkey + "/token/" + userToken)
  }

}
export default new TestGroupService();