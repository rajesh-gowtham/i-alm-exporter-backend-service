import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3034
class ReferenceService {
  CreateReferenceByOrg(Referencedata) {
console.log('Referencedata',Referencedata)
    return axios.post(baseAPIURL + "CreateReferenceByOrg/", {
      content: Referencedata,
      submittedBy: userdetaile
    });
  }

  UpdateReferenceByOrg(Referencedata) {
    return axios.put(baseAPIURL + "UpdateReferenceByOrg/", {
      content: Referencedata,
      submittedBy: userdetaile
    });
  }

  getReferenceByOrg() {
    return axios.get(baseAPIURL + "GetReferencebyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteReferenceByOrg(gkey) {
    return axios.delete(baseAPIURL + "DeleteReference/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new ReferenceService();