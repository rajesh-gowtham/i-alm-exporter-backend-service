import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetail = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3036
class SequenceService {

  CreateSequenceByOrg(Sequencedata) {
    console.log('add Sequencedata SequenceService', Sequencedata)
    return axios.post(baseAPIURL + "CreateSequenceByOrg/", {
      content: Sequencedata,
      submittedBy: userdetail
    });
  }

  UpdateSequenceByOrg(Sequencedata) {
    console.log('edit Sequencedata SequenceService', Sequencedata)
    console.log(JSON.stringify(Sequencedata))
    return axios.put(baseAPIURL + "UpdateSequenceByOrg/", {
      content: Sequencedata,
      submittedBy: userdetail
    });
  }

  GetSequenceByOrg() {
    const MasterBizUitKey = window.localStorage.getItem("MasterBizUitKey")
    return axios.get(baseAPIURL + "GetSequenceDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteSequenceByOrg(gkey) {
    console.log('delete sequence', gkey)
    return axios.delete(baseAPIURL + "DeleteSequence/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new SequenceService();