import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3036
class SettingsService {
  CreateSettingsByOrg(settingsdata) {
    return axios.post(baseAPIURL + "CreateSettingsByOrg/", {
      content: settingsdata,
      submittedBy: userdetaile
    });
  }
  UpdateSettingsByOrg(settingsdata) {
    console.log(JSON.stringify(settingsdata))
    return axios.put(baseAPIURL + "UpdateSettingsByOrg/", {
      content: settingsdata,
      submittedBy: userdetaile
    });
  }

  getSettingsByOrg() {
    const MasterBizUitKey = window.localStorage.getItem("MasterBizUitKey")
    return axios.get(baseAPIURL + "GetSettingsDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteSettingsByOrg(gkey) {
    return axios.delete(baseAPIURL + "DeleteSettings/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new SettingsService();