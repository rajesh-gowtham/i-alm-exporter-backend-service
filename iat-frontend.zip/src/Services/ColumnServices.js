import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3031
class ColumnServices {

  CreateColumnByOrg(newColumnData) {
    return axios.post(baseAPIURL + "CreateColumnByOrg/", {
      content: newColumnData,
      submittedBy: userdetaile
    });
  }

  UpdateColumnByOrg(CreateFields_Columns) {
    return axios.put(baseAPIURL + "UpdateColumnByOrg/", {
      content: CreateFields_Columns,
      submittedBy: userdetaile
    });
  }

  ExportCreateColumnByOrg(CreateFields_Columns) {
    return axios.put(baseAPIURL + "ExportCreateColumnByOrg/", {
      content: CreateFields_Columns,
      submittedBy: userdetaile
    });
  }

  ExportTransactionColumnByOrg(CreateFields_Columns) {
    return axios.put(baseAPIURL + "ExportTransactionColumnByOrg/", {
      content: CreateFields_Columns,
      submittedBy: userdetaile
    });
  }

  GetColumnsByOrg() {
    // console.log(baseAPIURL + "GetColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
    return axios.get(baseAPIURL + "GetColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }
  GetBrowsColumnsByOrg() {
    // console.log(baseAPIURL + "GetBrowseColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
    return axios.get(baseAPIURL + "GetBrowseColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }
  GetTransactionColumnsByOrg() {
    // console.log(baseAPIURL + "GetTransactionBrowseColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
    return axios.get(baseAPIURL + "GetTransactionBrowseColumnDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteColumnByOrg(gkey) {
    return axios.delete(baseAPIURL + "DeleteColumn/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new ColumnServices();