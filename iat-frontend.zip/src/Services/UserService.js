import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
//SCREEN ID -3038
class UserService {
  AllUsersbyOrg(OrgID) {
    console.log('OrgID :' + OrgID)
    return axios.get(baseAPIURL + "AllUsersbyOrg/OrgID/" + OrgID + "/token/" + userToken)
  }

  CreateUsersbyOrg(UserData,firebaseuid) {
    // console.log(">>> CreateUsersbyOrg service"+JSON.stringify(UserData))
    UserData.firebaseid=firebaseuid
    // console.log(">>>CreateUsersbyOrg 2 :"+JSON.stringify(UserData))
    // console.log(baseAPIURL + "CreateUserByOrg/userdata/CT");
    return axios.post(baseAPIURL + "CreateUserByOrg/", {
      content: UserData,
      submittedBy: window.localStorage.getItem("user Details")
    });
  }

  UpdateUsersbyOrg(UserData) {
    return axios.put(baseAPIURL + "UpdateUserByOrg/", {
      content: UserData[0],
      submittedBy: window.localStorage.getItem("user Details")
    });
  }

  DeleteUserByOrg(gkey) {
    console.log(baseAPIURL + "DeleteUser/gkey/" + gkey + "/token/" + userToken);
    return axios.delete(baseAPIURL + "DeleteUser/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new UserService();