import ColumnServices from "../Services/ColumnServices";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const localConstant = geAxiosConstants();
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
//SCREEN ID -3051
export async function InsetBulkColumn(Data) {
  const Newdata = Data.map(data => ({
    shortName: data.shortName,
    displayName: data.displayName,
    control: data.control,
    Applie_To: data.Applie_To,
    value: data.value,
    mode: data.mode,
    bizunit_gkey: data.bizunit_gkey,
    updatedAt: new Date(2023, 1, 23)
  }));

  try {
    const response = await ColumnServices.ExportCreateColumnByOrg(Newdata);

    if (response.data === "400") {
      toast.error("Invalid Excel Data");
      return;
    }

    if (response.status === 200) {
      toast.success(`${Data.length} Valid Data Inserted successfully`);
    } else {
      toast.error("Invalid Excel Data");
    }

    return response.status;
  } catch (error) {
    console.log(error);
    // Handle error here
  }
}

