import { toast } from "react-toastify";
import OrganizationService from "../Services/OrganizationService";
//SCREEN ID -3052
export function SetMasterBizUnit(email) {
    OrganizationService.GetOrgIDByEmail(email).
        then(
            responsekey => {
                window.localStorage.setItem("MasterBizUitKey", responsekey.data[0]["bizunit_gkey"]);
                return GetOrgname(responsekey.data[0]["bizunit_gkey"]);
            }
        );
}
export function GetOrgname(orgid) {
    OrganizationService.GetOrgNamebyID(orgid).
        then(
            responseorg => {
                window.localStorage.setItem("OrganizationName", responseorg.data[0]["name"]);
                window.location = "/users/organization/" + responseorg.data[0]["name"]
                return responseorg.data[0]["name"];
            }
        );
}
//Added By mubarak 16/03/2023
export async function GetOrgDetailsbyEmail(email) {
    try {
        const response = await OrganizationService.GetOrgDetailsbyEmail(email);
        console.log(response.data)
        if (response.data === "Not Exist") {
            toast.warning("Not Exist In Organisation");
            return 404;
        }
        window.localStorage.setItem("MasterBizUitKey", response.data["Bizunit_gkey"]);
        window.localStorage.setItem("OrganizationName", response.data["Organization"]);
        window.localStorage.setItem("LoginUserName", response.data["UserName"]);
        window.localStorage.setItem("RoleGkey", response.data["RoleGkey"]);
        window.localStorage.setItem("RoleName", response.data["RoleName"]);
        // window.location = "/users/organization/" + response.data[1]["bizunit_Name"] firstName
        window.location = "dashboard/organization/" + response.data["Organization"] + "/Role/" + response.data["RoleName"]
        window.localStorage.setItem("navpath", "dashboard")
        return response.data["Organization"];
    } catch (error) {
        console.error(error);
        console.log(error.message);
    }
}