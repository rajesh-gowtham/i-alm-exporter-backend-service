import PrivilageService from "../Services/PrivilageService";

//SCREEN ID -3050
// Modified By Mubarak 13-04-2023
// Upadted by rajesh for storing Module , privilege raw data 
//  and Modified Privileges 
export function GetAllPrivilages() {
  return new Promise((resolve, reject) => {
    PrivilageService.GetAllPrivilages().then(response => {
      let Privilage_Module = {};
      Privilage_Module["Privilage"] = response.data[0];
      Privilage_Module["Module"] = response.data[1];
      let privilages = response.data[0];
      let modules = response.data[1];
      for (var i = 0; i < privilages.length; i++) {
        for (var j = 0; j < modules.length; j++) {
          if (privilages[i].module_Key == modules[j].gkey) {
            privilages[i]["module_name"] = modules[j].name;
          }
        }
      }
      let privilagesdata = [];
      for (var i = 0; i < privilages.length; i++) {
        let privilagestemp = {
          gkey: privilages[i].gkey,
          Privilege_Name: privilages[i].Privilege_Name,
          module_Key: privilages[i].module_Key,
          module_name: privilages[i].module_name,
          Lable: privilages[i].lable,
          Status: privilages[i].status,
          CanAdd: privilages[i].CanAdd,
          CanUpdate: privilages[i].CanUpdate,
          CanDelete: privilages[i].CanDelete,
          CanView: privilages[i].CanView,
          CanExcute: privilages[i].CanExcute,
        }
        privilagesdata.push(privilagestemp)
      }
      resolve({ privilages, modules, privilagesdata });
    }).catch(error => {
      reject(error);
    });
  });
}