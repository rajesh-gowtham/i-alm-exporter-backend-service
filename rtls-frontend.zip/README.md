# RTLS Portal Monorepo

A monorepo for Real-Time Location System (RTLS) applications, featuring a rich geospatial admin portal built with React, Vite, and Tailwind CSS, optimized for 3D visualization, mapping, and data analytics.

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Monorepo Structure](#monorepo-structure)
- [Installation](#installation)
- [Development](#development)
- [Building for Production](#building-for-production)
- [Docker Deployment](#docker-deployment)
- [Usage Examples](#usage-examples)
- [Dependencies](#dependencies)
- [Contributing](#contributing)
- [License](#license)

---

## Overview

This project is a **pnpm monorepo** containing multiple applications and shared packages for RTLS solutions. The primary focus is the **Admin Portal**, a modern web app for managing, visualizing, and analyzing real-time location data.

The Admin Portal leverages:
- **React 18** with **Vite** for fast development
- **Tailwind CSS** for styling
- **deck.gl**, **luma.gl**, **three.js** for 3D geospatial visualization
- **PocketBase** as backend service
- **Radix UI** for accessible components
- **Nivo** and **Recharts** for data visualization

---

## Features

- Real-time geospatial data visualization
- Interactive 3D maps and globe rendering
- Data analytics dashboards
- User-friendly UI with Radix components
- Integration with PocketBase backend
- Modular monorepo architecture
- Dockerized deployment with nginx

---

## Monorepo Structure

```
rtls-portal/
├── apps/
│   ├── admin/        # Main Admin Portal (React + Vite)
│   ├── driver/       # (Placeholder for driver app)
│   └── operator/     # (Placeholder for operator app)
├── packages/
│   └── shared/       # Shared libraries and code
├── package.json      # Monorepo root config
├── pnpm-workspace.yaml
├── Dockerfile        # Multi-stage Docker build
├── nginx.conf        # nginx configuration
└── ...
```

---

## Installation

1. **Install pnpm (recommended version 10.4.1 or higher):**

```bash
corepack enable
corepack prepare pnpm@latest --activate
```

2. **Install dependencies:**

```bash
pnpm install
```

---

## Development

To start the **Admin Portal** in development mode:

```bash
pnpm dev
```

This runs:

```bash
pnpm --filter rtls-admin dev
```

which launches the Vite dev server for the admin app.

---

## Building for Production

Build the Admin Portal:

```bash
pnpm --filter rtls-admin build
```

The output will be in `apps/admin/dist`.

---

## Docker Deployment

Build and run the Docker container:

```bash
docker build -t rtls-portal .
docker run -p 80:80 rtls-portal
```

This will serve the **Admin Portal** via nginx on port 80.

---

## Usage Examples

- Access the Admin Portal at `http://localhost`
- Visualize real-time location data on interactive 3D maps
- Manage devices, zones, and analytics dashboards
- Export data to Excel (`.xlsx`)
- Integrate with PocketBase backend for data management

---

## Dependencies

Key dependencies include:

- **React 18**
- **Vite**
- **Tailwind CSS**
- **deck.gl**, **luma.gl**, **three.js**, **three-globe**
- **PocketBase**
- **Radix UI**
- **Nivo**, **Recharts**
- **Zustand**, **SWR**, **Axios**
- **TypeScript**

See `apps/admin/package.json` for full list.

---

## Contributing

Contributions are welcome!

- Fork the repository
- Create a new branch (`git checkout -b feature/your-feature`)
- Commit your changes
- Push to your fork
- Open a Pull Request

Please follow code style guidelines enforced by ESLint and formatters.

---

## Notes

- The `driver` and `operator` apps are placeholders or under development.
- The monorepo uses **pnpm workspaces** for efficient dependency management.
- The Docker image only builds and serves the **Admin Portal**.