export const containerColorMap = {
  "Damaged containers": ["#8cb750"],
  "ODC Cargo": ["#FFAC1C"],

  "Empty": ["#95b94d", "#a0c34f", "#adcd4f", "#c0d74b", "#cdde52"],
  "Future Reefer": ["#dbe74d", "#eff54b", "#ffff4f", "#fdff48", "#fdf64d",  "#fdf64d",  "#fdf64d", "transparent"],
  "Hazardous Cargo": ["#ffe647", "#ffd94e", "#ffcf4e", "#fec14c", "#cb973c"],
  "Reefer Pre Trip Inspection": ["#dbe74d", "#eff54b", "#ffff4f", "#fdff48", "#fdf64d"],

  default: "#FFFFFF",
};


// Constants
export const INITIAL_CENTER: [number, number] = [76.9974, 8.3702];
export const INITIAL_ZOOM = 16;
export const INITIAL_MIN_ZOOM =1;
export const INITIAL_MAX_ZOOM=24;
export const MODIFIED_MIN_ZOOM = 18;
export const INITIAL_BEARING = 50.7852;
export const BASE64_PATTERN =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAG0lEQVQoU2NkYGBg+A8EHjIwMDC8B4oFAAw9AwiC5i02AAAAAElFTkSuQmCC";


export const YardCranes = [
    { id: 'CRMG-E01', yard:"1E", longitude: 76.9961, latitude: 8.3738 },
    { id: 'CRMG-E02', yard:"1E", longitude: 76.9970, latitude: 8.3727 },
    { id: 'CRMG-E03', yard:"2E", longitude: 76.9982, latitude: 8.3712 },
    { id: 'CRMG-E04', yard:"2E", longitude: 76.9988, latitude: 8.3705 },
    { id: 'CRMG-E05', yard:"3E", longitude: 76.9995, latitude: 8.3696 },
    { id: 'CRMG-E06', yard:"3E", longitude: 77.0008, latitude: 8.3680 },
    { id: 'CRMG-E07', yard:"1D", longitude: 76.9961, latitude: 8.3730 },
    { id: 'CRMG-E08', yard:"1D", longitude: 76.9970, latitude: 8.3719 },
    { id: 'CRMG-E09', yard:"2D", longitude: 76.9982, latitude: 8.3704 },
    { id: 'CRMG-E10', yard:"2D", longitude: 76.9987, latitude: 8.3698 },
    { id: 'CRMG-E11', yard:"3D", longitude: 76.9995, latitude: 8.3688 },
    { id: 'CRMG-E12', yard:"3D", longitude: 76.9999, latitude: 8.3683 },
    { id: 'CRMG-E13', yard:"1C", longitude: 76.9955, latitude: 8.3729 },
    { id: 'CRMG-E14', yard:"1C", longitude: 76.9964, latitude: 8.3718 },
    { id: 'CRMG-E15', yard:"2C", longitude: 76.9971, latitude: 8.3710 },
    { id: 'CRMG-E16', yard:"2C", longitude: 76.9974, latitude: 8.3706 },
    { id: 'CRMG-E17', yard:"3C", longitude: 76.9989, latitude: 8.3687 },
    { id: 'CRMG-E18', yard:"3C", longitude: 76.9999, latitude: 8.3675 },
    { id: 'CRMG-E19', yard:"1B", longitude: 76.9954, latitude: 8.3723 },
    { id: 'CRMG-E20', yard:"1B", longitude: 76.9957, latitude: 8.3719 },
    { id: 'CRMG-E21', yard:"2B", longitude: 76.9973, latitude: 8.3700 },
    { id: 'CRMG-E22', yard:"2B", longitude: 76.9976, latitude: 8.3696 },
    { id: 'CRMG-E23', yard:"3B", longitude: 76.9990, latitude: 8.3679 },
    { id: 'CRMG-E24', yard:"3B", longitude: 76.9993, latitude: 8.3675 },
    { id: 'CRMG-E25', yard:"1A", longitude: 76.9946, latitude: 8.3725 },
    { id: 'CRMG-E26', yard:"1A", longitude: 76.9956, latitude: 8.3713 },
    { id:  'CRMG-E27', yard:"2A", longitude: 76.9974, latitude: 8.3691 },
    { id:  'CRMG-E28', yard:"2A", longitude: 76.9977, latitude: 8.3687 },
    { id:  'CRMG-E29', yard:"3A", longitude: 76.9981, latitude: 8.3682 },
    { id:  'CRMG-E30', yard:"3A", longitude: 76.9992, latitude: 8.3669 },
  ];
 export  const QuayCranes = [
    { id: 'STS01', longitude: 76.99561, latitude: 8.3699 },
    { id: 'STS02', longitude: 76.9961, latitude: 8.3693 },
    { id: 'STS03', longitude: 76.99675, latitude: 8.3685 },
    { id: 'STS04', longitude: 76.997485, latitude: 8.3676 },
    { id: 'STS05', longitude: 76.99789, latitude: 8.3671 },
    { id: 'STS06', longitude: 76.99838, latitude: 8.3665 },
  ];

  export const ITVSData = [
    { id: 'T001', longitude: 76.996284117636733, latitude: 8.373240026063501, bearing: 0, LAYER: "L to R"  }, // Added bearing for rotation
    { id: 'T002', longitude: 76.996279, latitude: 8.374311, bearing: 0, LAYER: "L to R" },
    { id: 'T003', longitude: 76.996279, latitude: 8.374311, bearing: 0, LAYER: "L to R" },
    { id: 'TT104', longitude: 76.995859817180744,  latitude: 8.372795996344021, bearing: 0 , LAYER: "R to L" },

  ];


  export const iconLayout = {
    'icon-image':  [
      'match',
        ['get', 'LAYER'],
          'D to U', "itvL2R",
          'U to D', "itvL2R",
          'L to R', "itvL2R",
          'R to L', "itvR2L",
        "itvL2R" // default bearing if none match
          // 'itv-marker'
    ],
    'icon-size': [
      'interpolate',
      ['linear'],
      ['zoom'],
      16, 0.4,
      18, 0.8,
      19, 1,
      20, 1.25,
      21, 1.8,
      22, 2
    ],
    'icon-anchor': 'center',
    // 'icon-rotate': ['get', 'bearing']
    'icon-rotate': [
      'match',
        ['get', 'LAYER'],
          'D to U', 90,
          'U to D', -90,
          'L to R', 0,
          'R to L', 0,
        0 // default bearing if none match
    ],
    'icon-overlap': 'always',
  };


  export const VITE_GOOGLE_MAPS_KEY = "AIzaSyDuajCHEOAmY9-N1dFx4phFJq_nOYd6gGw";
  export interface EquipmentState {
    equipmentId: number;
    equipmentName: string;
    equipmentType: string;
    status: string;
    message: string;
    gpsTime: Date;
    latitude: number;
    longitude: number;
    altitude: number;
    heading: number;
    parameters: Record<string, any>;
  }