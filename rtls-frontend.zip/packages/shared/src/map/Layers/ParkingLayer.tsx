import GeoJsonLayer from "../GeoJsonLayer";
import { MODIFIED_MIN_ZOOM, INITIAL_MAX_ZOOM } from "../MapConstants";
import { getCentroidsFeatureCollection } from "../MapUtils";
import Parking from "../../data/geojsonnew/parking.json";

export default function ParkingLayer() {
      const ParkingCentroids = getCentroidsFeatureCollection(Parking);
  return (
    <>
      <GeoJsonLayer
                  id="Parking"
                  data={Parking}
                  minzoom={MODIFIED_MIN_ZOOM}
                  maxzoom={INITIAL_MAX_ZOOM}
                  type="fill"
                  paint={{ "fill-color": "#9adaef", "fill-opacity": 0.9 }}                      
                />
                <GeoJsonLayer
                  id="Parking-Label"
                  data={ParkingCentroids}
                  minzoom={MODIFIED_MIN_ZOOM}
                  maxzoom={INITIAL_MAX_ZOOM}
                  type="symbol"
                  layout={{
                    "text-field": ["get", "type"],
                    "text-size":[
                      "interpolate",
                      ["linear"],
                      ["zoom"],
                      18,10,   // Medium size at zoom 18
                      19,12,
                      20,14,
                      21,18,
                      22, 20      // Large size at zoom 22+
                    ],
                    'text-anchor': 'center',
                    'text-justify': 'center',
                    'text-offset': [0, 0],
                    "text-rotate":-90,
                    "text-transform":"uppercase",
                    
      
                    }}
      
      
                  paint={{ "text-color": "#36454F" }}                      
                />
    </>
  );
}
