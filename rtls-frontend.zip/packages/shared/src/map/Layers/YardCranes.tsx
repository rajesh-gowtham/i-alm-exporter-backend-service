import { INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, INITIAL_ZOOM, YardCranes } from "../MapConstants";
import ContainerCenereLine from "../../data/geojsonnew/centerline_yard.json";
import { snapPointsToLine } from "../MapUtils";
import GeoJsonLayer from "../GeoJsonLayer";

// Constants for crane configurations
const CRANE_CONFIGURATIONS = {
    DOUBLE_SIDED_YARDS: ['1D', '2D', '3D', '1E', '2E', '3E'],
    ROTATED_YARDS: {
        '1A': 179.5, '1C': 179.5, '2A': 179.5,
        '2C': 179.5, '3A': 179.5, '3C': 179.5
    },
    OFFSET_YARDS: {
        GROUP1: ['1A', '1C', '2A', '2C', '3A', '3C'],
        GROUP2: ['1B', '2B', '3B']
    }
};

// Layer style configurations
const CRANE_CENTER_LINE_STYLE = {
    paint: {
        "line-color": "#c0d1f7",
        "line-width": 3
    },
    layout: {
        "visibility": "none"
    }
};

const getIconImage = (yardNo: string) => {
    return CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.includes(yardNo) 
        ? 'double-side-yard-crane' 
        : 'single-side-yard-crane';
};

const getIconRotation = (yardNo: string) => {
    return CRANE_CONFIGURATIONS.ROTATED_YARDS[yardNo] || -0.5;
};

const getIconOffset = (yardNo: string) => {
    if (CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.includes(yardNo)) return [0, 10];
    if (CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.includes(yardNo)) return [0, 7];
    return [0, 0];
};

const ZOOM_SCALE = [
    { zoom: 16, size: 0.20 },
    { zoom: 17, size: 0.33 },
    { zoom: 18, size: 0.75 },
    { zoom: 19, size: 1.55 },
    { zoom: 20, size: 3.03 },
    { zoom: 21, size: 6.3 },
    { zoom: 22, size: 12.5 }
];

export default function YardCranesLayer() {
    const snappedCranes = snapPointsToLine(YardCranes, ContainerCenereLine);

    return (
        <>
            <GeoJsonLayer
                id="craneCenterLine"
                data={ContainerCenereLine}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={CRANE_CENTER_LINE_STYLE.paint}
                layout={CRANE_CENTER_LINE_STYLE.layout}
            />
            <GeoJsonLayer
                id="yard-cranes-layer"
                data={{
                    type: 'FeatureCollection',
                    features: snappedCranes
                }}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    'icon-image': ['match', ['get', 'yardNo'], 
                        ...CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.flatMap(yard => 
                            [yard, 'double-side-yard-crane']),
                        'single-side-yard-crane'
                    ],
                    'icon-rotate': ['match', ['get', 'yardNo'],
                        ...Object.entries(CRANE_CONFIGURATIONS.ROTATED_YARDS).flat(),
                        -0.5
                    ],
                    'icon-size': [
                        'interpolate',
                        ['linear'],
                        ['zoom'],
                        ...ZOOM_SCALE.flatMap(({zoom, size}) => [zoom, size])
                    ],
                    'icon-offset': ['match', ['get', 'yardNo'],
                        ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.map(yard => 
                            [yard, ['literal', [0, 10]]]).flat(),
                        ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.map(yard => 
                            [yard, ['literal', [0, 7]]]).flat(),
                        ['literal', [0, 0]]
                    ],
                    'icon-allow-overlap': false,
                    'icon-anchor': 'center',
                }}
                paint={{}}
            />
        </>
    );
}
