import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MAX_ZOOM, INITIAL_ZOOM, QuayCranes } from "../MapConstants";

export default function QuayCrane({ active = [] }) {
   
    const quayCranesData = {
        type: 'FeatureCollection',
        features: QuayCranes.map(crane => ({
            type: 'Feature',
            geometry: {
                type: 'Point',
                coordinates: [crane.longitude, crane.latitude]
            },
            properties: {
                id: crane.id,
                isActive: active.includes(crane.id)
            }
        }))
    };

    const iconLayout = {
        'icon-image': ['case',
    ['boolean', ['get', 'isActive'], false],
    'quay-crane-active', // if isActive is true
    'quay-crane' ],
        'icon-size': [
            'interpolate',
            ['linear'],
            ['zoom'],
            16, 0.22,    // Small size at zoom 16
            17, 0.3,
            18, 0.8,     // Medium size at zoom 18
            19, 1.25,
            20, 1.4,
            21, 1.7,
            22, 2        // Large size at zoom 22+
        ],
        'icon-allow-overlap': true,
        'icon-anchor': 'center',
        'icon-rotate': 180,
        'icon-overlap': 'always',
    };

    return (
        <GeoJsonLayer
            id="Quay-cranes-layer"
            data={quayCranesData}
            minzoom={INITIAL_ZOOM}
            maxzoom={INITIAL_MAX_ZOOM}
            type="symbol"
            layout={iconLayout}
            paint={{}}
        />
    );
}
