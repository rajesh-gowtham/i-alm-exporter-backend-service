import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MAX_ZOOM, MODIFIED_MIN_ZOOM } from "../MapConstants";
import { getCentroidsFeatureCollection } from "../MapUtils";
import GeoFences from "../../data/geojsonnew/geofense_service.json";

export default function GeoFencesLayer() {
  const GeoFencesCentroids = getCentroidsFeatureCollection(GeoFences);
  return (
    <>
     {/*
              <GeoJsonLayer
                id="GeoFences"
                data={GeoFences}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{ "fill-color": "#ecfecb", "fill-opacity": 0.9 }}
              />
              <GeoJsonLayer
                id="GeoFences-outline"
                data={GeoFences}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={{ "line-color": "#538d3d", "line-width": 4 }}
              /> */}
              <GeoJsonLayer
            id="GeoFencesLabel"
            data={GeoFencesCentroids}
            minzoom={MODIFIED_MIN_ZOOM}
            maxzoom={INITIAL_MAX_ZOOM}
            type="symbol"
            layout={{
              "text-field": ["get", "name"] ,
              "text-size": [
                "interpolate",
                ["linear"],
                ["zoom"],
                17, 10,
                20, 14
              ],
              'text-anchor': 'center',
              'text-justify': 'center',
              'text-offset': [0, 0],
              "symbol-placement": "point",
              "symbol-avoid-edges": true,
            }}
            paint={{
              "text-color": "#000000",
              "text-halo-color": "#ffffff",
              "text-halo-width": 1,
              "text-halo-blur": 0.5,
            }}
          />
           
    </>
  );
}