import GeoJsonLayer from "../GeoJsonLayer";
import ContainerYard from "../../data/geojsonnew/container_yards.json";
import Containers from "../../data/geojsonnew/container.json";
import ContainersType from "../../data/geojsonnew/container_type.json";
import ContainerYardCentroids from "../../data/geojsonnew/container_yards_point.json";
import ContainerTypeLabel from "../../data/geojsonnew/container_type_point.json";
import ContainerPositionLabel from "../../data/geojsonnew/container_position_v1.json";
import { containerColorMap, INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, MODIFIED_MIN_ZOOM , INITIAL_ZOOM} from "../MapConstants";
import { useMemo } from "react";

export default function ContainerLayer() {
    function buildContainerFillColorExpression() {
        const expressions: any[] = ["case"];

        for (const [type, colors] of Object.entries(containerColorMap)) {
            if (type === "Damaged containers") {
                expressions.push(["==", ["get", "type"], type], colors[0]);
            } else if (type === "ODC Cargo") {
                expressions.push(["==", ["get", "type"], type], colors[0]);
            } else if (type === "default") {
                continue;
            } else {
                colors.forEach((color, index) => {
                    // console.log(`Adding color for type: ${type}, index: ${index}`, color);
                    expressions.push(
                        ["all", ["==", ["get", "type"], type], ["==", ["get", "stack_valu"], index]],
                        color
                    );
                });
            }
        }

        // Fallback
        expressions.push(containerColorMap.default);
        return expressions;
    }

    const containerTypeFillColor = useMemo(() => buildContainerFillColorExpression(), []);

    return (
        <>
            <GeoJsonLayer
                id="ContainerYard"
                data={ContainerYard}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                    "fill-outline-color": "#808080",
                    "fill-color": "#808080",
                    "fill-opacity": 0.1
                }}
            />
            <GeoJsonLayer
                id="Containers"
                data={Containers}
                minzoom={16}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                layout={{
                   
                }}
                paint={{
                    "fill-color": [
                        "step",
                        ["get", "stack_valu"],
                        "#FFFFFF", 0, "#FFFFFF",
                        1, "#709859",
                        2, "#f2eea2",
                        3, "#f5cb84",
                        4, "#c28b78",
                        5, "#c28b78"
                    ],
                    "fill-outline-color": "transparent",
                    
                }}
            />
            <GeoJsonLayer
                id="ContainersType"
                data={ContainersType}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                    "fill-color": containerTypeFillColor,
                    "fill-outline-color": "transparent",
                }}
            />
            <GeoJsonLayer
                id="ContainersType-border"
                data={ContainersType}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                filter={['all', ['==', ['get', 'stack_valu'], 7], ['==', ['get', 'type'], 'Future Reefer']]} 
                paint={{
                    'line-color': '#df6d72',
                    'line-width': [
                        "interpolate",
                        ["linear"],
                        ["zoom"],
                        16,.25,18,.5,20,1,22,1.25,24,1.5
                    ]
                }}
            />
            <GeoJsonLayer
                id="ContainersType-cross-line"
                data={ContainersType}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                filter={['all', ['==', ['get', 'stack_valu'], 7], ['==', ['get', 'type'], 'Future Reefer']]}
                type="line"
                paint={{
                   'line-color': '#df6d72',
                    'line-width': [
                        "interpolate",
                        ["linear"],
                        ["zoom"],
                        16,.25,18,.5,20,1,22,1.25,24,1.5
                    ],
                    'line-dasharray': [2, 2]
                }}
            />
            <GeoJsonLayer
                id="ContainerYardLabel"
                data={ContainerYardCentroids}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                    "text-size": 14,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "ID"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always"
                    
                }}
                paint={{
                    "text-color": "#000000",
                    "text-halo-color": "#ffffff",
                    "text-halo-width": 2,
                    "text-halo-blur": 0.5,
                }}
            />
            <GeoJsonLayer
                id="ContainerTypeLabel"
                data={ContainerTypeLabel}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["get", "Label"],
                    "text-size": 10,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "Label"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always"
                }}
                paint={{
                    "text-color": "#000000",
                    "text-halo-color": "#ffffff",
                    "text-halo-width": 2,
                    "text-halo-blur": 0.5,
                }}
            />
            <GeoJsonLayer
                id="ContainerPositionLabel"
                data={ContainerPositionLabel}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "Label"], ["get", "Label"], ""],
                    "text-size": 12,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "Label"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always"
                    
                }}
                paint={{
                    "text-color": "#71797E",
                    "text-halo-color": "#ffffff",
                    "text-halo-width": 2,
                    "text-halo-blur": 0.5,
                }}
            />
        </>
    );
}
