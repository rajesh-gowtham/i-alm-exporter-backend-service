import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MAX_ZOOM, MODIFIED_MIN_ZOOM , iconLayout} from "../MapConstants";
import TruckPoints from "../../data/geojsonnew/itv_trucks.json";

export default function ITVLayer() {
  

  

  return (
    <GeoJsonLayer
      id="itv-layer"
      data={TruckPoints}
      minzoom={MODIFIED_MIN_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      type="symbol"
      layout={iconLayout}
      paint={{}}
    />
  );
}
