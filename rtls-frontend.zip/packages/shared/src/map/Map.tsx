// MapComponent.tsx
import { useEffect, useState, useRef, useMemo } from "react";
import useSWRMutation from "swr/mutation";
import {
  RMap,
  RMapContextProvider} from "maplibre-react-components";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  googleProtocol,
  createGoogleStyle
} from "maplibre-google-maps";

// GeoJSON Data
import ITV from "../data/geojsonnew/flat-bed-truck.svg";
import IVTL2R from "../data/geojsonnew/itvL2R.png";
import ITVR2L from "../data/geojsonnew/itvR2L.png";
import QuayCraneImg from "../data/geojsonnew/QuayCrane-red.png";
import SingleSideYardCarneImg from "../data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "../data/geojsonnew/DoubleSideYardCrane-red.png";
import RFIDICON from "../data/geojsonnew/wifi.png";
import WIFIICON from "../data/geojsonnew/network.png";
import ServiceLaneIcon from "../data/geojsonnew/blueboxServiceLanes.svg";
import PlatformLanePattern from "../data/geojsonnew/platformdiagonal.svg";
import useSWR from "swr";


// Components
import BaseMapToggle from "./BaseMapToggle";
import MapControls from "./MapControls";
import LocationForm from "./LocationForm";
import ContainerLayer from "./Layers/ContainerLayer";
import RoadLane from "./Layers/RoadLane";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import HatchedAreaLayer from "./Layers/HatchedArea";
import DividerLayer from "./Layers/DividerLayer";
import ParkingLayer from "./Layers/ParkingLayer";
import RFIDLayer from "./Layers/RFIDLayer";
import PlatformLayer from "./Layers/PlatformLayer";
import GeoFencesLayer from "./Layers/GeoFencesLayer";
import axiosInstance from '../../../../apps/admin/src/lib/http-client'; 
import {
  INITIAL_CENTER,
  INITIAL_ZOOM,
  INITIAL_BEARING,
  BASE64_PATTERN,
  VITE_GOOGLE_MAPS_KEY,
  iconLayout,
  INITIAL_MAX_ZOOM,
  EquipmentState,
  MODIFIED_MIN_ZOOM,
  INITIAL_MIN_ZOOM
} from "./MapConstants";
import { loadSpriteImgs } from "./MapUtils";
import GeoJsonLayer from "./GeoJsonLayer";
import {useEquipmentGeoJSON} from "./MapUtils";


// Types
type LocationData = {
  name: string;
  description: string;
  latitude: number;
  longitude: number;
};

maplibregl.addProtocol("google", googleProtocol);

// Mock save API
const mockSaveLocation = async (data: LocationData) => {
  return new Promise<{ message: string; data: LocationData }>((resolve) => {
    setTimeout(() => {
      console.log("📌 Mock API Response:", data);
      resolve({ message: "Location saved", data });
    }, 1000);
  });
};

export default function MapComponent({height}) {
  const [selectedPoint, setSelectedPoint] = useState<{ lat: number; lng: number } | null>(null);
  const [showBaseMap, setShowBaseMap] = useState(false);
  const mapRef = useRef<any>(null);
  const { ITVGEOJSON, isLoading, error } = useEquipmentGeoJSON();
  console.log("ITVGEOJSON", ITVGEOJSON);
  
  const { trigger, isMutating } = useSWRMutation("/save-location", (_, { arg }) =>
    mockSaveLocation(arg)
  );

  const handleResetView = () => {
    mapRef.current?.flyTo({
      center: INITIAL_CENTER,
      zoom: INITIAL_ZOOM,
      bearing: INITIAL_BEARING,
      duration: 1000
    });
  };

  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs('quay-crane', QuayCraneImg, 80, 350, map);
      loadSpriteImgs('single-side-yard-crane', SingleSideYardCarneImg, 40, 205, map);
      loadSpriteImgs('double-side-yard-crane', DoubleSideYardCraneImg, 40, 225, map);
      loadSpriteImgs('itv-marker', ITV, 64, 64, map);
      loadSpriteImgs("diagonal-stripe", BASE64_PATTERN, 8, 8, map);
      loadSpriteImgs("boxed-stripe", ServiceLaneIcon, 32, 32, map);
      loadSpriteImgs("platform-stripe", PlatformLanePattern, 6, 6, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
      loadSpriteImgs("itvL2R", IVTL2R, 64, 64, map);
      loadSpriteImgs("itvR2L", ITVR2L, 64, 64, map);
    });
  }, []);

  const handleSaveLocation = async (data: LocationData) => {
    try {
      await trigger(data);
      alert("Location saved successfully!");
      console.log("📌 Location Data:", data);
      setSelectedPoint(null);
    } catch (error) {
      console.error("Error saving location:", error);
    }
  };

  return (
    <RMapContextProvider>
      <div className="relative">
        <BaseMapToggle showBaseMap={showBaseMap} onToggle={() => setShowBaseMap(!showBaseMap)} />
        <RMap
          ref={mapRef}
          style={{ width: "100%", minHeight: height==='waterside' ? '300px' : '500px', height: "100%", backgroundColor: showBaseMap ? "transparent" : "white" }}
          mapStyle={
            showBaseMap
              ? {
                ...createGoogleStyle("google", "satellite", VITE_GOOGLE_MAPS_KEY),
                glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
              }

              : {
                  version: 8,
                  sources: {},
                  layers: [],
                  glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf"
                }
          }
          initialCenter={INITIAL_CENTER}
          initialZoom={INITIAL_ZOOM}
          initialAttributionControl={false}
          initialBearing={INITIAL_BEARING}
          initialPitch={0}
          dragRotate={false}
          touchZoomRotate={false}
        >
          <PlatformLayer />
          <ContainerLayer />
          <RoadLane />
          <HatchedAreaLayer />
          <DividerLayer />
          <ParkingLayer />
          <RFIDLayer />
         
          <GeoFencesLayer />
          <GeoJsonLayer
            id="itv-layers"
            data={ITVGEOJSON}
            minzoom={INITIAL_ZOOM}
            maxzoom={INITIAL_MAX_ZOOM}
            type="symbol"
            layout={iconLayout}
            paint={{}}
          />
          <QuayCrane />
          <YardCranesLayer />
          
            
          <MapControls onResetView={handleResetView} />
        </RMap>

        {selectedPoint && (
          <LocationForm
            selectedPoint={selectedPoint}
            onSave={handleSaveLocation}
            isSaving={isMutating}
            onClose={() => setSelectedPoint(null)}
          />
        )}
      </div>
    </RMapContextProvider>
  );
}