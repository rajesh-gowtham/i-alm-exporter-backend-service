// ImageMarker.tsx
import React from "react";
import { RMarker } from "maplibre-react-components";

interface ImageMarkerProps {
  longitude: number;
  latitude: number;
  imageSrc: string;
  altText: string;
  className?: string;
  rotation?: number;
}

const ImageMarker: React.FC<ImageMarkerProps> = ({ longitude, latitude, imageSrc, altText, className, rotation }) => {
  const style = rotation ? { transform: `rotate(${rotation}deg)` } : {};
  return (
    <RMarker longitude={longitude} latitude={latitude} draggable={false}>
      <img src={imageSrc} alt={altText} className={className} style={style} />
    </RMarker>
  );
};

export default ImageMarker;