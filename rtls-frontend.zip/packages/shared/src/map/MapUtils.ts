import * as turf from '@turf/turf';
import { useMemo } from 'react';
import useSWR from 'swr';
import axiosInstance from '../lib/http-client'; // Adjust the import path as necessary
import {EquipmentState} from "./MapConstants";
interface Properties {
    [key: string]: any;
}

interface Feature {
    type: "Feature";
    geometry: any;
    properties: Properties;
}

interface FeatureCollection {
    type: string;
    features: Feature[];
}

export function getCentroidsFeatureCollection(featureCollection: FeatureCollection): FeatureCollection {
    return turf.featureCollection(
        featureCollection.features.map(feature =>
            turf.centroid(feature, { properties: feature.properties })
        )
    );
}


interface Crane {
  id: string | number;
  longitude: number;
  latitude: number;
  yard: string;
}

interface SnappedFeatureProperties {
  id: string | number;
  originalLongitude: number;
  originalLatitude: number;
  yardNo: string;
}

export function snapPointsToLine(
  points: Crane[],
  line: turf.Feature<turf.LineString> | turf.LineString,
  options: turf.NearestPointOnLineOptions = { units: 'meters' }
): turf.Feature<turf.Point, SnappedFeatureProperties>[] {
  return points.map((point) => {
    const targetPoint = turf.point([point.longitude, point.latitude]);
    const snapped = turf.nearestPointOnLine(line, targetPoint, options);

    return {
      type: 'Feature',
      geometry: snapped.geometry,
      properties: {
        id: point.id,
        originalLongitude: point.longitude,
        originalLatitude: point.latitude,
        yardNo: point.yard,
      },
    };
  });
}



export function loadSpriteImgs(
  name: string,
  imageSrc: string,
  imgWidth: number,
  imgHeight: number,
  map: maplibregl.Map | null
): void {
  if (!map || map.hasImage(name)) return;

  const image = new Image(imgWidth, imgHeight);
  image.onload = (): void => {
    map.addImage(name, image, { pixelRatio: 1, sdf: false });
  };
  image.onerror = (err) => {
    console.error(`Failed to load sprite image: ${imageSrc}`, err);
  };
  image.src = imageSrc;
}


export function useEquipmentGeoJSON() {

  function convertToGeoJSON(equipmentList: EquipmentState[]) {
  const ItvJson = {
    type: "FeatureCollection",
    features: equipmentList.map((item) => ({
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [item.longitude, item.latitude], // GeoJSON uses [lon, lat]
        // coordinates: [76.995859817180744,8.372795996344021], // GeoJSON uses [lon, lat]
      },
      properties: {
        equipmentId: item.equipmentId,
        equipmentName: item.equipmentName,
        equipmentType: item.equipmentType,
        status: item.status,
        message: item.message,
        gpsTime: item.gpsTime,
        altitude: item.altitude,
        heading: item.heading,
        parameters: item.parameters,
        LAYER: item.parameters?.LAYER ?? "R to L", 
      },
    })),
  };

  return ItvJson;
}
  interface CustomError extends Error {
    info?: any;
    status?: number;
  }

  const fetcher = (url: string) =>
  axiosInstance.get(url).then(async (res) => {
    if (res.status !== 200) {
      const error = new Error("An error occurred while fetching the data.") as CustomError;
      error.info = await res.data;
      error.status = res.status;
      throw error;
    }
    return res.data;
  });

  const { data, error, isLoading } = useSWR<EquipmentState[]>(
    "/equipment/states",
    fetcher,
    {
      refreshInterval: 30000, // 30 seconds
    }
  );

  const ITVGEOJSON = useMemo(() => {
    if (!data) return null;
    return convertToGeoJSON(data);
  }, [data]);

  return {
    data,
    ITVGEOJSON,
    error,
    isLoading,
  };
}