// stores/useMapPopupStore.ts
import { create } from 'zustand';

interface PopupProperties {
  equipmentName: string;
  ignition: string;
  operationalState: string;
  gpsTime: string;
}

interface PopupState {
  popupInfo: {
    longitude: number;
    latitude: number;
    properties: PopupProperties;
  } | null;
  setPopupInfo: (info: PopupState['popupInfo']) => void;
  clearPopupInfo: () => void;
}

export const useMapPopupStore = create<PopupState>((set) => ({
  popupInfo: null,
  setPopupInfo: (info) => set({ popupInfo: info }),
  clearPopupInfo: () => set({ popupInfo: null }),
}));
