"use client";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerClose, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format, parse } from "date-fns";
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

export default function UserContentsDrawer({ open, setOpen, selectedUser, onItemSelectOnClick, selectedContent, moduleName }) {
  const formatDate = (dateString) => {
    if (!dateString) return ""; // Handle null or undefined values
    let parsedDate;
    try {
      parsedDate = parse(dateString, "MMM dd yyyy hh:mma", new Date());
      if (isNaN(parsedDate.getTime())) {
        parsedDate = parse(dateString, "MM/dd/yyyy HH:mm:ss", new Date());
      }
      if (isNaN(parsedDate.getTime())) {
        console.error("Invalid date format:", dateString);
        return "Invalid Date";
      }
      return format(parsedDate, "dd MMM yyyy");

    } catch (error) {
      console.error("Date parsing error:", error);
      return "Invalid Date";
    }
  };
  const toPascalCase = (text) => {
    return text
      .toLowerCase() // Ensure lowercase for consistency
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize each word
  };
  // console.log(selectedContent.chartData);
  return (
    <Drawer direction="right" open={open} onOpenChange={setOpen}>
      <DrawerContent className="top-0 right-0 fixed bg-white shadow-lg border-l h-full">
        <DrawerHeader className="flex justify-between items-center p-4 border-b">
          <DrawerTitle > <span className="underline underline-offset-4"> User Content Details </span>
            <span className="font-bold text-black/55 text-sm">{'(' + selectedUser.loginId + ')'}</span>
          </DrawerTitle>
          <DrawerClose asChild>
            <Button variant="outline" size="sm">Close</Button>
          </DrawerClose>
        </DrawerHeader>

        <div className="p-4 max-h-[500px] overflow-auto">
          <Table>
            <TableHeader className={'border border-black/30 '}>
              <TableRow >
                <TableHead>Content Name</TableHead>
                <TableHead>Attempt Rem.</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>End Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {selectedUser?.userContents?.map((content, ind) => (
                <TableRow onClick={() => { onItemSelectOnClick(content, 'UserContent') }} key={ind}
                  className={`border border-black/30 rounded-4xl cursor-pointer ${selectedContent.name === content.name ? ' bg-blue-100 shadow ' : ' '}`}>
                  <TableCell>{content.name}</TableCell>
                  <TableCell className={' flex items-center justify-center w-full'}>{content.attemptRemains ?? '-'}</TableCell>
                  <TableCell>{formatDate(content.startDate)}</TableCell>
                  <TableCell>{formatDate(content.toDate)}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-[3px] rounded-md text-xs font-medium ${content.result === "PASS"
                        ? "bg-green-200 text-green-800"
                        : content.result === "FAIL"
                          ? "bg-red-200 text-red-800"
                          : "bg-yellow-200 text-yellow-800"
                        }`}
                    >
                      {content?.startDate ?
                        (content?.result === 'Invalid Input' ? 'Test not taken' : (content?.result ?? 'Test not taken')) :
                        'UnScheduled'}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div >

        {selectedContent?.chartData && selectedContent?.chartData?.length > 0 && (
          <div className="flex flex-col justify-center items-center pt-8 border-t border-black/30 w-full h-[45%]">
            <ResponsiveContainer className={'shadow-lg bg-teal-50 rounded-lg'} width="80%" height={220}>
              < span className="shadow-lg mb-4 p-2 font-semibold text-lg">{selectedContent?.name}</span>
              {moduleName?.includes('CB') || moduleName?.includes('cb') ?
                <PieChart className="p-4">
                  <Pie
                    data={selectedContent.chartData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    innerRadius={40}
                    label={({ name, percent }) => `${toPascalCase(name)} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                    animationDuration={600}
                  >
                    {selectedContent?.chartData?.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.color}
                        stroke="#fff"
                        style={{
                          transition: "all 0.3s ease-in-out",
                        }}
                        onMouseEnter={(e) => (e.target.style.opacity = 0.7)}
                        onMouseLeave={(e) => (e.target.style.opacity = 1)}
                      />
                    ))}
                  </Pie>

                  <Tooltip
                    formatter={(value, name) => [value, toPascalCase(name)]}
                    contentStyle={{
                      backgroundColor: "#fff",
                      borderRadius: "5px",
                      padding: "18px",
                      boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                    }}
                  />

                  <Legend height={'2%'} formatter={(value) => toPascalCase(value)} />
                </PieChart>
                :
                <div className="bg-teal-50 h-full overflow-y-auto">
                  {selectedContent?.chartData?.map((item, ind) => (
                    <div key={ind} className="space-y-1 px-1.5 border border-black/30 text-black"
                      dangerouslySetInnerHTML={{ __html: item?.result }}>
                    </div>
                  ))}
                </div>
              }
            </ResponsiveContainer>
          </div>)
        }
      </DrawerContent >
    </Drawer >
  );
}