import { ChevronRight, ExternalLink, Home, Search } from "lucide-react";
import { Card, CardContent, CardHeader } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { useState } from "react";
import { MdGroups } from "react-icons/md";
const UserListTable = ({ selectedGroup, onItemSelectOnClick }) => {
    const [search, setSearch] = useState("");

    const filteredUsers = selectedGroup?.userScheduleModel.filter((user) =>
        user.userName?.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <Card className="px-1 py-1.5 h-full">
            <CardHeader className="flex justify-start items-center gap-3 px-2">
                <nav className="flex justify-between items-center mt-0.5 p-2 border-b border-black/30 w-full font-medium text-blue-500 text-sm">
                    <div className="flex items-center">
                        <button onClick={() => { onItemSelectOnClick('', 'BackToHome') }} className="flex items-center gap-1 hover:text-blue-700 transition-all">
                            <MdGroups size={20} />
                            Groups
                        </button>
                        <ChevronRight size={18} className="mx-1 text-gray-400" />
                        <button className="border border-blue-800 hover:text-blue-700 decoration-1 underline transition-all">
                            {selectedGroup?.name}
                        </button>
                    </div>

                    <div>
                        <div className="relative">
                            <Search className="top-[8px] left-2 absolute w-4 h-4 text-gray-400" />
                            <input
                                type="search"
                                placeholder="Search users..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                className="px-1 py-1 pl-8 border border-gray-300 rounded-md w-48 text-gray-700"
                            />
                        </div>
                    </div>
                </nav>
            </CardHeader>

            <CardContent className="p-2 overflow-auto">
                {filteredUsers?.length > 0 ? (
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Login ID</TableHead>
                                <TableHead>Name</TableHead>
                                <TableHead>Role</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead>User Result</TableHead>
                                <TableHead>Action</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredUsers.map((user) => (
                                <TableRow key={user.loginId}>
                                    <TableCell>
                                        <span className="px-2 py-[1px] border border-black/20 rounded-sm">
                                            {user.loginId}
                                        </span>
                                    </TableCell>
                                    <TableCell>{user.userName}</TableCell>
                                    <TableCell>{user.userType}</TableCell>
                                    <TableCell>{user.email}</TableCell>
                                    <TableCell>
                                        <span
                                            className={`px-2 py-[3px] items-center rounded-md text-xs font-medium 
                                        ${user.userResult === "PASS"
                                                    ? "bg-green-200 text-green-800"
                                                    : user.userResult === "FAIL"
                                                        ? "bg-red-200 text-red-800"
                                                        : "bg-yellow-200 text-yellow-800"
                                                }`}
                                        >
                                            {user.userResult}
                                        </span>
                                    </TableCell>
                                    <TableCell>
                                        <span
                                            className="flex justify-center items-center space-x-2 hover:bg-blue-400 px-1.5 py-1 border border-blue-400/20 rounded-md hover:text-white cursor-pointer"
                                            onClick={() => onItemSelectOnClick(user, "User")}
                                        >
                                            <span>View</span>
                                            <ExternalLink size={16} />
                                        </span>
                                    </TableCell>
                                </TableRow>
                            ))}

                        </TableBody>
                    </Table>
                ) : (
                    <p className="text-gray-500 text-center">No Users found.</p>
                )}
            </CardContent>
        </Card>
    );
};

export default UserListTable;



// import React from 'react';
// import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
// import { ArrowLeft, ExternalLink } from 'lucide-react';
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';

// const UserListTable = ({ selectedGroup, onItemSelectOnClick, onBack }) => {
//     return (
//         <Card className="h-[400px]">
//             {/* Back Button + Title */}
//             <CardHeader className="flex items-center gap-3">
//                 <button
//                     onClick={onBack}
//                     className="flex items-center gap-1 text-blue-500 hover:text-blue-700 transition-all duration-300"
//                 >
//                     <ArrowLeft size={20} />
//                     <span className="font-medium">Back to Groups</span>
//                 </button>
//                 <CardTitle className="underline underline-offset-4">{selectedGroup?.name}:</CardTitle>
//             </CardHeader>

//             <CardContent className="max-h-[320px] overflow-auto">
//                 <Table>
//                     <TableHeader>
//                         <TableRow>
//                             <TableHead>Login ID</TableHead>
//                             <TableHead>Name</TableHead>
//                             <TableHead>Role</TableHead>
//                             <TableHead>Email</TableHead>
//                             <TableHead>Status</TableHead>
//                             <TableHead>Action</TableHead>
//                         </TableRow>
//                     </TableHeader>
//                     <TableBody>
//                         {selectedGroup?.userScheduleModel?.map((user) => (
//                             <TableRow key={user.loginId}>
//                                 <TableCell>
//                                     <span className="px-2 py-[1px] border border-black/20 rounded-sm">{user.loginId}</span>
//                                 </TableCell>
//                                 <TableCell>{user.userName}</TableCell>
//                                 <TableCell>{user.userRole}</TableCell>
//                                 <TableCell>{user.email}</TableCell>
//                                 <TableCell>
//                                     <span className={`px-2 py-[3px] rounded-md text-xs font-medium
//                                         ${user.status === "passed" ? "bg-green-200 text-green-800"
//                                         : user.status === "failed" ? "bg-red-200 text-red-800"
//                                         : "bg-yellow-200 text-yellow-800"}`}>
//                                         {user.status}
//                                     </span>
//                                 </TableCell>
//                                 <TableCell>
//                                     <span
//                                         className="flex justify-center items-center space-x-2 hover:bg-blue-400 px-1.5 py-1 border border-blue-400/20 rounded-md hover:text-white cursor-pointer"
//                                         onClick={() => onItemSelectOnClick(user)}
//                                     >
//                                         <span>View</span>
//                                         <ExternalLink size={16} />
//                                     </span>
//                                 </TableCell>
//                             </TableRow>
//                         ))}
//                     </TableBody>
//                 </Table>
//             </CardContent>
//         </Card>
//     );
// };

// export default UserListTable;
