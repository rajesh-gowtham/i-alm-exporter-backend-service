import { useState } from "react";
import { Search, ExternalLink, Home, ChevronRight } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/card";
import { MdGroups } from "react-icons/md";


export default function UserGroupsList(props) {
    const [search, setSearch] = useState("");

    const filteredGroups = props.groupList.filter((group) =>
        group.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <Card className="px-1 py-1.5 h-full overflow-y-hidden">
            <CardHeader className="flex justify-start items-center gap-3 px-2">
                <nav className="flex justify-between items-center mt-0.5 p-2 border-b border-black/30 w-full font-medium text-blue-500 text-sm">
                    <div className="flex items-center">
                        <button onClick={() => { props.onItemSelectOnClick('', 'BackToHome') }} className="flex items-center gap-1 hover:text-blue-700 transition-all">
                            <MdGroups size={20} />
                            Groups
                        </button>
                    </div>

                    <div>
                        <div className="relative">
                            <Search className="top-[8px] left-2 absolute w-4 h-4 text-gray-400" />
                            <input
                                type="search"
                                placeholder="Search groups..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                className="px-1 py-1 pl-8 border border-gray-300 rounded-md w-48 text-gray-700"
                            />
                        </div>
                    </div>
                </nav>
            </CardHeader>
            <div className="space-y-3.5 px-3 py-2 w-full overflow-y-auto">
                {filteredGroups?.length > 0 ? (
                    filteredGroups.map((group) => (
                        <div key={group.name} onClick={() => { props.onItemSelectOnClick(group, "Group") }} className="flex justify-between items-center bg-white hover:bg-gray-100 active:bg-gray-200 shadow-sm hover:shadow-md px-3 py-2.5 border rounded-md hover:scale-[1.02] active:scale-95 transition-all duration-300 ease-in-out cursor-pointer">
                            <span className="font-medium text-gray-800">{group.name}</span>
                            <ExternalLink className="text-blue-500 hover:text-blue-600 transition-all duration-300" size={20} />
                        </div>
                    ))
                ) : (
                    <p className="text-gray-500 text-center">No groups found.</p>
                )}
            </div>
        </Card>
    );
}