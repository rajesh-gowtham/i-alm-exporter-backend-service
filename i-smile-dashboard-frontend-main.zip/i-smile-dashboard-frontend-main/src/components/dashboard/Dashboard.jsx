import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import MainService from "@/service/MainService";
import { BookOpenCheck, CalendarCheck2, FolderCheck, Users } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

// Lazy load components
const UserGroupChart = React.lazy(() => import("./UserGroupChart"));
const UserGroupChartResults = React.lazy(() => import("./UserGroupChartResults"));
const UserContentsDrawer = React.lazy(() => import("./UserContentsDrawer"));
const UserGroups = React.lazy(() => import("./UserGroup"));
const UserListTable = React.lazy(() => import("./UserListTable"));

export default function Dashboard() {
    const [loading, setLoading] = useState(false);
    const [openDrawer, setOpenDrawer] = useState(false);
    const [isUserListEnable, setIsUserListEnable] = useState(false);
    const [isGroupChartEnable, setIsGroupChartEnable] = useState(true);
    const [rawResData, setRawResData] = useState({});
    const [groupChart, setGroupChart] = useState([]);
    const [groupList, setGroupList] = useState([]);
    const [cardCounts, setCardCounts] = useState([]);
    const [selectedUser, setSelectedUser] = useState({});
    const [selectedGroup, setSelectedGroup] = useState({});
    const [selectedContent, setSelectedContent] = useState({});

    const [searchParams] = useSearchParams();
    const loginUserId = searchParams.get("userId");
    const loginUserRole = searchParams.get("userRole"); // Training Manager
    const [moduleName, setModuleName] = useState(searchParams.get("module"));

    useEffect(() => {
        getAllDashboardDetails(moduleName);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [moduleName]);

    const setLoadingFunc = (flag) => setLoading(flag);

    const getAllDashboardDetails = async (moduleName) => {
        setLoadingFunc(true);
        try {
            const response = await MainService.getAllDashboardItemAPICALL(loginUserId, moduleName);
            const data = response.data;
            setRawResData(data);

            const { groups, userScheduleWithRankedResults, dashboardStatistics } = data;
            const updatedGroups = groups.map((group) => ({
                ...group,
                userScheduleModel: group.userScheduleModel.map((user) => {
                    const userContents = userScheduleWithRankedResults?.filter(
                        (content) => content.loginId === user.loginId
                    ) || [];
                    return {
                        ...user,
                        userContents,
                        userResult: userContents?.length > 0 ? (userContents[0].userAverageStatus === 'IN-COMPLETE' ? '-' : userContents[0].userAverageStatus) : "-",
                    };
                }),
            }));
            setGroupList(updatedGroups);

            // Simplified user type counts and chart data generation
            const userTypeCounts = updatedGroups.reduce((acc, group) => {
                acc[group.name] = group.userScheduleModel.reduce((userAcc, user) => {
                    if (user.userType) {
                        userAcc[user.userType] = (userAcc[user.userType] || 0) + 1;
                    }
                    return userAcc;
                }, {});
                return acc;
            }, {});

            const chartData = Object.keys(userTypeCounts).map((groupName) => ({
                group: groupName,
                ...userTypeCounts[groupName],
            }));

            setGroupChart(chartData);

            // Setting card counts
            setCardCounts([
                { title: "Total Users", value: dashboardStatistics.totalUser, icon: Users, color: "text-blue-500" },
                { title: "Total Contents", value: dashboardStatistics.totalContent, icon: BookOpenCheck, color: "text-green-500" },
                { title: "Scheduled Content", value: dashboardStatistics.scheduledContent, icon: CalendarCheck2, color: "text-yellow-500" },
                { title: "Reviewed Contents", value: dashboardStatistics.reviewPendingContent, icon: FolderCheck, color: "text-red-500" },
            ]);
        } catch (error) {
            console.error(error);
        } finally {
            setLoadingFunc(false);
        }
    };

    const getContentDetailsByUser = async (selectedContent) => {
        try {
            const payload = { loginId: selectedContent.loginId, contentType: moduleName, contentName: selectedContent.name };
            const response = await MainService.getContentDetailsByUserAPICALL(payload);
            return response.data;
        } catch (error) {
            console.error(error);
        }
    };

    const onItemSelectOnClick = async (selectedData, itemType) => {
        if (itemType === "Group") {
            setIsUserListEnable(true);
            selectedData.chartData = getUserResultsForChart(selectedData);
            setSelectedGroup(selectedData);
            setIsGroupChartEnable(false);
        } else if (itemType === "User") {
            setOpenDrawer(true);
            setSelectedUser(selectedData);
        } else if (itemType === "BackToHome") {
            setIsUserListEnable(false);
            setIsGroupChartEnable(true);
        } else if (itemType === "UserContent") {
            if (selectedData.result) {
                const data = await getContentDetailsByUser(selectedData);
                if (moduleName === "Assessment CB" || moduleName === "Assessment%20CB") {
                    const COLORS = { PASS: "#4CAF50", FAIL: "#FF5733" };
                    selectedData.chartData = Object.entries(getCumulativeResults(data)).map(([key, value]) => ({
                        name: key,
                        value: value,
                        color: COLORS[key], // Assign color dynamically
                    }));
                } else {
                    selectedData.chartData = data;
                }
            }
            setSelectedContent(selectedData);
        } else {
            setSelectedGroup(selectedData);
            setIsUserListEnable(true);
        }
    };

    const getCumulativeResults = (data) => {
        return data.reduce(
            (acc, item) => {
                if (item.result === "PASS") acc.PASS += 1;
                else if (item.result === "FAIL") acc.FAIL += 1;
                return acc;
            },
            { PASS: 0, FAIL: 0 }
        );
    };

    const getUserResultsForChart = (data) => {
        return data.userScheduleModel?.filter((user) => user.userType === 'User').map((user) => {
            const resultCounts = { PASS: 0, FAIL: 0, unScheduled: 0 };

            user.userContents.forEach((content) => {
                if (!content.startDate) {
                    resultCounts.unScheduled += 1;
                } else {
                    resultCounts[content.result] = (resultCounts[content.result] || 0) + 1;
                }
            });

            return { userName: `${user.userName} (${user.loginId})`, ...resultCounts };
        });
    };

    const onModuleToggleClick = (module) => {
        setModuleName(module);
        window.location.href = `?userId=${loginUserId}&module=${module}&userRole=${loginUserRole}`;
        console.log(rawResData);
    };
    return (
        <div className="bg-gray-100 px-3 py-2 w-screen h-screen">
            {/* Header - Sticky at the Top */}
            {["training manager", "training%20manager"].includes(loginUserRole?.toLocaleLowerCase()) ? (
                <div>
                    <header className="top-0 z-50 sticky bg-white shadow-md px-2 pb-1">
                        <div className="flex justify-end items-center space-x-2 py-1">
                            {loading && <div className="header-loader"></div>}
                            <span
                                onClick={() => onModuleToggleClick("Assessment%20CB")}
                                className={`${["assessment%20cb", "assessment cb"].includes(moduleName?.toLocaleLowerCase()) ? 'bg-violet-400 text-white' : 'border-black/30 text-violet-800'} px-2 py-1.5 border rounded-md font-bold cursor-pointer`}
                            >
                                Assessment CB
                            </span>
                            <span
                                onClick={() => onModuleToggleClick("Assessment%20QA")}
                                className={`${["assessment%20qa", "assessment qa"].includes(moduleName?.toLocaleLowerCase()) ? 'bg-violet-400 text-white' : 'border-black/30 text-violet-800'} px-2 py-1.5 border rounded-md font-bold cursor-pointer`}
                            >
                                Assessment QA
                            </span>
                        </div>
                    </header>

                    {/* Main Content */}
                    <main className="space-y-2 mt-4">
                        {/* 4 Cards Section */}
                        <div className="gap-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                            {cardCounts.map((item, index) => (
                                <Card key={index} className="flex flex-col justify-between bg-white">
                                    <CardHeader className="flex flex-row justify-between items-center">
                                        <CardTitle>{item.title}</CardTitle>
                                        <item.icon className={`h-6 w-6 ${item.color}`} />
                                    </CardHeader>
                                    <CardContent>
                                        <p className="font-bold text-2xl">{item.value}</p>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>

                        {/* Graph & Table Section */}
                        <div className="gap-6 grid grid-cols-1 lg:grid-cols-2">
                            <div className="h-[400px]">
                                {isGroupChartEnable ? (
                                    <UserGroupChart groupChart={groupChart} />
                                ) : (
                                    <UserGroupChartResults chartData={selectedGroup.chartData} />
                                )}
                            </div>
                            <div className="h-[400px]">
                                {isUserListEnable ? (
                                    <UserListTable
                                        selectedGroup={selectedGroup}
                                        onItemSelectOnClick={onItemSelectOnClick}
                                    />
                                ) : (
                                    <UserGroups groupList={groupList} onItemSelectOnClick={onItemSelectOnClick} />
                                )}
                            </div>
                        </div>
                    </main>

                    <UserContentsDrawer
                        open={openDrawer}
                        setOpen={setOpenDrawer}
                        selectedUser={selectedUser}
                        selectedContent={selectedContent}
                        onItemSelectOnClick={onItemSelectOnClick}
                        moduleName={moduleName}
                    />
                </div>
            ) : (
                <DefaultDash userName={loginUserId} userType={loginUserRole} />
            )}
        </div>
    );
}

export const DefaultDash = ({ userName, userType }) => {
    const content = 'Thank you for visiting. Unfortunately, the dashboard functionality is unavailable for your account at this time. For further assistance, please contact the administrator.'

    return (
        <>
            <section className="flex justify-center items-center bg-white dark:bg-gray-900 min-h-screen">
                <div className="px-2 lg:px-6 py-4 lg:py-16 w-full max-w-screen-xl text-center" >
                    <div className="w-full font-extrabold">
                        <span className="flex text-red-500 dark:text-primary-500 text-2xl lg:text-2xl">Hi {userName},</span>
                        <h1 className="flex justify-center items-center mb-4 w-full text-gray-400 dark:text-white text-xl lg:text-xl italic tracking-tight">
                            {userType} Does not have a Dashboard (v:1.0.0)
                        </h1>

                        {/* <div className="flex justify-center items-center space-x-2 py-2 italic">
                            <p className="my-0 font-bold text-gray-400 dark:text-white text-xl md:text-xl tracking-tight">
                                Something's missing.
                            </p>
                        </div> */}

                        <p className="mb-4 font-light text-gray-500 dark:text-gray-400 text-lg italic">
                            {content}
                        </p>
                    </div>
                </div>
            </section>

        </>
    );
};