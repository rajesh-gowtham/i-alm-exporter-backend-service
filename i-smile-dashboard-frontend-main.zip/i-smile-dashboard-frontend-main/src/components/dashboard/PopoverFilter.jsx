import { useState, useEffect } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Filter, CalendarIcon, ArrowRightSquare, ArrowRight, ArrowRightCircle, ArrowRightFromLine, ArrowRightIcon, CircleArrowRightIcon, ChevronRight, ChevronsRight } from "lucide-react";
import { format, subWeeks, subMonths, formatDate } from "date-fns";
import { DayPicker } from "react-day-picker";
import "react-day-picker/style.css";

const PopoverFilter = () => {
  const [selected, setSelected] = useState("lastMonth");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [record, setRecord] = useState({ selected: "lastMonth" });
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  useEffect(() => {
    if (selected === "lastWeek") {
      setFromDate(format(subWeeks(new Date(), 1), "yyyy-MM-dd"));
      setToDate(format(new Date(), "yyyy-MM-dd"));
    } else if (selected === "lastMonth") {
      setFromDate(format(subMonths(new Date(), 1), "yyyy-MM-dd"));
      setToDate(format(new Date(), "yyyy-MM-dd"));
    } else if (selected !== "specificDate") {
      console.log(" initial ");
      setFromDate("");
      setToDate("");
    }
  }, [selected]);

  const dateFilterApplyOnClick = () => {
    setRecord({ selected: selected, fromDate: fromDate, toDate: toDate });
    setIsPopoverOpen(false);
  }
  const dateFilterCancelOnClick = () => {
    setIsPopoverOpen(false); // Close the popup
  };
  const onPopOverTriggerOnClick = () => {
    setIsPopoverOpen(true)
    setSelected(record?.selected ?? 'lastMonth')
  }
  return (
    <div className="flex flex-col justify-center items-center space-y-2">
      <div className="flex items-center space-x-2 shadow py-0.5 border border-black/5 rounded-lg">
        <span className="px-1.5">
          {record?.selected === 'specificDate' ?
            <span className="flex justify-center items-center">
              <span className="bg-green-50 px-1 py-1 border border-blue-800/30 rounded-md font-bold">
                {fromDate}
              </span>
              <ChevronsRight className="p-1 border rounded-2xl text-black/45" />
              <span className="bg-green-50 px-1 py-1 border border-blue-800/30 rounded-md font-bold">
                {toDate}
              </span>
            </span>
            :
            <span className="bg-green-50 px-2 py-0.5 border border-blue-800/30 rounded-md font-semibold text-[16px]">
              {record?.selected === "lastMonth" ? 'Last 30 Days' : 'Last 7 days'}
            </span>}
        </span>
        <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
          <PopoverTrigger onClick={onPopOverTriggerOnClick} id='dateFilterPopup'>
            <div className="relative flex justify-center items-center w-[26px] h-[26px]">
              <div className="absolute bg-green-400 opacity-50 rounded-full w-[32px] h-[32px]"></div>
              <div className="absolute flex justify-center items-center bg-green-600 rounded-full w-[26px] h-[26px]">
                <Filter className="w-4 h-4 text-white" />
              </div>
            </div>
          </PopoverTrigger>
          <PopoverContent className="bg-white shadow-lg p-4 rounded-lg w-[16vw]">
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="filter"
                  value="lastWeek"
                  checked={selected === "lastWeek"}
                  onChange={() => setSelected("lastWeek")}
                  className="w-4 h-4 accent-green-600"
                />
                <span>Last Week</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="filter"
                  value="lastMonth"
                  checked={selected === "lastMonth"}
                  onChange={() => setSelected("lastMonth")}
                  className="w-4 h-4 accent-green-600"
                />
                <span>Last Month</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  name="filter"
                  value="specificDate"
                  checked={selected === "specificDate"}
                  onChange={() => setSelected("specificDate")}
                  className="w-4 h-4 accent-green-600"
                />
                <span>Specific Date</span>
              </label>
              {selected === "specificDate" && (
                <div className="flex flex-col mt-2">
                  <DatePickerUI label="FROM" date={fromDate} setDate={setFromDate} />
                  <DatePickerUI label="TO" date={toDate} setDate={setToDate} />
                </div>
              )}
              <div className="flex justify-end space-x-2 mt-4">
                <Button variant="outline" onClick={dateFilterCancelOnClick}>Cancel</Button>
                <Button id='applyFilterBtn' className="bg-green-600" onClick={dateFilterApplyOnClick}>Apply</Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
};

export default PopoverFilter;

const DatePickerUI = ({ label, date, setDate }) => {
  return (
    <div className="flex flex-col">
      <label className="mb-1 text-gray-700 text-sm">{label}</label>
      <Popover>
        <PopoverTrigger id='' asChild>
          <Button variant="outline" className="justify-start border border-black/30 w-[180px] font-normal text-left">
            <CalendarIcon className="mr-2 w-4 h-4" />
            {date ? format(new Date(date), "yyyy-MM-dd") : "Pick a date"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="p-2 w-auto">
          <DayPicker mode="single" selected={date} onSelect={(dateInput) => { setDate(formatDate(dateInput, "yyyy-MM-dd")) }} />
        </PopoverContent>
      </Popover>
    </div>
  );
};
