import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ResponsiveContainer, ComposedChart, Bar, XAxis, YAxis, Tooltip, Legend, Cell } from "recharts";
import PopoverFilter from "./PopoverFilter";
import { useState } from "react";

const UserGroupChartResults = ({ chartData }) => {
    const [hoveredIndex, setHoveredIndex] = useState(null);
    const COLORS = {
        PASS: "#4CAF50", // Green
        FAIL: "#FF5733", // Red
        unScheduled: "#FFC107", // Yellow
        // unknown: "#9E9E9E", // Gray
    };

    // Mapping keys to Pascal Case
    const labelMapping = {
        PASS: "Pass",
        FAIL: "Fail",
        unScheduled: "Unscheduled",
        // unknown: "Unknown"
    };

    // Function to convert HEX to RGBA for opacity effect
    const getTransparentColor = (hexColor, opacity) => {
        if (!/^#([A-Fa-f0-9]{6})$/.test(hexColor)) return hexColor; // Return original if not a valid hex
        const r = parseInt(hexColor.substring(1, 3), 16);
        const g = parseInt(hexColor.substring(3, 5), 16);
        const b = parseInt(hexColor.substring(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    };

    return (
        <Card className="shadow-lg rounded-lg h-full">
            <CardHeader>
                <CardTitle className="flex justify-between font-semibold text-gray-800 text-xl">
                    <span className="underline underline-offset-3">Training Progress Overview</span>
                    <PopoverFilter />
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                    <ComposedChart data={chartData} barGap={9}>
                        <XAxis
                            dataKey="userName"
                            tick={{ fill: "#4A4A4A", fontSize: 14, fontWeight: 500 }}
                        />
                        <YAxis
                            tick={{ fill: "#4A4A4A", fontSize: 14, fontWeight: 500 }}
                        />
                        <Tooltip
                            cursor={{ fill: "#f5f5f5" }}
                            formatter={(value, name) => [value, labelMapping[name] || name]}
                        />
                        <Legend
                            wrapperStyle={{ fontSize: "14px" }}
                            formatter={(value) => labelMapping[value] || value}
                        />

                        {Object.keys(COLORS).map((key, index) => (
                            <Bar
                                key={key}
                                dataKey={key}
                                stackId="a"
                                fill={COLORS[key]}
                                radius={[5, 5, 0, 0]}
                                barSize={40}
                                onMouseEnter={() => setHoveredIndex(index)}
                                onMouseLeave={() => setHoveredIndex(null)}
                            >
                                {chartData.map((entry, entryIndex) => {
                                    const baseColor = COLORS[key];
                                    const hoverColor = hoveredIndex === index ? getTransparentColor(baseColor, 0.6) : baseColor;
                                    return (
                                        <Cell
                                            key={`cell-${entryIndex}`}
                                            fill={hoverColor}
                                            style={{
                                                transition: "all 0.3s ease-in-out",
                                                cursor: "pointer",
                                            }}
                                        />
                                    );
                                })}
                            </Bar>
                        ))}
                    </ComposedChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
};

export default UserGroupChartResults;