import { APIURL } from "./AppConfigurations";
const bk_APIURL=APIURL;
class MainService {

    getAllDashboardItemAPICALL(loginId, modulename) {
       
        return fetch(bk_APIURL + 'api/v1/Dashboard?loginId=' + loginId + '&modelName=' + modulename)
            .then(response => response.json());
    }

    getContentDetailsByUserAPICALL(payload) {
        return fetch(bk_APIURL+'api/v1/Dashboard', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        }).then(response => response.json());
    }
}
export default new MainService();