const BACKEND_API_PROD_PRIVATE = 'http://172.22.6.13:7124/'
const BACKEND_API_PROD_PUBLIC = 'http://61.12.93.27:7124/'
const BACKEND_API_QA_PRIVATE = 'http://172.22.6.40:7145/'


const getBackendApis = () => {
    const orgin = window.origin;
    const env = 'development'; //development
    if (env == 'production') {
        if (orgin.includes("61.12.93.27")) {
            return BACKEND_API_PROD_PUBLIC;
        } else {
            return BACKEND_API_PROD_PRIVATE;
        }
    } else {
        return BACKEND_API_QA_PRIVATE
    }
} 
export const APIURL = getBackendApis();

