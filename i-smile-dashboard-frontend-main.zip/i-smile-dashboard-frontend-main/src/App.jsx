import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
const Dashboard = React.lazy(() => import(".//components/dashboard/Dashboard"));

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/" element={<Dashboard />} />
      </Routes>
    </Router>
  ); 
};

export default App;
