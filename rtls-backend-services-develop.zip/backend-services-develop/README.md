# RTLS Backend

A **Real-Time Location System (RTLS)** backend designed to manage geospatial data, telemetry, authentication, and messaging in a scalable, resilient, and modular architecture.

---

## Table of Contents

- [Features](#features)
- [Technology Stack](#technology-stack)
- [Architecture Overview](#architecture-overview)
- [Prerequisites](#prerequisites)
- [Installation & Setup](#installation--setup)
- [Running the Application](#running-the-application)
- [API Usage](#api-usage)
- [Testing](#testing)
- [Configuration Reference](#configuration-reference)
- [Contributing](#contributing)
- [License](#license)

---

## Features

- Modular, layered architecture with clean separation of concerns
- Minimal API endpoints with strong typing
- Geospatial data support via PostGIS and NetTopologySuite
- Real-time messaging with NATS
- Distributed caching with Redis and FusionCache
- Resilient design using Polly
- Background job scheduling with Quartz.NET
- Containerized deployment with Docker
- Automated CI/CD with GitHub Actions
- OpenAPI documentation

---

## Technology Stack

| Layer                     | Technology / Library                                         | Purpose                                                      |
|---------------------------|--------------------------------------------------------------|--------------------------------------------------------------|
| **Language**              | C# 12                                                        | Modern, safe, high-performance language                      |
| **Framework**             | .NET 9.0                                                     | Latest LTS .NET platform                                     |
| **Web API**               | ASP.NET Core Minimal APIs                                    | Lightweight, high-performance HTTP APIs                      |
| **ORMs**                  | Entity Framework Core, Dapper                                | Data access: EF Core for ORM, Dapper for raw SQL             |
| **Database**              | PostgreSQL with PostGIS (via NetTopologySuite)               | Relational + geospatial data                                 |
| **Caching**               | Redis, FusionCache                                           | Distributed caching, with Redis backplane                    |
| **Messaging**             | NATS                                                         | Lightweight, high-performance messaging                      |
| **Authentication**        | ASP.NET Core Identity                                        | User management, token issuance                              |
| **Scheduling**            | Quartz.NET                                                   | Background job scheduling                                    |
| **Resilience**            | Polly                                                        | Retry policies, circuit breakers                             |
| **Logging**               | NLog                                                         | Flexible, high-performance logging                           |
| **API Documentation**     | OpenAPI/Swagger                                              | API exploration and documentation                            |
| **Containerization**      | Docker                                                       | Deployment and environment consistency                       |
| **CI/CD**                 | GitHub Actions                                               | Automated build and deployment                               |

---

## Architecture Overview

```mermaid
flowchart TD
    subgraph "API Layer (Rtls.WebApi)"
        A1[Program.cs]
        A2[AuthEndpoints]
        A3[Background Services]
    end

    subgraph "Domain Layer (Rtls.Domain)"
        B1[Entities & Models]
        B2[DbContexts]
        B3[Processing & Handlers]
        B4[Helpers & Extensions]
    end

    subgraph Infrastructure
        C1[(PostgreSQL + PostGIS)]
        C2[(Redis)]
        C3[(NATS Server)]
    end

    A1 --> A2
    A1 --> A3
    A1 --> B2
    A1 --> C1
    A1 --> C2
    A1 --> C3

    B2 --> C1
    B3 --> C3
    B4 --> C2
```

---

## Prerequisites

- [.NET 9.0 SDK](https://dotnet.microsoft.com/download/dotnet/9.0)
- [Docker Desktop](https://www.docker.com/products/docker-desktop) (recommended for local development)
- **OR** manually install:
  - PostgreSQL 15+ with PostGIS extension enabled
  - Redis server
  - NATS server
- Git
- Optional: [EF Core CLI tools](https://learn.microsoft.com/en-us/ef/core/cli/dotnet)

---

## Installation & Setup

### 1. Clone the repository

```bash
git clone https://github.com/your-org/rtls-backend.git
cd rtls-backend
```

### 2. Configure environment

- Copy `Rtls.WebApi/appsettings.Development.json` and adjust as needed.
- Alternatively, set environment variables prefixed with `RTLS_` to override defaults.

**Key settings:**

- `ConnectionStrings:Postgres` — PostgreSQL connection string
- `ConnectionStrings:Redis` — Redis connection string
- `Nats:Url` — NATS server URL
- `Jwt:Issuer`, `Jwt:Audience`, `Jwt:Key` — JWT token settings

### 3. Setup the database

- **Apply EF Core migrations:**

  ```bash
  dotnet ef migrations add Initial --project Rtls.Domain --startup-project Rtls.WebApi --verbose
  dotnet ef database update --project Rtls.Domain --startup-project Rtls.WebApi --verbose
  ```

### 4. Build the solution

```bash
dotnet build
```

---

## Running the Application

### Using .NET CLI

```bash
cd Rtls.WebApi
dotnet run
```

The API will be available at `https://localhost:5001` (or as configured).

### Using Docker

Build the Docker image:

```bash
docker build -t rtls-backend -f Api.Dockerfile .
```

Run the container (adjust environment variables as needed):

```bash
docker run -p 5001:5001 -e "ASPNETCORE_ENVIRONMENT=Development" rtls-backend
```

### Using Docker Compose (recommended)

Create a `docker-compose.yml` (if not present) to orchestrate API, PostgreSQL, Redis, and NATS. Example snippet:

```yaml
version: '3.8'
services:
  postgres:
    image: postgis/postgis
    environment:
      POSTGRES_USER: youruser
      POSTGRES_PASSWORD: yourpassword
      POSTGRES_DB: yourdb
    ports:
      - "5432:5432"

  redis:
    image: redis
    ports:
      - "6379:6379"

  nats:
    image: nats
    ports:
      - "4222:4222"

  api:
    build:
      context: .
      dockerfile: Api.Dockerfile
    environment:
      ASPNETCORE_ENVIRONMENT: Development
      RTLS_ConnectionStrings__Postgres: Host=postgres;Database=yourdb;Username=youruser;Password=yourpassword
      RTLS_ConnectionStrings__Redis: redis:6379
      RTLS_Nats__Url: nats://nats:4222
    depends_on:
      - postgres
      - redis
      - nats
    ports:
      - "5001:5001"
```

Then run:

```bash
docker-compose up --build
```

---

## API Usage

- Access Swagger UI at: `https://localhost:5001/swagger`
- Use Swagger to explore and test endpoints.
- Example login request:

```bash
curl -X POST "https://localhost:5001/auth/login" -H "Content-Type: application/json" -d "{\"email\":\"user@example.com\",\"password\":\"yourpassword\"}"
```

---

## Testing

Run all tests:

```bash
dotnet test
```

Test projects are located in the `Rtls.Tests` directory.

---

## Configuration Reference

| Setting                               | Description                                   | Source (`appsettings.json` key or env var)            |
|---------------------------------------|-----------------------------------------------|-------------------------------------------------------|
| `ConnectionStrings:Postgres`          | PostgreSQL connection string                  | `RTLS_ConnectionStrings__Postgres`                    |
| `ConnectionStrings:Redis`             | Redis connection string                       | `RTLS_ConnectionStrings__Redis`                       |
| `Nats:Url`                           | NATS server URL                              | `RTLS_Nats__Url`                                     |
| `Jwt:Issuer`                          | JWT token issuer                             | `RTLS_Jwt__Issuer`                                   |
| `Jwt:Audience`                        | JWT token audience                           | `RTLS_Jwt__Audience`                                 |
| `Jwt:Key`                             | JWT signing key                              | `RTLS_Jwt__Key`                                      |
| `Logging:LogLevel:Default`            | Default log level                            | `RTLS_Logging__LogLevel__Default`                    |

Environment variables override `appsettings.json` values.

---

## Contributing

- Fork the repository
- Create a feature branch
- Commit and push your changes
- Submit a Pull Request

---

## Summary

This RTLS backend is a **modular, scalable, cloud-ready** system leveraging the latest .NET technologies, optimized for geospatial data, real-time messaging, and resilient distributed operations. Its clean architecture and modern stack facilitate rapid development, easy onboarding, and robust production deployments.