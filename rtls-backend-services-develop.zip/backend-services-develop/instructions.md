## 1. **Architecture & Solution Structure**

- **Layered, modular design:**
  - **API Layer (`Rtls.WebApi`)**: Minimal APIs, authentication, middleware, background services.
  - **Domain Layer (`Rtls.Domain`)**: Core business logic, data access, messaging, caching.
  - **Infrastructure**: PostgreSQL + PostGIS, Redis, NATS, Quartz.NET, Docker, CI/CD.
- **Respect boundaries:** API layer orchestrates, Domain layer owns business rules and data.
- **Solution layout:**

```
Rtls.sln
├── Rtls.Application/         # Application services layer
│   ├── Interfaces/           # Service contracts
│   ├── Mappings/             # AutoMapper profiles
│   ├── Models/               # DTOs
│   ├── Services/             # Service implementations
│   └── Rtls.Application.csproj
├── Rtls.Domain/              # Core domain layer
│   ├── Database/             # EF Core contexts & config
│   ├── DataAccess/           # Repository implementations
│   ├── Entities/             # Domain models
│   ├── Helpers/              # Utilities
│   ├── Processing/           # Message handlers
│   └── Rtls.Domain.csproj
├── Rtls.Tests/               # Test projects
│   ├── DataAccess/           # Repository tests
│   ├── Services/             # Service tests
│   ├── Utilities/            # Test infrastructure
│   └── Rtls.Tests.csproj
├── Rtls.WebApi/              # API presentation layer
│   ├── BgServices/           # Background services
│   ├── Endpoints/            # API endpoint classes
│   ├── Extensions/           # Startup configuration
│   └── Rtls.WebApi.csproj
├── Api.Dockerfile            # Containerization
├── docker-compose.yml        # Dev environment setup
├── instructions.md           # Development guidelines and code style rules
└── .gitignore                # Version control config
```

---

## 2. **API Endpoint Development**

### 2.1 **Directory & Organization**

- **All API endpoints** reside in `Rtls.WebApi/Endpoints`.
- Each logical group (e.g., Auth, Config, Devices) has its own static class named `XxxEndpoints`.
- Namespace must be `Rtls.WebApi.Endpoints`.

### 2.2 **Endpoint Class Pattern**

- Define as `public static class XxxEndpoints`.
- Implement a single public method:  
  `public static void MapRoutes(IEndpointRouteBuilder builder)`
- Inside, create a group:  
  `var group = builder.MapGroup("/groupname");`
- Register endpoints with `group.MapGet`, `group.MapPost`, etc.
- **Example:**

```csharp
public static void MapRoutes(IEndpointRouteBuilder builder)
{
    var group = builder.MapGroup("/auth");
    group.MapPost("/login", Login);
    group.MapPost("/refresh", Refresh);
}
```

### 2.3 **Endpoint Method Design**

- Use **Minimal API** style with explicit, strongly-typed signatures.
- Return **explicit union result types** via `Results<...>`.
- Prefer `TypedResults` helpers (`Ok`, `Problem`, `Empty`, `Challenge`, `SignIn`).
- Example:

```csharp
private static async Task<Results<Ok<AccessTokenResponse>, EmptyHttpResult, ProblemHttpResult>> Login(...)
```

### 2.4 **Request & Response Models**

- Define request DTOs as `record` types, e.g.:

```csharp
public sealed record LoginRequest(string Email, string Password);
```

- Use DTOs for responses, avoid anonymous objects.
- Place DTOs in the same file if tightly coupled, or in `Rtls.Domain/Models` if reused.

### 2.5 **Dependency Injection**

- Accept dependencies (e.g., `SignInManager`, `DbContext`) as method parameters.
- Avoid service locator or manual resolution.
- Use constructor injection only in background services or classes, not static endpoint methods.

### 2.6 **Error Handling**

- Return appropriate HTTP status codes:
  - `Problem()` for validation/auth failures.
  - `Unauthorized()` or `Challenge()` for auth issues.
  - `Ok()` for success.
  - `Empty()` when no content.
- Avoid unhandled exceptions; convert to problem details.

### 2.7 **Registration**

- Register all endpoint groups in `Rtls.WebApi/Extensions/Routes.cs`:

```csharp
public static WebApplication MapRoutes(this WebApplication app)
{
    AuthEndpoints.MapRoutes(app);
    ConfigEndpoints.MapRoutes(app);
    // Add other groups here
    return app;
}
```

### 2.8 **Security**

- Protect endpoints with `[Authorize]` or group-level policies.
- Use **ASP.NET Core Identity** and **Bearer tokens**.
- Handle token refresh securely.
- Never expose sensitive error details.

### 2.9 **Documentation & Style**

- Document endpoints with **OpenAPI** annotations.
- Use **async/await**.
- Follow **.NET naming conventions**.
- Comment complex logic inline.

---

## 3. **Coding Standards**

- Use **C# 12** and **.NET 9.0** features.
- PascalCase for types/methods, camelCase for locals/params, `_camelCase` for private fields.
- Prefer **async/await** for I/O.
- Use **nullable reference types**.
- Keep methods **short (<50 lines)** and single-responsibility.
- Favor **composition over inheritance**.
- Use **records** for immutable DTOs.
- Avoid magic strings/numbers.
- Write **XML comments** for public APIs.

---

## 4. **Domain Layer**

- Use **EF Core** for ORM, **Dapper** for raw queries.
- Separate **DbContexts** for core and telemetry.
- Support geospatial data with **NetTopologySuite** and **PostGIS**.
- Encapsulate messaging with **NATS**.
- Use **FusionCache** with Redis.
- Apply **Polly** policies for resilience.
- Register dependencies via modular DI extensions.

---

## 5. **Database & Geospatial**

- Maintain schema and EF migrations.
- Optimize geospatial queries with indexes.
- Use strongly-typed geometry types.

---

## 6. **Messaging & Background Jobs**

- Use **NATS** for messaging.
- Implement consumers as background services.
- Ensure idempotency and error handling.
- Use **Quartz.NET** for scheduled jobs.

---

## 7. **Caching**

- Use **Redis** with **FusionCache**.
- Cache geospatial queries, telemetry aggregates, tokens.
- Define sensible TTLs.

---

## 8. **Configuration**

- Store secrets and connection strings in `appsettings.json` or `RTLS_` env vars.
- Use strongly-typed config classes.
- Log config loading without exposing secrets.

---

## 9. **Logging & Monitoring**

- Use **NLog**.
- Log at appropriate levels.
- Include correlation IDs.
- Log requests and key events.
- Integrate with monitoring tools.

---

## 10. **Testing**

- Write **unit tests** for domain logic.
- Use **integration tests** for APIs and messaging.
- Mock external dependencies.

---

## 11. **Security Best Practices**

- Never log sensitive data.
- Use HTTPS.
- Validate all inputs.
- Use parameterized queries.
- Rotate secrets regularly.
- Enforce least privilege.

---

## 12. **Documentation**

- Maintain **OpenAPI** docs.
- Use **Mermaid** diagrams.
- Update `README.md` with major changes.
- Document environment variables.

---

## 13. **Architecture Diagram**

```mermaid
flowchart TD
    subgraph API Layer (Rtls.WebApi)
        A1[Program.cs]
        A2[AuthEndpoints]
        A3[Background Services]
    end

    subgraph Domain Layer (Rtls.Domain)
        B1[Entities & Models]
        B2[DbContexts]
        B3[Processing & Handlers]
        B4[Helpers & Extensions]
    end

    subgraph Infrastructure
        C1[(PostgreSQL + PostGIS)]
        C2[(Redis)]
        C3[(NATS Server)]
    end

    A1 --> A2
    A1 --> A3
    A1 --> B2
    A1 --> C1
    A1 --> C2
    A1 --> C3

    B2 --> C1
    B3 --> C3
    B4 --> C2
```