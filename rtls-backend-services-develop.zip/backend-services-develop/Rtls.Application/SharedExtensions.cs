﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Rtls.Domain;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Helpers;
using ZiggyCreatures.Caching.Fusion;
using ZiggyCreatures.Caching.Fusion.Serialization.SystemTextJson;

namespace Rtls.Application;

public static class SharedExtensions
{
    public static IServiceCollection AddMasterDb(this IServiceCollection services)
    {
        services.AddDbContext<AppDbContext>((provider, optionsBuilder) =>
        {
            var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
            optionsBuilder.UseNpgsql(cfg.Value.Master,
                    opt => opt
                        .MigrationsAssembly(typeof(AppDbContext).Assembly.FullName)
                        .UseNetTopologySuite(geographyAsDefault: true))
                .EnableSensitiveDataLogging()
                .EnableDetailedErrors()
                .UseSnakeCaseNamingConvention();
        });
        
        return services;
    }
    
    // public static IServiceCollection AddNatsConfigured(this IServiceCollection services)
    // {
    //     services.AddNatsClient(builder =>
    //     {
    //         builder.ConfigureOptions((provider, opts) =>
    //         {
    //             var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
    //             return opts with
    //             {
    //                 Url = cfg.Value.Nats
    //             };
    //         });
    //     });
    //     
    //     return services;
    // }

    // public static IServiceCollection AddTelemetryDb(this IServiceCollection services)
    // {
    //     services.AddSingleton<ITelemetryDb, TelemetryDb>(provider =>
    //     {
    //         var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
    //         var dataSourceBuilder = new NpgsqlDataSourceBuilder(cfg.Value.Telemetry);
    //         dataSourceBuilder.UseNetTopologySuite(geographyAsDefault: true);
    //         return new TelemetryDb(dataSourceBuilder.Build());
    //     });
    //
    //     return services;
    // }

    // public static IServiceCollection AddRedis(this IServiceCollection services)
    // {
    //
    //     services.AddSingleton<IConnectionMultiplexer>(provider =>
    //     {
    //         var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
    //         return ConnectionMultiplexer.Connect(cfg.Value.Redis, opt => GetOptions(cfg.Value.Redis, opt));
    //     });
    //
    //     services.AddSingleton<Func<Task<IConnectionMultiplexer>>>(provider =>
    //     {
    //         var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
    //         return async () => await ConnectionMultiplexer.ConnectAsync(cfg.Value.Redis,
    //             opt => GetOptions(cfg.Value.Redis, opt));
    //     });
    //
    //     services.AddTransient(provider =>
    //     {
    //         var cfg = provider.GetRequiredService<IOptions<ConnectionsConfig>>();
    //         return provider.GetService<IConnectionMultiplexer>()?.GetDatabase(0);
    //     });
    //
    //     return services;
    //
    //     static ConfigurationOptions GetOptions(string connectionString, ConfigurationOptions options)
    //     {
    //         options.DefaultDatabase = 0;
    //         options.ConnectRetry = 5;
    //         options.ConnectTimeout = 60 * 1000;
    //         options.SyncTimeout = 60 * 1000;
    //         options.AsyncTimeout = 60 * 1000;
    //         return options;
    //     }
    // }
    
    public static IServiceCollection AddCache(this IServiceCollection services)
    {
        services
            .AddFusionCache()
            .WithOptions(opt =>
            {
                // opt.AutoRecoveryMaxItems = 128;
                // opt.AutoRecoveryDelay = TimeSpan.FromSeconds(10);
                // opt.DistributedCacheCircuitBreakerDuration = TimeSpan.FromSeconds(15);
            })
            .WithDefaultEntryOptions(opt => opt.DefaultOptions())
            .WithSerializer(
                new FusionCacheSystemTextJsonSerializer()
            );
            // .WithDistributedCache(provider =>
            // {
            //     var connectionFactory = provider.GetService<Func<Task<IConnectionMultiplexer>>>();
            //     return new RedisCache(new RedisCacheOptions { ConnectionMultiplexerFactory = connectionFactory });
            // })
            // .WithBackplane(provider =>
            // {
            //     var connectionFactory = provider.GetService<Func<Task<IConnectionMultiplexer>>>();
            //     // var cfg = provider.GetService<IAppConfig>();
            //     // var redisOptions = ConfigurationOptions.Parse(cfg.RedisConnectionString);
            //     // redisOptions.DefaultDatabase = cfg.RedisDbId;
            //     // redisOptions.ConnectRetry = 5;
            //     // redisOptions.ConnectTimeout = 60_000;
            //     // redisOptions.SyncTimeout = 30_000;
            //     // redisOptions.AsyncTimeout = 30_000;
            //     return new RedisBackplane(
            //         new RedisBackplaneOptions { ConnectionMultiplexerFactory = connectionFactory });
            //     // return new RedisBackplane(new RedisBackplaneOptions { ConfigurationOptions = redisOptions });
            // });

        return services;
    }

    
    public static IServiceCollection AddSharedDependencies(this IServiceCollection services)
    {
        // Register data access layer components
        services.AddDataAccessLayer();

        return services;
    }

    public static IServiceCollection AddMessageBus(this IServiceCollection services)
    {
        services.AddSingleton<InMemoryMessageBus>();
        
        // // Register handlers
        // services.AddSingleton<RtlsSystemEventHandler>();
        //
        // // Register the bus factory itself
        // services.AddSlimMessageBus(mbb =>
        // {
        //     // In-memory transport provider
        //     mbb.WithProviderMemory();
        //
        //     // JSON serializer plugin (optional but recommended)
        //     mbb.AddJsonSerializer();
        //
        //     // subscriptions
        //     mbb.Consume<RtlsSystemEvent>(cfg => cfg
        //         .Topic(nameof(RtlsSystemEvent))
        //         .WithConsumer<RtlsSystemEventHandler>()
        //     );
        // });

        return services;
    }
}