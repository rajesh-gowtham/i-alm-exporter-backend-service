﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;
using SlimMessageBus;
using System.ComponentModel;
using System.Linq;
using System.Security.AccessControl;
using static Rtls.Domain.Constants;

namespace Rtls.Application.Services;

public class DashboardService : IDashboardService
{
    private readonly IVesselVisitDataAccess _vesselDataAccess;
    private readonly IWorkInstructionDataAccess _wiDataAccess;
    private readonly IVesselBerthingDataAccess _berthDataAccess;
    private readonly IEquipmentDataAccess _equipmentDataAccess;
    private readonly IAlarmsEventsDataAccess _alarmsEventsDataAccess;
    private readonly IVmtAuditLoginDataAccess _vmtAuditLoginDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly EquipmentStateService _equipmentStateService;
    private readonly ILogger<DashboardService> _logger;
    private readonly IMapper _mapper;

    public DashboardService(
        IVesselVisitDataAccess vesselDataAccess,
        IWorkInstructionDataAccess wiDataAccess,
        IVesselBerthingDataAccess berthDataAccess,
        IEquipmentDataAccess equipmentDataAccess,
        IVmtAuditLoginDataAccess vmtAuditLoginDataAccess,
        ICurrentUserService currentUserService,
        ILogger<DashboardService> logger,
        IMapper mapper, EquipmentStateService equipmentStateService, 
        IAlarmsEventsDataAccess alarmsEventsDataAccess)
    {
        _vesselDataAccess = vesselDataAccess ?? throw new ArgumentNullException(nameof(vesselDataAccess));
        _wiDataAccess = wiDataAccess ?? throw new ArgumentNullException(nameof(wiDataAccess));
        _berthDataAccess = berthDataAccess ?? throw new ArgumentNullException(nameof(berthDataAccess));
        _equipmentDataAccess = equipmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentDataAccess));
        _vmtAuditLoginDataAccess = vmtAuditLoginDataAccess ?? throw new ArgumentNullException(nameof(vmtAuditLoginDataAccess));
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _equipmentStateService = equipmentStateService;
        _alarmsEventsDataAccess = alarmsEventsDataAccess ?? throw new ArgumentNullException(nameof(alarmsEventsDataAccess));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
    }

    public async Task<WaterSideDashboardDto> GetWaterSideDashboardData(string cardName, int skip, int? take, CancellationToken ct)
    {
        var visits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (!visits.Any())
            return new WaterSideDashboardDto();

        var visitIds = visits.Select(vv => vv.Id).ToList();
        var vesselOnBerth = visits.Count;

        // Batch WI metrics (optional optimization)
        var activeQc = await _wiDataAccess.GetActiveQcCountAsync(visitIds, ct);
        var totalJobs = await _wiDataAccess.GetTotalJobsCountAsync(visitIds, ct);
        var assignedItvs = await _wiDataAccess.GetAssignedItvsCountAsync(visitIds, ct);
        var alerts = await _alarmsEventsDataAccess.GetByCountAsync(visitIds, "Hatch", ct);

        // Vessel Info
        var vesselInfo = BuildVesselInfo(visits);

        // Job Info
        var allInstructions = visits
            .SelectMany(vv => vv.WorkInstructions ?? Enumerable.Empty<WorkInstruction>());

        var jobInfos = new JobInfosDto
        {
            MovesCompleted = allInstructions.Count(wi => wi.WorkInstructionStatus == Constants.JobStatus.COMPLETED),
            MovesPending = allInstructions.Count(wi => wi.WorkInstructionStatus != Constants.JobStatus.COMPLETED)
        };

        // QcDetailsGetCardDetailsAsync
        var qcDetails = await GetCardDetailsAsync(cardName, skip, take, ct);

        return new WaterSideDashboardDto
        {
            VesselOnBerth = vesselOnBerth,
            ActiveQc = activeQc,
            TotalJobs = totalJobs,
            AssignedItvs = assignedItvs,
            Alerts = alerts,
            VesselInfo = vesselInfo,
            JobInfos = jobInfos,
            QcDetails = qcDetails,
            LastUpdatedUtc = DateTime.UtcNow
        };
    }

    private List<VesselInfoDto> BuildVesselInfo(List<VesselVisit> visits)
    {
        return visits
            .GroupBy(vv => new
            {
                vv.VisitRef,
                vv.Vessel.Id
            })
            .Select(g => new VesselInfoDto
            {
                VesselName = g.Key.VisitRef,
                VesselId = g.Key.Id,
                Qcs = g
                    .SelectMany(vv => vv.WorkInstructions ?? Enumerable.Empty<WorkInstruction>())
                    .GroupBy(wi => new
                    {
                        wi.PointOfWork?.Name,
                        wi.MoveType
                    })
                    .Select(g2 => new QcDto
                    {
                        Asset = g2.Key.Name,
                        Type = g2.Key.MoveType.ToString(),
                        ActiveJobs = g2.Where(wi => wi.WorkInstructionStatus != JobStatus.COMPLETED).Count(),
                        CompletedJobs = g2.Where(wi => wi.WorkInstructionStatus == JobStatus.COMPLETED).Count()
                    })
                    .ToList()
            })
            .ToList();
    }

    private async Task<PagedResponse<QcDetailDto>> BuildQcDetailsAsync(int skip, int? take, CancellationToken ct)
    {
        var eligibleVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        // Group by VesselName and PointOfWorkName
        var grouped = eligibleVisits
            .SelectMany(vv => vv.WorkInstructions)
            .GroupBy(wi => new
            {
                VesselName = wi.VesselVisit.Vessel.VesselName,
                PointOfWorkName = wi.PointOfWork.Name
            });

        int total = grouped.Count();

        // Apply pagination to the group
        var pagedGroups = grouped.Skip(skip).Take(take ?? total);

        var qcDetails = new List<QcDetailDto>();

        foreach (var g in pagedGroups)
        {
            var anyWi = g.FirstOrDefault(wi => wi.WorkInstructionStatus == Constants.JobStatus.INPROGRESS);
            if (anyWi == null) anyWi = g.First(); 
            // Fetch equipment info (awaited sequentially)
            var equipment = await _equipmentDataAccess.GetByNameAsync(g.Key.PointOfWorkName);

            // Determine ignition status from the first WorkInstruction
            bool ignition = anyWi.WorkQueue?.Status?.Equals(Constants.JobStatus.INPROGRESS) == true;

            qcDetails.Add(new QcDetailDto
            {
                Asset = equipment?.EquipmentName ?? "Unknown",
                Berth = anyWi.VesselVisit?.VesselBerthing?.Quay ?? string.Empty,
                GpsTime = DateTime.UtcNow,
                MovesPending = g.Count(wi => wi.WorkInstructionStatus != Constants.JobStatus.COMPLETED),
                MovesCompleted = g.Count(wi => wi.WorkInstructionStatus == Constants.JobStatus.COMPLETED),
                Ignition = ignition ? "ON" : "OFF",
                Make = equipment?.Make ?? string.Empty
            });
        }

        return new PagedResponse<QcDetailDto>(total, qcDetails.ToArray());
    }

    //Get the details based on the Card clicks (ActiveQc's, Total Jobs, Itv's)
    public async Task<PagedResponse<Object>> GetCardDetailsAsync(string cardName, int skip, int? take, CancellationToken ct)
    {
        switch (cardName)
        {
            case Constants.CardNames.ActiveQc:
                var activeQcData = await BuildActiveQcCardDetailsAsync(skip, take, ct);
                return new PagedResponse<Object>(activeQcData.TotalCount, activeQcData.Items.Cast<object>().ToArray());

            case Constants.CardNames.TotalJobs:
                var totalJobsData = await BuildTotalJobsCardDetailsAsync(skip, take, ct);
                return new PagedResponse<Object>(totalJobsData.TotalCount, totalJobsData.Items.Cast<object>().ToArray());

            case Constants.CardNames.AssignedItvs:
                var assigneditvData = await BuildAssignedItvCardDetailsAsync(skip, take, ct);
                return new PagedResponse<Object>(assigneditvData.TotalCount, assigneditvData.Items.Cast<object>().ToArray());

            case Constants.CardNames.Alerts:
                var alertsData = await BuildAlertsCardDetailsAsync(skip, take, ct);
                return new PagedResponse<Object>(alertsData.TotalCount, alertsData.Items.Cast<object>().ToArray());

            default:
                var assetDetails = await BuildQcDetailsAsync(skip, take, ct);
                return new PagedResponse<Object>(assetDetails.TotalCount, assetDetails.Items.Cast<object>().ToArray());
        }
    }

    // ActiveQc's Card
    private async Task<PagedResponse<ActiveQcDto>> BuildActiveQcCardDetailsAsync(int skip, int? take, CancellationToken ct)
    {
        var result = new List<ActiveQcDto>();

        var eligibleVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (!eligibleVisits.Any())
            return new PagedResponse<ActiveQcDto>(0, result.ToArray());
        var QcCount = eligibleVisits
            .SelectMany(vv => vv.WorkInstructions.Select(wi => wi.PointOfWork.Name))
            .Distinct()
            .Count();
        // Get distinct QC names with paging
        var allQcs = eligibleVisits
            .SelectMany(vv => vv.WorkInstructions.Select(wi => wi.PointOfWork.Name))
            .Distinct()
            .Skip(skip)
            .Take(take ?? QcCount)
            .ToList();

        foreach (var qcName in allQcs)
        {
            var relevantWIs = eligibleVisits
                .SelectMany(vv => vv.WorkInstructions, (vv, wi) => new
                {
                    vv,
                    wi
                })
                .Where(x => x.wi.PointOfWork.Name == qcName)
                .ToList();

            var completedCount = relevantWIs.Count(x => x.wi.WorkInstructionStatus == Constants.JobStatus.COMPLETED);
            var pendingCount = relevantWIs.Count - completedCount;
            var activeTime = TimeSpan.FromSeconds(completedCount * 120);

            var eligibleWi = relevantWIs
                .Select(x => x.wi)
                .FirstOrDefault(wi => wi.WorkInstructionStatus == Constants.JobStatus.INPROGRESS);

            var eligibleWq = eligibleWi?.WorkQueue?.Status == Constants.JobStatus.INPROGRESS ? eligibleWi.WorkQueue : null;

            var berth = relevantWIs
                .Select(x => x.vv.VesselBerthing?.Quay)
                .FirstOrDefault() ?? "";
            var equipment = await _equipmentDataAccess.GetByNameAsync(qcName);
            result.Add(new ActiveQcDto
            {
                Asset = qcName ?? "N/A",
                Berth = berth,
                Activity = eligibleWq?.Type ?? "",
                Job = eligibleWi?.ContainerId ?? "",
                GpsTime = DateTime.UtcNow,
                MovesCompleted = completedCount,
                MovesPending = pendingCount,
                Active = activeTime.ToString(@"hh\:mm\:ss"),
                Ignition = eligibleWq != null ? "ON" : "OFF",
                Make = equipment.Make
            });
        }

        return new PagedResponse<ActiveQcDto>(result.Count, result.ToArray());
    }

    // TotalJobs's Card
    private async Task<PagedResponse<TotalJobDto>> BuildTotalJobsCardDetailsAsync(int skip, int? take, CancellationToken ct)
    {
        var result = new List<TotalJobDto>();

        var eligibleVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (!eligibleVisits.Any())
            return new PagedResponse<TotalJobDto>(0, result.ToArray());

        var allWIs = eligibleVisits
            .SelectMany(vv => vv.WorkInstructions
                .Select(wi => new
                {
                    VesselVisit = vv,
                    WorkInstruction = wi
                }))
            .ToList();

        var pagedWIs = allWIs
            .Skip(skip) // <-- subtract 1 here
            .Take(take ?? allWIs.Count)
            .ToList();

        foreach (var item in pagedWIs)
        {
            var wi = item.WorkInstruction;
            var vesselVisit = item.VesselVisit;

            result.Add(new TotalJobDto
            {
                Asset = wi.PointOfWork?.Name ?? "N/A",
                Berth = vesselVisit.VesselBerthing?.Quay ?? "Unknown",
                Activity = wi.MoveType,
                Job = wi.ContainerId,
                StartTime = wi.DispatchTime,
                EndTime = wi.JobCompleteTime,
                Status = wi.WorkInstructionStatus,
                JobSteppingStatus = wi.JobSteppingStatus,
                AssignedItv = wi.CheCarry
            });
        }

        return new PagedResponse<TotalJobDto>(allWIs.Count(), result.ToArray());
    }

    //Assigned Itv's
    private async Task<PagedResponse<AssignedItvDto>> BuildAssignedItvCardDetailsAsync(int skip, int? take, CancellationToken ct)
    {
        var result = new List<AssignedItvDto>();

        var eligibleVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (!eligibleVisits.Any())
            return new PagedResponse<AssignedItvDto>(0, result.ToArray());

        // Step 1: Get all WorkInstructions with valid che_carry (ITV assigned)
        var allWIs = eligibleVisits
            .SelectMany(vv => vv.WorkInstructions
                .Where(wi => !string.IsNullOrWhiteSpace(wi.CheCarry))
                .Select(wi => new
                {
                    VesselVisit = vv,
                    WorkInstruction = wi
                }))
            .ToList();

        // Step 2: Apply pagination
        var pagedWIs = allWIs
            .Skip(skip) // <-- subtract 1 here
            .Take(take ?? allWIs.Count)
            .ToList();

        // Step 3: Build response for each WI
        foreach (var item in pagedWIs)
        {
            var wi = item.WorkInstruction;
            var vesselVisit = item.VesselVisit;
            var equipment = await _equipmentDataAccess.GetByNameAsync(wi.CheCarry);
            result.Add(new AssignedItvDto
            {
                Asset = wi.PointOfWork?.Name ?? "N/A",
                Berth = vesselVisit.VesselBerthing?.Quay ?? "Unknown",
                Activity = wi.MoveType,
                Job = wi.ContainerId,
                GpsTime = DateTime.UtcNow,
                AssignedItvs = equipment.EquipmentName,
                Make = equipment?.Make,
            });
        }
        return new PagedResponse<AssignedItvDto>(allWIs.Count(), result.ToArray());
    }

    private async Task<PagedResponse<AlarmsEventsDto>> BuildAlertsCardDetailsAsync(int skip, int? take, CancellationToken ct)
    {
        var result = new List<AlarmsEventsDto>();

        var eligibleVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (!eligibleVisits.Any())
            return new PagedResponse<AlarmsEventsDto>(0, result.ToArray());

        var alerts = await _alarmsEventsDataAccess.GetByVesselVisitIds(eligibleVisits.Select(vv => vv.Id).ToList(), "Hatch", skip, take, ct);

        // Step 3: Build response for each WI
        foreach (var item in alerts.Items)
        {
            result.Add(new AlarmsEventsDto
            {
                VisitRef = item.VesselVisit.VisitRef,
                Asset = item.Equipment.EquipmentName ?? "N/A",
                Type = item.Equipment.EquipmentType ?? "N/A",
                EventName = item.EventName,
                StartTime = item.StartTime,
                EndTime = item.EndTime,
                WorkQueue = item.WorkQueue.Name
            });
        }
        return new PagedResponse<AlarmsEventsDto>(alerts.TotalCount, result.ToArray());
    }

    // GET API - Land Side
    public async Task<LandSideDashboardDto> GetLandSideDashboardData(int skip, int? take, string cardName, CancellationToken ct)
    {
        var response = new LandSideDashboardDto();

        var activeVesselVisits = await _vesselDataAccess.GetActiveVesselVisitsAsync(ct);
        if (activeVesselVisits == null || !activeVesselVisits.Any())
            return response;

        var allWorkInstructions = activeVesselVisits
            .SelectMany(vv => vv.WorkInstructions ?? new List<WorkInstruction>())
            .ToList();

        var allCheCarry = allWorkInstructions
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();

        var activeCheCarry = allWorkInstructions
            .Where(wi => wi.WorkInstructionStatus == JobStatus.INPROGRESS)
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();

        if (!allCheCarry.Any())
            return response;

        var equipmentList = await _equipmentDataAccess.GetListByNamesAsync(allCheCarry, ct);

        response.Asserts = allCheCarry.Count;
        response.Active = GetActiveAssetCount(activeCheCarry, equipmentList, allWorkInstructions);
        response.Idling = await GetIdlingAssetCount(activeCheCarry, equipmentList, allWorkInstructions, activeVesselVisits);

        response.Stoppage = 0; // This can be calculated if needed.
        response.Alerts = 0;
        response.AvgCycleTime = 8; // You can adjust this as per your calculation.

        // Fetch ITVs and ECU status
        var (itvActivity, ecuStatus) = await GetItvActivityAndEcuStatus(allCheCarry, allWorkInstructions, activeVesselVisits);

        response.ItvActivity = itvActivity;
        response.EcuStatus = ecuStatus;
        response.ItvDistribution = GetItvDistribution(allWorkInstructions, equipmentList);
        response.AssertDetails = cardName.ToLower() switch
        {
            "active" => GetActiveItvData(allWorkInstructions, equipmentList, activeCheCarry, skip, take),
            "idling" => GetIdlingItvData(allWorkInstructions, equipmentList, activeVesselVisits, activeCheCarry, skip, take).Result,
            _ => GetAssertDetails(allCheCarry, equipmentList, allWorkInstructions, skip, take)
        };

        return response;
    }

    // Get Active count
    private int GetActiveAssetCount(List<string> activeCheCarry, List<Equipment> equipmentList, List<WorkInstruction> workInstructions)
    {
        var equipmentDict = equipmentList
            .Where(eq => activeCheCarry.Contains(eq.EquipmentName))
            .Where(eq => eq.Status != null && eq.Status == EquipmentStatus.AVAILABLE)
            .GroupBy(eq => eq.EquipmentName)
            .ToDictionary(g => g.Key, g => g.First());

        var grouped = workInstructions
            .Where(wi => wi.WorkInstructionStatus == JobStatus.INPROGRESS)
            .Select(wi => new { wi, key = wi.CheCarry })
            .Where(x => equipmentDict.ContainsKey(x.key))
            .GroupBy(x => x.key, x => x.wi)
            .ToList();

        return grouped.Count();
    }

    // Get Idle count
    private async Task<int> GetIdlingAssetCount(List<string> activeCheCarry, List<Equipment> equipmentList, List<WorkInstruction> workInstructions, List<VesselVisit> activeVesselVisits)
    {
        // Step 1: Collect all CheCarry names used in any WI
        var allCheCarry = workInstructions
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();
        var fromDate = activeVesselVisits
            .Select(vv => vv.StartWorkTime ?? vv.Ata ?? vv.Eta)
            .Min();
        var auditLogs = await _vmtAuditLoginDataAccess.GetRecentAuditLogsAsync(allCheCarry, fromDate);
        // Step 2: Build a filtered equipment dictionary for IDLE/AVAILABLE and not LOGOUT
        var equipmentDict = equipmentList
            .Where(eq =>
                !activeCheCarry.Contains(eq.EquipmentName) &&
                eq.Status != null &&
                !eq.Status.Equals(EquipmentStatus.LOGOUT))
            .GroupBy(eq => eq.EquipmentName)
            .ToDictionary(g => g.Key, g => g.First());

        // Step 3: Group WIs by CheCarry where CheCarry exists in equipmentDict
        var grouped = workInstructions
            .Select(wi => new { wi, key = wi.CheCarry })
            .Where(x => equipmentDict.ContainsKey(x.key))
            .GroupBy(x => x.key, x => x.wi)
            .ToList();

        return grouped.Count();
    }

    private ItvDistributionDto GetItvDistribution(List<WorkInstruction> workInstructions, List<Equipment> equipmentList)
    {
        var result = new ItvDistributionDto();

        var activeWorkInstructions = workInstructions
            .Where(wi => wi.WorkInstructionStatus == Constants.JobStatus.INPROGRESS)
            .ToList();

        // Distinct CheCarry in active WorkInstructions
        var activeCheCarry = activeWorkInstructions
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();

        // TaskStatus-based distribution for active CheCarry
        var cheCarryGroupedByTaskStatus = activeWorkInstructions
            .GroupBy(wi => new
            {
                wi.CheCarry,
                wi.TaskStatus
            })
            .ToList();

        var handledCheCarry = new HashSet<string>();

        foreach (var group in cheCarryGroupedByTaskStatus)
        {
            if (handledCheCarry.Contains(group.Key.CheCarry))
                continue; // avoid double counting the same che_carry in different categories

            handledCheCarry.Add(group.Key.CheCarry);

            var taskStatus = group.Key.TaskStatus;

            if (taskStatus == Constants.JobStepingStatus.ARRIVE_TO_ORIGIN)
                result.MovingToQuay++;
            else if (taskStatus == Constants.JobStepingStatus.ARRIVED_AT_ORIGIN || 
                taskStatus == Constants.JobStepingStatus.WAITING_PICKUP)
                result.AtQuay++;
            else if (taskStatus == Constants.JobStepingStatus.ARRIVE_TO_DESTINATION)
                result.MovingToYard++;
            else if (taskStatus == Constants.JobStepingStatus.ARRIVED_AT_BLOCK || 
                taskStatus == Constants.JobStepingStatus.ARRIVED_AT_DESTINATION || 
                taskStatus == Constants.JobStepingStatus.WAITING_DROP)
                result.AtYard++;
        }

        // All CheCarry seen in WorkInstructions
        var allCheCarry = workInstructions
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();

        // Identify CheCarry not in active WorkInstructions (i.e., not in progress)
        var inactiveCheCarry = allCheCarry
            .Where(c => !activeCheCarry.Contains(c))
            .ToHashSet();

        // Idle CheCarry = not in progress and equipment status != LOGOUT
        result.Idle = equipmentList
            .Where(eq => !activeCheCarry.Contains(eq.EquipmentName))
            .Where(eq => eq.Status != Constants.EquipmentStatus.LOGOUT)
            .Count();

        return result;
    }

    public async Task<(List<ItvActivityDto> itvActivity, EcuStatusDto ecuStatus)> GetItvActivityAndEcuStatus(
        List<string> cheCarries,
        List<WorkInstruction> workInstructions,
        List<VesselVisit> vesselVisits)
    {

        var fromDate = vesselVisits
            .Select(vv => vv.StartWorkTime ?? vv.Ata ?? vv.Eta)
            .Min(); // No fallback needed

        var auditLogs = await _vmtAuditLoginDataAccess.GetRecentAuditLogsAsync(cheCarries, fromDate);

        var itvActivityList = new List<ItvActivityDto>();
        var ecuStatus = new EcuStatusDto
        {
            EngineHours = 40,
            IdleHours = 10,
            StoppageHours = 0,
            FuelConsumpion = 20
        };

        foreach (var cheCarry in cheCarries)
        {
            // Work instructions for this cheCarry after fromDate
            var recentWorkInstructions = workInstructions
                .Where(wi => wi.CheCarry == cheCarry &&
                             wi.JobStartTime.HasValue &&
                             wi.JobCompleteTime.HasValue &&
                             wi.JobStartTime.Value >= fromDate)
                .ToList();

            // Active Time (sum of durations of completed jobs)
            double activeTime = recentWorkInstructions
                .Sum(wi => (wi.JobCompleteTime!.Value - wi.JobStartTime!.Value).TotalHours);

            // Login duration (from audit logs)
            double loginDuration = auditLogs
                .Where(log => log.EquipmentId == cheCarry &&
                              log.LoginTime.HasValue &&
                              log.LogoutTime.HasValue &&
                              log.LoginTime.Value >= fromDate)
                .Sum(log => (log.LogoutTime!.Value - log.LoginTime!.Value).TotalHours);

            double idleTime = Math.Max(0, loginDuration - activeTime); // Ensure no negative time

            itvActivityList.Add(new ItvActivityDto
            {
                Itv = cheCarry,
                Active = Math.Round(activeTime, 2),
                Idling = Math.Round(idleTime, 2),
                Stoppage = 0
            });
        }

        ecuStatus.EngineHours = Math.Round(itvActivityList.Sum(x => x.Active), 2);
        ecuStatus.IdleHours = Math.Round(itvActivityList.Sum(x => x.Idling), 2);

        return (itvActivityList, ecuStatus);
    }

    private PagedResponse<Object> GetAssertDetails(
        List<string> allCheCarry,
        List<Equipment> equipmentList,
        List<WorkInstruction> allWorkInstructions,
        int skip,
        int? take)
    {
        var serverTime = DateTime.UtcNow;

        var assertDetails = allCheCarry
            .Select(che =>
            {
                var equipment = equipmentList.FirstOrDefault(eq => eq.EquipmentName == che);
                var state = _equipmentStateService.GetEquipmentState(equipment!.Id);
                var wiForChe = allWorkInstructions
                    .Where(wi => wi.CheCarry == che)
                    .ToList();

                bool hasInProgressWI = wiForChe.Any(wi =>
                    wi.WorkInstructionStatus.Equals(JobStatus.INPROGRESS));

                string equipmentStatus = equipment?.Status ?? string.Empty;

                string operationStatus;

                if (hasInProgressWI &&
                    equipmentStatus.Equals(EquipmentStatus.AVAILABLE, StringComparison.OrdinalIgnoreCase))
                {
                    operationStatus = "Active";
                }
                else if ((equipmentStatus.Equals(EquipmentStatus.IDLE, StringComparison.OrdinalIgnoreCase) ||
                          equipmentStatus.Equals(EquipmentStatus.AVAILABLE, StringComparison.OrdinalIgnoreCase)))
                {
                    operationStatus = "Idle";
                }
                else
                {
                    operationStatus = "InActive";
                }
                
                return new ItvOpeartionalStatusDto
                {
                    Asset = che,
                    Type = equipment?.EquipmentType ?? "Unknown",
                    OperationStatus = operationStatus,
                    GpsTime = serverTime,
                    Ignition = operationStatus == "Active" ? "ON" : "OFF",
                    Make = equipment?.Make,
                    RfidTag1 = equipment?.RfidTag1,
                    RfidTag2 = equipment?.RfidTag2,
                    Latitude = state?.Latitude ?? 0,
                    Longitude = state?.Longitude ?? 0,
                    Status = state?.Status ?? "Unknown"
                };
            })
            .ToList();

        // Pagination
        var safeSkip = Math.Max(0, skip);
        var safeTake = take.HasValue && take.Value > 0 ? take.Value : 10;

        var pagedResult = assertDetails
            .Skip(safeSkip)
            .Take(safeTake)
            .ToArray();

        return new PagedResponse<Object>(assertDetails.Count, pagedResult);
    }

    // Active data with paging
    private PagedResponse<object> GetActiveItvData(
        List<WorkInstruction> workInstructions,
        List<Equipment> equipmentList,
        List<string> activeCheCarry,
        int skip,
        int? take)
    {
        var equipmentDict = equipmentList
            .Where(eq => activeCheCarry.Contains(eq.EquipmentName))
            .Where(eq => eq.Status != null && eq.Status == EquipmentStatus.AVAILABLE)
            .GroupBy(eq => eq.EquipmentName)
            .ToDictionary(g => g.Key, g => g.First());

        var grouped = workInstructions
            .Where(wi => wi.WorkInstructionStatus == JobStatus.INPROGRESS)
            .Select(wi => new { wi, key = wi.CheCarry})
            .Where(x => equipmentDict.ContainsKey(x.key))
            .GroupBy(x => x.key, x => x.wi)
            .ToList();

        var totalCount = grouped.Count;

        var paged = grouped
            .Skip(skip)
            .Take(take ?? totalCount)
            .Select(group =>
            {
                var cheCarry = group.Key;
                equipmentDict.TryGetValue(cheCarry, out var equipment);

                var state = _equipmentStateService.GetEquipmentState(equipment!.Id);
                var totalSeconds = group
                    .Where(wi => wi.JobStartTime.HasValue && wi.JobCompleteTime.HasValue)
                    .Sum(wi => (wi.JobCompleteTime.Value - wi.JobStartTime.Value).TotalSeconds);

                var timeSpan = TimeSpan.FromSeconds(totalSeconds);
                var formattedDuration = $"{timeSpan.Days}d {timeSpan.Hours}h {timeSpan.Minutes}m";

                return new ActiveItvDto
                {
                    Asset = cheCarry,
                    Type = equipment?.EquipmentType ?? "Unknown",
                    MovementState = group.OrderByDescending(w => w.JobStartTime)
                        .FirstOrDefault()?.JobSteppingStatus ?? "Unknown",
                    Active = formattedDuration,
                    Make = equipment?.Make,
                    RfidTag1 = equipment?.RfidTag1,
                    RfidTag2 = equipment?.RfidTag2,
                    Latitude = state?.Latitude ?? 0,
                    Longitude = state?.Longitude ?? 0,
                    Status = state?.Status ?? "Unknown"
                };
            })
            .Cast<object>()
            .ToList();

        return new PagedResponse<object>(totalCount, paged.ToArray());
    }

    // Idle data with paging
    private async Task<PagedResponse<object>> GetIdlingItvData(
        List<WorkInstruction> workInstructions,
        List<Equipment> equipmentList,
        List<VesselVisit> activeVesselVisits,
        List<string> activeCheCarry,
        int skip,
        int? take)
    {
        // Step 1: Collect all CheCarry names used in any WI
        var allCheCarry = workInstructions
            .Select(wi => wi.CheCarry)
            .Distinct()
            .ToList();
        var fromDate = activeVesselVisits
            .Select(vv => vv.StartWorkTime ?? vv.Ata ?? vv.Eta)
            .Min();
        var auditLogs = await _vmtAuditLoginDataAccess.GetRecentAuditLogsAsync(allCheCarry, fromDate);
        // Step 2: Build a filtered equipment dictionary for IDLE/AVAILABLE and not LOGOUT
        var equipmentDict = equipmentList
            .Where(eq =>
                !activeCheCarry.Contains(eq.EquipmentName) &&
                eq.Status != null &&
                !eq.Status.Equals(EquipmentStatus.LOGOUT))
            .GroupBy(eq => eq.EquipmentName)
            .ToDictionary(g => g.Key, g => g.First());

        // Step 3: Group WIs by CheCarry where CheCarry exists in equipmentDict
        var grouped = workInstructions
            .Select(wi => new { wi, key = wi.CheCarry})
            .Where(x => equipmentDict.ContainsKey(x.key))
            .GroupBy(x => x.key, x => x.wi)
            .ToList();

        var totalCount = grouped.Count;

        var paged = grouped
            .Skip(skip)
            .Take(take ?? totalCount)
            .Select(group =>
            {
                var cheCarry = group.Key;
                equipmentDict.TryGetValue(cheCarry, out var equipment);

                var state = _equipmentStateService.GetEquipmentState(equipment!.Id);
                // Calculate total active seconds for this equipment
                var activeSeconds = group
                    .Where(wi => wi.JobStartTime.HasValue && wi.JobCompleteTime.HasValue)
                    .Sum(wi => (wi.JobCompleteTime.Value - wi.JobStartTime.Value).TotalSeconds);

                // Calculate login session duration
                var loginSeconds = auditLogs
                    .Where(log => log.EquipmentId != null &&
                                  log.EquipmentId.Trim().ToUpperInvariant() == cheCarry &&
                                  log.LoginTime.HasValue && log.LogoutTime.HasValue)
                    .Sum(log => (log.LogoutTime.Value - log.LoginTime.Value).TotalSeconds);

                // Compute idling
                var idlingSeconds = Math.Max(0, loginSeconds - activeSeconds);
                var timeSpan = TimeSpan.FromSeconds(idlingSeconds);
                var formattedIdling = $"{timeSpan.Days}d {timeSpan.Hours}h {timeSpan.Minutes}m";

                return new IdilingItvDto
                {
                    Asset = cheCarry,
                    Type = equipment?.EquipmentType ?? "Unknown",
                    Idling = formattedIdling,
                    Make = equipment?.Make,
                    RfidTag1 = equipment?.RfidTag1,
                    RfidTag2 = equipment?.RfidTag2,
                    Latitude = state?.Latitude ?? 0,
                    Longitude = state?.Longitude ?? 0,
                    Status = state?.Status ?? "Unknown"
                };
            })
            .Cast<object>()
            .ToList();

        return new PagedResponse<object>(totalCount, paged.ToArray());
    }

}