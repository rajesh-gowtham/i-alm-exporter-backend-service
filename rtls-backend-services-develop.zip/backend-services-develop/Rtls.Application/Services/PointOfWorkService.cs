using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class PointOfWorkService : IPointOfWorkService
{
    private readonly IPointOfWorkDataAccess _dataAccess;
    private readonly IEquipmentPoolDataAccess _equipmentPoolDataAccess;
    private readonly IWorkInstructionDataAccess _workInstructionDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<PointOfWorkService> _logger;
    private readonly IMapper _mapper;

    public PointOfWorkService(
        ICurrentUserService currentUserService,
        ILogger<PointOfWorkService> logger,
        IMapper mapper,
        IPointOfWorkDataAccess dataAccess,
        IEquipmentPoolDataAccess equipmentPoolDataAccess,
        IWorkInstructionDataAccess workInstructionDataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _equipmentPoolDataAccess = equipmentPoolDataAccess ?? throw new ArgumentNullException(nameof(equipmentPoolDataAccess));
        _workInstructionDataAccess = workInstructionDataAccess ?? throw new ArgumentNullException(nameof(workInstructionDataAccess));
    }

    public async Task<PointOfWorkDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting point of work with ID: {PointOfWorkId}", id);
        var pointOfWork = await _dataAccess.GetByIdAsync(id, ct);

        if (pointOfWork == null)
        {
            _logger.LogWarning("Point of work with ID: {PointOfWorkId} not found", id);
            return null;
        }

        return _mapper.Map<PointOfWorkDto>(pointOfWork);
    }

    public async Task<PagedResponse<PointOfWorkDto>> GetAllAsync(int skip = 0, int? take = null, 
        string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all points of work");

        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);

        var dtos = _mapper.Map<PointOfWorkDto[]>(pagedEntities.Items);
        return new PagedResponse<PointOfWorkDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<PointOfWorkDto> CreateAsync(CreatePointOfWorkDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidatePointOfWorkData(dto);
        await ValidateDuplicateData(new List<CreatePointOfWorkDto> { dto }, ct);
        _logger.LogInformation("Creating new point of work: {Name}", dto.Name);

        var pointOfWork = _mapper.Map<PointOfWork>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        pointOfWork.CreatedBy = username;
        pointOfWork.UpdatedBy = username;
        pointOfWork.CreatedAt = now;
        pointOfWork.UpdatedAt = now;

        var createdPointOfWork = await _dataAccess.CreateAsync(pointOfWork, ct);

        _logger.LogInformation("Point of work created successfully with ID: {PointOfWorkId}", createdPointOfWork.Id);
        return _mapper.Map<PointOfWorkDto>(createdPointOfWork);
    }

    public async Task<bool> UpdateAsync(UpdatePointOfWorkDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidatePointOfWorkData(dto);

        _logger.LogInformation("Updating point of work with ID: {PointOfWorkId}", dto.Id);

        var entity = await _dataAccess.GetByIdAsync(dto.Id, ct);
        if (entity is null)
        {
            _logger.LogWarning("Point of work with ID: {PointOfWorkId} not found for update", dto.Id);
            return false;
        }

        _mapper.Map(dto, entity);
        entity.UpdatedBy = _currentUserService.GetUsername();
        entity.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(entity, ct);

        if (result)
        {
            _logger.LogInformation("Point of work with ID: {PointOfWorkId} updated successfully", dto.Id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting point of work with ID: {PointOfWorkId}", id);
        await RemovePowLinkedData(id, ct);
        var result = await _dataAccess.DeleteAsync(id, ct);

        if (result)
        {
            _logger.LogInformation("Point of work with ID: {PointOfWorkId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Point of work with ID: {PointOfWorkId} not found for deletion", id);
        }

        return result;
    }

    private async Task RemovePowLinkedData(long id, CancellationToken ct)
    {
        var jobCount = await _workInstructionDataAccess.GetCountByPow(id, ct);
        if (jobCount != 0)
        {
            _logger.LogError("POW has been assigned to the {count} WorkInstruction(s)", jobCount);
            throw new InvalidOperationException($"POW has been assigned to the {jobCount} WorkInstruction(s)");
        }
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreatePointOfWorkDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);
        var entities = new List<PointOfWork>();
        foreach (var dto in dtos)
        {
            var entity = _mapper.Map<PointOfWork>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            entity.CreatedBy = username;
            entity.UpdatedBy = username;
            entity.CreatedAt = now;
            entity.UpdatedAt = now;

            entities.Add(entity);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private async Task ValidateDuplicateData(IEnumerable<CreatePointOfWorkDto> dtos, CancellationToken ct)
    {
        var namesToCheck = dtos.Select(dto => dto.Name).ToList();
        // Check for existing pow names in the database
        var existingNames = await _dataAccess.CheckNameDuplicates(namesToCheck, ct);
        if (existingNames.Any())
        {
            var duplicates = string.Join(", ", existingNames);
            throw new ArgumentException($"The following pow name(s) already exist: {duplicates}");
        }
        var poolsToCheck = dtos.Select(dto => dto.Pool).ToList();
        // Check for existing pool names in the database
        var existingPools = await _dataAccess.CheckPoolDuplicates(poolsToCheck, ct);
        if (existingPools.Any())
        {
            var duplicates = string.Join(", ", existingPools);
            throw new ArgumentException($"The following pool name(s) already exist: {duplicates}");
        }
    }

    private void ValidatePointOfWorkData(CreatePointOfWorkDto dto)
    {
        // Add validation rules based on your requirements
        if (string.IsNullOrWhiteSpace(dto.Name))
        {
            _logger.LogError("Point of work name is required");
            throw new ArgumentException("Point of work name is required", nameof(dto.Name));
        }

        // Add other validations as needed
    }

    private void ValidatePointOfWorkData(UpdatePointOfWorkDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.Id <= 0)
        {
            _logger.LogError("Id must be greater than zero");
            throw new ArgumentException("Id must be greater than zero", nameof(dto.Id));
        }

        // Add other validations as needed (consider if name should be required on update)
    }
}
