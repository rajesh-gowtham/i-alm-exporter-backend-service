using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class VesselVisitService : IVesselVisitService
{
    private readonly IVesselVisitDataAccess _dataAccess;
    private readonly IWorkInstructionDataAccess _workInstructionDataAccess;
    private readonly IVesselBerthingDataAccess _vesselBerthingDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<VesselVisitService> _logger;
    private readonly IMapper _mapper;

    public VesselVisitService(
        ICurrentUserService currentUserService,
        ILogger<VesselVisitService> logger,
        IMapper mapper,
        IVesselVisitDataAccess dataAccess,
        IWorkInstructionDataAccess workInstructionDataAccess,
        IVesselBerthingDataAccess vesselBerthingDataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _workInstructionDataAccess = workInstructionDataAccess ?? throw new ArgumentNullException(nameof(workInstructionDataAccess));
        _vesselBerthingDataAccess = vesselBerthingDataAccess ?? throw new ArgumentNullException(nameof(vesselBerthingDataAccess));
    }

    public async Task<PagedResponse<VesselVisitDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all vessel visits");

        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedEntities.TotalCount == 0) return PagedResponse<VesselVisitDto>.Empty;

        var dtos = _mapper.Map<VesselVisitDto[]>(pagedEntities.Items);
        return new PagedResponse<VesselVisitDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<VesselVisitDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting vessel visit with ID: {VesselVisitId}", id);
        var visit = await _dataAccess.GetByIdAsync(id, ct);

        if (visit == null)
        {
            _logger.LogWarning("Vessel visit with ID: {VesselVisitId} not found", id);
            return null;
        }

        return _mapper.Map<VesselVisitDto>(visit);
    }

    public async Task<VesselVisitDto> CreateAsync(CreateVesselVisitDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselVisitData(dto);
        await ValidateDuplicateData(new List<CreateVesselVisitDto> { dto }, ct);
        // _logger.LogInformation("Creating new vessel visit for VesselId: {VesselId}", dto.VesselId);

        var visit = _mapper.Map<VesselVisit>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        visit.CreatedBy = username;
        visit.UpdatedBy = username;
        visit.CreatedAt = now;
        visit.UpdatedAt = now;

        var createdVisit = await _dataAccess.CreateAsync(visit, ct);

        _logger.LogInformation("Vessel visit created successfully with ID: {VesselVisitId}", createdVisit.Id);
        return _mapper.Map<VesselVisitDto>(createdVisit);
    }

    public async Task<bool> UpdateAsync(long id, UpdateVesselVisitDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselVisitData(dto);

        _logger.LogInformation("Updating vessel visit with ID: {VesselVisitId}", id);

        var visit = await _dataAccess.GetByIdAsync(id, ct);
        if (visit is null)
        {
            _logger.LogWarning("Vessel visit with ID: {VesselVisitId} not found for update", id);
            return false;
        }

        _mapper.Map(dto, visit);
        visit.UpdatedBy = _currentUserService.GetUsername();
        visit.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(visit, ct);

        if (result)
        {
            _logger.LogInformation("Vessel visit with ID: {VesselVisitId} updated successfully", id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting vessel visit with ID: {VesselVisitId}", id);
        await ValidateRelations(id, ct);
        var result = await _dataAccess.DeleteAsync(id, ct);

        if (result)
        {
            _logger.LogInformation("Vessel visit with ID: {VesselVisitId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Vessel visit with ID: {VesselVisitId} not found for deletion", id);
        }

        return result;
    }

    private async Task ValidateRelations(long id, CancellationToken ct)
    {
        var berthings = await _vesselBerthingDataAccess.GetCountByVesselVisitId(id, ct);
        if (berthings != 0)
        {
            _logger.LogError($"A vessel visit associated with {berthings} berthing(s).");
            throw new ArgumentException($"A vessel visit associated with {berthings} berthing(s).");
        }
        var workInstructions = await _workInstructionDataAccess.GetTotalJobsCountAsync(new List<long> { id }, ct);
        if (workInstructions != 0)
        {
            _logger.LogError($"A vessel visit associated with {workInstructions} work instruction(s).");
            throw new ArgumentException($"A vessel visit associated with {workInstructions} work instruction(s).");
        }
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateVesselVisitDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);
        var entities = new List<VesselVisit>();
        foreach (var dto in dtos)
        {
            var equipment = _mapper.Map<VesselVisit>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            equipment.CreatedBy = username;
            equipment.UpdatedBy = username;
            equipment.CreatedAt = now;
            equipment.UpdatedAt = now;

            entities.Add(equipment);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private async Task ValidateDuplicateData(IEnumerable<CreateVesselVisitDto> dtos, CancellationToken ct)
    {
        var duplicateNames = dtos
           .GroupBy(vv => vv.VisitRef)
           .Where(g => g.Count() > 1)
           .Select(g => g.Key)
           .ToList();
        if (duplicateNames.Any())
        {
            var duplicates = string.Join(", ", duplicateNames);
            _logger.LogError($"The following visit Reference name(s) already exist: {duplicates}");
            throw new InvalidOperationException($"The following visit Reference name(s) already exist: {duplicates}");
        }
        var nameToCheck = dtos.Select(dto => dto.VisitRef).ToList();
        // Check for existing Vessel Reference in the database
        var existing = await _dataAccess.CheckDuplicatesAsync(nameToCheck, ct);
        if (existing.Any())
        {
            var duplicates = string.Join(", ", existing);
            _logger.LogError($"The following visit Reference name(s) already exist: {duplicates}");
            throw new ArgumentException($"The following visit Reference name(s) already exist: {duplicates}");
        }
    }

    private void ValidateVesselVisitData(CreateVesselVisitDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.VisitRef))
        {
            _logger.LogError("Vessel visit code is required");
            throw new ArgumentException("Vessel visit code is required", nameof(dto.VisitRef));
        }

        if (long.IsNegative(dto.VesselId))
        {
            _logger.LogError("Vessel visit is required");
            throw new ArgumentException("Vessel name is required", nameof(dto.VesselId));
        }

        if (string.IsNullOrWhiteSpace(dto.InboundVoyage))
        {
            _logger.LogError("Inbound voyage is required");
            throw new ArgumentException("Inbound voyage is required", nameof(dto.InboundVoyage));
        }

        if (string.IsNullOrWhiteSpace(dto.OutboundVoyage))
        {
            _logger.LogError("Outbound voyage is required");
            throw new ArgumentException("Outbound voyage is required", nameof(dto.OutboundVoyage));
        }

        if (!Enum.IsDefined(typeof(VesselVisitPhase), dto.Phase))
        {
            _logger.LogError("Invalid vessel visit phase");
            throw new ArgumentException("Invalid vessel visit phase", nameof(dto.Phase));
        }

        if (string.IsNullOrWhiteSpace(dto.LineOperator))
        {
            _logger.LogError("Line operator is required");
            throw new ArgumentException("Line operator is required", nameof(dto.LineOperator));
        }
    }

    private void ValidateVesselVisitData(UpdateVesselVisitDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.InboundVoyage))
        {
            _logger.LogError("Inbound voyage is required");
            throw new ArgumentException("Inbound voyage is required", nameof(dto.InboundVoyage));
        }

        if (string.IsNullOrWhiteSpace(dto.OutboundVoyage))
        {
            _logger.LogError("Outbound voyage is required");
            throw new ArgumentException("Outbound voyage is required", nameof(dto.OutboundVoyage));
        }

        if (!Enum.IsDefined(typeof(VesselVisitPhase), dto.Phase))
        {
            _logger.LogError("Invalid vessel visit phase");
            throw new ArgumentException("Invalid vessel visit phase", nameof(dto.Phase));
        }

        if (string.IsNullOrWhiteSpace(dto.LineOperator))
        {
            _logger.LogError("Line operator is required");
            throw new ArgumentException("Line operator is required", nameof(dto.LineOperator));
        }

        if (dto.VesselId <= 0)
        {
            _logger.LogError("VesselId must be greater than zero");
            throw new ArgumentException("VesselId must be greater than zero", nameof(dto.VesselId));
        }

        // Add other validations as needed
    }
}