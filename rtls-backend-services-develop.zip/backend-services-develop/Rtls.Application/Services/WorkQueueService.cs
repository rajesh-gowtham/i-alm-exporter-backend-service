﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Application.Services
{
    public class WorkQueueService : IWorkQueue
    {
        private readonly IWorkQueueDataAccess _dataAccess;
        private readonly IPointOfWorkDataAccess _pointOfWorkDataAccess;
        private readonly IVesselVisitDataAccess _vesselVisitDataAccess;
        private readonly ICurrentUserService _currentUserService;
        private readonly ILogger<WorkQueueService> _logger;
        private readonly IMapper _mapper;

        public WorkQueueService(
           ICurrentUserService currentUserService,
           ILogger<WorkQueueService> logger,
           IMapper mapper,
           IWorkQueueDataAccess dataAccess,
           IPointOfWorkDataAccess pointOfWorkDataAccess,
           IVesselVisitDataAccess vesselVisitDataAccess)
        {
            _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
            _pointOfWorkDataAccess = pointOfWorkDataAccess;
            _vesselVisitDataAccess = vesselVisitDataAccess;
        }

        public async Task<WorkQueueDto?> GetByIdAsync(long id, CancellationToken ct = default)
        {
            _logger.LogInformation("Getting work instruction with ID: {WorkInstructionId}", id);
            var entity = await _dataAccess.GetByIdAsync(id, ct);

            if (entity == null)
            {
                _logger.LogWarning("Work instruction with ID: {WorkInstructionId} not found", id);
                return null;
            }

            return _mapper.Map<WorkQueueDto>(entity);
        }

        public async Task<Dictionary<WorkQueue, List<CreateWorkInstructionDto>>> CreateAsync(IEnumerable<CreateWorkInstructionDto> dto, CancellationToken ct = default)
        {
            try
            {
                // Group by derived Name, VesselVisitId, MoveType, and Deck
                var groupedDtos = dto
                    .GroupBy(d => new
                    {
                        Name = d.MoveType switch
                        {
                            Constants.MoveTypes.DISCHARGE => d.FromLocation?.Length > 2 ? d.FromLocation[..2] : d.FromLocation,
                            Constants.MoveTypes.LOAD => d.TargetLocation?.Length > 2 ? d.TargetLocation[..2] : d.TargetLocation,
                            _ => null
                        },
                        d.VesselVisitId,
                        d.MoveType,
                        d.Deck
                    })
                    .ToList();

                var vesselVisitIds = groupedDtos.Select(g => g.Key.VesselVisitId).Distinct().ToList();
                var existingQueues = await GetByVesselVisitIdsAsync(vesselVisitIds, ct);

                var result = new Dictionary<WorkQueue, List<CreateWorkInstructionDto>>();

                foreach (var group in groupedDtos)
                {
                    var key = group.Key;
                    var matchingQueue = existingQueues.FirstOrDefault(q =>
                        q.Name == key.Name &&
                        q.VesselVisitId == key.VesselVisitId &&
                        q.Type == key.MoveType &&
                        q.Deck == key.Deck);

                    var dtoList = group.ToList();

                    if (matchingQueue != null)
                    {
                        result.Add(matchingQueue, dtoList);
                    }
                    else
                    {
                        var newQueue = await MapWorkQueue(dtoList[0]);
                        var createdQueue = await _dataAccess.CreateSingleAsync(newQueue, ct);
                        result.Add(createdQueue, dtoList);
                    }
                }
                return await GroupTwinContainersInSameQueue(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating work queues.");
                throw new InvalidOperationException("An error occurred while creating work queues.", ex);
            }
        }

        private async Task<Dictionary<WorkQueue, List<CreateWorkInstructionDto>>> GroupTwinContainersInSameQueue(
            Dictionary<WorkQueue, List<CreateWorkInstructionDto>> result)
        {
            var allInstructions = result
                .SelectMany(kv => kv.Value.Select(dto => (WorkQueue: kv.Key, Dto: dto)))
                .ToList();

            foreach (var (sourceQueue, dto) in allInstructions)
            {
                //Twin containers in same work queue
                if (dto.Mode == Constants.WorkInstructionMode.TWIN && !string.IsNullOrEmpty(dto.PairContainer))
                {
                    var pairEntry = allInstructions.FirstOrDefault(x => x.Dto.ContainerId == dto.PairContainer);

                    if (pairEntry.Dto != null)
                    {
                        var primaryDto = dto;
                        var secondaryDto = pairEntry.Dto;
                        if (result[sourceQueue].Contains(primaryDto) && result[pairEntry.WorkQueue].Contains(secondaryDto))
                        {
                            // Remove secondaryDto from its original queue
                            result[pairEntry.WorkQueue].Remove(secondaryDto);
                            // Remove any previous accidental occurrence from sourceQueue
                            result[sourceQueue].Remove(secondaryDto);
                            // Insert after primaryDto's index
                            var primaryIndex = result[sourceQueue].IndexOf(primaryDto);
                            if (primaryIndex != -1)
                            {
                                result[sourceQueue].Insert(primaryIndex + 1, secondaryDto);
                            }
                        }
                    }
                }
                // 40 Feet containers in 20 Feet container workqueue
                else if (dto.IsoCode.StartsWith("4") && dto.MoveType.Equals(Constants.MoveTypes.DISCHARGE))
                {
                    string bay = (int.Parse(dto.FromLocation[..2]) - 1).ToString();
                    var oddEntry = allInstructions.FirstOrDefault(x => x.Dto.FromLocation[..2].StartsWith(bay) 
                                    && x.Dto.Deck.Equals(dto.Deck));
                    if (oddEntry.Dto != null)
                    {
                        var primaryDto = dto;
                        // Remove secondaryDto from its original queue
                        result[sourceQueue].Remove(primaryDto);
                        // Remove any previous accidental occurrence from sourceQueue
                        result[oddEntry.WorkQueue].Add(primaryDto);
                        if(result[sourceQueue].Count() == 0)
                        {
                            result.Remove(sourceQueue);
                        }
                    }
                }
                await Task.Yield();
            }
            return result;
        }

        public async Task<List<WorkQueue>> GetByVesselVisitIdsAsync(List<long> vesselVisitIds, CancellationToken ct = default)
        {
            return await _dataAccess.GetByVesselVisitIdsAsync(vesselVisitIds, ct);
        }

        public Task<WorkQueue> MapWorkQueue(CreateWorkInstructionDto dto)
        {
            return Task.FromResult(new WorkQueue
            {
                VesselVisitId = dto.VesselVisitId,
                Name = dto.MoveType == Constants.MoveTypes.DISCHARGE
                           ? (dto.FromLocation?.Length > 2 ? dto.FromLocation.Substring(0, 2) : dto.FromLocation)
                           : dto.MoveType == Constants.MoveTypes.LOAD
                           ? (dto.TargetLocation?.Length > 2 ? dto.TargetLocation.Substring(0, 2) : dto.TargetLocation)
                           : null,

                Type = dto.MoveType,
                Deck = dto.Deck,
                PointOfWorkId = dto.PointOfWorkId,
                Status = Constants.JobStatus.PLANNED,
                CreatedBy = _currentUserService.GetUsername(),
                CreatedAt = DateTime.UtcNow
            });
        }
    }

}
