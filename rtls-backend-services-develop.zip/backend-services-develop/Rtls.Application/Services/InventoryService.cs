﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services
{
     public class InventoryService: IInventoryService
    {

        private readonly IWorkInstructionDataAccess _workInstructionDataAccess;
        private readonly IAlarmsEventsDataAccess _alarmsEventsDataAccess;
        private readonly IWorkQueueDataAccess _workQueueDataAccess;
        private readonly ICurrentUserService _currentUserService;
        private readonly ILogger<InventoryService> _logger;
        private readonly IMapper _mapper;

        public InventoryService(
            ICurrentUserService currentUserService,
            ILogger<InventoryService> logger,
            IMapper mapper,
            IWorkInstructionDataAccess workInstructionDataAccess,
            IAlarmsEventsDataAccess alarmsEventsDataAccess,
            IWorkQueueDataAccess workQueueDataAccess)
        {
            _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _workInstructionDataAccess = workInstructionDataAccess ?? throw new ArgumentNullException(nameof(workInstructionDataAccess));
            _alarmsEventsDataAccess = alarmsEventsDataAccess ?? throw new ArgumentNullException(nameof(alarmsEventsDataAccess));
            _workQueueDataAccess = workQueueDataAccess ?? throw new ArgumentNullException(nameof(workQueueDataAccess));
        }


        public async Task<PagedResponse<InventoryContainerDto>> GetAllInventoryContainerAsync(int skip = 0, int? take = null,
        string search = "", CancellationToken ct = default)
        {
            _logger.LogInformation("Getting all work instructions");
            var pagedEntities = await _workInstructionDataAccess.GetAllInventoryContainerAsync(skip, take, search, ct);

            var result = pagedEntities.Items.Select(x => new InventoryContainerDto
            {
                Id = x.Id,
                ContainerId = x.ContainerId,
                IsoCode = x.IsoCode,
                Location = x.TargetLocation
            }).ToList();

            if (result.Count == 0) return PagedResponse<InventoryContainerDto>.Empty;

            var dtos = _mapper.Map<InventoryContainerDto[]>(result);
            return new PagedResponse<InventoryContainerDto>(result.Count, dtos);
        }

        public async Task<PagedResponse<InventoryVesselVisitDto>> GetAllInventoryVessel(int skip = 0, int? take = null,
            string search = "", CancellationToken ct = default)
        {
            _logger.LogInformation("Get All Inventory Vessel");

            var pagedEntities = await _workInstructionDataAccess.GetAllInventoryVessel(skip, take, search, ct);

            var result = pagedEntities.Items
                   .Select(x => new InventoryVesselVisitDto
                     {
                         Id = x.VesselVisit?.Id ?? 0,
                         VisitRef = x.VesselVisit?.VisitRef ?? string.Empty,
                         LineOperator = x.VesselVisit?.LineOperator ?? string.Empty,
                         VesselName = x.VesselVisit?.Vessel?.VesselName ?? string.Empty,
                         VesselClass = x.VesselVisit?.Vessel?.VesselClass ?? string.Empty,
                         Hatch = x.VesselVisit?.Id != null ? MapVesselEvents(x.VesselVisit.Id, ct).Result : []
                    })
                 // Filter distinct by Id (ignore zero if needed)
                 .GroupBy(dto => dto.Id)
                 .Where(g => g.Key != 0)        // optional: exclude Id=0 if it means "no visit"
                 .Select(g => g.First())
                 .ToList();

            var dtos = _mapper.Map<InventoryVesselVisitDto[]>(result);
            return new PagedResponse<InventoryVesselVisitDto>(pagedEntities.TotalCount, dtos);
        }

        private async Task<List<AlarmsEventsDto>> MapVesselEvents(long id, CancellationToken ct)
        {
            var events = await _alarmsEventsDataAccess.GetByVesselVisit(id, "Hatch", ct);

            return events.Select(itr => new AlarmsEventsDto
            {
                Id = itr.Id,
                EventName = itr.EventName,
                StartTime = itr.StartTime,
                EndTime = itr.EndTime,
                Asset = itr.Equipment?.EquipmentName,
                VisitRef = itr.VesselVisit?.VisitRef,
                Notes = itr.Notes,
                WorkQueue = itr.WorkQueue?.Name
            }).ToList();
        }

        public async Task<bool> ContainerClearAsync(ContainerClearRequestdto containerClearRequestdto, CancellationToken ct = default)
        {
            
            var idList= containerClearRequestdto.Ids;
            var entities = await _workInstructionDataAccess.GetByIds(idList, ct);
            var WorkQueueIds = entities
                .Select(j => j.WorkQueue.Id)
                .Distinct()
                .ToList();
            var result = await _workInstructionDataAccess.ContainerClearAsync(idList, ct);
            if (result)
            {
                _logger.LogInformation("Container Clear  successfully");
                await _alarmsEventsDataAccess.ClearAsync(WorkQueueIds, ct);
                result = await _workQueueDataAccess.DeleteAsync(WorkQueueIds, ct);
            }
            else
            {
                _logger.LogWarning("Container of ID not found for deletion");
            }

            return result;
        }

        public async Task<InventoryContainerListDto> GetInventoryContainerById(long id, CancellationToken ct = default)
        {

            var result = await _workInstructionDataAccess.GetInventoryContainerById(id, ct);
            var dto = MapToInventoryContainerListDto(result);
            return dto;
        }

        public InventoryContainerListDto MapToInventoryContainerListDto(WorkInstruction wi)
        {
            return new InventoryContainerListDto
            {
                MoveType = wi.MoveType,
                VesselRef = wi.VesselVisit.VisitRef,  // Navigation property
                CheCarry = wi.CheCarry,
                Pow = wi.PointOfWork.Name,            // Assuming this maps to "Pow"
                Mode = wi.Mode,
                AssignedChe = wi.AssignedChe,
                AssignedLane=wi.AssignedLane,
                Block= wi.TargetLocation[..2] + "W",
                Position = wi.TargetLocation[..2] + "W" + wi.TargetLocation.Substring(2, 2),
                PositionOnCarriage =wi.PositionOnCarriage,
                FromPosition = wi.FromLocation,
                JobCreatedTime = wi.CreatedAt,
                JobStartTime =wi.JobStartTime,
                DispatchTime =wi.DispatchTime,
                TimeAtOrigin =wi.TimeAtOrigin,
                DischargeTime = wi.DischargeTime,
                TimeFacilityIn = wi.TimeFacilityIn,
                TimeAtDestination = wi.TimeAtDestination,
                JobCompleteTime = wi.JobCompleteTime,
            };
        }
    }
}

