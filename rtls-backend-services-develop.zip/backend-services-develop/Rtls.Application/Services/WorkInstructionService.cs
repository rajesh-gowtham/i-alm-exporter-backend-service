using System.Collections.Immutable;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class WorkInstructionService : IWorkInstructionService
{
    private readonly IWorkInstructionDataAccess _dataAccess;
    private readonly IEquipmentPoolAssignmentDataAccess _equipmentPoolAssignmentDataAccess;
    private readonly IPointOfWorkDataAccess _pointOfWorkDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly IWorkQueueDataAccess _workQueueDataAccess;
    private readonly IAlarmsEventsDataAccess _alarmsEventsDataAccess;
    private readonly IEquipmentDataAccess _equipmentDataAccess;
    private readonly InMemoryMessageBus _messageBus;
    private readonly IWorkQueue _workQueueService;
    private readonly ILogger<WorkInstructionService> _logger;
    private readonly IMapper _mapper;

    public WorkInstructionService(
        ICurrentUserService currentUserService,
        IWorkQueue workQueueService,
        ILogger<WorkInstructionService> logger,
        IMapper mapper,
        IWorkInstructionDataAccess dataAccess,
        IEquipmentPoolAssignmentDataAccess equipmentPoolAssignmentDataAccess,
        IPointOfWorkDataAccess pointOfWorkDataAccess,
        IWorkQueueDataAccess workQueueDataAccess,
        IAlarmsEventsDataAccess alarmsEventsDataAccess,
        IEquipmentDataAccess equipmentDataAccess, InMemoryMessageBus messageBus)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _workQueueService = workQueueService ?? throw new ArgumentNullException(nameof(workQueueService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _equipmentPoolAssignmentDataAccess = equipmentPoolAssignmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentPoolAssignmentDataAccess));
        _pointOfWorkDataAccess = pointOfWorkDataAccess ?? throw new ArgumentNullException(nameof(pointOfWorkDataAccess));
        _workQueueDataAccess = workQueueDataAccess ?? throw new ArgumentNullException(nameof(workQueueDataAccess));
        _alarmsEventsDataAccess = alarmsEventsDataAccess ?? throw new ArgumentNullException(nameof(alarmsEventsDataAccess));
        _equipmentDataAccess = equipmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentDataAccess));
        _messageBus = messageBus;
    }

    public async Task<PagedResponse<WorkInstructionDto>> GetAllAsync(int skip = 0,
        int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all work instructions");
        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedEntities.TotalCount == 0) return PagedResponse<WorkInstructionDto>.Empty;

        var dtos = _mapper.Map<WorkInstructionDto[]>(pagedEntities.Items);
        return new PagedResponse<WorkInstructionDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<WorkInstructionDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting work instruction with ID: {WorkInstructionId}", id);
        var entity = await _dataAccess.GetByIdAsync(id, ct);

        if (entity == null)
        {
            _logger.LogWarning("Work instruction with ID: {WorkInstructionId} not found", id);
            return null;
        }

        return _mapper.Map<WorkInstructionDto>(entity);
    }

    public async Task<WorkInstructionDto> CreateAsync(CreateWorkInstructionDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateWorkInstructionData(dto);
        await ValidateDuplicateData(new List<CreateWorkInstructionDto>
        {
            dto
        }, ct);
        _logger.LogInformation("Creating new work instruction for VesselVisitId: {VesselVisitId}", dto.VesselVisitId);

        var entity = _mapper.Map<WorkInstruction>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.TaskStatus = Constants.JobStepingStatus.YET_TO_START;
        entity.CreatedBy = username;
        entity.UpdatedBy = username;
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        var createdEntity = await _dataAccess.CreateAsync(entity, ct);

        // event
        await _messageBus.PublishAsync(new RtlsSystemEvent<WorkInstruction>(
            SystemEventType.WorkInstructionCreated, createdEntity), ct);

        _logger.LogInformation("Work instruction created successfully with ID: {WorkInstructionId}", createdEntity.Id);
        return _mapper.Map<WorkInstructionDto>(createdEntity);
    }

    // clean - means without updating nav properties, in this case only WorkQueue
    public async Task<bool> UpdateAsync(UpdateWorkInstructionDto dto, bool clean = false, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateWorkInstructionData(dto);

        _logger.LogInformation("Updating work instruction with ID: {WorkInstructionId}", dto.Id);

        var entity = await _dataAccess.GetByIdAsync(dto.Id, ct);
        if (entity is null)
        {
            _logger.LogWarning("Work instruction with ID: {WorkInstructionId} not found for update", dto.Id);
            return false;
        }
        long sequence = entity.Sequence;
        string pairContainer = entity.PairContainer;
        _mapper.Map(dto, entity);

        entity.UpdatedBy = _currentUserService.GetUsername();
        entity.UpdatedAt = DateTime.UtcNow;
        entity.Sequence = sequence;
        entity.PairContainer = pairContainer;

        bool result;
        if (clean)
            result = await _dataAccess.UpdateEntityAsync(entity, ct);
        else
            result = await _dataAccess.UpdateAsync(entity, ct);
        
        if (result)
        {
            _logger.LogInformation("Work instruction with ID: {WorkInstructionId} updated successfully", dto.Id);

            // event
            await _messageBus.PublishAsync(new RtlsSystemEvent<WorkInstruction>(
                SystemEventType.WorkInstructionUpdated, entity), ct);
        }

        return result;
    }

    // temp solution
    public async Task UpdateWorkQueueStatus(long workQueueId, CancellationToken ct)
    {
        var workQueue = await _workQueueDataAccess.GetByIdAsync(workQueueId, ct);
        if (workQueue == null)
        {
            _logger.LogWarning("Work queue with ID: {WorkQueueId} not found", workQueueId);
            return;
        }

        var pendingJobs = workQueue.WorkInstructions
            .Count(x => !x.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED));

        if (pendingJobs == 0)
        {
            workQueue.Status = Constants.JobStatus.COMPLETED;
            workQueue.UpdatedAt = DateTime.UtcNow;
            await _workQueueDataAccess.UpdateAsync(workQueue, ct);
        }
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting work instruction with ID: {WorkInstructionId}", id);
        var entity = await _dataAccess.GetByIdAsync(id, ct) ?? throw new InvalidOperationException("Container not found!");

        var result = await _dataAccess.DeleteAsync(entity, ct);

        if (result)
        {
            _logger.LogInformation("Work instruction with ID: {WorkInstructionId} deleted successfully", id);
            await _alarmsEventsDataAccess.ClearAsync([entity.WorkQueueId], ct);
            await _workQueueDataAccess.DeleteAsync([entity.WorkQueueId], ct);
        }
        else
        {
            _logger.LogWarning("Work instruction with ID: {WorkInstructionId} not found for deletion", id);
        }

        return result;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateWorkInstructionDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);

        var updatedDtos = await ValidateTwinModeSequenceAsync(dtos);

        var workQueueMap = await _workQueueService.CreateAsync(updatedDtos, ct);

        var entities = new List<WorkInstruction>();

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;
        long count = 1;
        foreach (var (workQueue, workInstrutionDtos) in workQueueMap)
        {
            count = 1;
            var mappedEquipments = workInstrutionDtos.Select(dto =>
            {
                var equipment = _mapper.Map<WorkInstruction>(dto);
                equipment.TaskStatus = Constants.JobStepingStatus.YET_TO_START;
                equipment.CreatedBy = username;
                equipment.UpdatedBy = username;
                equipment.CreatedAt = now;
                equipment.UpdatedAt = now;

                equipment.Sequence = workQueue.WorkInstructions.Count() == 0 ? count++ : workQueue.WorkInstructions.Count() + count++;
                equipment.WorkQueueId = workQueue.Id;
                equipment.WorkQueue = workQueue;
                return equipment;
            });

            entities.AddRange(mappedEquipments);
        }
        await _dataAccess.CreateBatchAsync(entities, ct);
        return await JobStatusUpdateWhenWQActive(workQueueMap, ct);
    }

    private async Task<bool> JobStatusUpdateWhenWQActive(Dictionary<WorkQueue, List<CreateWorkInstructionDto>> workQueueMap, CancellationToken ct)
    {
        var workQueues = workQueueMap.Keys;
        foreach (var workQueue in workQueues)
        {
            if (IsWorkQueueActive(workQueue))
            {
                await JobStatusUpdate(workQueue, Constants.JobStatus.INPROGRESS, ct);
            }
        }
        return true;
    }

    private bool IsWorkQueueActive(WorkQueue workQueue)
    {
        if (workQueue.Status == Constants.JobStatus.COMPLETED || workQueue.Status == Constants.JobStatus.SUSPENDED
                                                              || workQueue.Status == Constants.JobStatus.PLANNED || !workQueue.WorkInstructions.Any())
            return false;

        return workQueue.WorkInstructions.All(wi => wi.WorkInstructionStatus == Constants.JobStatus.COMPLETED) == false;
    }

    private async Task ValidateDuplicateData(IEnumerable<CreateWorkInstructionDto> dtos, CancellationToken ct = default)
    {
        var duplicateIds = dtos
            .GroupBy(wi => wi.ContainerId)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        if (duplicateIds.Any())
        {
            var duplicates = string.Join(", ", duplicateIds);
            _logger.LogError($"The following container id(s) already exist: {duplicates}");
            throw new InvalidOperationException($"The following container id(s) already exist: {duplicates}");
        }
        var idToCheck = dtos.Select(dto => dto.ContainerId).ToList();

        // Check for existing Container id in the database
        var existingIds = await _dataAccess.CheckDuplicates(idToCheck, ct);

        if (existingIds.Any())
        {
            var duplicates = string.Join(", ", existingIds);
            _logger.LogError($"The following container id(s) already exist: {duplicates}");
            throw new ArgumentException($"The following container id(s) already exist: {duplicates}");
        }
    }

    private void ValidateWorkInstructionData(CreateWorkInstructionDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.VesselVisitId <= 0)
        {
            _logger.LogError("VesselVisitId must be greater than zero");
            throw new ArgumentException("VesselVisitId must be greater than zero", nameof(dto.VesselVisitId));
        }

        if (string.IsNullOrWhiteSpace(dto.MoveType))
        {
            _logger.LogError("Move type is required");
            throw new ArgumentException("Move type is required", nameof(dto.MoveType));
        }

        // if (dto.EquipmentId <= 0)
        // {
        //     _logger.LogError("EquipmentId must be greater than zero");
        //     throw new ArgumentException("EquipmentId must be greater than zero", nameof(dto.EquipmentId));
        // }

        // Add other validations as needed
    }

    private void ValidateWorkInstructionData(UpdateWorkInstructionDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.Id <= 0)
        {
            _logger.LogError("Id must be greater than zero");
            throw new ArgumentException("Id must be greater than zero", nameof(dto.Id));
        }

        if (dto.VesselVisitId <= 0)
        {
            _logger.LogError("VesselVisitId must be greater than zero");
            throw new ArgumentException("VesselVisitId must be greater than zero", nameof(dto.VesselVisitId));
        }

        if (string.IsNullOrWhiteSpace(dto.MoveType))
        {
            _logger.LogError("Move type is required");
            throw new ArgumentException("Move type is required", nameof(dto.MoveType));
        }

        // if (dto.EquipmentId <= 0)
        // {
        //     _logger.LogError("EquipmentId must be greater than zero");
        //     throw new ArgumentException("EquipmentId must be greater than zero", nameof(dto.EquipmentId));
        // }

        // Add other validations as needed
    }

    public async Task<PagedResponse<WorkInstructionDto>> GetByWorkQueueIdAsync(
        long workQueueId,
        int skip, int take,
        string search = "",
        CancellationToken ct = default)
    {
        // Retrieve work instructions from data access layer based on workQueueId and search text
        var workInstructions = await _dataAccess.GetByWorkQueueIdAsync(skip, take, workQueueId, search, ct);

        var totalCount = workInstructions.TotalCount;
        if (string.IsNullOrEmpty(search)) totalCount = workInstructions.Items.Length;

        // Map WorkInstruction entities to WorkInstructionDto using AutoMapper
        var workInstructionRes = _mapper.Map<List<WorkInstructionDto>>(workInstructions.Items);

        return new PagedResponse<WorkInstructionDto>(totalCount, workInstructionRes.OrderBy(w => w.Sequence).ToArray());
    }

    public async Task<bool> JobStatusUpdate(WorkQueue workQueue, string action, CancellationToken ct = default)
    {
        var pow = await _pointOfWorkDataAccess.GetByIdAsync(workQueue.PointOfWorkId, ct);
        await ValidateHatchRemoval(workQueue, ct);
        var assignedItvs = await _equipmentPoolAssignmentDataAccess.GetAssignedEquipmentNames(pow.Pool);
        var validPositions = new HashSet<string>
        {
            "1",
            "3"
        };
        if (assignedItvs == null)
        {
            _logger.LogError("No assigned ITVs were found for the POW: {powName}", pow.Name);
            throw new InvalidOperationException($"No assigned ITVs were found for the POW: {pow.Name}");
        }

        var workInstructions = workQueue.WorkInstructions.OrderBy(wi => wi.Sequence).ToArray();
        foreach (var itv in assignedItvs)
        {
            for (int i = 0; i < workInstructions.Count(); i++)
            {
                var wi = workInstructions[i];
                if (itv.Equals(wi.CheCarry) && !wi.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED))
                {
                    // This is for Single Discharge twin carry
                    if (wi.PairContainer == null && i + 1 < workInstructions.Count() && !wi.IsoCode.StartsWith("4"))
                    {
                        var nextWi = workInstructions[i + 1];
                        if (!nextWi.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED) && nextWi.Mode.Equals(wi.Mode)
                                                                                                && nextWi.IsoCode.StartsWith("2") && wi.IsoCode.StartsWith("2")
                                                                                                && nextWi.CheCarry.Equals(wi.CheCarry) && validPositions.Contains(wi.PositionOnCarriage)
                                                                                                && validPositions.Contains(nextWi.PositionOnCarriage)
                                                                                                && wi.PositionOnCarriage != nextWi.PositionOnCarriage)
                        {
                            await UpdateWorkInstructionJobStatus(new List<WorkInstruction>
                            {
                                wi,
                                nextWi
                            }, action);
                            break;
                        }
                    }
                    // This is for twin discharge twin carry
                    if (wi.PairContainer != null && i + 1 < workInstructions.Count())
                    {
                        var nextWi = workInstructions[i + 1];

                        if (!nextWi.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED)
                            && nextWi.ContainerId.Equals(wi.PairContainer))
                        {
                            await UpdateWorkInstructionJobStatus(new List<WorkInstruction>
                            {
                                wi,
                                nextWi
                            }, action);
                            break;
                        }
                    }
                    else
                    {
                        await UpdateWorkInstructionJobStatus(new List<WorkInstruction>
                        {
                            wi
                        }, action);
                    }
                    break;
                }
            }
        }
        return true;
    }

    private async Task ValidateHatchRemoval(WorkQueue workQueue, CancellationToken ct)
    {
        if (workQueue.Deck.Equals("B"))
        {
            string oddWqName = int.Parse(workQueue.Name) % 2 == 0 ? (int.Parse(workQueue.Name) - 1).ToString() : (int.Parse(workQueue.Name) + 2).ToString();
            var wqNames = new List<string>
            {
                oddWqName,
                workQueue.Name
            };
            var deckAWq = await _workQueueDataAccess.GetADeckWorkQueue(wqNames, workQueue.VesselVisitId, "A", ct);
            if (deckAWq.Count != 0)
            {
                string wqName = string.Join(", ", deckAWq.Select(wq => wq + "A"));
                _logger.LogError("Cannot activate below deck before completing the {workQueue}", wqName);
                throw new InvalidOperationException($"Cannot activate below deck before completing the {wqName}.");
            }
            else
            {
                oddWqName = int.Parse(workQueue.Name) % 2 == 0 ? (int.Parse(workQueue.Name) - 1).ToString() : (int.Parse(workQueue.Name) + 2).ToString();
                wqNames = new List<string>
                {
                    oddWqName,
                    workQueue.Name
                };
                var isHatchRemoved = await _alarmsEventsDataAccess.FindHatchRemoval(wqNames, workQueue.VesselVisitId, ct);
                if (isHatchRemoved) return;
                var equipment = await _equipmentDataAccess.GetByNameAsync(workQueue.PointOfWork.Name, ct);
                var date = DateTime.UtcNow;
                var hatchEvent = new AlarmsEvents
                {
                    EventName = "Hatch",
                    EquipmentId = equipment.Id,
                    StartTime = date,
                    EndTime = date.AddMinutes(2),
                    VesselVisitId = workQueue.VesselVisitId,
                    WorkQueueId = workQueue.Id,
                    CreatedAt = date,
                    CreatedBy = _currentUserService.GetUsername()
                };
                await _alarmsEventsDataAccess.CreateAsync(hatchEvent, ct);
            }
        }
    }

    private async Task UpdateWorkInstructionJobStatus(List<WorkInstruction> jobs, string action)
    {
        foreach (var wi in jobs)
        {
            wi.WorkInstructionStatus = action;
            string status = MapJobStepingStatus(action);
            wi.JobSteppingStatus = status;
            wi.TaskStatus = status;
            wi.JobStartTime = DateTime.UtcNow;
            wi.UpdatedAt = DateTime.UtcNow;
            wi.UpdatedBy = _currentUserService.GetUsername();
            await _dataAccess.UpdateAsync(wi);
        }
    }

    private static string MapJobStepingStatus(string action)
    {
        return action switch
        {
            Constants.JobStatus.INPROGRESS => Constants.JobStepingStatus.DISPATCHED,
            Constants.JobStatus.PLANNED => Constants.JobStepingStatus.YET_TO_START,
            Constants.JobStatus.COMPLETED => Constants.JobStepingStatus.COMPLETED,
            Constants.JobStatus.SUSPENDED => Constants.JobStepingStatus.SUSPENDED,
            _ => "Invalid",
        };
    }

    public Task<IEnumerable<CreateWorkInstructionDto>> ValidateTwinModeSequenceAsync(
        IEnumerable<CreateWorkInstructionDto> instructions)
    {
        var list = instructions.ToList();
        var updated = new List<CreateWorkInstructionDto>(list.Count);
        var validPositions = new HashSet<string>
        {
            "1",
            "3"
        };

        for (int i = 0; i < list.Count; i++)
        {
            var current = list[i];

            if (current.Mode == Constants.WorkInstructionMode.TWIN && !current.IsoCode.StartsWith("4"))
            {
                // Ensure next exists and is also Twin
                if (i + 1 >= list.Count || list[i + 1].Mode == Constants.WorkInstructionMode.SINGLE)
                {
                    _logger.LogError("Twin container {Container1} must be paired with the next container in the sequence.", current.ContainerId);
                    throw new InvalidOperationException($"Twin container {current.ContainerId} must be paired with the next container in the sequence.");
                }

                var next = list[i + 1];

                // Validate PositionOnCarriage
                if (!validPositions.Contains(current.PositionOnCarriage) ||
                    !validPositions.Contains(next.PositionOnCarriage) ||
                    current.PositionOnCarriage == next.PositionOnCarriage ||
                    !next.IsoCode.StartsWith("2") || !current.IsoCode.StartsWith("2"))
                {
                    _logger.LogError("Invalid twin pairing: Containers {Container1} and {Container2} must have different positions on the chassis.", current.ContainerId, list[i + 1].ContainerId);
                    throw new InvalidOperationException($"Invalid twin pairing: Containers {current.ContainerId} and {list[i + 1].ContainerId} must have different positions on the chassis.");
                }

                // Add updated Twin pair with TwinContainerIds
                updated.Add(current with
                {
                    PairContainer = next.ContainerId
                });
                updated.Add(next with
                {
                    PairContainer = current.ContainerId
                });

                i++; // Skip next (already handled as Twin pair)
            }
            else
            {
                // Just add single mode or non-Twin mode as-is
                updated.Add(current);
            }
        }
        return Task.FromResult<IEnumerable<CreateWorkInstructionDto>>(updated);
    }

    public async Task<bool> AppendWorkInstructionAsync(AppendWorkInstructionRequest request, CancellationToken ct)
    {
        var wi = await _dataAccess.GetByIdAsync(request.WorkInstructionId, ct);
        if (wi == null || wi.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED)
                       || wi.WorkInstructionStatus.Equals(Constants.JobStatus.INPROGRESS))
            return false;

        return await ReorderWorkInstructionSequence(wi, request, ct);
    }

    private async Task<bool> ReorderWorkInstructionSequence(WorkInstruction job, AppendWorkInstructionRequest request, CancellationToken ct)
    {
        long oldWqId = job.WorkQueueId;
        var newWq = await _workQueueDataAccess.GetByIdAsync(request.WorkQueueId, ct);
        if (newWq != null)
        {
            var pointOfWork = await _pointOfWorkDataAccess.GetByIdAsync(request.PowId, ct);
            job.Sequence = newWq.WorkInstructions.Count() + 1;
            job.WorkQueueId = request.WorkQueueId;
            job.WorkQueue = newWq;
            job.PointOfWorkId = request.PowId;
            job.PointOfWork = pointOfWork;
            job.UpdatedAt = DateTime.UtcNow;
            await _dataAccess.UpdateAsync(job);
        }
        var oldWq = await _workQueueDataAccess.GetByIdAsync(oldWqId, ct);
        if (oldWq != null)
        {
            int count = 1;
            var workInstructions = oldWq.WorkInstructions.OrderBy(wi => wi.Sequence).ToList();
            workInstructions = workInstructions.Where(wi => wi.ContainerId != job.ContainerId).ToList();
            foreach (var workInstruction in workInstructions)
            {
                workInstruction.Sequence = count++;
            }
            await _dataAccess.UpdateBatchAsync(workInstructions);
        }
        return true;
    }

    public async Task<bool> ActivateNextJobByPoolName(string poolName,
        string equipmentId,
        CancellationToken ct = default)
    {
        var workQueue = await _workQueueDataAccess.GetByPoolName(poolName, ct);
        if (workQueue == null)
        {
            return false;
        }
        var action = Constants.JobStatus.INPROGRESS;
        return await JobStatusUpdate(workQueue, action, ct);
    }

    public async Task<ImmutableArray<WorkInstruction>> GetByEquipmentCarry(long equipmentId, CancellationToken ct = default)
    {
        var equipment = await _equipmentDataAccess.GetByIdAsync(equipmentId, ct);
        if (equipment == null) return ImmutableArray<WorkInstruction>.Empty;

        var instructions = await _dataAccess.GetByEquipmentId(equipment.EquipmentName, ct);
        if (instructions.Count == 0)
        {
            _logger.LogInformation("No work instructions found for equipment ID: {EquipmentId}", equipmentId);
            return ImmutableArray<WorkInstruction>.Empty;
        }

        return [..instructions];
    }
}