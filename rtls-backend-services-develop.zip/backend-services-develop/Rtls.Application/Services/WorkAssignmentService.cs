using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class WorkAssignmentService : IWorkAssignmentService
{
    private readonly IVesselVisitDataAccess _vesselVisitDataAccess;
    private readonly IWorkInstructionDataAccess _workInstructionDataAccess;
    private readonly IWorkQueueDataAccess _workQueueDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly IWorkInstructionService _workInstructionService;
    private readonly ILogger<WorkAssignmentService> _logger;

    public WorkAssignmentService(
        ICurrentUserService currentUserService,
        ILogger<WorkAssignmentService> logger,
        IVesselVisitDataAccess vesselVisitDataAccess,
        IWorkInstructionDataAccess workInstructionDataAccess,
        IWorkQueueDataAccess workQueueDataAccess,
        IWorkInstructionService workInstructionService)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _vesselVisitDataAccess = vesselVisitDataAccess ?? throw new ArgumentNullException(nameof(vesselVisitDataAccess));
        _workInstructionDataAccess = workInstructionDataAccess ?? throw new ArgumentNullException(nameof(workInstructionDataAccess));
        _workQueueDataAccess = workQueueDataAccess ?? throw new ArgumentNullException(nameof(workQueueDataAccess));
        _workInstructionService = workInstructionService ?? throw new ArgumentNullException(nameof(workInstructionService));
    }

    public async Task<PagedResponse<WorkAssignmentDto>> GetAllAsync(int skip, int take, string search, CancellationToken ct)
    {
        _logger.LogInformation("Fetching work assignments from row {skip} to {take} with search term: '{Search}'", skip, take, search);

        var visitPhases = new List<string> { Constants.VesselVisitPhase.COMPLETED, Constants.VesselVisitPhase.DEPARTED };
        
        var vesselVisits = await _vesselVisitDataAccess.GetAllByVisitPhaseAsync(skip, take, visitPhases, search, ct);
        int vesselCount = await _vesselVisitDataAccess.GetAllCount(ct);
        var vesselIds = vesselVisits.Select(v => v.Id).ToHashSet();

        _logger.LogInformation("Retrieved {Count} vessel visits. Fetching work instructions for these vessels.", vesselVisits.Count);
        var workInstructions = await _workInstructionDataAccess.GetByVesselIdAsync(vesselIds, ct);

        _logger.LogInformation("Grouping and counting move data...");

        var powMapByVessel = GroupPointOfWorksByVessel(workInstructions);
        var totalMovesByVessel = CountTotalMovesByVessel(workInstructions);
        var completedMovesByVessel = CountCompletedMovesByVessel(workInstructions);
        var totalMovesByPow = CountTotalMovesByPow(workInstructions);
        var completedMovesByPow = CountCompletedMovesByPow(workInstructions);

        _logger.LogInformation("Constructing WorkAssignment DTOs...");

        var workAssignments = vesselVisits.Select(vessel => new WorkAssignmentDto
        {
            VesselVisitId = vessel.Id,
            VesselRef = vessel.VisitRef,
            VesselName = vessel?.Vessel?.VesselName,
            Quay = vessel?.VesselBerthing?.Quay,
            VesselVisitPhase = vessel?.Phase.ToString(),
            Eta = vessel.Eta,
            Etd = vessel.Etd,
            Ata = vessel.Ata,
            Atd = vessel.Atd,
            PointOfWork = BuildPowList(
                powMapByVessel.TryGetValue(vessel.Id, out var pows) ? pows : null,
                totalMovesByPow,
                completedMovesByPow, vessel.Id),
            TotalPlannedMoves = totalMovesByVessel.TryGetValue(vessel.Id, out var total) ? total : 0,
            CompletedMoves = completedMovesByVessel.TryGetValue(vessel.Id, out var done) ? done : 0
        }).ToArray();

        _logger.LogInformation("Returning {Count} work assignments.", workAssignments.Length);

        return new PagedResponse<WorkAssignmentDto>(search == "" ? vesselCount : workAssignments.Length, workAssignments);
    }

    public async Task<List<WorkQueueDto>> GetWorkQueuesByPowAsync(long vesselVisitId, long powId, CancellationToken ct)
    {
        _logger.LogInformation("Getting work queue info for VesselVisitId: {VesselVisitId}, PowId: {PowId}", vesselVisitId, powId);

        var workQueues = await _workQueueDataAccess.GetByVesselVisitIdPowAsync(vesselVisitId, powId, ct);

        if (workQueues == null || !workQueues.Any())
        {
            _logger.LogWarning("No Work Queue found for VesselVisitId: {VesselVisitId}, PowId: {PowId}", vesselVisitId, powId);
            return new List<WorkQueueDto>();
        }

        var workQueueDtos = workQueues
            .Select(wq =>
            {
                var totalPlanned = wq.WorkInstructions.Count();
                var completed = wq.WorkInstructions.Count(w => w.WorkInstructionStatus == Constants.JobStatus.COMPLETED);
                var pending = totalPlanned - completed;
                return new WorkQueueDto
                {
                    Id = wq.Id,
                    Name = wq.Name,
                    Type = wq.Type,
                    Deck = wq.Deck,
                    TotalPlannedMoves = totalPlanned,
                    CompletedMoves = completed,
                    PendingMoves = pending,
                    Status = wq.Status
                };
            })
            .ToList();

        return workQueueDtos;
    }

    public async Task<bool> OperateWorkQueueAsync(long workQueueId, string action, CancellationToken ct)
    {
        // Get the work instructions based on vesselVisitId
        var workQueue = await _workQueueDataAccess.GetByIdAsync(workQueueId, ct);
      
        // Check if we got any work instructions
        if (workQueue == null)
        {
            _logger.LogWarning("No work instructions found for workQueueId: {workQueueId}", workQueueId);
            return false;
        }
        await ValidateWorkQueueAgainstPow(workQueue, action, ct);
        var wiResult = await _workInstructionService.JobStatusUpdate(workQueue, action, ct);
        if (!wiResult)
        {
            _logger.LogError("Error occurred while updating work Instruction status: {WorkQueueId}, Action: {action}", workQueueId, action);
            throw new InvalidOperationException("Error occurred while updating status");
        }
        workQueue.Status = action;
        workQueue.UpdatedBy = _currentUserService.GetUsername();
        workQueue.UpdatedAt = DateTime.UtcNow;

        var result = await _workQueueDataAccess.UpdateAsync(workQueue, ct);
        // Return true if the update was successful for at least one record
        if(result) _logger.LogInformation("Operation {Action} performed successfully for WorkQueue: {WorkQueue}, MoveType: {MoveType}", action, workQueue.Name, workQueue.Type);
        return result;
    }

    private async Task ValidateWorkQueueAgainstPow(WorkQueue workQueue, string action, CancellationToken ct)
    {
        if (action.Equals(Constants.JobStatus.INPROGRESS))
        {
            var workQueueCount = await _workQueueDataAccess.GetCountAgainstPow(workQueue.PointOfWorkId, workQueue.VesselVisitId, ct);
            if(workQueueCount != 0)
            {
                _logger.LogError("Unable to activate this WorkQueue. Another WorkQueue is currently active under the same POW.");
                throw new InvalidOperationException("Unable to activate this WorkQueue. Another WorkQueue is currently active under the same POW.");
            }
            string vessel = await _workQueueDataAccess.GetCountAgainstVessel(workQueue.PointOfWorkId, ct);
            if (vessel != null)
            {
                _logger.LogError("Activation failed. A POW is already active for another vessel {vessel}.", vessel);
                throw new InvalidOperationException($"Activation failed. A POW is already active for another vessel ({vessel})");
            }
        }
    }

    private static Dictionary<long, List<PointOfWork>> GroupPointOfWorksByVessel(IEnumerable<WorkInstruction> instructions)
    {
        return instructions
            .Where(wi => wi.PointOfWork != null)
            .GroupBy(wi => wi.VesselVisitId)
            .ToDictionary(
                g => g.Key,
                g => g.Select(wi => wi.PointOfWork)
                      .DistinctBy(pow => pow.Id)
                      .ToList());
    }

    private static Dictionary<long, int> CountTotalMovesByVessel(IEnumerable<WorkInstruction> instructions)
    {
        return instructions
            .GroupBy(wi => wi.VesselVisitId)
            .ToDictionary(g => g.Key, g => g.Count());
    }

    private static Dictionary<long, int> CountCompletedMovesByVessel(IEnumerable<WorkInstruction> instructions)
    {
        return instructions
            .GroupBy(wi => wi.VesselVisitId)
            .ToDictionary(g => g.Key, g => g.Count(wi => wi.WorkInstructionStatus?.Contains(Constants.JobStatus.COMPLETED) == true));
    }

    private static Dictionary<(long VesselVisitId, long PointOfWorkId), int> CountTotalMovesByPow(IEnumerable<WorkInstruction> instructions)
    {
        return instructions
            .GroupBy(wi => (wi.VesselVisitId, wi.PointOfWorkId))
            .ToDictionary(g => g.Key, g => g.Count());
    }

    private static Dictionary<(long VesselVisitId, long PointOfWorkId), int> CountCompletedMovesByPow(IEnumerable<WorkInstruction> instructions)
    {
        return instructions
            .GroupBy(wi => (wi.VesselVisitId, wi.PointOfWorkId))
            .ToDictionary(g => g.Key, g => g.Count(wi => wi.WorkInstructionStatus?.Contains(Constants.JobStatus.COMPLETED) == true));
    }

    private static List<PointOfWorkWithRecords> BuildPowList(
        List<PointOfWork> powList,
        Dictionary<(long, long), int> totalMovesMap,
        Dictionary<(long, long), int> completedMovesMap, long vesselId)
    {
        return powList?.Where(pow => pow != null)
            .Select(pow => new PointOfWorkWithRecords
            {
                Id = pow.Id,
                Name = pow.Name,
                Pool = pow.Pool,
                CreatedAt = pow.CreatedAt,
                UpdatedAt = pow.UpdatedAt,
                CreatedBy = pow.CreatedBy,
                UpdatedBy = pow.UpdatedBy,
                TotalPlannedMoves = totalMovesMap.TryGetValue((vesselId, pow.Id), out var total) ? total : 0,
                CompletedMoves = completedMovesMap.TryGetValue((vesselId, pow.Id), out var done) ? done : 0
            }).ToList() ?? new List<PointOfWorkWithRecords>();
    }

}