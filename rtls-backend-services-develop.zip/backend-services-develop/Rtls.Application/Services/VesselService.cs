using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class VesselService : IVesselService
{
    private readonly IVesselDataAccess _vesselDataAccess;
    private readonly IVesselVisitDataAccess _vesselVisitDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<VesselService> _logger;
    private readonly IMapper _mapper;

    public VesselService(
        ICurrentUserService currentUserService,
        ILogger<VesselService> logger,
        IMapper mapper,
        IVesselDataAccess vesselDataAccess,
        IVesselVisitDataAccess vesselVisitDataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _vesselDataAccess = vesselDataAccess ?? throw new ArgumentNullException(nameof(vesselDataAccess));
        _vesselVisitDataAccess = vesselVisitDataAccess ?? throw new ArgumentNullException(nameof(vesselVisitDataAccess));
    }

    public async Task<PagedResponse<VesselDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all vessels");

        var pagedResponse = await _vesselDataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedResponse.TotalCount == 0) return PagedResponse<VesselDto>.Empty;

        // map to DTO
        var vesselDtos = pagedResponse.Items.Select(v => _mapper.Map<VesselDto>(v)).ToArray();

        return new PagedResponse<VesselDto>(pagedResponse.TotalCount, vesselDtos);
    }

    public async Task<VesselDto?> GetByIdAsync(long id)
    {
        _logger.LogInformation("Getting vessel with ID: {VesselId}", id);
        var vessel = await _vesselDataAccess.GetByIdAsync(id);

        if (vessel == null)
        {
            _logger.LogWarning("Vessel with ID: {VesselId} not found", id);
            return null;
        }

        return _mapper.Map<VesselDto>(vessel);
    }

    public async Task<VesselDto> CreateAsync(CreateVesselDto dto)
    {
        CancellationToken ct = default;
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselData(dto);
        await ValidateDuplicateData(new List<CreateVesselDto> { dto}, ct);
        _logger.LogInformation("Creating new vessel: {VesselName}", dto.VesselName);

        var vessel = _mapper.Map<Vessel>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        vessel.CreatedBy = username;
        vessel.UpdatedBy = username;
        vessel.CreatedAt = now;
        vessel.UpdatedAt = now;

        var createdVessel = await _vesselDataAccess.CreateAsync(vessel);

        _logger.LogInformation("Vessel created successfully with ID: {VesselId}", createdVessel.Id);
        return _mapper.Map<VesselDto>(createdVessel);
    }

    public async Task<bool> UpdateAsync(long id, UpdateVesselDto dto)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselData(dto);

        _logger.LogInformation("Updating vessel with ID: {VesselId}", id);

        var vessel = await _vesselDataAccess.GetByIdAsync(id);
        if (vessel is null)
        {
            _logger.LogWarning("Vessel with ID: {VesselId} not found for update", id);
            return false;
        }

        // Update vessel properties
        _mapper.Map(dto, vessel);
        vessel.UpdatedBy = _currentUserService.GetUsername();
        vessel.UpdatedAt = DateTime.UtcNow;

        var result = await _vesselDataAccess.UpdateAsync(vessel);

        if (result)
        {
            _logger.LogInformation("Vessel with ID: {VesselId} updated successfully", id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id)
    {
        _logger.LogInformation("Deleting vessel with ID: {VesselId}", id);
        await ValidateRelations(id);
        var result = await _vesselDataAccess.DeleteAsync(id);

        if (result)
        {
            _logger.LogInformation("Vessel with ID: {VesselId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Vessel with ID: {VesselId} not found for deletion", id);
        }

        return result;
    }

    private async Task ValidateRelations(long id)
    {
        var vesselVisit = await _vesselVisitDataAccess.GetVesselVisitByVesselId(id);
        if (vesselVisit.Any())
        {
            var duplicates = string.Join(", ", vesselVisit);
            _logger.LogError($"A vessel has associated vessel visits: {duplicates}");
            throw new ArgumentException($"A vessel has associated vessel visits: {duplicates}");
        }
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateVesselDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);
        var vessels = new List<Vessel>();
        foreach (var dto in dtos)
        {
            var vessel = _mapper.Map<Vessel>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            vessel.CreatedBy = username;
            vessel.UpdatedBy = username;
            vessel.CreatedAt = now;
            vessel.UpdatedAt = now;

            vessels.Add(vessel);
        }

        return await _vesselDataAccess.CreateBatchAsync(vessels, ct);
    }

    private async Task ValidateDuplicateData(IEnumerable<CreateVesselDto> dtos, CancellationToken ct)
    {
        var duplicateGroups = dtos
            .GroupBy(v => new
            {
                v.VesselName,
                v.LloydsIdentity,
                v.VesselClass,
                v.RadioCallSign
            })
            .Where(g => g.Count() > 1)
            .ToList();
        if (duplicateGroups.Any())
        {
            var duplicateMessages = duplicateGroups.Select(g =>
                $"VesselName: {g.Key.VesselName}, " +
                $"LloydsIdentity: {g.Key.LloydsIdentity}, " +
                $"VesselClass: {g.Key.VesselClass}, " +
                $"RadioCallSign: {g.Key.RadioCallSign} " +
                $"(Count: {g.Count()})"
            );

            var message = $"The following duplicates were found: {string.Join(" | ", duplicateMessages)}";
            _logger.LogError(message);
            throw new InvalidOperationException(message);
        }
        var lookupDict = new Dictionary<string, List<string>>
        {
            { "VesselName", dtos.Select(dto => dto.VesselName).ToList() },
            { "LloydsIdentity", dtos.Select(dto => dto.LloydsIdentity).ToList() },
            { "VesselClass", dtos.Select(dto => dto.VesselClass).ToList() },
            { "RadioCallSign", dtos.Select(dto => dto.RadioCallSign).ToList() }
        };
        // Check for existing Vessel names, class and radio call sign in the database
        var existing = await _vesselDataAccess.CheckDuplicatesAsync(lookupDict, ct);
        if (existing.Any())
        {
            var duplicateMessages = existing.Select(kvp => $"{kvp.Key}: {string.Join(", ", kvp.Value)}");
            _logger.LogError($"The following fields contain duplicates: {string.Join(" | ", duplicateMessages)}");
            throw new ArgumentException($"The following fields contain duplicates: {string.Join(" | ", duplicateMessages)}");
        }
    }

    private void ValidateVesselData(CreateVesselDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.VesselName))
        {
            _logger.LogError("Vessel name is required");
            throw new ArgumentException("Vessel name is required", nameof(dto.VesselName));
        }

        if (dto.OverallLength <= 0)
        {
            _logger.LogError("Overall length must be greater than zero");
            throw new ArgumentException("Overall length must be greater than zero", nameof(dto.OverallLength));
        }

        // Add other validations as needed
    }

    private void ValidateVesselData(UpdateVesselDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.VesselName))
        {
            _logger.LogError("Vessel name is required");
            throw new ArgumentException("Vessel name is required", nameof(dto.VesselName));
        }

        if (dto.OverallLength <= 0)
        {
            _logger.LogError("Overall length must be greater than zero");
            throw new ArgumentException("Overall length must be greater than zero", nameof(dto.OverallLength));
        }
    }
}