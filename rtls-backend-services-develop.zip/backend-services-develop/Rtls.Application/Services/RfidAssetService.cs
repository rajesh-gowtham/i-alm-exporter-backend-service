using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class RfidAssetService : IRfidAssetService
{
    private readonly ILogger<RfidAssetService> _logger;
    private readonly ICurrentUserService _currentUserService;
    private readonly IRfidIntegrationService _rfidIntegrationService;
    private readonly IRfidAssetDataAccess _dataAccess;
    private readonly IMapper _mapper;

    public RfidAssetService(
        ILogger<RfidAssetService> logger,
        IRfidIntegrationService rfidIntegrationService,
        IMapper mapper,
        ICurrentUserService currentUserService,
        IRfidAssetDataAccess dataAccess)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _rfidIntegrationService = rfidIntegrationService ?? throw new ArgumentNullException(nameof(rfidIntegrationService));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
    }

    public async Task<RfidSuccessResponseDto> CreateRfidAssetAsync(CreateRfidAssetDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started creating Rfid asset");
        await ValidateRfidAssetData(dto, ct);
        
        var response = await _rfidIntegrationService.PostAsync<CreateRfidAssetDto, RfidSuccessResponseDto>(
           Constants.RfidApiPaths.AddReaderApi, dto
        );
        var rfidAssets = await GetAllAssetsAsync(0, null, "", ct);

        var entity = _mapper.Map<RfidAsset>(dto);

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        var match = rfidAssets.Items.FirstOrDefault(lt => lt.RPName.Equals(dto.RPName));
        if (match != null)
        {
            entity.RPID = match.RPID;
        }
        entity.CreatedBy = username;
        entity.CreatedAt = now;

        await _dataAccess.CreateAsync(entity, ct);
        return response;
    }

    private async Task ValidateRfidAssetData(CreateRfidAssetDto dto, CancellationToken ct)
    {

        var duplicates = await _dataAccess.FindDuplicateDataAsync(dto.RPName, dto.Lat, dto.Long, ct);

        if (duplicates.Any())
        {
            throw new InvalidOperationException(
                $"Duplicate values found for: {string.Join(", ", duplicates)}"
            );
        }
    }

    public async Task<RfidSuccessResponseDto> DeleteRfidAssetsAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Started deleting Rfid asset");
        await _dataAccess.DeleteAsync(id, ct);

        var response = await _rfidIntegrationService.PostWithoutBodyAsync<RfidSuccessResponseDto>(
          Constants.RfidApiPaths.DeleteReaderApi + $"/{id}"
       );
        return response;
    }

    public async Task<PagedResponse<RfidAssetDto>> GetAllAssetsAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Started getting all Rfid asset details");
        var response = await _rfidIntegrationService.GetAsync<List<RfidAssetDto>>(
           Constants.RfidApiPaths.GetReaderApi
        );
        // If no data, return early
        if (response == null || !response.Any())
            return new PagedResponse<RfidAssetDto>(0, []);

        var totalCount = response.Count;
        // Filter by search if provided
        if (!string.IsNullOrWhiteSpace(search))
        {
            search = search.Trim().ToLower();
            response = response
                .Where(x =>
                    (!string.IsNullOrEmpty(x.RPName) && x.RPName.ToLower().Contains(search))
                )
                .ToList();
        }

        // Order
        response = response.OrderBy(x => x.RPID).ToList();

        // Pagination
        if (skip > 0)
            response = response.Skip(skip).ToList();

        if (take.HasValue && take.Value > 0)
            response = response.Take(take.Value).ToList();

        return new PagedResponse<RfidAssetDto>(totalCount, response.ToArray());
    }

    public async Task<RfidMasterDataDto> GetRfidAssetMasterDataAsync(CancellationToken ct = default)
    {
        _logger.LogInformation("Started fetching RFID master data");

        var readerType = await _rfidIntegrationService.GetAsync<List<RfidReaderModelTypeDto>>(
            Constants.RfidApiPaths.GetReaderTypeMasterDataApi);

        var readerModel = await _rfidIntegrationService.GetAsync<List<RfidReaderModelTypeDto>>(
            Constants.RfidApiPaths.GetReaderModelMasterDataApi);

        var levelTemplates = await _rfidIntegrationService.GetAsync<List<LevelTemplateValueDto>>(
            Constants.RfidLevelTemplateApiPaths.GetLevelTemplateValueApi);

        return new RfidMasterDataDto
        {
            ReaderType = readerType,
            ReaderModel = readerModel,
            LevelTemplate = levelTemplates
        };
    }

    public async Task<RfidSuccessResponseDto> UpdateRfidAssetsAsync(UpdateRfidAssetDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started updating Rfid asset");
        var entity = _mapper.Map<RfidAsset>(dto);

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.UpdatedBy = username;
        entity.UpdatedAt = now;

        await _dataAccess.UpdateAsync(entity, ct);

        var response = await _rfidIntegrationService.PostAsync<UpdateRfidAssetDto, RfidSuccessResponseDto>(
           Constants.RfidApiPaths.UpdateReaderApi, dto
        );
        return response;
    }
}