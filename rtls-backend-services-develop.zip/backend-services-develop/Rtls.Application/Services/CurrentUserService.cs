﻿using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;

namespace Rtls.Application.Services;

/// <summary>
/// Implementation of ICurrentUserService that retrieves user information from the HTTP context
/// </summary>
public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ILogger<CurrentUserService> _logger;

    public CurrentUserService(IHttpContextAccessor httpContextAccessor, ILogger<CurrentUserService> logger)
    {
        _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Gets the username of the currently authenticated user
    /// </summary>
    /// <returns>The username of the current user or "System" if not authenticated</returns>
    public string GetUsername()
    {
        _logger.LogInformation("Getting current username");
        return _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Name) ?? "System";
    }

    /// <summary>
    /// Gets the user ID of the currently authenticated user
    /// </summary>
    /// <returns>The user ID of the current user or null if not authenticated</returns>
    public string GetUserId()
    {
        _logger.LogInformation("Getting current user ID");
        return _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
    }

    /// <summary>
    /// Checks if the current user is authenticated
    /// </summary>
    /// <returns>True if the user is authenticated, false otherwise</returns>
    public bool IsAuthenticated()
    {
        _logger.LogInformation("Checking if user is authenticated");
        return _httpContextAccessor.HttpContext?.User.Identity?.IsAuthenticated ?? false;
    }
}