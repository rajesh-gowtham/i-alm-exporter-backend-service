using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class VesselBerthingService : IVesselBerthingService
{
    private readonly IVesselBerthingDataAccess _dataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<VesselBerthingService> _logger;
    private readonly IMapper _mapper;

    public VesselBerthingService(
        ICurrentUserService currentUserService,
        ILogger<VesselBerthingService> logger,
        IMapper mapper,
        IVesselBerthingDataAccess dataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
    }

    public async Task<PagedResponse<VesselBerthingDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all vessel berthings");

        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedEntities.TotalCount == 0) return PagedResponse<VesselBerthingDto>.Empty;

        var dtos = _mapper.Map<VesselBerthingDto[]>(pagedEntities.Items);
        return new PagedResponse<VesselBerthingDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<VesselBerthingDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting vessel berthing with ID: {VesselBerthingId}", id);
        var entity = await _dataAccess.GetByIdAsync(id, ct);

        if (entity == null)
        {
            _logger.LogWarning("Vessel berthing with ID: {VesselBerthingId} not found", id);
            return null;
        }

        return _mapper.Map<VesselBerthingDto>(entity);
    }

    public async Task<VesselBerthingDto> CreateAsync(CreateVesselBerthingDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselBerthingData(dto);
        await ValidateDuplicate(new List<CreateVesselBerthingDto> { dto }, ct);
        _logger.LogInformation("Creating new vessel berthing for VesselVisitId: {VesselVisitId}", dto.VesselVisitId);

        var entity = _mapper.Map<VesselBerthing>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.CreatedBy = username;
        entity.UpdatedBy = username;
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        var createdEntity = await _dataAccess.CreateAsync(entity, ct);

        _logger.LogInformation("Vessel berthing created successfully with ID: {VesselBerthingId}", createdEntity.Id);
        return _mapper.Map<VesselBerthingDto>(createdEntity);
    }

    public async Task<bool> UpdateAsync(long id, UpdateVesselBerthingDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateVesselBerthingData(dto);

        _logger.LogInformation("Updating vessel berthing with ID: {VesselBerthingId}", id);

        var entity = await _dataAccess.GetByIdAsync(id, ct);
        if (entity is null)
        {
            _logger.LogWarning("Vessel berthing with ID: {VesselBerthingId} not found for update", id);
            return false;
        }

        _mapper.Map(dto, entity);
        entity.UpdatedBy = _currentUserService.GetUsername();
        entity.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(entity, ct);

        if (result)
        {
            _logger.LogInformation("Vessel berthing with ID: {VesselBerthingId} updated successfully", id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting vessel berthing with ID: {VesselBerthingId}", id);

        var result = await _dataAccess.DeleteAsync(id, ct);

        if (result)
        {
            _logger.LogInformation("Vessel berthing with ID: {VesselBerthingId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Vessel berthing with ID: {VesselBerthingId} not found for deletion", id);
        }

        return result;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateVesselBerthingDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicate(dtos, ct);
        var entities = new List<VesselBerthing>();
        foreach (var dto in dtos)
        {
            var equipment = _mapper.Map<VesselBerthing>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            equipment.CreatedBy = username;
            equipment.UpdatedBy = username;
            equipment.CreatedAt = now;
            equipment.UpdatedAt = now;

            entities.Add(equipment);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private void ValidateVesselBerthingData(CreateVesselBerthingDto dto)
    {
        // Add validation rules based on your requirements
        if (string.IsNullOrWhiteSpace(dto.Quay))
        {
            _logger.LogError("Quay is required");
            throw new ArgumentException("Quay is required", nameof(dto.Quay));
        }

        if (string.IsNullOrWhiteSpace(dto.BerthingSide.ToString()))
        {
            _logger.LogError("Berthing side is required");
            throw new ArgumentException("Berthing side is required", nameof(dto.BerthingSide));
        }

        if (dto.VesselVisitId <= 0)
        {
            _logger.LogError("VesselVisitId must be greater than zero");
            throw new ArgumentException("VesselVisitId must be greater than zero", nameof(dto.VesselVisitId));
        }

        // Add other validations as needed
    }

    private void ValidateVesselBerthingData(UpdateVesselBerthingDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Quay))
        {
            _logger.LogError("Quay is required");
            throw new ArgumentException("Quay is required", nameof(dto.Quay));
        }

        if (string.IsNullOrWhiteSpace(dto.BerthingSide.ToString()))
        {
            _logger.LogError("Berthing side is required");
            throw new ArgumentException("Berthing side is required", nameof(dto.BerthingSide));
        }

        if (dto.VesselVisitId <= 0)
        {
            _logger.LogError("VesselVisitId must be greater than zero");
            throw new ArgumentException("VesselVisitId must be greater than zero", nameof(dto.VesselVisitId));
        }

        // Add other validations as needed
    }
    private async Task ValidateDuplicate(IEnumerable<CreateVesselBerthingDto> dtos, CancellationToken ct)
    {
        var vesselVisitIds = dtos.Select(vv => vv.VesselVisitId).ToList();
        var existing = await _dataAccess.CheckDuplicatesAsync(vesselVisitIds, ct);
        if (existing.Any())
        {
            var duplicates = string.Join(", ", existing);
            _logger.LogError($"Berthing has already been created for the following visit reference name(s): {duplicates}");
            throw new ArgumentException($"Berthing has already been created for the following visit reference name(s): {duplicates}");
        }
    }
}
