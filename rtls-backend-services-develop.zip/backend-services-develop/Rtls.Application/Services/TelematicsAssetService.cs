using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class TelematicsAssetService : ITelematicsAssetService
{
    private readonly ITelematicsDataAccess _dataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<TelematicsAssetService> _logger;
    private readonly IMapper _mapper;

    public TelematicsAssetService(
        ICurrentUserService currentUserService,
        ILogger<TelematicsAssetService> logger,
        IMapper mapper,
        ITelematicsDataAccess dataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        
    }

    public async Task<TelematicsDto?> GetByIdAsync(long id)
    {
        _logger.LogInformation("Service: Getting telematics by ID {Id}", id);
        var entity = await _dataAccess.GetByIdAsync(id);
        return entity is null ? null : _mapper.Map<TelematicsDto>(entity);
    }

    public async Task<PagedResponse<TelematicsDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Service: Getting all telematics with skip={Skip}, take={Take}, search='{Search}'", skip, take, search);
        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);
        var dtos = pagedEntities.Items.Select(_mapper.Map<TelematicsDto>).ToArray();
        return new PagedResponse<TelematicsDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<TelematicsDto> CreateAsync(TelematicsDto dto)
    {
        _logger.LogInformation("Service: Creating new telematics device with DeviceId={DeviceId}", dto.DeviceId);

        // Map DTO to Entity
        var entity = _mapper.Map<Telematics>(dto);

        // Get current user and time
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        // Set audit fields
        entity.CreatedBy = username;
        entity.UpdatedBy = username;
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        // Save to database
        var created = await _dataAccess.CreateAsync(entity);

        // Map back to DTO
        return _mapper.Map<TelematicsDto>(created);
    }


    public async Task<bool> UpdateAsync(long id, UpdateTelematicsDto dto)
    {
        _logger.LogInformation("Service: Updating telematics device ID={Id}", id);
        var existing = await _dataAccess.GetByIdAsync(id);
        if (existing is null)
        {
            _logger.LogWarning("Service: Cannot update, device ID={Id} not found", id);
            return false;
        }

        _mapper.Map(dto, existing);

        existing.UpdatedBy = _currentUserService.GetUsername();
        existing.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(existing);

        if (result)
        {
            _logger.LogInformation("Telematics with ID: {DeviceId} updated successfully", id);
        }

        return result;

    }

    public async Task<bool> DeleteAsync(long id)
    {
        _logger.LogInformation("Service: Deleting telematics device ID={Id}", id);
        var existing = await _dataAccess.GetByIdAsync(id);
        if (existing is null)
        {
            _logger.LogWarning("Service: Cannot delete, device ID={Id} not found", id);
            return false;
        }

        return await _dataAccess.DeleteAsync(id);
    }


    public async Task<bool> CreateBatchAsync(IEnumerable<CreateTelematicsDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);
        var entities = new List<Telematics>();
        foreach (var dto in dtos)
        {
            var entity = _mapper.Map<Telematics>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            entity.CreatedBy = username;
            entity.UpdatedBy = username;
            entity.CreatedAt = now;
            entity.UpdatedAt = now;

            entities.Add(entity);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }


    private async Task ValidateDuplicateData(IEnumerable<CreateTelematicsDto> dtos, CancellationToken ct)
    {
        var duplicateNames = dtos
           .GroupBy(tel => tel.DeviceId)
           .Where(g => g.Count() > 1)
           .Select(g => g.Key)
           .ToList();
        if (duplicateNames.Any())
        {
            var duplicates = string.Join(", ", duplicateNames);
            _logger.LogError($"The following DeviceId already exist: {duplicates}");
            throw new InvalidOperationException($"The following DeviceId already exist: {duplicates}");
        }
        var nameToCheck = dtos.Select(dto => dto.DeviceId).ToList();
        // Check for existing Vessel Reference in the database
        var existing = await _dataAccess.CheckDuplicatesAsync(nameToCheck, ct);
        if (existing.Any())
        {
            var duplicates = string.Join(", ", existing);
            _logger.LogError($"The following DeviceId  already exist: {duplicates}");
            throw new ArgumentException($"The following DeviceId already exist: {duplicates}");
        }
    }

    public async Task<TelematicsDto?> GetByDeviceIdAsync(string deviceId, CancellationToken ct)
    {
        _logger.LogInformation("Service: Getting telematics by device id {deviceId}", deviceId);
        var entity = await _dataAccess.GetByDeviceIdAsync(deviceId, ct);
        return entity is null ? null : _mapper.Map<TelematicsDto>(entity);
    }
}