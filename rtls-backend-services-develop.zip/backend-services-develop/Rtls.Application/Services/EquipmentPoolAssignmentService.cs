using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Rtls.Domain.Interfaces;

namespace Rtls.Application.Services
{
    public class EquipmentPoolAssignmentService : IEquipmentPoolAssignmentService
    {
        private readonly IEquipmentPoolAssignmentDataAccess _dataAccess;
        private readonly IEquipmentDataAccess _equipmentDataAccess;
        private readonly IEquipmentPoolDataAccess _equipmentPoolDataAccess;
        private readonly ICurrentUserService _currentUserService;
        private readonly ILogger<EquipmentPoolAssignmentService> _logger;
        private readonly IMapper _mapper;

        public EquipmentPoolAssignmentService(
            ICurrentUserService currentUserService,
            ILogger<EquipmentPoolAssignmentService> logger,
            IMapper mapper,
            IEquipmentPoolAssignmentDataAccess dataAccess,
            IEquipmentDataAccess equipmentDataAccess,
            IEquipmentPoolDataAccess equipmentPoolDataAccess)
        {
            _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
            _equipmentDataAccess = equipmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentDataAccess));
            _equipmentPoolDataAccess = equipmentPoolDataAccess;
        }

        public async Task<EquipmentAssignedAndUnassignedEquipmentDto> GetByIdAsync(long equipmentPoolId,
     CancellationToken ct = default)
        {
            _logger.LogInformation("Getting equipment pool assignment with ID: {EquipmentPoolAssignmentId}", equipmentPoolId);

            // Get assigned equipment only for the given pool ID
            var entity = await _dataAccess.GetByIdAsync(equipmentPoolId, ct);

            if (entity == null || entity.Count == 0)
            {
                _logger.LogWarning("No assignments found for equipment pool ID: {EquipmentPoolAssignmentId}", equipmentPoolId);
                entity = new List<EquipmentPoolAssignment>(); // Use empty list instead of throwing error
            }

            // Get all equipment
            var allEquipment = await _equipmentDataAccess.GetAllAsync(0, null, "", ct);

            // Get all assigned equipment IDs (across all pool assignments)
            var allAssignments = await _dataAccess.GetAllAsync(0, null, ct);
            var allAssignedEquipmentIds = allAssignments.Items.Select(a => a.EquipmentId).ToHashSet();

            // Filter: only those not in any assignment
            var unassignedEquipment = allEquipment.Items
                .Where(e => !allAssignedEquipmentIds.Contains(e.Id))
                .ToList();

            return new EquipmentAssignedAndUnassignedEquipmentDto
            {
                AssignedPools = _mapper.Map<List<EquipmentPoolAssignmentDto>>(entity),
                UnAssignedPools = _mapper.Map<List<EquipmentDto>>(unassignedEquipment)
            };
        }

        public async Task<bool> UpdateAsync(List<UpdateEquipmentPoolAssignmentDto> dtos, 
            long equipmentPoolId, CancellationToken ct = default)
        {
            ArgumentNullException.ThrowIfNull(dtos, nameof(dtos));

            _logger.LogInformation("Updating equipment pool assignment with Equipment Pool ID: {EquipmentPoolId}", equipmentPoolId);
           if(dtos.Count == 0)
            {
                return await _dataAccess.DeleteByEquipmentPoolIdAsync(equipmentPoolId, ct);
            }

            var entities = dtos.Select(dto => new EquipmentPoolAssignment
            {
                EquipmentPoolId = equipmentPoolId,
                EquipmentId = dto.EquipmentId,
                EquipmentAssignedDate = DateTime.UtcNow,
                CreatedBy = _currentUserService.GetUsername(),
                CreatedAt = DateTime.UtcNow,
            }).ToList();

            var result = await _dataAccess.UpdateAsync(entities, equipmentPoolId, ct);
            if (result)
            {
                _logger.LogInformation("Equipment pool assignment with Equipment Pool ID: {EquipmentPoolId} updated successfully", equipmentPoolId);
            }

            return result;
        }
        public async Task<List<string>> GetAssignedEquipments(string equipmentPoolName, CancellationToken ct = default)
        {
            ArgumentNullException.ThrowIfNull(equipmentPoolName);

            _logger.LogInformation("Getting assigned equipments by equipment pool name: {EquipmentPoolName}", equipmentPoolName);

            return await _dataAccess.GetAssignedEquipmentNames(equipmentPoolName, ct);
        }
    }
}