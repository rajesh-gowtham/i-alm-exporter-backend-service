using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using System.Text.Json;

namespace Rtls.Application.Services;

public class RfidLevelTemplateService : IRfidLevelTemplateService
{
    private readonly ILogger<RfidLevelTemplateService> _logger;
    private readonly IRfidIntegrationService _rfidIntegrationService;
    private readonly ICurrentUserService _currentUserService;
    private readonly IRfidLevelTemplateDataAccess _dataAccess;
    private readonly IRfidLevelTemplateValuesDataAccess _ltvDataAccess;
    private readonly IMapper _mapper;

    public RfidLevelTemplateService(
        ILogger<RfidLevelTemplateService> logger,
        IRfidIntegrationService rfidIntegrationService,
        IMapper mapper,
        ICurrentUserService currentUserService,
        IRfidLevelTemplateDataAccess dataAccess,
        IRfidLevelTemplateValuesDataAccess ltvDataAccess)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _rfidIntegrationService = rfidIntegrationService ?? throw new ArgumentNullException(nameof(rfidIntegrationService));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _ltvDataAccess = ltvDataAccess ?? throw new ArgumentNullException(nameof(ltvDataAccess));
    }

    public async Task<RfidSuccessResponseDto> CreateLevelTemplateAsync(LevelTemplateDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started creating Rfid level template");
        await ValidateLevelTemplate(dto, ct);

        var response = await _rfidIntegrationService.PostAsync<LevelTemplateDto, RfidSuccessResponseDto>(
           Constants.RfidLevelTemplateApiPaths.AddLevelTemplateApi, dto
        );

        var levelTemplates = await GetLevelTemplateAsync(ct);

        var entity = _mapper.Map<RfidLevelTemplate>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        var match = levelTemplates.Find(lt => lt.LTName.Equals(dto.LTName));
        if (match != null)
        {
            entity.LTID = match.LTID;
        }
        entity.CreatedBy = username;
        entity.CreatedAt = now;

        await _dataAccess.CreateAsync(entity, ct);

        return response;
    }

    private async Task ValidateLevelTemplate(LevelTemplateDto dto, CancellationToken ct)
    {
        //Check level template name exisit
        var exisitNameCount = await _dataAccess.GetCountByName(dto.LTName, ct);
        if(exisitNameCount != 0)
        {
            throw new InvalidOperationException($"Duplicate Values : lTName");
        }
    }

    public async Task<RfidSuccessResponseDto> CreateLevelTemplateValueAsync(LevelTemplateValueDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started creating Rfid level template value");
        await ValidateLevelTemplateValues(dto, ct);

        var response = await _rfidIntegrationService.PostAsync<LevelTemplateValueDto, RfidSuccessResponseDto>(
           Constants.RfidLevelTemplateApiPaths.AddLevelTemplateValueApi, dto
        );

        var levelTemplateValues = await GetLevelTemplateValueAsync(ct);

        var entity = _mapper.Map<RfidLevelTemplateValues>(dto);

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        var match = levelTemplateValues.Find(lt => lt.LTValue.Equals(dto.LTValue));
        if (match != null)
        {
            entity.LtVID = match.LtVID;
        }
        entity.CreatedBy = username;
        entity.CreatedAt = now;

        await _ltvDataAccess.CreateAsync(entity, ct);
        return response;
    }

    private async Task ValidateLevelTemplateValues(LevelTemplateValueDto dto, CancellationToken ct)
    {
        //Check level template name exisit
        var exisitNameCount = await _ltvDataAccess.GetCountByNameAsync(dto.LTValue, ct);
        if (exisitNameCount != 0)
        {
            throw new InvalidOperationException($"Duplicate Values : lTValue");
        }
    }

    public async Task<List<LevelTemplateDto>> GetLevelTemplateAsync(CancellationToken ct = default)
    {
        _logger.LogInformation("Started getting Rfid level template");
        var response = await _rfidIntegrationService.GetAsync<List<LevelTemplateDto>>(
           Constants.RfidLevelTemplateApiPaths.GetLevelTemplateApi
        );
        return response;
    }

    public async Task<List<LevelTemplateValueDto>> GetLevelTemplateValueAsync(CancellationToken ct = default)
    {
        _logger.LogInformation("Started getting Rfid level template value");
        var response = await _rfidIntegrationService.GetAsync<List<LevelTemplateValueDto>>(
           Constants.RfidLevelTemplateApiPaths.GetLevelTemplateValueApi
        );
        return response;
    }

    public async Task<RfidSuccessResponseDto> UpdateLevelTemplateAsync(LevelTemplateDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started updating Rfid level template");

        var entity = await _dataAccess.GetByLTIdAsync(dto.LTID, ct);
        _mapper.Map(dto, entity);

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.UpdatedBy = username;
        entity.UpdatedAt = now;

        await _dataAccess.UpdateAsync(entity, ct);

        var response = await _rfidIntegrationService.PostAsync<LevelTemplateDto, RfidSuccessResponseDto>(
           Constants.RfidLevelTemplateApiPaths.UpdateLevelTemplateApi, dto
        );
        return response;
    }

    public async Task<RfidSuccessResponseDto> UpdateLevelTemplateValueAsync(LevelTemplateValueDto dto, CancellationToken ct = default)
    {
        _logger.LogInformation("Started updating Rfid level template value");

        var entity = await _ltvDataAccess.GetByLTVIdAsync(dto.LtVID, ct);
        _mapper.Map(dto, entity);

        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.UpdatedBy = username;
        entity.UpdatedAt = now;

        await _ltvDataAccess.UpdateAsync(entity, ct);

        var response = await _rfidIntegrationService.PostAsync<LevelTemplateValueDto, RfidSuccessResponseDto>(
           Constants.RfidLevelTemplateApiPaths.UpdateLevelTemplateValueApi, dto
        );
        return response;
    }
}