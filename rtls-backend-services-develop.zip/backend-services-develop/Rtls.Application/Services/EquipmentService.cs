using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class EquipmentService : IEquipmentService
{
    private readonly IEquipmentDataAccess _dataAccess;
    private readonly IEquipmentPoolAssignmentDataAccess _equipmentPoolAssignmentDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<EquipmentService> _logger;
    private readonly IMapper _mapper;

    public EquipmentService(
        ICurrentUserService currentUserService,
        ILogger<EquipmentService> logger,
        IMapper mapper,
        IEquipmentDataAccess dataAccess,
        IEquipmentPoolAssignmentDataAccess equipmentPoolAssignmentDataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _equipmentPoolAssignmentDataAccess = equipmentPoolAssignmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentPoolAssignmentDataAccess));
    }

    public async Task<EquipmentDto?> GetByIdAsync(long id)
    {
        _logger.LogInformation("Getting equipment with ID: {EquipmentId}", id);
        var entity = await _dataAccess.GetByIdAsync(id);

        if (entity == null)
        {
            _logger.LogWarning("Equipment with ID: {EquipmentId} not found", id);
            return null;
        }

        return _mapper.Map<EquipmentDto>(entity);
    }

    public async Task<EquipmentDto?> GetByNameAsync(string name)
    {
        var entity = await _dataAccess.GetByNameAsync(name);
        if (entity == null)
        {
            _logger.LogWarning("Equipment with name: {Name} not found", name);
            return null;
        }
        return _mapper.Map<EquipmentDto>(entity);
    }

    public async Task<PagedResponse<EquipmentDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", 
        CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all equipment");

        var pagedResponse = await _dataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedResponse.TotalCount == 0) return PagedResponse<EquipmentDto>.Empty;

        var dtos = _mapper.Map<IEnumerable<EquipmentDto>>(pagedResponse.Items).ToArray();

        return new PagedResponse<EquipmentDto>(pagedResponse.TotalCount, dtos);
    }

    public async Task<EquipmentDto> CreateAsync(CreateEquipmentDto dto)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateEquipmentData(dto);
        await ValidateDuplicateData(new List<CreateEquipmentDto> { dto });
        _logger.LogInformation("Creating new equipment: {EquipmentName}", dto.EquipmentName);

        var entity = _mapper.Map<Equipment>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.Status = Constants.EquipmentStatus.LOGOUT;
        entity.CreatedBy = username;
        entity.UpdatedBy = username;
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        var createdEntity = await _dataAccess.CreateAsync(entity);

        _logger.LogInformation("Equipment created successfully with ID: {EquipmentId}", createdEntity.Id);
        return _mapper.Map<EquipmentDto>(createdEntity);
    }

    public async Task<bool> UpdateAsync(UpdateEquipmentDto dto)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateEquipmentData(dto);

        _logger.LogInformation("Updating equipment with ID: {EquipmentId}", dto.Id);

        var entity = await _dataAccess.GetByIdAsync(dto.Id);
        if (entity is null)
        {
            _logger.LogWarning("Equipment with ID: {EquipmentId} not found for update", dto.Id);
            return false;
        }

        _mapper.Map(dto, entity);
        entity.UpdatedBy = _currentUserService.GetUsername();
        entity.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(entity);

        if (result)
        {
            _logger.LogInformation("Equipment with ID: {EquipmentId} updated successfully", dto.Id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id)
    {
        _logger.LogInformation("Deleting equipment with ID: {EquipmentId}", id);
        var assignedPool = await _equipmentPoolAssignmentDataAccess.GetByEquipmentId(id);
        if(assignedPool != null)
        {
            _logger.LogError("Equipment has been assigned to the pool: {poolName}", assignedPool.EquipmentPool.PoolName);
            throw new InvalidOperationException($"Equipment has been assigned to the pool: {assignedPool.EquipmentPool.PoolName}");
        }
        var result = await _dataAccess.DeleteAsync(id);

        if (result)
        {
            _logger.LogInformation("Equipment with ID: {EquipmentId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Equipment with ID: {EquipmentId} not found for deletion", id);
        }

        return result;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateEquipmentDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos);
        var entities = new List<Equipment>();
        foreach (var dto in dtos)
        {
            var equipment = _mapper.Map<Equipment>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            equipment.Status = Constants.EquipmentStatus.LOGOUT;
            equipment.CreatedBy = username;
            equipment.UpdatedBy = username;
            equipment.CreatedAt = now;
            equipment.UpdatedAt = now;

            entities.Add(equipment);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private async Task ValidateDuplicateData(IEnumerable<CreateEquipmentDto> dtos, CancellationToken ct = default)
    {
        var duplicateNames = dtos
            .GroupBy(eq => eq.EquipmentName)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        if (duplicateNames.Any())
        {
            var duplicates = string.Join(", ", duplicateNames);
            _logger.LogError($"The following equipment name(s) already exist: {duplicates}");
            throw new InvalidOperationException($"The following equipment name(s) already exist: {duplicates}");
        }
        var namesToCheck = dtos.Select(dto => dto.EquipmentName).ToList();
        // Check for existing equipment names in the database
        var existingNames = await _dataAccess.CheckDuplicates(namesToCheck, ct);
        if (existingNames.Any())
        {
            var duplicates = string.Join(", ", existingNames);
            _logger.LogError($"The following equipment name(s) already exist: {duplicates}");
            throw new InvalidOperationException($"The following equipment name(s) already exist: {duplicates}");
        }
    }

    private void ValidateEquipmentData(CreateEquipmentDto dto)
    {
        // Add validation rules based on your requirements
        if (string.IsNullOrWhiteSpace(dto.EquipmentName))
        {
            _logger.LogError("Equipment name is required");
            throw new ArgumentException("Equipment name is required", nameof(dto.EquipmentName));
        }

        if (string.IsNullOrWhiteSpace(dto.EquipmentType))
        {
            _logger.LogError("Equipment type is required");
            throw new ArgumentException("Equipment type is required", nameof(dto.EquipmentType));
        }

        // Add other validations as needed
    }

    private void ValidateEquipmentData(UpdateEquipmentDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.Id <= 0)
        {
            _logger.LogError("Id must be greater than zero");
            throw new ArgumentException("Id must be greater than zero", nameof(dto.Id));
        }

        // Add other validations as needed (consider if name/type should be required on update)
    }
}