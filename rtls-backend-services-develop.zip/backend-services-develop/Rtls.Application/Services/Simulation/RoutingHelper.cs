﻿using System.Collections.Immutable;
using Rtls.Domain;

namespace Rtls.Application.Services.Simulation;

public static class RoutingHelper
{
    // Do not access it directly, use Segments property instead
    private static ImmutableList<RouteSegment> _segments = ImmutableList.Create<RouteSegment>();

    private static ImmutableList<RouteSegment> Segments
    {
        get
        {
            if (_segments.Count == 0)
            {
                // Load segments if not already loaded
                _segments = LoadAllSegments();
            }
            return _segments;
        }
    }

    // call it from safe place 
    // implement lazy loading or eager loading later
    private static ImmutableList<RouteSegment> LoadAllSegments()
    {
        return
        [
            // lane 1
            SimulationHelper.LoadSegment(RouteSegmentType.ParkingToSTS01),
            SimulationHelper.LoadSegment(RouteSegmentType.YardToSTS01),
            SimulationHelper.LoadSegment(RouteSegmentType.STS01ToYard),
            SimulationHelper.LoadSegment(RouteSegmentType.YardToParkingLane1),

            // lane 2
            SimulationHelper.LoadSegment(RouteSegmentType.ParkingToSTS02),
            SimulationHelper.LoadSegment(RouteSegmentType.YardToSTS02),
            SimulationHelper.LoadSegment(RouteSegmentType.STS02ToYard),
            SimulationHelper.LoadSegment(RouteSegmentType.YardToParkingLane2)
        ];
    }

    private static RouteSegment? GetSegment(RouteSegmentType type)
    {
        return Segments.FirstOrDefault(x => x.Type == type);
    }

    public static RouteSegment? FindSegment(Waypoint waypoint)
    {
        return Segments
            .FirstOrDefault(seg => seg.Waypoints.Any(x => x.Id == waypoint.Id));
    }

    // find segment by waypoint and get next one, if any
    public static Waypoint? GetNext(Waypoint waypoint)
    {
        // Find the route segment that contains the waypoint
        var segment = Segments
            .FirstOrDefault(seg => seg.Waypoints.Any(x => x.Id == waypoint.Id));

        return segment?.GetNextWaypoint(waypoint);
    }

    public static RouteSegment? GetSegment(string jobStatus, int lane, bool isAtParking)
    {
        // find route based on job status
        RouteSegment? routeSegment = null;

        // get segment per status and lane
        switch (jobStatus)
        {
            case Constants.JobStepingStatus.ARRIVE_TO_ORIGIN:
            case Constants.JobStepingStatus.ARRIVED_AT_ORIGIN:
            case Constants.JobStepingStatus.WAITING_PICKUP:
                routeSegment = isAtParking
                    ? GetSegment(lane == 1 ? RouteSegmentType.ParkingToSTS01 : RouteSegmentType.ParkingToSTS02)
                    : GetSegment(lane == 1 ? RouteSegmentType.YardToSTS01 : RouteSegmentType.YardToSTS02);
                break;
            case Constants.JobStepingStatus.ARRIVE_TO_DESTINATION:
            case Constants.JobStepingStatus.ARRIVED_AT_BLOCK:
            case Constants.JobStepingStatus.ARRIVED_AT_DESTINATION:
            case Constants.JobStepingStatus.WAITING_DROP:
                routeSegment = GetSegment(lane == 1 ? RouteSegmentType.STS01ToYard : RouteSegmentType.STS02ToYard);
                break;
            case Constants.JobStepingStatus.COMPLETED:
                // if there is a no job, return to parking
                if (!isAtParking)
                {
                    routeSegment = GetSegment(lane == 1 ? RouteSegmentType.YardToParkingLane1 : RouteSegmentType.YardToParkingLane2);
                }
                break;
        }

        return routeSegment;
    }

    public static Waypoint GetBayWaypoint(int bayNumber, RouteSegment segment)
    {
        Waypoint? wp;
        
        // check if bay number is even number
        if (int.IsEvenInteger(bayNumber))
        {
            var idx = segment.Waypoints.FindIndex(x => x.BayNo == bayNumber - 1);
            wp = segment.Waypoints.ElementAtOrDefault(idx + 1);
        }
        else
        {
            wp = segment.Waypoints.FirstOrDefault(x => x.BayNo == bayNumber);
        }
        
        // just in case we didn't find the waypoint
        return wp ?? segment.Waypoints.Last();
    }
}