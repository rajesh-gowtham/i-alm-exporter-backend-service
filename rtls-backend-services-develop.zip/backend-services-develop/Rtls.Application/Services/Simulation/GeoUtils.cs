﻿namespace Rtls.Application.Services.Simulation;

public static class GeoUtils
{
    // Returns distance in meters between two lon/lat points
    public static double GetDistanceMeters(double lon1, double lat1, double lon2, double lat2)
    {
        const double R = 6371000; // Earth's radius in meters
        var latRad1 = Math.PI * lat1 / 180.0;
        var latRad2 = Math.PI * lat2 / 180.0;
        var dLat = latRad2 - latRad1;
        var dLon = Math.PI * (lon2 - lon1) / 180.0;

        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(latRad1) * Math.Cos(latRad2) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
        return R * c;
    }
    
    public static double ToRadians(double angle) => Math.PI * angle / 180.0;
    
    public static (double X, double Y) Normalize(double x, double y)
    {
        var mag = Math.Sqrt(x * x + y * y);
        return mag == 0 ? (0, 0) : (x / mag, y / mag);
    }

    public static double Dot(double x1, double y1, double x2, double y2)
    {
        return x1 * x2 + y1 * y2;
    }
}
