﻿# ITV Simulation Service - Functional Documentation

## Overview

The **ITV Simulation Service** is a core RTLS background module designed to simulate the real-time movement of Internal Transfer Vehicles (ITVs) within a container terminal. Its main goal is to replicate realistic vehicle movement and job execution—either autonomously or by following real Work Instructions—by updating each ITV’s GPS location, state, and job status as if it were operating in a live terminal.

This simulation is critical for:

* **System testing/demo** (showing live asset movement without physical vehicles)
* **Integration** (validating job and asset workflows)
* **Operator training** (mocking real operational behavior)
* **MVP requirement** for ITVs in RTLS (see Use Cases UC011–UC014, UC034–UC035, UC048+ in the BRS).

---

## 1. Service Modes and High-Level Behavior

The service operates in one of two **simulation modes**:

### 1. Self-Driven (Autonomous) Mode

* **Purpose:** Simulate an ITV looping a predefined terminal route endlessly (for demo or load-testing).
* **Behavior:** The vehicle continuously moves through GIS-defined segments and waypoints, pausing at "loading/unloading" points. No Work Instructions are needed; there is no job status update logic.

### 2. WorkInstruction-Driven Mode

* **Purpose:** Simulate real operations: ITV waits idle until assigned a WorkInstruction (job), then executes the job-specific route and status updates.
* **Behavior:** When a WorkInstruction is assigned (via API/import), the ITV:

    * Loads the correct route (from GeoJSON definitions)
    * Moves through waypoints per second
    * Pauses for "loading/unloading" at segment boundaries
    * Updates WorkInstruction status fields at each lifecycle step (dispatch, at origin, at destination, complete)
    * Returns to idle, awaiting the next job

This mode supports all required job stepping/status flows described in RTLS business requirements (see UC012–UC014, UC034, UC048+).

---

## 2. Core Components

### 2.1. **AssetWorker**

* **Runs as:** A background task (per asset/vehicle), ticked by a 1-second timer
* **Responsibilities:**

    * Maintains simulation state for one ITV (location, job, route progress, job status, etc.)
    * Loads and manages route data (via `SimulationHelper`)
    * Transitions through a defined state machine (Idle → Dispatched → ArrivedAtOrigin → LoadedAtOrigin → ArrivedAtDestination → UnloadedAtDestination → Idle)
    * In WorkInstruction mode, pulls jobs from the `IWorkInstructionService` and updates their statuses per RTLS workflow
    * Updates the asset's real-time "EquipmentState" (location, timestamp, route segment)
    * Optionally, raises system events via an in-memory message bus for further integration (demo/logging)
    * Optionally simulates RFID validation on entry into geo-zones using GIS proximity logic (as per UC030/UC031)

**Key Functionalities:**

* Per-second location/route progression (waypoint/time-driven)
* Simulated "pause" at loading/unloading points (randomized 20–30s wait)
* Live GPS/segment updates for each ITV in memory
* Realistic job stepping: status, timestamps, and queue state updates aligned with RTLS use case flows

### 2.2. **AssetWorkerManager**

* **Role:** Tracks, starts, stops, and disposes all active AssetWorker instances at runtime.
* Enables dynamic scaling (start/stop ITV simulators on demand).
* Provides enumeration of all active workers (for monitoring, "safe gap" logic, etc.)

### 2.3. **GeoUtils**

* Provides distance calculations (meters between GPS points) for RFID/geo-fence simulation.
* Used for RFID proximity checks (see UC030, UC031: virtual zone entry/validation logic).

---

## 3. Main Process Flow

### 3.1. **Initialization**

* Each ITV (AssetWorker) is registered with a unique ID, simulation mode, and, if autonomous, a fixed route.
* Dependencies (state service, work instruction service, logger, etc.) are injected.
* Upon startup, each worker begins its per-second simulation loop.

### 3.2. **State Machine (Per-Second Loop)**

1. **Idle**

    * Self-Driven: Never idle (starts driving immediately)
    * WorkInstruction: Polls for a new job every N seconds; starts route when assigned

2. **Dispatched (Driving a Segment)**

    * Moves through current segment’s waypoints, updating GPS location when time matches
    * If segment complete: transitions to ArrivedAtOrigin or ArrivedAtDestination

3. **ArrivedAtOrigin / ArrivedAtDestination**

    * Pauses for simulated load/unload
    * Updates relevant job fields (arrival time, status) if in WorkInstruction mode

4. **LoadedAtOrigin**

    * Starts segment 2 (from crane to yard block)

5. **UnloadedAtDestination**

    * Updates final job completion status
    * Returns to Idle (WorkInstruction) or restarts route (Self-Driven)

**At each step:**

* Logs key events and transitions (INFO/DEBUG level)
* Updates in-memory asset state (used by RTLS web dashboard/UI)
* Optionally checks for RFID proximity and updates simulated message


Here is the updated documentation section **(for your `Description.md`)** reflecting the new “Blocking/Convoy Logic” feature for realistic ITV queuing and anti-stacking.

You can place this as a new section **after "3. Main Process Flow"** (or as an addendum, if you prefer).
**I’ll show you the full suggested section; you can simply paste this in.**

---

## 3A. Blocking and Convoy Logic (Queueing at Stops)

### **Purpose**

To improve simulation realism, the service now models **ITV convoy and queueing behavior**:
When multiple ITVs approach the same stop point (such as under a quay crane or at a yard block), each ITV will check if there is another vehicle ahead on the same segment and will **wait (pause)** behind it if the route is blocked.

### **How It Works**

* **Ahead Detection:**
  Each ITV, before moving to the next waypoint or pause (e.g., loading/unloading), checks the state of all other ITVs operating on the same route segment.
* **Blocking:**
  If another ITV is already stopped (paused for loading/unloading, or otherwise blocked) at a waypoint ahead (within a configured “blocking distance”), the following ITV will wait at its current position and will not proceed until the route ahead is clear.
* **Queue Formation:**
  This results in realistic queues or convoys at all bottleneck points—no more ITVs “stacking” on the exact same coordinates.
* **Release:**
  When the ITV ahead resumes movement, the next ITV in the queue is allowed to advance, ensuring safe, non-overlapping progression along the segment.

### **Feature Details**

* The blocking check occurs **on every simulation tick**, just before the ITV would otherwise advance to a new waypoint or enter a pause.
* **Blocking distance** is configurable.
* **JobSteppingStatus** is set to `"Waiting for route to clear"` while an ITV is blocked, allowing operators to see queue state in real-time dashboards.
* No changes are needed in route or waypoint definitions: this logic is transparent to route data.
* This queueing applies in both **Self-Driven** and **WorkInstruction-Driven** simulation modes.

### **Benefits**

* Prevents visual “stacking” (marker overlap) at terminal choke points on the GIS map or dashboard.
* Models real-world operational bottlenecks (e.g., queueing under a crane).
* Enables better testing of terminal throughput and operator interventions.

### **Sample State Transition**

1. ITV1 arrives under a quay crane and begins unloading (pause).
2. ITV2 arrives at the last waypoint before the crane, checks and finds ITV1 is paused ahead, so ITV2 stops and waits.
3. When ITV1 resumes (leaves the crane), ITV2 can proceed to the crane for its own operation.

---

## 4. Route/Job Data and State

* **Routes:** Defined by GeoJSON files (imported via `SimulationHelper`). Each route has segments (e.g., parking→crane, crane→yard), each segment is a polyline of waypoints with time offsets.
* **Waypoints:** Define exact positions and expected time-of-arrival for precise, smooth movement simulation.
* **EquipmentState:** Tracks current GPS point, last update time, segment, and optional message.
* **Job/WorkInstruction:** Contains all the fields and timestamps required by the RTLS business process (dispatch, at origin, at destination, completed, etc.)

---

## 5. RFID/Geo-fence Simulation

* Each AssetWorker can simulate RFID zone entry (for MVP), e.g., detecting if ITV is "at the block entry" or "at the quay lane" using the real-time simulated GPS and preconfigured virtual reader zones (see UC030, UC031).
* Proximity is determined by simple distance calculation (see GeoUtils), with results available in the EquipmentState for UI display or validation logic.

---

## 6. Management and Extensibility

* **AssetWorkerManager:** Allows dynamic creation/destruction of ITVs in simulation (matching actual operations, e.g., maintenance, handover).
* **Service Registration:** Can register any number of AssetWorker instances, each with unique configuration/mode/route.
* **Route Extensibility:** New terminal layouts/routes are easily added by updating GeoJSON files and registering the new RouteType.
* **RFID Checkpoint Simulation:** Additional checkpoints can be configured for richer validation scenarios.

---

## 7. Relation to RTLS Business Requirements and Use Cases

This service directly implements and supports:

* **MVP Equipment Tracking (Req T001, G005, G003, G006 in BRS)** – Real-time ITV position, status, and job progress
* **Job Stepping and Status (UC012–UC014, UC034, UC048–UC050)** – Full job lifecycle emulation with stepwise updates
* **RFID/Validation Scenarios (UC030, UC031, UC032)** – Virtual checkpoints for arrival/validation events
* **Integration with GIS and Telematics (Req G005, G008, T012)** – Accurate route following and spatial updates
* **User/Operator Training and Demo** – Enables non-disruptive system demos and onboarding
* **Simulation for Test Automation and QA (Req T013, general NFRs)**

---

## 8. Logging, Monitoring, and Troubleshooting

* **Per-event logging:** All transitions and significant state changes are logged at INFO or DEBUG, aiding operational monitoring and troubleshooting.
* **OnStopped events:** Workers signal their termination for clean resource management.
* **Manager allows clean shutdown:** Ensures no asset worker is left orphaned; all are cleanly disposed.

---

## 9. Deployment/Integration Guide

* Each AssetWorker is typically registered via Dependency Injection in the backend (Minimal API).
* The AssetWorkerManager is used to control runtime behavior and scaling.
* Simulated ITVs can be started/stopped dynamically to reflect the current terminal operational state.
* The state for each ITV is made available for UI dashboards, REST APIs, and analytics modules.

---

## 10. Summary

**The ITV Simulation Service is the engine powering virtual equipment movement and job lifecycle emulation in the RTLS MVP. 
It ensures accurate, testable, and observable simulation of real terminal processes and is designed to support all core operational, training, 
and demonstration needs for RTLS at a container terminal.
**

