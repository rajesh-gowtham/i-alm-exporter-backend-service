using System.Collections.Concurrent;
using System.Collections.Immutable;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Rtls.Domain;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Application.Services.Simulation;

/// <summary>
/// Keeps track of all live AssetWorker instances.
/// Allows starting/stopping by assetId at runtime.
/// </summary>
public class AssetWorkerManager : IAsyncDisposable
{
    private readonly Func<long, AssetWorkerManager, AssetWorker> _workerFactory;
    // private readonly AppDbContext _dbContext;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ConcurrentDictionary<long, AssetWorker> _workers = new();

    private PeriodicTimer? _timer;
    private Task? _workerTask;
    private CancellationTokenSource? _cts;

    public AssetWorkerManager(
        Func<long, AssetWorkerManager, AssetWorker> workerFactory,
        IServiceScopeFactory scopeFactory)
    {
        _workerFactory = workerFactory;
        _scopeFactory = scopeFactory;
        // _dbContext = dbContext;
    }

    public async Task StartAsync(CancellationToken ct)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        _timer = new PeriodicTimer(TimeSpan.FromSeconds(3));
        _workerTask = Task.Factory.StartNew(RunLoopAsync, TaskCreationOptions.LongRunning);
        await Task.CompletedTask;
    }

    // TODO: merge with the SimulatorBgService
    private void RunLoopAsync()
    {
        try
        {
            while (!_cts!.IsCancellationRequested)
            {
                ProcessJobs().GetAwaiter().GetResult();
                Thread.Sleep(TimeSpan.FromSeconds(3));
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            // Handle exceptions, log them, etc.
            throw new InvalidOperationException("Error in AssetWorkerManager loop", ex);
        }
    }

    // Periodically checks the database for jobs and processes them.
    private async Task ProcessJobs()
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var workQueues = await db.WorkQueues
            .Include(x => x.WorkInstructions)
            .ThenInclude(x => x.PointOfWork)
            .Where(x => x.Status == Constants.JobStatus.INPROGRESS)
            .AsNoTracking()
            .ToArrayAsync();

        foreach (var workQueue in workQueues)
        {
            // pending work instructions
            var pending = workQueue.WorkInstructions
                .Where(x => x.TaskStatus == Constants.JobStepingStatus.YET_TO_START
                            || x.TaskStatus == Constants.JobStepingStatus.DISPATCHED)
                .OrderBy(x => x.Sequence)
                .ToArray();

            if (pending.Length == 0)
                continue;

            // group by ITV
            foreach (var grouped in pending.GroupBy(x => x.CheCarry))
            {
                var itvInstructions = grouped
                    .OrderBy(x => x.Sequence)
                    .ToArray();

                // instructions to pass to worker
                var instructionsToExec = new List<WorkInstruction>();

                // take first instruction 
                var firstInstruction = itvInstructions.First();
                if (itvInstructions.Length == 1)
                {
                    // pass single instruction to worker
                    instructionsToExec.Add(firstInstruction);
                }
                else
                {
                    // check if the first two instructions are Single mode and have the same BayNumber
                    if (AreTwins(itvInstructions[0], itvInstructions[1]))
                    {
                        instructionsToExec.AddRange(itvInstructions[0], itvInstructions[1]);
                    }
                    else
                    {
                        instructionsToExec.Add(firstInstruction);
                    }
                }

                await PassInstructions(instructionsToExec.ToArray());
            }
        }
    }

    private async Task PassInstructions(params WorkInstruction[] instructions)
    {
        var assetName = instructions[0].CheCarry;

        // fetch asset
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var equipment = await db.Equipments
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.EquipmentType == "Terminal Truck" && x.EquipmentName == assetName);

        if (equipment == null)
        {
            // log message
            return;
        }

        var assetId = equipment.Id;

        // If the worker does not exist, create it
        if (!_workers.TryGetValue(assetId, out var worker))
        {
            worker = _workerFactory(assetId, this);
            // Subscribe to OnStopped so we can remove it if it fails or completes.
            worker.OnStopped += OnWorkerStopped;
            // add worker to the pool
            _workers.TryAdd(assetId, worker);
        }

        // Pass the instructions to the worker
        if (!worker.IsBusy)
            worker.HandleJob(instructions);

        // fake delay to dispatch ITVs
        await Task.Delay(TimeSpan.FromSeconds(5));
    }

    private static readonly StringComparer Comparer = StringComparer.OrdinalIgnoreCase;

    private static bool AreTwins(WorkInstruction a, WorkInstruction b)
    {
        // 1) Bay must match
        //if (a.BayNumber != b.BayNumber)
        //    return false;

        // 2) Modes must match
        if (a.Mode != b.Mode)
            return false;

        // 2) Itv must match
        if (a.CheCarry != b.CheCarry)
            return false;

        var validChassisPositions = new HashSet<string>
        {
            "1",
            "3"
        };

        // 3) If TWIN, we’re done; if SINGLE, positions must differ
        return a.Mode == Constants.WorkInstructionMode.TWIN
            || (!Comparer.Equals(a.PositionOnCarriage, b.PositionOnCarriage) 
            && validChassisPositions.Contains(a.PositionOnCarriage)
            && validChassisPositions.Contains(b.PositionOnCarriage));
}
    
    // private static bool AreTwins(WorkInstruction first, WorkInstruction second)
    // {
    //     if (first.Mode == Constants.WorkInstructionMode.SINGLE
    //         && second.Mode == Constants.WorkInstructionMode.SINGLE
    //         && first.BayNumber == second.BayNumber
    //         && !string.Equals(first.PositionOnCarriage, second.PositionOnCarriage, StringComparison.OrdinalIgnoreCase))
    //         return true;
    //     return first.Mode == Constants.WorkInstructionMode.TWIN
    //            && second.Mode == Constants.WorkInstructionMode.TWIN
    //            && first.BayNumber == second.BayNumber;
    // }
    
    /// <summary>
    /// If any AssetWorker signals OnStopped, we remove and dispose it here.
    /// </summary>
    private async void OnWorkerStopped(long assetId)
    {
        try
        {
            if (_workers.TryRemove(assetId, out var worker))
            {
                // Unsubscribe first to avoid reentrancy
                worker.OnStopped -= OnWorkerStopped;

                // Dispose, if not already in DisposeAsync path
                await worker.DisposeAsync();
            }
        }
        catch (Exception e)
        {
            throw; // TODO handle exception
        }
    }

    public ImmutableList<AssetWorker> GetActiveWorkers()
    {
        return _workers.Values.ToImmutableList();
    }

    public AssetWorker? GetWorker(long assetId)
    {
        _workers.TryGetValue(assetId, out var worker);
        return worker;
    }

    /// <summary>
    /// Stops all running workers (e.g. on application shutdown).
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        if (_cts != null) await _cts.CancelAsync();
        if (_timer != null)
        {
            _timer.Dispose();
            _timer = null;
        }

        // dispose workers
        foreach (var kv in _workers)
        {
            var worker = kv.Value;
            worker.OnStopped -= OnWorkerStopped;
            await worker.DisposeAsync();
        }
        _workers.Clear();

        try
        {
            if (_workerTask != null)
                await _workerTask;
        }
        catch (OperationCanceledException)
        {
            // swallow
        }
        finally
        {
            _cts?.Dispose();
        }
    }
}
