﻿// ReSharper disable InconsistentNaming

using System.Collections.Immutable;
using NetTopologySuite.Features;
using NetTopologySuite.Geometries;
using NetTopologySuite.IO;

namespace Rtls.Application.Services.Simulation;

public enum RouteSegmentType
{
    ParkingToSTS01 = 10,
    ParkingToSTS02,
    
    YardToSTS01,
    YardToSTS02,
    
    STS01ToYard,
    STS02ToYard,
    
    YardToParkingLane1,
    YardToParkingLane2,
}

public enum RouteType
{
    Lane1,
    Lane2,
}

public record Waypoint(Point Location, string Id, int TimeMills, int Distance, string Label, int BayNo = 0);

public record RouteSegment(RouteSegmentType Type, ImmutableList<Waypoint> Waypoints)
{
    // store waypoints in a sorted list to ensure they are in the correct order?
    
    public Waypoint? GetNextWaypoint(Waypoint? currentWaypoint)
    {
        var waypoints = Waypoints;
        
        // get first waypoint if current is null
        if (currentWaypoint == null)
            return waypoints.FirstOrDefault();
        
        var currentIndex = waypoints.FindIndex(w => w.Id == currentWaypoint.Id);
        
        // from start
        if (currentIndex < 0)
            return waypoints.FirstOrDefault();

        if (currentIndex >= waypoints.Count - 1)
            return null;

        return waypoints[currentIndex + 1];
    }
}

public record Route(RouteType Type, ImmutableList<RouteSegment> Segments);

public static class SimulationHelper
{
    
    private const string Parking_To_STS01 = "Label_Parking_to_STS01_Lane_1_Truck_1.geojson";
    private const string Parking_To_STS02 = "Label_Parking_to_STS02_Lane_2_Truck_2.geojson";
    
    private const string Yard_To_STS01 = "Label_1E35A_to_STS01_Lane_1_Truck_1.geojson";
    private const string Yard_To_STS02 = "Label_1E35A_to_STS02_Lane_2_Truck_2.geojson";
    
    private const string STS01_To_Yard = "Label_STS_01_to_1E35A_Lane_1_Truck_1.geojson";
    private const string STS02_To_Yard = "Label_STS_02_to_1E35A_Lane 2_Truck_2.geojson";
    
    private const string Yard_To_Parking_Lane1 = "Label_1E35A_to_Parking_Lane_1_Truck_1.geojson";
    private const string Yard_To_Parking_Lane2 = "Label_1E35A_to_Parking_Lane_2_Truck_2.geojson";
    
    public static Waypoint? GetNextWaypoint(this RouteSegment segment, Waypoint currentWaypoint)
    {
        var waypoints = segment.Waypoints;
        var currentIndex = waypoints.FindIndex(w => w.Id == currentWaypoint.Id);

        if (currentIndex < 0 || currentIndex >= waypoints.Count - 1)
            return null;

        return waypoints[currentIndex + 1];
    }

    public static RouteSegment? GetNextSegment(this Route route, RouteSegmentType currentSegmentType)
    {
        var segments = route.Segments;
        var currentIndex = segments.FindIndex(s => s.Type == currentSegmentType);

        if (currentIndex < 0 || currentIndex >= segments.Count - 1)
            return null;

        return segments[currentIndex + 1];
    }
    
    public static RouteSegment LoadSegment(RouteSegmentType routeSegmentType)
    {
        var fileName = routeSegmentType switch
        {
            RouteSegmentType.ParkingToSTS01 => Parking_To_STS01,
            RouteSegmentType.ParkingToSTS02 => Parking_To_STS02,
            
            RouteSegmentType.YardToSTS01 => Yard_To_STS01,
            RouteSegmentType.YardToSTS02 => Yard_To_STS02,
            
            RouteSegmentType.STS01ToYard => STS01_To_Yard,
            RouteSegmentType.STS02ToYard => STS02_To_Yard,
            
            RouteSegmentType.YardToParkingLane1 => Yard_To_Parking_Lane1,
            RouteSegmentType.YardToParkingLane2 => Yard_To_Parking_Lane2,

            _ => throw new ArgumentOutOfRangeException(nameof(routeSegmentType), routeSegmentType, null)
        };

        return new RouteSegment(routeSegmentType, ReadWaypoints(fileName));
    }

    private static ImmutableList<Waypoint> ReadWaypoints(string fileName)
    {
        var waypoints = new List<Waypoint>();

        // Read the GeoJSON text from file
        var path = Path.Combine(AppContext.BaseDirectory, $"Data/{fileName}");
        var geoJsonText = File.ReadAllText(path);
        var reader = new GeoJsonReader();
        var featureCollection = reader.Read<FeatureCollection>(geoJsonText);

        foreach (var feature in featureCollection)
        {
            var location = Point.Empty;
            var id = string.Empty;
            int timeMills = 0;
            int distMeter = 0;
            string? label = null;
            int bayNo = 0;

            // Access the Geometry object (could be Point, MultiPoint, etc.)
            var geometry = feature.Geometry;
            if (geometry is Point point)
                location = point;

            // Make sure each attribute exists before converting/casting
            if (feature.Attributes.Exists("New_ID"))
                id = feature.Attributes["New_ID"].ToString();

            if (feature.Attributes.Exists("time_sec"))
                timeMills = (int)(Convert.ToSingle(feature.Attributes["time_sec"]) * 1000); // Convert to milliseconds

            if (feature.Attributes.Exists("dist_m"))
                distMeter = Convert.ToInt32(feature.Attributes["dist_m"]);

            if (feature.Attributes.Exists("Label"))
                label = feature.Attributes["Label"].ToString();

            if (feature.Attributes.Exists("bay_no"))
                bayNo = Convert.ToInt32(feature.Attributes["bay_no"]);

            waypoints.Add(new Waypoint(location, id, timeMills, distMeter, label ?? string.Empty, bayNo));
        }

        return waypoints
            .OrderBy(x => x.TimeMills)
            .ToImmutableList();
    }
}