﻿using System.Collections.Immutable;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;

namespace Rtls.Application.Services.Simulation;

public sealed class AssetWorker : IAsyncDisposable
{

    #region Fields

    private readonly ILogger<AssetWorker> _logger;
    private readonly AssetWorkerManager _manager;
    private readonly EquipmentStateService _equipmentStateService;
    private readonly IServiceProvider _serviceProvider;

    private readonly PeriodicTimer _timer;
    private readonly CancellationTokenSource _cts = new();
    private Task? _workerTask;
    private readonly object _lock = new();

    // logic related fields
    private Waypoint? _waypoint;
    private WorkInstruction[] _currentJobs = [];
    private WorkInstruction? CurrentJob => _currentJobs.FirstOrDefault();
    private int _completeCounter; // time to wait in a complete state for a new job
    private volatile bool _startsFromParking = true;
    
    // constants
    private const double RfidDetectionRadiusMeters = 5.0;
    private const int CompleteDelaySeconds = 10;
    private const double SafeDistanceMeters = 20.0;
    private const double CorridorWidthMeters = 3.5; // This should be about your vehicle width plus buffer
    
    // public properties
    public long AssetId { get; }
    public Waypoint? Waypoint => _waypoint;
    public bool IsBusy
    {
        get
        {
            lock (_lock)
            {
                return CurrentJob != null && CurrentJob.TaskStatus != Constants.JobStepingStatus.COMPLETED;
            }
        }
    }

    // --- RFID Reader Config (hardcoded for MVP) ---
    private static readonly List<RfidReaderInfo> RfidReaders =
    [
        new()
        {
            Rfid = "RF8",
            Block = "1E",
            Longitude = 76.997400156513876,
            Latitude = 8.371908061591775
        }
    ];

    private sealed class RfidReaderInfo
    {
        public string Rfid { get; set; }
        public string Block { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }

    #endregion
    
    public AssetWorker(
        long assetId,
        ILogger<AssetWorker> logger,
        AssetWorkerManager manager,
        EquipmentStateService equipmentStateService,
        IServiceProvider serviceProvider)
    {
        AssetId = assetId;

        _logger = logger;
        _manager = manager;
        _equipmentStateService = equipmentStateService;
        _serviceProvider = serviceProvider;

        // Fire once per 500 ms
        _timer = new PeriodicTimer(TimeSpan.FromMilliseconds(500));
    }

    public bool HandleJob(WorkInstruction[] jobs)
    {
        if (jobs.Length == 0)
        {
            _logger.LogWarning("No jobs provided to AssetWorker for {AssetId}.", AssetId);
            return false;
        }

        _logger.LogInformation("AssetWorker for {AssetId} IsBusy: {Status}", AssetId, IsBusy);
        if (IsBusy) return false;

        _currentJobs = [..jobs];

        foreach (var job in jobs)
            _logger.LogInformation("AssetWorker for {AssetId} received job: {JobId}", AssetId, job.Id);

        // start worker thread if not already running
        _workerTask ??= RunLoopAsync(_cts.Token)
            .ContinueWith(t => OnStopped?.Invoke(AssetId), TaskScheduler.Default);

        return true;
    }

    private async Task RunLoopAsync(CancellationToken ct)
    {
        try
        {
            while (await _timer.WaitForNextTickAsync(ct))
            {
                try
                {
                    var job = CurrentJob;
                    if (job == null)
                    {
                        _logger.LogWarning("No current job for AssetWorker {AssetId}.", AssetId);
                        break;
                    }

                    var state = _equipmentStateService.GetEquipmentState(AssetId);
                    if (state == null)
                    {
                        _logger.LogWarning(
                            "No EquipmentState found for Asset {AssetId} at {Time}.",
                            AssetId, DateTime.UtcNow);
                        continue;
                    }

                    // Always update GPS timestamp
                    state.GpsTime = DateTime.UtcNow;

                    // simulate GPS movement
                    await WorkerStateMachine(state, ct);

                    // update route segment 
                    if (_waypoint != null)
                        state.RouteSegment = RoutingHelper.FindSegment(_waypoint)?.Type;

                    // job status update
                    state.JobStatus = job.TaskStatus;

                    // job stepping status update
                    state.JobSteppingStatus = job.JobSteppingStatus != Constants.JobStepingStatus.COMPLETED ? job.JobSteppingStatus : "Waiting for Job";

                    // message for driver
                    state.Message = GetDriverMessage(job);

                    //Obtaining container data to monitor the ITV
                    state.JobDetails = GetJobDetails();

                    //Just show message to VMT user after block entry - Rfid validation success
                    state.RfidMessage = GetRfidConfirmMessage();

                    // Save state after any potential update
                    _equipmentStateService.SetEquipmentState(state);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(
                        ex,
                        "Error updating asset {AssetId} at {Time}.",
                        AssetId, DateTime.UtcNow);
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("AssetWorker for {AssetId} canceled.", AssetId);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Fatal error in AssetWorker for {AssetId}; loop terminated.",
                AssetId);
        }
    }

    private async Task WorkerStateMachine(EquipmentState state, CancellationToken ct)
    {
        var job = CurrentJob!;

        // just in case
        if (_waypoint == null)
            _startsFromParking = true;

        // state machine based on current job status
        switch (job.TaskStatus)
        {
            case Constants.JobStepingStatus.YET_TO_START:
                await HandleYetToStart(job, state, ct);
                break;
            case Constants.JobStepingStatus.DISPATCHED:
                await HandleDispatchedState(job, state, ct);
                break;
            case Constants.JobStepingStatus.ARRIVE_TO_ORIGIN:
                await HandleArriveToOriginState(job, state, ct);
                break;
            case Constants.JobStepingStatus.ARRIVED_AT_ORIGIN:
                await HandleArrivedOrigin(job, state, ct);
                break;
            case Constants.JobStepingStatus.WAITING_PICKUP:
                await HandlePickUp(job, state, ct);
                break;
            case Constants.JobStepingStatus.ARRIVE_TO_DESTINATION:
                await HandleDeparture(job, state, ct);
                break;
            case Constants.JobStepingStatus.ARRIVED_AT_BLOCK:
                await HandleBlockAssign(job, state, ct);
                break;
            case Constants.JobStepingStatus.ARRIVED_AT_DESTINATION:
                await HandleArrived(job, state, ct);
                break;
            case Constants.JobStepingStatus.WAITING_DROP:
                await HandleDrop(job, state, ct);
                break;
            case Constants.JobStepingStatus.COMPLETED:
                await HandleComplete(job, state, ct);
                break;
            default:
                _logger.LogWarning("Unhandled job stepping status: {Status} for AssetId: {AssetId}",
                    job.TaskStatus, AssetId);
                break;
        }
    }

    # region State handling

    private async Task HandleYetToStart(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandleDispatchedState(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // just in case
        _completeCounter = 0;

        // delay for 2 seconds just in case
        await Task.Delay(TimeSpan.FromSeconds(2), ct);

        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandleArriveToOriginState(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        var result = GoToNextWaypoint(job, state);
        
        // arrived to destination
        if (result == AdvanceResult.Finished)
        {
            // change status
            var next = GetNextJobSteppingStatus(job.TaskStatus!);
            await UpdateJob(next, ct);
        }

        await Task.CompletedTask;
    }

    private async Task HandleArrivedOrigin(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // simulate waiting
        await Task.Delay(TimeSpan.FromSeconds(3), ct);
        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandlePickUp(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // simulate waiting
        await Task.Delay(TimeSpan.FromSeconds(3), ct);

        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandleDeparture(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        var result = GoToNextWaypoint(job, state);
        if (result != AdvanceResult.Advanced) return;

        // check for block arrival, then head to the bay number
        var reader = GetRfidReader(state);
        if (reader != null)
        {
            // change status
            var next = GetNextJobSteppingStatus(job.TaskStatus!);
            await UpdateJob(next, ct);
        }
    }

    // a trick to store bay waypoint
    private Waypoint? _bayWayPoint;
    
    private async Task HandleBlockAssign(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // bay number 
        var bayNo = CurrentJob?.BayNumber;

        // set it once
        if (bayNo != null && _bayWayPoint == null)
        {
            // get destination waypoint
            var segment = RoutingHelper.FindSegment(_waypoint!);
            _bayWayPoint = RoutingHelper.GetBayWaypoint(bayNo.Value, segment!);
        }
        
        var result = GoToNextWaypoint(job, state);
        if (result == AdvanceResult.Advanced)
        {
            // check if arrived at a bay number
            if (_bayWayPoint != null && _waypoint?.Id == _bayWayPoint.Id)
            {
                // reset
                _bayWayPoint = null;
                
                // see if we have to finish the segment
                if (RoutingHelper.GetNext(_waypoint!) != null)
                    _hasToFinishCurrentSegment = true;
                
                // change status
                var next = GetNextJobSteppingStatus(job.TaskStatus!);
                await UpdateJob(next, ct);
            }
        }

        await Task.CompletedTask;
    }

    private async Task HandleArrived(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // simulate waiting
        await Task.Delay(TimeSpan.FromSeconds(3), ct);
        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandleDrop(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // simulate waiting
        await Task.Delay(TimeSpan.FromSeconds(3), ct);
        // trick
        _startsFromParking = false;
        // change status
        var next = GetNextJobSteppingStatus(job.TaskStatus!);
        await UpdateJob(next, ct);
    }

    private async Task HandleComplete(WorkInstruction job, EquipmentState state, CancellationToken ct)
    {
        // already parked
        if (_waypoint == null) return;

        // wait for new jobs if any
        if (_completeCounter++ < CompleteDelaySeconds)
        {
            await Task.Delay(TimeSpan.FromSeconds(1), ct);
            return;
        }

        // move to parking
        var result = GoToNextWaypoint(job, state);
        if (result != AdvanceResult.Finished)
            return;

        // reset all
        _completeCounter = 0;
        _waypoint = null;
        _startsFromParking = true;
        _currentJobs = [];

        // notify manager that worker is stopped
        OnStopped?.Invoke(AssetId);
    }
    
    public enum AdvanceResult
    {
        Advanced,    // Successfully moved to next waypoint
        Blocked,     // Temporarily blocked (by ITV, at bay, etc)
        Finished     // Route completed; segment finished
    }

    private volatile bool _hasToFinishCurrentSegment;
    
    private AdvanceResult GoToNextWaypoint(WorkInstruction job, EquipmentState state)
    {
        var currentWaypoint = _waypoint;
        RouteSegment? segment;
        
        // get current route segment
        if (_hasToFinishCurrentSegment && currentWaypoint != null)
        {
            segment = RoutingHelper.FindSegment(currentWaypoint);
        }
        else
        {
            // get lane number
            var lane = int.Parse(job.AssignedLane);
            var jobStatus = job.TaskStatus ?? string.Empty;
            segment = RoutingHelper.GetSegment(jobStatus, lane, _startsFromParking);
        }

        // if segment not found - then route is finished
        if (segment == null) return AdvanceResult.Finished;

        var nextWaypoint = segment.GetNextWaypoint(currentWaypoint);
        
        // if we are at the bay number, then we have to finish the segment
        // in case next waypoint is null and _hasToFinishCurrentSegment = true
        // we need to switch to the next segment if possible
        if (nextWaypoint == null && _hasToFinishCurrentSegment)
        {
            _hasToFinishCurrentSegment = false;
            // get lane number
            var lane = int.Parse(job.AssignedLane);
            var jobStatus = job.TaskStatus ?? string.Empty;
            segment = RoutingHelper.GetSegment(jobStatus, lane, _startsFromParking);
            if (segment == null) return AdvanceResult.Finished;
            nextWaypoint = segment.GetNextWaypoint(currentWaypoint); 
        }
        
        // if next waypoint is null, it means we reached the end of the segment
        if (nextWaypoint == null)
        {
            _logger.LogWarning(
                "AssetWorker {AssetId} reached the end of segment {SegmentType} at waypoint {WaypointId}.",
                AssetId, segment.Type, currentWaypoint?.Id);
            return AdvanceResult.Finished;
        }
        
        // check if there is another ITV ahead
        if (IsBlockedAhead(nextWaypoint))
        {
            _logger.LogWarning(
                "AssetWorker {AssetId} blocked ahead by another ITV at waypoint {WaypointId}.",
                AssetId, nextWaypoint?.Id);
            return AdvanceResult.Blocked;
        }
        
        // update current waypoint
        _waypoint = nextWaypoint;

        // update location
        state.Location = nextWaypoint.Location;

        _logger.LogInformation("AssetWorker {AssetId} moved to waypoint {X} {Y}", 
            AssetId, nextWaypoint.Location.X, nextWaypoint.Location.Y);
        
        return AdvanceResult.Advanced;
    }

    /// <summary>
    /// Checks if there is any other ITV in front within safe distance.
    /// </summary>
    private bool IsBlockedAhead(Waypoint? nextWaypoint)
    {
        if (nextWaypoint == null)
            return false;

        // 1. Use current position
        var myLon = _waypoint?.Location.X ?? nextWaypoint.Location.X;
        var myLat = _waypoint?.Location.Y ?? nextWaypoint.Location.Y;

        // 2. Compute heading vector in meters
        double dxToNext = GeoUtils.GetDistanceMeters(myLon, myLat, nextWaypoint.Location.X, myLat);
        if (nextWaypoint.Location.X < myLon) dxToNext = -dxToNext;
        double dyToNext = GeoUtils.GetDistanceMeters(myLon, myLat, myLon, nextWaypoint.Location.Y);
        if (nextWaypoint.Location.Y < myLat) dyToNext = -dyToNext;
        var (hx, hy) = GeoUtils.Normalize(dxToNext, dyToNext);

        // 3. Scan other ITVs
        foreach (var other in _manager.GetActiveWorkers())
        {
            if (other.AssetId == AssetId || other.Waypoint == null)
                continue;

            // 4. Compute other‐ITV offset in meters
            double dx = GeoUtils.GetDistanceMeters(myLon, myLat, other.Waypoint.Location.X, myLat);
            if (other.Waypoint.Location.X < myLon) dx = -dx;
            double dy = GeoUtils.GetDistanceMeters(myLon, myLat, myLon, other.Waypoint.Location.Y);
            if (other.Waypoint.Location.Y < myLat) dy = -dy;

            // 5. Project onto heading (longitudinal)
            double longitudinal = hx * dx + hy * dy;
            if (longitudinal <= 0 || longitudinal > SafeDistanceMeters)
                continue; // behind or too far ahead

            // 6. Compute lateral distance
            double lateral = Math.Sqrt(dx * dx + dy * dy - longitudinal * longitudinal);
            if (lateral < CorridorWidthMeters)
            {
                _logger.LogInformation(
                    "AssetWorker {AssetId} blocked by ITV {BlockerId} at longitudinal {Longitudinal:F2}m, lateral {Lateral:F2}m.",
                    AssetId, other.AssetId, longitudinal, lateral);
                return true;
            }
        }

        return false;
    }


    # endregion

    private static RfidReaderInfo? GetRfidReader(EquipmentState state)
    {
        RfidReaderInfo? r = null;

        foreach (var reader in RfidReaders)
        {
            var dist = GeoUtils.GetDistanceMeters(state.Longitude, state.Latitude, reader.Longitude, reader.Latitude);
            if (dist <= RfidDetectionRadiusMeters)
            {
                r = reader;
                break;
            }
        }

        return r;
    }
    
    private async Task UpdateJob(string nextStatus, CancellationToken ct = default)
    {
        using var scope = _serviceProvider.CreateScope();
        var workInstructionService = scope.ServiceProvider.GetRequiredService<IWorkInstructionService>();

        var updateQueue = false;
        var jobs = _currentJobs;

        foreach (var workInstruction in jobs)
        {
            var dto = UpdateStatus(workInstruction, nextStatus);
            await workInstructionService.UpdateAsync(dto, true, ct);
            updateQueue = dto.JobSteppingStatus == Constants.JobStepingStatus.COMPLETED;
        }

        if (updateQueue) await workInstructionService.UpdateWorkQueueStatus(CurrentJob!.WorkQueueId, ct);
    }

    private static UpdateWorkInstructionDto UpdateStatus(WorkInstruction job, string nextStatus)
    {
        switch (nextStatus)
        {
            case Constants.JobStepingStatus.DISPATCHED:
            case Constants.JobStepingStatus.ARRIVE_TO_ORIGIN:
                if (job.DispatchTime == null)
                {
                    job.DispatchTime = DateTime.UtcNow;
                    job.JobSteppingStatus = $"ITV enroute to {job.PointOfWork.Name} - {job.AssignedLane}";
                    job.WorkInstructionStatus = Constants.JobStatus.INPROGRESS;
                    job.TaskStatus = Constants.JobStepingStatus.ARRIVE_TO_ORIGIN;
                }
                break;

            case Constants.JobStepingStatus.ARRIVED_AT_ORIGIN:
                if (job.TimeAtOrigin == null)
                {
                    job.TimeAtOrigin = DateTime.UtcNow;
                    job.JobSteppingStatus = "Carry Ready";
                    job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_ORIGIN;
                }
                break;

            case Constants.JobStepingStatus.WAITING_PICKUP:
                if (job.TaskStatus != Constants.JobStepingStatus.WAITING_PICKUP)
                {
                    job.JobSteppingStatus = Constants.JobStepingStatus.WAITING_PICKUP;
                    job.TaskStatus = Constants.JobStepingStatus.WAITING_PICKUP;
                }
                break;

            case Constants.JobStepingStatus.ARRIVE_TO_DESTINATION:
                if (job.DischargeTime == null)
                {
                    job.DischargeTime = DateTime.UtcNow;
                    job.JobSteppingStatus = $"ITV enroute to {job.TargetLocation[..2]}W";
                    job.TaskStatus = Constants.JobStepingStatus.ARRIVE_TO_DESTINATION;
                }
                break;

            case Constants.JobStepingStatus.ARRIVED_AT_BLOCK:
                if (job.TimeFacilityIn == null)
                {
                    job.TimeFacilityIn = DateTime.UtcNow;
                    job.JobSteppingStatus = $"ITV enroute to {job.TargetLocation[..2]}W{job.TargetLocation.Substring(2, 2)}";
                    job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_BLOCK;
                }
                break;

            case Constants.JobStepingStatus.ARRIVED_AT_DESTINATION:
                if (job.TimeAtDestination == null)
                {
                    job.TimeAtDestination = DateTime.UtcNow;
                    job.JobSteppingStatus = $"ITV reaches {job.TargetLocation[..2]}W{job.TargetLocation.Substring(2, 2)}";
                    job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_DESTINATION;
                }
                break;

            case Constants.JobStepingStatus.WAITING_DROP:
                if (job.TaskStatus != Constants.JobStepingStatus.WAITING_DROP)
                {
                    job.JobSteppingStatus = Constants.JobStepingStatus.WAITING_DROP;
                    job.TaskStatus = Constants.JobStepingStatus.WAITING_DROP;
                }
                break;

            case Constants.JobStepingStatus.COMPLETED:
                if (job.JobCompleteTime == null)
                {
                    job.JobCompleteTime = DateTime.UtcNow;
                    job.JobSteppingStatus = Constants.JobStepingStatus.COMPLETED;
                    job.TaskStatus = Constants.JobStepingStatus.COMPLETED;
                    job.WorkInstructionStatus = Constants.JobStatus.COMPLETED;
                }
                break;
        }

        job.UpdatedAt = DateTime.UtcNow;
        return ToUpdateDto(job);
    }

    private static string GetNextJobSteppingStatus(string jobSteppingStatus)
    {
        return jobSteppingStatus switch
        {
            Constants.JobStepingStatus.YET_TO_START => Constants.JobStepingStatus.DISPATCHED,
            Constants.JobStepingStatus.DISPATCHED => Constants.JobStepingStatus.ARRIVE_TO_ORIGIN,
            Constants.JobStepingStatus.ARRIVE_TO_ORIGIN => Constants.JobStepingStatus.ARRIVED_AT_ORIGIN,
            Constants.JobStepingStatus.ARRIVED_AT_ORIGIN => Constants.JobStepingStatus.WAITING_PICKUP,
            Constants.JobStepingStatus.WAITING_PICKUP => Constants.JobStepingStatus.ARRIVE_TO_DESTINATION,
            Constants.JobStepingStatus.ARRIVE_TO_DESTINATION => Constants.JobStepingStatus.ARRIVED_AT_BLOCK,
            Constants.JobStepingStatus.ARRIVED_AT_BLOCK => Constants.JobStepingStatus.ARRIVED_AT_DESTINATION,
            Constants.JobStepingStatus.ARRIVED_AT_DESTINATION => Constants.JobStepingStatus.WAITING_DROP,
            Constants.JobStepingStatus.WAITING_DROP => Constants.JobStepingStatus.COMPLETED,
            _ => "Invalid"
        };
    }

    private static string GetDriverMessage(WorkInstruction wi)
    {
        return wi.TaskStatus switch
        {
            Constants.JobStepingStatus.DISPATCHED or Constants.JobStepingStatus.ARRIVE_TO_ORIGIN => "Drive to " + wi.PointOfWork.Name + " - " + wi.AssignedLane,
            Constants.JobStepingStatus.ARRIVED_AT_ORIGIN => "Arrived at " + wi.PointOfWork.Name + " - " + wi.AssignedLane,
            Constants.JobStepingStatus.WAITING_PICKUP => "Waiting for Pickup",
            Constants.JobStepingStatus.ARRIVE_TO_DESTINATION => "Drive to " + wi.TargetLocation[..2] + "W",
            Constants.JobStepingStatus.ARRIVED_AT_BLOCK => "Drive to " + wi.TargetLocation[..2] + "W" + wi.TargetLocation.Substring(2, 2),
            Constants.JobStepingStatus.ARRIVED_AT_DESTINATION => "Arrived at " + wi.TargetLocation[..2] + "W" + wi.TargetLocation.Substring(2, 2),
            Constants.JobStepingStatus.WAITING_DROP => "Waiting for Drop",
            _ => string.Empty
        };
    }

    private ImmutableArray<JobDetailsDto> GetJobDetails()
    {
        var jobs = _currentJobs;
        return jobs
            .Where(x => x.TaskStatus != Constants.JobStepingStatus.COMPLETED)
            .Select(x => new JobDetailsDto
            {
                ContainerId = x.ContainerId,
                Iso = x.IsoCode,
                Type = x.MoveType,
                PosOnChassis = x.PositionOnCarriage,
                TargetPos = x.TargetLocation
            })
            .ToImmutableArray();
    }
    
    private string GetRfidConfirmMessage()
    {
        return CurrentJob?.TaskStatus == Constants.JobStepingStatus.ARRIVED_AT_BLOCK 
            ? "Block Entry Confirmed" 
            : string.Empty;
    }
    
    private static UpdateWorkInstructionDto ToUpdateDto(WorkInstruction job)
    {
        return new UpdateWorkInstructionDto(
            Id: job.Id,
            VesselVisitId: job.VesselVisitId,
            MoveType: job.MoveType,
            FromLocation: job.FromLocation,
            TargetLocation: job.TargetLocation,
            IsoCode: job.IsoCode,
            AssignedChe: job.AssignedChe,
            CheCarry: job.CheCarry,
            PositionOnCarriage: job.PositionOnCarriage,
            PointOfWorkId: job.PointOfWorkId,
            ContainerId: job.ContainerId,
            WorkInstructionStatus: job.WorkInstructionStatus,
            JobSteppingStatus: job.JobSteppingStatus,
            Sequence: job.Sequence,
            Mode: job.Mode,
            InboundLocationType: job.InboundLocationType,
            OutboundLocationType: job.OutboundLocationType,
            OutboundCarrier: job.OutboundCarrier,
            Deck: job.Deck,
            PairContainer: job.PairContainer,
            Weight: job.Weight,
            AssignedLane: job.AssignedLane,
            TaskStatus: job.TaskStatus,
            JobStartTime: job.JobStartTime,
            DispatchTime: job.DispatchTime,
            JobCompleteTime: job.JobCompleteTime,
            TimeAtOrigin: job.TimeAtOrigin,
            TimeAtDestination: job.TimeAtDestination,
            DischargeTime: job.DischargeTime,
            TimeFacilityIn: job.TimeFacilityIn
        );
    }
    
    #region Public Events & Disposal

    public event Action<long>? OnStopped;

    public async ValueTask DisposeAsync()
    {
        _cts.Cancel();
        _timer.Dispose();

        try
        {
            if (_workerTask != null)
                await _workerTask;
        }
        catch (OperationCanceledException)
        {
            // swallow
        }
        finally
        {
            _cts.Dispose();
        }

        _logger.LogInformation("AssetWorker for {AssetId} disposed.", AssetId);
    }

    #endregion
}