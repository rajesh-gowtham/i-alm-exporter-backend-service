using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rtls.Application.Interfaces;
using System.Net.Http.Headers;
using System.Text;

namespace Rtls.Application.Services;

public class RfidIntegrationService : IRfidIntegrationService
{
    private readonly ILogger<RfidIntegrationService> _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly RfidTokenProvider _rfidTokenProvider;

    public RfidIntegrationService(
        ILogger<RfidIntegrationService> logger,
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        RfidTokenProvider rfidTokenProvider
        )
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _rfidTokenProvider = rfidTokenProvider ?? throw new ArgumentNullException(nameof(rfidTokenProvider));
    }

    public async Task RefreshTokenAsync()
    {
        _logger.LogInformation("Rfid Token Refresh Started");
        var client = _httpClientFactory.CreateClient();

        var loginPayload = new
        {
            email = _configuration["RfidAuth:Email"],
            password = _configuration["RfidAuth:Password"],
            rememberMe = bool.Parse(_configuration["RfidAuth:RememberMe"] ?? "true")
        };

        var content = new StringContent(JsonConvert.SerializeObject(loginPayload), Encoding.UTF8, "application/json");

        var loginUrl = _configuration["RfidAuth:LoginUrl"];
        var response = await client.PostAsync(loginUrl, content);
        
        if (!response.IsSuccessStatusCode)
            throw new Exception("Rfid Token fetch failed");

        var responseContent = await response.Content.ReadAsStringAsync();
        var json = JObject.Parse(responseContent);

        var accessToken = json["token"]?.ToString();
        _rfidTokenProvider.SetToken(accessToken);
    }

    public async Task<TResponse> PostAsync<TRequest, TResponse>(string url, TRequest body)
    {
        _logger.LogInformation("Rfid Post Method Started");
        var client = _httpClientFactory.CreateClient("rfidClient");

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rfidTokenProvider.GetToken());

        var json = JsonConvert.SerializeObject(body);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var baseUrl = _configuration["RfidAuth:DataUrl"];
        var response = await client.PostAsync(baseUrl + url, content);

        var responseContent = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"POST {url} failed. Status: {response.StatusCode}, Body: {responseContent}");
            throw new HttpRequestException($"API call failed: {response.StatusCode} - {responseContent}");
        }

        try
        {
            return JsonConvert.DeserializeObject<TResponse>(responseContent)
                   ?? throw new Exception("Empty response");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Deserialization failed for URL: {url}", url);
            throw;
        }
    }

    public async Task<TResponse> GetAsync<TResponse>(string url)
    {
        _logger.LogInformation("Rfid Get Method Started");
        var client = _httpClientFactory.CreateClient("rfidClient");

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rfidTokenProvider.GetToken());

        var baseUrl = _configuration["RfidAuth:DataUrl"];
        var response = await client.GetAsync(baseUrl + url);

        var responseContent = await response.Content.ReadAsStringAsync();
        _logger.LogInformation($"Response JSON : {responseContent}");
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"GET {url} failed. Status: {response.StatusCode}, Body: {responseContent}");
            throw new HttpRequestException($"GET request failed: {response.StatusCode} - {responseContent}");
        }

        try
        {
            return JsonConvert.DeserializeObject<TResponse>(responseContent)
                   ?? throw new Exception("Empty response");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Deserialization failed for URL: {url}", url);
            throw;
        }
    }

    public async Task<TResponse> PostWithoutBodyAsync<TResponse>(string url)
    {
        var client = _httpClientFactory.CreateClient("rfidClient");

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rfidTokenProvider.GetToken());

        var baseUrl = _configuration["RfidAuth:DataUrl"];
        var response = await client.PostAsync(baseUrl + url, null);

        var responseContent = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"POST {url} failed. Status: {response.StatusCode}, Body: {responseContent}");
            throw new HttpRequestException($"API call failed: {response.StatusCode} - {responseContent}");
        }

        try
        {
            return JsonConvert.DeserializeObject<TResponse>(responseContent)
                   ?? throw new Exception("Empty response");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Deserialization failed for URL: {url}", url);
            throw;
        }
    }
}