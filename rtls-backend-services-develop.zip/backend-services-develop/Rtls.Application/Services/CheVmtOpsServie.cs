using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Application.Services;

public class CheVmtOpsServie : ICheVmtOpsServie
{
    private readonly IEquipmentDataAccess _equipmentDataAccess;
    private readonly IEquipmentPoolAssignmentDataAccess _equipmentPoolAssignmentDataAccess;
    private readonly IWorkInstructionDataAccess _workInstructionDataAccess;
    private readonly IWorkQueueDataAccess _workQueueDataAccess;
    private readonly IWorkInstructionService _workInstructionService;
    private readonly IVmtUsersDataAccess _vmtUsersDataAccess;
    private readonly IVmtAuditLoginDataAccess _vmtAuditLoginDataAccess;
    private readonly ILogger<CheVmtOpsServie> _logger;

    public CheVmtOpsServie(
        ILogger<CheVmtOpsServie> logger,
        IEquipmentDataAccess equipmentDataAccess,
        IVmtUsersDataAccess vmtUsersDataAccess,
        IWorkInstructionDataAccess workInstructionDataAccess,
        IEquipmentPoolAssignmentDataAccess equipmentPoolAssignmentDataAccess,
        IWorkInstructionService workInstructionService,
        IWorkQueueDataAccess workQueueDataAccess,
        IVmtAuditLoginDataAccess vmtAuditLoginDataAccess)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _equipmentDataAccess = equipmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentDataAccess));
        _vmtUsersDataAccess = vmtUsersDataAccess ?? throw new ArgumentNullException(nameof(vmtUsersDataAccess));
        _workInstructionDataAccess = workInstructionDataAccess ?? throw new ArgumentNullException(nameof(workInstructionDataAccess));
        _equipmentPoolAssignmentDataAccess = equipmentPoolAssignmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentPoolAssignmentDataAccess));
        _workInstructionService = workInstructionService ?? throw new ArgumentNullException(nameof(workInstructionService));
        _workQueueDataAccess = workQueueDataAccess ?? throw new ArgumentNullException(nameof(workQueueDataAccess));
        _vmtAuditLoginDataAccess = vmtAuditLoginDataAccess ?? throw new ArgumentNullException(nameof(vmtAuditLoginDataAccess));
    }

    public async Task<VmtJobDto> Login(string cheId, string userId, CancellationToken ct = default)
    {
        _logger.LogInformation("ITV driver login with userId: {userId} and target che {cheId}", userId, cheId);
        var user = await _vmtUsersDataAccess.GetByNameAsync(userId, ct) ?? throw new UnauthorizedAccessException("User Not Found");
        var equipment = await _equipmentDataAccess.GetByVmtUserIdAsync(user.Id, ct);
        if (equipment != null && equipment.EquipmentName.Equals(cheId) && equipment.Status.Equals(Constants.EquipmentStatus.AVAILABLE))
        {
            return await MapVmtJobDetails(cheId, userId, equipment, ct);
        }
        else if (equipment != null)
        {
            _logger.LogError($"This user is already logged into another che {equipment.EquipmentName}.");
            throw new InvalidOperationException($"This user is already logged into another che {equipment.EquipmentName}.");
        }
        else
        {
            var status = Constants.EquipmentStatus.IDLE;
            await UpdateUserDetailsToChe(cheId, user, status, ct);
            await UpdateAuditLogin(cheId, userId, Constants.UserStatus.LOGIN, ct);
            return new VmtJobDto
            {
                UserId = userId,
                CheId = cheId,
                Status = status,
                SingleDischTwinCarry = false,
                JobDetails = [],
                Instruction = "You are IDLE",
                RfidMessage = ""
            };
        }
    }

    private async Task UpdateAuditLogin(string cheId, string userId, string action, CancellationToken ct)
    {
        switch (action)
        {
            case Constants.UserStatus.LOGIN:
                var vmtAuditLogin = new VmtAuditLogin
                {
                    EquipmentId = cheId,
                    UserId = userId,
                    LoginTime = DateTime.UtcNow,
                    CreatedAt = DateTime.UtcNow,
                    CreatedBy = "Admin"
                };
                await _vmtAuditLoginDataAccess.CreateAsync(vmtAuditLogin, ct);
            break;
            case Constants.UserStatus.LOGOUT:
                var auditLogin = await _vmtAuditLoginDataAccess.GetByUserIdAndChe(userId, cheId, ct);
                auditLogin.LogoutTime = DateTime.UtcNow;
                auditLogin.UpdatedAt = DateTime.UtcNow;
                auditLogin.UpdatedBy = "Admin";
                await _vmtAuditLoginDataAccess.UpdateAsync(auditLogin, ct);
            break;
        }
    }

    private async Task<VmtJobDto> MapVmtJobDetails(string cheId, string userId, Equipment equipment, CancellationToken ct = default)
    {
        var jobDetails = await GetVmtActiveJobDetails(cheId, ct);
        return new VmtJobDto
        {
            UserId = userId,
            CheId = cheId,
            Status = equipment.Status,
            SingleDischTwinCarry = FindSingleDishTwinCarry(jobDetails),
            JobDetails = jobDetails,
            Instruction = !jobDetails.Any() ? "Waiting for Job" :await MapVmtInstructionByStatus(cheId, ct),
            RfidMessage = jobDetails.Any() ? await GetRfidMessage(cheId, ct) : ""
        };
    }

    private async Task<string> GetRfidMessage(string cheId, CancellationToken ct)
    {
        var workInstructions = await _workInstructionDataAccess.GetByEquipmentId(cheId, ct);
        return workInstructions[0].TaskStatus.Equals(Constants.JobStepingStatus.ARRIVED_AT_BLOCK) ? "Block Entry Confirmed" : "";
    }


    private bool FindSingleDishTwinCarry(List<JobDetailsDto> jobDetails)
    {
        return jobDetails.Count == 2 && jobDetails[0].Mode == Constants.WorkInstructionMode.SINGLE;
    }

    private async Task<List<JobDetailsDto>> GetVmtActiveJobDetails(string cheId, CancellationToken ct = default)
    {
        var workInstructions = await _workInstructionDataAccess.GetByEquipmentId(cheId, ct);
        //if(workInstructions == null || workInstructions.Count() == 0)
        //{
        //    var poolName = await _equipmentPoolAssignmentDataAccess.GetPoolNameByEquipmentName(cheId, ct);
        //    if(poolName == null) return new List<JobDetailsDto>();
        //    var result = await _workInstructionService.ActivateNextJobByPoolName(poolName, cheId, ct);
        //    if(!result) return new List<JobDetailsDto>();
        //}
        if (workInstructions == null) return new List<JobDetailsDto>();
        workInstructions = workInstructions.OrderBy(wi => wi.Sequence).ToList();
        var jobDetails = workInstructions?.Select(wi =>
        {
            bool isAtDestination = !(wi.TaskStatus.Equals(Constants.JobStepingStatus.DISPATCHED) ||
                                    wi.TaskStatus.Equals(Constants.JobStepingStatus.ARRIVE_TO_ORIGIN) ||
                                    wi.TaskStatus.Equals(Constants.JobStepingStatus.ARRIVED_AT_ORIGIN) ||
                                    wi.TaskStatus.Equals(Constants.JobStepingStatus.WAITING_PICKUP));

            return new JobDetailsDto
            {
                ContainerId = isAtDestination ? wi.ContainerId : null,
                Iso = isAtDestination ? wi.IsoCode : null,
                Weight = isAtDestination ? wi.Weight : null,
                Type = wi.MoveType,
                Mode = wi.Mode,
                PosOnChassis = isAtDestination ? wi.PositionOnCarriage : null,
            };
        }).ToList();

        return jobDetails ?? new List<JobDetailsDto>();
    }

    private async Task<string> MapVmtInstructionByStatus(string cheId, CancellationToken ct = default)
    {
        var workInstructions = await _workInstructionDataAccess.GetByEquipmentId(cheId, ct);
        if (workInstructions.Count == 0) return "Waiting for Job";
        workInstructions = workInstructions.OrderBy(wi => wi.Sequence).ToList();
        var wi = workInstructions.Count == 2 ? workInstructions[1] : workInstructions[0];
        switch (wi.TaskStatus)
        {
            case Constants.JobStepingStatus.DISPATCHED:
            case Constants.JobStepingStatus.ARRIVE_TO_ORIGIN:
                foreach (var job in workInstructions)
                {
                    if (job.DispatchTime == null)
                    {
                        job.DispatchTime = DateTime.UtcNow;
                        job.UpdatedAt = DateTime.UtcNow;
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVE_TO_ORIGIN;
                        job.JobSteppingStatus = "ITV enroute to " + job.PointOfWork.Name + " - " + job.AssignedLane;
                        await _workInstructionDataAccess.UpdateAsync(job);
                    }
                }
                return "Drive to " + wi.PointOfWork.Name + " - " + wi.AssignedLane;
            case Constants.JobStepingStatus.ARRIVED_AT_ORIGIN:
                return "Arrived at " + wi.PointOfWork.Name + " - " + wi.AssignedLane;
            case Constants.JobStepingStatus.WAITING_PICKUP:
                return "Waiting for Pickup";
            case Constants.JobStepingStatus.ARRIVE_TO_DESTINATION:
                return "Drive to " + wi.TargetLocation[..2] + "W";
            case Constants.JobStepingStatus.ARRIVED_AT_BLOCK:
                return "Drive to " + wi.TargetLocation[..2] + "W" + wi.TargetLocation.Substring(2, 2);
            case Constants.JobStepingStatus.ARRIVED_AT_DESTINATION:
                return "Arrived at " + wi.TargetLocation[..2] + "W" + wi.TargetLocation.Substring(2, 2);
            case Constants.JobStepingStatus.WAITING_DROP:
                return "Waiting for Drop";
            default:
                return "Invalid";
        }
    }

    public async Task<bool> Logout(string cheId, string userId, CancellationToken ct = default)
    {
        _logger.LogInformation("ITV driver logout with userId: {userId} and target che {cheId}", userId, cheId);
        var user = await _vmtUsersDataAccess.GetByNameAsync(userId, ct) ?? throw new UnauthorizedAccessException("User Not Found");
        var equipment = await _equipmentDataAccess.GetByVmtUserIdAsync(user.Id, ct);
        if (equipment != null)
        {
            var status = Constants.EquipmentStatus.LOGOUT;
            await UpdateAuditLogin(cheId, userId, Constants.UserStatus.LOGOUT, ct);
            return await UpdateUserDetailsToChe(cheId, null, status, ct);
        }
        return false;
    }

    private async Task<bool> UpdateUserDetailsToChe(string cheId, VmtUsers user, string status, CancellationToken ct = default)
    {
        var equipment = await _equipmentDataAccess.GetByNameAsync(cheId, ct) ?? throw new InvalidOperationException("This equipment was not found.");
        equipment.Status = status;
        equipment.VmtUserId = user != null ? user.Id : null;
        equipment.VmtUser = user != null ? user : null;
        equipment.UpdatedAt = DateTime.UtcNow;
        return await _equipmentDataAccess.UpdateAsync(equipment, ct);
    }

    public async Task<VmtJobDto> JobStepingUpdates(string cheId, string userId, string action, CancellationToken ct = default)
    {
        var equipment = await _equipmentDataAccess.GetByNameAsync(cheId, ct) ?? throw new InvalidOperationException("This equipment was not found.");
        if (action.Equals(Constants.EquipmentStatus.UNAVAILABLE))
        {
            var status = Constants.EquipmentStatus.IDLE;
            equipment.Status = status;
            equipment.UpdatedAt = DateTime.UtcNow;
            await _equipmentDataAccess.UpdateAsync(equipment, ct);
            return new VmtJobDto
            {
                UserId = userId,
                CheId = cheId,
                Status = status,
                SingleDischTwinCarry = false,
                JobDetails = [],
                Instruction = "You are IDLE",
                RfidMessage = ""
            };
        }
        if (!action.Equals(Constants.EquipmentStatus.AVAILABLE))
        {
            await UpdateJobStatus(cheId, action, ct);
        }
        if (equipment.Status != null && !equipment.Status.Equals(Constants.EquipmentStatus.AVAILABLE))
        {
            equipment.Status = Constants.EquipmentStatus.AVAILABLE;
            equipment.UpdatedAt = DateTime.UtcNow;
            await _equipmentDataAccess.UpdateAsync(equipment, ct);
        }
        var jobDetails = await GetVmtActiveJobDetails(cheId, ct);
        return new VmtJobDto
        {
            UserId = userId,
            CheId = cheId,
            Status = equipment.Status,
            SingleDischTwinCarry = FindSingleDishTwinCarry(jobDetails),
            JobDetails = jobDetails,
            Instruction = jobDetails.Count == 0 ? "Waiting for Job" : await MapVmtInstructionByStatus(cheId, ct),
            RfidMessage = jobDetails.Any() ? await GetRfidMessage(cheId, ct) : ""
        };
    }

    private async Task UpdateJobStatus(string cheId, string action, CancellationToken ct)
    {
        var workInstructions = await _workInstructionDataAccess.GetByEquipmentId(cheId, ct);
        int count = workInstructions.Count;

        if (count == 0) return;

        workInstructions = count == 2 ? UpdateInstructionsIfReadyForDischargeOrTwinCarry(workInstructions) : workInstructions;

        for (int i = 0; i < workInstructions.Count; i++)
        {
            var job = workInstructions[i];

            var nextStatus = job.TaskStatus;
            if (action == Constants.EquipmentStatus.LOCKED)
            {
                nextStatus = GetNextJobStepingStatus(job.TaskStatus);
            }
            
            switch (nextStatus)
            {
                case Constants.JobStepingStatus.DISPATCHED:
                case Constants.JobStepingStatus.ARRIVE_TO_ORIGIN:
                    if (job.DispatchTime == null)
                    {
                        job.DispatchTime = DateTime.UtcNow;
                        job.JobSteppingStatus = $"ITV enroute to {job.PointOfWork.Name} - {job.AssignedLane}";
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVE_TO_ORIGIN;
                    }
                    break;

                case Constants.JobStepingStatus.ARRIVED_AT_ORIGIN:
                    if (job.TimeAtOrigin == null)
                    {
                        job.TimeAtOrigin = DateTime.UtcNow;
                        job.JobSteppingStatus = "Carry Ready";
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_ORIGIN;
                    }
                    break;

                case Constants.JobStepingStatus.WAITING_PICKUP:
                    if (job.TaskStatus != Constants.JobStepingStatus.WAITING_PICKUP)
                    {
                        job.JobSteppingStatus = Constants.JobStepingStatus.WAITING_PICKUP;
                        job.TaskStatus = Constants.JobStepingStatus.WAITING_PICKUP;
                    }
                    break;

                case Constants.JobStepingStatus.ARRIVE_TO_DESTINATION:
                    if (job.DischargeTime == null)
                    {
                        job.DischargeTime = DateTime.UtcNow;
                        job.JobSteppingStatus = $"ITV enroute to {job.TargetLocation[..2]}W";
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVE_TO_DESTINATION;
                    }
                    break;

                case Constants.JobStepingStatus.ARRIVED_AT_BLOCK:
                    if (job.TimeFacilityIn == null)
                    {
                        job.TimeFacilityIn = DateTime.UtcNow;
                        job.JobSteppingStatus = $"ITV enroute to {job.TargetLocation[..2]}W{job.TargetLocation.Substring(2, 2)}";
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_BLOCK;
                    }
                    break;

                case Constants.JobStepingStatus.ARRIVED_AT_DESTINATION:
                    if (job.TimeAtDestination == null)
                    {
                        job.TimeAtDestination = DateTime.UtcNow;
                        job.JobSteppingStatus = $"ITV reaches {job.TargetLocation[..2]}W{job.TargetLocation.Substring(2, 2)}";
                        job.TaskStatus = Constants.JobStepingStatus.ARRIVED_AT_DESTINATION;
                    }
                    break;

                case Constants.JobStepingStatus.WAITING_DROP:
                    if (job.TaskStatus != Constants.JobStepingStatus.WAITING_DROP)
                    {
                        job.JobSteppingStatus = Constants.JobStepingStatus.WAITING_DROP;
                        job.TaskStatus = Constants.JobStepingStatus.WAITING_DROP;
                    }
                    break;

                case Constants.JobStepingStatus.COMPLETED:
                    if (job.JobCompleteTime == null)
                    {
                        job.JobCompleteTime = DateTime.UtcNow;
                        job.JobSteppingStatus = Constants.JobStepingStatus.COMPLETED;
                        job.TaskStatus = Constants.JobStepingStatus.COMPLETED;
                        job.WorkInstructionStatus = Constants.JobStatus.COMPLETED;
                        await UpdateWorkQueueStatus(job.WorkQueueId, ct);
                    }
                    break;
            }
            job.UpdatedAt = DateTime.UtcNow;
            await _workInstructionDataAccess.UpdateAsync(job);
        }
    }

    private List<WorkInstruction> UpdateInstructionsIfReadyForDischargeOrTwinCarry(List<WorkInstruction> workInstructions)
    {
        if (workInstructions[0].TaskStatus == Constants.JobStepingStatus.WAITING_DROP)
            workInstructions = workInstructions.OrderByDescending(wi => wi.PositionOnCarriage).ToList();
        else
            workInstructions = workInstructions.OrderBy(wi => wi.Sequence).ToList();

        bool isSingleDishTwinCarry = workInstructions[0].Mode == Constants.WorkInstructionMode.SINGLE;
        bool isTwinMode = workInstructions[0].Mode == Constants.WorkInstructionMode.TWIN;

        bool isAtOrigin = workInstructions[0].TaskStatus == Constants.JobStepingStatus.WAITING_PICKUP
                       || workInstructions[1].TaskStatus == Constants.JobStepingStatus.WAITING_PICKUP;

        bool isAtDestination = workInstructions[0].TaskStatus == Constants.JobStepingStatus.WAITING_DROP
                            || workInstructions[1].TaskStatus == Constants.JobStepingStatus.WAITING_DROP;

        if ((isSingleDishTwinCarry && (isAtOrigin || isAtDestination)) ||
            (isTwinMode && isAtDestination))
        {
            workInstructions = SingleDischargeTwinCarry(workInstructions);
        }
        return workInstructions;
    }

    private List<WorkInstruction> SingleDischargeTwinCarry(List<WorkInstruction> workInstructions)
    {
        workInstructions = workInstructions.OrderBy(wi => wi.Sequence).ToList();
        if (workInstructions[0].TaskStatus == Constants.JobStepingStatus.WAITING_PICKUP)
        {
            workInstructions.Remove(workInstructions[1]);
        }
        else
        {
            workInstructions.Remove(workInstructions[0]);
        }
        return workInstructions;
    }

    private async Task UpdateWorkQueueStatus(long workQueueId, CancellationToken ct)
    {
        var workQueue = await _workQueueDataAccess.GetByIdAsync(workQueueId, ct);
        int pendingJobs = workQueue.WorkInstructions
            .Where(wi => !wi.WorkInstructionStatus.Equals(Constants.JobStatus.COMPLETED))
            .Count();
        if(pendingJobs == 0)
        {
            workQueue.Status = Constants.JobStatus.COMPLETED;
            workQueue.UpdatedAt = DateTime.UtcNow;
            await _workQueueDataAccess.UpdateAsync(workQueue, ct);
        }
    }

    private static string GetNextJobStepingStatus(string jobSteppingStatus)
    {
        return jobSteppingStatus switch
        {
            Constants.JobStepingStatus.DISPATCHED => Constants.JobStepingStatus.ARRIVE_TO_ORIGIN,
            Constants.JobStepingStatus.ARRIVE_TO_ORIGIN => Constants.JobStepingStatus.ARRIVED_AT_ORIGIN,
            Constants.JobStepingStatus.ARRIVED_AT_ORIGIN => Constants.JobStepingStatus.WAITING_PICKUP,
            Constants.JobStepingStatus.WAITING_PICKUP => Constants.JobStepingStatus.ARRIVE_TO_DESTINATION,
            Constants.JobStepingStatus.ARRIVE_TO_DESTINATION => Constants.JobStepingStatus.ARRIVED_AT_BLOCK,
            Constants.JobStepingStatus.ARRIVED_AT_BLOCK => Constants.JobStepingStatus.ARRIVED_AT_DESTINATION,
            Constants.JobStepingStatus.ARRIVED_AT_DESTINATION => Constants.JobStepingStatus.WAITING_DROP,
            Constants.JobStepingStatus.WAITING_DROP => Constants.JobStepingStatus.COMPLETED,
            _ => "Invalid",
        } ?? "Invalid";
    }
}