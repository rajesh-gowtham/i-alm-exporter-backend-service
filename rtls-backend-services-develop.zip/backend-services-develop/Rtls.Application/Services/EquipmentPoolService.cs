using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class EquipmentPoolService : IEquipmentPoolService
{
    private readonly IEquipmentPoolDataAccess _dataAccess;
    private readonly IEquipmentPoolAssignmentDataAccess _equipmentPoolAssignmentDataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<EquipmentPoolService> _logger;
    private readonly IMapper _mapper;

    public EquipmentPoolService(
        ICurrentUserService currentUserService,
        ILogger<EquipmentPoolService> logger,
        IMapper mapper,
        IEquipmentPoolDataAccess dataAccess,
        IEquipmentPoolAssignmentDataAccess equipmentPoolAssignmentDataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
        _equipmentPoolAssignmentDataAccess = equipmentPoolAssignmentDataAccess ?? throw new ArgumentNullException(nameof(equipmentPoolAssignmentDataAccess));
    }

    public async Task<PagedResponse<EquipmentPoolDto>> GetAllAsync(int skip = 0, int? take = null, 
        string search = "", CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all equipment pools");

        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, search, ct);

        if (pagedEntities.TotalCount == 0) return PagedResponse<EquipmentPoolDto>.Empty;

        var dtos = _mapper.Map<EquipmentPoolDto[]>(pagedEntities.Items);

        return new PagedResponse<EquipmentPoolDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<EquipmentPoolDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting equipment pool with ID: {EquipmentPoolId}", id);
        var entity = await _dataAccess.GetByIdAsync(id, ct);

        if (entity == null)
        {
            _logger.LogWarning("Equipment pool with ID: {EquipmentPoolId} not found", id);
            return null;
        }

        return _mapper.Map<EquipmentPoolDto>(entity);
    }

    public async Task<EquipmentPoolDto> CreateAsync(CreateEquipmentPoolDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateEquipmentPoolData(dto);
        await ValidateDuplicateData(new List<CreateEquipmentPoolDto> { dto }, ct);
        _logger.LogInformation("Creating new equipment pool: {PoolName}", dto.PoolName);

        var entity = _mapper.Map<EquipmentPool>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.CreatedBy = username;
        entity.UpdatedBy = username;
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        var createdEntity = await _dataAccess.CreateAsync(entity, ct);

        _logger.LogInformation("Equipment pool created successfully with ID: {EquipmentPoolId}", createdEntity.Id);
        return _mapper.Map<EquipmentPoolDto>(createdEntity);
    }

    public async Task<bool> UpdateAsync(UpdateEquipmentPoolDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidateEquipmentPoolData(dto);

        _logger.LogInformation("Updating equipment pool with ID: {EquipmentPoolId}", dto.Id);

        var entity = await _dataAccess.GetByIdAsync(dto.Id, ct);
        if (entity is null)
        {
            _logger.LogWarning("Equipment pool with ID: {EquipmentPoolId} not found for update", dto.Id);
            return false;
        }

        _mapper.Map(dto, entity);
        entity.UpdatedBy = _currentUserService.GetUsername();
        entity.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(entity, ct);

        if (result)
        {
            _logger.LogInformation("Equipment pool with ID: {EquipmentPoolId} updated successfully", dto.Id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting equipment pool with ID: {EquipmentPoolId}", id);

        await _equipmentPoolAssignmentDataAccess.DeleteByEquipmentPoolIdAsync(id);

        var result = await _dataAccess.DeleteAsync(id, ct);

        if (result)
        {
            _logger.LogInformation("Equipment pool with ID: {EquipmentPoolId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("Equipment pool with ID: {EquipmentPoolId} not found for deletion", id);
        }

        return result;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreateEquipmentPoolDto> dtos, CancellationToken ct = default)
    {
        await ValidateDuplicateData(dtos, ct);
        var entities = new List<EquipmentPool>();
        foreach (var dto in dtos)
        {
            var equipmentPool = _mapper.Map<EquipmentPool>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            equipmentPool.CreatedBy = username;
            equipmentPool.UpdatedBy = username;
            equipmentPool.CreatedAt = now;
            equipmentPool.UpdatedAt = now;

            entities.Add(equipmentPool);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private async Task ValidateDuplicateData(IEnumerable<CreateEquipmentPoolDto> dtos, CancellationToken ct)
    {
        var duplicateNames = dtos
           .GroupBy(ep => ep.PoolName)
           .Where(g => g.Count() > 1)
           .Select(g => g.Key)
           .ToList();
        if (duplicateNames.Any())
        {
            var duplicates = string.Join(", ", duplicateNames);
            _logger.LogError($"The following pool name(s) already exist: {duplicates}");
            throw new InvalidOperationException($"The following pool name(s) already exist: {duplicates}");
        }
        var namesToCheck = dtos.Select(dto => dto.PoolName).ToList();
        // Check for existing pool names in the database
        var existingNames = await _dataAccess.CheckDuplicates(namesToCheck, ct);
        if (existingNames.Any())
        {
            var duplicates = string.Join(", ", existingNames);
            _logger.LogError($"The following pool name(s) already exist: {duplicates}");
            throw new ArgumentException($"The following pool name(s) already exist: {duplicates}");
        }
    }

    private void ValidateEquipmentPoolData(CreateEquipmentPoolDto dto)
    {
        // Add validation rules based on your requirements
        if (string.IsNullOrWhiteSpace(dto.PoolName))
        {
            _logger.LogError("Pool name is required");
            throw new ArgumentException("Pool name is required", nameof(dto.PoolName));
        }

        // Add other validations as needed
    }

    private void ValidateEquipmentPoolData(UpdateEquipmentPoolDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.Id <= 0)
        {
            _logger.LogError("Id must be greater than zero");
            throw new ArgumentException("Id must be greater than zero", nameof(dto.Id));
        }

        if (string.IsNullOrWhiteSpace(dto.PoolName))
        {
            _logger.LogError("Pool name is required");
            throw new ArgumentException("Pool name is required", nameof(dto.PoolName));
        }

        // Add other validations as needed
    }
}
