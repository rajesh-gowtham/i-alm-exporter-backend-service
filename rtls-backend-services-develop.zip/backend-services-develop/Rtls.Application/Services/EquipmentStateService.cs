﻿using System.Collections.Concurrent;
using System.Collections.Immutable;
using Rtls.Application.Models;

namespace Rtls.Application.Services;

public sealed class EquipmentStateService
{
    private ConcurrentDictionary<long, EquipmentState> States { get; } = new();

    public ImmutableArray<EquipmentState> GetAll() => [.. States.Values];
    
    public EquipmentState? GetEquipmentState(long equipmentId) => States.GetValueOrDefault(equipmentId);
    
    public void SetEquipmentState(EquipmentState state)
    {
        States.AddOrUpdate(state.EquipmentId, state, (key, oldState) => state);
    }
}