using AutoMapper;
using Microsoft.Extensions.Logging;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Application.Services;

public class PowAssignmentService : IPowAssignmentService
{
    private readonly IPowAssignmentDataAccess _dataAccess;
    private readonly ICurrentUserService _currentUserService;
    private readonly ILogger<PowAssignmentService> _logger;
    private readonly IMapper _mapper;

    public PowAssignmentService(
        ICurrentUserService currentUserService,
        ILogger<PowAssignmentService> logger,
        IMapper mapper,
        IPowAssignmentDataAccess dataAccess)
    {
        _currentUserService = currentUserService ?? throw new ArgumentNullException(nameof(currentUserService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _dataAccess = dataAccess ?? throw new ArgumentNullException(nameof(dataAccess));
    }

    public async Task<PagedResponse<PowAssignmentDto>> GetAllAsync(int skip = 0, int? take = null, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting all POW assignments");

        var pagedEntities = await _dataAccess.GetAllAsync(skip, take, ct);

        if (pagedEntities.TotalCount == 0) return PagedResponse<PowAssignmentDto>.Empty;

        var dtos = _mapper.Map<PowAssignmentDto[]>(pagedEntities.Items);
        return new PagedResponse<PowAssignmentDto>(pagedEntities.TotalCount, dtos);
    }

    public async Task<PowAssignmentDto?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Getting POW assignment with ID: {PowAssignmentId}", id);
        var entity = await _dataAccess.GetByIdAsync(id, ct);

        if (entity == null)
        {
            _logger.LogWarning("POW assignment with ID: {PowAssignmentId} not found", id);
            return null;
        }

        return _mapper.Map<PowAssignmentDto>(entity);
    }

    public async Task<PowAssignmentDto> CreateAsync(CreatePowAssignmentDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidatePowAssignmentData(dto);

        _logger.LogInformation("Creating new POW assignment for PowId: {PowId} and EquipmentPoolId: {EquipmentPoolId}", dto.PowId, dto.EquipmentPoolId);

        var entity = _mapper.Map<PowAssignment>(dto);
        var username = _currentUserService.GetUsername();
        var now = DateTime.UtcNow;

        entity.CreatedBy = username;
        entity.UpdatedBy = username; // Assuming UpdatedBy and UpdatedAt are also set on creation
        entity.CreatedAt = now;
        entity.UpdatedAt = now;

        var createdEntity = await _dataAccess.CreateAsync(entity, ct);

        _logger.LogInformation("POW assignment created successfully with ID: {PowAssignmentId}", createdEntity.Id);
        return _mapper.Map<PowAssignmentDto>(createdEntity);
    }

    public async Task<bool> UpdateAsync(UpdatePowAssignmentDto dto, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(dto, nameof(dto));
        ValidatePowAssignmentData(dto);

        _logger.LogInformation("Updating POW assignment with ID: {PowAssignmentId}", dto.Id);

        var existing = await _dataAccess.GetByIdAsync(dto.Id, ct);
        if (existing is null)
        {
            _logger.LogWarning("POW assignment with ID: {PowAssignmentId} not found for update", dto.Id);
            return false;
        }

        _mapper.Map(dto, existing);
        existing.UpdatedBy = _currentUserService.GetUsername();
        existing.UpdatedAt = DateTime.UtcNow;

        var result = await _dataAccess.UpdateAsync(existing, ct);

        if (result)
        {
            _logger.LogInformation("POW assignment with ID: {PowAssignmentId} updated successfully", dto.Id);
        }

        return result;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting POW assignment with ID: {PowAssignmentId}", id);

        var result = await _dataAccess.DeleteAsync(id, ct);

        if (result)
        {
            _logger.LogInformation("POW assignment with ID: {PowAssignmentId} deleted successfully", id);
        }
        else
        {
            _logger.LogWarning("POW assignment with ID: {PowAssignmentId} not found for deletion", id);
        }

        return result;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<CreatePowAssignmentDto> dtos, CancellationToken ct = default)
    {
        var entities = new List<PowAssignment>();
        foreach (var dto in dtos)
        {
            var entity = _mapper.Map<PowAssignment>(dto);
            var username = _currentUserService.GetUsername();
            var now = DateTime.UtcNow;

            entity.CreatedBy = username;
            entity.UpdatedBy = username;
            entity.CreatedAt = now;
            entity.UpdatedAt = now;

            entities.Add(entity);
        }

        return await _dataAccess.CreateBatchAsync(entities, ct);
    }

    private void ValidatePowAssignmentData(CreatePowAssignmentDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.PowId <= 0)
        {
            _logger.LogError("PowId must be greater than zero");
            throw new ArgumentException("PowId must be greater than zero", nameof(dto.PowId));
        }

        if (dto.EquipmentPoolId <= 0)
        {
            _logger.LogError("EquipmentPoolId must be greater than zero");
            throw new ArgumentException("EquipmentPoolId must be greater than zero", nameof(dto.EquipmentPoolId));
        }

        // Add other validations as needed
    }

    private void ValidatePowAssignmentData(UpdatePowAssignmentDto dto)
    {
        // Add validation rules based on your requirements
        if (dto.Id <= 0)
        {
            _logger.LogError("Id must be greater than zero");
            throw new ArgumentException("Id must be greater than zero", nameof(dto.Id));
        }

        if (dto.PowId <= 0)
        {
            _logger.LogError("PowId must be greater than zero");
            throw new ArgumentException("PowId must be greater than zero", nameof(dto.PowId));
        }

        if (dto.EquipmentPoolId <= 0)
        {
            _logger.LogError("EquipmentPoolId must be greater than zero");
            throw new ArgumentException("EquipmentPoolId must be greater than zero", nameof(dto.EquipmentPoolId));
        }

        // Add other validations as needed
    }
}
