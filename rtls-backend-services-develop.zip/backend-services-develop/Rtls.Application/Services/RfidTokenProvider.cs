namespace Rtls.Application.Services;

public sealed class RfidTokenProvider
{

    private string? _accessToken;

    public string? GetToken() => _accessToken;

    public void SetToken(string token)
    {
        _accessToken = token;
    }
}