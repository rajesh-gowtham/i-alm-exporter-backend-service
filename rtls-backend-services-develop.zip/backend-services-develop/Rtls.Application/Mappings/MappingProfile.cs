﻿using AutoMapper;
using Rtls.Application.Models;
using Rtls.Domain.Entities;

namespace Rtls.Application.Mappings;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Vessel, VesselDto>();
        CreateMap<CreateVesselDto, Vessel>();
        CreateMap<UpdateVesselDto, Vessel>();
        
        CreateMap<Equipment, EquipmentDto>();
        CreateMap<CreateEquipmentDto, Equipment>();
        CreateMap<UpdateEquipmentDto, Equipment>();

        CreateMap<PointOfWork, PointOfWorkDto>();
        CreateMap<CreatePointOfWorkDto, PointOfWork>();
        CreateMap<UpdatePointOfWorkDto, PointOfWork>();

        CreateMap<EquipmentPoolAssignment, EquipmentPoolAssignmentDto>();
        CreateMap<CreateEquipmentPoolAssignmentDto, EquipmentPoolAssignment>();
        CreateMap<UpdateEquipmentPoolAssignmentDto, EquipmentPoolAssignment>();

        CreateMap<EquipmentPool, EquipmentPoolDto>();
        CreateMap<CreateEquipmentPoolDto, EquipmentPool>();
        CreateMap<UpdateEquipmentPoolDto, EquipmentPool>();

        CreateMap<PowAssignment, PowAssignmentDto>();
        CreateMap<CreatePowAssignmentDto, PowAssignment>();
        CreateMap<UpdatePowAssignmentDto, PowAssignment>();

        CreateMap<VesselBerthing, VesselBerthingDto>();
        CreateMap<CreateVesselBerthingDto, VesselBerthing>();
        CreateMap<UpdateVesselBerthingDto, VesselBerthing>();

        CreateMap<VesselVisit, VesselVisitDto>();
        CreateMap<CreateVesselVisitDto, VesselVisit>();
        CreateMap<UpdateVesselVisitDto, VesselVisit>();

        CreateMap<WorkInstruction, WorkInstructionDto>();
        CreateMap<CreateWorkInstructionDto, WorkInstruction>();
        CreateMap<UpdateWorkInstructionDto, WorkInstruction>();

        CreateMap<InventoryContainerDto, WorkInstruction>();
        CreateMap<InventoryVesselVisitDto, WorkInstruction>();

        CreateMap<CreateRfidAssetDto, RfidAsset>();
        CreateMap<RfidAsset, RfidAssetDto>();

        CreateMap<TelematicsDto, Telematics>();
        CreateMap<Telematics, TelematicsDto>();

        CreateMap<CreateTelematicsDto, Telematics>();
        CreateMap<UpdateTelematicsDto, Telematics>();

        CreateMap<CreateRfidAssetDto, RfidAsset>();
        CreateMap<UpdateRfidAssetDto, RfidAsset>();

        CreateMap<LevelTemplateValueDto, RfidLevelTemplateValues>();
        CreateMap<LevelTemplateDto, RfidLevelTemplate>();
    }
}