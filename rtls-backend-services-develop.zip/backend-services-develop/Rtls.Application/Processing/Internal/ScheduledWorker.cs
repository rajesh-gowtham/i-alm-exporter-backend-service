namespace Rtls.Application.Processing.Internal;

public class ScheduledWorker : IDisposable
{
    private readonly TimeSpan _interval;
    private readonly TimeSpan _delay;
    private readonly Action _action;
    private Timer? _timer;

    public ScheduledWorker(Action action, TimeSpan interval, TimeSpan? delay = null)
    {
        _action = action;
        _interval = interval;
        _delay = delay ?? TimeSpan.Zero;
    }

    public void Start()
    {
        if (_timer != null) return;
        _timer = new Timer(
            (state => _action()), null, _delay, _interval
        );
    }

    public static ScheduledWorker Start(Action action, TimeSpan interval, TimeSpan? delay = null)
    {
        var worker = new ScheduledWorker(action, interval, delay);
        worker.Start();
        return worker;
    }

    public void Dispose() => _timer?.Dispose();
}