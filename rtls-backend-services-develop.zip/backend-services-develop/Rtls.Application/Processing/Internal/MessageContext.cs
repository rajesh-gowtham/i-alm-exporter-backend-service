﻿namespace Rtls.Application.Processing.Internal;

public record MessageContext<T>(string Key, T Payload, Func<Task>? AckCallback = null);