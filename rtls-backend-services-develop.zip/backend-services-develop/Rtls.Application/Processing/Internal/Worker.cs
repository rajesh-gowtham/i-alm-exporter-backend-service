using System.Threading.Channels;
using Microsoft.Extensions.Logging;

namespace Rtls.Application.Processing.Internal;

public class WorkerOptions
{
    public WorkerOptions(int capacity,
        TimeSpan readTimeout,
        TimeSpan handleTimeout,
        bool isLongRunning = false, string? workerName = null)
    {
        WorkerName = workerName;
        Capacity = capacity;

        if (readTimeout < Timeout.InfiniteTimeSpan) throw new ArgumentOutOfRangeException(nameof(readTimeout));
        if (handleTimeout < Timeout.InfiniteTimeSpan) throw new ArgumentOutOfRangeException(nameof(handleTimeout));

        ReadTimeout = readTimeout;
        IsLongRunning = isLongRunning;
    }

    public string? WorkerName { get; }

    /// <summary>
    ///  If capacity set to 1, worker will process only 1 
    /// </summary>
    public int Capacity { get; }

    /// <summary>
    /// How long to wait before stopping the worker
    /// </summary>
    public TimeSpan ReadTimeout { get; }

    /// <summary>
    /// How long to wait before cancelling handler
    /// </summary>
    public TimeSpan HandleTimeout { get; }

    public bool IsLongRunning { get; }
}

public class Worker<T> : IDisposable
{
    private readonly ILogger<Worker<T>> _logger;
    private readonly WorkerOptions _options;

    private readonly Channel<T> _channel;

    // used only in case of IsLongRunning is set to true
    private Task? _task;
    private CancellationTokenSource? _cts;
    private volatile bool _isRunning;

    public event Action<Exception> OnException;

    public bool IsRunning => _isRunning;

    protected Worker(ILogger<Worker<T>> logger, WorkerOptions options)
    {
        _logger = logger;
        _options = options;
        _channel = Channel.CreateBounded<T>(new BoundedChannelOptions(_options.Capacity)
        {
            SingleWriter = true, SingleReader = true, FullMode = BoundedChannelFullMode.Wait,
        });
    }

    protected bool PutWorkItem(
        T item,
        Func<T, CancellationToken, Task>? handler = null,
        CancellationToken cancellationToken = default)
    {
        var canWrite = _channel.Writer.TryWrite(item);
        if (canWrite && !_isRunning) _isRunning = StartBackgroundWorker(handler ?? HandleWorkItem);
        return canWrite;
    }

    private bool StartBackgroundWorker(Func<T, CancellationToken, Task> handler)
    {
        _cts = new CancellationTokenSource();

        if (_options.IsLongRunning)
        {
            _task = Task.Factory.StartNew(
                (state) => ((Worker<T>)state!).Run(handler, _cts.Token).ConfigureAwait(false),
                this, _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
            // _task = Task.Factory.StartNew(
            //     () => Run(handler, _cts.Token), _cts.Token, TaskCreationOptions.LongRunning,
            //     TaskScheduler.Default);
            return true;
        }
        
        _task = Run(handler, _cts.Token);
        return true;
        // return ThreadPool.QueueUserWorkItem(
        //     (state) => ((Worker<T>)state!).Run(handler, _cts.Token).ConfigureAwait(false),
        //     this);
    }

    private async Task Run(Func<T, CancellationToken, Task> handler, CancellationToken ct = default)
    {
        var stoppingToken = _cts?.Token ?? CancellationToken.None;
        var readCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken, ct);
        readCts.CancelAfter(_options.ReadTimeout);
        try
        {
            await foreach (var ctx in _channel.Reader.ReadAllAsync(readCts.Token))
            {
                try
                {
                    await handler(ctx, readCts.Token);
                }
                catch (Exception e)
                {
                    TriggerOnException(e);
                    break;
                }

                if (readCts.TryReset()) readCts.CancelAfter(_options.ReadTimeout);
            }
        }
        catch (OperationCanceledException)
        {
            // ignore
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            TriggerOnException(ex);
        }
        finally
        {
            _isRunning = false;
            readCts.Dispose();
        }
    }

    protected virtual Task HandleWorkItem(T item, CancellationToken cancellationToken = default)
    {
        return Task.CompletedTask;
    }

    public async Task Stop(CancellationToken cancellationToken)
    {
        _isRunning = false;
        try
        {
            // Signal cancellation to the executing method
            await _cts!.CancelAsync();
        }
        finally
        {
            // Wait until the task completes or the stop token triggers
            var tcs = new TaskCompletionSource<object>();
            await using var registration = cancellationToken
                .Register(s => ((TaskCompletionSource<object>)s!).SetCanceled(), tcs);
            // Do not await the _executeTask because cancelling it will throw an OperationCanceledException which we are explicitly ignoring
            await Task.WhenAny(_task, tcs.Task).ConfigureAwait(false);
        }
    }

    public void Dispose()
    {
        _cts?.Cancel();
        OnDispose();
    }

    protected virtual void OnDispose()
    {
    }

    protected virtual void TriggerOnException(Exception exception)
    {
        OnException?.Invoke(exception);
    }
}