namespace Rtls.Application.Processing.Internal;

/// <summary>
/// Represents a void type, since <see cref="System.Void"/> is not a valid return type in C#.
/// </summary>
public readonly record struct Unit
{
    private static readonly Unit _value;

    public static ref readonly Unit Value => ref _value;
    
    public static Task<Unit> Task { get; } = System.Threading.Tasks.Task.FromResult(_value);
    
    public override int GetHashCode() => 0;
    
    public bool Equals(Unit other) => true;
}