
namespace Rtls.Application.Processing.Internal;

public interface IHandler
{
}

public interface IHandler<TIn, TOut> : IHandler
{
    Task<TOut?> Handle(MessageContext<TIn> context, CancellationToken cancellationToken);
}

public interface IHandler<TIn> : IHandler<TIn, Unit> { }