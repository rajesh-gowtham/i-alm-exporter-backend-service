﻿using Microsoft.Extensions.Logging;
using Npgsql;
using Rtls.Application.Processing.Internal;
using Rtls.Domain.Database;
using Rtls.Domain.Helpers;
using Rtls.Domain.Models;

namespace Rtls.Application.Processing.Handlers;

// public sealed class InsertMessageHandler : Worker<DeviceMessage>, IHandler<DeviceMessage, bool>
public sealed class InsertMessageHandler : IHandler<DeviceMessage, bool>
{
    private readonly NpgsqlDataSource _dataSource;

    private static readonly WorkerOptions WorkerOptions = new(10,
        TimeSpan.FromSeconds(60),
        TimeSpan.FromSeconds(30),
        false, nameof(InsertMessageHandler));

    // public InsertMessageHandler(ILogger<Worker<DeviceMessage>> logger, ITimescaleDb timescaleDb, GeoZonesStore geoZonesStore)
    //     : base(logger, WorkerOptions)
    // {
    //     _dataSource = timescaleDb.GetDataSource();
    //     _geoZonesStore = geoZonesStore;
    // }
    public InsertMessageHandler(ILogger<InsertMessageHandler> logger, ITelemetryDb telemetryDb )
    {
        _dataSource = telemetryDb.GetDataSource();
    }

    public async Task<bool> Handle(MessageContext<DeviceMessage> context, CancellationToken ct)
    {
        var deviceMessage = context.Payload;
        try
        {
            // var zones = await _geoZonesStore.GetAllAsync(ct);
            // foreach (var (id, zone) in zones)
            // {
            //     if (deviceMessage.Location.Within(zone.Polygon))
            //         deviceMessage.Zones.Add(id);
            // }
            
            await _dataSource.InsertDeviceMessage(deviceMessage, cancellationToken: ct);
        }
        catch (Exception e)
        {
            throw new Exception($"Failed to insert device message: {e.Message}", e);
        }
        
        return true;
        // await Task.CompletedTask;
        // return PutWorkItem(context.Payload, cancellationToken: ct);
    }

    // protected override async Task HandleWorkItem(DeviceMessage item, CancellationToken cancellationToken = default)
    // {
    //     try
    //     {
    //         var zones = await _geoZonesStore.GetAllAsync(cancellationToken);
    //         foreach (var (id, zone) in zones)
    //         {
    //             if (item.Location.Within(zone.Polygon))
    //                 item.Zones.Add(id);
    //         }
    //         
    //         await _dataSource.InsertDeviceMessage(item, cancellationToken: cancellationToken);
    //     }
    //     catch (Exception e)
    //     {
    //         throw new Exception($"Failed to insert device message: {e.Message}", e);
    //     }
    // }
}