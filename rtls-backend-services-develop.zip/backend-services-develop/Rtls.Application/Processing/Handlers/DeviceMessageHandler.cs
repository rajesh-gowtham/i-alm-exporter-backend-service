using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using Rtls.Application.Processing.Internal;
using Rtls.Domain.Models;

namespace Rtls.Application.Processing.Handlers;

public sealed class DeviceMessageHandler : Worker<MessageContext<DeviceMessage>>, IHandler<DeviceMessage, bool>
{
    private readonly ILogger<DeviceMessageHandler> _logger;

    // handlers
    private readonly InsertMessageHandler _insertMessageHandler;
    private readonly StateHandler _stateHandler;

    /// <summary>
    /// Will retry to put a work item into the queue (channel).
    /// Default is set to 15 retries with 2 seconds delay each (total 30 seconds).
    /// </summary>
    private readonly ResiliencePipeline<bool> _resiliencePipeline;
    
    private static readonly WorkerOptions WorkerOptions = new(10,
        TimeSpan.FromSeconds(60),
        TimeSpan.FromSeconds(30),
        false, nameof(DeviceMessageHandler));

    public DeviceMessageHandler(ILogger<DeviceMessageHandler> logger,
        InsertMessageHandler insertMessageHandler,
        StateHandler stateHandler,
        ViolationsHandler violationsHandler) : base(logger, WorkerOptions)
    {
        _logger = logger;
        _insertMessageHandler = insertMessageHandler;
        _stateHandler = stateHandler;

        // _insertMessageHandler.OnException += HandleOnException;
        
        _resiliencePipeline = new ResiliencePipelineBuilder<bool>()
            .AddRetry(new RetryStrategyOptions<bool>
            {
                ShouldHandle = new PredicateBuilder<bool>()
                    .HandleResult(r => !r),
                MaxRetryAttempts = 15,
                UseJitter = true,
                BackoffType = DelayBackoffType.Constant,
                Delay = TimeSpan.FromSeconds(2)
            })
            .Build();
    }

    private void HandleOnException(Exception exception)
    {
        _logger.LogError(exception, "Exception occured");
    }
    
    public bool HandleSync(MessageContext<DeviceMessage> context, CancellationToken cancellationToken)
    {
        var retries = 0;
        while (!PutWorkItem(context, cancellationToken: cancellationToken))
        {
            if (cancellationToken.IsCancellationRequested) return false;
            // wait for 15 sec
            if (++retries >= 10 * 15) return false;
            Thread.Sleep(100);
        }

        return true;
    }

    public async Task<bool> Handle(MessageContext<DeviceMessage> context, CancellationToken cancellationToken)
    {
        await Task.CompletedTask;
        return _resiliencePipeline.Execute(
            (x, ct) => x.PutWorkItem(context, cancellationToken: cancellationToken),
            this, cancellationToken);
    }

    protected override async Task HandleWorkItem(MessageContext<DeviceMessage> item,
        CancellationToken cancellationToken = default)
    {
        // insert into db
        await _insertMessageHandler.Handle(item, cancellationToken);
        var state = await _stateHandler.Handle(item, cancellationToken);
        if (state == null) return;
        var stateCtx = new MessageContext<DeviceState>(item.Key, state);
        // await _violationsHandler.Handle(new MessageContext<DeviceState>(item.Key, state), cancellationToken);
    }
}