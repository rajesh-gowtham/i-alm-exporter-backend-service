using Rtls.Application.Processing.Internal;

namespace Rtls.Application.Processing.Handlers;

public class ViolationsHandler : IHandler<DeviceState, bool>
{
    public Task<bool> Handle(MessageContext<DeviceState> context, CancellationToken cancellationToken)
    {
        return Task.FromResult(true);
    }
}