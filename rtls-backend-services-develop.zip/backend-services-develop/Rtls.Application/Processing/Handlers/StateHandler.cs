using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Logging;
using Rtls.Application.Processing.Internal;
using Rtls.Domain.Helpers;
using Rtls.Domain.Models;
using StackExchange.Redis;

namespace Rtls.Application.Processing.Handlers;

public class StateHandler(ILogger<StateHandler> logger, IDatabase redisDatabase, VehicleStore vehicleStore)
    : IHandler<DeviceMessage, DeviceState>
{
    private Vehicle? _vehicle;
    private DeviceState? _deviceState;

    public async Task<DeviceState?> Handle(MessageContext<DeviceMessage> input, CancellationToken ct)
    {
        var deviceMessage = input.Payload;

        // get vehicle
        if (_vehicle == null)
        {
            var vehicle = await vehicleStore.GetVehicleByDevice(deviceMessage.DeviceId);
            if (vehicle == null)
            {
                logger.LogDebug($"No vehicle found for device {deviceMessage.DeviceId}");
                return null;
            }

            _vehicle = vehicle;
        }

        // check if state exists
        DeviceState? deviceState;
        if (_deviceState == null)
        {
            var redisStateValue = await redisDatabase.StringGetAsync($"states:{_vehicle.Id}");
            if (redisStateValue.HasValue)
            {
                deviceState = JsonSerializer.Deserialize<DeviceState>(redisStateValue.ToString());
                if (deviceState == null)
                {
                    // warning
                    logger.LogDebug($"No state found for device {deviceMessage.DeviceId}");
                    return null;
                }
            }
            else
            {
                // create first state
                deviceState = DeviceState.FromMessage(deviceMessage);
                deviceState.VehicleId = _vehicle.Id;
                // save to Redis
                await redisDatabase.StringSetAsync($"states:{_vehicle.Id}",
                    JsonSerializer.Serialize(deviceState),
                    flags: CommandFlags.FireAndForget);
                // store in-mem
                _deviceState = deviceState;
                return deviceState;
            }
        }
        else
        {
            deviceState = _deviceState;
        }

        // update vehicle id
        if (deviceState!.VehicleId != _vehicle.Id)
        {
            // logger.LogDebug($"Vehicle {_vehicle.Id} does not match state {deviceState}");
            // deviceState = deviceState with { VehicleId = vehicle.Id };
            deviceState.VehicleId = _vehicle.Id;
        }

        // state
        var prev = deviceState.State;
        var next = deviceMessage;

        // validate
        if (prev.GpsTime >= next.GpsTime)
            return deviceState;
        
        // update parameters
        var parameters = prev.Parameters.Merge(next.Parameters);

        // update state
        var isValidCoordinates = next.Latitude != 0 && next.Longitude != 0;
        var latest = prev with
        {
            Heading = next.Heading,
            Altitude = next.Altitude,
            Latitude = isValidCoordinates ? next.Latitude : prev.Latitude,
            Longitude = isValidCoordinates ? next.Longitude : prev.Longitude,
            GpsTime = next.GpsTime,
            ReceiveTime = next.ReceiveTime,
            Parameters = parameters,
            Zones = [..next.Zones]
        };

        deviceState.Update(latest);

        // save to redis
        await redisDatabase.StringSetAsync($"states:{_vehicle.Id}",
            JsonSerializer.Serialize(deviceState),
            flags: CommandFlags.FireAndForget);

        // store in-mem
        _deviceState = deviceState;

        return deviceState;
    }
}

public class Vehicle
{
    public Guid Id { get; set; }
}

public class VehicleStore
{
    public async Task<Vehicle?> GetVehicleByDevice(string deviceMessageDeviceId)
    {
        throw new NotImplementedException();
    }
}

public sealed class DeviceState
{
    public Guid VehicleId { get; set; }
    public DeviceMessage State { get; set; }

    /// <summary>
    /// Backing field for Prev property
    /// </summary>
    [JsonIgnore]
    private DeviceMessage? _previous;

    [JsonIgnore] public DeviceMessage Prev
    {
        get
        {
            return _previous ??= State;
        }
        private set => _previous = value;
    }

    [JsonIgnore] public DeviceMessage Next => State;

    public DeviceState Update(DeviceMessage message)
    {
        Prev = State;
        State = message;
        return this;
    }

    public static DeviceState FromMessage(DeviceMessage message) =>
        new()
        {
            State = message,
            Prev = message
        };
}