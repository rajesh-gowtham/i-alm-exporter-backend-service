using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Rtls.Application.Processing.Handlers;
using Rtls.Application.Processing.Internal;
using Rtls.Domain.Models;

namespace Rtls.Application.Processing;

[SuppressMessage("Performance", "CA1848:Use the LoggerMessage delegates")]
public class MessageRouter : IDisposable
{
    private readonly ILogger<MessageRouter> _logger;
    private readonly IServiceScopeFactory _serviceScopeFactory;
    // private readonly Func<DeviceMessageHandler> _handlerFactory;
    private readonly ConcurrentDictionary<string, ScopedHandler<DeviceMessageHandler>> _handlers = new();
    private ScheduledWorker? _cleanupWorker;
    private volatile bool _isRunning;
    private volatile bool _isDisposing;

    // public MessageRouter(ILogger<MessageRouter> logger, IServiceScopeFactory serviceScopeFactory, Func<DeviceMessageHandler> handlerFactory)
    public MessageRouter(ILogger<MessageRouter> logger, IServiceScopeFactory serviceScopeFactory)
    {
        _logger = logger;
        _serviceScopeFactory = serviceScopeFactory;
        // _handlerFactory = handlerFactory;
    }

    public bool Route(MessageContext<DeviceMessage> context, CancellationToken cancellationToken = default)
    {
        var scopedHandler = OnUpdate(context, cancellationToken);
        var handler = scopedHandler.Instance;
        return handler.HandleSync(context, cancellationToken);
        // await handler.Handle(context, cancellationToken);
    }

    public async Task<bool> RouteAsync(MessageContext<DeviceMessage> context,
        CancellationToken cancellationToken = default)
    {
        var scopedHandler = OnUpdate(context, cancellationToken);
        var handler = scopedHandler.Instance;

        var result = await handler.Handle(context, cancellationToken);

        if (result && context.AckCallback != null)
        {
            await context.AckCallback.Invoke();
        }
        
        return result;
    }

    private ScopedHandler<DeviceMessageHandler> OnUpdate(MessageContext<DeviceMessage> context, CancellationToken cancellationToken)
    {
        if (!_handlers.TryGetValue(context.Key, out var scopedHandler))
        {
            // create handler
            _logger.LogDebug("Creating handler for key {Key}", context.Key);

            var scope = _serviceScopeFactory.CreateScope();
            var underlyingHandler = scope.ServiceProvider.GetRequiredService<DeviceMessageHandler>();
            underlyingHandler.OnException += HandlerOnOnException;
            scopedHandler = new ScopedHandler<DeviceMessageHandler>(scope, underlyingHandler);

            // handler = _handlerFactory();
            // handler.OnException += HandlerOnOnException;
            _handlers.TryAdd(context.Key, scopedHandler);
        }

        if (!_isRunning)
        {
            // run cleanup worker to remove stopped handlers
            _cleanupWorker = ScheduledWorker.Start(Cleanup, TimeSpan.FromSeconds(60), TimeSpan.FromSeconds(30));
            _isRunning = true;
        }

        return scopedHandler;
    }

    private void HandlerOnOnException(Exception exception)
    {
        if (exception is OperationCanceledException canceledException) {}
        else if (exception is TaskCanceledException taskCanceledException) {}
        else _logger.LogError(exception, "Exception occured");
    }

    private void Cleanup()
    {
        _logger.LogDebug($"Running cleanup worker");
        _logger.LogDebug($"Total number of handlers: {_handlers.Count}");
        _logger.LogDebug($"Number of threads: {ThreadPool.ThreadCount}");

        foreach (var (key, scopedHandler) in _handlers)
        {
            if (scopedHandler.Instance.IsRunning) continue;
            _handlers.TryRemove(key, out _);
            _ = scopedHandler.Instance.Stop(CancellationToken.None).ConfigureAwait(false);
        }

        _logger.LogDebug($"Cleanup finished");
    }

    public async Task Stop(CancellationToken cancellationToken = default)
    {
        if (!_isRunning) return;
        _logger.LogDebug($"Stopping message router");
        _cleanupWorker?.Dispose();
        _cleanupWorker = null;

        // dispose handlers
        foreach (var (key, scopedHandler) in _handlers)
        {
            if (!scopedHandler.Instance.IsRunning)
            {
                _logger.LogDebug($"Handler {key} already stopped");
                continue;
            }
            _ = scopedHandler.Instance.Stop(cancellationToken).ConfigureAwait(false);
            scopedHandler.Instance.OnException -= HandlerOnOnException;
            scopedHandler.Dispose();
            _logger.LogDebug($"Handler {key} stopped");
        }

        _logger.LogDebug("All handlers disposed");

        // cleanup
        _handlers.Clear();
        _isRunning = false;
        _logger.LogDebug($"Stopped message router");
        await Task.CompletedTask;
    }

    public void Dispose()
    {
        if (_isDisposing) return;
        _isDisposing = true;
        _logger.LogDebug("Disposing started");
        // Stop().Wait();
        _logger.LogDebug("Disposing finished");
    }
}