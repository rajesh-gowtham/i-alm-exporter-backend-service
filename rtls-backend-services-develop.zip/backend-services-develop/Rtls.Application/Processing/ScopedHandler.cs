﻿using Microsoft.Extensions.DependencyInjection;
using Rtls.Application.Processing.Internal;

namespace Rtls.Application.Processing;

public class ScopedHandler<T> : IHandler, IDisposable where T : IHandler
{
    private readonly IServiceScope _scope;

    public T Instance { get; }
    
    public ScopedHandler(IServiceScope scope, T handler)
    {
        _scope = scope;
        Instance = handler;
    }

    public void Dispose()
    {
        _scope.Dispose();
    }
}