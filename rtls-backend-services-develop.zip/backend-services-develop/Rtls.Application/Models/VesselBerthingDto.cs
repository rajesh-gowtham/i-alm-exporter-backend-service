using Rtls.Domain.Entities;

namespace Rtls.Application.Models;

public sealed record VesselBerthingDto(
    long Id,
    string Quay,
    BerthingSide BerthingSide,
    DateTime? BerthEta,
    DateTime? BerthEtd,
    DateTime? BerthAta,
    DateTime? StartWorkTime,
    long VesselVisitId,
    string? StartBollard,
    string? EndBollard,
    string? CreatedBy,
    string? UpdatedBy,
    DateTime? CreatedAt,
    DateTime? UpdatedAt
);

public sealed record CreateVesselBerthingDto(
    string Quay,
    BerthingSide BerthingSide,
    DateTime? BerthEta, // Apply custom converter
    DateTime? BerthEtd,
    DateTime? BerthAta,
    DateTime? StartWorkTime,
    long VesselVisitId,
    string? StartBollard,
    string? EndBollard
);

public sealed record UpdateVesselBerthingDto(
    string Quay,
    BerthingSide BerthingSide,
    DateTime? BerthEta,
    DateTime? BerthEtd,
    DateTime? BerthAta,
    DateTime? StartWorkTime,
    long VesselVisitId,
    string? StartBollard,
    string? EndBollard
);
