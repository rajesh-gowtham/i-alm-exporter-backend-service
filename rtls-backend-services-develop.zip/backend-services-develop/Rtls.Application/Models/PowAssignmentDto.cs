namespace Rtls.Application.Models
{
    public sealed record PowAssignmentDto(
        long Id,
        long PowId,
        long EquipmentPoolId,
        bool? EquipmentPoolStatus,
        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt
    );

    public sealed record CreatePowAssignmentDto(
        long PowId,
        long EquipmentPoolId,
        bool? EquipmentPoolStatus,
        string? CreatedBy,
        DateTime? CreatedAt
    );

    public sealed record UpdatePowAssignmentDto(
        long Id,
        long PowId,
        long EquipmentPoolId,
        bool? EquipmentPoolStatus,
        string? UpdatedBy,
        DateTime? UpdatedAt
    );
}