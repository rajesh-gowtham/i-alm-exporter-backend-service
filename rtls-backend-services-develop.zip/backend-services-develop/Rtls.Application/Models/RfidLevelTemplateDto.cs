using Newtonsoft.Json;

namespace Rtls.Application.Models;

public class LevelTemplateValueDto
{
    [JsonProperty("LtV_ID")]
    public long LtVID { get; set; }
    [JsonProperty("LT_ID")]
    public long LTID { get; set; }
    [JsonProperty("LT_Value")]
    public string LTValue { get; set; } = default!;
    [JsonProperty("LtV_Parent_ID")]
    public long? LtVParentID { get; set; }
    [JsonProperty("LtV_Description")]
    public string LtVDescription { get; set; } = default!;
    public long? ChildCount { get; set; }
    public string UserId { get; set; } = default!;
}

public class LevelTemplateSuccessResponseDto
{
    public string ResponseCode { get; set; } = default!;
    public string ResponseMessage { get; set; } = default!;
}

public class LevelTemplateDto
{
    [JsonProperty("LT_ID")]
    public long LTID { get; set; }
    [JsonProperty("LT_Name")]
    public string LTName { get; set; } = default!;
    [JsonProperty("LT_Parent_ID")]
    public long? LTParentID { get; set; }
    public long ChildCount { get; set; } = default!;
    public string UserId { get; set; } = default!;
}