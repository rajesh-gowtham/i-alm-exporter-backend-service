using Rtls.Domain.Models;

namespace Rtls.Application.Models;

public class WaterSideDashboardDto
{
    public int VesselOnBerth { get; set; }
    public int ActiveQc { get; set; }
    public int TotalJobs { get; set; }
    public int AssignedItvs { get; set; }
    public long Alerts { get; set; }
    public List<VesselInfoDto> VesselInfo { get; set; } = new();
    public JobInfosDto JobInfos { get; set; } = new();
    public PagedResponse<Object> QcDetails { get; set; }
    public DateTime? LastUpdatedUtc { get; set; }
}

public class VesselInfoDto
{
    public string VesselName { get; set; } = null!;
    public long VesselId { get; set; }
    public List<QcDto> Qcs { get; set; } = new();
}

public class QcDto
{
    public string Asset { get; set; } = null!;
    public string Type { get; set; } = null!;
    public int ActiveJobs { get; set; }
    public int CompletedJobs { get; set; }
}

public class JobInfosDto
{
    public int MovesCompleted { get; set; }
    public int MovesPending { get; set; }
}

public class QcDetailDto
{
    public string Asset { get; set; } = null!;
    public string? Make { get; set; }
    public string Berth { get; set; } = null!;
    public DateTime? GpsTime { get; set; }
    public int MovesPending { get; set; }
    public int MovesCompleted { get; set; }
    public string Ignition { get; set; } = string.Empty;
}

public class WaterSideRequestDto
{
    public string CardName { get; set; } = string.Empty;
    public int Skip { get; set; }
    public int Take { get; set; }
    public List<VesselDetailsDto> VesselDetails { get; set; } = new();
}

public class VesselDetailsDto
{
    public string VesselName { get; set; } = string.Empty;
    public long VesselId { get; set; }
}

public class WaterSideResponseDto
{
    public string CardName { get; set; } = string.Empty;
    public int Skip { get; set; }
    public int Take { get; set; }
    // Dynamic list of response items based on the card name
    public new PagedResponse<object> Data { get; set; }
}

public class ActiveQcDto
{
    public string Asset { get; set; } = string.Empty;
    public string? Make { get; set; }
    public DateTime? GpsTime { get; set; }
    public string Berth { get; set; } = string.Empty;
    public string Activity { get; set; } = string.Empty;
    public string Job { get; set; } = string.Empty;
    public int MovesCompleted { get; set; }
    public int MovesPending { get; set; }
    public string Active { get; set; } = string.Empty;
    public string Ignition { get; set; } = string.Empty;
}

public class TotalJobDto
{
    public string Asset { get; set; } = string.Empty;
    public string Berth { get; set; } = string.Empty;
    public string Activity { get; set; } = string.Empty;
    public string Job { get; set; } = string.Empty;
    public DateTime? StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public string Status { get; set; } = string.Empty;
    public string JobSteppingStatus { get; set; } = string.Empty;
    public string AssignedItv { get; set; } = string.Empty;
}
public class AssignedItvDto
{
    public string Asset { get; set; } = string.Empty;
    public string? Make { get; set; }
    public string Berth { get; set; } = string.Empty;
    public DateTime? GpsTime { get; set; }
    public string Activity { get; set; } = string.Empty;
    public string Job { get; set; } = string.Empty;
    public string AssignedItvs { get; set; } = string.Empty;
}