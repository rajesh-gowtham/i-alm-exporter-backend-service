namespace Rtls.Application.Models;

public class AlarmsEventsDto
{
    public long Id { get; set; }
    public string? EventName { get; set; }
    public string? Asset { get; set; }
    public string? Type { get; set; }
    public DateTime? StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public string? VisitRef { get; set; }
    public string? Notes { get; set; }
    public string? WorkQueue { get; set; }
}
