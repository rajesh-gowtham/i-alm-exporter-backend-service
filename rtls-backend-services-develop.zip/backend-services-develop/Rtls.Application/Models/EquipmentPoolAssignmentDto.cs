using Rtls.Domain.Entities;

namespace Rtls.Application.Models
{
    public record EquipmentPoolAssignmentDto
    {
        public long Id { get; init; }
        public long EquipmentPoolId { get; init; }
        public EquipmentPool? EquipmentPool { get; init; }
        public long EquipmentId { get; init; }
        public Equipment? Equipment { get; init; }
        public bool? AssignmentStatus { get; init; }
        public DateTime EquipmentAssignedDate { get; init; }
        public string? CreatedBy { get; init; }
        public string? UpdatedBy { get; init; }
        public DateTime? CreatedAt { get; init; }
        public DateTime? UpdatedAt { get; init; }
    }

    public record CreateEquipmentPoolAssignmentDto
    {
        public long EquipmentPoolId { get; init; }
        public long EquipmentId { get; init; }
     
    }

    public record UpdateEquipmentPoolAssignmentDto
    {
        public long Id { get; init; }
        public long EquipmentPoolId { get; init; }
        public long EquipmentId { get; init; }
    }

    public record EquipmentAssignedAndUnassignedEquipmentDto
    {
        public List<EquipmentPoolAssignmentDto>? AssignedPools { get; set; }
        public List<EquipmentDto>? UnAssignedPools { get; set; }
    }
}