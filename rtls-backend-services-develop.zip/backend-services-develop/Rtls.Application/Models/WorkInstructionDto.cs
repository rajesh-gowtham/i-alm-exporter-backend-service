namespace Rtls.Application.Models
{
    public record WorkInstructionDto(
        long Id,
        long VesselVisitId,
        string MoveType,
        string FromLocation,
        string TargetLocation,
        string IsoCode,
        string AssignedChe,
        string CheCarry,
        string PositionOnCarriage,
        long PointOfWorkId,
        string ContainerId,
        string WorkInstructionStatus,
        string JobSteppingStatus,
        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt,
        long Sequence,
        string Mode,
        string? InboundLocationType,
        string? OutboundLocationType,
        string? OutboundCarrier,
        string Deck,
        string? PairContainer,
        long Weight,
        string AssignedLane,
        VesselVisitDto? VesselVisit
    );

    public record CreateWorkInstructionDto(
        long VesselVisitId,
        string MoveType,
        string FromLocation,
        string TargetLocation,
        string IsoCode,
        string AssignedChe,
        string CheCarry,
        string PositionOnCarriage,
        long PointOfWorkId,
        string ContainerId,
        string WorkInstructionStatus,
        string JobSteppingStatus,
        long Sequence,
        string Mode,
        string InboundLocationType ,
        string OutboundLocationType ,
        string OutboundCarrier,
        string Deck,
        string? PairContainer,
        long Weight,
        string AssignedLane
        );

    public record UpdateWorkInstructionDto(
        long Id,
        long VesselVisitId,
        string MoveType,
        string FromLocation,
        string TargetLocation,
        string IsoCode,
        string AssignedChe,
        string CheCarry,
        string PositionOnCarriage,
        long PointOfWorkId,
        string ContainerId,
        string WorkInstructionStatus,
        string JobSteppingStatus,
        long Sequence,
        string Mode,
        string InboundLocationType ,
        string OutboundLocationType ,
        string OutboundCarrier ,
        string Deck,
        string? PairContainer,
        long Weight,
        string AssignedLane,
        string TaskStatus,
        DateTime? JobStartTime,
        DateTime? DispatchTime,
        DateTime? TimeAtOrigin,
        DateTime? DischargeTime,
        DateTime? TimeFacilityIn,
        DateTime? TimeAtDestination,
        DateTime? JobCompleteTime
    );

    public record AppendWorkInstructionRequest(
        long WorkInstructionId,
        long PowId,
        long WorkQueueId
    );

}