﻿using System.Collections.Immutable;
using System.Text.Json.Serialization;
using NetTopologySuite.Geometries;
using Rtls.Application.Services.Simulation;
using Rtls.Domain;
using Rtls.Domain.Helpers;

namespace Rtls.Application.Models;

/// <summary>
/// Represents the state (latest location, status and telemetry data) of equipment in the RTLS system.
/// </summary>
public sealed class EquipmentState
{
    public long EquipmentId { get; set; }
    public string EquipmentName { get; set; } = null!;
    public string EquipmentType { get; set; } = null!;
    public string Status { get; set; } = Constants.EquipmentStatus.AVAILABLE;
    // Additional message to show for the DEMO only
    public string Message { get; set; }
    
    public DateTime GpsTime { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    
    [JsonIgnore]
    public Point Location
    {
        get => TopologyHelper.CreatePoint(Longitude, Latitude);
        set
        {
            Latitude = value.Y;
            Longitude = value.X;
        }
    }
    
    public short Altitude { get; set; }
    public short Heading { get; set; }
    
    public Dictionary<string, object> Parameters { get; init; } = new();
    
    // indexer to allow use [] notation.
    public object this[string key]
    {
        get => Parameters[key];
        set => Parameters[key] = value;
    }
    
    // additional properties for the demo
    public RouteSegmentType? RouteSegment { get; set; }
    public string? JobStatus { get; set; }
    // temporary for the demo
    public ImmutableArray<JobDetailsDto> JobDetails { get; set; } = ImmutableArray<JobDetailsDto>.Empty;
    public string? RfidMessage { get; set; }
    public string? JobSteppingStatus { get; set; }
}