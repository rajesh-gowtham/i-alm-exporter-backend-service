using Rtls.Domain.Models;
using System;

namespace Rtls.Application.Models;

public class LandSideDashboardDto
{
    public int Asserts { get; set; }
    public int Active { get; set; }
    public int Idling { get; set; }
    public int Stoppage { get; set; }
    public int Alerts { get; set; }
    public int AvgCycleTime { get; set; }
    public ItvDistributionDto ItvDistribution { get; set; } = new();
    public List<ItvActivityDto> ItvActivity { get; set; } = new();
    public EcuStatusDto EcuStatus { get; set; } = new();
    public PagedResponse<Object> AssertDetails { get; set; }
}

public class ItvDistributionDto
{
    public int Idle { get; set; }
    public int MovingToQuay { get; set; }
    public int AtQuay { get; set; }
    public int MovingToYard { get; set; }
    public int AtYard { get; set; }
}

public class ItvActivityDto
{
    public string Itv { get; set; } = null!;
    public double Idling { get; set; }
    public double Active { get; set; }
    public double Stoppage { get; set; }
}

public class EcuStatusDto
{
    public double EngineHours { get; set; }
    public double IdleHours { get; set; }
    public double StoppageHours { get; set; }
    public double FuelConsumpion { get; set; }
}

public class AssertDetailsDto
{
    public string Asset { get; set; } = null!;
    public string Type { get; set; } = null!;
    public string? Make { get; set; }
    public DateTime GpsTime { get; set; }
    public string? RfidTag1 { get; set; }
    public string? RfidTag2 { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Status { get; set; } = "N/A";
}

public class LandSideResponseDto
{
    public string CardName { get; set; } = string.Empty;
    public int Skip { get; set; }
    public int Take { get; set; }
    // Dynamic list of response items based on the card name
    public new PagedResponse<object> Data { get; set; }
}

public class ActiveItvDto : AssertDetailsDto
{
    public string MovementState { get; set; } = string.Empty;
    public string Active { get; set; } = string.Empty;
}

public class IdilingItvDto : AssertDetailsDto
{
    public string Idling { get; set; } = string.Empty;
}

public class ItvOpeartionalStatusDto : AssertDetailsDto
{
    public string OperationStatus { get; set; } = null!;
    public string Ignition { get; set; } = null!;
}
