namespace Rtls.Application.Models
{
    public record WorkAssignmentDto
    {
        public long VesselVisitId { get; set; }
        public String VesselRef { get; set; }
        public String? VesselName { get; set; }
        public string? Quay { get; set; }
        public string? VesselVisitPhase { get; set; }
        public DateTime Eta { get; set; }
        public DateTime Etd { get; set; }
        public DateTime? Ata { get; set; }
        public DateTime? Atd { get; set; }
        public long TotalPlannedMoves { get; set; }
        public long CompletedMoves { get; set; }
        public List<PointOfWorkWithRecords>? PointOfWork { get; set; }
    };

    public class PointOfWorkWithRecords : PointOfWorkDto
    {
        public long TotalPlannedMoves { get; set; }
        public long CompletedMoves { get; set; }
    }
}