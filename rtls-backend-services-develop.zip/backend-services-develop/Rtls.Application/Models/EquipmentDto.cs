namespace Rtls.Application.Models;

public class EquipmentDto
{
    public long Id { get; set; }
    public string EquipmentName { get; set; } = null!;
    public string EquipmentType { get; set; } = null!;
    public int? MaxWeight { get; set; }
    public int? MaxTeu { get; set; }
    public string? Status { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public long? VmtUserId { get; set; }
    public string? CurrentPosition { get; set; }
    public string? Origin { get; set; }
    public string? Destination { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public string? RfidTag1 { get; set; }
    public string? RfidTag2 { get; set; }
}

public class CreateEquipmentDto
{
    public string EquipmentName { get; set; } = null!;
    public string EquipmentType { get; set; } = null!;
    public int? MaxWeight { get; set; }
    public int? MaxTeu { get; set; }
    public string? Status { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public string? RfidTag1 { get; set; }
    public string? RfidTag2 { get; set; }
}

public class UpdateEquipmentDto
{
    public long Id { get; set; }
    public string? EquipmentName { get; set; }
    public string? EquipmentType { get; set; }
    public int? MaxWeight { get; set; }
    public int? MaxTeu { get; set; }
    public string? Status { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public string? RfidTag1 { get; set; }
    public string? RfidTag2 { get; set; }
}
