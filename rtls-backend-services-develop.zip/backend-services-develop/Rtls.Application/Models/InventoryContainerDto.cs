﻿namespace Rtls.Application.Models
{

    public class InventoryContainerDto
    {
        public long Id { get; set; }
        public string ContainerId { get; set; } = string.Empty;
        public string IsoCode { get; set; } = string.Empty;
        public string Block { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;

    }

    public class ContainerClearRequestdto
    {
        public List<long> Ids { get; set; } = new();
    }

    public class InventoryContainerListDto
    {
        public string MoveType { get; set; } = string.Empty;
        public string VesselRef { get; set; } = string.Empty;
        public string CheCarry { get; set; } = string.Empty;
        public string Pow { get; set; } = string.Empty;
        public string Mode { get; set; } = string.Empty;
        public string AssignedChe { get; set; } = string.Empty;
        public string AssignedLane { get; set; } = string.Empty;
        public string PositionOnCarriage { get; set; } = string.Empty;
        public string FromPosition { get; set; } = string.Empty;
        public string Position { get; set; } = string.Empty;
        public string Block { get; set; } = string.Empty;
        public DateTime? JobStartTime { get; set; }
        public DateTime? DispatchTime { get; set; }
        public DateTime? TimeAtOrigin { get; set; }
        public DateTime? DischargeTime { get; set; }
        public DateTime? TimeFacilityIn { get; set; }
        public DateTime? TimeAtDestination { get; set; }
        public DateTime? JobCompleteTime { get; set; }
        public DateTime? JobCreatedTime { get; set; }
    }

    public class InventoryVesselVisitDto
    {
        public long Id { get; set; }
        public string VisitRef { get; set; } = string.Empty;
        public string VesselName { get; set; } =string.Empty;
        public string VesselClass { get; set; }=string.Empty;
        public string LineOperator { get; set; } = string.Empty;
        public List<AlarmsEventsDto> Hatch { get; set; } = new();
    }

}

