namespace Rtls.Application.Models
{
    public record WorkQueueDto
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public string? Deck { get; set; }
        public long VesselVisitId { get; set; }
        public long PointOfWorkId { get; set; }
        public long TotalPlannedMoves { get; set; }
        public long PendingMoves { get; set; }
        public long CompletedMoves { get; set; }
        public string? Status { get; set; }
    };

}