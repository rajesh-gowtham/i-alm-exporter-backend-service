namespace Rtls.Application.Models;

public sealed record VesselDto(
    long Id,
    string VesselName,
    int OverallLength,
    string LloydsIdentity,
    string VesselClass,
    string RadioCallSign,
    string? Operator,
    bool? Status,
    string? CreatedBy,
    string? UpdatedBy,
    DateTime? CreatedAt,
    DateTime? UpdatedAt,
    string? Notes
);

public sealed record CreateVesselDto(
    string VesselName,
    int OverallLength,
    string LloydsIdentity,
    string VesselClass,
    string RadioCallSign,
    string? Operator,
    bool? Status,
    string? Notes
);

public sealed record UpdateVesselDto(
    string VesselName,
    int OverallLength,
    string LloydsIdentity,
    string VesselClass,
    string RadioCallSign,
    string? Operator,
    bool? Status,
    string? Notes
);