using Rtls.Domain.Entities;
namespace Rtls.Application.Models;

public sealed record VesselVisitDto(
    long Id,
    string VisitRef,
    string InboundVoyage,
    string OutboundVoyage,
    VesselVisitPhase Phase,
    string LineOperator,
    DateTime Eta,
    DateTime Etd,
    DateTime? Ata,
    DateTime? Atd,
    DateTime? StartWorkTime,
    DateTime? EndWorkTime,
    long VesselId,
    string? CreatedBy,
    string? UpdatedBy,
    DateTime? CreatedAt,
    DateTime? UpdatedAt,
    string? Classification,
    string? Service
);

public sealed record CreateVesselVisitDto(
    string VisitRef,
    string InboundVoyage,
    string OutboundVoyage,
    VesselVisitPhase Phase,
    string LineOperator,
    DateTime Eta,
    DateTime Etd,
    long VesselId,
    DateTime? Ata,
    DateTime? Atd,
    DateTime? StartWorkTime,
    DateTime? EndWorkTime,
    string? Classification,
    string? Service
);

public sealed record UpdateVesselVisitDto(
    string InboundVoyage,
    string OutboundVoyage,
    VesselVisitPhase Phase,
    string LineOperator,
    DateTime Eta,
    DateTime Etd,
    DateTime? Ata,
    DateTime? Atd,
    long VesselId,
    DateTime? StartWorkTime,
    DateTime? EndWorkTime,
    string? Classification,
    string? Service
);
