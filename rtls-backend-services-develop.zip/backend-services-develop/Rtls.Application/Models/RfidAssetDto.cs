using Newtonsoft.Json;

namespace Rtls.Application.Models;

public class CreateRfidAssetDto
{
    [JsonProperty("RP_ID")]
    public long RPID { get; set; }
    [JsonProperty("Reader_IP")]
    public string ReaderIP { get; set; } = default!;
    [JsonProperty("RP_Name")]
    public string RPName { get; set; } = default!;
    [JsonProperty("Antenna_ID")]
    public long AntennaID { get; set; }
    [JsonProperty("LtV_ID")]
    public long LtVID { get; set; }
    [JsonProperty("Reader_Type")]
    public string ReaderType { get; set; } = default!;
    [JsonProperty("Reader_Model")]
    public string ReaderModel { get; set; } = default!;
    [JsonProperty("Location_ID")]
    public long? LocationID { get; set; }
    public string Lat { get; set; } = default!;
    public string Long { get; set; } = default!;
    public string UserId { get; set; } = default!;
}

public class UpdateRfidAssetDto
{
    [JsonProperty("RP_ID")]
    public long RPID { get; set; }
    [JsonProperty("Reader_IP")]
    public string ReaderIP { get; set; } = default!;
    [JsonProperty("RP_Name")]
    public string RPName { get; set; } = default!;
    [JsonProperty("Antenna_ID")]
    public long AntennaID { get; set; }
    [JsonProperty("LtV_ID")]
    public long LtVID { get; set; }
    [JsonProperty("Reader_Type")]
    public string ReaderType { get; set; } = default!;
    [JsonProperty("Reader_Model")]
    public string ReaderModel { get; set; } = default!;
    [JsonProperty("Location_ID")]
    public long? LocationID { get; set; }
    public string Lat { get; set; } = default!;
    public string Long { get; set; } = default!;
    public string UserId { get; set; } = default!;
}

public class RfidAssetDto
{
    [JsonProperty("RP_ID")]
    public long RPID { get; set; }
    [JsonProperty("Reader_IP")]
    public string ReaderIP { get; set; } = default!;
    [JsonProperty("RP_Name")]
    public string RPName { get; set; } = default!;
    [JsonProperty("Antenna_ID")]
    public long AntennaID { get; set; }
    [JsonProperty("LtV_ID")]
    public long LtVID { get; set; }
    [JsonProperty("Reader_Type")]
    public string ReaderType { get; set; } = default!;
    [JsonProperty("Reader_Model")]
    public string ReaderModel { get; set; } = default!;
    [JsonProperty("Ready_Status")]
    public bool ReadyStatus { get; set; }
    [JsonProperty("Present_Status")]
    public string PresentStatus { get; set; } = default!;
    [JsonProperty("Manage_UnManage")]
    public string ManageUnManage { get; set; } = default!;
    [JsonProperty("Location_ID")]
    public long? LocationID { get; set; }
    public string Lat { get; set; } = default!;
    public string Long { get; set; } = default!;
    [JsonProperty("Reader_Type_Value")]
    public string ReaderTypeValue { get; set; } = default!;
    [JsonProperty("Reader_Model_Value")]
    public string ReaderModelValue { get; set; } = default!;
    [JsonProperty("Reader_Type_GP_Value")]
    public string ReaderTypeGPValue { get; set; } = default!;
    [JsonProperty("LT_Value")]
    public string LTValue { get; set; } = default!;
    [JsonProperty("Location_Name")]
    public string LocationName { get; set; } = default!;
    public string UserId { get; set; } = default!;
}

public class RfidSuccessResponseDto
{
    public string ResponseCode { get; set; } = default!;
    public string ResponseMessage { get; set; } = default!;
}

public class RfidReaderModelTypeDto
{
    [JsonProperty("gP_ID")]
    public long GPID { get; set; }
    [JsonProperty("gP_Name")]
    public string GPName { get; set; } = default!;
    [JsonProperty("gP_Value")]
    public string GPValue { get; set; } = default!;
}

public class RfidMasterDataDto
{
    public List<RfidReaderModelTypeDto> ReaderType { get; set; } = default!;
    public List<RfidReaderModelTypeDto> ReaderModel { get; set; } = default!;
    public List<LevelTemplateValueDto> LevelTemplate { get; set; } = default!;
}