using Rtls.Domain.Entities;
using System.Text.Json.Serialization;
namespace Rtls.Application.Models;

public sealed record TelematicsDto(
        long Id,
        string DeviceId,
        string Manufacturer,
        string Model,
        string FirmwareVersion,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        DeviceType DeviceType,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        CommunicationProtocol CommunicationProtocol,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        PowerSource PowerSource,

        DateTime? WarrantyStartDate,
        DateTime? WarrantyExpiryDate,

        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt
);


public sealed record UpdateTelematicsDto(
        string DeviceId,
        string Manufacturer,
        string Model,
        string FirmwareVersion,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        DeviceType DeviceType,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        CommunicationProtocol CommunicationProtocol,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        PowerSource PowerSource,

        DateTime? WarrantyStartDate,
        DateTime? WarrantyExpiryDate,

        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt
);


public sealed record CreateTelematicsDto(
        string DeviceId,
        string Manufacturer,
        string Model,
        string FirmwareVersion,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        DeviceType DeviceType,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        CommunicationProtocol CommunicationProtocol,

        [property: JsonConverter(typeof(JsonStringEnumConverter))]
        PowerSource PowerSource,

        DateTime? WarrantyStartDate,
        DateTime? WarrantyExpiryDate,

        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt
);