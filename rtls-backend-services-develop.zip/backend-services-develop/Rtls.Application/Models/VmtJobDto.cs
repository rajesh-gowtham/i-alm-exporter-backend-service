namespace Rtls.Application.Models;

public class VmtJobDto
{
    public string? UserId { get; set; }
    public string? CheId { get; set; }
    public string? Status { get; set; }
    public bool SingleDischTwinCarry { get; set; }
    public string? Instruction { get; set; }
    public List<JobDetailsDto>? JobDetails { get; set; }
    public string? RfidMessage { get; set; }
}

public class JobDetailsDto
{
    public string? ContainerId { get; set; }
    public string? Iso { get; set; }
    public long? Weight { get; set; }
    public string? Type { get; set; }
    public string? PosOnChassis { get; set; }
    public string? Mode { get; set; }
    public string? TargetPos { get; set; }
}
