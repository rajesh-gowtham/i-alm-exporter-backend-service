namespace Rtls.Application.Models
{
    public record EquipmentPoolDto
    (
        long Id,
        string PoolName,
        string? DispatchState,
        string? OperatingMode,
        string? JobStartPosition,
        string? CreatedBy,
        string? UpdatedBy,
        DateTime? CreatedAt,
        DateTime? UpdatedAt
    );

    public record CreateEquipmentPoolDto
    (
        string PoolName,
        string? DispatchState,
        string? OperatingMode,
        string? JobStartPosition
    );

    public record UpdateEquipmentPoolDto
    (
        long Id,
        string PoolName,
        string? DispatchState,
        string? OperatingMode,
        string? JobStartPosition
    );
}