using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IRfidIntegrationService
{
    Task RefreshTokenAsync();
    Task<TResponse> PostAsync<TRequest, TResponse>(string url, TRequest body);
    Task<TResponse> PostWithoutBodyAsync<TResponse>(string url);
    Task<TResponse> GetAsync<TResponse>(string url);
}