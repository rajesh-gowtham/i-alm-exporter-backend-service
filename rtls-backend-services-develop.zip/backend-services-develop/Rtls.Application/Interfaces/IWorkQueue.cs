﻿using Rtls.Application.Models;
using Rtls.Domain.Entities;

namespace Rtls.Application.Interfaces
{
    public interface IWorkQueue
    {

        Task<WorkQueueDto?> GetByIdAsync(long id, CancellationToken ct = default);
        Task<Dictionary<WorkQueue, List<CreateWorkInstructionDto>>> CreateAsync(IEnumerable<CreateWorkInstructionDto> dto, CancellationToken ct = default);
        Task<List<WorkQueue>> GetByVesselVisitIdsAsync(List<long> vesselVisitIds, CancellationToken ct = default);


    }

}
