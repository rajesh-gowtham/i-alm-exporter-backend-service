using Rtls.Application.Models;

namespace Rtls.Application.Interfaces
{
    public interface IDashboardService
    {
        Task<WaterSideDashboardDto> GetWaterSideDashboardData(string cardName, int skip, int? take, CancellationToken ct);
        Task<LandSideDashboardDto> GetLandSideDashboardData(int skip, int? take, string cardName, CancellationToken ct);
    }
}

