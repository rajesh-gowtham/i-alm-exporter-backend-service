using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IPowAssignmentService
{
    Task<PagedResponse<PowAssignmentDto>> GetAllAsync(int skip = 0, int? take = null, CancellationToken ct = default);
    Task<PowAssignmentDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<PowAssignmentDto> CreateAsync(CreatePowAssignmentDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(UpdatePowAssignmentDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreatePowAssignmentDto> dtos, CancellationToken ct = default);

}
