using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IEquipmentPoolService
{
    Task<PagedResponse<EquipmentPoolDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<EquipmentPoolDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<EquipmentPoolDto> CreateAsync(CreateEquipmentPoolDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(UpdateEquipmentPoolDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreateEquipmentPoolDto> dtos, CancellationToken ct = default);
}
