using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IEquipmentService
{
    Task<EquipmentDto?> GetByIdAsync(long id);
    Task<EquipmentDto?> GetByNameAsync(string name);
    Task<PagedResponse<EquipmentDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<EquipmentDto> CreateAsync(CreateEquipmentDto dto);
    Task<bool> UpdateAsync(UpdateEquipmentDto dto);
    Task<bool> DeleteAsync(long id);
    Task<bool> CreateBatchAsync(IEnumerable<CreateEquipmentDto> dtos, CancellationToken ct = default);
}