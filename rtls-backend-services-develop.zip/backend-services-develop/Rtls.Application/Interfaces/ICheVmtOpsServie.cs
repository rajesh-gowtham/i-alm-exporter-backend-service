using Rtls.Application.Models;

namespace Rtls.Application.Interfaces;

public interface ICheVmtOpsServie
{
    Task<VmtJobDto> Login(string cheId, string userId, CancellationToken ct = default);
    Task<bool> Logout(string cheId, string userId, CancellationToken ct = default);
    Task<VmtJobDto> JobStepingUpdates(string cheId, string userId, string action, CancellationToken ct = default);
}