using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IWorkAssignmentService
{
    Task<PagedResponse<WorkAssignmentDto>> GetAllAsync(int skip, int take, String search, CancellationToken ct);
    Task<List<WorkQueueDto>> GetWorkQueuesByPowAsync(long vesselVisitId, long powId, CancellationToken ct);
    Task<bool> OperateWorkQueueAsync(long workQueueId, string action, CancellationToken ct);
}