using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IPointOfWorkService
{
    Task<PointOfWorkDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<PagedResponse<PointOfWorkDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<PointOfWorkDto> CreateAsync(CreatePointOfWorkDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(UpdatePointOfWorkDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreatePointOfWorkDto> dtos, CancellationToken ct = default);
}
