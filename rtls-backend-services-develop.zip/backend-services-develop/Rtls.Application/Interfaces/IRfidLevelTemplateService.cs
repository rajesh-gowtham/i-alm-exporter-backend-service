using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IRfidLevelTemplateService
{
    Task<RfidSuccessResponseDto> CreateLevelTemplateAsync(LevelTemplateDto dto, CancellationToken ct = default);
    Task<List<LevelTemplateDto>> GetLevelTemplateAsync(CancellationToken ct = default);
    Task<RfidSuccessResponseDto> UpdateLevelTemplateAsync(LevelTemplateDto dto, CancellationToken ct = default);
    Task<RfidSuccessResponseDto> CreateLevelTemplateValueAsync(LevelTemplateValueDto dto, CancellationToken ct = default);
    Task<List<LevelTemplateValueDto>> GetLevelTemplateValueAsync(CancellationToken ct = default);
    Task<RfidSuccessResponseDto> UpdateLevelTemplateValueAsync(LevelTemplateValueDto dto, CancellationToken ct = default);
}