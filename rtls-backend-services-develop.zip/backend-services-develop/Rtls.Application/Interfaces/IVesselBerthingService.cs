using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IVesselBerthingService
{
    Task<PagedResponse<VesselBerthingDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<VesselBerthingDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<VesselBerthingDto> CreateAsync(CreateVesselBerthingDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(long id, UpdateVesselBerthingDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreateVesselBerthingDto> dtos, CancellationToken ct = default);
}
