﻿using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces
{
    public interface IInventoryService
    {
        Task<PagedResponse<InventoryContainerDto>> GetAllInventoryContainerAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);

        Task<PagedResponse<InventoryVesselVisitDto>> GetAllInventoryVessel(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
        
        Task<bool> ContainerClearAsync(ContainerClearRequestdto containerClearRequestdto, CancellationToken ct = default);

        Task<InventoryContainerListDto> GetInventoryContainerById(long id, CancellationToken ct = default);
        
    }
}
