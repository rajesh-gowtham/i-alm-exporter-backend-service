using System.Collections.Immutable;
using Rtls.Application.Models;
using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IWorkInstructionService
{
    Task<PagedResponse<WorkInstructionDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<WorkInstructionDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<WorkInstructionDto> CreateAsync(CreateWorkInstructionDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(UpdateWorkInstructionDto dto, bool clean = false, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task UpdateWorkQueueStatus(long workQueueId, CancellationToken ct);
    Task<PagedResponse<WorkInstructionDto>> GetByWorkQueueIdAsync(long workQueueId, int skip, 
        int take, string search="", CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreateWorkInstructionDto> dtos, CancellationToken ct = default);
    Task<bool> JobStatusUpdate(WorkQueue workQueue, string action, CancellationToken ct = default);
    Task<bool> AppendWorkInstructionAsync(AppendWorkInstructionRequest request, CancellationToken ct);
    Task<bool> ActivateNextJobByPoolName(string poolName, string equipmentId, CancellationToken ct = default);
    Task<ImmutableArray<WorkInstruction>> GetByEquipmentCarry(long equipmentId, CancellationToken ct = default);
}