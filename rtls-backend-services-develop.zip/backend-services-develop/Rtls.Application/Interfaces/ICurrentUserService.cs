﻿namespace Rtls.Application.Interfaces;

/// <summary>
/// Service to retrieve information about the currently authenticated user
/// </summary>
public interface ICurrentUserService
{
    /// <summary>
    /// Gets the username of the currently authenticated user
    /// </summary>
    /// <returns>The username of the current user</returns>
    string GetUsername();

    /// <summary>
    /// Gets the user ID of the currently authenticated user
    /// </summary>
    /// <returns>The user ID of the current user</returns>
    string GetUserId();

    /// <summary>
    /// Checks if the current user is authenticated
    /// </summary>
    /// <returns>True if the user is authenticated, false otherwise</returns>
    bool IsAuthenticated();
}