using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface ITelematicsAssetService
{
    Task<TelematicsDto?> GetByIdAsync(long id);
    Task<PagedResponse<TelematicsDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<TelematicsDto> CreateAsync(TelematicsDto dto);
    Task<bool> UpdateAsync(long id, UpdateTelematicsDto dto);
    Task<bool> DeleteAsync(long id);
    Task<bool> CreateBatchAsync(IEnumerable<CreateTelematicsDto> dtos, CancellationToken ct = default);
    Task<TelematicsDto?> GetByDeviceIdAsync(string id, CancellationToken ct = default);
}