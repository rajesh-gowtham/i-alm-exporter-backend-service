using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IRfidAssetService
{
    Task<RfidSuccessResponseDto> CreateRfidAssetAsync(CreateRfidAssetDto dto, CancellationToken ct = default);
    Task<PagedResponse<RfidAssetDto>> GetAllAssetsAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<RfidSuccessResponseDto> UpdateRfidAssetsAsync(UpdateRfidAssetDto dto, CancellationToken ct = default);
    Task<RfidSuccessResponseDto> DeleteRfidAssetsAsync(long id, CancellationToken ct = default);
    Task<RfidMasterDataDto> GetRfidAssetMasterDataAsync(CancellationToken ct = default);
}