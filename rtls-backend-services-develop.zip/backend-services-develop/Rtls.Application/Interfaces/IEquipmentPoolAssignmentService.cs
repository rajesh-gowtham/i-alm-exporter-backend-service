using Rtls.Application.Models;

namespace Rtls.Application.Interfaces
{
    public interface IEquipmentPoolAssignmentService
    {
        Task<EquipmentAssignedAndUnassignedEquipmentDto> GetByIdAsync(long id, CancellationToken ct = default);
        Task<bool> UpdateAsync(List<UpdateEquipmentPoolAssignmentDto> dto, long equipmentPoolId, CancellationToken ct = default);
        Task<List<string>> GetAssignedEquipments(string equipmentPoolName, CancellationToken ct = default);
    }
}