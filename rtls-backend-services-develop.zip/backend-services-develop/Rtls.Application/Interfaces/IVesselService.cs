using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IVesselService
{
    Task<VesselDto?> GetByIdAsync(long id);
    Task<PagedResponse<VesselDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<VesselDto> CreateAsync(CreateVesselDto dto);
    Task<bool> UpdateAsync(long id, UpdateVesselDto dto);
    Task<bool> DeleteAsync(long id);
    Task<bool> CreateBatchAsync(IEnumerable<CreateVesselDto> dtos, CancellationToken ct = default);
}