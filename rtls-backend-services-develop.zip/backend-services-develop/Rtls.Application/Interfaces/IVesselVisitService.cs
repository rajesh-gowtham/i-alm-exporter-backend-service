using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.Application.Interfaces;

public interface IVesselVisitService
{
    Task<VesselVisitDto?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<PagedResponse<VesselVisitDto>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    Task<VesselVisitDto> CreateAsync(CreateVesselVisitDto dto, CancellationToken ct = default);
    Task<bool> UpdateAsync(long id, UpdateVesselVisitDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<CreateVesselVisitDto> dtos, CancellationToken ct = default);
}