using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class VesselVisitDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly VesselVisitDataAccess _dataAccess;

        public VesselVisitDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new VesselVisitDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoVesselVisitsExist()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenVesselVisitsExist()
        {
            // Arrange
            var visits = new[]
            {
                new VesselVisit { Id = 1, VisitRef = "VV001", VesselId = 1, Eta = DateTime.UtcNow, Etd = DateTime.UtcNow.AddDays(1), InboundVoyage = "IN1", OutboundVoyage = "OUT1", Phase = VesselVisitPhase.Inbound, LineOperator = "Operator X" },
                new VesselVisit { Id = 2, VisitRef = "VV002", VesselId = 1, Eta = DateTime.UtcNow.AddHours(1), Etd = DateTime.UtcNow.AddDays(1).AddHours(1), InboundVoyage = "IN2", OutboundVoyage = "OUT2", Phase = VesselVisitPhase.Arrived, LineOperator = "Operator Y" },
                new VesselVisit { Id = 3, VisitRef = "VV003", VesselId = 2, Eta = DateTime.UtcNow.AddHours(2), Etd = DateTime.UtcNow.AddDays(1).AddHours(2), InboundVoyage = "IN3", OutboundVoyage = "OUT3", Phase = VesselVisitPhase.Inbound, LineOperator = "Operator X" }
            };
            await _dbContext.VesselVisits.AddRangeAsync(visits);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(visits.Length, result.TotalCount);
            Assert.Equal(visits.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnVesselVisit_WhenIdExists()
        {
            // Arrange
            var visit = new VesselVisit { Id = 1, VesselId = 1, Eta = DateTime.UtcNow, Etd = DateTime.UtcNow.AddDays(1), InboundVoyage = "IN001", OutboundVoyage = "OUT001", Phase = VesselVisitPhase.Arrived, LineOperator = "Operator 1" };
            await _dbContext.VesselVisits.AddAsync(visit);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal(1, result.VesselId);
            Assert.Equal("IN001", result.InboundVoyage);
            Assert.Equal("OUT001", result.OutboundVoyage);
            Assert.Equal(VesselVisitPhase.Arrived, result.Phase);
            Assert.Equal("Operator 1", result.LineOperator);
            // Consider adding assertions for Eta and Etd with appropriate tolerance
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No vessel visits in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task CreateAsync_ShouldAddVesselVisitToDatabase()
        {
            // Arrange
            var visit = new VesselVisit { VesselId = 1, Eta = DateTime.UtcNow, Etd = DateTime.UtcNow.AddDays(1), InboundVoyage = "IN002", OutboundVoyage = "OUT002", Phase = VesselVisitPhase.Working, LineOperator = "Operator 2" };

            // Act
            var result = await _dataAccess.CreateAsync(visit);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.VesselId);
            Assert.Equal("IN002", result.InboundVoyage);
            Assert.Equal("OUT002", result.OutboundVoyage);
            Assert.Equal(VesselVisitPhase.Working, result.Phase);
            Assert.Equal("Operator 2", result.LineOperator);
            var addedVisit = await _dbContext.VesselVisits.FirstOrDefaultAsync(v => v.VesselId == 1 && v.InboundVoyage == "IN002");
            Assert.NotNull(addedVisit);
            Assert.Equal(1, addedVisit.VesselId);
            Assert.Equal("IN002", addedVisit.InboundVoyage);
            Assert.Equal("OUT002", addedVisit.OutboundVoyage);
            Assert.Equal(VesselVisitPhase.Working, addedVisit.Phase);
            Assert.Equal("Operator 2", addedVisit.LineOperator);
            // Consider adding assertions for Eta and Etd with appropriate tolerance
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateVesselVisitInDatabase()
        {
            // Arrange
            var visit = new VesselVisit { Id = 1, VesselId = 1, Eta = DateTime.UtcNow, Etd = DateTime.UtcNow.AddDays(1), InboundVoyage = "IN001", OutboundVoyage = "OUT001", Phase = VesselVisitPhase.Arrived, LineOperator = "Operator 1" };
            await _dbContext.VesselVisits.AddAsync(visit);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(visit).State = EntityState.Detached; // Detach the entity

            var updatedVisit = new VesselVisit { Id = 1, VesselId = 2, Eta = DateTime.UtcNow.AddHours(1), Etd = DateTime.UtcNow.AddDays(1).AddHours(1), InboundVoyage = "IN002", OutboundVoyage = "OUT002", Phase = VesselVisitPhase.Working, LineOperator = "Operator 2" };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedVisit);

            // Assert
            Assert.True(result);
            var dbVisit = await _dbContext.VesselVisits.FirstOrDefaultAsync(v => v.Id == 1);
            Assert.NotNull(dbVisit);
            Assert.Equal(2, dbVisit.VesselId);
            Assert.Equal("IN002", dbVisit.InboundVoyage);
            Assert.Equal("OUT002", dbVisit.OutboundVoyage);
            Assert.Equal(VesselVisitPhase.Working, dbVisit.Phase);
            Assert.Equal("Operator 2", dbVisit.LineOperator);
            // Consider adding assertions for Eta and Etd with appropriate tolerance
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemoveVesselVisitFromDatabase_WhenIdExists()
        {
            // Arrange
            var visit = new VesselVisit { Id = 1, VesselId = 1, Eta = DateTime.UtcNow, Etd = DateTime.UtcNow.AddDays(1), InboundVoyage = "IN003", OutboundVoyage = "OUT003", Phase = VesselVisitPhase.Completed, LineOperator = "Operator 3" };
            await _dbContext.VesselVisits.AddAsync(visit);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);

            // Assert
            Assert.True(result);
            var deletedVisit = await _dbContext.VesselVisits.FirstOrDefaultAsync(v => v.Id == 1);
            Assert.Null(deletedVisit);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No vessel visits in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}