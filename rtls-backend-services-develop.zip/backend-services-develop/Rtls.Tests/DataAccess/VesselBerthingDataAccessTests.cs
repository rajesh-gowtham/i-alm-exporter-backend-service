using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class VesselBerthingDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly VesselBerthingDataAccess _dataAccess;

        public VesselBerthingDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new VesselBerthingDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoVesselBerthingsExist()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenVesselBerthingsExist()
        {
            // Arrange
            var berthings = new[]
            {
                new VesselBerthing { Id = 1, VesselVisitId = 1, Quay = "Quay A", BerthingSide = BerthingSide.Port, StartWorkTime = DateTime.UtcNow, StartBollard = "Bollard A" },
                new VesselBerthing { Id = 2, VesselVisitId = 2, Quay = "Quay B", BerthingSide = BerthingSide.Starboard, StartWorkTime = DateTime.UtcNow, StartBollard = "Bollard B" },
                new VesselBerthing { Id = 3, VesselVisitId = 2, Quay = "Quay C", BerthingSide = BerthingSide.Port, StartWorkTime = DateTime.UtcNow, StartBollard = "Bollard C" }
            };
            await _dbContext.VesselBerthings.AddRangeAsync(berthings);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(berthings.Length, result.TotalCount);
            Assert.Equal(berthings.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnVesselBerthing_WhenIdExists()
        {
            // Arrange
            var berthing = new VesselBerthing { Id = 1, VesselVisitId = 1, Quay = "Test Quay", BerthingSide = BerthingSide.Port, StartWorkTime = DateTime.UtcNow, StartBollard = "Test Bollard" };
            await _dbContext.VesselBerthings.AddAsync(berthing);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal(1, result.VesselVisitId);
            Assert.Equal("Test Quay", result.Quay);
            Assert.Equal("Port", result.BerthingSide.ToString());
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No berthings in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        // TODO: Add tests for CreateAsync
        [Fact]
        public async Task CreateAsync_ShouldAddVesselBerthingToDatabase()
        {
            // Arrange
            var vesselVisit = new VesselVisit
            {
                Id = 1,
                VesselId = 1,
                Eta = DateTime.UtcNow, // Use Eta instead of ArrivalTime
                InboundVoyage = "TestInbound",
                OutboundVoyage = "TestOutbound",
                Phase = VesselVisitPhase.Inbound,
                LineOperator = "TestOperator",
                CreatedBy = "test", // Add auditable properties
                UpdatedBy = "test"
            }; // Create a related VesselVisit
            await _dbContext.VesselVisits.AddAsync(vesselVisit); // Add the VesselVisit to the context
            var berthing = new VesselBerthing { VesselVisitId = 1, VesselVisit = vesselVisit, Quay = "New Quay", BerthingSide = BerthingSide.Starboard, StartWorkTime = DateTime.UtcNow, StartBollard = "New Bollard" };

            // Act
            var result = await _dataAccess.CreateAsync(berthing);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.VesselVisitId);
            Assert.Equal("New Quay", result.Quay);
            Assert.Equal("Starboard", result.BerthingSide.ToString());
            var addedBerthing = await _dbContext.VesselBerthings.FirstOrDefaultAsync(b => b.VesselVisitId == 1 && b.Quay == "New Quay");
            Assert.NotNull(addedBerthing);
            Assert.Equal(1, addedBerthing.VesselVisitId);
            Assert.Equal("New Quay", addedBerthing.Quay);
            Assert.Equal("Starboard", addedBerthing.BerthingSide.ToString());
        }

        // TODO: Add tests for UpdateAsync
        [Fact]
        public async Task UpdateAsync_ShouldUpdateVesselBerthingInDatabase()
        {
            // Arrange
            var berthing = new VesselBerthing { Id = 1, VesselVisitId = 1, Quay = "Original Quay", BerthingSide = BerthingSide.Port, StartWorkTime = DateTime.UtcNow, StartBollard = "Original Bollard" };
            await _dbContext.VesselBerthings.AddAsync(berthing);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(berthing).State = EntityState.Detached; // Detach the entity

            var updatedBerthing = new VesselBerthing { Id = 2, VesselVisitId = 2, Quay = "Updated Quay", BerthingSide = BerthingSide.Starboard, StartWorkTime = DateTime.UtcNow.AddHours(1), StartBollard = "Updated Bollard" };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedBerthing);

            // Assert
            Assert.True(result);
            var dbBerthing = await _dbContext.VesselBerthings.FirstOrDefaultAsync(b => b.Id == 1);
            Assert.NotNull(dbBerthing);
            Assert.Equal(2, dbBerthing.VesselVisitId);
            Assert.Equal("Updated Quay", dbBerthing.Quay);
            Assert.Equal("Starboard", dbBerthing.BerthingSide.ToString());
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemoveVesselBerthingFromDatabase_WhenIdExists()
        {
            // Arrange
            var berthing = new VesselBerthing { Id = 1, VesselVisitId = 1, Quay = "Quay to Delete", BerthingSide = BerthingSide.Port, StartWorkTime = DateTime.UtcNow, StartBollard = "Bollard to Delete" };
            await _dbContext.VesselBerthings.AddAsync(berthing);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);

            // Assert
            Assert.True(result);
            var deletedBerthing = await _dbContext.VesselBerthings.FirstOrDefaultAsync(b => b.Id == 1);
            Assert.Null(deletedBerthing);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No berthings in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}