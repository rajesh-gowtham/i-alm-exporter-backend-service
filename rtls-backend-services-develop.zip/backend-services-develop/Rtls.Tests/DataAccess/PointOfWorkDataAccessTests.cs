using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class PointOfWorkDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly PointOfWorkDataAccess _dataAccess;

        public PointOfWorkDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new PointOfWorkDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoPointOfWorkExists()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenPointOfWorkExists()
        {
            // Arrange
            var pointsOfWork = new[]
            {
                new PointOfWork { Id = 1, Name = "POW 1", CreatedBy = "test", UpdatedBy = "test" },
                new PointOfWork { Id = 2, Name = "POW 2", CreatedBy = "test", UpdatedBy = "test" },
                new PointOfWork { Id = 3, Name = "POW 3", CreatedBy = "test", UpdatedBy = "test" }
            };
            await _dbContext.PointOfWorks.AddRangeAsync(pointsOfWork);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(pointsOfWork.Length, result.TotalCount);
            Assert.Equal(pointsOfWork.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnPointOfWork_WhenIdExists()
        {
            // Arrange
            var pointOfWork = new PointOfWork { Id = 1, Name = "Test POW", CreatedBy = "test", UpdatedBy = "test" };
            await _dbContext.PointOfWorks.AddAsync(pointOfWork);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal("Test POW", result.Name);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No points of work in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        // TODO: Add tests for CreateAsync
        [Fact]
        public async Task CreateAsync_ShouldAddPointOfWorkToDatabase()
        {
            // Arrange
            var pointOfWork = new PointOfWork
            {
                Name = "New POW",
                CreatedBy = "TestUser",
                UpdatedBy = "TestUser",
            };

            // Act
            var result = await _dataAccess.CreateAsync(pointOfWork);
            await _dbContext.SaveChangesAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal("New POW", result.Name);
            var addedPointOfWork = await _dbContext.PointOfWorks.FirstOrDefaultAsync(p => p.Name == "New POW");
            Assert.NotNull(addedPointOfWork);
            Assert.Equal("New POW", addedPointOfWork.Name);
        }

        // TODO: Add tests for UpdateAsync
        [Fact]
        public async Task UpdateAsync_ShouldUpdatePointOfWorkInDatabase()
        {
            // Arrange
            var pointOfWork = new PointOfWork
            {
                Id = 1,
                Name = "Original Name",
                CreatedBy = "TestUser",
                UpdatedBy = "TestUser",
            };
            await _dbContext.PointOfWorks.AddAsync(pointOfWork);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(pointOfWork).State = EntityState.Detached; // Detach the entity

            var updatedPointOfWork = new PointOfWork
            {
                Id = 1,
                Name = "Updated Name",
                CreatedBy = "TestUser",
                UpdatedBy = "TestUser",
            };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedPointOfWork);
            await _dbContext.SaveChangesAsync();

            // Assert
            Assert.True(result);
            var dbPointOfWork = await _dbContext.PointOfWorks.FirstOrDefaultAsync(p => p.Id == 1);
            Assert.NotNull(dbPointOfWork);
            Assert.Equal("Updated Name", dbPointOfWork.Name);
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemovePointOfWorkFromDatabase_WhenIdExists()
        {
            // Arrange
            var pointOfWork = new PointOfWork { Id = 1, Name = "POW to Delete", CreatedBy = "test", UpdatedBy = "test" };
            await _dbContext.PointOfWorks.AddAsync(pointOfWork);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);
            await _dbContext.SaveChangesAsync();

            // Assert
            Assert.True(result);
            var deletedPointOfWork = await _dbContext.PointOfWorks.FirstOrDefaultAsync(p => p.Id == 1);
            Assert.Null(deletedPointOfWork);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No points of work in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}