using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class EquipmentPoolDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly EquipmentPoolDataAccess _dataAccess;

        public EquipmentPoolDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new EquipmentPoolDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoEquipmentPoolsExist()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenEquipmentPoolsExist()
        {
            // Arrange
            var equipmentPools = new[]
            {
                new EquipmentPool { Id = 1, PoolName = "Pool 1" },
                new EquipmentPool { Id = 2, PoolName = "Pool 2" },
                new EquipmentPool { Id = 3, PoolName = "Pool 3" }
            };
            await _dbContext.EquipmentPools.AddRangeAsync(equipmentPools);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(equipmentPools.Length, result.TotalCount);
            Assert.Equal(equipmentPools.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        // TODO: Add tests for GetByIdAsync
        [Fact]
        public async Task GetByIdAsync_ShouldReturnEquipmentPool_WhenIdExists()
        {
            // Arrange
            var equipmentPool = new EquipmentPool { Id = 1, PoolName = "Test Pool" };
            await _dbContext.EquipmentPools.AddAsync(equipmentPool);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal("Test Pool", result.PoolName);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No equipment pools in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        // TODO: Add tests for CreateAsync
        [Fact]
        public async Task CreateAsync_ShouldAddEquipmentPoolToDatabase()
        {
            // Arrange
            var equipmentPool = new EquipmentPool { PoolName = "New Pool" };

            // Act
            var result = await _dataAccess.CreateAsync(equipmentPool);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("New Pool", result.PoolName);
            var addedPool = await _dbContext.EquipmentPools.FirstOrDefaultAsync(p => p.PoolName == "New Pool");
            Assert.NotNull(addedPool);
            Assert.Equal("New Pool", addedPool.PoolName);
        }

        // TODO: Add tests for UpdateAsync
        [Fact]
        public async Task UpdateAsync_ShouldUpdateEquipmentPoolInDatabase()
        {
            // Arrange
            var equipmentPool = new EquipmentPool { Id = 1, PoolName = "Original Name" };
            await _dbContext.EquipmentPools.AddAsync(equipmentPool);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(equipmentPool).State = EntityState.Detached; // Detach the entity

            var updatedEquipmentPool = new EquipmentPool { Id = 1, PoolName = "Updated Name" };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedEquipmentPool);

            // Assert
            Assert.True(result);
            var dbPool = await _dbContext.EquipmentPools.FirstOrDefaultAsync(p => p.Id == 1);
            Assert.NotNull(dbPool);
            Assert.Equal("Updated Name", dbPool.PoolName);
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemoveEquipmentPoolFromDatabase_WhenIdExists()
        {
            // Arrange
            var equipmentPool = new EquipmentPool { Id = 1, PoolName = "Pool to Delete" };
            await _dbContext.EquipmentPools.AddAsync(equipmentPool);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);

            // Assert
            Assert.True(result);
            var deletedPool = await _dbContext.EquipmentPools.FirstOrDefaultAsync(p => p.Id == 1);
            Assert.Null(deletedPool);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No equipment pools in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}