using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class WorkInstructionDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly WorkInstructionDataAccess _dataAccess;

        public WorkInstructionDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new WorkInstructionDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoWorkInstructionsExist()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenWorkInstructionsExist()
        {
            // Arrange
            var instructions = new[]
            {
                new WorkInstruction
                {
                    Id = 1,
                    VesselVisitId = 1,
                    MoveType = "Load",
                    FromLocation = "Yard",
                    TargetLocation = "Vessel",
                    AssignedChe = "CHE1",
                    CheCarry = "Carry 1",
                    PositionOnCarriage = "On Carriage",
                    ContainerId = "CONT1"
                },
                new WorkInstruction
                {
                    Id = 2,
                    VesselVisitId = 2,
                    MoveType = "Discharge",
                    FromLocation = "Vessel",
                    TargetLocation = "Yard",
                    AssignedChe = "CHE2",
                    CheCarry = "Carry 2",
                    PositionOnCarriage = "On Ground",
                    ContainerId = "CONT2"
                },
                new WorkInstruction
                {
                    Id = 3,
                    VesselVisitId = 3,
                    MoveType = "Shift",
                    FromLocation = "Yard",
                    TargetLocation = "Yard",
                    AssignedChe = "CHE3",
                    CheCarry = "Carry 3",
                    PositionOnCarriage = "On RTG",
                    ContainerId = "CONT3"
                }
            };
            await _dbContext.WorkInstructions.AddRangeAsync(instructions);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(instructions.Length, result.TotalCount);
            Assert.Equal(instructions.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnWorkInstruction_WhenIdExists()
        {
            // Arrange
            var instruction = new WorkInstruction
            {
                Id = 1,
                VesselVisitId = 1,
                MoveType = "Load",
                FromLocation = "Yard",
                TargetLocation = "Vessel",
                AssignedChe = "CHE1",
                CheCarry = "Carry 1",
                PositionOnCarriage = "On Carriage",
                ContainerId = "CONT1"
            };
            await _dbContext.WorkInstructions.AddAsync(instruction);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal(1, result.VesselVisitId);
            Assert.Equal("Load", result.MoveType);
            Assert.Equal("Yard", result.FromLocation);
            Assert.Equal("Vessel", result.TargetLocation);
            // Removed: EquipmentType property no longer exists
            Assert.Equal("CHE1", result.AssignedChe);
            Assert.Equal("Carry 1", result.CheCarry);
            Assert.Equal("On Carriage", result.PositionOnCarriage);
            // Removed: BlockId, BayId, PowId, ContainerName properties no longer exist
            Assert.Equal("CONT1", result.ContainerId);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No work instructions in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task CreateAsync_ShouldAddWorkInstructionToDatabase()
        {
            // Arrange
            var instruction = new WorkInstruction
            {
                VesselVisitId = 1,
                MoveType = "Load",
                FromLocation = "Yard",
                TargetLocation = "Vessel",
                AssignedChe = "CHE1",
                CheCarry = "Carry 1",
                PositionOnCarriage = "On Carriage",
                ContainerId = "CONT1"
            };

            // Act
            var result = await _dataAccess.CreateAsync(instruction);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.VesselVisitId);
            Assert.Equal("Load", result.MoveType);
            Assert.Equal("Yard", result.FromLocation);
            Assert.Equal("Vessel", result.TargetLocation);
            // Removed: EquipmentType property no longer exists
            Assert.Equal("CHE1", result.AssignedChe);
            Assert.Equal("Carry 1", result.CheCarry);
            Assert.Equal("On Carriage", result.PositionOnCarriage);
            // Removed: BlockId, BayId, PowId, ContainerName properties no longer exist
            Assert.Equal("CONT1", result.ContainerId);
            var addedInstruction = await _dbContext.WorkInstructions.FirstOrDefaultAsync(i => i.MoveType == "Load" && i.ContainerId == "CONT1");
            Assert.NotNull(addedInstruction);
            Assert.Equal(1, addedInstruction.VesselVisitId);
            Assert.Equal("Load", addedInstruction.MoveType);
            Assert.Equal("Yard", addedInstruction.FromLocation);
            Assert.Equal("Vessel", addedInstruction.TargetLocation);
            // Removed: EquipmentType, BlockId, BayId, PowId, ContainerName properties no longer exist
            Assert.Equal("CHE1", addedInstruction.AssignedChe);
            Assert.Equal("Carry 1", addedInstruction.CheCarry);
            Assert.Equal("On Carriage", addedInstruction.PositionOnCarriage);
            Assert.Equal("CONT1", addedInstruction.ContainerId);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateWorkInstructionInDatabase()
        {
            // Arrange
            var instruction = new WorkInstruction
            {
                Id = 1,
                VesselVisitId = 1,
                MoveType = "Load",
                FromLocation = "Yard",
                TargetLocation = "Vessel",
                AssignedChe = "CHE1",
                CheCarry = "Carry 1",
                PositionOnCarriage = "On Carriage",
                ContainerId = "CONT1"
            };
            await _dbContext.WorkInstructions.AddAsync(instruction);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(instruction).State = EntityState.Detached; // Detach the entity

            var updatedInstruction = new WorkInstruction
            {
                Id = 1,
                VesselVisitId = 1,
                MoveType = "Discharge",
                FromLocation = "Vessel",
                TargetLocation = "Yard",
                AssignedChe = "CHE2",
                CheCarry = "Carry 2",
                PositionOnCarriage = "On Ground",
                ContainerId = "CONT2"
            };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedInstruction);

            // Assert
            Assert.True(result);
            var dbInstruction = await _dbContext.WorkInstructions.FirstOrDefaultAsync(i => i.Id == 1);
            Assert.NotNull(dbInstruction);
            Assert.Equal(2, dbInstruction.VesselVisitId);
            Assert.Equal("Discharge", dbInstruction.MoveType);
            Assert.Equal("Vessel", dbInstruction.FromLocation);
            Assert.Equal("Yard", dbInstruction.TargetLocation);
            // Removed: EquipmentType property no longer exists
            Assert.Equal("CHE2", dbInstruction.AssignedChe);
            Assert.Equal("Carry 2", dbInstruction.CheCarry);
            Assert.Equal("On Ground", dbInstruction.PositionOnCarriage);
            // Removed: BlockId, BayId, PowId, ContainerName properties no longer exist
            Assert.Equal("CONT2", dbInstruction.ContainerId);
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemoveWorkInstructionFromDatabase_WhenIdExists()
        {
            // Arrange
            var instruction = new WorkInstruction
            {
                Id = 1,
                VesselVisitId = 1,
                MoveType = "Load",
                FromLocation = "Yard",
                TargetLocation = "Vessel",
                AssignedChe = "CHE1",
                CheCarry = "Carry 1",
                PositionOnCarriage = "On Carriage",
                ContainerId = "CONTDEL"
            };
            await _dbContext.WorkInstructions.AddAsync(instruction);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(instruction);

            // Assert
            Assert.True(result);
            var deletedInstruction = await _dbContext.WorkInstructions.FirstOrDefaultAsync(i => i.Id == 1);
            Assert.Null(deletedInstruction);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No work instructions in the database

            // Act
            var result = await _dataAccess.DeleteAsync(new WorkInstruction
            {
                Id = 999
            }); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}