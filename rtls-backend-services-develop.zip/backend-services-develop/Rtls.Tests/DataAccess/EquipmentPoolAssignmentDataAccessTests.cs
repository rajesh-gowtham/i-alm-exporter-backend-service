using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class EquipmentPoolAssignmentDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly EquipmentPoolAssignmentDataAccess _dataAccess;

        public EquipmentPoolAssignmentDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new EquipmentPoolAssignmentDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No assignments in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        // TODO: Add tests for CreateAsync
        [Fact]
        public async Task CreateAsync_ShouldAddEquipmentPoolAssignmentToDatabase()
        {
            // Arrange
            var assignment = new EquipmentPoolAssignment { EquipmentPoolId = 1, EquipmentId = 1 };

            // Act
            var result = await _dataAccess.CreateAsync(assignment);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.EquipmentPoolId);
            Assert.Equal(1, result.EquipmentId);
            var addedAssignment = await _dbContext.EquipmentPoolAssignments.FirstOrDefaultAsync(a => a.EquipmentPoolId == 1 && a.EquipmentId == 1);
            Assert.NotNull(addedAssignment);
            Assert.Equal(1, addedAssignment.EquipmentPoolId);
            Assert.Equal(1, addedAssignment.EquipmentId);
        }

        // TODO: Add tests for UpdateAsync
        [Fact]
        public async Task UpdateAsync_ShouldUpdateEquipmentPoolAssignmentInDatabase()
        {
            // Arrange
            var assignment = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1 };
            await _dbContext.EquipmentPoolAssignments.AddAsync(assignment);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(assignment).State = EntityState.Detached; // Detach the entity

            var updatedAssignment = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 2, EquipmentId = 3 };

            // Act
      //      var result = await _dataAccess.UpdateAsync(updatedAssignment);

            // Assert
        //    Assert.True(result);
            var dbAssignment = await _dbContext.EquipmentPoolAssignments.FirstOrDefaultAsync(a => a.Id == 1);
            Assert.NotNull(dbAssignment);
            Assert.Equal(2, dbAssignment.EquipmentPoolId);
            Assert.Equal(3, dbAssignment.EquipmentId);
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemoveEquipmentPoolAssignmentFromDatabase_WhenIdExists()
        {
            // Arrange
            var assignment = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1 };
            await _dbContext.EquipmentPoolAssignments.AddAsync(assignment);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);

            // Assert
            Assert.True(result);
            var deletedAssignment = await _dbContext.EquipmentPoolAssignments.FirstOrDefaultAsync(a => a.Id == 1);
            Assert.Null(deletedAssignment);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No assignments in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}