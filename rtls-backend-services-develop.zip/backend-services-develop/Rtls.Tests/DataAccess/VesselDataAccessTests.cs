using Rtls.Domain.DataAccess;
using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Microsoft.Extensions.Logging;
using Moq;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class VesselDataAccessTests
    {
        private AppDbContext CreateInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;
            var dbContext = new AppDbContext(options);
            // Ensure the database is clean for each test
            dbContext.Database.EnsureDeleted();
            dbContext.Database.EnsureCreated();
            return dbContext;
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnVessel_WhenVesselExists()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var vessel = new Vessel
            {
                Id = 1,
                VesselName = "Test Vessel",
                CreatedBy = "test",
                UpdatedBy = "test",
                LloydsIdentity = "123",
                Operator = "Operator A",
                RadioCallSign = "RCS1",
                VesselClass = "Class A"
            };
            dbContext.Vessels.Add(vessel);
            await dbContext.SaveChangesAsync();

            // Act
            var retrievedVessel = await dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(retrievedVessel);
            Assert.Equal(vessel.Id, retrievedVessel.Id);
            Assert.Equal(vessel.VesselName, retrievedVessel.VesselName);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenVesselDoesNotExist()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            // Act
            var retrievedVessel = await dataAccess.GetByIdAsync(999); // Use an ID that does not exist

            // Assert
            Assert.Null(retrievedVessel);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnAllVessels_WhenCalledWithoutParameters()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var vessels = new List<Vessel>
            {
                new Vessel { Id = 1, VesselName = "Vessel 1", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "123", Operator = "Operator A", RadioCallSign = "RCS1", VesselClass = "Class A" },
                new Vessel { Id = 2, VesselName = "Vessel 2", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "456", Operator = "Operator B", RadioCallSign = "RCS2", VesselClass = "Class B" },
                new Vessel { Id = 3, VesselName = "Vessel 3", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "789", Operator = "Operator C", RadioCallSign = "RCS3", VesselClass = "Class C" }
            };
            dbContext.Vessels.AddRange(vessels);
            await dbContext.SaveChangesAsync();

            // Act
            var pagedResponse = await dataAccess.GetAllAsync();

            // Assert
            Assert.NotNull(pagedResponse);
            Assert.Equal(vessels.Count, pagedResponse.TotalCount);
            Assert.Equal(vessels.Count, pagedResponse.Items.Count());
            // Further assertions can be added to check the content of the returned items
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnCorrectSubsetOfVessels_WhenSkipAndTakeAreProvided()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var vessels = new List<Vessel>
            {
                new Vessel { Id = 1, VesselName = "Vessel 1", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "123", Operator = "Operator A", RadioCallSign = "RCS1", VesselClass = "Class A" },
                new Vessel { Id = 2, VesselName = "Vessel 2", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "456", Operator = "Operator B", RadioCallSign = "RCS2", VesselClass = "Class B" },
                new Vessel { Id = 3, VesselName = "Vessel 3", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "789", Operator = "Operator C", RadioCallSign = "RCS3", VesselClass = "Class C" },
                new Vessel { Id = 4, VesselName = "Vessel 4", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "101", Operator = "Operator D", RadioCallSign = "RCS4", VesselClass = "Class D" },
                new Vessel { Id = 5, VesselName = "Vessel 5", CreatedBy = "test", UpdatedBy = "test", LloydsIdentity = "112", Operator = "Operator E", RadioCallSign = "RCS5", VesselClass = "Class E" }
            };
            dbContext.Vessels.AddRange(vessels);
            await dbContext.SaveChangesAsync();

            var skip = 1;
            var take = 2;

            // Act
            var pagedResponse = await dataAccess.GetAllAsync(skip, take);

            // Assert
            Assert.NotNull(pagedResponse);
            Assert.Equal(vessels.Count, pagedResponse.TotalCount); // Total count should still be the same
            Assert.Equal(take, pagedResponse.Items.Count());
            Assert.Equal("Vessel 2", pagedResponse.Items.First().VesselName);
            Assert.Equal("Vessel 3", pagedResponse.Items.Last().VesselName);
        }

        [Fact]
        public async Task CreateAsync_ShouldAddVesselToDatabase()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var newVessel = new Vessel
            {
                VesselName = "New Test Vessel",
                CreatedBy = "test",
                UpdatedBy = "test",
                LloydsIdentity = "987",
                Operator = "Operator X",
                RadioCallSign = "RCSX",
                VesselClass = "Class X"
            };

            // Act
            var createdVessel = await dataAccess.CreateAsync(newVessel);

            // Assert
            Assert.NotNull(createdVessel);
            Assert.True(createdVessel.Id > 0); // Verify that an ID was generated
            Assert.Equal(newVessel.VesselName, createdVessel.VesselName);

            // Verify that the vessel was added to the database
            var vesselInDb = await dbContext.Vessels.FindAsync(createdVessel.Id);
            Assert.NotNull(vesselInDb);
            Assert.Equal(createdVessel.Id, vesselInDb.Id);
            Assert.Equal(createdVessel.VesselName, vesselInDb.VesselName);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateVesselInDatabase()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var initialVessel = new Vessel
            {
                Id = 1,
                VesselName = "Initial Vessel",
                CreatedBy = "test",
                UpdatedBy = "test",
                LloydsIdentity = "111",
                Operator = "Operator I",
                RadioCallSign = "RCSI",
                VesselClass = "Class I"
            };
            dbContext.Vessels.Add(initialVessel);
            await dbContext.SaveChangesAsync();
            dbContext.Entry(initialVessel).State = EntityState.Detached; // Detach the entity

            var updatedVessel = new Vessel
            {
                Id = 1,
                VesselName = "Updated Vessel",
                CreatedBy = "test", // Assuming these are not updated by the method
                UpdatedBy = "test_updated",
                LloydsIdentity = "111_updated",
                Operator = "Operator U",
                RadioCallSign = "RCSU",
                VesselClass = "Class U"
            };

            // Act
            var result = await dataAccess.UpdateAsync(updatedVessel);

            // Assert
            Assert.True(result); // Verify that the update was successful

            // Verify that the vessel was updated in the database
            var vesselInDb = await dbContext.Vessels.FindAsync(updatedVessel.Id);
            Assert.NotNull(vesselInDb);
            Assert.Equal(updatedVessel.VesselName, vesselInDb.VesselName);
            Assert.Equal(updatedVessel.UpdatedBy, vesselInDb.UpdatedBy);
            // Add assertions for other updated properties
        }

        [Fact]
        public async Task DeleteAsync_ShouldRemoveVesselFromDatabase_WhenVesselExists()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            var vesselToDelete = new Vessel
            {
                Id = 1,
                VesselName = "Vessel to Delete",
                CreatedBy = "test",
                UpdatedBy = "test",
                LloydsIdentity = "222",
                Operator = "Operator D",
                RadioCallSign = "RCSD",
                VesselClass = "Class D"
            };
            dbContext.Vessels.Add(vesselToDelete);
            await dbContext.SaveChangesAsync();

            // Act
            var result = await dataAccess.DeleteAsync(vesselToDelete.Id);

            // Assert
            Assert.True(result); // Verify that the deletion was successful

            // Verify that the vessel was removed from the database
            var vesselInDb = await dbContext.Vessels.FindAsync(vesselToDelete.Id);
            Assert.Null(vesselInDb);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenVesselDoesNotExist()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var loggerMock = new Mock<ILogger<VesselDataAccess>>();
            var dataAccess = new VesselDataAccess(dbContext, loggerMock.Object);

            // Act
            var result = await dataAccess.DeleteAsync(999); // Use an ID that does not exist

            // Assert
            Assert.False(result); // Verify that the deletion was not successful
        }
    }
}