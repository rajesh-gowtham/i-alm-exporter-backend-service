using Microsoft.EntityFrameworkCore;
using Rtls.Domain.DataAccess;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class PowAssignmentDataAccessTests
    {
        private readonly AppDbContext _dbContext;
        private readonly PowAssignmentDataAccess _dataAccess;

        public PowAssignmentDataAccessTests()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            _dbContext = new AppDbContext(options);
            _dataAccess = new PowAssignmentDataAccess(_dbContext);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenNoPowAssignmentsExist()
        {
            // Arrange

            // Act
            var result = await _dataAccess.GetAllAsync(0, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.TotalCount);
            Assert.Empty(result.Items);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnPagedResponse_WhenPowAssignmentsExist()
        {
            // Arrange
            var assignments = new[]
            {
                new PowAssignment { Id = 1, PowId = 1, EquipmentPoolId = 1 },
                new PowAssignment { Id = 2, PowId = 1, EquipmentPoolId = 2 },
                new PowAssignment { Id = 3, PowId = 2, EquipmentPoolId = 3 }
            };
            await _dbContext.PowAssignments.AddRangeAsync(assignments);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetAllAsync(0, null);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(assignments.Length, result.TotalCount);
            Assert.Equal(assignments.Length, result.Items.Count());
            // Add more specific assertions about the returned items if needed
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnPowAssignment_WhenIdExists()
        {
            // Arrange
            var assignment = new PowAssignment { Id = 1, PowId = 1, EquipmentPoolId = 1 };
            await _dbContext.PowAssignments.AddAsync(assignment);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal(1, result.PowId);
            Assert.Equal(1, result.EquipmentPoolId);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenIdDoesNotExist()
        {
            // Arrange
            // No assignments in the database

            // Act
            var result = await _dataAccess.GetByIdAsync(999); // Use a non-existent ID

            // Assert
            Assert.Null(result);
        }

        // TODO: Add tests for CreateAsync
        [Fact]
        public async Task CreateAsync_ShouldAddPowAssignmentToDatabase()
        {
            // Arrange
            var assignment = new PowAssignment { PowId = 1, EquipmentPoolId = 1 };

            // Act
            var result = await _dataAccess.CreateAsync(assignment);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.PowId);
            Assert.Equal(1, result.EquipmentPoolId);
            var addedAssignment = await _dbContext.PowAssignments.FirstOrDefaultAsync(a => a.PowId == 1 && a.EquipmentPoolId == 1);
            Assert.NotNull(addedAssignment);
            Assert.Equal(1, addedAssignment.PowId);
            Assert.Equal(1, addedAssignment.EquipmentPoolId);
        }

        // TODO: Add tests for UpdateAsync
        [Fact]
        public async Task UpdateAsync_ShouldUpdatePowAssignmentInDatabase()
        {
            // Arrange
            var assignment = new PowAssignment { Id = 1, PowId = 1, EquipmentPoolId = 1 };
            await _dbContext.PowAssignments.AddAsync(assignment);
            await _dbContext.SaveChangesAsync();
            _dbContext.Entry(assignment).State = EntityState.Detached; // Detach the entity

            var updatedAssignment = new PowAssignment { Id = 1, PowId = 2, EquipmentPoolId = 3 };

            // Act
            var result = await _dataAccess.UpdateAsync(updatedAssignment);

            // Assert
            Assert.True(result);
            var dbAssignment = await _dbContext.PowAssignments.FirstOrDefaultAsync(a => a.Id == 1);
            Assert.NotNull(dbAssignment);
            Assert.Equal(2, dbAssignment.PowId);
            Assert.Equal(3, dbAssignment.EquipmentPoolId);
        }

        // TODO: Add tests for DeleteAsync
        [Fact]
        public async Task DeleteAsync_ShouldRemovePowAssignmentFromDatabase_WhenIdExists()
        {
            // Arrange
            var assignment = new PowAssignment { Id = 1, PowId = 1, EquipmentPoolId = 1 };
            await _dbContext.PowAssignments.AddAsync(assignment);
            await _dbContext.SaveChangesAsync();

            // Act
            var result = await _dataAccess.DeleteAsync(1);

            // Assert
            Assert.True(result);
            var deletedAssignment = await _dbContext.PowAssignments.FirstOrDefaultAsync(a => a.Id == 1);
            Assert.Null(deletedAssignment);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenIdDoesNotExist()
        {
            // Arrange
            // No assignments in the database

            // Act
            var result = await _dataAccess.DeleteAsync(999); // Use a non-existent ID

            // Assert
            Assert.False(result);
        }
    }
}