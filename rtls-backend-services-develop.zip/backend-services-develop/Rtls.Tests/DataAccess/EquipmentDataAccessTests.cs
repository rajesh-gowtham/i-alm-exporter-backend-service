using Rtls.Domain.DataAccess;
using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.DataAccess
{
    public class EquipmentDataAccessTests
    {
        private AppDbContext CreateInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "TestEquipmentDatabase")
                .Options;
            var dbContext = new AppDbContext(options);
            // Ensure the database is clean for each test
            dbContext.Database.EnsureDeleted();
            dbContext.Database.EnsureCreated();
            return dbContext;
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnEquipment_WhenEquipmentExists()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var equipment = new Equipment { Id = 1, EquipmentType = "Test Equipment Type", EquipmentName = "Test Equipment Name" };
            dbContext.Equipments.Add(equipment);
            await dbContext.SaveChangesAsync();

            // Act
            var retrievedEquipment = await dataAccess.GetByIdAsync(1);

            // Assert
            Assert.NotNull(retrievedEquipment);
            Assert.Equal(equipment.Id, retrievedEquipment.Id);
            Assert.Equal(equipment.EquipmentType, retrievedEquipment.EquipmentType);
            Assert.Equal(equipment.EquipmentName, retrievedEquipment.EquipmentName);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnNull_WhenEquipmentDoesNotExist()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            // Act
            var retrievedEquipment = await dataAccess.GetByIdAsync(999); // Use an ID that does not exist

            // Assert
            Assert.Null(retrievedEquipment);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnAllEquipment_WhenCalledWithoutParameters()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var equipmentList = new List<Equipment>
            {
                new Equipment { Id = 1, EquipmentType = "Type 1", EquipmentName = "Equipment 1" },
                new Equipment { Id = 2, EquipmentType = "Type 2", EquipmentName = "Equipment 2" },
                new Equipment { Id = 3, EquipmentType = "Type 3", EquipmentName = "Equipment 3" }
            };
            dbContext.Equipments.AddRange(equipmentList);
            await dbContext.SaveChangesAsync();

            // Act
            var pagedResponse = await dataAccess.GetAllAsync(0, null, "");

            // Assert
            Assert.NotNull(pagedResponse);
            Assert.Equal(equipmentList.Count, pagedResponse.TotalCount);
            Assert.Equal(equipmentList.Count, pagedResponse.Items.Count());
            // Further assertions can be added to check the content of the returned items
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnCorrectSubsetOfEquipment_WhenSkipAndTakeAreProvided()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var equipmentList = new List<Equipment>
            {
                new Equipment { Id = 1, EquipmentType = "Type 1", EquipmentName = "Equipment 1" },
                new Equipment { Id = 2, EquipmentType = "Type 2", EquipmentName = "Equipment 2" },
                new Equipment { Id = 3, EquipmentType = "Type 3", EquipmentName = "Equipment 3" },
                new Equipment { Id = 4, EquipmentType = "Type 4", EquipmentName = "Equipment 4" },
                new Equipment { Id = 5, EquipmentType = "Type 5", EquipmentName = "Equipment 5" }
            };
            dbContext.Equipments.AddRange(equipmentList);
            await dbContext.SaveChangesAsync();

            var skip = 1;
            var take = 2;

            // Act
            var pagedResponse = await dataAccess.GetAllAsync(skip, take, "");

            // Assert
            Assert.NotNull(pagedResponse);
            Assert.Equal(equipmentList.Count, pagedResponse.TotalCount); // Total count should still be the same
            Assert.Equal(take, pagedResponse.Items.Count());
            Assert.Equal("Equipment 2", pagedResponse.Items.First().EquipmentName);
            Assert.Equal("Equipment 3", pagedResponse.Items.Last().EquipmentName);
        }

        [Fact]
        public async Task CreateAsync_ShouldAddEquipmentToDatabase()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var newEquipment = new Equipment
            {
                EquipmentType = "New Type",
                EquipmentName = "New Equipment"
            };

            // Act
            var createdEquipment = await dataAccess.CreateAsync(newEquipment);

            // Assert
            Assert.NotNull(createdEquipment);
            Assert.True(createdEquipment.Id > 0); // Verify that an ID was generated
            Assert.Equal(newEquipment.EquipmentType, createdEquipment.EquipmentType);
            Assert.Equal(newEquipment.EquipmentName, createdEquipment.EquipmentName);

            // Verify that the equipment was added to the database
            var equipmentInDb = await dbContext.Equipments.FindAsync(createdEquipment.Id);
            Assert.NotNull(equipmentInDb);
            Assert.Equal(createdEquipment.Id, equipmentInDb.Id);
            Assert.Equal(createdEquipment.EquipmentType, equipmentInDb.EquipmentType);
            Assert.Equal(createdEquipment.EquipmentName, equipmentInDb.EquipmentName);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateEquipmentInDatabase()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var initialEquipment = new Equipment
            {
                Id = 1,
                EquipmentType = "Initial Type",
                EquipmentName = "Initial Equipment"
            };
            dbContext.Equipments.Add(initialEquipment);
            await dbContext.SaveChangesAsync();
            dbContext.Entry(initialEquipment).State = EntityState.Detached; // Detach the entity

            var updatedEquipment = new Equipment
            {
                Id = 1,
                EquipmentType = "Updated Type",
                EquipmentName = "Updated Equipment"
            };

            // Act
            var result = await dataAccess.UpdateAsync(updatedEquipment);

            // Assert
            Assert.True(result); // Verify that the update was successful

            // Verify that the equipment was updated in the database
            var equipmentInDb = await dbContext.Equipments.FindAsync(updatedEquipment.Id);
            Assert.NotNull(equipmentInDb);
            Assert.Equal(updatedEquipment.EquipmentType, equipmentInDb.EquipmentType);
            Assert.Equal(updatedEquipment.EquipmentName, equipmentInDb.EquipmentName);
        }

        [Fact]
        public async Task DeleteAsync_ShouldRemoveEquipmentFromDatabase_WhenEquipmentExists()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            var equipmentToDelete = new Equipment
            {
                Id = 1,
                EquipmentType = "Type to Delete",
                EquipmentName = "Equipment to Delete"
            };
            dbContext.Equipments.Add(equipmentToDelete);
            await dbContext.SaveChangesAsync();

            // Act
            var result = await dataAccess.DeleteAsync(equipmentToDelete.Id);

            // Assert
            Assert.True(result); // Verify that the deletion was successful

            // Verify that the equipment was removed from the database
            var equipmentInDb = await dbContext.Equipments.FindAsync(equipmentToDelete.Id);
            Assert.Null(equipmentInDb);
        }

        [Fact]
        public async Task DeleteAsync_ShouldReturnFalse_WhenEquipmentDoesNotExist()
        {
            // Arrange
            using var dbContext = CreateInMemoryDbContext();
            var dataAccess = new EquipmentDataAccess(dbContext);

            // Act
            var result = await dataAccess.DeleteAsync(999); // Use an ID that does not exist

            // Assert
            Assert.False(result); // Verify that the deletion was not successful
        }
    }
}