using Rtls.Domain.Entities;

namespace Rtls.Tests.Utilities;

/// <summary>
/// Factory for generating common test data entities.
/// </summary>
public static class TestDataFactory
{
    public static Equipment CreateEquipment(
        long id = 0,
        string? equipmentName = null,
        string? equipmentType = null,
        int? maxWeight = null,
        int? maxTeu = null,
        string? status = null,
        string? createdBy = null,
        string? updatedBy = null)
        => new Equipment
        {
            Id = id,
            EquipmentName = equipmentName ?? "Test Equipment",
            EquipmentType = equipmentType ?? "Forklift",
            MaxWeight = maxWeight ?? 1000,
            MaxTeu = maxTeu ?? 2,
            Status = status ?? "",
            CreatedBy = createdBy ?? "TestUser",
            UpdatedBy = updatedBy ?? "TestUser",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

    public static EquipmentPool CreateEquipmentPool(
        long id = 0,
        string? poolName = null,
        string? dispatchState = null,
        string? operatingMode = null,
        string? jobStartPosition = null,
        long equipmentId = 0)
        => new EquipmentPool
        {
            Id = id,
            PoolName = poolName ?? "Test Pool",
            DispatchState = dispatchState,
            OperatingMode = operatingMode,
            JobStartPosition = jobStartPosition,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

    public static PointOfWork CreatePointOfWork(
        long id = 0,
        string? pointOfWorkName = null,
        string? createdBy = null,
        string? updatedBy = null)
        => new PointOfWork
        {
            Id = id,
            Name = pointOfWorkName ?? $"POW_{Guid.NewGuid()}",
            CreatedBy = createdBy ?? "TestUser",
            UpdatedBy = updatedBy ?? "TestUser",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

    // Additional factories for other entities can be added similarly,
    // using their actual properties and types.
    public static PowAssignment CreatePowAssignment(
        long id = 0,
        long powId = 1,
        long equipmentPoolId = 1,
        bool equipmentPoolStatus = true,
        string? createdBy = "UnitTest",
        DateTime? createdAt = null,
        string? updatedBy = null,
        DateTime? updatedAt = null)
    {
        return new PowAssignment
        {
            Id = id,
            PowId = powId,
            EquipmentPoolId = equipmentPoolId,
            EquipmentPoolStatus = equipmentPoolStatus,
            CreatedBy = createdBy,
            CreatedAt = createdAt ?? DateTime.UtcNow,
            UpdatedBy = updatedBy,
            UpdatedAt = updatedAt
        };
    }

    public static WorkInstruction CreateWorkInstruction(
        long id = 0,
        long vesselVisitId = 0,
        string? moveType = null,
        long equipmentId = 0,
        string? fromLocation = null,
        string? toLocation = null,
        string? dispatchState = null,
        string? equipmentType = null,
        string? assignedChe = null,
        string? assignedLane = null,
        string? cheCarry = null,
        string? currentPosition = null,
        string? positionOnCarriage = null,
        string? blockId = null,
        string? bayId = null,
        string? createdBy = null,
        string? updatedBy = null,
        DateTime? createdAt = null,
        DateTime? updatedAt = null,
        long powId = 0,
        long containerId = 0,
        string? containerName = null)
    {
        return new WorkInstruction
        {
            Id = id,
            VesselVisitId = vesselVisitId,
            MoveType = moveType ?? "Load",
            FromLocation = fromLocation ?? "A",
            TargetLocation = toLocation ?? "B",
            WorkInstructionStatus = dispatchState ?? "Pending",
            IsoCode = equipmentType ?? "ISO1",
            AssignedChe = assignedChe ?? "CHE1",
            CheCarry = cheCarry ?? "Carry1",
            PositionOnCarriage = positionOnCarriage ?? "PosCar1",
            PointOfWorkId = powId != 0 ? powId : 0,
            ContainerId = containerId != 0 ? containerId.ToString() : "CONT1",
            CreatedBy = createdBy ?? "creator",
            UpdatedBy = updatedBy ?? "updater",
            CreatedAt = createdAt ?? DateTime.UtcNow.AddDays(-1),
            UpdatedAt = updatedAt ?? DateTime.UtcNow.AddDays(-1)
        };
    }

    public static List<WorkInstruction> CreateWorkInstructionList(int count)
    {
        var workInstructions = new List<WorkInstruction>();
        for (int i = 0; i < count; i++)
        {
            workInstructions.Add(CreateWorkInstruction());
        }
        return workInstructions;
    }

    public static VesselVisit CreateVesselVisit(
        long id = 0,
        string? vesselClass = null,
        string? inboundVoyage = null,
        string? outboundVoyage = null,
        VesselVisitPhase? phase = null,
        string? lineOperator = null,
        DateTime? eta = null,
        DateTime? etd = null,
        long vesselId = 0,
        string? createdBy = null,
        string? updatedBy = null,
        DateTime? createdAt = null,
        DateTime? updatedAt = null)
    {
        return new VesselVisit
        {
            Id = id,
            InboundVoyage = inboundVoyage ?? "IN123",
            OutboundVoyage = outboundVoyage ?? "OUT456",
            Phase = phase ?? VesselVisitPhase.Inbound,
            LineOperator = lineOperator ?? "OperatorX",
            Eta = eta ?? DateTime.UtcNow.AddDays(1),
            Etd = etd ?? DateTime.UtcNow.AddDays(2),
            VesselId = vesselId,
            CreatedBy = createdBy ?? "creator",
            UpdatedBy = updatedBy ?? "updater",
            CreatedAt = createdAt ?? DateTime.UtcNow.AddDays(-1),
            UpdatedAt = updatedAt ?? DateTime.UtcNow
        };
    }

    public static List<VesselVisit> CreateVesselVisitList(int count)
    {
        var vesselVisits = new List<VesselVisit>();
        for (int i = 0; i < count; i++)
        {
            vesselVisits.Add(CreateVesselVisit());
        }
        return vesselVisits;
    }

    public static VesselBerthing CreateVesselBerthing(
        long id = 0,
        string? quay = null,
        string? berthingSide = null,
        string? bollard = null,
        DateTime? berthEta = null,
        DateTime? berthEtd = null,
        DateTime? berthAta = null,
        DateTime? startWorkTime = null,
        int? bollardFore = null,
        int? bollardAft = null,
        long vesselVisitId = 0,
        string? createdBy = null,
        string? updatedBy = null)
    {
        return new VesselBerthing
        {
            Id = id,
            Quay = quay ?? "Q1",
            BerthingSide = BerthingSide.Port,
            StartBollard = bollard ?? "B1",
            EndBollard = bollard ?? "B2",
            BerthEta = berthEta ?? DateTime.UtcNow.AddHours(1),
            BerthEtd = berthEtd ?? DateTime.UtcNow.AddHours(5),
            BerthAta = berthAta ?? DateTime.UtcNow.AddHours(2),
            StartWorkTime = startWorkTime ?? DateTime.UtcNow.AddHours(3),
            VesselVisitId = vesselVisitId,
            CreatedBy = createdBy ?? "TestUser",
            UpdatedBy = updatedBy ?? "TestUser",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }

    public static List<VesselBerthing> CreateVesselBerthingList(int count)
    {
        var vesselBerthings = new List<VesselBerthing>();
        for (int i = 0; i < count; i++)
        {
            vesselBerthings.Add(CreateVesselBerthing(i + 1));
        }
        return vesselBerthings;
    }

    public static Vessel CreateVessel(
        long id = 0,
        string? vesselName = null,
        int? overallLength = null,
        string? lordsIdentity = null,
        string? vesselClass = null,
        string? radioCallSign = null,
        string? operatorName = null,
        bool? status = null,
        string? createdBy = null,
        string? updatedBy = null)
    {
        return new Vessel
        {
            Id = id,
            VesselName = vesselName ?? $"Vessel_{id}",
            OverallLength = overallLength ?? 200,
            LloydsIdentity = lordsIdentity ?? $"L{id}",
            VesselClass = vesselClass ?? "Class A",
            RadioCallSign = radioCallSign ?? $"CALL{id}",
            Operator = operatorName ?? "OperatorX",
            Status = status ?? true,
            CreatedBy = createdBy ?? "TestUser",
            UpdatedBy = updatedBy ?? "TestUser",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }

    public static List<Vessel> CreateVesselList(int count)
    {
        var vessels = new List<Vessel>();
        for (int i = 0; i < count; i++)
        {
            vessels.Add(CreateVessel(i + 1));
        }
        return vessels;
    }
    public static EquipmentPoolAssignment CreateEquipmentPoolAssignment(
        long id = 0,
        long equipmentPoolId = 1,
        long equipmentId = 1,
        DateTime? assignedDate = null,
        bool? assignmentStatus = null,
        string? createdBy = null,
        string? updatedBy = null,
        DateTime? createdAt = null,
        DateTime? updatedAt = null)
    {
        return new EquipmentPoolAssignment
        {
            Id = id,
            EquipmentPoolId = equipmentPoolId,
            EquipmentId = equipmentId,
            EquipmentAssignedDate = assignedDate ?? DateTime.UtcNow,
            AssignmentStatus = assignmentStatus,
            CreatedBy = createdBy,
            UpdatedBy = updatedBy,
            CreatedAt = createdAt ?? DateTime.UtcNow,
            UpdatedAt = updatedAt ?? DateTime.UtcNow
        };
    }
}
