using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;

namespace Rtls.Tests.Utilities;

/// <summary>
/// Base class for repository tests providing isolated in-memory database setup.
/// </summary>
public abstract class DbContextTestBase
{
    /// <summary>
    /// Creates new DbContextOptions with a unique in-memory database name for isolation.
    /// </summary>
    protected DbContextOptions<AppDbContext> CreateNewContextOptions()
    {
        var builder = new DbContextOptionsBuilder<AppDbContext>();
        builder.UseInMemoryDatabase($"TestDb_{Guid.NewGuid()}");
        builder.EnableSensitiveDataLogging();
        return builder.Options;
    }

    /// <summary>
    /// Creates a new AppDbContext instance with a unique in-memory database.
    /// Configures the context to ignore Identity entities to avoid EF Core InMemory provider issues.
    /// </summary>
    protected AppDbContext CreateContext()
    {
        var options = CreateNewContextOptions();

        // Create a custom DbContext that ignores Identity entities
        var context = new TestAppDbContext(options);
        context.Database.EnsureDeleted();
        context.Database.EnsureCreated();
        return context;
    }

    /// <summary>
    /// Custom AppDbContext for testing that ignores Identity entities
    /// </summary>
    private class TestAppDbContext : AppDbContext
    {
        public TestAppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Skip calling base.OnModelCreating to avoid Identity configuration
            // Configure only the entities needed for tests

            // Ignore Identity entities
            modelBuilder.Ignore<IdentityUserLogin<string>>();
            modelBuilder.Ignore<IdentityUserRole<string>>();
            modelBuilder.Ignore<IdentityUserClaim<string>>();
            modelBuilder.Ignore<IdentityUserToken<string>>();
            modelBuilder.Ignore<IdentityUser>();
            modelBuilder.Ignore<ApplicationUser>();

            // Configure all entities needed for tests with explicit primary keys
            modelBuilder.Entity<Equipment>().HasKey(e => e.Id);
            modelBuilder.Entity<EquipmentPool>().HasKey(e => e.Id);
            modelBuilder.Entity<EquipmentPoolAssignment>().HasKey(e => e.Id);
            modelBuilder.Entity<PointOfWork>().HasKey(e => e.Id);
            modelBuilder.Entity<PowAssignment>().HasKey(e => e.Id);
            modelBuilder.Entity<Vessel>().HasKey(e => e.Id);
            modelBuilder.Entity<VesselVisit>().HasKey(e => e.Id);
            modelBuilder.Entity<WorkInstruction>().HasKey(e => e.Id);

            // Configure VesselBerthing with explicit foreign key relationships
            modelBuilder.Entity<VesselBerthing>().HasKey(e => e.Id);
            modelBuilder.Entity<VesselBerthing>()
                .HasOne(vb => vb.VesselVisit)
                .WithOne(x => x.VesselBerthing)
                .HasForeignKey<VesselBerthing>(x => x.VesselVisitId)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure EquipmentPoolAssignment relationships
            modelBuilder.Entity<EquipmentPoolAssignment>()
                .HasOne(epa => epa.EquipmentPool)
                .WithMany()
                .HasForeignKey("EquipmentPoolId")
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<EquipmentPoolAssignment>()
                .HasOne(epa => epa.Equipment)
                .WithMany()
                .HasForeignKey("EquipmentId")
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure PowAssignment relationships
            modelBuilder.Entity<PowAssignment>()
                .HasOne(pa => pa.PointOfWork)
                .WithMany()
                .HasForeignKey("PowId")
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<PowAssignment>()
                .HasOne(pa => pa.EquipmentPool)
                .WithMany()
                .HasForeignKey("EquipmentPoolId")
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure WorkInstruction relationships
            modelBuilder.Entity<WorkInstruction>()
                .HasOne(wi => wi.VesselVisit)
                .WithMany()
                .HasForeignKey("VesselVisitId")
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}