using Testcontainers.PostgreSql;

namespace Rtls.Tests;

public class DbTestCase : IAsyncLifetime
{
    private readonly PostgreSqlContainer _postgres = new PostgreSqlBuilder()
        .WithImage("postgres:16")
        .WithCleanUp(true)
        .Build();

    public Task DisposeAsync()
    {
        return _postgres.DisposeAsync().AsTask();
    }

    public Task InitializeAsync()
    {
        return _postgres.StartAsync();
    }

    [Fact]
    public void Test_Test()
    {
        _postgres.GetConnectionString();
        Assert.True(true);
    }
}