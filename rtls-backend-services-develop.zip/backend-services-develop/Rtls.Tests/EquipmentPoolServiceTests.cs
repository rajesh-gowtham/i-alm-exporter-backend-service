using Moq;
using Rtls.Application.Services;
using Rtls.Domain.Entities;
using Rtls.Tests.Utilities;
using Rtls.Domain.Database;
using Microsoft.EntityFrameworkCore;
using Rtls.Application.Interfaces;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Rtls.Application.Models;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Tests;

public class EquipmentPoolServiceTests : DbContextTestBase
{

    private readonly AppDbContext _dbContext;
    private readonly EquipmentPoolService _service;
    private readonly Mock<ICurrentUserService> _mockCurrentUserService;
    private readonly Mock<ILogger<EquipmentPoolService>> _mockLogger;
    private readonly Mock<IMapper> _mockMapper;
    private readonly Mock<IEquipmentPoolDataAccess> _mockDataAccess;
    private readonly Mock<IEquipmentPoolAssignmentDataAccess> _mockPoolAssignDataAccess;

    public EquipmentPoolServiceTests()
    {
        _dbContext = CreateContext();
        _mockCurrentUserService = new Mock<ICurrentUserService>();
        _mockLogger = new Mock<ILogger<EquipmentPoolService>>();
        _mockMapper = new Mock<IMapper>();
        _mockDataAccess = new Mock<IEquipmentPoolDataAccess>();
        _mockPoolAssignDataAccess = new Mock<IEquipmentPoolAssignmentDataAccess>();

        // Configure the mock data access to use the in-memory database context
        _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((long id, CancellationToken ct) => _dbContext.EquipmentPools.FirstOrDefault(p => p.Id == id));
        _mockDataAccess.Setup(d => d.CreateAsync(It.IsAny<EquipmentPool>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((EquipmentPool pool, CancellationToken ct) =>
            {
                _dbContext.EquipmentPools.Add(pool);
                _dbContext.SaveChanges(); // Use SaveChanges for synchronous in-memory DB
                return pool;
            });
         _mockDataAccess.Setup(d => d.UpdateAsync(It.IsAny<EquipmentPool>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((EquipmentPool pool, CancellationToken ct) =>
            {
                _dbContext.EquipmentPools.Update(pool);
                _dbContext.SaveChanges();
                return true; // Assuming update is always successful in this test context
            });
        _mockDataAccess.Setup(d => d.DeleteAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((long id, CancellationToken ct) =>
            {
                var poolToDelete = _dbContext.EquipmentPools.FirstOrDefault(p => p.Id == id);
                if (poolToDelete == null) return false;
                _dbContext.EquipmentPools.Remove(poolToDelete);
                _dbContext.SaveChanges();
                return true; // Assuming delete is always successful if entity exists
            });
         _mockDataAccess.Setup(d => d.GetAllAsync(It.IsAny<int>(), It.IsAny<int?>(), "", It.IsAny<CancellationToken>()))
             .ReturnsAsync((int skip, int? take, CancellationToken ct) =>
             {
                 var query = _dbContext.EquipmentPools.AsQueryable();
                 var total = query.Count();
                 var items = take.HasValue ? query.Skip(skip).Take(take.Value).ToArray() : query.Skip(skip).ToArray();
                 return new PagedResponse<EquipmentPool>(total, items);
             });


        _service = new EquipmentPoolService(
            _mockCurrentUserService.Object,
            _mockLogger.Object,
            _mockMapper.Object,
            _mockDataAccess.Object,
            _mockPoolAssignDataAccess.Object
        );
    }

    // [Fact]
    // public async Task GetAllAsync_ShouldReturnAllPools_WhenRepositoryReturnsEntities()
    // {
    //     // Arrange
    //     var pools = new List<EquipmentPool>
    //     {
    //         TestDataFactory.CreateEquipmentPool(1, poolName: "Pool A", equipmentId: 1),
    //         TestDataFactory.CreateEquipmentPool(2, poolName: "Pool B", equipmentId: 2)
    //     };
    //     MockRepository.Setup(r => r.GetAllAsync()).ReturnsAsync(pools);

    //     // Act
    //     var result = await Service.GetAllAsync();

    //     // Assert
    //     Assert.NotNull(result);
    //     Assert.Equal(2, ((List<EquipmentPool>)result).Count);
    // }

    /// <summary>
    /// Should return equipment pool when entity with given ID exists.
    /// </summary>
    [Fact]
    public async Task GetByIdAsync_ShouldReturnPool_WhenEntityExists()
    {
        // Arrange
        var pool = TestDataFactory.CreateEquipmentPool(1, poolName: "Pool A", equipmentId: 1);
        _dbContext.EquipmentPools.Add(pool);
        await _dbContext.SaveChangesAsync();

        var poolDto = new EquipmentPoolDto(
            pool.Id,
            pool.PoolName,
            "DispatchState",
            "OperatingMode",
            "JobStartPosition",
            "CreatedBy",
            "UpdatedBy",
            DateTime.UtcNow,
            DateTime.UtcNow
        );
        _mockMapper.Setup(m => m.Map<EquipmentPoolDto>(It.IsAny<EquipmentPool>())).Returns(poolDto);

        // Act
        var result = await _service.GetByIdAsync(1);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(1, result.Id);
    }

    /// <summary>
    /// Should return null when equipment pool with given ID does not exist.
    /// </summary>
    [Fact]
    public async Task GetByIdAsync_ShouldReturnNull_WhenEntityDoesNotExist()
    {
        // Arrange
        // No entity added, so GetByIdAsync should return null

        // Act
        var result = await _service.GetByIdAsync(99);

        // Assert
        Assert.Null(result);
    }

    /// <summary>
    /// Should add equipment pool and call repository CreateAsync once.
    /// </summary>
    [Fact]
    public async Task CreateAsync_ShouldAddPool_WhenDtoIsValid()
    {
        // Arrange
        var createDto = new CreateEquipmentPoolDto(
            "Pool C",
            "DispatchState",
            "OperatingMode",
            "JobStartPosition"
        );
        var poolEntity = TestDataFactory.CreateEquipmentPool(0, poolName: createDto.PoolName);
        var createdPoolEntity = TestDataFactory.CreateEquipmentPool(3, poolName: createDto.PoolName); // Simulate DB assigning ID
        var createdPoolDto = new EquipmentPoolDto(
            createdPoolEntity.Id,
            createdPoolEntity.PoolName,
            "DispatchState",
            "OperatingMode",
            "JobStartPosition",
            "CreatedBy",
            "UpdatedBy",
            DateTime.UtcNow,
            DateTime.UtcNow
        );

        _mockMapper.Setup(m => m.Map<EquipmentPool>(It.IsAny<CreateEquipmentPoolDto>())).Returns(poolEntity);
        _mockMapper.Setup(m => m.Map<EquipmentPoolDto>(It.IsAny<EquipmentPool>())).Returns(createdPoolDto);
        _mockCurrentUserService.Setup(s => s.GetUsername()).Returns("testuser");

        // Act
        var result = await _service.CreateAsync(createDto);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(createdPoolDto.Id, result.Id);
        Assert.Equal(createdPoolDto.PoolName, result.PoolName);

        _mockDataAccess.Verify(d => d.CreateAsync(It.Is<EquipmentPool>(pool =>
            pool.PoolName == poolEntity.PoolName
        ), It.IsAny<CancellationToken>()), Times.Once);
    }

    /// <summary>
    /// Should update equipment pool and call repository UpdateAsync once.
    /// </summary>
    [Fact]
    public async Task UpdateAsync_ShouldUpdatePool_WhenDtoIsValid()
    {
        // Arrange
        var existingPool = TestDataFactory.CreateEquipmentPool(1, poolName: "Old Pool", equipmentId: 99);
        _dbContext.EquipmentPools.Add(existingPool);
        await _dbContext.SaveChangesAsync();
        _dbContext.Entry(existingPool).State = EntityState.Detached; // Detach to simulate a real scenario

        var updateDto = new UpdateEquipmentPoolDto(
            1,
            "Updated Pool",
            "DispatchState",
            "OperatingMode",
            "JobStartPosition"
        );
        var updatedPoolEntity = TestDataFactory.CreateEquipmentPool(updateDto.Id, poolName: updateDto.PoolName);

        _mockMapper.Setup(m => m.Map(It.IsAny<UpdateEquipmentPoolDto>(), It.IsAny<EquipmentPool>())).Callback<UpdateEquipmentPoolDto, EquipmentPool>((dto, entity) =>
        {
            entity.PoolName = dto.PoolName;
        });
        _mockCurrentUserService.Setup(s => s.GetUsername()).Returns("testuser");


        // Act
        var result = await _service.UpdateAsync(updateDto);

        // Assert
        Assert.True(result);

        var updatedPool = await _dbContext.EquipmentPools.FirstOrDefaultAsync(p => p.Id == updateDto.Id);
        Assert.NotNull(updatedPool);
        Assert.Equal(updateDto.PoolName, updatedPool.PoolName);
    }

    /// <summary>
    /// Should delete equipment pool and call repository DeleteAsync once.
    /// </summary>
    [Fact]
    public async Task DeleteAsync_ShouldDeletePool_WhenIdIsValid()
    {
        // Arrange
        var id = 1;
        // Add an existing entity to delete
        var entityToDelete = TestDataFactory.CreateEquipmentPool(id, poolName: "To Delete", equipmentId: 99);
        _dbContext.EquipmentPools.Add(entityToDelete);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _service.DeleteAsync(id);

        // Assert
        Assert.True(result);
        var deletedPool = await _dbContext.EquipmentPools.FirstOrDefaultAsync(p => p.Id == id);
        Assert.Null(deletedPool);
    }
}