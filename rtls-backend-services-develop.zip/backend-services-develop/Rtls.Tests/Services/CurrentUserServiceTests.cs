using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Rtls.Application.Services;
using System.Security.Claims;

namespace Rtls.Tests.Services
{
    public class CurrentUserServiceTests
    {
        private readonly Mock<IHttpContextAccessor> _mockHttpContextAccessor;
        private readonly Mock<ILogger<CurrentUserService>> _mockLogger;
        private readonly CurrentUserService _currentUserService;

        public CurrentUserServiceTests()
        {
            _mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
            _mockLogger = new Mock<ILogger<CurrentUserService>>();
            _currentUserService = new CurrentUserService(_mockHttpContextAccessor.Object, _mockLogger.Object);
        }

        [Fact]
        public void GetUsername_ShouldReturnUsername_WhenUserIsAuthenticated()
        {
            // Arrange
            var claims = new[] { new Claim(ClaimTypes.Name, "testuser") };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var principal = new ClaimsPrincipal(identity);
            var httpContext = new DefaultHttpContext { User = principal };
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var username = _currentUserService.GetUsername();

            // Assert
            Assert.Equal("testuser", username);
        }

        [Fact]
        public void GetUsername_ShouldReturnSystem_WhenUserIsNotAuthenticated()
        {
            // Arrange
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(new DefaultHttpContext());

            // Act
            var username = _currentUserService.GetUsername();

            // Assert
            Assert.Equal("System", username);
        }

        [Fact]
        public void GetUserId_ShouldReturnUserId_WhenUserIsAuthenticatedWithUserIdClaim()
        {
            // Arrange
            var claims = new[] { new Claim(ClaimTypes.NameIdentifier, "user123") };
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var principal = new ClaimsPrincipal(identity);
            var httpContext = new DefaultHttpContext { User = principal };
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var userId = _currentUserService.GetUserId();

            // Assert
            Assert.Equal("user123", userId);
        }

        [Fact]
        public void GetUserId_ShouldReturnNull_WhenUserIsAuthenticatedWithoutUserIdClaim()
        {
            // Arrange
            var claims = new[] { new Claim(ClaimTypes.Name, "testuser") }; // No NameIdentifier claim
            var identity = new ClaimsIdentity(claims, "TestAuth");
            var principal = new ClaimsPrincipal(identity);
            var httpContext = new DefaultHttpContext { User = principal };
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var userId = _currentUserService.GetUserId();

            // Assert
            Assert.Null(userId);
        }

        [Fact]
        public void GetUserId_ShouldReturnNull_WhenUserIsNotAuthenticated()
        {
            // Arrange
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(new DefaultHttpContext());

            // Act
            var userId = _currentUserService.GetUserId();

            // Assert
            Assert.Null(userId);
        }

        // TODO: Add tests for IsAuthenticated
        [Fact]
        public void IsAuthenticated_ShouldReturnTrue_WhenUserIsAuthenticated()
        {
            // Arrange
            var identity = new ClaimsIdentity("TestAuth");
            var principal = new ClaimsPrincipal(identity);
            var httpContext = new DefaultHttpContext { User = principal };
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var isAuthenticated = _currentUserService.IsAuthenticated();

            // Assert
            Assert.True(isAuthenticated);
        }

        [Fact]
        public void IsAuthenticated_ShouldReturnFalse_WhenUserIsNotAuthenticated()
        {
            // Arrange
            _mockHttpContextAccessor.Setup(x => x.HttpContext).Returns(new DefaultHttpContext());

            // Act
            var isAuthenticated = _currentUserService.IsAuthenticated();

            // Assert
            Assert.False(isAuthenticated);
        }
    }
}