//using AutoMapper;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Logging;
//using Moq;
//using Rtls.Application.Interfaces;
//using Rtls.Application.Models;
//using Rtls.Application.Services;
//using Rtls.Domain.Database;
//using Rtls.Domain.Entities;
//using Rtls.Domain.Interfaces;
//using Rtls.Domain.Models;
//using Rtls.Tests.Utilities; // Assuming TestDataFactory is in this namespace
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading;
//using System.Threading.Tasks;
//using Xunit;

//namespace Rtls.Tests.Services
//{
//    public class EquipmentPoolAssignmentServiceTests : DbContextTestBase // Assuming DbContextTestBase is in Utilities
//    {
//        private readonly AppDbContext _dbContext;
//        private readonly EquipmentPoolAssignmentService _service;
//        private readonly Mock<ICurrentUserService> _mockCurrentUserService;
//        private readonly Mock<ILogger<EquipmentPoolAssignmentService>> _mockLogger;
//        private readonly Mock<IMapper> _mockMapper;
//        private readonly Mock<IEquipmentPoolAssignmentDataAccess> _mockDataAccess;

//        public EquipmentPoolAssignmentServiceTests()
//        {
//            _dbContext = CreateContext(); // From DbContextTestBase
//            _mockCurrentUserService = new Mock<ICurrentUserService>();
//            _mockLogger = new Mock<ILogger<EquipmentPoolAssignmentService>>();
//            _mockMapper = new Mock<IMapper>();
//            _mockDataAccess = new Mock<IEquipmentPoolAssignmentDataAccess>();

//            // Configure the mock data access to use the in-memory database context
//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync((long id, CancellationToken ct) => _dbContext.EquipmentPoolAssignments.FirstOrDefault(a => a.Id == id));
//            _mockDataAccess.Setup(d => d.CreateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync((EquipmentPoolAssignment assignment, CancellationToken ct) =>
//                {
//                    _dbContext.EquipmentPoolAssignments.Add(assignment);
//                    _dbContext.SaveChanges(); // Use SaveChanges for synchronous in-memory DB
//                    return assignment;
//                });
//             _mockDataAccess.Setup(d => d.UpdateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync((EquipmentPoolAssignment assignment, CancellationToken ct) =>
//                {
//                    _dbContext.EquipmentPoolAssignments.Update(assignment);
//                    _dbContext.SaveChanges();
//                    return true; // Assuming update is always successful in this test context
//                });
//            _mockDataAccess.Setup(d => d.DeleteAsync(It.IsAny<long>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync((long id, CancellationToken ct) =>
//                {
//                    var assignmentToDelete = _dbContext.EquipmentPoolAssignments.FirstOrDefault(a => a.Id == id);
//                    if (assignmentToDelete == null) return false;
//                    _dbContext.EquipmentPoolAssignments.Remove(assignmentToDelete);
//                    _dbContext.SaveChanges();
//                    return true; // Assuming delete is always successful if entity exists
//                });
//             _mockDataAccess.Setup(d => d.GetAllAsync(It.IsAny<int>(), It.IsAny<int?>(), It.IsAny<CancellationToken>()))
//                 .ReturnsAsync((int skip, int? take, CancellationToken ct) =>
//                 {
//                     var query = _dbContext.EquipmentPoolAssignments.AsQueryable();
//                     var total = query.Count();
//                     var items = take.HasValue ? query.Skip(skip).Take(take.Value).ToArray() : query.Skip(skip).ToArray();
//                     return new PagedResponse<EquipmentPoolAssignment>(total, items);
//                 });


//            _service = new EquipmentPoolAssignmentService(
//                _mockCurrentUserService.Object,
//                _mockLogger.Object,
//                _mockMapper.Object,
//                _mockDataAccess.Object
//            );
//        }

//        [Fact]
//        public async Task GetAllAsync_ShouldReturnEmptyPagedResponse_WhenDataAccessReturnsEmpty()
//        {
//            // Arrange
//            _mockDataAccess.Setup(d => d.GetAllAsync(It.IsAny<int>(), It.IsAny<int?>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync(PagedResponse<EquipmentPoolAssignment>.Empty);

//            // Act
//            var result = await _service.GetAllAsync();

//            // Assert
//            Assert.NotNull(result);
//            Assert.Equal(0, result.TotalCount);
//            Assert.Empty(result.Items);
//        }

//        [Fact]
//        public async Task GetAllAsync_ShouldReturnMappedPagedResponse_WhenDataAccessReturnsEntities()
//        {
//            // Arrange
//            var assignments = new[]
//            {
//                new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow },
//                new EquipmentPoolAssignment { Id = 2, EquipmentPoolId = 1, EquipmentId = 2, AssignmentStatus = false, EquipmentAssignedDate = DateTime.UtcNow.AddHours(1) }
//            };
//            var assignmentDtos = new[]
//            {
//                new EquipmentPoolAssignmentDto { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow, CreatedBy = "user1", UpdatedBy = "user1", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
//                new EquipmentPoolAssignmentDto { Id = 2, EquipmentPoolId = 1, EquipmentId = 2, AssignmentStatus = false, EquipmentAssignedDate = DateTime.UtcNow.AddHours(1), CreatedBy = "user2", UpdatedBy = "user2", CreatedAt = DateTime.UtcNow.AddHours(1), UpdatedAt = DateTime.UtcNow.AddHours(1) }
//            };
//            _mockDataAccess.Setup(d => d.GetAllAsync(It.IsAny<int>(), It.IsAny<int?>(), It.IsAny<CancellationToken>()))
//                .ReturnsAsync(new PagedResponse<EquipmentPoolAssignment>(assignments.Length, assignments));
//            _mockMapper.Setup(m => m.Map<IEnumerable<EquipmentPoolAssignmentDto>>(It.IsAny<IEnumerable<EquipmentPoolAssignment>>())).Returns(assignmentDtos);

//            // Act
//            var result = await _service.GetAllAsync();

//            // Assert
//            Assert.NotNull(result);
//            Assert.Equal(assignments.Length, result.TotalCount);
//            Assert.Equal(assignmentDtos.Length, result.Items.Count());
//            // Add more specific assertions about the returned DTOs if needed
//        }

//        [Fact]
//        public async Task GetByIdAsync_ShouldReturnMappedDto_WhenDataAccessReturnsEntity()
//        {
//            // Arrange
//            var assignment = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow };
//            var assignmentDto = new EquipmentPoolAssignmentDto { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow, CreatedBy = "user1", UpdatedBy = "user1", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };

//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync(assignment);
//            _mockMapper.Setup(m => m.Map<EquipmentPoolAssignmentDto>(It.IsAny<EquipmentPoolAssignment>())).Returns(assignmentDto);

//            // Act
//            var result = await _service.GetByIdAsync(1);

//            // Assert
//            Assert.NotNull(result);
//            Assert.Equal(assignmentDto.Id, result.Id);
//            Assert.Equal(assignmentDto.EquipmentPoolId, result.EquipmentPoolId);
//            Assert.Equal(assignmentDto.EquipmentId, result.EquipmentId);
//            Assert.Equal(assignmentDto.AssignmentStatus, result.AssignmentStatus);
//            Assert.Equal(assignmentDto.EquipmentAssignedDate, result.EquipmentAssignedDate);
//        }

//        [Fact]
//        public async Task GetByIdAsync_ShouldReturnNull_WhenDataAccessReturnsNull()
//        {
//            // Arrange
//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync((EquipmentPoolAssignment?)null);

//            // Act
//            var result = await _service.GetByIdAsync(999);

//            // Assert
//            Assert.Null(result);
//        }

//        [Fact]
//        public async Task CreateAsync_ShouldCreateAssignment_WhenDtoIsValid()
//        {
//            // Arrange
//            var createDto = new CreateEquipmentPoolAssignmentDto
//            {
//                EquipmentPoolId = 1,
//                EquipmentId = 1,
//                AssignmentStatus = true,
//                EquipmentAssignedDate = DateTime.UtcNow
//            };
//            var assignmentEntity = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow };
//            var assignmentDto = new EquipmentPoolAssignmentDto { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow, CreatedBy = "testuser", UpdatedBy = "testuser", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };

//            _mockMapper.Setup(m => m.Map<EquipmentPoolAssignment>(It.IsAny<CreateEquipmentPoolAssignmentDto>())).Returns(assignmentEntity);
//            _mockCurrentUserService.Setup(s => s.GetUsername()).Returns("testuser");
//            _mockDataAccess.Setup(d => d.CreateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>())).ReturnsAsync(assignmentEntity);
//            _mockMapper.Setup(m => m.Map<EquipmentPoolAssignmentDto>(It.IsAny<EquipmentPoolAssignment>())).Returns(assignmentDto);

//            // Act
//            var result = await _service.CreateAsync(createDto);

//            // Assert
//            Assert.NotNull(result);
//            Assert.Equal(assignmentDto.Id, result.Id);
//            Assert.Equal(assignmentDto.EquipmentPoolId, result.EquipmentPoolId);
//            Assert.Equal(assignmentDto.EquipmentId, result.EquipmentId);
//            Assert.Equal(assignmentDto.AssignmentStatus, result.AssignmentStatus);
//            Assert.Equal(assignmentDto.EquipmentAssignedDate, result.EquipmentAssignedDate);
//            _mockDataAccess.Verify(d => d.CreateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>()), Times.Once);
//        }

//        [Fact]
//        public async Task CreateAsync_ShouldThrowArgumentNullException_WhenDtoIsNull()
//        {
//            // Arrange
//            CreateEquipmentPoolAssignmentDto? createDto = null;

//            // Act & Assert
//            await Assert.ThrowsAsync<ArgumentNullException>(() => _service.CreateAsync(createDto!));
//        }

//        [Theory]
//        [InlineData(0, 1)] // Invalid EquipmentPoolId
//        [InlineData(1, 0)] // Invalid EquipmentId
//        public async Task CreateAsync_ShouldThrowArgumentException_WhenValidationFails(long equipmentPoolId, long equipmentId)
//        {
//            // Arrange
//            var createDto = new CreateEquipmentPoolAssignmentDto
//            {
//                EquipmentPoolId = equipmentPoolId,
//                EquipmentId = equipmentId,
//                AssignmentStatus = true,
//                EquipmentAssignedDate = DateTime.UtcNow
//            };

//            // Act & Assert
//            await Assert.ThrowsAsync<ArgumentException>(() => _service.CreateAsync(createDto));
//        }


//        [Fact]
//        public async Task UpdateAsync_ShouldUpdateAssignment_WhenDtoIsValidAndEntityExists()
//        {
//            // Arrange
//            var updateDto = new UpdateEquipmentPoolAssignmentDto
//            {
//                Id = 1,
//                EquipmentPoolId = 2,
//                EquipmentId = 3,
//                AssignmentStatus = false,
//                EquipmentAssignedDate = DateTime.UtcNow.AddHours(1)
//            };
//            var existingAssignment = new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow };

//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync(existingAssignment);
//            _mockMapper.Setup(m => m.Map(It.IsAny<UpdateEquipmentPoolAssignmentDto>(), It.IsAny<EquipmentPoolAssignment>())).Callback<UpdateEquipmentPoolAssignmentDto, EquipmentPoolAssignment>((dto, entity) =>
//            {
//                entity.EquipmentPoolId = dto.EquipmentPoolId;
//                entity.EquipmentId = dto.EquipmentId;
//                entity.AssignmentStatus = dto.AssignmentStatus;
//                entity.EquipmentAssignedDate = dto.EquipmentAssignedDate;
//            });
//            _mockCurrentUserService.Setup(s => s.GetUsername()).Returns("testuser");
//            _mockDataAccess.Setup(d => d.UpdateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>())).ReturnsAsync(true);

//            // Act
//            var result = await _service.UpdateAsync(updateDto);

//            // Assert
//            Assert.True(result);
//            _mockDataAccess.Verify(d => d.GetByIdAsync(updateDto.Id, It.IsAny<CancellationToken>()), Times.Once);
//            _mockMapper.Verify(m => m.Map(updateDto, existingAssignment), Times.Once);
//            _mockDataAccess.Verify(d => d.UpdateAsync(existingAssignment, It.IsAny<CancellationToken>()), Times.Once);
//        }

//        [Fact]
//        public async Task UpdateAsync_ShouldReturnFalse_WhenEntityDoesNotExist()
//        {
//            // Arrange
//            var updateDto = new UpdateEquipmentPoolAssignmentDto { Id = 999, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow };
//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync((EquipmentPoolAssignment?)null);

//            // Act
//            var result = await _service.UpdateAsync(updateDto);

//            // Assert
//            Assert.False(result);
//            _mockDataAccess.Verify(d => d.GetByIdAsync(updateDto.Id, It.IsAny<CancellationToken>()), Times.Once);
//            _mockDataAccess.Verify(d => d.UpdateAsync(It.IsAny<EquipmentPoolAssignment>(), It.IsAny<CancellationToken>()), Times.Never);
//        }

//        [Fact]
//        public async Task UpdateAsync_ShouldThrowArgumentNullException_WhenDtoIsNull()
//        {
//            // Arrange
//            UpdateEquipmentPoolAssignmentDto? updateDto = null;

//            // Act & Assert
//            await Assert.ThrowsAsync<ArgumentNullException>(() => _service.UpdateAsync(updateDto!));
//        }

//        [Theory]
//        [InlineData(0, 1, 1)] // Invalid Id
//        [InlineData(1, 0, 1)] // Invalid EquipmentPoolId
//        [InlineData(1, 1, 0)] // Invalid EquipmentId
//        public async Task UpdateAsync_ShouldThrowArgumentException_WhenValidationFails(long id, long equipmentPoolId, long equipmentId)
//        {
//            // Arrange
//            var updateDto = new UpdateEquipmentPoolAssignmentDto
//            {
//                Id = id,
//                EquipmentPoolId = equipmentPoolId,
//                EquipmentId = equipmentId,
//                AssignmentStatus = true,
//                EquipmentAssignedDate = DateTime.UtcNow
//            };
//            // Mock GetByIdAsync to return a non-null entity to reach validation
//            _mockDataAccess.Setup(d => d.GetByIdAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync(new EquipmentPoolAssignment { Id = 1, EquipmentPoolId = 1, EquipmentId = 1, AssignmentStatus = true, EquipmentAssignedDate = DateTime.UtcNow });


//            // Act & Assert
//            await Assert.ThrowsAsync<ArgumentException>(() => _service.UpdateAsync(updateDto));
//        }

//        [Fact]
//        public async Task DeleteAsync_ShouldReturnTrue_WhenDataAccessReturnsTrue()
//        {
//            // Arrange
//            _mockDataAccess.Setup(d => d.DeleteAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync(true);

//            // Act
//            var result = await _service.DeleteAsync(1);

//            // Assert
//            Assert.True(result);
//            _mockDataAccess.Verify(d => d.DeleteAsync(1, It.IsAny<CancellationToken>()), Times.Once);
//        }

//        [Fact]
//        public async Task DeleteAsync_ShouldReturnFalse_WhenDataAccessReturnsFalse()
//        {
//            // Arrange
//            _mockDataAccess.Setup(d => d.DeleteAsync(It.IsAny<long>(), It.IsAny<CancellationToken>())).ReturnsAsync(false);

//            // Act
//            var result = await _service.DeleteAsync(999);

//            // Assert
//            Assert.False(result);
//            _mockDataAccess.Verify(d => d.DeleteAsync(999, It.IsAny<CancellationToken>()), Times.Once);
//        }

//        [Theory]
//        [InlineData(0, 1, 1)] // Invalid Id
//        [InlineData(1, 0, 1)] // Invalid EquipmentPoolId
//        [InlineData(1, 1, 0)] // Invalid EquipmentId
//        public void ValidateEquipmentPoolAssignmentData_Update_ShouldThrowArgumentException_WhenValidationFails(long id, long equipmentPoolId, long equipmentId)
//        {
//            // Arrange
//            var updateDto = new UpdateEquipmentPoolAssignmentDto
//            {
//                Id = id,
//                EquipmentPoolId = equipmentPoolId,
//                EquipmentId = equipmentId,
//                AssignmentStatus = true,
//                EquipmentAssignedDate = DateTime.UtcNow
//            };

//            // Act & Assert
//            // Use reflection to access the private method
//            var serviceType = typeof(EquipmentPoolAssignmentService);
//            // Ensure the method exists
//            var methodInfo = serviceType.GetMethod(
//                "ValidateEquipmentPoolAssignmentData",
//                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance,
//                null,
//                new[] { typeof(UpdateEquipmentPoolAssignmentDto) },
//                null
//            );

//            // Guard against null methodInfo
//            Assert.True(methodInfo != null, "Private method 'ValidateEquipmentPoolAssignmentData' not found");

//            // Safely invoke the method
//            var exception = Record.Exception(() => methodInfo.Invoke(_service, new object[] { updateDto }));

//            Assert.NotNull(exception);
//            var innerException = exception.InnerException as ArgumentException;
//            Assert.NotNull(innerException);
//            // Optionally, assert on the exception message or parameter name
//        }
//    }
//}