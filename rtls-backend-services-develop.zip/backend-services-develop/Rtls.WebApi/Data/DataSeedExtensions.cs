﻿using Rtls.Domain.Database;

namespace Rtls.WebApi.Data;

public static class DataSeedExtensions
{
    public static async Task UseDefaultData(this IServiceProvider serviceProvider)
    {
        await using var scope = serviceProvider.CreateAsyncScope();
        await using var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        if (db is null) throw new NullReferenceException("Database is null");
        await db.Database.EnsureCreatedAsync();
        await using var transaction = await db.Database.BeginTransactionAsync();

        try
        {
            // seed data
            await db.SaveChangesAsync();
            await transaction.CommitAsync();
        }
        catch (Exception e)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }
}