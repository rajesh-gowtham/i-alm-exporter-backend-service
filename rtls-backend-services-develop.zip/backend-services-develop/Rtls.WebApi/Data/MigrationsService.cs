﻿using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;

namespace Rtls.WebApi.Data;

public static class MigrationsService
{
    public static void ApplyMigrations(this IApplicationBuilder app)
    {
        using var scope = app.ApplicationServices.CreateScope();
        using var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        dbContext.Database.Migrate();
    }
}