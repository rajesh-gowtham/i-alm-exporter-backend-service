﻿using Rtls.Application.Interfaces;
using Rtls.Application.Services;
using Rtls.Application.Services.Simulation;

namespace Rtls.WebApi.Extensions;

public static class ServiceExtensions
{
    public static void ConfigureCors(this IServiceCollection services) =>
        services.AddCors(options =>
        {
            options.AddPolicy("CorsPolicy", builder =>
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
        });

    public static IServiceCollection AddDependencies(this IServiceCollection services)
    {
        // Register HttpContextAccessor
        services.AddHttpContextAccessor();

        // Register CurrentUserService
        services.AddScoped<ICurrentUserService, CurrentUserService>();

        services.ConfigureServices();
        
        //Register Singleton
        services.AddSingleton<RfidTokenProvider>();
        return services;
    }


    public static IServiceCollection ConfigureServices(this IServiceCollection services)
    {
        services.AddScoped<IEquipmentService, EquipmentService>();
        services.AddScoped<IPointOfWorkService, PointOfWorkService>();
        services.AddScoped<IVesselService, VesselService>();
        services.AddScoped<IEquipmentPoolService, EquipmentPoolService>();
        services.AddScoped<IVesselVisitService, VesselVisitService>();
        services.AddScoped<IWorkInstructionService, WorkInstructionService>();
        services.AddScoped<IEquipmentPoolAssignmentService, EquipmentPoolAssignmentService>();
        services.AddScoped<IPowAssignmentService, PowAssignmentService>();
        services.AddScoped<IVesselBerthingService, VesselBerthingService>();
        services.AddScoped<IWorkAssignmentService, WorkAssignmentService>();
        services.AddScoped<ICheVmtOpsServie, CheVmtOpsServie>();
        services.AddScoped<IDashboardService, DashboardService>();
        services.AddScoped<IWorkQueue, WorkQueueService>();
        services.AddScoped<IRfidAssetService, RfidAssetService>();
        services.AddScoped<IInventoryService, InventoryService>();
        services.AddScoped<IRfidIntegrationService, RfidIntegrationService>();
        services.AddScoped<ITelematicsAssetService, TelematicsAssetService>();
        services.AddScoped<IRfidLevelTemplateService, RfidLevelTemplateService>();

        return services;
    }

    public static IServiceCollection AddSimulationServices(this IServiceCollection services)
    {
        // Register simulation services
        services.AddSingleton<EquipmentStateService>();
        services.AddSingleton<AssetWorkerManager>();
        
        // Worker factory
        services.AddSingleton<Func<long, AssetWorkerManager, AssetWorker>>(sp =>
        {
            // ITV unique ID
            return (id, manager) =>
            {
                // using var scope = sp.CreateScope();
                var logger = sp.GetRequiredService<ILogger<AssetWorker>>();
                var eqSvc = sp.GetRequiredService<EquipmentStateService>();
                // var wiSvc = scope.ServiceProvider.GetRequiredService<IWorkInstructionService>();

                return new AssetWorker(
                    assetId: id, 
                    logger: logger,
                    manager: manager,
                    equipmentStateService: eqSvc,
                    serviceProvider: sp // Pass the root provider
                    // scope.ServiceProvider.GetRequiredService<IWorkInstructionService>()
                );
            };
        });        
        
        // services.AddSingleton<Func<long, AssetWorkerManager, AssetWorker>>(sp =>
        // {
        //     // ITV unique ID
        //     return (id, manager) =>
        //     {
        //         // using var scope = sp.CreateScope();
        //         var logger = sp.GetRequiredService<ILogger<AssetWorker>>();
        //         var bus = sp.GetRequiredService<InMemoryMessageBus>();
        //         var eqSvc = sp.GetRequiredService<EquipmentStateService>();
        //         // var wiSvc = scope.ServiceProvider.GetRequiredService<IWorkInstructionService>();
        //
        //         return new AssetWorker(
        //             assetId: id, 
        //             simulationMode: AssetWorker.SimulationMode.WorkInstruction, // SelfDriven or WorkInstruction
        //             autonomyRouteType: RouteType.Lane1, // for SelfDriven, ignored for WorkInstruction
        //             logger: logger,
        //             manager: manager,
        //             messageBus: bus,
        //             equipmentStateService: eqSvc,
        //             serviceProvider: sp // Pass the root provider
        //             // scope.ServiceProvider.GetRequiredService<IWorkInstructionService>()
        //         );
        //     };
        // });

        return services;
    }
}