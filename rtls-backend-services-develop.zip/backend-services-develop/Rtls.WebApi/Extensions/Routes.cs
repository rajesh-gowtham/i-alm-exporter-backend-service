﻿using Rtls.WebApi.Endpoints;

namespace Rtls.WebApi.Extensions;

public static class Routes
{
    public static WebApplication MapRoutes(this WebApplication app)
    {        
        // ConfigEndpoints.MapRoutes(app);
        AuthEndpoints.MapRoutes(app);
        EquipmentEndpoints.MapRoutes(app);
        PointOfWorkEndpoints.MapRoutes(app);
        VesselEndpoints.MapRoutes(app);
        EquipmentPoolEndpoints.MapRoutes(app);
        VesselVisitEndpoints.MapRoutes(app);
        EquipmentPoolAssignmentEndpoints.MapRoutes(app);
        PowAssignmentEndpoints.MapRoutes(app);
        VesselBerthingEndpoints.MapRoutes(app);
        WorkInstructionEndpoints.MapRoutes(app);
        WorkAssignmentEndpoints.MapRoutes(app);
        CheVmtOpsEndpoint.MapRoutes(app);
        DashBoardEndpoints.MapRoutes(app);
        InventoryEndpoints.MapRoutes(app);
        RfidAssetEndpoints.MapRoutes(app);
        TelematicsAssetEndpoints.MapRoutes(app);
        RfidLevelTemplateEndpoints.MapRoutes(app);

        return app;
    }
}