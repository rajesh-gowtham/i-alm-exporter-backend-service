﻿using Rtls.Application.Interfaces;
using Rtls.Application.Services;

namespace Rtls.WebApi.BgServices;

public sealed class RfidBgService : IHostedService, IDisposable
{
    private readonly ILogger<RfidBgService> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly RfidTokenProvider _rfidTokenProvider;
    private DateTime _expiryTime;
    private CancellationTokenSource _cts;
    private Task _executingTask;
    

    public RfidBgService(
        IServiceScopeFactory scopeFactory,
        ILogger<RfidBgService> logger,
        RfidTokenProvider rfidTokenProvider)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
        _rfidTokenProvider = rfidTokenProvider;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _executingTask = Task.Factory.StartNew(ExecuteAsync, _cts.Token, TaskCreationOptions.LongRunning,
            TaskScheduler.Default);
        _logger.LogInformation("Rfid Bg Service started");
        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        await _cts.CancelAsync();
        await _executingTask;
        _logger.LogInformation("Rfid Bg Service stopped");
    }

    private async Task ExecuteAsync()
    {
        while (!_cts.Token.IsCancellationRequested)
        {
            try
            {
                // Just refresh token in background loop
                if (_rfidTokenProvider.GetToken() == null || DateTime.UtcNow >= _expiryTime)
                {
                    // Token expiry is set to 24 hours after creation
                    _expiryTime = DateTime.UtcNow.AddDays(1);
                    using (var scope = _scopeFactory.CreateScope())
                    {
                        var rfidService = scope.ServiceProvider.GetRequiredService<IRfidIntegrationService>();
                        await rfidService.RefreshTokenAsync();
                    }
                }

                await Task.Delay(TimeSpan.FromMinutes(5), _cts.Token); // keep running
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Rfid Token refresh failed");
                await Task.Delay(TimeSpan.FromSeconds(10), _cts.Token);
            }
        }
    }

    public void Dispose()
    {
        _cts.Dispose();
        _executingTask.Dispose();
    }

}