﻿using System.Collections.Immutable;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Application.Services;
using Rtls.Application.Services.Simulation;
using Rtls.Domain;
using Rtls.Domain.Helpers;

namespace Rtls.WebApi.BgServices;

public sealed class SimulatorBgService : IHostedService, IDisposable
{
    private readonly ILogger<SimulatorBgService> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly EquipmentStateService _equipmentStateService;
    private readonly AssetWorkerManager _assetWorkerManager;
    private CancellationTokenSource _cts;
    private Task _executingTask;

    public SimulatorBgService(
        ILogger<SimulatorBgService> logger,
        IServiceScopeFactory scopeFactory,
        EquipmentStateService equipmentStateService,
        AssetWorkerManager assetWorkerManager)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _equipmentStateService = equipmentStateService;
        _assetWorkerManager = assetWorkerManager;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _executingTask = Task.Factory.StartNew(ExecuteAsync, _cts.Token, TaskCreationOptions.LongRunning,
            TaskScheduler.Default);
        _logger.LogInformation("Service started");
        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        await _cts.CancelAsync();
        await _executingTask;
        _logger.LogInformation("Service stopped");
    }

    private async Task ExecuteAsync()
    {
        // load equipment from somewhere, e.g., database or configuration
        ImmutableArray<EquipmentDto> equipments;
        using (var scope = _scopeFactory.CreateScope())
        {
            var equipmentService = scope.ServiceProvider.GetRequiredService<IEquipmentService>();
            var pagedResponse = await equipmentService.GetAllAsync(ct: _cts.Token);
            if (pagedResponse.TotalCount == 0)
            {
                _logger.LogWarning("No equipment found to simulate.");
                return;
            }

            equipments = pagedResponse.Items
                .Where(x => x.EquipmentType == "Terminal Truck")
                .ToImmutableArray();
        }

        // Create default state
        foreach (var equipment in equipments)
        {
            var state = CreateDefaultState(equipment);
            _equipmentStateService.SetEquipmentState(state);
        }

        // Start worker manager
        await _assetWorkerManager.StartAsync(_cts.Token);
        
        _logger.LogInformation("Simulation started for {Count} equipments.", equipments.Length);
    }

    private static EquipmentState CreateDefaultState(EquipmentDto equipment)
    {
        // (Longitude, Latitude)
        var parkingLoc = TopologyHelper.CreatePoint(76.996279, 8.374311);

        return new EquipmentState
        {
            EquipmentId = equipment.Id,
            EquipmentName = equipment.EquipmentName,
            EquipmentType = equipment.EquipmentType,
            Status = Constants.EquipmentStatus.AVAILABLE,
            Message = "Ready for operation",
            GpsTime = DateTime.UtcNow,
            Latitude = parkingLoc.Y,
            Longitude = parkingLoc.X,
            Altitude = 0,
            Heading = 0
        };
    }

    public void Dispose()
    {
        _cts.Dispose();
        _executingTask.Dispose();
    }
}