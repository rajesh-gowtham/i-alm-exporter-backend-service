﻿using NATS.Client.Core;
using NATS.Client.JetStream;
using NATS.Client.JetStream.Models;
using NATS.Net;
using Rtls.Application.Processing;
using Rtls.Application.Processing.Internal;
using Rtls.Domain.Models;

namespace Rtls.WebApi.BgServices;

public sealed class NatsBgService : IHostedService, IDisposable
{
    private readonly ILogger<NatsBgService> _logger;
    private readonly INatsClient _natsClient;
    private readonly MessageRouter _messageRouter;
    private readonly INatsJSContext _jetStreamContext;
    private CancellationTokenSource _cts;
    private Task _executingTask;
    private long _counter;

    public NatsBgService(
        ILogger<NatsBgService> logger,
        INatsClient natsClient,
        MessageRouter messageRouter)
    {
        _logger = logger;
        _natsClient = natsClient;
        _messageRouter = messageRouter;
        _jetStreamContext = _natsClient.CreateJetStreamContext();
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _executingTask = Task.Factory.StartNew(ExecuteAsync, _cts.Token, TaskCreationOptions.LongRunning,
            TaskScheduler.Default);
        _logger.LogInformation("Service started");
        return Task.CompletedTask;
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        await _cts.CancelAsync();
        await _executingTask;
        _logger.LogInformation("Service stopped");
    }

    private async Task ExecuteAsync()
    {
        const string streamName = "device-messages";
        const string consumerName = "device-message-handlers";
        // const string consumerName = "device-message-processor";

        var streamConfig = new StreamConfig(
            name: streamName,
            subjects: ["devices.*.telemetry"])
        {
            // Storage = StreamConfigStorage.File,
            // Compression = StreamConfigCompression.S2
        };

        await _jetStreamContext.CreateStreamAsync(streamConfig);

        // Configure the consumer with a custom Ack Wait time
        var consumerConfig = new ConsumerConfig(consumerName)
        {
            AckWait = TimeSpan.FromSeconds(600),
            // MaxBatch = 100,
            // MaxWaiting = 50,
            // MaxAckPending = 100,
            DurableName = consumerName,
        };
        
        var consumer = await _jetStreamContext.CreateOrUpdateConsumerAsync(
            stream: streamName,
            consumerConfig);

        // performance
        var timer = new Timer(
            (state =>
            {
                _logger.LogDebug("{Mps} messages in past 10 seconds", Interlocked.Exchange(ref _counter, 0));
            }), null,
            TimeSpan.Zero, TimeSpan.FromSeconds(10));

        _logger.LogInformation("Consumer created");

        await foreach (var msg in consumer.ConsumeAsync<DeviceMessage>().WithCancellation(_cts.Token))
        {
            // Loop ends when pull request expires or when requested number of messages (MaxMsgs) received
            if (msg.Data == null) continue;
            var deviceMessage = msg.Data;

            // _logger.LogDebug($"Device message: {JsonSerializer.Serialize(deviceMessage)}");
            // var context = new MessageContext<DeviceMessage>(
            //     deviceMessage.Imei, deviceMessage,
            //     async () => await msg.AckAsync()); 
                                                   
            var context = new MessageContext<DeviceMessage>(deviceMessage.DeviceId, deviceMessage);

            try
            {
                // processing
                await _messageRouter.RouteAsync(context, _cts.Token);
            }
            catch (TaskCanceledException tex)
            {
                // ignore
                _logger.LogWarning(tex.Message);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while processing message");
                break;
            }
            
            // ack
            await msg.AckAsync();

            // counter
            Interlocked.Increment(ref _counter);
        }

        // close and dispose
        try
        {
            await timer.DisposeAsync();
            await _messageRouter.Stop(_cts.Token);
            _logger.LogInformation("Consumer closed");
        }
        catch (Exception e)
        {
            _logger.LogError(e.Message, e);
        }
    }

    public void Dispose()
    {
        _cts?.Dispose();
        _executingTask?.Dispose();
    }
}