using System.Net.Http.Headers;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.ResponseCompression;
using Rtls.Application;
using Rtls.Application.Mappings;
using Rtls.Domain;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.WebApi.BgServices;
using Rtls.WebApi.Data;
using Rtls.WebApi.Extensions;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration
    .SetBasePath(Environment.CurrentDirectory)
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables(prefix: "RTLS_");

builder.Services.Configure<ConnectionsConfig>(
    builder.Configuration.GetRequiredSection(nameof(ConnectionsConfig)));

// openapi/v1.json
builder.Services.AddOpenApi();
builder.Services.AddCors();
builder.Services.AddAuthentication(IdentityConstants.BearerScheme)
    .AddCookie(IdentityConstants.ApplicationScheme)
    .AddBearerToken(IdentityConstants.BearerScheme,
        options =>
        {
            options.BearerTokenExpiration = TimeSpan.FromDays(365);
        });

builder.Services.AddAuthorization();

builder.Services
    .AddIdentityCore<ApplicationUser>(options =>
    {
        options.SignIn.RequireConfirmedAccount = false;
        options.SignIn.RequireConfirmedEmail = false;
        options.SignIn.RequireConfirmedPhoneNumber = false;
        options.User.RequireUniqueEmail = true;
    })
    .AddEntityFrameworkStores<AppDbContext>()
    .AddApiEndpoints();

// JSON config
builder.Services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
{
    options.SerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    options.SerializerOptions.NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals | JsonNumberHandling.AllowReadingFromString;
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

// compression
// Register Response Compression services
builder.Services.AddResponseCompression(options =>
{
    options.EnableForHttps = true;
    options.Providers.Add<BrotliCompressionProvider>();
    options.Providers.Add<GzipCompressionProvider>();
});

// (Optional) Configure compression levels
builder.Services.Configure<BrotliCompressionProviderOptions>(options =>
{
    options.Level = System.IO.Compression.CompressionLevel.Fastest;
});

builder.Services.Configure<GzipCompressionProviderOptions>(options =>
{
    options.Level = System.IO.Compression.CompressionLevel.SmallestSize;
});

// deps
builder.Services
    .AddMasterDb()
    .AddMessageBus()
    .AddAutoMapper(typeof(MappingProfile))
    .AddSharedDependencies()
    .AddDependencies()
    .AddSimulationServices()
    .ConfigureServices();

if (builder.Environment.IsDevelopment())
{
    builder.Services.AddDatabaseDeveloperPageExceptionFilter();
}

// bg services
builder.Services.AddHostedService<SimulatorBgService>();
builder.Services.AddHostedService<RfidBgService>();
if (builder.Environment.IsProduction())
{
    // builder.Services.AddHostedService<NatsBgService>();
}

builder.Services.AddHttpClient("rfidClient", client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
});

var app = builder.Build();
// routes
app.MapRoutes();

// other configurations
app.UseCors(x => x
    .AllowAnyOrigin()
    .AllowAnyMethod()
    .AllowAnyHeader());
app.UseAuthentication();
app.UseAuthorization();

// Use Response Compression middleware
app.UseResponseCompression();

// open API
app.MapOpenApi();
app.MapScalarApiReference();

// if (app.Environment.IsDevelopment())
app.MapIdentityApi<ApplicationUser>().WithTags("Identity");

// migrations
app.ApplyMigrations();

// run app
await app.RunAsync();
