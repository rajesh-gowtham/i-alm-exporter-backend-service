using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class VesselEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/vessels");

        group.MapGet("/", GetAllVessels);
        group.MapGet("/{id:long}", GetVesselById);
        group.MapPost("/", CreateVessel);
        group.MapPost("/batch", CreateVesselsBatch);
        group.MapPut("/{id:long}", UpdateVessel);
        group.MapDelete("/{id:long}", DeleteVessel);
    }

    private static async Task<Results<Ok<PagedResponse<VesselDto>>, EmptyHttpResult>> GetAllVessels(
        IVesselService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }
    private static async Task<Results<Ok<VesselDto>, NotFound>> GetVesselById(
        long id,
        IVesselService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }

    private static async Task<IResult> CreateVessel(
        CreateVesselDto dto,
        IVesselService service)
    {
        try
        {
            var created = await service.CreateAsync(dto);
            return TypedResults.Created($"/vessels/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateVesselsBatch(
        CreateVesselDto[] dtos,
        IVesselService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdateVessel( // Changed return type to Ok<bool> and added ProblemHttpResult
        long id,
        UpdateVesselDto dto,
        IVesselService service)
    {
        try
        {
            var result = await service.UpdateAsync(id, dto); // Changed method call to UpdateAsync with id and dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<IResult> DeleteVessel( // Added ProblemHttpResult to return types
        long id,
        IVesselService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }
}