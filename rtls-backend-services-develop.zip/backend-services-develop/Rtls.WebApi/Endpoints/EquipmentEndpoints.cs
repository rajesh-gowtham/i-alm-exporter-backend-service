using System.Collections.Immutable;
using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Application.Services; // Added using directive for DTOs
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class EquipmentEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/equipment");

        group.MapGet("/", GetAllEquipment);
        group.MapGet("/{id:long}", GetEquipmentById);
        group.MapGet("/states", GetAllEquipmentStates);
        group.MapGet("/{id:long}/state", GetEquipmentState);
        group.MapGet("/{name}/state", GetEquipmentStateByName);
        
        group.MapPost("/", CreateEquipment);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/", UpdateEquipment);
        group.MapDelete("/{id:long}", DeleteEquipment);
    }

    private static async Task<Results<Ok<PagedResponse<EquipmentDto>>, EmptyHttpResult>> GetAllEquipment( // Changed return type to EquipmentDto
        IEquipmentService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<EquipmentDto>, NotFound>> GetEquipmentById( // Changed return type to EquipmentDto
        long id,
        IEquipmentService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }    
    
    private static Ok<ImmutableArray<EquipmentState>> GetAllEquipmentStates(EquipmentStateService service)
    {
        return TypedResults.Ok(service.GetAll());
    }
    
    private static Results<Ok<EquipmentState>, NotFound> GetEquipmentState(
        long id,
        EquipmentStateService service)
    {
        var state = service.GetEquipmentState(id);
        return state is null ? TypedResults.NotFound() : TypedResults.Ok(state);
    }    
    
    private static async Task<Results<Ok<EquipmentState>, NotFound>> GetEquipmentStateByName(
        string name,
        EquipmentStateService equipmentStateService,
        IEquipmentService equipmentService)
    {
        var equipment = await equipmentService.GetByNameAsync(name);
        if (equipment is null) return TypedResults.NotFound();
        
        var state = equipmentStateService.GetEquipmentState(equipment.Id);
        return state is null ? TypedResults.NotFound() : TypedResults.Ok(state);
    }

    private static async Task<IResult> CreateEquipment( // Changed return type to EquipmentDto
        CreateEquipmentDto dto, // Changed parameter type to CreateEquipmentDto
        IEquipmentService service)
    {
        try
        {
            var created = await service.CreateAsync(dto); // Changed method call to CreateAsync with dto
            return TypedResults.Created($"/equipment/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateBatch(
        CreateEquipmentDto[] dtos,
        IEquipmentService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdateEquipment( // Changed return type to Ok<bool>
        UpdateEquipmentDto dto, // Changed parameter type to UpdateEquipmentDto
        IEquipmentService service)
    {
        try
        {
            var result = await service.UpdateAsync(dto); // Changed method call to UpdateAsync with dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<IResult> DeleteEquipment( // Added ProblemHttpResult to return types
        long id,
        IEquipmentService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }
}