using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class PowAssignmentEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/powassignments");

        group.MapGet("/", GetAllPowAssignments);
        group.MapGet("/{id:long}", GetPowAssignmentById);
        group.MapPost("/", CreatePowAssignment);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/", UpdatePowAssignment);
        group.MapDelete("/{id:long}", DeletePowAssignment);
    }

    private static async Task<Results<Ok<PagedResponse<PowAssignmentDto>>, EmptyHttpResult>> GetAllPowAssignments(
        IPowAssignmentService service,
        int skip = 0,
        int? take = null,
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<PowAssignmentDto>, NotFound>> GetPowAssignmentById(
        long id,
        IPowAssignmentService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }

    private static async Task<Results<Created<PowAssignmentDto>, ProblemHttpResult>> CreatePowAssignment(
        CreatePowAssignmentDto dto,
        IPowAssignmentService service)
    {
        try
        {
            var created = await service.CreateAsync(dto);
            return TypedResults.Created($"/powassignments/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<Created, ProblemHttpResult>> CreateBatch(
        CreatePowAssignmentDto[] dtos,
        IPowAssignmentService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdatePowAssignment( // Changed return type to Ok<bool> and added ProblemHttpResult
        UpdatePowAssignmentDto dto,
        IPowAssignmentService service)
    {
        try
        {
            var result = await service.UpdateAsync(dto); // Changed method call to UpdateAsync with dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<NoContent, NotFound, ProblemHttpResult>> DeletePowAssignment( // Added ProblemHttpResult to return types
        long id,
        IPowAssignmentService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }
}