﻿using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;

namespace Rtls.WebApi.Endpoints;

public static class DashBoardEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/dashboard");
        group.MapGet("/waterSide", GetWaterSideDashboardAsync);
        group.MapGet("/landSide", GetLandSideDashboardAsync);
    }

    //Water Side Dashboard API's:
    private static async Task<Results<Ok<WaterSideDashboardDto>, NoContent>> GetWaterSideDashboardAsync(
            IDashboardService service,
            ILogger<IDashboardService> logger,
            HttpContext httpContext,
            string cardName,
            int skip = 0,
            int? take = null,
            CancellationToken ct = default)
    {
        try
        {
            logger.LogInformation("Fetching WaterSide dashboard data...");
            var dto = await service.GetWaterSideDashboardData(cardName, skip, take, ct);

            return TypedResults.Ok(dto);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error occurred while fetching WaterSide dashboard data.");
            throw new InvalidOperationException($"Error occurred while fetching WaterSide dashboard data : {ex.Message}");
        }
    }

    //Land Side Dashboard API's:
    private static async Task<Results<Ok<LandSideDashboardDto>, NoContent>> GetLandSideDashboardAsync(
            IDashboardService service,
            ILogger<IDashboardService> logger,
            HttpContext httpContext,
            int skip,
            int? take,
            string cardName,
            CancellationToken ct = default)
    {
        try
        {
            logger.LogInformation("Fetching LandSide dashboard data...");
            var dto = await service.GetLandSideDashboardData(skip, take, cardName, ct);

            return TypedResults.Ok(dto);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error occurred while fetching LandSide dashboard data.");
            throw new InvalidOperationException($"Error occurred while fetching LandSide dashboard data : {ex.Message}");
        }
    }
}