using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models; // Added using directive for DTOs
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class EquipmentPoolEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/equipmentpools");

        group.MapGet("/", GetAllEquipmentPools);
        group.MapGet("/{id:long}", GetEquipmentPoolById);
        group.MapPost("/", CreateEquipmentPool);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/", UpdateEquipmentPool);
        group.MapDelete("/{id:long}", DeleteEquipmentPool);
    }

    private static async Task<Results<Ok<PagedResponse<EquipmentPoolDto>>, EmptyHttpResult>> GetAllEquipmentPools(
        IEquipmentPoolService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<EquipmentPoolDto>, NotFound>> GetEquipmentPoolById( // Changed return type to EquipmentPoolDto
        long id,
        IEquipmentPoolService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }

    private static async Task<IResult> CreateEquipmentPool( // Changed return type to EquipmentPoolDto
        CreateEquipmentPoolDto dto, // Changed parameter type to CreateEquipmentPoolDto
        IEquipmentPoolService service)
    {
        try
        {
            var created = await service.CreateAsync(dto); // Changed method call to CreateAsync with dto
            return TypedResults.Created($"/equipmentpools/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateBatch(
        CreateEquipmentPoolDto[] dtos,
        IEquipmentPoolService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdateEquipmentPool( // Changed return type to Ok<bool>
        UpdateEquipmentPoolDto dto, // Changed parameter type to UpdateEquipmentPoolDto
        IEquipmentPoolService service)
    {
        try
        {
            var result = await service.UpdateAsync(dto); // Changed method call to UpdateAsync with dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<NoContent, NotFound, ProblemHttpResult>> DeleteEquipmentPool( // Added ProblemHttpResult to return types
        long id,
        IEquipmentPoolService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }
}