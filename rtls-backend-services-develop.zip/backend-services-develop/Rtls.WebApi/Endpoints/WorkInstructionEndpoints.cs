using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class WorkInstructionEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/workinstructions");

        group.MapGet("/", GetAllWorkInstructions);
        group.MapGet("/{id:long}", GetWorkInstructionById);
        group.MapPost("/", CreateWorkInstruction);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/{id:long}", UpdateWorkInstruction);
        group.MapDelete("/{id:long}", DeleteWorkInstruction);
        group.MapGet("/workQueue/{workQueueId}", GetWorkInstructionByWorkQueueId);
        group.MapPost("/append", AppendWorkInstruction);
    }

    private static async Task<Results<Ok<PagedResponse<WorkInstructionDto>>, EmptyHttpResult>> GetAllWorkInstructions(
        IWorkInstructionService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<WorkInstructionDto>, NotFound>> GetWorkInstructionById(
        long id,
        IWorkInstructionService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }

    private static async Task<IResult> CreateWorkInstruction(
        CreateWorkInstructionDto dto,
        IWorkInstructionService service)
    {
        try
        {
            var dtoArray = new[] { dto }; // Convert single DTO to array
            var created = await service.CreateBatchAsync(dtoArray); // Call batch creation
            return TypedResults.Created(); // Just return 201 Created with no location/body
            // var created = await service.CreateAsync(dto);
            // return TypedResults.Created($"/workinstructions/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateBatch(
        CreateWorkInstructionDto[] dtos,
        IWorkInstructionService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }
    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdateWorkInstruction( // Changed return type to Ok<bool> and added ProblemHttpResult
        long id,
        UpdateWorkInstructionDto dto,
        IWorkInstructionService service)
    {
        if (dto.Id != id)
            return TypedResults.Problem("ID mismatch");

        try
        {
            var result = await service.UpdateAsync(dto); // Changed method call to UpdateAsync with dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<NoContent, NotFound, ProblemHttpResult>> DeleteWorkInstruction( // Added ProblemHttpResult to return types
        long id,
        IWorkInstructionService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }
    private static async Task<IResult> GetWorkInstructionByWorkQueueId(
        IWorkInstructionService service,
        long workQueueId,
        [FromQuery] int skip,
        [FromQuery] int take,
        [FromQuery] string search = "",
        CancellationToken ct = default)
    {
        try
        { 
            if (skip < 0 || take <= skip)
            {
                return Results.BadRequest("Invalid pagination range.");
            }
            var  workInstructions = await service.GetByWorkQueueIdAsync(workQueueId, skip, take, search, ct);
            // Return the list of WorkInstruction data in the response
            return Results.Ok(workInstructions);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> AppendWorkInstruction([FromBody] AppendWorkInstructionRequest request,
        IWorkInstructionService service,
        CancellationToken ct = default)
    {
        var result = await service.AppendWorkInstructionAsync(request, ct);
        return result ? Results.Ok("WorkInstruction updated successfully.") : Results.NotFound("WorkInstruction not found.");
    }


}