using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class InventoryEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/inventory");

        group.MapGet("/container", GetAllInventoryContainer);
        group.MapPost("/container/clear", ContainerClear);
        group.MapGet("container/{id:long}", GetInventoryContainerById);
        group.MapGet("/vessel", GetAllInventoryVessel);
    }

    private static async Task<Results<Ok<PagedResponse<InventoryContainerDto>>, EmptyHttpResult>> GetAllInventoryContainer(
        IInventoryService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllInventoryContainerAsync(skip, take, search, ct);
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<PagedResponse<InventoryVesselVisitDto>>, EmptyHttpResult>> GetAllInventoryVessel(
        IInventoryService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllInventoryVessel(skip, take, search, ct);
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<IResult> ContainerClear(
       ContainerClearRequestdto dtos,
       IInventoryService service)
    {
        try
        {
            var created = await service.ContainerClearAsync(dtos);
            return TypedResults.Ok();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<InventoryContainerListDto>, NotFound>> GetInventoryContainerById( // Changed return type to EquipmentDto
        long id,
        IInventoryService service)
    {
        var item = await service.GetInventoryContainerById(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }


}