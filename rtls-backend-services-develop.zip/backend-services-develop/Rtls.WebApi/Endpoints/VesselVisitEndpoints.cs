using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class VesselVisitEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/vesselvisits");

        group.MapGet("/", GetAllVesselVisits);
        group.MapGet("/{id:long}", GetVesselVisitById);
        group.MapPost("/", CreateVesselVisit);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/{id:long}", UpdateVesselVisit);
        group.MapDelete("/{id:long}", DeleteVesselVisit);
    }

    private static async Task<Results<Ok<PagedResponse<VesselVisitDto>>, EmptyHttpResult>> GetAllVesselVisits(
        IVesselVisitService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<VesselVisitDto>, NotFound>> GetVesselVisitById(
        long id,
        IVesselVisitService service)
    {
        var item = await service.GetByIdAsync(id);
        return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
    }

    private static async Task<IResult> CreateVesselVisit(
        CreateVesselVisitDto dto,
        IVesselVisitService service)
    {
        try
        {
            var created = await service.CreateAsync(dto);
            return TypedResults.Created($"/vesselvisits/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateBatch(
        CreateVesselVisitDto[] dtos, 
        IVesselVisitService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> UpdateVesselVisit( // Changed return type to Ok<bool> and added ProblemHttpResult
        long id,
        UpdateVesselVisitDto dto,
        IVesselVisitService service)
    {
        try
        {
            var result = await service.UpdateAsync(id, dto); // Changed method call to UpdateAsync with id and dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<IResult> DeleteVesselVisit( // Added ProblemHttpResult to return types
        long id,
        IVesselVisitService service)
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }
}