using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class VesselBerthingEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/vesselberthings");

        group.MapGet("/", GetAll);
        group.MapGet("/{id:long}", GetById);
        group.MapPost("/", Create);
        group.MapPost("/batch", CreateBatch);
        group.MapPut("/{id:long}", Update);
        group.MapDelete("/{id:long}", Delete);
    }

    private static async Task<Results<Ok<PagedResponse<VesselBerthingDto>>, EmptyHttpResult>> GetAll(
        IVesselBerthingService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
        if (pagedResponse.TotalCount == 0) // Changed Total to TotalCount
            return TypedResults.Empty;
        return TypedResults.Ok(pagedResponse);
    }

    private static async Task<Results<Ok<VesselBerthingDto>, NotFound>> GetById(long id, IVesselBerthingService service)
    {
        var entity = await service.GetByIdAsync(id);
        return entity is null ? TypedResults.NotFound() : TypedResults.Ok(entity);
    }

    private static async Task<IResult> Create(CreateVesselBerthingDto dto, IVesselBerthingService service)
    {
        try
        {
            var created = await service.CreateAsync(dto);
            return TypedResults.Created($"/vesselberthings/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> CreateBatch(
        CreateVesselBerthingDto[] dtos,
        IVesselBerthingService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, ProblemHttpResult>> Update(long id, UpdateVesselBerthingDto dto, IVesselBerthingService service) // Changed return type to Ok<bool> and added ProblemHttpResult
    {
        try
        {
            var result = await service.UpdateAsync(id, dto); // Changed method call to UpdateAsync with id and dto
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.Ok(result); // Return boolean result
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<NoContent, NotFound, ProblemHttpResult>> Delete(long id, IVesselBerthingService service) // Added ProblemHttpResult to return types
    {
        try
        {
            var result = await service.DeleteAsync(id); // Changed method call to DeleteAsync
            if (!result) // Check boolean result
                return TypedResults.NotFound();

            return TypedResults.NoContent();
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }
}
