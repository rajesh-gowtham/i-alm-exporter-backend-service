using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class WorkAssignmentEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/workassignment");

        group.MapGet("/", GetWorkAssignmentByPagination);
        group.MapGet("/pow/{vesselVisitId}/{powId}", GetWorkAssignmentByPow);
        group.MapPost("/operation/{workQueueId}", OperateWorkQueue);
    }

    private static async Task<Results<Ok<PagedResponse<WorkAssignmentDto>>, EmptyHttpResult, ProblemHttpResult>> GetWorkAssignmentByPagination(
        IWorkAssignmentService service,
        int skip,
        int take,
        String search,
        CancellationToken ct = default)
    {
        try 
        { 
            var pagedResponse = await service.GetAllAsync(skip, take, search, ct);
            return TypedResults.Ok(pagedResponse);
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<Ok<List<WorkQueueDto>>, NotFound, ProblemHttpResult>> GetWorkAssignmentByPow(
      IWorkAssignmentService service,
      long vesselVisitId,
      long powId,
      CancellationToken ct = default)
    {
        try
        {
            var result = await service.GetWorkQueuesByPowAsync(vesselVisitId, powId, ct);
            return TypedResults.Ok(result);
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }
    private static async Task<IResult> OperateWorkQueue(
        long workQueueId,
        [FromQuery] string action,
        IWorkAssignmentService service,
        CancellationToken ct)
    {
        try
        { 
            var result = await service.OperateWorkQueueAsync(workQueueId, action, ct);
            return result ? Results.Ok(true) : Results.Ok(false);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

}