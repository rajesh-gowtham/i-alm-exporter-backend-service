using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Rtls.Application.Interfaces;
using Rtls.Application.Models;

namespace Rtls.WebApi.Endpoints;

public static class EquipmentPoolAssignmentEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/equipmentpoolassignments");

        group.MapGet("/{equipmentPoolId:long}", GetAssignmentById);
        group.MapGet("/assignedPools", GetAssignedEquipment);
        group.MapPost("/{equipmentPoolId:long}", UpdateAssignment);
    }

    private static async Task<Results<Ok<EquipmentAssignedAndUnassignedEquipmentDto>, NotFound, ProblemHttpResult>> GetAssignmentById(
        long equipmentPoolId,
        IEquipmentPoolAssignmentService service,
        CancellationToken ct = default)
    {
        try
        {
            var item = await service.GetByIdAsync(equipmentPoolId, ct);
            return item is null ? TypedResults.NotFound() : TypedResults.Ok(item);
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message);
        }
    }

    private static async Task<Results<Ok<bool>, NotFound, Ok, ProblemHttpResult>> UpdateAssignment(
        long equipmentPoolId, // Corrected variable name to follow C# conventions
        List<UpdateEquipmentPoolAssignmentDto>? dto,
        IEquipmentPoolAssignmentService service,
        CancellationToken ct = default)
    {
        try
        {
            Console.WriteLine("Enter");
            // Perform the update operation for each item in the list
            var update = await service.UpdateAsync(dto, equipmentPoolId, ct);
            return TypedResults.Ok(update); // Return the updated status wrapped in Ok.
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message); // Return a problem result if an exception occurs.
        }
    }

    private static async Task<IResult> GetAssignedEquipment(
         [FromQuery] string equipmentPoolName,
         IEquipmentPoolAssignmentService service, 
         CancellationToken ct = default)
    {
        try
        {
            var item = await service.GetAssignedEquipments(equipmentPoolName, ct);
            return TypedResults.Ok(item);
        }
        catch (Exception ex)
        {
            return TypedResults.Problem(ex.Message); // Return a problem result if an exception occurs.
        }
    }
}