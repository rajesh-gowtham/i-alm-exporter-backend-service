using Rtls.Application.Interfaces;
using Rtls.Application.Models;

namespace Rtls.WebApi.Endpoints;

public static class RfidAssetEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/asset/rfid");

        group.MapPost("/", CreateRfidAsset);
        group.MapGet("/", GetRfidAsset);
        group.MapPut("/", UpdateRfidAsset);
        group.MapDelete("/{id:long}", DeleteRfidAsset);
        group.MapGet("/masterData", GetRfidMasterData);
    }

    private static async Task<IResult> CreateRfidAsset(
        CreateRfidAssetDto dto,
        IRfidAssetService service,
        CancellationToken ct = default)
    {
        var response = await service.CreateRfidAssetAsync(dto, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> GetRfidAsset(
       IRfidAssetService service,
       int skip = 0,
       int? take = null,
       string search = "",
       CancellationToken ct = default)
    {
        var response = await service.GetAllAssetsAsync(skip, take, search, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> UpdateRfidAsset(
        UpdateRfidAssetDto dto,
      IRfidAssetService service,
      CancellationToken ct = default)
    {
        var response = await service.UpdateRfidAssetsAsync(dto, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> DeleteRfidAsset(
        long id,
      IRfidAssetService service,
      CancellationToken ct = default)
    {
        var response = await service.DeleteRfidAssetsAsync(id, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> GetRfidMasterData(
      IRfidAssetService service,
      CancellationToken ct = default)
    {
        var response = await service.GetRfidAssetMasterDataAsync(ct);
        return Results.Ok(response);
    }
}