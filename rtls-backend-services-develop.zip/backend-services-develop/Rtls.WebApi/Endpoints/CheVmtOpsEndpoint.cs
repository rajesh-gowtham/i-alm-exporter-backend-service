using Microsoft.AspNetCore.Mvc;
using Rtls.Application.Interfaces;

namespace Rtls.WebApi.Endpoints;

public static class CheVmtOpsEndpoint
{
    public sealed record LoginRequest(string CheId, string UserId);
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/vmt");

        group.MapPost("/login", Login);
        group.MapPost("/logout", Logout);
        group.MapPost("/job", FetchJobStatus);
    }

    private static async Task<IResult> Login(
        LoginRequest request,
        ICheVmtOpsServie service, 
        CancellationToken ct = default)
    {
        try
        {
            var response = await service.Login(request.CheId, request.UserId, ct);
            return TypedResults.Ok(response);
        }catch(Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> Logout(
        LoginRequest request,
        ICheVmtOpsServie service,
        CancellationToken ct = default)
    {
        try
        {
            var response = await service.Logout(request.CheId, request.UserId, ct);
            return TypedResults.Ok(response);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<IResult> FetchJobStatus(
       LoginRequest request,
       [FromQuery]string action,
       ICheVmtOpsServie service,
       CancellationToken ct = default)
    {
        try
        {
            var response = await service.JobStepingUpdates(request.CheId, request.UserId, action, ct);
            return TypedResults.Ok(response);
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }
}