﻿using Microsoft.AspNetCore.Http.HttpResults;
using Rtls.Application.Interfaces;
using Rtls.Application.Models; // TelematicsDto, UpdateTelematicsDto
using Rtls.Domain.Models;

namespace Rtls.WebApi.Endpoints;

public static class TelematicsAssetEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/asset/telematics");

        group.MapGet("/", GetAll);
        group.MapGet("/{id:long}", GetById);
        group.MapPost("/", Create);
        group.MapPut("/{id:long}", Update);
        group.MapDelete("/{id:long}", Delete);
        group.MapPost("/batch", CreateBatch);
        group.MapGet("/{deviceId}", GetByDeviceId);
    }

    private static async Task<Results<Ok<PagedResponse<TelematicsDto>>, EmptyHttpResult>> GetAll(
        ITelematicsAssetService service,
        int skip = 0,
        int? take = null,
        string search = "",
        CancellationToken ct = default)
    {
        var result = await service.GetAllAsync(skip, take, search, ct);

        return result.TotalCount == 0
            ? TypedResults.Empty
            : TypedResults.Ok(result);
    }

    private static async Task<Results<Ok<TelematicsDto>, NotFound>> GetById(
        long id,
        ITelematicsAssetService service)
    {
        var item = await service.GetByIdAsync(id);

        return item is null
            ? TypedResults.NotFound()
            : TypedResults.Ok(item);
    }

    private static async Task<IResult> Create(
        TelematicsDto dto,
        ITelematicsAssetService service)
    {
        if (dto == null)
            return TypedResults.BadRequest("Payload is null");

        var created = await service.CreateAsync(dto);
        return TypedResults.Created($"/telematics/{created.Id}", created);
    }

    private static async Task<Results<Ok<bool>, NotFound, BadRequest<string>>> Update(
        long id,
        UpdateTelematicsDto dto,
        ITelematicsAssetService service)
    {
        if (dto == null)
            return TypedResults.BadRequest("Payload is null");

        var updated = await service.UpdateAsync(id, dto);
        return !updated
            ? TypedResults.NotFound()
            : TypedResults.Ok(updated);
    }

    private static async Task<Results<NoContent, NotFound, BadRequest<string>>> Delete(
        long id,
        ITelematicsAssetService service)
    {
        var deleted = await service.DeleteAsync(id);
        return !deleted
            ? TypedResults.NotFound()
            : TypedResults.NoContent();
    }

    private static async Task<IResult> CreateBatch(
      CreateTelematicsDto[] dtos,
      ITelematicsAssetService service)
    {
        try
        {
            var created = await service.CreateBatchAsync(dtos);
            return TypedResults.Created();
        }
        catch (Exception ex)
        {
            return TypedResults.BadRequest(ex.Message);
        }
    }

    private static async Task<TelematicsDto> GetByDeviceId(
        string deviceId,
        ITelematicsAssetService service)
    {
        var item = await service.GetByDeviceIdAsync(deviceId);

        return item;
    }

}
