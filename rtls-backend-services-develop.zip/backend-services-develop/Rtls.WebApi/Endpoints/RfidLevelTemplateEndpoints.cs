using Rtls.Application.Interfaces;
using Rtls.Application.Models;

namespace Rtls.WebApi.Endpoints;

public static class RfidLevelTemplateEndpoints
{
    public static void MapRoutes(IEndpointRouteBuilder builder)
    {
        var group = builder.MapGroup("/asset/rfid/levelTemplate");

        group.MapPost("/", CreateLevelTemplate);
        group.MapGet("/", GetLevelTemplate);
        group.MapPut("/", UpdateLevelTemplate);

        group.MapGet("/values/", GetLevelTemplateValues);
        group.MapPost("/values/", CreateLevelTemplateValues);
        group.MapPut("/values/", UpdateLevelTemplateValues);
    }

    private static async Task<IResult> CreateLevelTemplate(
        LevelTemplateDto dto,
        IRfidLevelTemplateService service,
        CancellationToken ct = default)
    {
        var response = await service.CreateLevelTemplateAsync(dto, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> GetLevelTemplate(
       IRfidLevelTemplateService service,
       CancellationToken ct = default)
    {
        var response = await service.GetLevelTemplateAsync(ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> UpdateLevelTemplate(
        LevelTemplateDto dto,
      IRfidLevelTemplateService service,
      CancellationToken ct = default)
    {
        var response = await service.UpdateLevelTemplateAsync(dto, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> CreateLevelTemplateValues(
       LevelTemplateValueDto dto,
       IRfidLevelTemplateService service,
       CancellationToken ct = default)
    {
        var response = await service.CreateLevelTemplateValueAsync(dto, ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> GetLevelTemplateValues(
      IRfidLevelTemplateService service,
      CancellationToken ct = default)
    {
        var response = await service.GetLevelTemplateValueAsync(ct);
        return Results.Ok(response);
    }

    private static async Task<IResult> UpdateLevelTemplateValues(
       LevelTemplateValueDto dto,
     IRfidLevelTemplateService service,
     CancellationToken ct = default)
    {
        var response = await service.UpdateLevelTemplateValueAsync(dto, ct);
        return Results.Ok(response);
    }
}