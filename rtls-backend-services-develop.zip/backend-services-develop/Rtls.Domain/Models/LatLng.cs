﻿using NetTopologySuite.Geometries;

namespace Rtls.Domain.Models;

public class LatLng
{
    public double Latitude { get; set; }
    public double Longitude { get; set; }

    public static LatLng? FromPoint(Point? point)
    {
        if (point == null) return null;

        return new LatLng
        {
            Latitude = point.X,
            Longitude = point.Y
        };
    }
}