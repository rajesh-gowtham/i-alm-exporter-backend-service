﻿namespace Rtls.Domain.Models;

public class PagedResponse<T>(int total, T[] records)
    where T : class
{
    public int TotalCount { get; } = total;
    public T[] Items { get; } = records;
    public static PagedResponse<T> Empty => new(0, []);
}