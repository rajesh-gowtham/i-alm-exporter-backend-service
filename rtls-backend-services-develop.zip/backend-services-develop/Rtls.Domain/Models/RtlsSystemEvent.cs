﻿namespace Rtls.Domain.Models;


public record RtlsSystemEvent<T>(SystemEventType Type, T? Entity = default)
{
    public DateTime UtcTime { get; init; } = DateTime.UtcNow;
}

public enum SystemEventType
{
    PowAssignmentCreated,
    PowAssignmentUpdated,
    PowAssignmentDeleted,
    WorkInstructionCreated,
    WorkInstructionUpdated,
}