﻿using System.ComponentModel;
using System.Text.Json.Serialization;
using NetTopologySuite.Geometries;

namespace Rtls.Domain.Models;

public record DeviceMessage
{
    public required string DeviceId { get; init; }
    public DateTime GpsTime { get; init; }
    public DateTime ReceiveTime { get; init; }
    public double Latitude { get; init; }
    public double Longitude { get; init; }
    public short Altitude { get; init; }
    public short Heading { get; init; }
    public Dictionary<string, object> Parameters { get; init; } = new();

    /// <summary>
    /// IDs of zones where message was created
    /// </summary>
    public List<int> Zones { get; init; } = new();

    // indexer to allow use [] notation.
    public object this[string key]
    {
        get => Parameters[key];
        set => Parameters[key] = value;
    }

    public T? GetParam<T>(string key, T? defaultValue = default)
    {
        ArgumentNullException.ThrowIfNull(key);
        if (Parameters.Count == 0) return defaultValue;

        if (Parameters.TryGetValue(key, out var paramValue) && paramValue != null)
        {
            if (paramValue is T typedValue) return typedValue;
            var converter = TypeDescriptor.GetConverter(typeof(T));
            if (converter.CanConvertFrom(typeof(string)))
            {
                var value = (T)converter.ConvertFromString(paramValue.ToString());
                return value;
            }
        }

        return defaultValue;
    }

    private Point? _point;

    [JsonIgnore]
    public Point Location
    {
        get
        {
            if (_point == null)
            {
                _point = new Point(new Coordinate(Longitude, Latitude));
            }
            return _point;
        }
    }

    [JsonIgnore]
    public bool IgnitionOn => Parameters.ContainsKey("eldIgnition")
        ? EldIgnition
        : GetParam<bool>("ignition");

    [JsonIgnore]
    public short Speed => GetParam<short>("speed");

    [JsonIgnore]
    public int Rpm => GetParam<int>("rpmObd");

    [JsonIgnore]
    public int EngineCoolantTemp => GetParam<int>("engineCoolantTemp");

    [JsonIgnore]
    public byte GsmSignal => GetParam<byte>("GSMSignal");

    [JsonIgnore]
    public int ExternalVoltage => GetParam<int>("externalVoltage");

    #region ELD IO elements

    [JsonIgnore]
    public long DashboardMileage => GetParam<long>("dashboardMileage");

    [JsonIgnore]
    public long EngineHours => GetParam<long>("engineHours");

    [JsonIgnore]
    public bool EldIgnition
    {
        get
        {
            if (!Parameters.TryGetValue("eldIgnition", out var value))
                return false;
            if (value == null) return false;

            var strValue = value.ToString();
            return strValue == "1" || strValue!.Equals("true", StringComparison.OrdinalIgnoreCase);
        }
    }

    [JsonIgnore]
    public byte ParkingBrakeSwitch => GetParam<byte>("parkingBrakeSwitch");

    [JsonIgnore]
    public int TotalFuel => GetParam<int>("totalFuel");

    [JsonIgnore]
    public int TotalIdleFuel => GetParam<int>("totalIdleFuel");

    [JsonIgnore]
    public int EngineIdleHours => GetParam<int>("engineIdleHours");

    [JsonIgnore]
    public int AmbientAirTemp => GetParam<int>("ambientAirTemp");

    [JsonIgnore]
    public byte CruiseControlState => GetParam<byte>("cruiseControlState");

    [JsonIgnore]
    public int OilTemperature => GetParam<int>("oilTemp");

    [JsonIgnore]
    public int OilPressure => GetParam<int>("oilPressure");

    /// <summary>
    /// Value in %
    /// </summary>
    [JsonIgnore]
    public byte ThrottlePedalPos => GetParam<byte>("throttlePedalPos");

    /// <summary>
    /// Value in %
    /// </summary>
    [JsonIgnore]
    public byte EngineCoolantLevel => GetParam<byte>("engineCoolantLevel");

    [JsonIgnore]
    public int TransmissionOilTemp => GetParam<int>("transmissionOilTemp");

    /// <summary>
    /// Value in %
    /// </summary>
    [JsonIgnore]
    public byte BrakePedalPos => GetParam<byte>("brakePedalPos");

    #endregion

}