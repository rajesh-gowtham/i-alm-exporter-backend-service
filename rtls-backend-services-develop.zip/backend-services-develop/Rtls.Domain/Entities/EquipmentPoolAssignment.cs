namespace Rtls.Domain.Entities;

public class EquipmentPoolAssignment : IAuditableEntity
{
    public long Id { get; set; }
    public long EquipmentPoolId { get; set; }
    public long EquipmentId { get; set; }
    public bool? AssignmentStatus { get; set; }
    public DateTime EquipmentAssignedDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    public EquipmentPool EquipmentPool { get; set; }
    public Equipment Equipment { get; set; }
}
