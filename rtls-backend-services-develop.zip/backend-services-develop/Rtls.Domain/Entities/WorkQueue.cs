﻿namespace Rtls.Domain.Entities;

public class WorkQueue : IAuditableEntity
{
    public long Id { get; set; }
    public string? Name { get; set; }
    public string? Type { get; set; }
    public string? Deck { get; set; }
    public string Status { get; set; }
    public long VesselVisitId { get; set; }
    public long PointOfWorkId { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public VesselVisit VesselVisit { get; set; } = default!;
    public PointOfWork PointOfWork { get; set; } = default!;
    public ICollection<WorkInstruction> WorkInstructions { get; set; } = new List<WorkInstruction>();
    public ICollection<AlarmsEvents> AlarmsEvents { get; set; } = new List<AlarmsEvents>();
}