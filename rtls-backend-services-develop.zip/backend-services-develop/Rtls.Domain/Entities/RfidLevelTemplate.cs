﻿namespace Rtls.Domain.Entities
{
    public class RfidLevelTemplate : IAuditableEntity
    {
        public long Id { get; set; }
        public string LTName { get; set; }
        public long LTID { get; set; }
        public long LTParentID { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public ICollection<RfidLevelTemplateValues> LevelTemplateValues { get; set; } = new List<RfidLevelTemplateValues>();
    }
}
