namespace Rtls.Domain.Entities;

public class EquipmentPool : IAuditableEntity
{
    public long Id { get; set; }
    public string PoolName { get; set; } = default!;
    public string? DispatchState { get; set; }
    public string? OperatingMode { get; set; }
    public string? JobStartPosition { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    // Navigation property to Equipment (1:1)

    // one Pool → many assignments
    public ICollection<EquipmentPoolAssignment> Assignments { get; set; } = new List<EquipmentPoolAssignment>();

    // one Pool → many POW assignments
    public ICollection<PowAssignment> PowAssignments { get; set; } = new List<PowAssignment>();
}
