namespace Rtls.Domain.Entities;

public class VesselVisit : IAuditableEntity
{
    public long Id { get; set; }
    public string InboundVoyage { get; set; } = default!;
    public string OutboundVoyage { get; set; } = default!;
    public VesselVisitPhase Phase { get; set; } = default!;
    public string LineOperator { get; set; } = default!;
    public DateTime Eta { get; set; }
    public DateTime Etd { get; set; }
    public string VisitRef { get; set; }
    public DateTime? Ata { get; set; }
    public DateTime? Atd { get; set; }
    public DateTime? StartWorkTime { get; set; }
    public DateTime? EndWorkTime { get; set; }
    public long VesselId { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Classification { get; set; }
    public string? Service { get; set; }
    // Navigation properties
    // one Visit → one Berthing
    public VesselBerthing? VesselBerthing { get; set; }
    public Vessel? Vessel { get; set; }
    // one Visit → many WorkInstructions
    public ICollection<WorkInstruction> WorkInstructions { get; set; } = new List<WorkInstruction>();
    public ICollection<WorkQueue> WorkQueues { get; set; } = new List<WorkQueue>();
    public ICollection<AlarmsEvents> AlarmsEvents { get; set; } = new List<AlarmsEvents>();
}
