namespace Rtls.Domain.Entities;

public class Vessel : IAuditableEntity
{
    public long Id { get; set; }
    public string VesselName { get; set; }
    public int OverallLength { get; set; }
    public string LloydsIdentity { get; set; }
    public string VesselClass { get; set; }
    public string RadioCallSign { get; set; }
    public string Operator { get; set; }
    public bool? Status { get; set; }
    public string CreatedBy { get; set; }
    public string UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Notes { get; set; }

    // Navigation properties
    // one Vessel → many visits
    public ICollection<VesselVisit> Visits { get; set; } = new List<VesselVisit>();
}
