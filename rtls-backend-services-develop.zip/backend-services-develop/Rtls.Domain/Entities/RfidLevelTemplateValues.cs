﻿namespace Rtls.Domain.Entities
{
    public class RfidLevelTemplateValues : IAuditableEntity
    {
        public long Id { get; set; }
        public string LTValue { get; set; }
        public long LtVID { get; set; }
        public long LTID { get; set; }
        public long LtVParentID { get; set; }
        public string LtVDescription { get; set; } = default!;
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public RfidLevelTemplate LevelTemplate { get; set; } = default!;
    }
}
