﻿namespace Rtls.Domain.Entities
{
    public class VmtAuditLogin : IAuditableEntity
    {
        public long Id { get; set; }
        public string UserId { get; set; } = default!;
        public string EquipmentId { get; set; } = default!;
        public DateTime? LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public DateTime? IdleTime { get; set; }
        public DateTime? StoppageTime { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
