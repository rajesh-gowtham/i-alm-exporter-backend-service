namespace Rtls.Domain.Entities;

public class Equipment : IAuditableEntity
{
    public long Id { get; set; }
    public string EquipmentName { get; set; } = null!;
    public string EquipmentType { get; set; } = null!;
    public int? MaxWeight { get; set; }
    public int? MaxTeu { get; set; }
    public string? Status { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public long? VmtUserId { get; set; }
    public string? CurrentPosition { get; set; }
    public string? Origin { get; set; }
    public string? Destination { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public string? RfidTag1 { get; set; }
    public string? RfidTag2 { get; set; }
    // Navigation properties
    // one Equipment ← many assignments
    public ICollection<EquipmentPoolAssignment> PoolAssignments { get; set; } = new List<EquipmentPoolAssignment>();
    // one Equipment ← many work instructions
    public ICollection<WorkInstruction> WorkInstructions { get; set; } = new List<WorkInstruction>();
    public ICollection<AlarmsEvents> AlarmsEvents { get; set; } = new List<AlarmsEvents>();
    public VmtUsers? VmtUser { get; set; }
}
