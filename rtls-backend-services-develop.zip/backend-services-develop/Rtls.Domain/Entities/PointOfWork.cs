namespace Rtls.Domain.Entities;

public class PointOfWork : IAuditableEntity
{
    public long Id { get; set; }
    public string Name { get; set; }
    public bool Status { get; set; }
    public string Pool { get; set; }
    public string CreatedBy { get; set; }
    public string UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // one PointOfWork → many WorkInstructions
    public ICollection<WorkInstruction> WorkInstructions { get; set; } = new List<WorkInstruction>();
    public ICollection<WorkQueue> WorkQueues { get; set; } = new List<WorkQueue>();
    public ICollection<PowAssignment> Assignments { get; set; } = new List<PowAssignment>();
}
