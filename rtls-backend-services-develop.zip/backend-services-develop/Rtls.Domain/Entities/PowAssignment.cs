namespace Rtls.Domain.Entities;

public class PowAssignment : IAuditableEntity
{
    public long Id { get; set; }
    public long PowId { get; set; }
    public long EquipmentPoolId { get; set; }
    public bool? EquipmentPoolStatus { get; set; }
    
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    public PointOfWork PointOfWork { get; set; } = null!;
    public EquipmentPool EquipmentPool { get; set; } = null!;
}
