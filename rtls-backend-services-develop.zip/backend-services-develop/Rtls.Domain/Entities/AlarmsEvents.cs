﻿namespace Rtls.Domain.Entities
{
    public class AlarmsEvents : IAuditableEntity
    {
        public long Id { get; set; }
        public string EventName { get; set; } = default!;
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public long VesselVisitId { get; set; }
        public long EquipmentId { get; set; }
        public long WorkQueueId { get; set; }
        public string? Notes { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public VesselVisit VesselVisit { get; set; }
        public WorkQueue WorkQueue { get; set; }
        public Equipment Equipment { get; set; }
    }
}
