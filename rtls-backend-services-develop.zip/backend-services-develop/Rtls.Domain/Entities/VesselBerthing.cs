namespace Rtls.Domain.Entities;

public class VesselBerthing : IAuditableEntity
{
    public long Id { get; set; }
    public string Quay { get; set; } = null!;
    public BerthingSide BerthingSide { get; set; }
    public DateTime? BerthEta { get; set; }
    public DateTime? BerthEtd { get; set; }
    public DateTime? BerthAta { get; set; }
    public DateTime? StartWorkTime { get; set; }
    public DateTime? EndWorkTime { get; set; }
    public long? VesselVisitId { get; set; }
    
    public string? StartBollard { get; set; }
    public string? EndBollard { get; set; }

    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    // Navigation properties
    public VesselVisit? VesselVisit { get; set; } // 1:1 via PK-FK
}
