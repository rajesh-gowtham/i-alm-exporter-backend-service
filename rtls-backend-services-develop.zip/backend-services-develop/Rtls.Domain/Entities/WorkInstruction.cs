using System.Text.Json.Serialization;

namespace Rtls.Domain.Entities;

public class WorkInstruction : IAuditableEntity
{
    public long Id { get; set; }
    public long VesselVisitId { get; set; }
    public string MoveType { get; set; } = default!;
    public string FromLocation { get; set; } = default!;
    public string TargetLocation { get; set; } = default!;
    public string IsoCode { get; set; } = default!;
    // CHE - container handling equipment
    public string AssignedChe { get; set; } = default!;
    public string CheCarry { get; set; } = default!;
    public string PositionOnCarriage { get; set; } = default!;
    public string ContainerId { get; set; } = default!;
    public string WorkInstructionStatus { get; set; } = default!;
    public string JobSteppingStatus { get; set; } = default!;
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public long Sequence { get; set; }
    public string Mode { get; set; } = default!;
    public string? InboundLocationType { get; set; }
    public string? OutboundLocationType { get; set; }
    public string? OutboundCarrier { get; set; }
    public string Deck { get; set; } = default!;
    public long WorkQueueId { get; set; } = default!;
    public string? PairContainer { get; set; }
    public long Weight { get; set; }
    public string AssignedLane { get; set; } = default!;
    public DateTime? JobStartTime { get; set; }
    public DateTime? DispatchTime { get; set; }
    public DateTime? TimeAtOrigin { get; set; }
    public DateTime? DischargeTime { get; set; }
    public DateTime? TimeFacilityIn { get; set; }
    public DateTime? TimeAtDestination { get; set; }
    public DateTime? JobCompleteTime { get; set; }
    public string? TaskStatus { get; set; }
    // Navigation properties
    public VesselVisit VesselVisit { get; set; } = default!;
    public long PointOfWorkId { get; set; }
    public PointOfWork PointOfWork { get; set; } = default!;
    public WorkQueue WorkQueue { get; set; } = default!;

    [JsonIgnore]
    public int BayNumber
    {
        get
        {
            if (string.IsNullOrEmpty(TargetLocation) || TargetLocation.Length < 4)
                return 0;
            return int.TryParse(TargetLocation[2..4], out var bayNumber) ? bayNumber : 0;
        }
    } 
}
