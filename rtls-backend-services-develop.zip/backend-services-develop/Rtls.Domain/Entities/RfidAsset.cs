﻿namespace Rtls.Domain.Entities
{
    public class RfidAsset : IAuditableEntity
    {
        public long Id { get; set; }
        public string ReaderIP { get; set; } = default!;
        public string RPName { get; set; }
        public long AntennaID { get; set; }
        public long RPID { get; set; }
        public string ReaderType { get; set; } = default!;
        public string ReaderModel { get; set; } = default!;
        public string Lat { get; set; } = default!;
        public string Long { get; set; } = default!;
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
