using System.ComponentModel.DataAnnotations;

namespace Rtls.Domain.Entities;

public enum VesselVisitPhase { Inbound, Arrived, Working, Completed, Departed }
public enum BerthingSide { Starboard, Port }
public enum MoveType { Load, Discharge }

#region Telematics
public enum DeviceType
{
    [Display(Name = "ECU Reader")]
    ECUReader,

    [Display(Name = "CAN bus logger")]
    CANBusLogger,

    [Display(Name = "Speed Sensor")]
    SpeedSensor,

    [Display(Name = "Battery monitor")]
    BatteryMonitor
}

public enum CommunicationProtocol
{
    [Display(Name = "CAN Bus")]
    CANBus,

    [Display(Name = "RS-232")]
    RS232,

    BLE,
    LoRa,
    LTE
}

public enum PowerSource
{
    [Display(Name = "Vehicle battery")]
    VehicleBattery,

    [Display(Name = "External wired")]
    ExternalWired,

    [Display(Name = "Self-powered")]
    SelfPowered
}
#endregion