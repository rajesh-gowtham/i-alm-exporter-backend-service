namespace Rtls.Domain.Entities;

public class Telematics : IAuditableEntity
{
    public long Id { get; set; }
    public string DeviceId { get; set; } = default!;
    public string Manufacturer { get; set; } = default!;
    public string Model { get; set; } = default!;
    public string FirmwareVersion { get; set; } = default!;

    public DeviceType DeviceType { get; set; }
    public CommunicationProtocol CommunicationProtocol { get; set; }
    public PowerSource PowerSource { get; set; }

    public DateTime? WarrantyStartDate { get; set; }
    public DateTime? WarrantyExpiryDate { get; set; }

    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}
