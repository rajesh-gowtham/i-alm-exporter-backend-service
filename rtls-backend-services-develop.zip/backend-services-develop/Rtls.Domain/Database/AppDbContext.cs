﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database;

public class AppDbContext(DbContextOptions<AppDbContext> options) : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Equipment> Equipments => Set<Equipment>();
    public DbSet<EquipmentPool> EquipmentPools => Set<EquipmentPool>();
    public DbSet<Vessel> Vessels => Set<Vessel>();
    public DbSet<VesselVisit> VesselVisits => Set<VesselVisit>();
    public DbSet<VesselBerthing> VesselBerthings => Set<VesselBerthing>();
    public DbSet<PointOfWork> PointOfWorks => Set<PointOfWork>();
    public DbSet<WorkQueue> WorkQueues => Set<WorkQueue>();
    public DbSet<WorkInstruction> WorkInstructions => Set<WorkInstruction>();
    public DbSet<EquipmentPoolAssignment> EquipmentPoolAssignments => Set<EquipmentPoolAssignment>();
    public DbSet<PowAssignment> PowAssignments => Set<PowAssignment>();
    public DbSet<VmtUsers> VmtUsers => Set<VmtUsers>();
    public DbSet<VmtAuditLogin> VmtAuditLogins => Set<VmtAuditLogin>();
    public DbSet<RfidAsset> RfidAssets => Set<RfidAsset>();
    public DbSet<AlarmsEvents> AlarmsEvents => Set<AlarmsEvents>();
    public DbSet<Telematics> Telematics => Set<Telematics>();
    public DbSet<RfidLevelTemplate> RfidLevelTemplate => Set<RfidLevelTemplate>();
    public DbSet<RfidLevelTemplateValues> RfidLevelTemplateValues => Set<RfidLevelTemplateValues>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        
        if (Database.IsNpgsql())
        {
            modelBuilder
                .HasPostgresExtension("uuid-ossp")
                .HasAnnotation("Relational:Collation", "en_US.UTF-8")
                .UseIdentityByDefaultColumns();
        }
        
        modelBuilder.Entity<ApplicationUser>(b =>
        {
            b.ToTable("auth_users");
        });

        modelBuilder.Entity<IdentityUserClaim<string>>(b =>
        {
            b.ToTable("auth_user_claims");
        });

        modelBuilder.Entity<IdentityUserLogin<string>>(b =>
        {
            b.ToTable("auth_user_logins");
        });

        modelBuilder.Entity<IdentityUserToken<string>>(b =>
        {
            b.ToTable("auth_user_tokens");
        });

        modelBuilder.Entity<IdentityRole>(b =>
        {
            b.ToTable("auth_roles");
        });

        modelBuilder.Entity<IdentityRoleClaim<string>>(b =>
        {
            b.ToTable("auth_role_claims");
        });

        modelBuilder.Entity<IdentityUserRole<string>>(b =>
        {
            b.ToTable("auth_user_roles");
        });
    }
}