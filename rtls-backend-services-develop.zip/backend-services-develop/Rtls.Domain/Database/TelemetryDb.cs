﻿using System.Data;
using System.Text.Json;
using Dapper;
using NetTopologySuite.Geometries;
using Npgsql;
using NpgsqlTypes;

namespace Rtls.Domain.Database;

public class TelemetryDb : ITelemetryDb
{
    private readonly NpgsqlDataSource _dataSource;

    public TelemetryDb(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource;
        DefaultTypeMap.MatchNamesWithUnderscores = true;
        SqlMapper.AddTypeHandler(new GeographyTypeHandler<Point>());
        SqlMapper.AddTypeHandler(new GeographyTypeHandler<Polygon>());
        SqlMapper.AddTypeHandler(typeof(Dictionary<string, object>), new JsonTypeHandler());
    }

    public NpgsqlDataSource GetDataSource() => _dataSource;
}

public interface ITelemetryDb
{
    NpgsqlDataSource GetDataSource();
}

public sealed class GeographyTypeHandler<T> : SqlMapper.TypeHandler<T> where T : Geometry
{
    public override T Parse(object value)
    {
        if (value is Geometry geometry)
        {
            return (T)geometry;
        }

        throw new ArgumentException(null, nameof(value));
    }

    public override void SetValue(IDbDataParameter parameter, T value)
    {
        if (parameter is NpgsqlParameter npgsqlParameter)
        {
            npgsqlParameter.NpgsqlDbType = NpgsqlDbType.Geography;
            npgsqlParameter.NpgsqlValue = value;
        }
        else
        {
            throw new ArgumentException();
        }
    }
}

public class JsonTypeHandler : SqlMapper.ITypeHandler
{
    public void SetValue(IDbDataParameter parameter, object value) =>
        parameter.Value = JsonSerializer.Serialize(value);

    public object? Parse(Type destinationType, object value)
    {
        return JsonSerializer.Deserialize(
            value as string ?? string.Empty,
            destinationType);
    }
}