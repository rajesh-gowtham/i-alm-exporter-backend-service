﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;


namespace Rtls.Domain.Database.Configuration
{
    public class WorkQueueConfiguration : IEntityTypeConfiguration<WorkQueue>
    {
        public void Configure(EntityTypeBuilder<WorkQueue> builder)
        {
            builder.HasKey(w => w.Id);

            builder.Property(w => w.VesselVisitId)
                .IsRequired();

            builder.Property(w => w.Deck)
                .IsRequired();

            builder.Property(w => w.Name)
                .IsRequired();

            builder.Property(w => w.PointOfWorkId)
                .IsRequired();

            builder.Property(w => w.CreatedBy);

            builder.Property(w => w.UpdatedBy);

            builder.Property(w => w.CreatedAt);

            builder.Property(w => w.UpdatedAt);

            builder.HasOne(w => w.VesselVisit)
            .WithMany(w => w.WorkQueues)
            .HasForeignKey(w => w.VesselVisitId)
            .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(w => w.PointOfWork)
                .WithMany(w => w.WorkQueues)
                .HasForeignKey(w => w.PointOfWorkId) // Use scalar foreign key property
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
