using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class EquipmentConfiguration : IEntityTypeConfiguration<Equipment>
{
    public void Configure(EntityTypeBuilder<Equipment> builder)
    {
        builder.HasKey(e => e.Id);

        builder.Property(e => e.EquipmentName)
            .IsRequired();

        builder.Property(e => e.EquipmentType)
            .IsRequired();

        builder.Property(e => e.MaxWeight);
        builder.Property(e => e.MaxTeu);
        builder.Property(e => e.Status);
        builder.Property(e => e.CreatedBy);
        builder.Property(e => e.UpdatedBy);
        builder.Property(e => e.CreatedAt);
        builder.Property(e => e.UpdatedAt);
    }
}