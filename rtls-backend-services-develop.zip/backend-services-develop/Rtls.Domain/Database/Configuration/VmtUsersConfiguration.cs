using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class VmtUsersConfiguration : IEntityTypeConfiguration<VmtUsers>
{
    public void Configure(EntityTypeBuilder<VmtUsers> builder)
    {
        builder.HasKey(v => v.Id);

        builder.Property(v => v.UserId)
            .IsRequired();

        builder.Property(v => v.CreatedBy);

        builder.Property(v => v.UpdatedBy);

        builder.Property(v => v.CreatedAt);

        builder.Property(v => v.UpdatedAt);
    }
}