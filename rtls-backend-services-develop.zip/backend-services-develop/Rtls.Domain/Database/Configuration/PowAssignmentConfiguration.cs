using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class PowAssignmentConfiguration : IEntityTypeConfiguration<PowAssignment>
{
    public void Configure(EntityTypeBuilder<PowAssignment> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.PowId)
            .IsRequired();

        builder.Property(p => p.EquipmentPoolId)
            .IsRequired();

        builder.Property(p => p.EquipmentPoolStatus);

        builder.Property(p => p.CreatedBy);
        builder.Property(p => p.UpdatedBy);
        builder.Property(p => p.CreatedAt);
        builder.Property(p => p.UpdatedAt);

        builder.HasOne(p => p.PointOfWork)
            .WithMany(p => p.Assignments)
            .HasForeignKey(p => p.PowId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(p => p.EquipmentPool)
            .WithMany(p => p.PowAssignments)
            .HasForeignKey(p => p.EquipmentPoolId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}