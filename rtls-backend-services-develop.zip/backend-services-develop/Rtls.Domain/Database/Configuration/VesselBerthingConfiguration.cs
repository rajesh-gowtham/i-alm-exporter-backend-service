using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class VesselBerthingConfiguration : IEntityTypeConfiguration<VesselBerthing>
{
    public void Configure(EntityTypeBuilder<VesselBerthing> builder)
    {
        builder.HasKey(vb => vb.Id);

        builder.Property(vb => vb.Quay)
            .IsRequired();

        builder.Property(vb => vb.BerthingSide)
            .IsRequired();

        builder.Property(vb => vb.BerthEta);

        builder.Property(vb => vb.BerthEtd);

        builder.Property(vb => vb.BerthAta);

        builder.Property(vb => vb.StartWorkTime);

        builder.Property(vb => vb.VesselVisitId)
            .IsRequired();
            
        builder.Property(vb => vb.StartBollard);
        
        builder.Property(vb => vb.EndBollard);

        builder.Property(vb => vb.CreatedBy);

        builder.Property(vb => vb.UpdatedBy);

        builder.Property(vb => vb.CreatedAt);

        builder.Property(vb => vb.UpdatedAt);

        builder
            .HasOne(x => x.VesselVisit)
            .WithOne(x => x.VesselBerthing)
            // .HasForeignKey<VesselBerthing>(vb => vb.Id)
            .HasForeignKey<VesselBerthing>(x => x.VesselVisitId)
            .OnDelete(DeleteBehavior.Restrict);

        // builder.HasOne(vb => vb.VesselVisitRef)
        //     .WithMany()
        //     .HasForeignKey(vb => vb.VesselVisitId)
        //     .OnDelete(DeleteBehavior.Restrict);
    }
}