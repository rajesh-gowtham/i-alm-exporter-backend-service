using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class VesselVisitConfiguration : IEntityTypeConfiguration<VesselVisit>
{
    public void Configure(EntityTypeBuilder<VesselVisit> builder)
    {
        builder.HasKey(vv => vv.Id);

        builder.Property(vv => vv.VisitRef)
            .IsRequired();

        builder.HasIndex(vv => vv.VisitRef)
            .IsUnique();

        builder.Property(vv => vv.InboundVoyage)
            .IsRequired();

        builder.Property(vv => vv.OutboundVoyage)
            .IsRequired();

        builder.Property(vv => vv.Phase)
            .IsRequired();

        builder.Property(vv => vv.LineOperator)
            .IsRequired();

        builder.Property(vv => vv.Eta)
            .IsRequired();

        builder.Property(vv => vv.Etd)
            .IsRequired();

        builder.Property(vv => vv.VisitRef);

        builder.Property(vv => vv.Ata);

        builder.Property(vv => vv.Atd);

        builder.Property(vv => vv.StartWorkTime);

        builder.Property(vv => vv.EndWorkTime);

        builder.Property(vv => vv.VesselId)
            .IsRequired();

        builder.Property(vv => vv.CreatedBy);

        builder.Property(vv => vv.UpdatedBy);

        builder.Property(vv => vv.CreatedAt);

        builder.Property(vv => vv.UpdatedAt);

        builder.Property(vv => vv.Classification);

        builder.Property(vv => vv.Service);

        builder.HasOne(vv => vv.Vessel)
            .WithMany(v => v.Visits)
            .HasForeignKey(vv => vv.VesselId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}