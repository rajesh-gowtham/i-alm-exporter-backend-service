using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class PointOfWorkConfiguration : IEntityTypeConfiguration<PointOfWork>
{
    public void Configure(EntityTypeBuilder<PointOfWork> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Name)
            .IsRequired();

        builder.Property(p => p.Status);
        builder.Property(p => p.Pool)
           .IsRequired();
        builder.Property(p => p.CreatedBy);
        builder.Property(p => p.UpdatedBy);
        builder.Property(p => p.CreatedAt);
        builder.Property(p => p.UpdatedAt);
    }
}