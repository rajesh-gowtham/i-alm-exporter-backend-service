﻿namespace Rtls.Domain.Database.Configuration;

public class IdentityConfiguration
{
}