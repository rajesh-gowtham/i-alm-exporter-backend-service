﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class TelematicsConfiguration : IEntityTypeConfiguration<Telematics>
{
    public void Configure(EntityTypeBuilder<Telematics> builder)
    {
        // Primary key
        builder.HasKey(x => x.Id);
        
        // Property configurations
        builder.Property(x => x.Id)
            .ValueGeneratedOnAdd();
        
        builder.Property(x => x.DeviceId)
            .IsRequired()
            .HasMaxLength(100);
        
        builder.Property(x => x.Manufacturer)
            .IsRequired()
            .HasMaxLength(100);
        
        builder.Property(x => x.Model)
            .IsRequired()
            .HasMaxLength(100);
        
        builder.Property(x => x.FirmwareVersion)
            .IsRequired()
            .HasMaxLength(100);
        
        // Enum configurations - store as strings for better readability
        builder.Property(x => x.DeviceType)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(50);
        
        builder.Property(x => x.CommunicationProtocol)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(50);
        
        builder.Property(x => x.PowerSource)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(50);
        
        // Audit fields
        builder.Property(x => x.CreatedBy).HasMaxLength(100);
        builder.Property(x => x.UpdatedBy).HasMaxLength(100);
        builder.Property(x => x.CreatedAt);
        builder.Property(x => x.UpdatedAt);
        
        // Warranty dates
        builder.Property(x => x.WarrantyStartDate);
        builder.Property(x => x.WarrantyExpiryDate);
        
        // Indexes
        builder.HasIndex(x => x.DeviceId).IsUnique();
        builder.HasIndex(x => x.DeviceType);
        builder.HasIndex(x => x.CreatedAt);
    }
}