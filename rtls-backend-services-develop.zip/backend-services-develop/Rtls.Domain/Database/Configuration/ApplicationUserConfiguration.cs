using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class ApplicationUserConfiguration : IEntityTypeConfiguration<ApplicationUser>
{
    public void Configure(EntityTypeBuilder<ApplicationUser> builder)
    {
        // Each User can have many UserClaims
        builder.HasMany(e => e.Claims)
            .WithOne()
            .HasForeignKey(uc => uc.UserId)
            .IsRequired();

        // Each User can have many UserLogins
        builder.HasMany(e => e.Logins)
            .WithOne()
            .HasForeignKey(ul => ul.UserId)
            .IsRequired();

        // Each User can have many UserTokens
        builder.HasMany(e => e.Tokens)
            .WithOne()
            .HasForeignKey(ut => ut.UserId)
            .IsRequired();

        // Each User can have many entries in the UserRole join table
        builder.HasMany(e => e.UserRoles)
            .WithOne()
            .HasForeignKey(ur => ur.UserId)
            .IsRequired();
        
        // builder.HasKey(u => u.Id);
        //
        // builder.HasMany<IdentityUserClaim<string>>(u => u.Claims)
        //     .WithOne()
        //     .HasForeignKey(c => c.UserId)
        //     .IsRequired()
        //     .OnDelete(DeleteBehavior.Cascade);
        //
        // builder.HasMany<IdentityUserLogin<string>>(u => u.Logins)
        //     .WithOne()
        //     .HasForeignKey(l => l.UserId)
        //     .IsRequired()
        //     .OnDelete(DeleteBehavior.Cascade);
        //
        // builder.HasMany<IdentityUserToken<string>>(u => u.Tokens)
        //     .WithOne()
        //     .HasForeignKey(t => t.UserId)
        //     .IsRequired()
        //     .OnDelete(DeleteBehavior.Cascade);
        //
        // builder.HasMany<IdentityUserRole<string>>(u => u.UserRoles)
        //     .WithOne()
        //     .HasForeignKey(ur => ur.UserId)
        //     .IsRequired()
        //     .OnDelete(DeleteBehavior.Cascade);
    }
}