using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class VesselConfiguration : IEntityTypeConfiguration<Vessel>
{
    public void Configure(EntityTypeBuilder<Vessel> builder)
    {
        builder.HasKey(v => v.Id);

        builder.Property(v => v.VesselName)
            .IsRequired();

        builder.Property(v => v.OverallLength)
            .IsRequired();

        builder.Property(v => v.LloydsIdentity)
            .IsRequired();

        builder.Property(v => v.VesselClass)
            .IsRequired();

        builder.Property(v => v.RadioCallSign)
            .IsRequired();

        builder.Property(v => v.Operator)
            .IsRequired();

        builder.Property(v => v.Status);

        builder.Property(v => v.CreatedBy);

        builder.Property(v => v.UpdatedBy);

        builder.Property(v => v.CreatedAt);

        builder.Property(v => v.UpdatedAt);

        builder.Property(v => v.Notes);
    }
}