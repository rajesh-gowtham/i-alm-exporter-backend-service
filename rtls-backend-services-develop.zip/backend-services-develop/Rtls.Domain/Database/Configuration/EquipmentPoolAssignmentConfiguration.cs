using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class EquipmentPoolAssignmentConfiguration : IEntityTypeConfiguration<EquipmentPoolAssignment>
{
    public void Configure(EntityTypeBuilder<EquipmentPoolAssignment> builder)
    {
        builder.HasKey(e => e.Id);

        builder.Property(e => e.EquipmentPoolId)
            .IsRequired();

        builder.Property(e => e.EquipmentId)
            .IsRequired();

        builder.Property(e => e.AssignmentStatus);

        builder.Property(e => e.EquipmentAssignedDate)
            .IsRequired();

        builder.Property(e => e.CreatedBy);

        builder.Property(e => e.UpdatedBy);

        builder.Property(e => e.CreatedAt);

        builder.Property(e => e.UpdatedAt);

        builder.HasOne(e => e.EquipmentPool)
            .WithMany(e => e.Assignments)
            .HasForeignKey(e => e.EquipmentPoolId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(e => e.Equipment)
            .WithMany(e => e.PoolAssignments)
            .HasForeignKey(e => e.EquipmentId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}