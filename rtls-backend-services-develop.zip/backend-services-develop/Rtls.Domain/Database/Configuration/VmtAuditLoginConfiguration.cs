using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class VmtAuditLoginConfiguration : IEntityTypeConfiguration<VmtAuditLogin>
{
    public void Configure(EntityTypeBuilder<VmtAuditLogin> builder)
    {
        builder.HasKey(v => v.Id);

        builder.Property(v => v.UserId)
            .IsRequired();

        builder.Property(v => v.EquipmentId)
           .IsRequired();

        builder.Property(v => v.LoginTime);

        builder.Property(v => v.LogoutTime);

        builder.Property(v => v.StoppageTime);

        builder.Property(v => v.IdleTime);

        builder.Property(v => v.UpdatedBy);

        builder.Property(v => v.CreatedAt);

        builder.Property(v => v.UpdatedAt);
    }
}