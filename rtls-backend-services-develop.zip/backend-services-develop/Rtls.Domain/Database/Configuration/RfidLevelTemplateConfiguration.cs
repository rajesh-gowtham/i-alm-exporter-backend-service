﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class RfidLevelTemplateConfiguration : IEntityTypeConfiguration<RfidLevelTemplate>
{
    public void Configure(EntityTypeBuilder<RfidLevelTemplate> builder)
    {
        // Primary key
        builder.HasKey(x => x.Id);
        
        // Property configurations
        builder.Property(x => x.Id)
            .ValueGeneratedOnAdd();

        builder.Property(x => x.LTID)
            .IsRequired();

        builder.Property(x => x.LTParentID)
            .IsRequired();
        
        builder.Property(x => x.LTName)
            .IsRequired()
            .HasMaxLength(100);
        
        // Audit fields
        builder.Property(x => x.CreatedBy).HasMaxLength(100);
        builder.Property(x => x.UpdatedBy).HasMaxLength(100);
        builder.Property(x => x.CreatedAt);
        builder.Property(x => x.UpdatedAt);
    }
}