using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class AlarmsEventsConfiguration : IEntityTypeConfiguration<AlarmsEvents>
{
    public void Configure(EntityTypeBuilder<AlarmsEvents> builder)
    {
        builder.HasKey(v => v.Id);

        builder.Property(v => v.EventName)
            .IsRequired();

        builder.Property(v => v.Notes);

        builder.Property(v => v.VesselVisitId);

        builder.Property(v => v.EquipmentId);

        builder.Property(v => v.WorkQueueId);

        builder.Property(v => v.StartTime);

        builder.Property(v => v.EndTime);

        builder.Property(v => v.CreatedBy);

        builder.Property(v => v.UpdatedBy);

        builder.Property(v => v.CreatedAt);

        builder.Property(v => v.UpdatedAt);

        builder.HasOne(v => v.Equipment)
          .WithMany(v => v.AlarmsEvents)
          .HasForeignKey(w => w.EquipmentId)
          .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(v => v.WorkQueue)
          .WithMany(v => v.AlarmsEvents)
          .HasForeignKey(w => w.WorkQueueId)
          .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(v => v.VesselVisit)
           .WithMany(v => v.AlarmsEvents)
           .HasForeignKey(w => w.VesselVisitId)
           .OnDelete(DeleteBehavior.Restrict);
    }
}