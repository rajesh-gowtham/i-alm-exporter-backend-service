using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class WorkInstructionConfiguration : IEntityTypeConfiguration<WorkInstruction>
{
    public void Configure(EntityTypeBuilder<WorkInstruction> builder)
    {
        builder.HasKey(w => w.Id);

        builder.Property(w => w.VesselVisitId)
            .IsRequired();

        builder.Property(w => w.MoveType)
            .IsRequired();

        builder.Property(w => w.FromLocation)
            .IsRequired();

        builder.Property(w => w.TargetLocation)
            .IsRequired();

        builder.Property(w => w.WorkInstructionStatus)
            .IsRequired();

        builder.Property(w => w.IsoCode)
            .IsRequired();

        builder.Property(w => w.AssignedChe)
            .IsRequired();

        builder.Property(w => w.CheCarry)
            .IsRequired();

        builder.Property(w => w.PositionOnCarriage)
            .IsRequired();

        builder.Property(w => w.PointOfWorkId)
            .IsRequired();

        builder.Property(w => w.ContainerId)
            .IsRequired()
            .HasMaxLength(11); // 11 digit alphanumeric value

        builder.Property(w => w.WorkInstructionStatus)
            .IsRequired();

        builder.Property(w => w.JobSteppingStatus)
            .IsRequired();

        builder.Property(w => w.CreatedBy);

        builder.Property(w => w.UpdatedBy);

        builder.Property(w => w.CreatedAt);

        builder.Property(w => w.UpdatedAt);

        builder.Property(w => w.Sequence)
            .IsRequired();

        builder.Property(w => w.Mode)
            .IsRequired();

        builder.Property(w => w.Deck)
           .IsRequired();

        builder.Property(w => w.InboundLocationType);

        builder.Property(w => w.OutboundLocationType);

        builder.Property(w => w.OutboundCarrier);

        builder.HasOne(w => w.VesselVisit)
            .WithMany(w => w.WorkInstructions)
            .HasForeignKey(w => w.VesselVisitId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(w => w.PointOfWork)
            .WithMany(w => w.WorkInstructions)
            .HasForeignKey(w => w.PointOfWorkId) // Use scalar foreign key property
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(w => w.WorkQueue)
            .WithMany(w => w.WorkInstructions)
            .HasForeignKey(w => w.WorkQueueId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}