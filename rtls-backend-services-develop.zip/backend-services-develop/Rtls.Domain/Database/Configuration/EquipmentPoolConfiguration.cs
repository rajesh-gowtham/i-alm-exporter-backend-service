using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class EquipmentPoolConfiguration : IEntityTypeConfiguration<EquipmentPool>
{
    public void Configure(EntityTypeBuilder<EquipmentPool> builder)
    {
        builder.HasKey(e => e.Id);

        builder.Property(e => e.PoolName)
            .IsRequired();

        builder.Property(e => e.DispatchState);

        builder.Property(e => e.OperatingMode);

        builder.Property(e => e.JobStartPosition);

        builder.Property(e => e.CreatedBy);

        builder.Property(e => e.UpdatedBy);

        builder.Property(e => e.CreatedAt);

        builder.Property(e => e.UpdatedAt);

    }
}