﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Rtls.Domain.Entities;

namespace Rtls.Domain.Database.Configuration;

public class RfidAssetConfiguration : IEntityTypeConfiguration<RfidAsset>
{
    public void Configure(EntityTypeBuilder<RfidAsset> builder)
    {
        // Primary key
        builder.HasKey(x => x.Id);

        // Property configurations
        builder.Property(x => x.Id)
            .ValueGeneratedOnAdd();

        builder.Property(x => x.RPName)
            .IsRequired()
            .HasMaxLength(100);
        
        builder.Property(x => x.ReaderIP)
            .IsRequired()
            .HasMaxLength(50);
        
        builder.Property(x => x.ReaderModel)
            .IsRequired()
            .HasMaxLength(100);
        
        builder.Property(x => x.ReaderType)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(x => x.AntennaID)
            .IsRequired();

        builder.Property(x => x.RPID)
            .IsRequired();
        
        // Audit fields
        builder.Property(x => x.CreatedBy).HasMaxLength(100);
        builder.Property(x => x.UpdatedBy).HasMaxLength(100);
        builder.Property(x => x.CreatedAt);
        builder.Property(x => x.UpdatedAt);
    }
}