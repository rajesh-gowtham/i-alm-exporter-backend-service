﻿using System.Collections.Concurrent;
using System.Threading.Channels;

namespace Rtls.Domain;

public interface IConsumer<T>
{
    Task OnHandle(T message);
}

public sealed class InMemoryMessageBus : IDisposable
{
    private readonly ConcurrentDictionary<Type, object> _topics = new();
    private bool _disposed;

    /// <summary>
    /// Subscribes to messages of type T, returning a ChannelReader and an IDisposable to unsubscribe.
    /// </summary>
    public IDisposable Subscribe<T>(out ChannelReader<T> reader)
    {
        ThrowIfDisposed();

        var topic = (BusTopic<T>)_topics.GetOrAdd(typeof(T), _ => new BusTopic<T>());
        var (id, rdr) = topic.AddSubscriber();
        reader = rdr;
        return new Subscription<T>(this, topic, id);
    }

    /// <summary>
    /// Subscribes to messages of type T with an async handler. Returns an IDisposable to unsubscribe.
    /// </summary>
    public IDisposable Subscribe<T>(Func<T, Task> handler, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();

        var topic = (BusTopic<T>)_topics.GetOrAdd(typeof(T), _ => new BusTopic<T>());
        var (id, reader) = topic.AddSubscriber();

        // Start a background loop that invokes the handler for each message.
        _ = Task.Run(async () =>
        {
            try
            {
                await foreach (var message in reader.ReadAllAsync(cancellationToken).ConfigureAwait(false))
                {
                    try
                    {
                        await handler(message).ConfigureAwait(false);
                    }
                    catch
                    {
                        // Swallow handler exceptions.
                    }
                }
            }
            catch (OperationCanceledException) { }
        }, cancellationToken);

        return new Subscription<T>(this, topic, id);
    }

    /// <summary>
    /// Subscribes to messages of type T with a synchronous handler. Returns an IDisposable to unsubscribe.
    /// </summary>
    public IDisposable Subscribe<T>(Action<T> handler, CancellationToken cancellationToken = default)
    {
        return Subscribe<T>(evt =>
        {
            handler(evt);
            return Task.CompletedTask;
        }, cancellationToken);
    }

    /// <summary>
    /// Subscribes to messages of type T using an IConsumer<T> implementation. Returns an IDisposable to unsubscribe.
    /// </summary>
    public IDisposable Subscribe<T>(IConsumer<T> consumer, CancellationToken cancellationToken = default)
    {
        return Subscribe<T>(message => consumer.OnHandle(message), cancellationToken);
    }

    /// <summary>
    /// Broadcasts a message of type T to all subscribers. Awaits all writes.
    /// </summary>
    public async Task PublishAsync<T>(T message, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();

        if (_topics.TryGetValue(typeof(T), out var topicObj) && topicObj is BusTopic<T> topic)
        {
            await topic.PublishAsync(message, cancellationToken).ConfigureAwait(false);
        }
    }

    /// <summary>
    /// Completes all subscriber channels and clears all topics.
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        foreach (var topicObj in _topics.Values)
        {
            if (topicObj is IDisposable disposableTopic)
            {
                disposableTopic.Dispose();
            }
        }
        _topics.Clear();
    }

    private void Unsubscribe<T>(BusTopic<T> topic, long id)
    {
        // Remove subscriber and complete its channel
        var empty = topic.RemoveSubscriber(id);

        // If no subscribers remain, remove the entire topic
        if (empty)
        {
            _topics.TryRemove(typeof(T), out _);
            topic.Dispose();
        }
    }

    private void ThrowIfDisposed()
    {
        if (_disposed) throw new ObjectDisposedException(nameof(InMemoryMessageBus));
    }

    private sealed class Subscription<T> : IDisposable
    {
        private readonly InMemoryMessageBus _bus;
        private readonly BusTopic<T> _topic;
        private readonly long _id;
        private int _disposed;

        public Subscription(InMemoryMessageBus bus, BusTopic<T> topic, long id)
        {
            _bus = bus;
            _topic = topic;
            _id = id;
        }

        public void Dispose()
        {
            if (Interlocked.Exchange(ref _disposed, 1) == 0)
            {
                _bus.Unsubscribe(_topic, _id);
            }
        }
    }

    private sealed class BusTopic<T> : IDisposable
    {
        private readonly ConcurrentDictionary<long, ChannelWriter<T>> _subscribers = new();
        private long _currentId;
        private readonly UnboundedChannelOptions _channelOptions;

        public BusTopic()
        {
            _channelOptions = new UnboundedChannelOptions
            {
                SingleWriter = false,
                SingleReader = false
            };
        }

        /// <summary>
        /// Adds a new subscriber, returning its ID and a ChannelReader for consumption.
        /// </summary>
        public (long id, ChannelReader<T> reader) AddSubscriber()
        {
            var channel = Channel.CreateUnbounded<T>(_channelOptions);
            var id = Interlocked.Increment(ref _currentId);
            _subscribers[id] = channel.Writer;
            return (id, channel.Reader);
        }

        /// <summary>
        /// Removes a subscriber by ID. Returns true if no subscribers remain.
        /// </summary>
        public bool RemoveSubscriber(long id)
        {
            if (_subscribers.TryRemove(id, out var writer))
            {
                writer.TryComplete();
            }
            return _subscribers.IsEmpty;
        }

        /// <summary>
        /// Publishes a message to all current subscribers. Awaits all writes.
        /// </summary>
        public async Task PublishAsync(T message, CancellationToken cancellationToken)
        {
            var writers = _subscribers.Values.ToList();
            if (writers.Count == 0) return;

            var writeTasks = new List<Task>(writers.Count);
            foreach (var writer in writers)
            {
                try
                {
                    writeTasks.Add(writer.WriteAsync(message, cancellationToken).AsTask());
                }
                catch
                {
                    // Ignore write failures for individual subscribers
                }
            }

            if (writeTasks.Count > 0)
            {
                await Task.WhenAll(writeTasks).ConfigureAwait(false);
            }
        }

        public void Dispose()
        {
            foreach (var writer in _subscribers.Values)
            {
                writer.TryComplete();
            }
            _subscribers.Clear();
        }
    }
}