using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class EquipmentPoolDataAccess : IEquipmentPoolDataAccess
{
    private readonly AppDbContext _dbContext;

    public EquipmentPoolDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<EquipmentPool>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.EquipmentPools.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<EquipmentPool>.Empty;

        var entities = await query
            .Where(x => x.PoolName.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<EquipmentPool>(total, entities);
    }

    public async Task<EquipmentPool?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.EquipmentPools.FindAsync(new object[] { id }, ct);
    }

    public async Task<EquipmentPool> CreateAsync(EquipmentPool entity, CancellationToken ct = default)
    {
        await _dbContext.EquipmentPools.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(EquipmentPool entity, CancellationToken ct = default)
    {
        _dbContext.EquipmentPools.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.EquipmentPools.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.EquipmentPools.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<EquipmentPool> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.EquipmentPools.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicates(List<string> poolNames, CancellationToken ct = default)
    {
        return await _dbContext.EquipmentPools
            .Where(e => poolNames.Contains(e.PoolName))
            .Select(e => e.PoolName)
            .ToListAsync(ct);
    }

    public async Task<EquipmentPool?> GetByPoolName(string poolName, CancellationToken ct = default)
    {
        return await _dbContext.EquipmentPools
            .Where(e => e.PoolName.Equals(poolName))
            .FirstOrDefaultAsync(ct);
    }
}
