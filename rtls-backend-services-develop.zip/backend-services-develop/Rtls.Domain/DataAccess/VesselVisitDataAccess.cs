using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class VesselVisitDataAccess : IVesselVisitDataAccess
{
    private readonly AppDbContext _dbContext;

    public VesselVisitDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<VesselVisit>> GetAllAsync(int skip, int? take, string search = "", CancellationToken ct = default)
    {
        var query = _dbContext.VesselVisits.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<VesselVisit>.Empty;

        var entities = await query
            .OrderBy(x => x.Id)
            .Where(x => x.VisitRef.Contains(search)
                || x.Vessel.VesselName.Contains(search)
                || x.Phase.ToString().Contains(search)
                || x.LineOperator.Contains(search))
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<VesselVisit>(total, entities);
    }

    public async Task<VesselVisit?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.VesselVisits.FindAsync(new object[] { id }, ct);
    }

    public async Task<VesselVisit> CreateAsync(VesselVisit entity, CancellationToken ct = default)
    {
        await _dbContext.VesselVisits.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(VesselVisit entity, CancellationToken ct = default)
    {
        _dbContext.VesselVisits.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.VesselVisits.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.VesselVisits.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

        public async Task<List<VesselVisit>> GetByIdsAsync(int skip, int take, HashSet<long> ids, List<string> visitPhases, CancellationToken ct = default)
        {
            // Parse string phases to enum
            var excludedPhases = visitPhases
                .Select(phase => Enum.Parse<VesselVisitPhase>(phase))
                .ToHashSet();
            return await _dbContext.VesselVisits
                  .Include(v => v.Vessel)
                  .Include(v => v.VesselBerthing)
                  .Where(v => ids.Contains(v.Id))
                  .Where(v => !excludedPhases.Contains(v.Phase))
                  .OrderBy(v => v.Id)
                  .Skip(skip)
                  .Take(take - skip)
                  .ToListAsync(ct);
        }

        public async Task<List<VesselVisit>> GetAllByVisitPhaseAsync(int skip, int take, List<string> visitPhases, string search, CancellationToken ct = default)
        {
            // Parse string phases to enum
            var excludedPhases = visitPhases
                .Select(phase => Enum.Parse<VesselVisitPhase>(phase))
                .ToHashSet();
            return await _dbContext.VesselVisits
                  .Include(v => v.Vessel)
                  .Include(v => v.VesselBerthing)
                  .Where(v => !excludedPhases.Contains(v.Phase))
                  .Where(x => x.VisitRef.Contains(search)
                    || x.Vessel.VesselName.Contains(search)
                    || x.Phase.ToString().Contains(search))
                  .OrderBy(v => v.Id)
                  .Skip(skip)
                  .Take(take - skip)
                  .ToListAsync(ct);
        }

    public async Task<bool> CreateBatchAsync(IEnumerable<VesselVisit> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.VesselVisits.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicatesAsync(List<string> nameToCheck, CancellationToken ct)
    {
        return await _dbContext.VesselVisits
            .Where(v => nameToCheck.Contains(v.VisitRef))
            .Select(v => v.VisitRef)
            .ToListAsync(ct);
    }

    public async Task<int> GetAllCount(CancellationToken ct = default)
    {
        return await _dbContext.VesselVisits
            .Where(v => v.Phase != VesselVisitPhase.Completed && v.Phase != VesselVisitPhase.Departed)
            .CountAsync(ct);
    }

    // 1. WaterSide Dashbboard - Active visits (Arrived or Working), including Vessel and related WorkInstructions & Berthing
    public async Task<List<VesselVisit>> GetActiveVesselVisitsAsync(CancellationToken ct)
    {
        return await _dbContext.Set<VesselVisit>()
            .Include(vv => vv.Vessel)
            .Include(vv => vv.WorkQueues)
            .Include(vv => vv.WorkInstructions)
                .ThenInclude(wi => wi.PointOfWork) 
            .Include(vv => vv.VesselBerthing)     
            .Where(vv =>
                (vv.Phase == VesselVisitPhase.Arrived || vv.Phase == VesselVisitPhase.Working) &&
                vv.VesselBerthing != null
            )
            .ToListAsync(ct);
    }

    public async Task<List<VesselVisit>> GetActiveVesselVisitsByVesselIdsAsync(HashSet<long> vesselIds, CancellationToken ct = default)
    {
        if (vesselIds == null || vesselIds.Count == 0)
            return [];

        var activePhases = new[] { VesselVisitPhase.Arrived, VesselVisitPhase.Working };

        var query = _dbContext.VesselVisits
            .Include(vv => vv.Vessel)
            .Include(vv => vv.WorkQueues)
            .Include(vv => vv.WorkInstructions)
                .ThenInclude(wi => wi.PointOfWork)
            .Include(vv => vv.VesselBerthing)
            .Where(vv =>
                vesselIds.Contains(vv.VesselId) &&
                activePhases.Contains(vv.Phase) &&
                vv.VesselBerthing != null
            );

        return await query.ToListAsync(ct);
    }

    public async Task<List<string>> GetVesselVisitByVesselId(long vesselId, CancellationToken ct = default)
    {
        return await _dbContext.VesselVisits
            .Where(vv => vv.VesselId == vesselId)
            .Select(vv => vv.VisitRef)
            .ToListAsync(ct);
    }
}
