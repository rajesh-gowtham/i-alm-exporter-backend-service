using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class RfidLevelTemplateValuesDataAccess : IRfidLevelTemplateValuesDataAccess
{
    private readonly AppDbContext _dbContext;

    public RfidLevelTemplateValuesDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<bool> CreateAsync(RfidLevelTemplateValues entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.RfidLevelTemplateValues.AddAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<RfidLevelTemplateValues?> GetByLTVIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.RfidLevelTemplateValues
            .FirstOrDefaultAsync(x => x.LtVID == id, ct);
    }

    public async Task<int> GetCountByNameAsync(string name, CancellationToken ct = default)
    {
        return await _dbContext.RfidLevelTemplateValues
                .Where(x => x.LTValue == name)
                .CountAsync(ct);
    }

    public async Task<bool> UpdateAsync(RfidLevelTemplateValues entity, CancellationToken ct = default)
    {
        _dbContext.RfidLevelTemplateValues.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }
}
