using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class EquipmentPoolAssignmentDataAccess : IEquipmentPoolAssignmentDataAccess
{
    private readonly AppDbContext _dbContext;

    public EquipmentPoolAssignmentDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<EquipmentPoolAssignment>> GetAllAsync(int skip = 0, int? take = null, CancellationToken ct = default)
    {
        var total = await _dbContext.EquipmentPoolAssignments.CountAsync(ct);
        var assignments = await _dbContext.EquipmentPoolAssignments
            .Include(x => x.EquipmentPool)
            .OrderBy(e => e.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<EquipmentPoolAssignment>(total, assignments);
    }

    public async Task<List<EquipmentPoolAssignment>?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        var query = _dbContext.EquipmentPoolAssignments.AsQueryable();

        var assignments = await query
            .Include(e => e.Equipment)
            .Where(e => e.EquipmentPoolId == id) // filter here
            .OrderBy(e => e.Id)
            .AsNoTracking()
            .ToListAsync(); // don't forget to materialize the query

        return assignments;
    }

    public async Task<EquipmentPoolAssignment> CreateAsync(EquipmentPoolAssignment entity, CancellationToken ct = default)
    {
        await _dbContext.EquipmentPoolAssignments.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    #region Inser Only new record if exist skip and remove unmatched data from dbcotext
    public async Task<bool> UpdateAsync(List<EquipmentPoolAssignment> entities, long equipmentPoolId, CancellationToken ct = default)
    {
        if (entities == null || entities.Count == 0)
            return false;

        // Filter nulls and ensure we're only dealing with the specified EquipmentPoolId
        var incomingEntities = entities
            .Where(e => e != null && e.EquipmentPoolId == equipmentPoolId)
            .ToList();

        var incomingPairs = incomingEntities
            .Select(e => (e.EquipmentPoolId, e.EquipmentId))
            .ToHashSet();

        // Get existing assignments for the given EquipmentPoolId
        var existingAssignments = await _dbContext.EquipmentPoolAssignments
            .Where(e => e.EquipmentPoolId == equipmentPoolId)
            .ToListAsync(ct);

        var existingPairs = existingAssignments
            .Select(e => (e.EquipmentPoolId, e.EquipmentId))
            .ToHashSet();

        // Determine records to add
        var toAdd = incomingEntities
            .Where(e => !existingPairs.Contains((e.EquipmentPoolId, e.EquipmentId)))
            .ToList();

        // Determine records to delete
        var toDelete = existingAssignments
            .Where(e => !incomingPairs.Contains((e.EquipmentPoolId, e.EquipmentId)))
            .ToList();

        // Perform DB operations
        if (toAdd.Any())
            await _dbContext.EquipmentPoolAssignments.AddRangeAsync(toAdd, ct);

        if (toDelete.Any())
            _dbContext.EquipmentPoolAssignments.RemoveRange(toDelete);

        var result = await _dbContext.SaveChangesAsync(ct);
        return result > 0;
    }
    #endregion

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.EquipmentPoolAssignments.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.EquipmentPoolAssignments.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteByEquipmentPoolIdAsync(long equipmentPoolId, CancellationToken ct = default)
    {
        var existingEntities = _dbContext.EquipmentPoolAssignments
            .Where(e => e.EquipmentPoolId == equipmentPoolId);

        _dbContext.EquipmentPoolAssignments.RemoveRange(existingEntities);
        var deletedRows = await _dbContext.SaveChangesAsync(ct);
        return deletedRows > 0;
    }

    public async Task<Dictionary<long, string>> GetEquipmentPoolNameMap()
    {
        return await (
            from assignment in _dbContext.EquipmentPoolAssignments
            join pool in _dbContext.EquipmentPools
                on assignment.EquipmentPoolId equals pool.Id
            select new
            {
                assignment.EquipmentId,
                pool.PoolName
            }
        ).ToDictionaryAsync(x => x.EquipmentId, x => x.PoolName);
    }

    public async Task<List<string>> GetAssignedEquipmentNames(string equipmentPoolName, CancellationToken ct = default)
    {
        return await _dbContext.EquipmentPoolAssignments
            .Include(e => e.Equipment)
            .Where(e => e.EquipmentPool.PoolName == equipmentPoolName)
            .Select(e => e.Equipment.EquipmentName)
            .Distinct()
            .ToListAsync(ct);
    }

    public async Task<EquipmentPoolAssignment?> GetByEquipmentId(long equipmentId)
    {
        return await _dbContext.EquipmentPoolAssignments
            .Include(e => e.EquipmentPool)
            .Where(e => e.EquipmentId == equipmentId)
            .FirstOrDefaultAsync();
    }

    public async Task<string?> GetPoolNameByEquipmentName(string equipmentName, CancellationToken ct = default)
    {
        return await _dbContext.EquipmentPoolAssignments
            .Where(ep => ep.Equipment.EquipmentName.Equals(equipmentName))
            .Select(ep => ep.EquipmentPool.PoolName)
            .FirstOrDefaultAsync(ct);
    }
}
