using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

/// <summary>
/// Implementation of vessel data access operations
/// </summary>
public class VesselDataAccess : IVesselDataAccess
{
    private readonly AppDbContext _dbContext;
    private readonly ILogger<VesselDataAccess> _logger;

    public VesselDataAccess(
        AppDbContext dbContext,
        ILogger<VesselDataAccess> logger)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Vessel?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        _logger.LogDebug("Getting vessel with ID: {VesselId}", id);
        return await _dbContext.Vessels.FindAsync(new object[] { id }, ct);
    }

    public async Task<PagedResponse<Vessel>> GetAllAsync(int skip = 0, int? take = null, string search="", CancellationToken ct = default)
    {
        _logger.LogDebug("Getting all vessels with skip: {Skip}, take: {Take}, search: {search}", skip, take, search);

        var total = await _dbContext.Vessels.CountAsync(ct);

        if (total == 0) return PagedResponse<Vessel>.Empty;

        var vessels = await _dbContext.Vessels
            .OrderBy(v => v.Id)
            .Where(v => v.VesselName.Contains(search) || v.VesselClass.Contains(search))
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<Vessel>(total, vessels);
    }

    public async Task<Vessel> CreateAsync(Vessel vessel, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(vessel, nameof(vessel));

        _logger.LogDebug("Creating new vessel: {VesselName}", vessel.VesselName);

        await _dbContext.Vessels.AddAsync(vessel, ct);
        await _dbContext.SaveChangesAsync(ct);

        _logger.LogDebug("Vessel created successfully with ID: {VesselId}", vessel.Id);
        return vessel;
    }

    public async Task<bool> UpdateAsync(Vessel vessel, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(vessel, nameof(vessel));

        _logger.LogDebug("Updating vessel with ID: {VesselId}", vessel.Id);

        _dbContext.Vessels.Update(vessel);
        var rowsAffected = await _dbContext.SaveChangesAsync(ct);

        var success = rowsAffected > 0;
        _logger.LogDebug("Vessel update {Result}", success ? "succeeded" : "failed");

        return success;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        _logger.LogDebug("Deleting vessel with ID: {VesselId}", id);

        var vessel = await _dbContext.Vessels.FindAsync(new object[] { id }, ct);
        if (vessel is null)
        {
            _logger.LogWarning("Vessel with ID: {VesselId} not found for deletion", id);
            return false;
        }

        _dbContext.Vessels.Remove(vessel);
        var rowsAffected = await _dbContext.SaveChangesAsync(ct);

        var success = rowsAffected > 0;
        _logger.LogDebug("Vessel deletion {Result}", success ? "succeeded" : "failed");

        return success;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<Vessel> vessels, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(vessels, nameof(vessels));

        _logger.LogDebug("Creating vessels using batch");

        await _dbContext.Vessels.AddRangeAsync(vessels, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        _logger.LogDebug("Vessels created successfully using batch");

        return saved > 0;
    }

    public async Task<Dictionary<string, List<string>>> CheckDuplicatesAsync(Dictionary<string, List<string>> check, CancellationToken ct = default)
    {
        var nameList = check.TryGetValue("VesselName", out var n) ? n : new List<string>();
        var lloydsIdentity = check.TryGetValue("LloydsIdentity", out var l) ? l : new List<string>();
        var classList = check.TryGetValue("VesselClass", out var c) ? c : new List<string>();
        var radioList = check.TryGetValue("RadioCallSign", out var r) ? r : new List<string>();

        var query = _dbContext.Vessels.AsQueryable();

        if (nameList.Any() || classList.Any() || radioList.Any() || lloydsIdentity.Any())
        {
            query = query.Where(v =>
                (nameList.Any() && nameList.Contains(v.VesselName)) ||
                (classList.Any() && classList.Contains(v.VesselClass)) ||
                (lloydsIdentity.Any() && lloydsIdentity.Contains(v.LloydsIdentity)) ||
                (radioList.Any() && radioList.Contains(v.RadioCallSign)));
        }

        var results = await query
            .Select(v => new { v.VesselName, v.VesselClass, v.RadioCallSign, v.LloydsIdentity })
            .ToListAsync(ct);

        var resultDict = new Dictionary<string, List<string>>();

        if (nameList.Any())
        {
            var vesselName = results.Select(r => r.VesselName).Where(nameList.Contains).Distinct().ToList();
            if (vesselName.Any())  resultDict["VesselName"] = vesselName;
        }
        if (classList.Any())
        {
            var vesselClass = results.Select(r => r.VesselClass).Where(classList.Contains).Distinct().ToList();
            if (vesselClass.Any()) resultDict["VesselClass"] = vesselClass;
        }
        if (radioList.Any())
        {
            var radioCallSign = results.Select(r => r.RadioCallSign).Where(radioList.Contains).Distinct().ToList();
            if (radioCallSign.Any()) resultDict["RadioCallSign"] = radioCallSign;
        }
        if (lloydsIdentity.Any())
        {
            var lloyds = results.Select(r => r.LloydsIdentity).Where(lloydsIdentity.Contains).Distinct().ToList();
            if (lloyds.Any()) resultDict["LloydsIdentity"] = lloyds;
        }
        return resultDict;
    }
}