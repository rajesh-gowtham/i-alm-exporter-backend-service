using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class PowAssignmentDataAccess : IPowAssignmentDataAccess
{
    private readonly AppDbContext _dbContext;

    public PowAssignmentDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<PowAssignment>> GetAllAsync(int skip, int? take, CancellationToken ct = default)
    {
        var query = _dbContext.PowAssignments.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<PowAssignment>.Empty;

        var entities = await query
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<PowAssignment>(total, entities);
    }

    public async Task<PowAssignment?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.PowAssignments.FindAsync(new object[] { id }, ct);
    }

    public async Task<PowAssignment> CreateAsync(PowAssignment entity, CancellationToken ct = default)
    {
        await _dbContext.PowAssignments.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(PowAssignment entity, CancellationToken ct = default)
    {
        _dbContext.PowAssignments.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.PowAssignments.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.PowAssignments.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<PowAssignment> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.PowAssignments.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }
}
