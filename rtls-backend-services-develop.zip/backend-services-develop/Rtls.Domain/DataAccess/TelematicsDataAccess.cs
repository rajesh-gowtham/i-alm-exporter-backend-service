using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

/// <summary>
/// Implementation of vessel data access operations
/// </summary>
public class TelematicsDataAccess : ITelematicsDataAccess
{
    private readonly AppDbContext _dbContext;
    private readonly ILogger<TelematicsDataAccess> _logger;

    public TelematicsDataAccess(AppDbContext dbContext, ILogger<TelematicsDataAccess> logger)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Telematics?> GetByIdAsync(long id)
    {
        _logger.LogInformation("Getting telematics by ID: {Id}", id);
        return await _dbContext.Telematics.FindAsync(id);
    }

    public async Task<PagedResponse<Telematics>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        _logger.LogInformation("Fetching all telematics records. Skip: {Skip}, Take: {Take}, Search: {Search}", skip, take, search);

        var query = _dbContext.Telematics.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(t =>
                t.DeviceId.Contains(search) ||
                t.Manufacturer.Contains(search) ||
                t.Model.Contains(search));

            _logger.LogInformation("Search applied for: {Search}", search);
        }

        var totalCount = await query.CountAsync(ct);
        var items = await query
            .OrderBy(t => t.Id)
            .Skip(skip)
            .Take(take ?? totalCount)
            .ToListAsync(ct);

        _logger.LogInformation("Found {Count} telematics records", items.Count);

        return new PagedResponse<Telematics>(totalCount, items.ToArray());
    }


    public async Task<Telematics> CreateAsync(Telematics entity)
    {
        if (entity == null)
        {
            _logger.LogError("CreateAsync failed: entity is null");
            throw new ArgumentNullException(nameof(entity));
        }

        _logger.LogInformation("Creating telematics record for DeviceId: {DeviceId}", entity.DeviceId);

        await _dbContext.Telematics.AddAsync(entity);
        await _dbContext.SaveChangesAsync();

        _logger.LogInformation("Telematics created with Id: {Id}", entity.Id);

        return entity;
    }

    public async Task<bool> UpdateAsync(Telematics entity)
    {
        if (entity == null)
        {
            _logger.LogError("UpdateAsync failed: entity is null");
            throw new ArgumentNullException(nameof(entity));
        }

        _logger.LogInformation("Updating telematics record with Id: {Id}", entity.Id);

        _dbContext.Telematics.Update(entity);
        var updated = await _dbContext.SaveChangesAsync();

        if (updated > 0)
        {
            _logger.LogInformation("Telematics record updated successfully.");
            return true;
        }

        _logger.LogWarning("UpdateAsync did not affect any records.");
        return false;
    }

    public async Task<bool> DeleteAsync(long id)
    {
        _logger.LogInformation("Attempting to delete telematics record with Id: {Id}", id);

        var entity = await _dbContext.Telematics.FindAsync(id);
        if (entity is null)
        {
            _logger.LogWarning("DeleteAsync failed: Telematics record not found for Id: {Id}", id);
            return false;
        }

        _dbContext.Telematics.Remove(entity);
        var deleted = await _dbContext.SaveChangesAsync();

        if (deleted > 0)
        {
            _logger.LogInformation("Telematics record with Id {Id} deleted successfully.", id);
            return true;
        }

        _logger.LogWarning("DeleteAsync did not delete any record for Id: {Id}", id);
        return false;
    }


    public async Task<bool> CreateBatchAsync(IEnumerable<Telematics> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.Telematics.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicatesAsync(List<string> nameToCheck, CancellationToken ct)
    {
        return await _dbContext.Telematics
            .Where(t => nameToCheck.Contains(t.DeviceId))
            .Select(t => t.DeviceId)
            .ToListAsync(ct);
    }

    public async Task<Telematics?> GetByDeviceIdAsync(string deviceId, CancellationToken ct)
    {
        _logger.LogInformation("Getting telematics by device id: {deviceId}", deviceId);
        return await _dbContext.Telematics
            .Where(t => t.DeviceId.Contains(deviceId))
            .FirstOrDefaultAsync(ct);
    }
}