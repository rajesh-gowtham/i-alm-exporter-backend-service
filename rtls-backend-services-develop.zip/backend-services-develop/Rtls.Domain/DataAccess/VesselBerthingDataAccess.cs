using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class VesselBerthingDataAccess : IVesselBerthingDataAccess
{
    private readonly AppDbContext _dbContext;

    public VesselBerthingDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<VesselBerthing>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.VesselBerthings.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<VesselBerthing>.Empty;

        var entities = await query
            .Where(x => x.VesselVisit.VisitRef.Contains(search) || x.Quay.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<VesselBerthing>(total, entities);
    }

    public async Task<VesselBerthing?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.VesselBerthings.FindAsync(new object[] { id }, ct);
    }

    public async Task<VesselBerthing> CreateAsync(VesselBerthing entity, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entity, nameof(entity));
        ArgumentNullException.ThrowIfNull(entity.VesselVisitId, nameof(entity.VesselVisitId));

        _dbContext.Attach(new VesselVisit { Id = entity.VesselVisitId!.Value });
        await _dbContext.VesselBerthings.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(VesselBerthing entity, CancellationToken ct = default)
    {
        _dbContext.VesselBerthings.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.VesselBerthings.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.VesselBerthings.Remove(entity);
        return await _dbContext.SaveChangesAsync(ct) > 0;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<VesselBerthing> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.VesselBerthings.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicatesAsync(List<long> IdToCheck, CancellationToken ct)
    {
        return await _dbContext.VesselBerthings
            .Where(vv => IdToCheck.Contains(vv.VesselVisit.Id))
            .Select(vv => vv.VesselVisit.VisitRef)
            .ToListAsync(ct);
    }

    public async Task<long> GetCountByVesselVisitId(long vesselVisitId, CancellationToken ct = default)
    {
        return await _dbContext.VesselBerthings
             .Include(vb => vb.VesselVisit)
             .Where(vb => vesselVisitId.Equals(vb.VesselVisitId))
             .CountAsync(ct);
    }

}
