using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class RfidAssetDataAccess : IRfidAssetDataAccess
{
    private readonly AppDbContext _dbContext;

    public RfidAssetDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<bool> CreateAsync(RfidAsset entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.RfidAssets.AddAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.RfidAssets.FirstOrDefaultAsync(x => x.RPID == id, ct);
        if (entity == null) return false;

        _dbContext.RfidAssets.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<List<string>> FindDuplicateDataAsync(
     string name, string latitude, string longitude, CancellationToken ct = default)
    {
        var matches = await _dbContext.RfidAssets
            .Where(x => x.RPName == name || x.Lat == latitude || x.Long == longitude)
            .Select(x => new { x.RPName, x.Lat, x.Long })
            .ToListAsync(ct);

        var duplicates = new List<string>();

        if (matches.Any(m => m.RPName == name))
            duplicates.Add("rPName");
        if (matches.Any(m => m.Long == longitude))
            duplicates.Add("long");
        if (matches.Any(m => m.Lat == latitude))
            duplicates.Add("lat");

        return duplicates;
    }

    public async Task<bool> UpdateAsync(RfidAsset entity, CancellationToken ct = default)
    {
        _dbContext.RfidAssets.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }
}
