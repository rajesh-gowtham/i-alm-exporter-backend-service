using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class PointOfWorkDataAccess : IPointOfWorkDataAccess
{
    private readonly AppDbContext _dbContext;

    public PointOfWorkDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<PointOfWork>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.PointOfWorks.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<PointOfWork>.Empty;

        var entities = await query
            .Where(x => x.Name.Contains(search) || x.Pool.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<PointOfWork>(total, entities);
    }

    public async Task<PointOfWork?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.PointOfWorks.FindAsync(new object[] { id }, ct);
    }

    public async Task<PointOfWork> CreateAsync(PointOfWork entity, CancellationToken ct = default)
    {
        await _dbContext.PointOfWorks.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(PointOfWork entity, CancellationToken ct = default)
    {
        _dbContext.PointOfWorks.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.PointOfWorks.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.PointOfWorks.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<PointOfWork> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.PointOfWorks.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckNameDuplicates(List<string> namesToCheck, CancellationToken ct = default)
    {
        // Check for existing pow names in the database
        return await _dbContext.PointOfWorks
            .Where(e => namesToCheck.Contains(e.Name))
            .Select(e => e.Name)
            .ToListAsync(ct);
    }

    public async Task<List<string>> CheckPoolDuplicates(List<string> namesToCheck, CancellationToken ct = default)
    {
        // Check for existing pow names in the database
        return await _dbContext.PointOfWorks
            .Where(e => namesToCheck.Contains(e.Pool))
            .Select(e => e.Pool)
            .ToListAsync(ct);
    }
}
