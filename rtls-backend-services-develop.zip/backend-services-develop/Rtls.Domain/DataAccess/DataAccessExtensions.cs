using Microsoft.Extensions.DependencyInjection;
using Rtls.Domain.Interfaces;

namespace Rtls.Domain.DataAccess;

/// <summary>
/// Extension methods for registering data access components
/// </summary>
public static class DataAccessExtensions
{
    /// <summary>
    /// Adds data access layer components to the service collection
    /// </summary>
    /// <param name="services">The service collection</param>
    /// <returns>The service collection for chaining</returns>
    public static IServiceCollection AddDataAccessLayer(this IServiceCollection services)
    {
        // Register all data access interfaces and implementations
        services.AddScoped<IVesselDataAccess, VesselDataAccess>();
        services.AddScoped<IEquipmentDataAccess, EquipmentDataAccess>();
        services.AddScoped<IEquipmentPoolAssignmentDataAccess, EquipmentPoolAssignmentDataAccess>();
        services.AddScoped<IEquipmentPoolDataAccess, EquipmentPoolDataAccess>();
        services.AddScoped<IPointOfWorkDataAccess, PointOfWorkDataAccess>();
        services.AddScoped<IPowAssignmentDataAccess, PowAssignmentDataAccess>();
        services.AddScoped<IVesselBerthingDataAccess, VesselBerthingDataAccess>();
        services.AddScoped<IVesselVisitDataAccess, VesselVisitDataAccess>();
        services.AddScoped<IWorkInstructionDataAccess, WorkInstructionDataAccess>();
        services.AddScoped<IVmtUsersDataAccess, VmtUsersDataAccess>();
        services.AddScoped<IWorkQueueDataAccess, WorkQueueDataAccess>();
        services.AddScoped<IVmtAuditLoginDataAccess, VmtAuditLoginDataAccess>();
        services.AddScoped<IRfidAssetDataAccess, RfidAssetDataAccess>();
        services.AddScoped<IAlarmsEventsDataAccess, AlarmsEventsDataAccess>();
        services.AddScoped<ITelematicsDataAccess, TelematicsDataAccess>();
        services.AddScoped<IRfidLevelTemplateDataAccess, RfidLevelTemplateDataAccess>();
        services.AddScoped<IRfidLevelTemplateValuesDataAccess, RfidLevelTemplateValuesDataAccess>();

        return services;
    }
}