﻿using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Domain.DataAccess
{
    public class WorkQueueDataAccess: IWorkQueueDataAccess
    {
        private readonly AppDbContext _dbContext;

        public WorkQueueDataAccess(AppDbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        public async Task<List<WorkQueue>> GetByVesselVisitIdsAsync(List<long> vesselVisitIds, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Include(wq => wq.PointOfWork)
                .Include(wq => wq.WorkInstructions)
                .Where(wq => vesselVisitIds.Contains(wq.VesselVisitId))
                .ToListAsync(ct);
        }

        public async Task<WorkQueue?> GetByIdAsync(long id, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Include(wq => wq.PointOfWork)
                .Include(wq => wq.WorkInstructions)
                .FirstOrDefaultAsync(wq => wq.Id == id, ct);
        }

        public Task<List<WorkQueue>> CreateAsync(List<WorkQueue> entity, CancellationToken ct = default)
        {
            var res = entity;
            return Task.FromResult(res);
        }

        public async Task<WorkQueue> CreateSingleAsync(WorkQueue entity, CancellationToken ct = default)
        {
            // Ensure the entity is not null
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            // Add the entity to the DbContext
            await _dbContext.WorkQueues.AddAsync(entity, ct);
            // Save changes to the database
            await _dbContext.SaveChangesAsync(ct);
            // Return the saved entity from the DbContext.
            return entity;
        }

        public async Task<List<WorkQueue>> GetByVesselVisitIdPowAsync(long vesselVisitId, long powId, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Include(wq => wq.PointOfWork)
                .Include(wq => wq.WorkInstructions)
                .Where(wq => wq.WorkInstructions.Count() > 0)
                .Where(wq => wq.VesselVisitId == vesselVisitId && wq.PointOfWorkId == powId)
                .ToListAsync(ct);
        }

        public async Task<bool> UpdateAsync(WorkQueue entity, CancellationToken ct = default)
        {
            _dbContext.WorkQueues.Update(entity);
            var affectedRows = await _dbContext.SaveChangesAsync(ct);
            return affectedRows > 0;
        }

        public async Task<WorkQueue?> GetByPoolName(string poolName, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Include(wq => wq.WorkInstructions)
                .Include(wq => wq.PointOfWork)
                .Where(wq => wq.PointOfWork.Pool.Equals(poolName) && wq.Status.Equals(Constants.JobStatus.INPROGRESS))
                .FirstOrDefaultAsync();
        }

        public async Task<long> GetCountAgainstPow(long powId, long vesselVisitId, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Where(x => x.VesselVisitId == vesselVisitId && x.PointOfWorkId == powId)
                .Where(x => x.Status.Equals(Constants.JobStatus.INPROGRESS))
                .CountAsync(ct);
        }

        public async Task<string?> GetCountAgainstVessel(long powId, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
               .Where(x => x.PointOfWorkId == powId)
               .Where(x => x.Status.Equals(Constants.JobStatus.INPROGRESS))
               .Select(x => x.VesselVisit.VisitRef)
               .FirstOrDefaultAsync(ct);
        }

        public async Task<List<string?>> GetADeckWorkQueue(List<string> name, long vesselVisitId, string deck, CancellationToken ct = default)
        {
            return await _dbContext.WorkQueues
                .Where(wq => name.Contains(wq.Name) 
                        && wq.Deck.Equals(deck) 
                        && wq.VesselVisitId == vesselVisitId 
                        && !wq.Status.Equals(Constants.JobStatus.COMPLETED))
                .Select(wq => wq.Name)
                .ToListAsync(ct);
        }

        public async Task<bool> DeleteAsync(List<long> ids, CancellationToken ct = default)
        {
            var affectedRows = await _dbContext.WorkQueues
                .Where(wq => ids.Contains(wq.Id) && !wq.WorkInstructions.Any())
                .ExecuteDeleteAsync(ct);

            return affectedRows > 0;
        }

    }
}
