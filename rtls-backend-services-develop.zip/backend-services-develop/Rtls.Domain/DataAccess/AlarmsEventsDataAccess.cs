using Microsoft.EntityFrameworkCore;
using Polly.Caching;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class AlarmsEventsDataAccess : IAlarmsEventsDataAccess
{
    private readonly AppDbContext _dbContext;

    public AlarmsEventsDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<AlarmsEvents> CreateAsync(AlarmsEvents entity, CancellationToken ct = default)
    {
        await _dbContext.AlarmsEvents.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> FindHatchRemoval(List<string> workQueues, long vesselVisitId, CancellationToken ct = default)
    {
        return await _dbContext.AlarmsEvents
            .Where(ae => ae.VesselVisitId == vesselVisitId)
            .Where(ae => workQueues.Contains(ae.WorkQueue.Name))
            .AnyAsync(ct);
    }

    public async Task<long> GetByCountAsync(List<long> vesselVisitIds, string eventName, CancellationToken ct = default)
    {
        return await _dbContext.AlarmsEvents
            .Where(ae => vesselVisitIds.Contains(ae.VesselVisitId) && eventName.Equals(ae.EventName))
            .CountAsync(ct);
    }

    public async Task<List<AlarmsEvents>> GetByVesselVisit(long vesselVisitId, string eventName, CancellationToken ct = default)
    {
        return await _dbContext.AlarmsEvents
            .Include(ae => ae.VesselVisit)
            .Include(ae => ae.Equipment)
            .Include(ae => ae.WorkQueue)
            .Where(ae => ae.VesselVisitId == vesselVisitId && eventName.Equals(ae.EventName))
            .ToListAsync(ct);
    }

    public async Task<PagedResponse<AlarmsEvents>> GetByVesselVisitIds(List<long> vesselVisitIds, string eventName, 
        int skip, int? take, CancellationToken ct = default)
    {
        int totalCount = await _dbContext.AlarmsEvents
            .Where(ae => vesselVisitIds.Contains(ae.VesselVisitId) && eventName.Equals(ae.EventName))
            .CountAsync(ct);

        var entities = await _dbContext.AlarmsEvents
           .Include(ae => ae.VesselVisit)
           .Include(ae => ae.Equipment)
           .Include(ae => ae.WorkQueue)
           .Where(ae => vesselVisitIds.Contains(ae.VesselVisitId) && eventName.Equals(ae.EventName))
           .Skip(skip)
           .Take(take ?? totalCount)
           .OrderBy(ae => ae.Id)
        .ToArrayAsync(ct);

        return new PagedResponse<AlarmsEvents>(totalCount, entities);
    }

    public async Task<bool> ClearAsync(List<long> workQueueids, CancellationToken ct = default)
    {
        var affectedRows = await _dbContext.AlarmsEvents
            .Where(ae => workQueueids.Contains(ae.WorkQueueId) && !ae.WorkQueue.WorkInstructions.Any())
            .ExecuteDeleteAsync(ct);

        return affectedRows > 0;
    }
}
