using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Domain.DataAccess;

public class RfidLevelTemplateDataAccess : IRfidLevelTemplateDataAccess
{
    private readonly AppDbContext _dbContext;

    public RfidLevelTemplateDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<bool> CreateAsync(RfidLevelTemplate entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.RfidLevelTemplate.AddAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<RfidLevelTemplate?> GetByLTIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.RfidLevelTemplate
            .FirstOrDefaultAsync(x => x.LTID == id, ct);
    }

    public async Task<int> GetCountByName(string name, CancellationToken ct = default)
    {
        return await _dbContext.RfidLevelTemplate
                .Where(x => x.LTName == name)
                .CountAsync(ct);
    }

    public async Task<bool> UpdateAsync(RfidLevelTemplate entity, CancellationToken ct = default)
    {
        _dbContext.RfidLevelTemplate.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }
}
