using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class WorkInstructionDataAccess : IWorkInstructionDataAccess
{
    private readonly AppDbContext _dbContext;

    public WorkInstructionDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<WorkInstruction>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.WorkInstructions.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<WorkInstruction>.Empty;

        var entities = await query
            .Where(x => x.ContainerId.Contains(search)
                        || x.MoveType.Contains(search)
                        || x.VesselVisit.VisitRef.Contains(search)
                        || x.IsoCode.Contains(search)
                        || x.Mode.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<WorkInstruction>(total, entities);
    }

    public async Task<WorkInstruction?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .AsNoTracking()
            .Include(wi => wi.WorkQueue)
            .FirstOrDefaultAsync(wi => wi.Id == id, ct);
    }

    public async Task<WorkInstruction> CreateAsync(WorkInstruction entity, CancellationToken ct = default)
    {
        await _dbContext.WorkInstructions.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(WorkInstruction entity, CancellationToken ct = default)
    {
        _dbContext.WorkInstructions.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> UpdateEntityAsync(WorkInstruction entity, CancellationToken ct = default)
    {
        // ignore work queue
        entity.WorkQueue = null;
        _dbContext.WorkInstructions.Update(entity);
        // _dbContext.Entry(entity).State = EntityState.Modified;
        
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }
    
    public async Task<bool> DeleteAsync(WorkInstruction entity, CancellationToken ct = default)
    {
        _dbContext.WorkInstructions.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<HashSet<long>> GetVesselIdByFilterAsync(string search, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .Where(w => w.PointOfWork.Name == search || w.VesselVisit.VisitRef == search)
            .Select(w => w.VesselVisit.Id)
            .Distinct()
            .ToHashSetAsync(ct);
    }

    public async Task<HashSet<WorkInstruction>> GetByVesselIdAsync(HashSet<long> vesselIds, String powName, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .Include(w => w.PointOfWork)
            .Where(w => vesselIds.Contains(w.VesselVisitId))
            .Where(w => powName.Equals(w.PointOfWork.Name))
            .ToHashSetAsync(ct);
    }

    public async Task<HashSet<WorkInstruction>> GetByVesselIdAsync(HashSet<long> vesselIds, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .Include(w => w.PointOfWork)
            .Where(w => vesselIds.Contains(w.VesselVisitId))
            .ToHashSetAsync(ct);
    }

    public async Task<List<WorkInstruction>> GetByVesselVisitIdAndPowIdAsync(long vesselVisitId, long powId, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .Where(w => w.VesselVisitId == vesselVisitId && w.PointOfWorkId == powId)
            .ToListAsync(ct);
    }

    public async Task<PagedResponse<WorkInstruction>> GetByWorkQueueIdAsync(int skip, int take, long workQueueId, string search = "", CancellationToken ct = default)
    {
        var query = _dbContext.WorkInstructions.AsQueryable();

        var total = await query
            .Where(w => w.WorkQueueId == workQueueId)
            .CountAsync();
        if (total == 0) return PagedResponse<WorkInstruction>.Empty;

        var entities = await _dbContext.WorkInstructions
            .Include(v => v.VesselVisit)
            .Where(wi => wi.WorkQueueId == workQueueId)
            .Where(wi => wi.ContainerId.Contains(search) || wi.PointOfWork.Name.Contains(search) ||
                         wi.VesselVisit.VisitRef.Contains(search))
            .Skip(skip)
            .Take(take - skip)
            .ToArrayAsync(ct);

        return new PagedResponse<WorkInstruction>(total, entities);
    }

    public async Task<List<WorkInstruction>> GetByVesselVisitIdAsync(long vesselVisitId, CancellationToken ct)
    {
        // Query the database for work instructions based on vesselVisitId
        var workInstructions = await _dbContext.WorkInstructions
            .Where(wi => wi.VesselVisitId == vesselVisitId)
            .ToListAsync(ct);
        return workInstructions;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<WorkInstruction> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.WorkInstructions.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicates(List<string> containerIds, CancellationToken ct = default)
    {
        return await _dbContext.WorkInstructions
            .Where(w => containerIds.Contains(w.ContainerId))
            .Select(w => w.ContainerId)
            .ToListAsync(ct);
    }

    // 3. WaterSide Dashbboard - Active QC: distinct PointOfWorkId in WorkInstruction
    public async Task<int> GetActiveQcCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct)
    {
        return await _dbContext.Set<WorkInstruction>()
            .Where(wi => vesselVisitIds.Contains(wi.VesselVisitId))
            .Select(wi => wi.PointOfWorkId)
            .Distinct()
            .CountAsync(ct);
    }

    // 4. WaterSide Dashbboard - Total jobs: count of WorkInstruction
    public async Task<int> GetTotalJobsCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct)
    {
        return await _dbContext.Set<WorkInstruction>()
            .Where(wi => vesselVisitIds.Contains(wi.VesselVisitId))
            .CountAsync(ct);
    }

    // 5. WaterSide Dashbboard - Assigned ITVs: distinct CheCarry
    public async Task<int> GetAssignedItvsCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct)
    {
        return await _dbContext.Set<WorkInstruction>()
            .Where(wi => vesselVisitIds.Contains(wi.VesselVisitId))
            .Select(wi => wi.CheCarry)
            .Distinct()
            .CountAsync(ct);
    }

    public async Task<int> GetCountByPow(long powId, CancellationToken ct)
    {
        return await _dbContext.Set<WorkInstruction>()
            .Where(wi => powId == wi.PointOfWorkId)
            .Distinct()
            .CountAsync(ct);
    }

    public async Task<List<WorkInstruction>> GetByEquipmentId(string equipmentId, CancellationToken ct)
    {
        return await _dbContext.WorkInstructions
            .Include(wi => wi.PointOfWork)
            .Include(wi => wi.WorkQueue)
            .Where(wi => wi.CheCarry.Equals(equipmentId) && wi.WorkInstructionStatus.Equals(Constants.JobStatus.INPROGRESS))
            .ToListAsync(ct);
    }

    public async Task<PagedResponse<WorkInstruction>> GetAllInventoryContainerAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.WorkInstructions.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<WorkInstruction>.Empty;

        var entities = await query
            .Where(x => x.ContainerId.Contains(search)
                        || x.MoveType.Contains(search)
                        || x.IsoCode.Contains(search)
                        || x.Mode.Contains(search)).Where(x => x.WorkInstructionStatus.Contains(Constants.JobStatus.COMPLETED))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<WorkInstruction>(total, entities);
    }

    public async Task<PagedResponse<WorkInstruction>> GetAllInventoryVessel(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.WorkInstructions.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<WorkInstruction>.Empty;

        var entities = await query
            .Include(wi => wi.VesselVisit)
            .ThenInclude(vv => vv.Vessel)
            .Where(x => x.VesselVisit.VisitRef.Contains(search) || x.VesselVisit.Vessel.VesselName.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<WorkInstruction>(total, entities);
    }


    public async Task<bool> ContainerClearAsync(List<long> ids, CancellationToken ct = default)
    {
        var affectedRows = await _dbContext.WorkInstructions
            .Where(wi => ids.Contains(wi.Id))
            .ExecuteDeleteAsync(ct);

        return affectedRows > 0;
    }


    public async Task<WorkInstruction> GetInventoryContainerById(long id, CancellationToken ct)
    {
        var entity = await _dbContext.WorkInstructions
            .Include(wi => wi.PointOfWork)
            .Include(wi => wi.VesselVisit)
            .FirstOrDefaultAsync(wi => wi.Id == id, ct);
        if (entity == null)
            throw new KeyNotFoundException($"WorkInstruction with ID {id} was not found.");
        return entity;
    }

    public async Task<List<WorkInstruction>> GetByIds(List<long> ids, CancellationToken ct)
    {
        return await _dbContext.WorkInstructions
            .Include(wi => wi.WorkQueue)
            .Where(wi => ids.Contains(wi.Id))
            .ToListAsync(ct);
    }

    public async Task<bool> UpdateBatchAsync(IEnumerable<WorkInstruction> entities, CancellationToken ct = default)
    {
        _dbContext.WorkInstructions.UpdateRange(entities);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }
}