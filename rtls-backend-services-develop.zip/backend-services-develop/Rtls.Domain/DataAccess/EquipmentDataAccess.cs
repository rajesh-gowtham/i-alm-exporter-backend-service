using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;
using Rtls.Domain.Models;

namespace Rtls.Domain.DataAccess;

public class EquipmentDataAccess : IEquipmentDataAccess
{
    private readonly AppDbContext _dbContext;

    public EquipmentDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<PagedResponse<Equipment>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default)
    {
        var query = _dbContext.Equipments.AsQueryable();

        var total = await query.CountAsync(ct);
        if (total == 0) return PagedResponse<Equipment>.Empty;

        var entities = await query
            .Where(x => x.EquipmentName.Contains(search) || x.EquipmentType.Contains(search))
            .OrderBy(x => x.Id)
            .Skip(skip)
            .Take(take ?? total)
            .AsNoTracking()
            .ToArrayAsync(ct);

        return new PagedResponse<Equipment>(total, entities);
    }

    public async Task<Equipment?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        return await _dbContext.Equipments.FindAsync(new object[] { id }, ct);
    }

    public async Task<Equipment> CreateAsync(Equipment entity, CancellationToken ct = default)
    {
        await _dbContext.Equipments.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<bool> UpdateAsync(Equipment entity, CancellationToken ct = default)
    {
        _dbContext.Equipments.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> DeleteAsync(long id, CancellationToken ct = default)
    {
        var entity = await _dbContext.Equipments.FindAsync(new object[] { id }, ct);
        if (entity == null) return false;

        _dbContext.Equipments.Remove(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<bool> CreateBatchAsync(IEnumerable<Equipment> entities, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(entities, nameof(entities));

        await _dbContext.Equipments.AddRangeAsync(entities, ct);
        var saved = await _dbContext.SaveChangesAsync(ct);

        return saved > 0;
    }

    public async Task<List<string>> CheckDuplicates(List<string> equipmentNames, CancellationToken ct = default)
    {
        // Check for existing equipment names in the database
        return await _dbContext.Equipments
            .Where(e => equipmentNames.Contains(e.EquipmentName))
            .Select(e => e.EquipmentName)
            .ToListAsync(ct);
    }

    public async Task<Equipment?> GetByVmtUserIdAsync(long vmtUserId, CancellationToken ct = default)
    {
        return await _dbContext.Equipments
             .Where(e => vmtUserId == e.VmtUserId)
             .FirstOrDefaultAsync(ct);
    }

    public async Task<Equipment?> GetByNameAsync(string equipmentName, CancellationToken ct = default)
    {
        return await _dbContext.Equipments
            .Where(e => equipmentName == e.EquipmentName)
            .FirstOrDefaultAsync(ct);
    }

    public async Task<List<Equipment>> GetListByNamesAsync(List<string> equipmentNames, CancellationToken ct = default)
    {
        return await _dbContext.Equipments
            .Where(e => equipmentNames.Contains(e.EquipmentName))
            .ToListAsync(ct);
    }

}
