using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Domain.DataAccess;

public class VmtAuditLoginDataAccess : IVmtAuditLoginDataAccess
{
    private readonly AppDbContext _dbContext;

    public VmtAuditLoginDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<VmtAuditLogin> CreateAsync(VmtAuditLogin entity, CancellationToken ct = default)
    {
        await _dbContext.VmtAuditLogins.AddAsync(entity, ct);
        await _dbContext.SaveChangesAsync(ct);
        return entity;
    }

    public async Task<VmtAuditLogin> GetByUserIdAndChe(string userId, string cheId, CancellationToken ct = default)
    {
        return await _dbContext.VmtAuditLogins
            .Where(v => v.UserId.Equals(userId) && v.EquipmentId.Equals(cheId))
            .OrderByDescending(v => v.Id)
            .FirstAsync(ct);
    }

    public async Task<bool> UpdateAsync(VmtAuditLogin entity, CancellationToken ct = default)
    {
        _dbContext.VmtAuditLogins.Update(entity);
        var affectedRows = await _dbContext.SaveChangesAsync(ct);
        return affectedRows > 0;
    }

    public async Task<List<VmtAuditLogin>> GetRecentAuditLogsAsync(List<string> cheCarries, DateTime fromDate)
    {
        return await _dbContext.VmtAuditLogins
            .Where(log =>
                cheCarries.Contains(log.EquipmentId) && 
                log.LoginTime != null &&
                log.LogoutTime != null &&
                log.LoginTime >= fromDate)
            .ToListAsync();
    }


}
