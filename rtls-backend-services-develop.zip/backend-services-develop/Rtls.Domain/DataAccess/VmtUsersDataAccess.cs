using Microsoft.EntityFrameworkCore;
using Rtls.Domain.Database;
using Rtls.Domain.Entities;
using Rtls.Domain.Interfaces;

namespace Rtls.Domain.DataAccess;

public class VmtUsersDataAccess : IVmtUsersDataAccess
{
    private readonly AppDbContext _dbContext;

    public VmtUsersDataAccess(AppDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    public async Task<VmtUsers?> GetByNameAsync(string userId, CancellationToken ct = default)
    {
        return await _dbContext.VmtUsers
           .Where(v => userId == v.UserId)
           .FirstOrDefaultAsync(ct);
    }
}
