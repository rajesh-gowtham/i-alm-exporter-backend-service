﻿namespace Rtls.Domain;

/// <summary>
/// Connections strings config
/// </summary>
public class ConnectionsConfig
{
    public string Master { get; init; }
    // public string Telemetry { get; init; }
    // public string Redis { get; init; }
    // public string Nats { get; init; }
}