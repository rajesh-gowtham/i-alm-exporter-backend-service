﻿namespace Rtls.Domain;

public static class Constants
{
    public static class EquipmentStatus
    {
        public const string IDLE = "Idle";
        public const string AVAILABLE = "Available";
        public const string UNAVAILABLE = "Unavailable";
        public const string LOGOUT = "Logout";
        public const string LOGIN = "Login";
        public const string WORKING = "Working";
        public const string LOCKED = "Locked";
    }

    public static class MoveTypes
    {
        public const string LOAD = "Load";
        public const string DISCHARGE = "Discharge";
    }

    public static class JobStatus
    {
        public const string COMPLETED = "Completed";
        public const string SUSPENDED = "Suspended";
        public const string PLANNED = "Planned";
        public const string INPROGRESS = "Inprogress";
        public const string YetToStart = "Yet to Start";
 
    }

    public static class VesselVisitPhase
    {
        public const string INBOUND = "Inbound";
        public const string ARRIVED = "Arrived";
        public const string WORKING = "Working";
        public const string COMPLETED = "Completed";
        public const string DEPARTED = "Departed";
    }

    public static class JobStepingStatus
    {
        public const string YET_TO_START = "Yet to Start";
        public const string DISPATCHED = "Dispatched";
        public const string CANCELLED = "Cancelled";
        public const string ARRIVE_TO_ORIGIN = "Arrive to Origin";
        public const string ARRIVED_AT_ORIGIN = "Arrived at Origin";
        public const string ARRIVE_TO_DESTINATION = "Arrive to Destination";
        public const string ARRIVED_AT_BLOCK = "Arrived at Block";
        public const string ARRIVED_AT_DESTINATION = "Arrived at Destination";
        public const string COMPLETED = "Completed";
        public const string SUSPENDED = "Suspended";
        public const string WAITING_PICKUP = "Waiting Pickup";
        public const string WAITING_DROP = "Waiting Drop";
    }

    public static class WorkInstructionMode
    {
        public const string TWIN = "Twin";
        public const string SINGLE = "Single";
    }

    public static class CardNames
    {
        public const string ActiveQc = "Active QC's";
        public const string TotalJobs = "Total Jobs";
        public const string AssignedItvs = "Assigned ITV's";
        public const string Alerts = "Alerts";
    }

    public static class UserStatus
    {
        public const string LOGIN = "Login";
        public const string LOGOUT = "Logout";
    }

    public static class RfidApiPaths
    {
        public const string AddReaderApi = "ReadPointMaster/AddReadPoint";
        public const string UpdateReaderApi = "ReadPointMaster/UpdateReadPoint";
        public const string DeleteReaderApi = "ReadPointMaster/DeleteReadPoint";
        public const string GetReaderApi = "ReadPointMaster/GetAllReadPointDetails";
        public const string GetReaderModelMasterDataApi = "ReadPointMaster/GetGlobalParameterByName/Reader Model";
        public const string GetReaderTypeMasterDataApi = "ReadPointMaster/GetGlobalParameterByName/Reader Type";
    }

    public static class RfidLevelTemplateApiPaths
    {
        public const string AddLevelTemplateApi = "LevelTemplate/AddLevelTemplate";
        public const string UpdateLevelTemplateApi = "LevelTemplate/UpdateLevelTemplate";
        public const string GetLevelTemplateApi = "LevelTemplate/GetLevelTemplate";
        public const string AddLevelTemplateValueApi = "LevelTemplate/AddLevelTemplateValue";
        public const string UpdateLevelTemplateValueApi = "LevelTemplate/UpdateLevelTemplateValue";
        public const string GetLevelTemplateValueApi = "LevelTemplate/GetLevelTemplateValues";
    }
}