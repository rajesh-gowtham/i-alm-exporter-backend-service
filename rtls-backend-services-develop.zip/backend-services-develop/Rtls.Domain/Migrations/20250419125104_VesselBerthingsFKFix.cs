﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class VesselBerthingsFKFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_vessel_berthings_vessel_visits_id",
                table: "vessel_berthings");

            migrationBuilder.DropIndex(
                name: "ix_vessel_berthings_vessel_visit_id",
                table: "vessel_berthings");

            migrationBuilder.AlterColumn<long>(
                name: "id",
                table: "vessel_berthings",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.CreateIndex(
                name: "ix_vessel_berthings_vessel_visit_id",
                table: "vessel_berthings",
                column: "vessel_visit_id",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_vessel_berthings_vessel_visit_id",
                table: "vessel_berthings");

            migrationBuilder.AlterColumn<long>(
                name: "id",
                table: "vessel_berthings",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.CreateIndex(
                name: "ix_vessel_berthings_vessel_visit_id",
                table: "vessel_berthings",
                column: "vessel_visit_id");

            migrationBuilder.AddForeignKey(
                name: "fk_vessel_berthings_vessel_visits_id",
                table: "vessel_berthings",
                column: "id",
                principalTable: "vessel_visits",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
