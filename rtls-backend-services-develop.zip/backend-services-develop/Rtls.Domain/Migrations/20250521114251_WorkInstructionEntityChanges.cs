﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class WorkInstructionEntityChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "pair_container",
                table: "work_instructions",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "weight",
                table: "work_instructions",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "pair_container",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "weight",
                table: "work_instructions");
        }
    }
}
