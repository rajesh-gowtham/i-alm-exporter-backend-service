﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class ChangesToWIAndEquipment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "outbound_location_type",
                table: "work_instructions",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<string>(
                name: "outbound_carrier",
                table: "work_instructions",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<string>(
                name: "inbound_location_type",
                table: "work_instructions",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<string>(
                name: "deck",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "status",
                table: "equipments",
                type: "text",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "boolean",
                oldNullable: true);

            migrationBuilder.AddColumn<long>(
                name: "vmt_user_id",
                table: "equipments",
                type: "bigint",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "vmt_users",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<string>(type: "text", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_vmt_users", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "ix_equipments_vmt_user_id",
                table: "equipments",
                column: "vmt_user_id");

            migrationBuilder.AddForeignKey(
                name: "fk_equipments_vmt_users_vmt_user_id",
                table: "equipments",
                column: "vmt_user_id",
                principalTable: "vmt_users",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_equipments_vmt_users_vmt_user_id",
                table: "equipments");

            migrationBuilder.DropTable(
                name: "vmt_users");

            migrationBuilder.DropIndex(
                name: "ix_equipments_vmt_user_id",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "deck",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "vmt_user_id",
                table: "equipments");

            migrationBuilder.AlterColumn<string>(
                name: "outbound_location_type",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "outbound_carrier",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "inbound_location_type",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "status",
                table: "equipments",
                type: "boolean",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);
        }
    }
}
