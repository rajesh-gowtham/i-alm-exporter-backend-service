﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class WorkInstructionFieldChangesV2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "discharge_time",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "dispatch_time",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "job_complete_time",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "job_start_time",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "time_at_destination",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "time_at_origin",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "time_facility_in",
                table: "work_instructions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "current_position",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "destination",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "origin",
                table: "equipments",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "discharge_time",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "dispatch_time",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "job_complete_time",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "job_start_time",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "time_at_destination",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "time_at_origin",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "time_facility_in",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "current_position",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "destination",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "origin",
                table: "equipments");
        }
    }
}
