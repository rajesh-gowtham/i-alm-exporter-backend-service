﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class DatabaseFieldChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_work_instructions_point_of_works_pow_id",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "vessel_visit_phase",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "bollard",
                table: "vessel_berthings");

            migrationBuilder.DropColumn(
                name: "bollard_aft",
                table: "vessel_berthings");

            migrationBuilder.DropColumn(
                name: "bollard_fore",
                table: "vessel_berthings");

            migrationBuilder.RenameColumn(
                name: "to_location",
                table: "work_instructions",
                newName: "work_instruction_status");

            migrationBuilder.RenameColumn(
                name: "pow_id",
                table: "work_instructions",
                newName: "point_of_work_id");

            migrationBuilder.RenameColumn(
                name: "equipment_type",
                table: "work_instructions",
                newName: "target_location");

            migrationBuilder.RenameColumn(
                name: "container_name",
                table: "work_instructions",
                newName: "pow_name");

            migrationBuilder.RenameColumn(
                name: "block_id",
                table: "work_instructions",
                newName: "job_stepping_status");

            migrationBuilder.RenameColumn(
                name: "bay_id",
                table: "work_instructions",
                newName: "iso_code");

            migrationBuilder.RenameIndex(
                name: "ix_work_instructions_pow_id",
                table: "work_instructions",
                newName: "ix_work_instructions_point_of_work_id");

            migrationBuilder.AlterColumn<string>(
                name: "container_id",
                table: "work_instructions",
                type: "character varying(11)",
                maxLength: 11,
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<DateTime>(
                name: "ata",
                table: "vessel_visits",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "atd",
                table: "vessel_visits",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "end_work_time",
                table: "vessel_visits",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "phase",
                table: "vessel_visits",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "start_work_time",
                table: "vessel_visits",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "visit_reference",
                table: "vessel_visits",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "end_bollard",
                table: "vessel_berthings",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "start_bollard",
                table: "vessel_berthings",
                type: "text",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "fk_work_instructions_point_of_works_point_of_work_id",
                table: "work_instructions",
                column: "point_of_work_id",
                principalTable: "point_of_works",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_work_instructions_point_of_works_point_of_work_id",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "ata",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "atd",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "end_work_time",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "phase",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "start_work_time",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "visit_reference",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "end_bollard",
                table: "vessel_berthings");

            migrationBuilder.DropColumn(
                name: "start_bollard",
                table: "vessel_berthings");

            migrationBuilder.RenameColumn(
                name: "work_instruction_status",
                table: "work_instructions",
                newName: "to_location");

            migrationBuilder.RenameColumn(
                name: "target_location",
                table: "work_instructions",
                newName: "equipment_type");

            migrationBuilder.RenameColumn(
                name: "pow_name",
                table: "work_instructions",
                newName: "container_name");

            migrationBuilder.RenameColumn(
                name: "point_of_work_id",
                table: "work_instructions",
                newName: "pow_id");

            migrationBuilder.RenameColumn(
                name: "job_stepping_status",
                table: "work_instructions",
                newName: "block_id");

            migrationBuilder.RenameColumn(
                name: "iso_code",
                table: "work_instructions",
                newName: "bay_id");

            migrationBuilder.RenameIndex(
                name: "ix_work_instructions_point_of_work_id",
                table: "work_instructions",
                newName: "ix_work_instructions_pow_id");

            migrationBuilder.AlterColumn<long>(
                name: "container_id",
                table: "work_instructions",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(11)",
                oldMaxLength: 11);

            migrationBuilder.AddColumn<string>(
                name: "vessel_visit_phase",
                table: "vessel_visits",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "bollard",
                table: "vessel_berthings",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "bollard_aft",
                table: "vessel_berthings",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "bollard_fore",
                table: "vessel_berthings",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "fk_work_instructions_point_of_works_pow_id",
                table: "work_instructions",
                column: "pow_id",
                principalTable: "point_of_works",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
