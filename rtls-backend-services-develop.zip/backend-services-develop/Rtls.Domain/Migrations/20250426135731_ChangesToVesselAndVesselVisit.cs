﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class ChangesToVesselAndVesselVisit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "code",
                table: "vessel_visits",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "ix_vessel_visits_code",
                table: "vessel_visits",
                column: "code",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_vessel_visits_code",
                table: "vessel_visits");

            migrationBuilder.DropColumn(
                name: "code",
                table: "vessel_visits");
        }
    }
}
