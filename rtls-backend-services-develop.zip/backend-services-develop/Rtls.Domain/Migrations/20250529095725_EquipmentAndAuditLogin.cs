﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class EquipmentAndAuditLogin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "is_inv_clear",
                table: "work_instructions",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "make",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "model",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "rfid_tag1",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "rfid_tag2",
                table: "equipments",
                type: "text",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "vmt_audit_logins",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<string>(type: "text", nullable: false),
                    equipment_id = table.Column<string>(type: "text", nullable: false),
                    login_time = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    logout_time = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    idle_time = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    stoppage_time = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_vmt_audit_logins", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "vmt_audit_logins");

            migrationBuilder.DropColumn(
                name: "is_inv_clear",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "make",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "model",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "rfid_tag1",
                table: "equipments");

            migrationBuilder.DropColumn(
                name: "rfid_tag2",
                table: "equipments");
        }
    }
}
