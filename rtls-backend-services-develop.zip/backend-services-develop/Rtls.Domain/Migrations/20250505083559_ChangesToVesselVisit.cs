﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class ChangesToVesselVisit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "visit_reference",
                table: "vessel_visits");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "visit_reference",
                table: "vessel_visits",
                type: "text",
                nullable: true);
        }
    }
}
