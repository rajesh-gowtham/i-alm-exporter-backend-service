﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class AddRfidAssetAndLevelTemplateEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "latitude",
                table: "rfid_assets");

            migrationBuilder.DropColumn(
                name: "location_id",
                table: "rfid_assets");

            migrationBuilder.DropColumn(
                name: "user_id",
                table: "rfid_assets");

            migrationBuilder.RenameColumn(
                name: "read_point_name",
                table: "rfid_assets",
                newName: "long");

            migrationBuilder.RenameColumn(
                name: "longitude",
                table: "rfid_assets",
                newName: "lat");

            migrationBuilder.RenameColumn(
                name: "itv_id",
                table: "rfid_assets",
                newName: "rpid");

            migrationBuilder.AlterColumn<string>(
                name: "updated_by",
                table: "rfid_assets",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "reader_type",
                table: "rfid_assets",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<string>(
                name: "reader_model",
                table: "rfid_assets",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<string>(
                name: "reader_ip",
                table: "rfid_assets",
                type: "character varying(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<string>(
                name: "created_by",
                table: "rfid_assets",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "antenna_id",
                table: "rfid_assets",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<string>(
                name: "rp_name",
                table: "rfid_assets",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "rfid_level_template",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    lt_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    ltid = table.Column<long>(type: "bigint", nullable: false),
                    lt_parent_id = table.Column<long>(type: "bigint", nullable: false),
                    created_by = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    updated_by = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_rfid_level_template", x => x.id);
                    table.UniqueConstraint("ak_rfid_level_template_ltid", x => x.ltid);
                });

            migrationBuilder.CreateTable(
                name: "rfid_level_template_values",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    lt_value = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    lt_vid = table.Column<long>(type: "bigint", nullable: false),
                    ltid = table.Column<long>(type: "bigint", nullable: false),
                    lt_v_parent_id = table.Column<long>(type: "bigint", nullable: false),
                    lt_v_description = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    created_by = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    updated_by = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_rfid_level_template_values", x => x.id);
                    table.ForeignKey(
                        name: "fk_rfid_level_template_values_rfid_level_template_ltid",
                        column: x => x.ltid,
                        principalTable: "rfid_level_template",
                        principalColumn: "ltid",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "ix_rfid_level_template_values_ltid",
                table: "rfid_level_template_values",
                column: "ltid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "rfid_level_template_values");

            migrationBuilder.DropTable(
                name: "rfid_level_template");

            migrationBuilder.DropColumn(
                name: "rp_name",
                table: "rfid_assets");

            migrationBuilder.RenameColumn(
                name: "rpid",
                table: "rfid_assets",
                newName: "itv_id");

            migrationBuilder.RenameColumn(
                name: "long",
                table: "rfid_assets",
                newName: "read_point_name");

            migrationBuilder.RenameColumn(
                name: "lat",
                table: "rfid_assets",
                newName: "longitude");

            migrationBuilder.AlterColumn<string>(
                name: "updated_by",
                table: "rfid_assets",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "reader_type",
                table: "rfid_assets",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "reader_model",
                table: "rfid_assets",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "reader_ip",
                table: "rfid_assets",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(50)",
                oldMaxLength: 50);

            migrationBuilder.AlterColumn<string>(
                name: "created_by",
                table: "rfid_assets",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "antenna_id",
                table: "rfid_assets",
                type: "text",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<string>(
                name: "latitude",
                table: "rfid_assets",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<double>(
                name: "location_id",
                table: "rfid_assets",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<string>(
                name: "user_id",
                table: "rfid_assets",
                type: "text",
                nullable: true);
        }
    }
}
