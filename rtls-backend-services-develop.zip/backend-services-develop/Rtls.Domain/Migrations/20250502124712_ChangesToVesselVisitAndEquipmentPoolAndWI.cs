﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class ChangesToVesselVisitAndEquipmentPoolAndWI : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "pow_name",
                table: "work_instructions");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "pow_name",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}
