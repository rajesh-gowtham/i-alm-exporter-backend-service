﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:PostgresExtension:postgis", ",,")
                .Annotation("Npgsql:PostgresExtension:uuid-ossp", ",,");

            migrationBuilder.CreateTable(
                name: "auth_roles",
                columns: table => new
                {
                    id = table.Column<string>(type: "text", nullable: false),
                    name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    normalized_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    concurrency_stamp = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_roles", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "auth_users",
                columns: table => new
                {
                    id = table.Column<string>(type: "text", nullable: false),
                    user_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    normalized_user_name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    normalized_email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    email_confirmed = table.Column<bool>(type: "boolean", nullable: false),
                    password_hash = table.Column<string>(type: "text", nullable: true),
                    security_stamp = table.Column<string>(type: "text", nullable: true),
                    concurrency_stamp = table.Column<string>(type: "text", nullable: true),
                    phone_number = table.Column<string>(type: "text", nullable: true),
                    phone_number_confirmed = table.Column<bool>(type: "boolean", nullable: false),
                    two_factor_enabled = table.Column<bool>(type: "boolean", nullable: false),
                    lockout_end = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    lockout_enabled = table.Column<bool>(type: "boolean", nullable: false),
                    access_failed_count = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "equipments",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    equipment_name = table.Column<string>(type: "text", nullable: false),
                    equipment_type = table.Column<string>(type: "text", nullable: false),
                    max_weight = table.Column<int>(type: "integer", nullable: true),
                    max_teu = table.Column<int>(type: "integer", nullable: true),
                    status = table.Column<bool>(type: "boolean", nullable: true),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateOnly>(type: "date", nullable: true),
                    updated_at = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_equipments", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "point_of_works",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    point_of_work_name = table.Column<string>(type: "text", nullable: false),
                    status = table.Column<bool>(type: "boolean", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: false),
                    updated_by = table.Column<string>(type: "text", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_point_of_works", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "vessels",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    vessel_name = table.Column<string>(type: "text", nullable: false),
                    overall_length = table.Column<int>(type: "integer", nullable: false),
                    lords_identity = table.Column<string>(type: "text", nullable: false),
                    vessel_class = table.Column<string>(type: "text", nullable: false),
                    radio_call_sign = table.Column<string>(type: "text", nullable: false),
                    @operator = table.Column<string>(name: "operator", type: "text", nullable: false),
                    status = table.Column<bool>(type: "boolean", nullable: true),
                    created_by = table.Column<string>(type: "text", nullable: false),
                    updated_by = table.Column<string>(type: "text", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_vessels", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "auth_role_claims",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    role_id = table.Column<string>(type: "text", nullable: false),
                    claim_type = table.Column<string>(type: "text", nullable: true),
                    claim_value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_role_claims", x => x.id);
                    table.ForeignKey(
                        name: "fk_auth_role_claims_auth_roles_role_id",
                        column: x => x.role_id,
                        principalTable: "auth_roles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "auth_user_claims",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    user_id = table.Column<string>(type: "text", nullable: false),
                    claim_type = table.Column<string>(type: "text", nullable: true),
                    claim_value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_user_claims", x => x.id);
                    table.ForeignKey(
                        name: "fk_auth_user_claims_auth_users_user_id",
                        column: x => x.user_id,
                        principalTable: "auth_users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "auth_user_logins",
                columns: table => new
                {
                    login_provider = table.Column<string>(type: "text", nullable: false),
                    provider_key = table.Column<string>(type: "text", nullable: false),
                    provider_display_name = table.Column<string>(type: "text", nullable: true),
                    user_id = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_user_logins", x => new { x.login_provider, x.provider_key });
                    table.ForeignKey(
                        name: "fk_auth_user_logins_auth_users_user_id",
                        column: x => x.user_id,
                        principalTable: "auth_users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "auth_user_roles",
                columns: table => new
                {
                    user_id = table.Column<string>(type: "text", nullable: false),
                    role_id = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_user_roles", x => new { x.user_id, x.role_id });
                    table.ForeignKey(
                        name: "fk_auth_user_roles_auth_roles_role_id",
                        column: x => x.role_id,
                        principalTable: "auth_roles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_auth_user_roles_auth_users_user_id",
                        column: x => x.user_id,
                        principalTable: "auth_users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "auth_user_tokens",
                columns: table => new
                {
                    user_id = table.Column<string>(type: "text", nullable: false),
                    login_provider = table.Column<string>(type: "text", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false),
                    value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_auth_user_tokens", x => new { x.user_id, x.login_provider, x.name });
                    table.ForeignKey(
                        name: "fk_auth_user_tokens_auth_users_user_id",
                        column: x => x.user_id,
                        principalTable: "auth_users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "equipment_pools",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    pool_name = table.Column<string>(type: "text", nullable: false),
                    dispatch_state = table.Column<string>(type: "text", nullable: true),
                    operating_mode = table.Column<string>(type: "text", nullable: true),
                    job_start_position = table.Column<string>(type: "text", nullable: true),
                    equipment_id = table.Column<long>(type: "bigint", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_equipment_pools", x => x.id);
                    table.ForeignKey(
                        name: "fk_equipment_pools_equipments_equipment_id",
                        column: x => x.equipment_id,
                        principalTable: "equipments",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "vessel_visits",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    vessel_class = table.Column<string>(type: "text", nullable: false),
                    inbound_voyage = table.Column<string>(type: "text", nullable: false),
                    outbound_voyage = table.Column<string>(type: "text", nullable: false),
                    vessel_visit_phase = table.Column<string>(type: "text", nullable: false),
                    line_operator = table.Column<string>(type: "text", nullable: false),
                    eta = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    etd = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    vessel_id = table.Column<long>(type: "bigint", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_vessel_visits", x => x.id);
                    table.ForeignKey(
                        name: "fk_vessel_visits_vessels_vessel_id",
                        column: x => x.vessel_id,
                        principalTable: "vessels",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "equipment_pool_assignments",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    equipment_pool_id = table.Column<long>(type: "bigint", nullable: false),
                    equipment_id = table.Column<long>(type: "bigint", nullable: false),
                    assignment_status = table.Column<bool>(type: "boolean", nullable: true),
                    equipment_assigned_date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_equipment_pool_assignments", x => x.id);
                    table.ForeignKey(
                        name: "fk_equipment_pool_assignments_equipment_pools_equipment_pool_id",
                        column: x => x.equipment_pool_id,
                        principalTable: "equipment_pools",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_equipment_pool_assignments_equipments_equipment_id",
                        column: x => x.equipment_id,
                        principalTable: "equipments",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "pow_assignments",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    pow_id = table.Column<long>(type: "bigint", nullable: false),
                    equipment_pool_id = table.Column<long>(type: "bigint", nullable: false),
                    equipment_pool_status = table.Column<bool>(type: "boolean", nullable: true),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_pow_assignments", x => x.id);
                    table.ForeignKey(
                        name: "fk_pow_assignments_equipment_pools_equipment_pool_id",
                        column: x => x.equipment_pool_id,
                        principalTable: "equipment_pools",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_pow_assignments_point_of_works_pow_id",
                        column: x => x.pow_id,
                        principalTable: "point_of_works",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "vessel_berthings",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false),
                    sequence = table.Column<int>(type: "integer", nullable: false),
                    quay = table.Column<string>(type: "text", nullable: false),
                    berthing_side = table.Column<string>(type: "text", nullable: false),
                    berth_eta = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    berth_etd = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    berth_ata = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    start_work_time = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    bollard = table.Column<string>(type: "text", nullable: false),
                    bollard_fore = table.Column<int>(type: "integer", nullable: false),
                    bollard_aft = table.Column<int>(type: "integer", nullable: false),
                    vessel_visit_id = table.Column<long>(type: "bigint", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_vessel_berthings", x => x.id);
                    table.ForeignKey(
                        name: "fk_vessel_berthings_vessel_visits_id",
                        column: x => x.id,
                        principalTable: "vessel_visits",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_vessel_berthings_vessel_visits_vessel_visit_id",
                        column: x => x.vessel_visit_id,
                        principalTable: "vessel_visits",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "work_instructions",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    vessel_visit_id = table.Column<long>(type: "bigint", nullable: false),
                    move_type = table.Column<string>(type: "text", nullable: false),
                    equipment_id = table.Column<long>(type: "bigint", nullable: false),
                    from_location = table.Column<string>(type: "text", nullable: false),
                    to_location = table.Column<string>(type: "text", nullable: false),
                    dispatch_state = table.Column<string>(type: "text", nullable: false),
                    equipment_type = table.Column<string>(type: "text", nullable: false),
                    assigned_che = table.Column<string>(type: "text", nullable: false),
                    assigned_lane = table.Column<string>(type: "text", nullable: false),
                    che_carry = table.Column<string>(type: "text", nullable: false),
                    current_position = table.Column<string>(type: "text", nullable: false),
                    position_on_carriage = table.Column<string>(type: "text", nullable: false),
                    block_id = table.Column<string>(type: "text", nullable: false),
                    bay_id = table.Column<string>(type: "text", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    pow_id = table.Column<long>(type: "bigint", nullable: false),
                    container_id = table.Column<long>(type: "bigint", nullable: false),
                    container_name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_work_instructions", x => x.id);
                    table.ForeignKey(
                        name: "fk_work_instructions_equipments_equipment_id",
                        column: x => x.equipment_id,
                        principalTable: "equipments",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_work_instructions_point_of_works_pow_id",
                        column: x => x.pow_id,
                        principalTable: "point_of_works",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_work_instructions_vessel_visits_vessel_visit_id",
                        column: x => x.vessel_visit_id,
                        principalTable: "vessel_visits",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "ix_auth_role_claims_role_id",
                table: "auth_role_claims",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "auth_roles",
                column: "normalized_name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_auth_user_claims_user_id",
                table: "auth_user_claims",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_auth_user_logins_user_id",
                table: "auth_user_logins",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ix_auth_user_roles_role_id",
                table: "auth_user_roles",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "auth_users",
                column: "normalized_email");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "auth_users",
                column: "normalized_user_name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_equipment_pool_assignments_equipment_id",
                table: "equipment_pool_assignments",
                column: "equipment_id");

            migrationBuilder.CreateIndex(
                name: "ix_equipment_pool_assignments_equipment_pool_id",
                table: "equipment_pool_assignments",
                column: "equipment_pool_id");

            migrationBuilder.CreateIndex(
                name: "ix_equipment_pools_equipment_id",
                table: "equipment_pools",
                column: "equipment_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_pow_assignments_equipment_pool_id",
                table: "pow_assignments",
                column: "equipment_pool_id");

            migrationBuilder.CreateIndex(
                name: "ix_pow_assignments_pow_id",
                table: "pow_assignments",
                column: "pow_id");

            migrationBuilder.CreateIndex(
                name: "ix_vessel_berthings_vessel_visit_id",
                table: "vessel_berthings",
                column: "vessel_visit_id");

            migrationBuilder.CreateIndex(
                name: "ix_vessel_visits_vessel_id",
                table: "vessel_visits",
                column: "vessel_id");

            migrationBuilder.CreateIndex(
                name: "ix_work_instructions_equipment_id",
                table: "work_instructions",
                column: "equipment_id");

            migrationBuilder.CreateIndex(
                name: "ix_work_instructions_pow_id",
                table: "work_instructions",
                column: "pow_id");

            migrationBuilder.CreateIndex(
                name: "ix_work_instructions_vessel_visit_id",
                table: "work_instructions",
                column: "vessel_visit_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "auth_role_claims");

            migrationBuilder.DropTable(
                name: "auth_user_claims");

            migrationBuilder.DropTable(
                name: "auth_user_logins");

            migrationBuilder.DropTable(
                name: "auth_user_roles");

            migrationBuilder.DropTable(
                name: "auth_user_tokens");

            migrationBuilder.DropTable(
                name: "equipment_pool_assignments");

            migrationBuilder.DropTable(
                name: "pow_assignments");

            migrationBuilder.DropTable(
                name: "vessel_berthings");

            migrationBuilder.DropTable(
                name: "work_instructions");

            migrationBuilder.DropTable(
                name: "auth_roles");

            migrationBuilder.DropTable(
                name: "auth_users");

            migrationBuilder.DropTable(
                name: "equipment_pools");

            migrationBuilder.DropTable(
                name: "point_of_works");

            migrationBuilder.DropTable(
                name: "vessel_visits");

            migrationBuilder.DropTable(
                name: "equipments");

            migrationBuilder.DropTable(
                name: "vessels");
        }
    }
}
