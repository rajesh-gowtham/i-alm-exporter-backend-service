﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class ChangesToWIAndVesselVisitAndVessel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "inbound_mode",
                table: "work_instructions",
                newName: "outbound_location_type");

            migrationBuilder.RenameColumn(
                name: "current_position",
                table: "work_instructions",
                newName: "outbound_carrier");

            migrationBuilder.AddColumn<string>(
                name: "inbound_location_type",
                table: "work_instructions",
                type: "text",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "inbound_location_type",
                table: "work_instructions");

            migrationBuilder.RenameColumn(
                name: "outbound_location_type",
                table: "work_instructions",
                newName: "inbound_mode");

            migrationBuilder.RenameColumn(
                name: "outbound_carrier",
                table: "work_instructions",
                newName: "current_position");
        }
    }
}
