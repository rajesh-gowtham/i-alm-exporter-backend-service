﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class CreateWorkQueueEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "work_queues",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "text", nullable: false),
                    type = table.Column<string>(type: "text", nullable: true),
                    deck = table.Column<string>(type: "text", nullable: false),
                    vessel_visit_id = table.Column<long>(type: "bigint", nullable: false),
                    pow_id = table.Column<long>(type: "bigint", nullable: false),
                    point_of_work_id = table.Column<long>(type: "bigint", nullable: false),
                    created_by = table.Column<string>(type: "text", nullable: true),
                    updated_by = table.Column<string>(type: "text", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_work_queues", x => x.id);
                    table.ForeignKey(
                        name: "fk_work_queues_point_of_works_point_of_work_id",
                        column: x => x.point_of_work_id,
                        principalTable: "point_of_works",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_work_queues_vessel_visits_vessel_visit_id",
                        column: x => x.vessel_visit_id,
                        principalTable: "vessel_visits",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_work_queues_point_of_work_id",
                table: "work_queues",
                column: "point_of_work_id");

            migrationBuilder.CreateIndex(
                name: "ix_work_queues_vessel_visit_id",
                table: "work_queues",
                column: "vessel_visit_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "work_queues");
        }
    }
}
