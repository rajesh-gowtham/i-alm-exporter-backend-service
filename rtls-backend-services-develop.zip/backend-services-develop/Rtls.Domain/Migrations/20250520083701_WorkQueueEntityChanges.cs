﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rtls.Domain.Migrations
{
    /// <inheritdoc />
    public partial class WorkQueueEntityChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_work_queues_point_of_works_point_of_work_id",
                table: "work_queues");

            migrationBuilder.DropForeignKey(
                name: "fk_work_queues_vessel_visits_vessel_visit_id",
                table: "work_queues");

            migrationBuilder.AddColumn<string>(
                name: "status",
                table: "work_queues",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<long>(
                name: "work_queue_id",
                table: "work_instructions",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "ix_work_instructions_work_queue_id",
                table: "work_instructions",
                column: "work_queue_id");

            migrationBuilder.AddForeignKey(
                name: "fk_work_instructions_work_queues_work_queue_id",
                table: "work_instructions",
                column: "work_queue_id",
                principalTable: "work_queues",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "fk_work_queues_point_of_works_point_of_work_id",
                table: "work_queues",
                column: "point_of_work_id",
                principalTable: "point_of_works",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "fk_work_queues_vessel_visits_vessel_visit_id",
                table: "work_queues",
                column: "vessel_visit_id",
                principalTable: "vessel_visits",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_work_instructions_work_queues_work_queue_id",
                table: "work_instructions");

            migrationBuilder.DropForeignKey(
                name: "fk_work_queues_point_of_works_point_of_work_id",
                table: "work_queues");

            migrationBuilder.DropForeignKey(
                name: "fk_work_queues_vessel_visits_vessel_visit_id",
                table: "work_queues");

            migrationBuilder.DropIndex(
                name: "ix_work_instructions_work_queue_id",
                table: "work_instructions");

            migrationBuilder.DropColumn(
                name: "status",
                table: "work_queues");

            migrationBuilder.DropColumn(
                name: "work_queue_id",
                table: "work_instructions");

            migrationBuilder.AddColumn<long>(
                name: "pow_id",
                table: "work_queues",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddForeignKey(
                name: "fk_work_queues_point_of_works_point_of_work_id",
                table: "work_queues",
                column: "point_of_work_id",
                principalTable: "point_of_works",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_work_queues_vessel_visits_vessel_visit_id",
                table: "work_queues",
                column: "vessel_visit_id",
                principalTable: "vessel_visits",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
