﻿using System.Buffers;

namespace Rtls.Domain.Helpers;

public static class Utils
{
    public static Dictionary<string, TValue> Merge<TValue>(this IDictionary<string, TValue> source,
        params IDictionary<string, TValue>[] others)
    {
        var result = new Dictionary<string, TValue>(StringComparer.OrdinalIgnoreCase);

        foreach (var dictionary in new[]
                 {
                     source
                 }.Concat(others))
        {
            foreach (var element in dictionary)
            {
                if (result.ContainsKey(element.Key))
                {
                    if (element.Value != null)
                        result[element.Key] = element.Value;
                }
                else
                {
                    result.TryAdd(element.Key, element.Value);
                }
            }
        }

        return result;
    }

    public static T[] AddItemsWithArrayPool<T>(IEnumerable<T> items, int approximateSize)
    {
        var pool = ArrayPool<T>.Shared;
        T[] buffer = pool.Rent(approximateSize);
        int count = 0;

        foreach (var item in items)
        {
            if (count == buffer.Length)
            {
                var newBuffer = pool.Rent(buffer.Length * 2);
                Array.Copy(buffer, newBuffer, buffer.Length);
                pool.Return(buffer);
                buffer = newBuffer;
            }
            buffer[count++] = item;
        }

        var result = new T[count];
        Array.Copy(buffer, result, count);
        pool.Return(buffer);
        return result;
    }
}