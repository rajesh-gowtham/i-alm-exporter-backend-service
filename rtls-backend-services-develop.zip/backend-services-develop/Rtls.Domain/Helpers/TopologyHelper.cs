﻿using NetTopologySuite.Features;
using NetTopologySuite.Geometries;

namespace Rtls.Domain.Helpers;

public static class TopologyHelper
{
    public static bool IsWithin(Point point, FeatureCollection featureCollection)
    {
        var within = false;
        foreach (var feature in featureCollection)
        {
            within = feature.Geometry switch
            {
                MultiPoint multiPoint => point.Within(multiPoint),
                LineString lineString => point.Within(lineString),
                MultiLineString multiLineString => point.Within(multiLineString),
                Polygon polygon => point.Within(polygon),
                MultiPolygon multiPolygon => point.Within(multiPolygon),
                GeometryCollection geometryCollection => point.Within(geometryCollection),
                _ => false,
            };

            if (within) break;
        }
        return within;
    }
    
    public static Point CreatePoint(double longitude, double latitude)
    {
        // // Create geometry factory if needed
        // var geometryFactory = NtsGeometryServices.Instance.CreateGeometryFactory(srid: 4326);
        // // Create Point (X = Longitude, Y = Latitude)
        // return geometryFactory.CreatePoint(new Coordinate(longitude, latitude));
        return new Point(new Coordinate(longitude, latitude))
        {
            SRID = 4326 // WGS 84
        };
    }
}