﻿using Npgsql;
using Rtls.Domain.Models;

namespace Rtls.Domain.Helpers;

public static class TimescaleExtensions
{
    public static async Task InsertDeviceMessage(this NpgsqlDataSource? dataSource, DeviceMessage deviceMessage,
        CancellationToken cancellationToken = default)
    {
        if (dataSource is null) return;

        const string commandText =
            """
            INSERT INTO device_messages (
                device_id, gps_time, received_time, altitude, latitude, longitude, loc, heading, speed, ign, params, zones
            ) VALUES (
                @DeviceId,
                @GpsTime,
                @ReceivedTime,
                @Altitude,
                @Latitude,
                @Longitude,
                ST_SetSRID(ST_MakePoint(@Longitude, @Latitude), 4326),
                @Heading,
                @Speed,
                @Ignition,
                @Params::jsonb,
                @Zones
            )
            """;

        await using var command = dataSource.CreateCommand(commandText);
        // set command parameters
        command.Parameters.Add(new() { ParameterName = "DeviceId", Value = deviceMessage.DeviceId });
        command.Parameters.Add(new() { ParameterName = "GpsTime", Value = deviceMessage.GpsTime });
        command.Parameters.Add(new() { ParameterName = "ReceivedTime", Value = deviceMessage.ReceiveTime });
        command.Parameters.Add(new() { ParameterName = "Altitude", Value = deviceMessage.Altitude });
        command.Parameters.Add(new() { ParameterName = "Latitude", Value = deviceMessage.Latitude });
        command.Parameters.Add(new() { ParameterName = "Longitude", Value = deviceMessage.Longitude });
        command.Parameters.Add(new() { ParameterName = "Heading", Value = deviceMessage.Heading });

        // get data from params
        var speed = deviceMessage.GetParam<int>("speed");
        var ignition = deviceMessage.GetParam<bool?>("ignition");

        command.Parameters.Add(new() { ParameterName = "Speed", Value = speed });
        command.Parameters.Add(new()
            { ParameterName = "Ignition", Value = ignition.HasValue ? ignition.Value : DBNull.Value });

        // store parameters dict as a JSON
        var jsonParams = System.Text.Json.JsonSerializer.Serialize(deviceMessage.Parameters);
        command.Parameters.Add(new()
            { ParameterName = "Params", Value = jsonParams, NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Jsonb });
        
        // zones
        command.Parameters.Add(new()
        {
            ParameterName = "Zones", 
            Value = deviceMessage.Zones, 
            NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
        });

        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}