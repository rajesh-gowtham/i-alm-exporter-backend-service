﻿using ZiggyCreatures.Caching.Fusion;

namespace Rtls.Domain.Helpers;

public static class CacheHelper
{
    public static FusionCacheEntryOptions DefaultOptions(this FusionCacheEntryOptions opt)
    {
        opt.Duration = TimeSpan.FromMinutes(5);
        // opt.IsFailSafeEnabled = true;
        // opt.FailSafeMaxDuration = TimeSpan.FromHours(1);
        // opt.FailSafeThrottleDuration = TimeSpan.FromSeconds(45);
        //
        // opt.FactorySoftTimeout = TimeSpan.FromSeconds(2);
        // opt.FactoryHardTimeout = TimeSpan.FromSeconds(10);
        //
        // opt.DistributedCacheDuration = TimeSpan.FromMinutes(15);
        // opt.DistributedCacheSoftTimeout = TimeSpan.FromSeconds(3);
        // opt.DistributedCacheHardTimeout = TimeSpan.FromSeconds(10);
        // opt.AllowBackgroundDistributedCacheOperations = true;
        //
        // opt.JitterMaxDuration = TimeSpan.FromSeconds(2);
        return opt;
    }

    public static FusionCacheEntryOptions WithInMemOptions(this FusionCacheEntryOptions opt, bool eagerRefresh = false)
    {
        opt.Duration = TimeSpan.FromMinutes(5);
        opt.IsFailSafeEnabled = true;
        opt.FailSafeMaxDuration = TimeSpan.FromMinutes(15);
        opt.FactorySoftTimeout = TimeSpan.FromSeconds(60);
        opt.FactoryHardTimeout = TimeSpan.FromSeconds(120);
        if (eagerRefresh)
            opt.EagerRefreshThreshold = 0.8f;
        opt.SkipDistributedCache = true;
        opt.SkipBackplaneNotifications = true;
        return opt;
    }

    public static FusionCacheEntryOptions WithDistributedOptions(this FusionCacheEntryOptions opt)
    {
        opt.SkipDistributedCache = false;
        opt.AllowBackgroundDistributedCacheOperations = true;
        opt.SkipBackplaneNotifications = true;
        opt.Duration = TimeSpan.FromMinutes(5);
        opt.IsFailSafeEnabled = true;
        opt.FailSafeMaxDuration = TimeSpan.FromHours(1);
        opt.FailSafeThrottleDuration = TimeSpan.FromSeconds(45);
        opt.FactorySoftTimeout = TimeSpan.FromSeconds(2);
        opt.FactoryHardTimeout = TimeSpan.FromSeconds(10);
        opt.EagerRefreshThreshold = 0.8f;
        opt.DistributedCacheDuration = TimeSpan.FromMinutes(15);
        opt.DistributedCacheSoftTimeout = TimeSpan.FromSeconds(3);
        opt.DistributedCacheHardTimeout = TimeSpan.FromSeconds(10);
        opt.DistributedCacheFailSafeMaxDuration = TimeSpan.FromSeconds(30);
        opt.JitterMaxDuration = TimeSpan.FromSeconds(2);
        return opt;
    }

    public static FusionCacheEntryOptions VehiclesOptions => new()
    {
        SkipBackplaneNotifications = true,
        SkipDistributedCache = true,
        Duration = TimeSpan.FromMinutes(1),
        IsFailSafeEnabled = true,
        FailSafeMaxDuration = TimeSpan.FromMinutes(30),
        FailSafeThrottleDuration = TimeSpan.FromSeconds(30),
        FactorySoftTimeout = TimeSpan.FromSeconds(5),
        FactoryHardTimeout = TimeSpan.FromSeconds(30),
        AllowTimedOutFactoryBackgroundCompletion = true,
    };
}