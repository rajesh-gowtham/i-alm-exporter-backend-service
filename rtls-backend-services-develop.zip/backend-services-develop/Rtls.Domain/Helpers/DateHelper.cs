﻿namespace Rtls.Domain.Helpers;

public static class DateHelper
{
    public static DateTime ConvertToUtc(this DateTime localTime, int offsetMinutes)
    {
        // Ensure that localTime is treated as unspecified so we can apply the offset
        var unspecifiedLocalTime = DateTime.SpecifyKind(localTime, DateTimeKind.Unspecified);
        // Negate offsetMinutes since Date.getTimezoneOffset returns minutes to add to local time to get UTC
        var localOffset = TimeSpan.FromMinutes(-offsetMinutes);
        var localDateTimeOffset = new DateTimeOffset(unspecifiedLocalTime, localOffset);
        return localDateTimeOffset.UtcDateTime;
    }
    
    public static DateTime ConvertUtcToLocal(this DateTime utcTime, int offsetMinutes)
    {
        // Ensure that utcTime is explicitly marked as UTC
        if (utcTime.Kind != DateTimeKind.Utc)
        {
            utcTime = DateTime.SpecifyKind(utcTime, DateTimeKind.Utc);
        }
    
        // Since getTimezoneOffset returns the number of minutes to add to local time to get UTC,
        // you subtract the offset from UTC time to recover the local time.
        return utcTime.AddMinutes(-offsetMinutes);
    }

    public static DateTime SetKindUtc(this DateTime dateTime)
    {
        return dateTime.Kind == DateTimeKind.Utc ? dateTime : DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
    }

    public static DateTime SetUnspecified(this DateTime dateTime)
    {
        return dateTime.Kind == DateTimeKind.Unspecified ? dateTime : DateTime.SpecifyKind(dateTime, DateTimeKind.Unspecified);
    }
}