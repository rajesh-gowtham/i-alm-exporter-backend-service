using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IEquipmentDataAccess
{
    Task<PagedResponse<Equipment>> GetAllAsync(int skip, int? take, string search = "", CancellationToken ct = default);
    Task<Equipment?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<Equipment> CreateAsync(Equipment entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(Equipment entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<Equipment> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicates(List<string> equipmentNames, CancellationToken ct = default);
    Task<Equipment?> GetByVmtUserIdAsync(long vmtUserId, CancellationToken ct = default);
    Task<Equipment?> GetByNameAsync(string equipmentName, CancellationToken ct = default);
    Task<List<Equipment>> GetListByNamesAsync(List<string> equipmentNames, CancellationToken ct = default);
}
