using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IRfidAssetDataAccess
{
    Task<bool> CreateAsync(RfidAsset entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> UpdateAsync(RfidAsset entity, CancellationToken ct = default);
    Task<List<string>> FindDuplicateDataAsync(string name, string latitude, string longitude, CancellationToken ct = default);
}
