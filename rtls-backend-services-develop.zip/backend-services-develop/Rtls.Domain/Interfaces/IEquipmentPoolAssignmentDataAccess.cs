using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces
{
    public interface IEquipmentPoolAssignmentDataAccess
    {
        Task<PagedResponse<EquipmentPoolAssignment>> GetAllAsync(int skip = 0, int? take = null, CancellationToken ct = default);
        Task<List<EquipmentPoolAssignment>?> GetByIdAsync(long id, CancellationToken ct = default);
        Task<bool> UpdateAsync(List<EquipmentPoolAssignment> entity, long equipmentPoolId, CancellationToken ct = default);
        Task<bool> DeleteByEquipmentPoolIdAsync(long id, CancellationToken ct = default);
        Task<Dictionary<long, string>> GetEquipmentPoolNameMap();
        Task<List<string>> GetAssignedEquipmentNames(string equipmentPoolName, CancellationToken ct = default);
        Task<EquipmentPoolAssignment?> GetByEquipmentId(long equipmentId);
        Task<string> GetPoolNameByEquipmentName(string equipmentName, CancellationToken ct = default);
    }
}