using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IEquipmentPoolDataAccess
{
    Task<PagedResponse<EquipmentPool>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<EquipmentPool?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<EquipmentPool> CreateAsync(EquipmentPool entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(EquipmentPool entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<EquipmentPool> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicates(List<string> poolNames, CancellationToken ct = default);
    Task<EquipmentPool?> GetByPoolName(string poolName, CancellationToken ct = default);
}
