using Rtls.Domain.Entities;

namespace Rtls.Domain.Interfaces;

public interface IVmtUsersDataAccess
{
    Task<VmtUsers> GetByNameAsync(string userId, CancellationToken ct = default);
}
