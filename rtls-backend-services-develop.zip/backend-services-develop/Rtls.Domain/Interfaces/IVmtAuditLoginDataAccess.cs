using Rtls.Domain.Entities;

namespace Rtls.Domain.Interfaces;

public interface IVmtAuditLoginDataAccess
{
    Task<VmtAuditLogin> CreateAsync(VmtAuditLogin entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(VmtAuditLogin entity, CancellationToken ct = default);
    Task<VmtAuditLogin> GetByUserIdAndChe(string userId, string cheId, CancellationToken ct = default);
    Task<List<VmtAuditLogin>> GetRecentAuditLogsAsync(List<string> cheCarries, DateTime fromDate);
}
