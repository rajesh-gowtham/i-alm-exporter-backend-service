using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IRfidLevelTemplateDataAccess
{
    Task<bool> CreateAsync(RfidLevelTemplate entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(RfidLevelTemplate entity, CancellationToken ct = default);
    Task<int> GetCountByName(string name, CancellationToken ct = default);
    Task<RfidLevelTemplate> GetByLTIdAsync(long id, CancellationToken ct = default);
}
