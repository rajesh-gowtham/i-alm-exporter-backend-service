﻿using Rtls.Domain.Entities;

namespace Rtls.Domain.Interfaces
{
    public interface IWorkQueueDataAccess
    {
        Task<WorkQueue?> GetByIdAsync(long id, CancellationToken ct = default);
        Task<WorkQueue> CreateSingleAsync(WorkQueue entity, CancellationToken ct = default);
        Task<List<WorkQueue>> CreateAsync(List<WorkQueue> entity, CancellationToken ct = default);
        Task<List<WorkQueue>> GetByVesselVisitIdsAsync(List<long> vesselVisitIds, CancellationToken ct = default);
        Task<List<WorkQueue>> GetByVesselVisitIdPowAsync(long vesselVisitId, long powId, CancellationToken ct = default);
        Task<bool> UpdateAsync(WorkQueue entity, CancellationToken ct = default);
        Task<WorkQueue> GetByPoolName(string poolName, CancellationToken ct = default);
        Task<long> GetCountAgainstPow(long powId, long vesselVisitId, CancellationToken ct = default);
        Task<string> GetCountAgainstVessel(long powId, CancellationToken ct = default);
        Task<List<string>> GetADeckWorkQueue(List<string> name, long vesselVisitId, string deck, CancellationToken ct = default);
        Task<bool> DeleteAsync(List<long> ids, CancellationToken ct = default);
    }
}
