using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IWorkInstructionDataAccess
{
    Task<PagedResponse<WorkInstruction>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<WorkInstruction?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<WorkInstruction> CreateAsync(WorkInstruction entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(WorkInstruction entity, CancellationToken ct = default);
    // temp
    Task<bool> UpdateEntityAsync(WorkInstruction entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(WorkInstruction entity, CancellationToken ct = default);
    Task<HashSet<long>> GetVesselIdByFilterAsync(String search, CancellationToken ct = default);
    Task<HashSet<WorkInstruction>> GetByVesselIdAsync(HashSet<long> vesselIds, String powName, CancellationToken ct = default);
    Task<HashSet<WorkInstruction>> GetByVesselIdAsync(HashSet<long> vesselIds, CancellationToken ct = default);
    Task<List<WorkInstruction>> GetByVesselVisitIdAndPowIdAsync(long vesselVisitId, long powId, CancellationToken ct = default);
    Task<PagedResponse<WorkInstruction>> GetByWorkQueueIdAsync(int skip, int take, long workQueueId, string search="", 
        CancellationToken ct = default);
    Task<List<WorkInstruction>> GetByVesselVisitIdAsync(long vesselVisitId, CancellationToken ct);
    Task<bool> CreateBatchAsync(IEnumerable<WorkInstruction> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicates(List<string> containerIds, CancellationToken ct = default);
    Task<int> GetActiveQcCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct);
    Task<int> GetTotalJobsCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct);
    Task<int> GetAssignedItvsCountAsync(IEnumerable<long> vesselVisitIds, CancellationToken ct);
    Task<int> GetCountByPow(long powId, CancellationToken ct);
    Task<List<WorkInstruction>> GetByEquipmentId(string equipmentId, CancellationToken ct);
    Task<PagedResponse<WorkInstruction>> GetAllInventoryContainerAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<PagedResponse<WorkInstruction>> GetAllInventoryVessel(int skip, int? take, string search, CancellationToken ct = default);
    Task<bool> ContainerClearAsync(List<long> ids, CancellationToken ct = default);
    Task<WorkInstruction> GetInventoryContainerById(long id, CancellationToken ct);
    Task<List<WorkInstruction>> GetByIds(List<long> ids, CancellationToken ct);
    Task<bool> UpdateBatchAsync(IEnumerable<WorkInstruction> entities, CancellationToken ct = default);
}
