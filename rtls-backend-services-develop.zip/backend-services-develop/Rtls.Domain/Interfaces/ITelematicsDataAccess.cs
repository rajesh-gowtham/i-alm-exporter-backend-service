using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface ITelematicsDataAccess
{
    Task<Telematics?> GetByIdAsync(long id);
    Task<PagedResponse<Telematics>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<Telematics> CreateAsync(Telematics entity);
    Task<bool> UpdateAsync(Telematics entity);
    Task<bool> DeleteAsync(long id);
    Task<bool> CreateBatchAsync(IEnumerable<Telematics> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicatesAsync(List<string> nameToCheck, CancellationToken ct);
    Task<Telematics?> GetByDeviceIdAsync(string deviceId, CancellationToken ct);
}
