using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IVesselBerthingDataAccess
{
    Task<PagedResponse<VesselBerthing>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<VesselBerthing?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<VesselBerthing> CreateAsync(VesselBerthing entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(VesselBerthing entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<VesselBerthing> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicatesAsync(List<long> IdToCheck, CancellationToken ct);
    Task<long> GetCountByVesselVisitId(long vesselVisitId, CancellationToken ct = default);
}
