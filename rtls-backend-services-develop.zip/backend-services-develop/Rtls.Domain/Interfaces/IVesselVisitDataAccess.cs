using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IVesselVisitDataAccess
{
    Task<PagedResponse<VesselVisit>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<VesselVisit?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<VesselVisit> CreateAsync(VesselVisit entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(VesselVisit entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<List<VesselVisit>> GetByIdsAsync(int skip, int take, HashSet<long> ids, List<String> visitPhases, CancellationToken ct = default);
    Task<List<VesselVisit>> GetAllByVisitPhaseAsync(int skip, int take, List<String> visitPhases, string search, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<VesselVisit> entities, CancellationToken ct = default);
    Task<List<string>> CheckDuplicatesAsync(List<string> nameToCheck, CancellationToken ct);
    Task<int> GetAllCount(CancellationToken ct = default);
    Task<List<VesselVisit>> GetActiveVesselVisitsAsync(CancellationToken ct);
    Task<List<VesselVisit>> GetActiveVesselVisitsByVesselIdsAsync(HashSet<long> vesselIds, CancellationToken ct = default);
    Task<List<string>> GetVesselVisitByVesselId(long vesselId, CancellationToken ct = default);
}
