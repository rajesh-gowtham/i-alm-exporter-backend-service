using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IPowAssignmentDataAccess
{
    Task<PagedResponse<PowAssignment>> GetAllAsync(int skip, int? take, CancellationToken ct = default);
    Task<PowAssignment?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<PowAssignment> CreateAsync(PowAssignment entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(PowAssignment entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<PowAssignment> entities, CancellationToken ct = default);
}
