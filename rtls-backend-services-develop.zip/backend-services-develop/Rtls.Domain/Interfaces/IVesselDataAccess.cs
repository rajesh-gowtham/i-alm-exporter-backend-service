using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

/// <summary>
/// Interface for Vessel data access operations
/// </summary>
public interface IVesselDataAccess
{
    /// <summary>
    /// Gets a vessel by its ID
    /// </summary>
    /// <param name="id">The vessel ID</param>
    /// <returns>The vessel if found, null otherwise</returns>
    Task<Vessel?> GetByIdAsync(long id, CancellationToken ct = default);
    
    /// <summary>
    /// Gets all vessels with pagination
    /// </summary>
    /// <param name="skip">Number of records to skip</param>
    /// <param name="take">Number of records to take, null for all</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>A paged response containing vessels</returns>
    Task<PagedResponse<Vessel>> GetAllAsync(int skip = 0, int? take = null, string search = "", CancellationToken ct = default);
    
    /// <summary>
    /// Creates a new vessel
    /// </summary>
    /// <param name="vessel">The vessel to create</param>
    /// <returns>The created vessel</returns>
    Task<Vessel> CreateAsync(Vessel vessel, CancellationToken ct = default);
    
    /// <summary>
    /// Updates an existing vessel
    /// </summary>
    /// <param name="vessel">The vessel to update</param>
    /// <returns>True if successful, false otherwise</returns>
    Task<bool> UpdateAsync(Vessel vessel, CancellationToken ct = default);
    
    /// <summary>
    /// Deletes a vessel by its ID
    /// </summary>
    /// <param name="id">The ID of the vessel to delete</param>
    /// <returns>True if successful, false otherwise</returns>
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);

    Task<bool> CreateBatchAsync(IEnumerable<Vessel> vessels, CancellationToken ct = default);
    Task<Dictionary<string, List<string>>> CheckDuplicatesAsync(Dictionary<string, List<string>> check, CancellationToken ct = default);
}