using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IRfidLevelTemplateValuesDataAccess
{
    Task<bool> CreateAsync(RfidLevelTemplateValues entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(RfidLevelTemplateValues entity, CancellationToken ct = default);
    Task<int> GetCountByNameAsync(string name, CancellationToken ct = default);
    Task<RfidLevelTemplateValues> GetByLTVIdAsync(long id, CancellationToken ct = default);
}
