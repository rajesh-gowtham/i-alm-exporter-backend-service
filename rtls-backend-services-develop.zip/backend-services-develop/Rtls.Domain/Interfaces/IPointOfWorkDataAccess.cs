using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IPointOfWorkDataAccess
{
    Task<PagedResponse<PointOfWork>> GetAllAsync(int skip, int? take, string search, CancellationToken ct = default);
    Task<PointOfWork?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<PointOfWork> CreateAsync(PointOfWork entity, CancellationToken ct = default);
    Task<bool> UpdateAsync(PointOfWork entity, CancellationToken ct = default);
    Task<bool> DeleteAsync(long id, CancellationToken ct = default);
    Task<bool> CreateBatchAsync(IEnumerable<PointOfWork> entities, CancellationToken ct = default);
    Task<List<string>> CheckNameDuplicates(List<string> namesToCheck, CancellationToken ct = default);
    Task<List<string>> CheckPoolDuplicates(List<string> namesToCheck, CancellationToken ct = default);
}
