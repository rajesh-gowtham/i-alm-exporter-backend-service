using Rtls.Domain.Entities;
using Rtls.Domain.Models;

namespace Rtls.Domain.Interfaces;

public interface IAlarmsEventsDataAccess
{
    Task<AlarmsEvents> CreateAsync(AlarmsEvents entity, CancellationToken ct = default);
    Task<bool> FindHatchRemoval(List<string> workQueues, long vesselVisitId, CancellationToken ct = default);
    Task<List<AlarmsEvents>> GetByVesselVisit(long vesselVisitId, string eventName, CancellationToken ct = default);
    Task<PagedResponse<AlarmsEvents>> GetByVesselVisitIds(List<long> vesselVisitIds, string eventName, int skip, int? take, CancellationToken ct = default);
    Task<long> GetByCountAsync(List<long> vesselVisitIds, string eventName, CancellationToken ct = default);
    Task<bool> ClearAsync(List<long> workQueueIds, CancellationToken ct = default);
}
