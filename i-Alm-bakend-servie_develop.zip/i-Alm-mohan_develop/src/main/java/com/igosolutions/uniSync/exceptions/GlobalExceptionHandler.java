package com.igosolutions.uniSync.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.igosolutions.uniSync.Modal.ALMServerErrorResponse;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(ALMServerException.class)
    public ResponseEntity<ALMServerErrorResponse> handleALMServerException(ALMServerException ex) {
        ALMServerErrorResponse response = new ALMServerErrorResponse();
        if (ex.getMessage().contains("401")) {
            response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            response.setError("Unauthorized");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
        else if (ex.getMessage().contains("403")) {
            response.setStatusCode(HttpStatus.FORBIDDEN.value());
            response.setError("Forbidden");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }
        else {
            response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setError("ALM Server Error");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ALMServerErrorResponse> handleGenericException(Exception ex) {
        ALMServerErrorResponse response = new ALMServerErrorResponse();
        response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        response.setError("Internal Server Error");
        response.setMessage(ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
