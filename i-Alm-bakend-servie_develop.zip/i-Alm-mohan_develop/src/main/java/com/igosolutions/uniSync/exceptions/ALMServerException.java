package com.igosolutions.uniSync.exceptions;

public class ALMServerException extends RuntimeException{
    public ALMServerException(String message){
        super(message);
    }
}
