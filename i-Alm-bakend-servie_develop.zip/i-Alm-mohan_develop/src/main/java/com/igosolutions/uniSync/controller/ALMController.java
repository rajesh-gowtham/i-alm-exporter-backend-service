package com.igosolutions.uniSync.controller;

import java.io.IOException;

import java.net.MalformedURLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Service.ALMService;

@RestController
public class ALMController {

    private static final Logger logger = LoggerFactory.getLogger(ALMController.class);

    @Autowired
    private ALMService almService;

    @CrossOrigin(origins = "*")
    @GetMapping("/alm/fetchTestFolders/{domain}/{project}")
    public ResponseEntity<List<Map<String, Object>>> fetchTestFolders(
            @PathVariable String domain, @PathVariable String project, @RequestHeader Map<String, String> headers) throws Exception {

        logger.info("Received request to fetch test folders for domain: {} and project: {}", domain, project);

       
            // Delegate logic to the service layer
            List<Map<String, Object>> response = almService.fetchTestFolders(domain, project, headers);
            logger.info("Response received successfully from ALM API.");
            return ResponseEntity.ok(response);
      
        
        
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/alm/fetchTestFolders/{domain}/{project}/{testFolderId}")
    public ResponseEntity<List<Map<String, Object>>> fetchTestFoldersWithId(
            @PathVariable String domain, @PathVariable String project, @PathVariable long testFolderId,
            @RequestBody DataSource dataSource) {

        logger.info("Received request to fetch test folders for domain: {} and project: {}", domain, project);

        try {
            // Delegate logic to the service layer
            List<Map<String, Object>> response = almService.fetchTestFoldersWithId(domain, project, dataSource,
                    testFolderId);
            logger.info("Response received successfully from ALM API.");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error occurred while fetching test folders: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } finally {
            logger.info("Request to fetch test folders completed.");
        }
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/alm/authentication")
    public ResponseEntity<?> defectToolAuthentication(@RequestBody DataSource authmodal) throws Exception {
        logger.info("Starting ALM authentication for URL: {}", authmodal.getUrl());

            // Delegate the authentication logic to the service layer
            Map<String, String> responseBody = almService.defectToolAuthentication(authmodal);
            return ResponseEntity.ok(responseBody);
        
         
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/getDomainData", method = RequestMethod.GET)
    public List<Object> getDomainData(@RequestHeader Map<String, String> headers)
            throws Exception {
        List<Object> domaindata = new LinkedList<Object>();
        try {
            domaindata = almService.getAllDomain(headers);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        // LogFile.LogWrite("getDomainData xsrfHeaderValue is" + xsrfHeaderValue);
        return domaindata;
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/getProjectByDomain/{domainname}", method = RequestMethod.GET)
    public List<Object> getAllProject(@PathVariable(name = "domainname", required = false) String domainname,
            @RequestHeader Map<String, String> headers)
            throws Exception {

        try {
            return almService.getAllProjectsForDomain(domainname, headers);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

    }
}
