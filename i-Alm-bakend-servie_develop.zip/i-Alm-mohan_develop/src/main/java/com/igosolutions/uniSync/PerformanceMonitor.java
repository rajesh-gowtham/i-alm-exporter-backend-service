package com.igosolutions.uniSync;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class PerformanceMonitor {

	private static final Logger logger = LoggerFactory.getLogger(PerformanceMonitor.class);
	
	@Around("execution (* com.igosolutions.uniSync.controller..*(..))")
	public Object monitorTime(ProceedingJoinPoint jp) throws Throwable {
		
		long start = System.currentTimeMillis();
		
		Object obj = jp.proceed();
		
		long end = System.currentTimeMillis();
		
		logger.info("Time taken to execute " + jp.getSignature().getName()+ " :"+ (end-start) + "ms");
		
		return obj;
		
	}
}
