package com.igosolutions.uniSync;

public class Debugging {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		
		if(a == 10) {
			b=30;
			System.out.println(b);
		}
		else {
			System.out.println(b);
		}
	}
}
