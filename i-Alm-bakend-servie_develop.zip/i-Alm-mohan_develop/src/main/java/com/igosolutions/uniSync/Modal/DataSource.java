package com.igosolutions.uniSync.Modal;

public class DataSource {
	    private Long id;
	private String url;
	private String username;
	private String password;
	private String domainname;
	private String projectname;
	private String datasourcename;
	private String defectTool;
	private String modulename;
	private String techniciankey;
	
    
	public DataSource() {
		
	}
	
	@Override
	public String toString() {
		return "DataSource [id=" + id + ", url=" + url + ", username=" + username + ", password=" + password
				+ ", domainname=" + domainname + ", projectname=" + projectname + ", datasourcename=" + datasourcename
				+ ", defectTool=" + defectTool + ", modulename=" + modulename + ", techniciankey=" + techniciankey
				+ "]";
	}
	
	public String getModulename() {
		return modulename;
	}
	public void setModulename(String modulename) {
		this.modulename = modulename;
	}
	public String getDatasourcename() {
		return datasourcename;
	}

	public void setDatasourcename(String datasourcename) {
		this.datasourcename = datasourcename;
	}

	public String getDefectTool() {
		return defectTool;
	}

	public void setDefectTool(String defectTool) {
		this.defectTool = defectTool;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDomainname() {
		return domainname;
	}

	public void setDomainname(String domainname) {
		this.domainname = domainname;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}


	public String getTechniciankey() {
		return techniciankey;
	}


	public void setTechniciankey(String techniciankey) {
		this.techniciankey = techniciankey;
	}
}
