package com.igosolutions.uniSync.Service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;

import com.igosolutions.uniSync.Modal.DataSource;

public interface ALMService {

	// Map<String, Object> callAlmApi(String apiUrl, String xsrfHeaderValue, String lwssoCookie) throws IOException;
	
	public HttpURLConnection isValidUser(DataSource authmodal) throws IOException, Exception;
	
	public Map<String,String> generateXSRFTOKEN(HttpURLConnection authConnection, String almURL)
			throws MalformedURLException, IOException;
	
	// public Map<String, Object> GetDesignStepsMap(String url, String domainname, String projectname,
	// 		String xsrfHeaderValue, String lwssoCookie);

	List<Map<String, Object>> fetchTestFolders(String domain, String project,  Map<String, String> headers) throws Exception;
	
	List<Map<String, Object>> fetchTestFoldersWithId(String domain, String project, DataSource dataSource, long testFolderId) throws Exception;

	Map<String, String> defectToolAuthentication(DataSource authmodal) throws IOException, Exception;

	List<Object> getAllDomain( Map<String, String> headers) throws IOException, Exception;

	List<Object> getAllProjectsForDomain(String domainname, Map<String, String> headers)throws Exception;
}
