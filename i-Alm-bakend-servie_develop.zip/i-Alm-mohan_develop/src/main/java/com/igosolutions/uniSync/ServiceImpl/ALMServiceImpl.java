package com.igosolutions.uniSync.ServiceImpl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Service.ALMService;
import com.igosolutions.uniSync.controller.LogFile;
import com.igosolutions.uniSync.exceptions.ALMServerException;
import com.igosolutions.uniSync.utils.HeaderUtil;
import java.nio.charset.StandardCharsets;

@Service
public class ALMServiceImpl implements ALMService {

	public static String Client_ALM_URL = null;
	public static String Client_ALM_USERNAME = null;
	public static String Client_ALM_PASSWORD = null;

	public static String lwssoCookie = "";
	public static String cookies;
	public static String xsrfHeaderValue = "";
	public List<Object> projectData = new LinkedList<>();
	String almURL = "";

	private static final Logger logger = LoggerFactory.getLogger(ALMServiceImpl.class);

	@Override
	public List<Map<String, Object>> fetchTestFolders(String domain, String project, Map<String, String> headers)
			throws Exception {
		try {
			String lwssoCookie = HeaderUtil.getLwssoCookie(headers);
			String xsrfHeaderValue = HeaderUtil.getXsrfHeaderValue(headers);
			String almHostedUrl = HeaderUtil.getAlmHostedUrl(headers);
			String cookies = HeaderUtil.getCookies(headers);
			String almUrl = almHostedUrl + "/qcbin";
			String folderUrl = almUrl + "/rest/domains/" + domain + "/projects/" + project
					+ "/test-folders?page-size=max";
			String testUrl = almUrl + "/rest/domains/" + domain + "/projects/" + project + "/tests?page-size=max";

			logger.info("Constructed URLs: folderUrl = {}, testUrl = {}", folderUrl, testUrl);

			// HttpURLConnection connection = isValidUser(dataSource);
			// Map<String, String> headerAndCookie = generateXSRFTOKEN(connection, almUrl);
			// xsrfHeaderValue = headerAndCookie.get("xsrfHeaderValue");
			// lwssoCookie = headerAndCookie.get("lwssoCookie");

			// Fetch data from ALM API
			Map<String, Object> folderResponse = callAlmApi(folderUrl, xsrfHeaderValue, lwssoCookie, cookies);
			Map<String, Object> testResponse = callAlmApi(testUrl, xsrfHeaderValue, lwssoCookie, cookies);
			Map<String, Object> designStepsResponse = GetDesignStepsMap(almHostedUrl, domain, project,
					xsrfHeaderValue, lwssoCookie, cookies);

			List<Map<String, Object>> response = new ArrayList<>();
			Map<String, Object> map1 = new HashMap<>();
			map1.put("TestFolders", folderResponse);
			response.add(map1);

			Map<String, Object> map2 = new HashMap<>();
			map2.put("TestCase", testResponse);
			response.add(map2);

			Map<String, Object> map3 = new HashMap<>();
			map3.put("DesignSteps", designStepsResponse);
			response.add(map3);

			return response;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public Map<String, String> defectToolAuthentication(DataSource authmodal) throws Exception {
		logger.info("Authenticating ALM user for URL: {}", authmodal.getUrl());
		try {

			HttpURLConnection authConnection = isValidUser(authmodal);
			Map<String, String> headerAndCookie = generateXSRFTOKEN(authConnection, authmodal.getUrl() + "/qcbin");
			xsrfHeaderValue = headerAndCookie.get("xsrfHeaderValue");
			lwssoCookie = headerAndCookie.get("lwssoCookie");
			String cookies = headerAndCookie.get("cookies");
			if (authConnection.getResponseCode() == 200) {
				logger.info("Authentication successful.");
				Map<String, String> authResponse = new HashMap<>();
				authResponse.put("xsrfheadervalue", xsrfHeaderValue);
				authResponse.put("lwssocookie", lwssoCookie);
				authResponse.put("responseMessage", authConnection.getResponseMessage());
				authResponse.put("cookies", cookies);
				return authResponse;
			} else {
				logger.error("Authentication failed with response code: {}", authConnection.getResponseCode());
				throw new IOException("Authentication failed: " + authConnection.getResponseMessage());
			}
		}
		 catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> callAlmApi(String apiUrl, String xsrfHeaderValue, String lwssoCookie, String cookies)
			throws IOException {
		try {
			URL url = new URL(apiUrl);
			System.out.println("Cookie " + cookies + lwssoCookie);
			System.out.println("X-XSRF-TOKEN " + xsrfHeaderValue);
			System.out.println("lwssoCookie " + lwssoCookie);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Cookie", cookies + lwssoCookie);
			connection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.connect();

			int responseCode = connection.getResponseCode();
			logger.info("Response code and message in ALM API call: {}", responseCode + ":" + connection.getResponseMessage());
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
				// BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuilder response = new StringBuilder();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// Parse the JSON response to a Map
				ObjectMapper objectMapper = new ObjectMapper();
				return objectMapper.readValue(response.toString(), Map.class); // Return as Map
			} else {
				throw new ALMServerException("Failed to fetch data: HTTP code " + responseCode + ":" + connection.getResponseMessage());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public HttpURLConnection isValidUser(DataSource authmodal) throws Exception {
		HttpURLConnection authConnection = null;
		try {
		almURL = authmodal.getUrl() + "/qcbin";
		String authEndPoint = almURL + "/authentication-point/alm-authenticate";
		URL authUrl = new URL(authEndPoint);
		 authConnection = (HttpURLConnection) authUrl.openConnection();

		

			authConnection.setRequestMethod("POST");
			authConnection.setRequestProperty("Content-Type", "application/xml");
			authConnection.setDoOutput(true);
			OutputStream os = authConnection.getOutputStream();
			try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
				osw.write("<alm-authentication><user>" + authmodal.getUsername() + "</user><password>"
						+ authmodal.getPassword() + "</password></alm-authentication>");
			}
			authConnection.connect();
			Client_ALM_URL = authmodal.getUrl();
			Client_ALM_USERNAME = authmodal.getUsername();
			Client_ALM_PASSWORD = authmodal.getPassword();
			System.out.println("Response Code for ALM authentication "+authConnection.getResponseCode());
			if (authConnection.getResponseCode() == 200) {
				return authConnection;
			}
			else{
				throw new ALMServerException("Authentication failed: " + authConnection.getResponseMessage() +" Error code: "+authConnection.getResponseCode());
			}
			
			

		}
		 catch (Exception ex) {
			LogFile.LogWrite("Data Source Controller - Error isValidUser func:" + ex);
	
			throw ex;

		}
		finally{
			if (authConnection != null) {
				authConnection.disconnect();
			}
			
		}

		
	}

	public Map<String, String> generateXSRFTOKEN(HttpURLConnection authConnection, String almURL)
			throws MalformedURLException, IOException, ALMServerException {

		String qcSessionEndPoint = almURL + "/rest/site-session";
		LogFile.LogWrite("Data Source Controller - qcSessionEndPoint" + qcSessionEndPoint);
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Data Source Controller - the lwss cokkies" + lwssoCookie);
		/* create session begin */
		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		String xsrfHeaderValue = "";
		if (cookies != null) {
			cookies = null;
		}
		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			 cookies = cookies + content + ";";
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}
		LogFile.LogWrite("Data Source Controller - the header value is" + xsrfHeaderValue);
		logger.info("Response code and message in create Session call: {}", createSession.getResponseCode() + ":"
				+ createSession.getResponseMessage());
		if (createSession.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
			throw new ALMServerException("Failed to create session: HTTP code " + createSession.getResponseCode() + ":"
					+ createSession.getResponseMessage());
			
		}		
		createSession.disconnect();
		Map<String, String> map = new HashMap<String, String>();
		map.put("lwssoCookie", lwssoCookie);
		map.put("xsrfHeaderValue", xsrfHeaderValue);
		map.put("cookies", cookies);
		return map;
	}

	// public Map<String, Object> GetDesignStepsMap(String url, String domainname,
	// String projectname,
	// String xsrfHeaderValue, String lwssoCookie, String startIndex) {
	// HttpURLConnection connection = null;
	// BufferedReader reader = null;
	// try {
	// URL apiUrl = new URL(
	// url + "/qcbin/rest/domains/" + domainname + "/projects/" + projectname
	// + "/design-steps?page-size=2000&start-index="+startIndex);
	// connection = (HttpURLConnection) apiUrl.openConnection();
	// connection.setRequestMethod("GET");
	// connection.setRequestProperty("Cookie", cookies + lwssoCookie);
	// connection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
	// connection.setRequestProperty("Content-Type", "application/JSON");
	// connection.setRequestProperty("Accept", "application/JSON");
	// connection.connect();
	// logger.info("DESIGN STEPS LOG " + apiUrl.toString() + " " +
	// apiUrl.getQuery());

	// // Use BufferedReader to read the response
	// InputStream inputStream = new
	// BufferedInputStream(connection.getInputStream());
	// reader = new BufferedReader(new InputStreamReader(inputStream));
	// StringBuilder response = new StringBuilder();
	// String line;
	// int count = 0;
	// while ((line = reader.readLine()) != null) {
	// response.append(line);
	// logger.info("line" + line);
	// count++;
	// }
	// logger.info(count + " design steps fetched");

	// // Log the response
	// // LogFile.LogWrite("BPMN DESIGN STEPS result1<><> :" + response.toString());

	// // Use ObjectMapper to convert the JSON string to a Map
	// ObjectMapper objectMapper = new ObjectMapper();
	// logger.info(response.toString());
	// return objectMapper.readValue(response.toString(), Map.class);
	// } catch (Exception ex) {
	// // LogFile.LogWrite("BPMN GetDesignSteps Exception :" + ex.getMessage());
	// return null; // Or handle the error as needed
	// } finally {
	// if (reader != null) {
	// try {
	// reader.close();
	// } catch (IOException e) {
	// // LogFile.LogWrite("Error closing reader: " + e.getMessage());
	// }
	// }
	// if (connection != null) {
	// connection.disconnect();
	// }
	// }
	// }

	public Map<String, Object> GetDesignStepsMap(String url, String domainname, String projectname,
			String xsrfHeaderValue, String lwssoCookie, String cookies) throws Exception {
		HttpURLConnection connection = null;
		BufferedReader reader = null;
		Map<String, Object> finalResult = new HashMap<>();
		List<Map<String, Object>> allEntities = new ArrayList<>();
		int totalResults = 0;
		int pageSize = 2000;
		int startIndex = 1;

		try {
			do {
				URL apiUrl = new URL(
						url + "/qcbin/rest/domains/" + domainname + "/projects/" + projectname
								+ "/design-steps?page-size=" + pageSize + "&start-index=" + startIndex);

				connection = (HttpURLConnection) apiUrl.openConnection();
				connection.setRequestMethod("GET");
				connection.setRequestProperty("Cookie", cookies + lwssoCookie);
				connection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
				connection.setRequestProperty("Content-Type", "application/JSON");
				connection.setRequestProperty("Accept", "application/JSON");
				connection.connect();

				logger.info("DESIGN STEPS LOG " + apiUrl.getPath() + "  " + apiUrl.getQuery());

				// Use BufferedReader to read the response
				InputStream inputStream = new BufferedInputStream(connection.getInputStream());
				reader = new BufferedReader(new InputStreamReader(inputStream));
				StringBuilder response = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					response.append(line);
				}
				// Use ObjectMapper to convert the JSON string to a Map
				ObjectMapper objectMapper = new ObjectMapper();
				@SuppressWarnings("unchecked")
				Map<String, Object> responseMap = objectMapper.readValue(response.toString(), Map.class);

				// Extract entities and append them to allEntities list
				@SuppressWarnings("unchecked")
				List<Map<String, Object>> entities = (List<Map<String, Object>>) responseMap.get("entities");
				if (entities != null) {
					allEntities.addAll(entities);
				}

				// Extract the totalResults to determine whether we need more requests
				totalResults = (int) responseMap.get("TotalResults");
				logger.info("Total Results: " + totalResults);
				logger.info("Current Fetched Entities: " + allEntities.size());

				// Increment startIndex for the next page of results
				startIndex += pageSize;

			} while (allEntities.size() < totalResults); // Stop when we have fetched all entities
			logger.info("Reponse code and response message in getDesignSteps "+connection.getResponseCode() + " " + connection.getResponseMessage());
			if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new ALMServerException("Failed to fetch data: HTTP code " + connection.getResponseCode() + ": " + connection.getResponseMessage());
				
			} else {
				// Add all entities to the final result map
				finalResult.put("entities", allEntities);
				finalResult.put("TotalResults", totalResults);

				return finalResult;
			}

			
		} catch (Exception ex) {
			Map<String, Object> result = new HashMap<>();
			logger.error("Exception while fetching design steps: " + ex.getMessage());
			ex.printStackTrace();
			result.put("error", ex.getMessage());
			throw ex; // Or handle the error as needed
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
				if (connection != null) {
					connection.disconnect();
				}
			} catch (IOException e) {
				logger.error("Error closing resources: " + e.getMessage());
				throw e;
			}
		}
	}

	@Override
	public List<Object> getAllDomain(Map<String, String> headers) throws Exception {
		try {
			String lwssoCookie = HeaderUtil.getLwssoCookie(headers);
			String xsrfHeaderValue = HeaderUtil.getXsrfHeaderValue(headers);
			String almHostedUrl = HeaderUtil.getAlmHostedUrl(headers);
			String cookies = HeaderUtil.getCookies(headers);
			String listAllDomainURL = almHostedUrl + "/qcbin/api/domains";
			HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllDomainURL).openConnection();
			createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
			createSession1.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
			createSession1.setRequestProperty("Content-Type", "application/json");
			createSession1.setRequestProperty("Accept", "application/json");
			createSession1.setRequestMethod("GET");
			createSession1.connect();
			InputStream in = new BufferedInputStream(createSession1.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}
			createSession1.disconnect();
			// Updated By Mubarak Ali M
			if (!lwssoCookie.isEmpty()) {
			}
			String jsonstring = result.toString();
			List<Object> domainData = new LinkedList<Object>();
			JSONObject jsonobject = new JSONObject(jsonstring);
			JSONArray jsarray = jsonobject.getJSONArray("results");
			// JSONObject data=(object)result;
			for (int i = 0; i < jsarray.length(); i++) {
				JSONObject objects = jsarray.getJSONObject(i);
				domainData.add(objects.get("name"));
			}
			logger.info("Response Code and Response Message in getAllDomainData API " + createSession1.getResponseCode()
					+ " " + createSession1.getResponseMessage());
			if (createSession1.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new ALMServerException(
						"Failed to fetch data: HTTP code " + createSession1.getResponseCode() + ": "
								+ createSession1.getResponseMessage());
			}
			return domainData;
		} catch (Exception e) {
			logger.error("Exception while fetching getAllDomainData: " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public List<Map<String, Object>> fetchTestFoldersWithId(String domain, String project, DataSource dataSource,
			long testFolderId)
			throws Exception {

		String almUrl = dataSource.getUrl() + "/qcbin";
		String testUrl = almUrl + "/rest/domains/" + domain + "/projects/" + project + "/tests?query={test-folder-id%3D"
				+ testFolderId + "}";

		logger.info("Constructed URLs:  testUrl = {}", testUrl);

		// HttpURLConnection connection = isValidUser(dataSource);
		// Map<String, String> headerAndCookie = generateXSRFTOKEN(connection, almUrl);
		// String xsrfHeaderValue = headerAndCookie.get("xsrfHeaderValue");
		// String lwssoCookie = headerAndCookie.get("lwssoCookie");

		// Fetch data from ALM API
		// Map<String, Object> testResponse = callAlmApi(testUrl, xsrfHeaderValue, lwssoCookie);
		// Map<String, Object> designStepsResponse =
		// GetDesignStepsMap(dataSource.getUrl(), domain, project, xsrfHeaderValue,
		// lwssoCookie);

		List<Map<String, Object>> response = new ArrayList<>();
		// response.add(Map.of("TestCase", testResponse));
		// response.add(Map.of("DesignSteps", designStepsResponse));

		return response;

	}

	@Override
	public List<Object> getAllProjectsForDomain(String domainname, Map<String, String> headers) throws Exception {
		try {
			String lwssoCookie = HeaderUtil.getLwssoCookie(headers);
		String xsrfHeaderValue = HeaderUtil.getXsrfHeaderValue(headers);
		String almURL = HeaderUtil.getAlmHostedUrl(headers);
		String cookies = HeaderUtil.getCookies(headers);
		String listAllProjectsInDomain = almURL + "/qcbin/api/domains/" + domainname + "/projects";
		LogFile.LogWrite("/domain/getProject/ - almURL" + almURL);
		// Getting the Access Data through headers

		HttpURLConnection getProjectsConnection = (HttpURLConnection) new URL(listAllProjectsInDomain).openConnection();
		LogFile.LogWrite("getProject lwssoCookie is" + lwssoCookie);
		LogFile.LogWrite("getProject xsrfHeaderValue is" + xsrfHeaderValue);
		getProjectsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		getProjectsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		// getProjectsConnection.setRequestProperty("Content-Type", "application/json");
		getProjectsConnection.setRequestProperty("Accept", "application/json");
		getProjectsConnection.setRequestMethod("GET");
		getProjectsConnection.connect();
		LogFile.LogWrite("/domain/getProject/ - getProjectsConnection CONNECTED");
		LogFile.LogWrite("/domain/getProject/ - getProjectsConnection.getInputStream()"
				+ getProjectsConnection.getInputStream().toString());
		InputStream in1 = new BufferedInputStream(getProjectsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
		StringBuilder result1 = new StringBuilder();
		String line1;

		try {
			while ((line1 = reader1.readLine()) != null) {
				result1.append(line1);
			}

		} catch (Exception ex) {
			LogFile.LogWrite("/domain/getProject/ - getProjectsConnection Exception" + ex.getMessage());
			getProjectsConnection.disconnect();
			throw ex;
		}

		getProjectsConnection.disconnect();
		String jsonstring = result1.toString();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		projectData = new LinkedList<>();
		// if (!lwssoCookie.isEmpty()) {
		// lwssoCookie = "";
		// cookies = "";
		// xsrfHeaderValue = "";
		// }
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			projectData.add(objects.get("name"));
			// LogFile.LogWrite(objects.get("name"));
		}
		logger.info("Response Code and Response Message in GetProjects for Domain API: " + getProjectsConnection.getResponseCode() + ": "
				+ getProjectsConnection.getResponseMessage());
		if (getProjectsConnection.getResponseCode() != HttpURLConnection.HTTP_OK) {
			throw new ALMServerException("Failed to fetch data: HTTP code " + getProjectsConnection.getResponseCode() + ": "
					+ getProjectsConnection.getResponseMessage());
		}
		return projectData;
		}catch (Exception ex) {
			throw ex;
		}
		
	}

}
