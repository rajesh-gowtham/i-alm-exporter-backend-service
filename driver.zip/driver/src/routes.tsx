import LoginPage from "@/app/login/login-page";
import {
  Gauge,
  LucideProps
} from "lucide-react";
import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
} from "react-router";

import Profile from "@/app/profile/profile";
import VmtMaster from "./app/vmtScreen/vmt-master";

export const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route index path="/" element={<VmtMaster />} />
      <Route path="/login" element={<LoginPage />} />
      <Route index path="/profile" element={<Profile />} />
    </>
  )
);

export interface RouteItem {
  title: string;
  url: string;
  icon: React.ForwardRefExoticComponent<
    Omit<LucideProps, "ref"> & React.RefAttributes<SVGSVGElement>
  >;
  subItems?: RouteItem[];
}

export const routesList: RouteItem[] = [
  {
    title: "Dashboard",
    url: "/",
    icon: Gauge,
  },

];
