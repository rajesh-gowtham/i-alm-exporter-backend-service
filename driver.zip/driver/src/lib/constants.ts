export const Env = {
  ApiUrl: import.meta.env.VITE_API_URL,
  GoogleMapsUrl: import.meta.env.VITE_GOOGLE_MAPS_KEY,
  PocketBaseUrl: import.meta.env.VITE_POCKET_BASE_URL,
  PocketBaseToken: import.meta.env.VITE_POCKET_BASE_TOKEN,
};

export const ReadableDateFormat = "DD-MMM-YYYY, hh:mm A";
export const ReadableDateFormatSeconds = "DD-MM-YYYY HH:mm:ss A";
