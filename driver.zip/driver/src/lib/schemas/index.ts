import { z } from 'zod';

const optionalMeta = {
  createdBy: z.string().nullable().optional(),
  updatedBy: z.string().nullable().optional(),
  createdAt: z.string().nullable().optional(),
  updatedAt: z.string().nullable().optional()
};

const optionalId = {
  id: z.number().optional()
};

export const vesselSchema = z.object({
  ...optionalId,
  vesselName: z.string().min(1, "Vessel name is required"),
  overallLength: z.number().min(1, "Overall length is required"),
  lordsIdentity: z.string().min(1, "Lloyds identity is required"),
  vesselClass: z.string().min(1, "Vessel class is required"),
  radioCallSign: z.string().min(1, "Radio call sign is required"),
  operator: z.string().min(1, "Operator is required"),
  status: z.boolean().optional(),
  ...optionalMeta
});

export const VesselVisitSchema = z.object({
  ...optionalId,
  vesselClass: z.string().min(1, "Vessel Class is required"),
  inboundVoyage: z.string().min(1, "Inbound Voyage is required"),
  outboundVoyage: z.string().min(1, "Outbound Voyage is required"),
  vesselVisitPhase: z.string().min(1, "Vessel Visit Phase is required"),
  lineOperator: z.string().min(1, "Operator is required"),
  eta: z.string().min(1, "eta is required"),
  etd: z.string().min(1, "etd is required"),
  vesselId: z.number().min(1, "Select a Vessel"),
  ...optionalMeta
});

export const VesselBerthingSchema = z.object({
  ...optionalId,
  sequence: z.number().min(1, "Sequence is required"),
  quay: z.string().min(1, "Quay is required"),
  berthingSide: z.string().min(1, "Berthing Side is required"),
  berthEta: z.string().min(1, "ETA is required"),
  berthEtd: z.string().min(1, "ETD is required"),
  berthAta: z.string().min(1, "ATA is required"),
  startWorkTime: z.string().min(1, "Start Work Time is required"),
  bollard: z.string().min(1, "Bollard is required"),
  bollardFore: z.number().min(1, "BollardFore is required"),
  bollardAft: z.number().min(1, "BollardAft is required"),
  vesselVisitId: z.number().min(1, "Vessel Visit is required"),
  ...optionalMeta
});

export const EquipmentSchema = z.object({
  ...optionalId,
  equipmentName: z.string().min(1, "Equipment Name Visit is required"),
  equipmentType: z.string().min(1, "Equipment Type Visit is required"),
  maxWeight: z.number().min(1, "Max Weight Visit is required"),
  maxTeu: z.number().min(1, "MaxTeu is required"),
  ...optionalMeta
});


export const EquipmentPoolSchema = z.object({
  ...optionalId,
  poolName: z.string().min(1, "Pool Name is required"),
  dispatchState: z.string().min(1, "Dispatch State is required"),
  operatingMode: z.string().min(1, "Operating Mode is required"),
  jobStartPosition: z.string().min(1, "Job Start Position is required"),
  equipmentId: z.number().min(1, "EquipmentId is required"),
  ...optionalMeta
});

export const PointofWorkSchema = z.object({
  ...optionalId,
  name: z.string().min(1, "Name is required"),
  status: z.boolean().optional(),
  ...optionalMeta
});


export const WorkInstructionSchema = z.object({
  ...optionalId,
  vesselVisitId: z.number().min(1, "Vessel Visit is required"),
  moveType: z.string().min(1, "Move type is required"),
  equipmentId: z.number().min(1, "Equipment is required"),
  fromLocation: z.string().min(1, "From Location is required"),
  toLocation: z.string().min(1, "To Location is required"),
  dispatchState: z.string().min(1, "Dispatch State is required"),
  equipmentType: z.string().min(1, "Equipement type is required"),
  assignedChe: z.string().min(1, "Assigned CHE is required"),
  assignedLane: z.string().min(1, "Assigned Lane is required"),
  cheCarry: z.string().min(1, "CHE Carry is required"),
  currentPosition: z.string().min(1, "Current Position is required"),
  positionOnCarriage: z.string().min(1, "Position On Carriage is required"),
  blockId: z.string().min(1, "Block is required"),
  bayId: z.string().min(1, "Bay is required"),
  powId: z.number().min(1, "POW is required"),
  containerId: z.number().min(1, "Container Id is required"),
  containerName: z.string().min(1, "Container Name is required"),
  ...optionalMeta
});

export const PowAssignmentSchema = z.object({
  ...optionalId,
  powId: z.number().min(1, "POW is required"),
  equipmentPoolId: z.number().min(1, "Equipment Pool is required"),
  equipmentPoolStatus: z.boolean(),
  ...optionalMeta
});

export const EquipmentPoolAssignmentSchema = z.object({
  ...optionalId,
  equipmentPoolId: z.number().min(1, "Equipment Pool is required"),
  equipmentId: z.number().min(1, "Equipment is required"),
  assignmentStatus: z.boolean(),
  equipmentAssignedDate: z.string().min(1, "Assigned Date is required"),
  ...optionalMeta
});