// Common Interfaces
export interface BaseEntity {
  id: number | string;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaginatedResponse<T> {
  totalCount: number;
  items: T[];
}

// Vessel Interface
export interface Vessel extends BaseEntity {
  vesselName: string;
  overallLength: number;
  lordsIdentity: string;
  vesselClass: string;
  radioCallSign: string;
  operator: string;
  status: boolean | undefined;
}

// Vessel Visit Interface
export interface VesselVisit extends BaseEntity {
  vesselClass: string;
  inboundVoyage: string;
  outboundVoyage: string;
  vesselVisitPhase: string;
  lineOperator: string;
  eta: Date | string;
  etd: Date | string;
  vesselId: number;
  vessel?: Vessel;
}

// Vessel Berthing Interface
export interface VesselBerthing extends BaseEntity {
  sequence: number;
  quay: string;
  berthingSide: string;
  berthEta: Date | string;
  berthEtd: Date | string;
  berthAta: Date | string;
  startWorkTime: Date | string;
  bollard: string;
  bollardFore: number;
  bollardAft: number;
  vesselVisitId: number;
  vesselVisit?: VesselVisit;
}

// Equipment Interface
export interface Equipment extends BaseEntity {
  equipmentName: string;
  equipmentType: string;
  maxWeight: number;
  maxTeu: number;
  status?: boolean;
}

// Equipment Pool Interface
export interface EquipmentPool extends BaseEntity {
  poolName: string;
  dispatchState: string;
  operatingMode: string;
  jobStartPosition: string;
  equipmentId: number;
  equipment?: Equipment;
}

// Point of Work Interface
export interface PointofWork extends BaseEntity {
  name: string;
  status?: boolean;
}

// Work Instruction Interface
export interface WorkInstruction extends BaseEntity {
  vesselVisitId: number;
  moveType: string;
  equipmentId: number;
  fromLocation: string;
  toLocation: string;
  dispatchState: string;
  equipmentType: string;
  assignedChe: string;
  assignedLane: string;
  cheCarry: string;
  currentPosition: string;
  positionOnCarriage: string;
  blockId: string;
  bayId: string;
  powId: number;
  containerId: number;
  containerName: string;
  vesselVisit?: VesselVisit;
  equipment?: Equipment;
  pointofwork?: PointofWork;
}

// POW Assignment Interface
export interface PowAssignment extends BaseEntity {
  powId: number;
  equipmentPoolId: number;
  equipmentPoolStatus: boolean;
  pointofwork: PointofWork;
  equipmentPool: EquipmentPool;
}

// Equipment Pool Assignment Interface
export interface EquipmentPoolAssignment extends BaseEntity {
  equipmentPoolId: number;
  equipmentId: number;
  assignmentStatus: boolean;
  equipmentAssignedDate: string;
  equipmentPool: EquipmentPool;
  equipment: Equipment;
}

export type AuthResponse = {
  tokenType: string;
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
  jobStatus: JobStatus;
};


export interface ContainerYardInventory {
  id?: string;
  created?: Date;
  updated?: Date;
  containerId: string;
  equipmentType: string;
  category: string;
  transitState: number;
  position: number;
  lineOperator: string;
  inboundActualVisit: string;
  outboundActualVisit: string;
  portOfDischarge: string;
  freightKind: string;
  lastMove: Date;
}


export interface PoolDetails {
  powName: string;
  poolName: string;
}
export type requestBody = {
  userId: string;
  cheId: string;

}
export type JobDetail = {
  containerId: string;
  iso: string;
  weight: number;
  type: string;
  posOnChassis: string;
};

export type JobStatus = {
  status: string;
  userId: string;
  cheId: string;
  instruction: string;
  jobDetails: JobDetail[];
  singleDischTwinCarry:boolean;
  rfidMessage:string;
};


// Paginated Interfaces
export type PaginatedVesselResponse = PaginatedResponse<Vessel>;
export type PaginatedVesselVisitResponse = PaginatedResponse<VesselVisit>;
export type PaginatedVesselBerthingResponse = PaginatedResponse<VesselBerthing>;
export type PaginatedEquipmentResponse = PaginatedResponse<Equipment>;
export type PaginatedEquipmentPoolResponse = PaginatedResponse<EquipmentPool>;
export type PaginatedPointOfWorkResponse = PaginatedResponse<PointofWork>;
export type PaginatedWorkInstructionResponse = PaginatedResponse<WorkInstruction>;
export type PaginatedPowAssignmentResponse = PaginatedResponse<PowAssignment>;
export type PaginatedEquipmentPoolAssignmentResponse = PaginatedResponse<EquipmentPoolAssignment>;

export enum RouteSegmentType {
  ParkingToSTS01 = "ParkingToSTS01",
  ParkingToSTS02 = "ParkingToSTS02",
  STS01ToYard = "STS01ToYard",
  STS02ToYard = "STS02ToYard",
  YardToParkingLane1 = "YardToParkingLane1",
  YardToParkingLane2 = "YardToParkingLane2",
  YardToSTS01 = "YardToSTS01",
  YardToSTS02 = "YardToSTS02",
}

/*
 public const string YET_TO_START = "Yet to Start";
        public const string DISPATCHED = "Dispatched";
        public const string CANCELLED = "Cancelled";
        public const string ARRIVE_TO_ORIGIN = "Arrive to Origin";
        public const string ARRIVED_AT_ORIGIN = "Arrived at Origin";
        public const string ARRIVE_TO_DESTINATION = "Arrive to Destination";
        public const string ARRIVED_AT_BLOCK = "Arrived at Block";
        public const string ARRIVED_AT_DESTINATION = "Arrived at Destination";
        public const string COMPLETED = "Completed";
        public const string SUSPENDED = "Suspended";
        public const string WAITING_PICKUP = "Waiting Pickup";
        public const string WAITING_DROP = "Waiting Drop";

*/

export enum EquipmentJobStatus {
    YET_TO_START = "YET_TO_START",
    DISPATCHED = "DISPATCHED",
    CANCELLED = "CANCELLED",
    ARRIVE_TO_ORIGIN = "ARRIVE_TO_ORIGIN",
    ARRIVED_AT_ORIGIN = "ARRIVED_AT_ORIGIN",
    ARRIVE_TO_DESTINATION = "ARRIVE_TO_DESTINATION",
    ARRIVED_AT_BLOCK = "ARRIVED_AT_BLOCK",
    ARRIVED_AT_DESTINATION = "ARRIVED_AT_DESTINATION",
    COMPLETED = "COMPLETED",
    SUSPENDED = "SUSPENDED",
    WAITING_PICKUP = "WAITING_PICKUP",    
    WAITING_DROP = "WAITING_DROP",

}



export interface EquipmentState {
    equipmentId: number;
    equipmentName: string;
    equipmentType: string;
    status: string;
    message: string;
    gpsTime: Date;
    latitude: number;
    longitude: number;
    altitude: number;
    heading: number;
    parameters: Record<string, any>;
    routeSegment: RouteSegmentType | null;
    jobStatus:  string | null;
  }