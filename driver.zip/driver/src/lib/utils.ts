import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { formatInTimeZone, fromZonedTime } from "date-fns-tz";
import { differenceInDays, differenceInHours, differenceInMinutes, formatISO, parseISO } from "date-fns";

const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Convert minutes into readable duratiojn format (0 D 0 H 0 M) */
export function minutesToHumanReadable(value: number) {
  const [days, hours, minutes] = fromMinutes(value);
  return `${days}d ${hours}h ${minutes}m`;
}

export function getFormattedTimeInDays(value: number) {
  return `${Math.floor(value / 1440)}`;
}

export const toApiDateFormat = (date: Date) => {
  return fromZonedTime(date, timeZone)
  // return formatISO(date, { representation: 'complete' })
};

export const toApiQueryDateOnly = (date: Date) => {
  return formatISO(date, { representation: 'complete' })
};

export const fromMinutes = (
  value: number
): [days: number, hours: number, minutes: number] => {
  const days = Math.floor(value / 1440);
  const hours = Math.floor((value - days * 1440) / 60);
  const minutes = value - days * 1440 - hours * 60;
  return [days, hours, minutes];
};

export function camelCaseToNormal(str: string) {
  const normalString = str.replace(/([A-Z])/g, " $1").trim();
  return normalString.replace(/(?:^|\s)\S/g, (char) => char.toUpperCase());
}

export function capitalize(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}


export function convertTime(date: Date | string | null | undefined) {
  console.log(date, "date")
  if (date) {
    // Format date in local time zone
    return formatInTimeZone(date, timeZone, "yyyy-MM-dd HH:mm:ss");
  }

  return "N/A";
};

export function getDifferenceBetweenTwoDates(value: string, value2: string) {
  const fromTime = parseISO(value);
  const toTime = parseISO(value2);

  const TTdiffDurationMin = Math.max(differenceInMinutes(toTime, fromTime) % 60, 0);
  const TTdiffDurationHrs = Math.max(differenceInHours(toTime, fromTime) % 24, 0);
  const TTdiffDurationDays = Math.max(differenceInDays(toTime, fromTime), 0);

  return `${TTdiffDurationDays} D ${TTdiffDurationHrs} H ${TTdiffDurationMin} M`;
}