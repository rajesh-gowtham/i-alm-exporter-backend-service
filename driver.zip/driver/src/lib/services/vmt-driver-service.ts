// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { JobStatus, PaginatedEquipmentResponse, requestBody } from '../models';

export async function fetchEquipments(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedEquipmentResponse> {

  const equipments = await axiosInstance.get<PaginatedEquipmentResponse>("/equipment", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip, take, filter, sort, search, searchFields, expand,
    },
  });
  if (equipments.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;

}


export async function vmtFetchTriggerAPICALL(req: requestBody, action: string): Promise<JobStatus> {
  const actionKey = action === 'Available' ? action :"";
  // console.log("Payload ", req, action);

  const response = await axiosInstance.post<JobStatus>("/vmt/job?action=" + actionKey, req, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  // console.log(response)
  if (response.status !== 200) {
    throw new Error("Failed to add data");
  }
  return response.data;

}

export async function logOutAPICALL(req: requestBody): Promise<JobStatus> {

  const response = await axiosInstance.post<JobStatus>("/vmt/logout", req, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  return response.data;

}