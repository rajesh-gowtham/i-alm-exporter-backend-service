import { create } from "zustand";
import { JobStatus } from "../models";

type AuthState = {
    isAuthorized: boolean;
    token: string | null;
};

type Actions = {
    getIsAuthorized: () => boolean;
    getToken: () => string | null;
    logIn: (cheId: string, userId: string, data: JobStatus) => void;
    logout: () => void;
};

const initialState: AuthState = {
    isAuthorized: false,
    token: null,
};

const useAuthStore = create<AuthState & Actions>()((set, get) => ({
    // state
    ...initialState,
    // actions
    getIsAuthorized() {
        return get().isAuthorized
            ? true
            : localStorage.getItem("isAuthorized") === "true";
    },
    getToken() {
        return get().token || localStorage.getItem("token");
    },
    logIn(cheId, userId, data) {
        localStorage.setItem("isAuthorized", "true");
        localStorage.setItem("cheId", cheId);
        localStorage.setItem("userId", userId);
        localStorage.setItem("data", JSON.stringify(data));
        set({ isAuthorized: true });
    },
    logout() {
        localStorage.removeItem("isAuthorized");
        localStorage.removeItem("token");
        localStorage.removeItem("cheId");
        localStorage.removeItem("userId");
        localStorage.removeItem("data")
        set({ isAuthorized: false, token: null });
    },
}));

export default useAuthStore;
