import { LoginForm } from "@/components/login-form";

export default function LoginPage() {
  return (
    <div className="bg-white dark:bg-black">
      <LoginForm />
    </div>
  );
}
