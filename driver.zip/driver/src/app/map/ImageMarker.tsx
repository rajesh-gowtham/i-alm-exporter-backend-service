// ImageMarker.tsx
import React from "react";
import { RMarker } from "maplibre-react-components";
import arrow from "@/data/geojsonnew/arrow.png";
interface ImageMarkerProps {
  equipmentId: string;
  longitude: number;
  latitude: number;
  imageSrc: string;
  altText: string;
  className?: string;
  rotation?: number;
  size: number;
}

const ImageMarker: React.FC<ImageMarkerProps> = ({ equipmentId, longitude, latitude, imageSrc, altText, className, rotation, size }) => {
  const { width, height } = size;
  console.log('imageWidth', width, 'imageHeight', height)
  return (
    <div key={equipmentId}>
      <RMarker longitude={longitude} latitude={latitude} draggable={false} >
        {/* <img key={equipmentId} src={imageSrc} alt={altText} className={className}  style={{
          width: `${width}px`,
          height: `${height}px`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          pointerEvents: "none",
        }} /> */}
      
        <div className="relative flex items-center justify-center w-4 h-4">
  {/* Base Circle */}
  {/* <div className="w-full h-full bg-[#FFA500] rounded-full z-10"></div> */}
  <img src={imageSrc} alt="arrow" className="w-4 h-4 rotate-60" />

  {/* Outer Ping (larger and centered) */}
  
   {/* Beacon Ring 1 */}
  <div className="absolute w-5 h-5 rounded-full border border-[#1e3a8a] opacity-75 animate-ping z-0"></div>

  {/* Beacon Ring 2 with delay */}
  <div className="absolute w-5 h-5 rounded-full border border-[#1e3a8a] opacity-50 animate-ping z-0 [animation-delay:0.5s]"></div>

  {/* Beacon Ring 3 with more delay */}
  <div className="absolute w-5 h-5 rounded-full border border-[#1e3a8a] opacity-25 animate-ping z-0 [animation-delay:1s]"></div>

</div>
      </RMarker>
    </div>
  );
};

export default ImageMarker;