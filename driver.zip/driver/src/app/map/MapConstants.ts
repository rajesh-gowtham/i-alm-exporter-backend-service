export const containerColorMap = {
  "Damaged containers": ["#8cb750"],
  "ODC Cargo": ["#FFAC1C"],

  "Empty": ["#95b94d", "#a0c34f", "#adcd4f", "#c0d74b", "#cdde52"],
  "Future Reefer": ["#dbe74d", "#eff54b", "#ffff4f", "#fdff48", "#fdf64d",  "#fdf64d",  "#fdf64d", "transparent"],
  "Hazardous Cargo": ["#ffe647", "#ffd94e", "#ffcf4e", "#fec14c", "#cb973c"],
  "Reefer Pre Trip Inspection": ["#dbe74d", "#eff54b", "#ffff4f", "#fdff48", "#fdf64d"],

  default: "#FFFFFF",
};


// Constants
export const INITIAL_CENTER: [number, number] = [76.9974, 8.3702];
export const INITIAL_ZOOM = 16;
export const INITIAL_MIN_ZOOM =1;
export const INITIAL_MAX_ZOOM=24;
export const MODIFIED_MIN_ZOOM = 18;
export const INITIAL_BEARING = 230.7852;
export const BASE64_PATTERN =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAG0lEQVQoU2NkYGBg+A8EHjIwMDC8B4oFAAw9AwiC5i02AAAAAElFTkSuQmCC";


export const YardCranes = [
    { id: 'CRMG-E01', yard:"1E", longitude: 76.9970, latitude: 8.3727 },
    { id: 'CRMG-E02', yard:"1E", longitude: 76.9961, latitude: 8.3738 },
    
  ];
 export  const QuayCranes = [
    { id: 'STS01', longitude: 76.995625, latitude: 8.369885 },
    { id: 'STS02', longitude: 76.9961, latitude: 8.3693 },

  ];

  export const ITVSData = [
    { id: 'T001', longitude: 76.996284117636733, latitude: 8.373240026063501, bearing: 0, LAYER: "L to R"  }, // Added bearing for rotation
    { id: 'T002', longitude: 76.996279, latitude: 8.374311, bearing: 0, LAYER: "L to R" },
    { id: 'T003', longitude: 76.996279, latitude: 8.374311, bearing: 0, LAYER: "L to R" },
    { id: 'TT104', longitude: 76.995859817180744,  latitude: 8.372795996344021, bearing: 0 , LAYER: "R to L" },

  ];


  export const iconLayout = {
    'icon-image':  [
      'match',
        ['get', 'LAYER'],
          'D to U', "itvL2R",
          'U to D', "itvL2R",
          'L to R', "itvL2R",
          'R to L', "itvR2L",
        "itvL2R" // default bearing if none match
          // 'itv-marker'
    ],
    'icon-size': [
      'interpolate',
      ['linear'],
      ['zoom'],
      16, 0.4,
      18, 0.8,
      19, 1,
      20, 1.25,
      21, 1.8,
      22, 2
    ],
    'icon-anchor': 'center',
    // 'icon-rotate': ['get', 'bearing']
    'icon-rotate': [
      'match',
        ['get', 'LAYER'],
          'D to U', -90,
          'U to D', 90,
          'L to R', 0,
          'R to L', 0,
        0 // default bearing if none match
    ],
    'icon-overlap': 'always',
  };


  export const VITE_GOOGLE_MAPS_KEY = "AIzaSyDuajCHEOAmY9-N1dFx4phFJq_nOYd6gGw";
  export interface EquipmentState {
    equipmentId: number;
    equipmentName: string;
    equipmentType: string;
    status: string;
    message: string;
    gpsTime: Date;
    latitude: number;
    longitude: number;
    altitude: number;
    heading: number;
    parameters: Record<string, any>;
  }