import React from "react";
import ImageMarker from "./ImageMarker";
import {
  easeInOutQuad,
  useSmoothRotation,
  useUltraSmooth,
} from "./Markers/hooks";

interface EnhancedAnimatedMarkerProps {
  equipmentId: number;
  image: string;
  rotation: number;
  size: {
    width: number;
    height: number;
  };
  targetLat: number;
  targetLng: number;
}

const EnhancedAnimatedMarker: React.FC<EnhancedAnimatedMarkerProps> = ({
  equipmentId,
  image,
  rotation: targetRotation, // Renamed for clarity: this is the *final* rotation
  size,
  targetLat,
  targetLng,
}) => {
  const [lng, lat] = useUltraSmooth([targetLng, targetLat], 500);
  // const currentRotation = useSmoothRotationNew(targetRotation, 6, "bezier");
  const currentRotation = useSmoothRotation(targetRotation, {
    duration: 1500,
    easing: easeInOutQuad,
    threshold: 0.5,
  });

  console.log('enancsize', size);

  return (
    <ImageMarker
      equipmentId={equipmentId}
      longitude={lng}
      latitude={lat}
      imageSrc={image}
      altText={`Equipment ${equipmentId}`}
      className="custom-marker"
      rotation={currentRotation} // Use the interpolated rotation
      size={size}
    />
  );
};

export default EnhancedAnimatedMarker;
