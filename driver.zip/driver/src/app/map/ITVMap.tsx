// ITVMap.tsx
import { useEffect, useState, useRef } from "react";
import {
  RMap,
  RMapContextProvider,
  RMarker} from "maplibre-react-components";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  googleProtocol,
  createGoogleStyle
} from "maplibre-google-maps";
import * as turf from "@turf/turf";

import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_DeepYellow.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-Yellow.png";
import RFIDICON from "@/data/geojsonnew/wifi.png";
import WIFIICON from "@/data/geojsonnew/network.png";

// Routes
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";

// Components
import ContainerYard from "@/data/geojsonnew/container_yards.json";
import ContainerYardCentroids from "@/data/geojsonnew/container_yards_point.json";
import Road from "@/data/geojsonnew/road_v1.json";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import DividerLayer from "./Layers/DividerLayer";
import TruckTraffic from "@/data/geojsonnew/truck_traffic_polygon.json";


import RoutesLayer from "./Layers/RoutesLayer";

import {
  INITIAL_CENTER,
  INITIAL_BEARING,
  INITIAL_MAX_ZOOM, 
  INITIAL_MIN_ZOOM,
  iconLayout,
  INITIAL_ZOOM} from "./MapConstants";
import { loadSpriteImgs, getEquipmentMarkerImageByDirection, calculateBearing, createLineGeoJsonByDirectionChange, sortGeoJsonByTime } from "./MapUtils";
import GeoJsonLayer from "./GeoJsonLayer";

import useSWR from "swr";
import {fetchEquipmentStateByName} from "@/lib/services/map-services";
import { AnimatedMarker } from "./AnimatedMarker";
import { RouteSegmentType } from "@/lib/models";
import HatchedAreaLayer from "./Layers/HatchedArea";
import RFIDLayer from "./Layers/RFIDLayer";
import { calculateBearingToNorth } from "@/hooks/useBearing";
import EnhancedAnimatedMarker from "./EnhancedRouteFollowingMarker";

maplibregl.addProtocol("google", googleProtocol);

export default function ITVMap() {
  const [bearing, setBearing] = useState(INITIAL_BEARING);
// Returns bearing in degrees to face north from that position
  const [initialCoord, setInitialCoord] = useState(INITIAL_CENTER);
  const [showBaseMap, setShowBaseMap] = useState(false);
  const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);
  const [RouteingJson, setRouteingJson] = useState({});
  const [equipmentStateMessage, setEquipmentMessage] = useState("");
  const mapRef = useRef<any>(null);
  const id = localStorage.getItem("cheId") ?? ""; // This should be dynamically set based on your application logic
  
  const { data: equipmentData } =  useSWR(id ? `/equipment/${id}/state` : null, () => fetchEquipmentStateByName(id!), 
     {
      refreshInterval: 500,
      dedupingInterval: 0, // turn off dedupe throttling
      revalidateOnFocus: false, // disable focus-triggered revalidations
      refreshWhenHidden: false, // pause polling when tab is hidden
    }
    );

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleZoom = () => {
      setMapZoom(map.getZoom());
    };

    map.on("zoom", handleZoom);

    return () => {
      map.off("zoom", handleZoom);
    };
  }, []);
    useEffect(() => {
    if (!equipmentData || !mapRef.current) {
      setRouteingJson({});
      return;
    }

    let FollowRoute = null;
    switch (equipmentData.routeSegment) {
      case RouteSegmentType.ParkingToSTS01:
        FollowRoute = RouteParkingToLane1;
        break;
      case RouteSegmentType.ParkingToSTS02:
        FollowRoute = RouteParkingToLane2;
        break;
      case RouteSegmentType.STS01ToYard:
        FollowRoute = RouteLane1ToBlock1EW;
        break;
      case RouteSegmentType.STS02ToYard:
        FollowRoute = RouteLate2ToBlock1EW;
        break;
      case RouteSegmentType.YardToParkingLane1:
        FollowRoute = RouteBlock1EWToParking;
        break;
      case RouteSegmentType.YardToParkingLane2:
        FollowRoute = RouteBlock1EWToParking2;
        break;
      case RouteSegmentType.YardToSTS01:
        FollowRoute = Route1EBlockToLane1;
        break;
      case RouteSegmentType.YardToSTS02:
        FollowRoute = Route1EBlockToLane2;
    }

    if (!FollowRoute) {
      setRouteingJson({});
      return;
    }

   
    

FollowRoute = createLineGeoJsonByDirectionChange(sortGeoJsonByTime(FollowRoute as GeoJSON.FeatureCollection));
const equipmentPoint = turf.point([equipmentData.longitude, equipmentData.latitude]);
let nearestCoordIdx = 0;
let minDistance = Infinity;

// Flatten all coordinates from all LineStrings
const allCoords: number[][] = [];

FollowRoute.features.forEach((feature) => {
  if (feature.geometry.type === "LineString") {
    allCoords.push(...feature.geometry.coordinates);
  }
});

// Find the nearest coordinate
allCoords.forEach((coord, index) => {
  const point = turf.point(coord);
  const distance = turf.distance(equipmentPoint, point, { units: "meters" });

  if (distance < minDistance) {
    minDistance = distance;
    nearestCoordIdx = index;
  }
});

// Trim coordinates from nearest index
const trimmedCoords = allCoords.slice(nearestCoordIdx);
// const trimmedCoords = allCoords;
// Safely create LineString if enough points
if (trimmedCoords.length >= 2) {
  const updatedRoute = turf.featureCollection([
    turf.lineString(trimmedCoords)
  ]);
  setRouteingJson(updatedRoute);
} else {
  console.warn("Not enough points to form a LineString");
  setRouteingJson(null); // or handle appropriately
}
    const [lng, lat] = initialCoord;
    setBearing(calculateBearing(lat, lng, equipmentData.latitude, equipmentData.longitude));
    console.log('bearing',bearing);
    setInitialCoord([equipmentData.longitude, equipmentData.latitude]);
     mapRef.current.easeTo({
      center: [equipmentData.longitude, equipmentData.latitude],
      bearing: bearing , // Animate bearing
      pitch: 0, // Animate pitch (if you had a dynamic pitch)
      zoom: 18, // Animate zoom (if you had a dynamic zoom)
      duration: 500 // Duration for the easeTo animation
    });
     // 500ms duration for smooth pan

    /*  mapRef.current.jumpTo({
      center: [equipmentData.longitude, equipmentData.latitude],
      // zoom: 18,
      duration: 500,
      // bearing: bearing + 50.7852,
      // bearing: 90 + INITIAL_BEARING
    }); */
if(equipmentData.message !== equipmentStateMessage){
      setEquipmentMessage(equipmentData.message);
    }
    
  }, [equipmentData]);
  
    const getMarkerSize = (zoom: number) => {
      const baseWidth = 45; // width at zoom 16
      const baseHeight = 14; // maintains original image aspect ratio
      const scale =
        zoom <= 17
          ? 1 + (zoom - 17) * 0.3 // zoom 16 → 1.0, zoom 17 → 1.3
          : 1.3 + (zoom - 17) * 0.6; // zoom 18 → 1.9, zoom 19 → 2.5, zoom 20 → 3.1
      const clampedScale = Math.min(scale, 3); // prevent excessive size at high zoom
      return {
        width: baseWidth * clampedScale,
        height: baseHeight * clampedScale,
      }; // scales between 12px and 48px
  };

  
  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs('quay-crane', QuayCraneImg, 150, 380, map);
      loadSpriteImgs('single-side-yard-crane', SingleSideYardCarneImg, 40, 205, map);
      loadSpriteImgs('double-side-yard-crane', DoubleSideYardCraneImg, 40, 225, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
    });
  }, []);

  return(
    <> 
      <RMapContextProvider>
            <div className="relative">
              
              <RMap
                ref={mapRef}
                style={{
                  width: "100%",
                  minHeight: "500px",
                  height: "100%",
                  backgroundColor: showBaseMap ? "transparent" : "white"
                }}
                mapStyle={
                  showBaseMap
                    ? createGoogleStyle("google", "satilite", "AIzaSyBiurjht6cC9wpq3EbU9TIMNxE9cGiafqQ")
                    : {
                        version: 8,
                        sources: {},
                        layers: [],
                        glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf"
                      }
                }
                initialCenter={INITIAL_CENTER}
                initialZoom={18}
                initialAttributionControl={false}
                initialBearing={INITIAL_BEARING}
                initialPitch={0}
                dragRotate={false}
                touchZoomRotate={false}
                initialCanvasContextAttributes={{
                  antialias: true,
                }}
              >
               
                  <GeoJsonLayer
                      id="ContainerYard"
                      data={ContainerYard}
                      minzoom={INITIAL_MIN_ZOOM}
                      maxzoom={INITIAL_MAX_ZOOM}
                      type="fill"
                      paint={{
                          "fill-outline-color": "#5f5f5f",
                          "fill-color": "#5f5f5f",
                          "fill-opacity": 0.1
                      }}
                  />
                <GeoJsonLayer
                      id="Road"
                      data={Road}
                      minzoom={INITIAL_MIN_ZOOM}
                      maxzoom={INITIAL_MAX_ZOOM}
                      type="line"
                      paint={{
                          "line-color": [
                              "match",
                              ["get", "LAYER"],
                              "Centerline", "transparent",
                              "Service Lane", "transparent",
                              "centre line truck traffic", "transparent",
                              "#c2d1fa"
                          ],
                          "line-width": 1
                      }}
                      filter={["in", ["get", "LAYER"], ["literal", ["MA_ROAD MARKING", "MA_ROAD"]]]}
                  />
                <RFIDLayer />
                <DividerLayer />
                
                <HatchedAreaLayer />
               <GeoJsonLayer
                      id="ContainerYardLabel"
                      data={ContainerYardCentroids}
                      minzoom={INITIAL_MIN_ZOOM}
                      maxzoom={INITIAL_MAX_ZOOM}
                      type="symbol"
                      layout={{
                          "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                          "text-size":[
                      "interpolate",
                      ["linear"],
                      ["zoom"],
                      14,10,
                      16,12,   // Medium size at zoom 18
                      18,14,
                      20,16,
                      21,18,
                      22, 20      // Large size at zoom 22+
                    ],
                          "text-anchor": "center",
                          "text-justify": "center",
                          "text-offset": [0, 0],
                          "symbol-placement": "point",
                          "symbol-avoid-edges": true,
                          "symbol-sort-key": ["get", "ID"],
                          "symbol-spacing": 1000,
                          "symbol-z-order": "source",
                          "text-overlap": "always",
                         "text-rotate":  INITIAL_BEARING,
                    'text-rotation-alignment': 'map',
                    'text-pitch-alignment': 'map',
                          
                      }}
                      paint={{
                          "text-color": "#000000",
                          "text-halo-color": "#ffffff",
                          "text-halo-width": 2,
                          "text-halo-blur": 0.5,
                      }}
                  />
                  <RoutesLayer data={RouteingJson} />

            {equipmentData && (
               (() => {
                 const markerSize = getMarkerSize(mapZoom);
                 console.log('markerSize', markerSize);
                 const { image, rotation } = getEquipmentMarkerImageByDirection(
                   equipmentData
                 );

                 return (
                   <EnhancedAnimatedMarker
                     key={equipmentData.equipmentId}
                     equipmentId={equipmentData.equipmentId}
                     image={image}
                     rotation={rotation}
                     size={markerSize}
                     targetLat={equipmentData.latitude}
                     targetLng={equipmentData.longitude}
                   />
                 ); 
                 /* return (
                  <RMarker longitude={equipmentData.longitude} latitude={equipmentData.latitude} draggable={false}  rotation={rotation}>
                    <div className="relative flex items-center justify-center w-4 h-4">
                      <div className={`absolute w-full h-full bg-[#1e3a8a] rounded-full opacity-100 animate-ping`} ></div>
                    </div>
                  </RMarker>
                 ) */
               })()
            )}
              

           
                
                <YardCranesLayer bearing={bearing}  />
                
                 <QuayCrane bearing={bearing} />
               
              </RMap>
            </div>
          </RMapContextProvider>
    </>
  );
}