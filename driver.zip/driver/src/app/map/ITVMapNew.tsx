// ITVMap.tsx
import { useEffect, useState, useRef, useCallback } from "react";
import {
  RMap,
  RMapContextProvider
} from "maplibre-react-components";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  googleProtocol,
  createGoogleStyle
} from "maplibre-google-maps";
import * as turf from "@turf/turf";

import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_DeepYellow.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-Yellow.png";
import RFIDICON from "@/data/geojsonnew/wifi.png";
import WIFIICON from "@/data/geojsonnew/network.png";

// Routes
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";

// Components
import ContainerYard from "@/data/geojsonnew/container_yards.json";
import ContainerYardCentroids from "@/data/geojsonnew/container_yards_point.json";
import Road from "@/data/geojsonnew/road_v1.json";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import DividerLayer from "./Layers/DividerLayer";
import TruckTraffic from "@/data/geojsonnew/truck_traffic_polygon.json";


import RoutesLayer from "./Layers/RoutesLayer";

import {
  INITIAL_CENTER,
  INITIAL_BEARING,
  INITIAL_MAX_ZOOM,
  INITIAL_MIN_ZOOM,
  iconLayout,
  INITIAL_ZOOM
} from "./MapConstants";
import { loadSpriteImgs, getEquipmentMarkerImageByDirection } from "./MapUtils";
import GeoJsonLayer from "./GeoJsonLayer";

import useSWR from "swr";
import { fetchEquipmentStateByName } from "@/lib/services/map-services";
import { AnimatedMarker } from "./AnimatedMarker";
import { RouteSegmentType } from "@/lib/models";
import HatchedAreaLayer from "./Layers/HatchedArea";
import RFIDLayer from "./Layers/RFIDLayer";
import { calculateBearingToNorth } from "@/hooks/useBearing";

maplibregl.addProtocol("google", googleProtocol);

export default function ITVMap() {
  const [bearing, setBearing] = useState(INITIAL_BEARING);
  const [showBaseMap, setShowBaseMap] = useState(false);
  const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);
  const [RouteingJson, setRouteingJson] = useState({});
  const [equipmentStateMessage, setEquipmentMessage] = useState("");
  const mapRef = useRef<maplibregl.Map | null>(null);

  // State to control the map's center, to make it follow the marker
  // Initialize mapCenter with INITIAL_CENTER, this will be the starting point
  const [mapCenter, setMapCenter] = useState(INITIAL_CENTER);
  const [mapBearing, setMapBearing] = useState(INITIAL_BEARING);
  const [mapPitch, setMapPitch] = useState(0);

  const id = localStorage.getItem("cheId") ?? "";

  const { data: equipmentData } = useSWR(id ? `/equipment/${id}/state` : null, () => fetchEquipmentStateByName(id!), {
    refreshInterval: 500,
    revalidateOnFocus: false,
  });

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleZoom = () => {
      setMapZoom(map.getZoom());
    };

    map.on("zoom", handleZoom);

    return () => {
      map.off("zoom", handleZoom);
    };
  }, []);

  // Effect to update marker position, route, and map camera
  useEffect(() => {
    if (!equipmentData || !mapRef.current) {
      setRouteingJson({});
      return;
    }

    let FollowRoute = null;
    switch (equipmentData.routeSegment) {
      case RouteSegmentType.ParkingToSTS01:
        FollowRoute = RouteParkingToLane1;
        break;
      case RouteSegmentType.ParkingToSTS02:
        FollowRoute = RouteParkingToLane2;
        break;
      case RouteSegmentType.STS01ToYard:
        FollowRoute = RouteLane1ToBlock1EW;
        break;
      case RouteSegmentType.STS02ToYard:
        FollowRoute = RouteLate2ToBlock1EW;
        break;
      case RouteSegmentType.YardToParkingLane1:
        FollowRoute = RouteBlock1EWToParking;
        break;
      case RouteSegmentType.YardToParkingLane2:
        FollowRoute = Route1EBlockToLane1;
        break;
      case RouteSegmentType.YardToSTS01:
        FollowRoute = RouteBlock1EWToParking2;
        break;
      case RouteSegmentType.YardToSTS02:
        FollowRoute = Route1EBlockToLane2;
        break;
    }

    if (!FollowRoute) {
      setRouteingJson({});
      return;
    }

    const equipmentPoint = turf.point([equipmentData.longitude, equipmentData.latitude]);
    let nearestIdx = 0;
    let minDistance = Infinity;

    FollowRoute.features.forEach((feature, index) => {
      if (feature.geometry.type !== "Point") return;

      const point = turf.point(feature.geometry.coordinates);
      const distance = turf.distance(equipmentPoint, point, { units: "meters" });

      if (distance < minDistance) {
        minDistance = distance;
        nearestIdx = index;
      }
    });

    const trimmedFeatures = FollowRoute.features.slice(nearestIdx);
    const updatedRoute = { ...FollowRoute, features: trimmedFeatures };
    setRouteingJson(updatedRoute);

    const newBearing = calculateBearingToNorth({ latitude: equipmentData.latitude, longitude: equipmentData.longitude });
    // setBearing(newBearing); // This state is for the marker rotation
    console.log('newBearing',  newBearing);
    // Update map center and bearing to follow the equipment
    // setMapCenter([equipmentData.longitude, equipmentData.latitude]);
    // setMapBearing(newBearing); // Make the map's bearing match the equipment's heading if desired
    // setMapPitch(60); // Optionally, set a pitch for a more dynamic view
 mapRef.current.panTo([equipmentData.longitude, equipmentData.latitude], { duration: 500 });
    if (equipmentData.message !== equipmentStateMessage) {
      setEquipmentMessage(equipmentData.message);
    }

  }, [equipmentData, equipmentStateMessage]);

  const getMarkerSize = (zoom: number) => {
    return Math.min(Math.max(12, zoom * 2), 48); // scales between 12px and 48px
  };

  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs('quay-crane', QuayCraneImg, 150, 380, map);
      loadSpriteImgs('single-side-yard-crane', SingleSideYardCarneImg, 40, 205, map);
      loadSpriteImgs('double-side-yard-crane', DoubleSideYardCraneImg, 40, 225, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
    });
  }, []);

  return (
    <>
      <RMapContextProvider>
        <div className="relative">
          <RMap
            ref={mapRef}
            style={{
              width: "100%",
              minHeight: "500px",
              height: "100%",
              backgroundColor: showBaseMap ? "transparent" : "white"
            }}
            mapStyle={
              showBaseMap
                ? createGoogleStyle("google", "satilite", "AIzaSyBiurjht6cC9wpq3EbU9TIMNxE9cGiafqQ")
                : {
                  version: 8,
                  sources: {},
                  layers: [],
                  glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf"
                }
            }
            // Removed initialCenter - now 'center' will control the map's position from the start
            // and react to updates from mapCenter state.
            initialZoom={18}
            initialAttributionControl={false}
            initialCenter={mapCenter}
            initialBearing={INITIAL_BEARING}
            initialPitch={mapPitch}
            dragRotate={false}
            touchZoomRotate={false}
            initialCanvasContextAttributes={{
              antialias: true,
            }}
            // Controlled props for dynamic camera updates
            // center={mapCenter}
            // zoom={18} // You might want to make this dynamic with a state variable too
            // bearing={mapBearing}
            // pitch={mapPitch}
            // Add duration for smooth transitions, e.g., duration={500}
          >
            <GeoJsonLayer
              id="ContainerYard"
              data={ContainerYard}
              minzoom={INITIAL_MIN_ZOOM}
              maxzoom={INITIAL_MAX_ZOOM}
              type="fill"
              paint={{
                "fill-outline-color": "#5f5f5f",
                "fill-color": "#5f5f5f",
                "fill-opacity": 0.1
              }}
            />
            <GeoJsonLayer
              id="Road"
              data={Road}
              minzoom={INITIAL_MIN_ZOOM}
              maxzoom={INITIAL_MAX_ZOOM}
              type="line"
              paint={{
                "line-color": [
                  "match",
                  ["get", "LAYER"],
                  "Centerline", "transparent",
                  "Service Lane", "transparent",
                  "centre line truck traffic", "transparent",
                  "#c2d1fa"
                ],
                "line-width": 1
              }}
              filter={["in", ["get", "LAYER"], ["literal", ["MA_ROAD MARKING", "MA_ROAD"]]]}
            />
            <RFIDLayer />
            <DividerLayer />
            <HatchedAreaLayer />
            <GeoJsonLayer
              id="ContainerYardLabel"
              data={ContainerYardCentroids}
              minzoom={INITIAL_MIN_ZOOM}
              maxzoom={INITIAL_MAX_ZOOM}
              type="symbol"
              layout={{
                "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                "text-size": [
                  "interpolate",
                  ["linear"],
                  ["zoom"],
                  14, 10,
                  16, 12,
                  18, 14,
                  20, 16,
                  21, 18,
                  22, 20
                ],
                "text-anchor": "center",
                "text-justify": "center",
                "text-offset": [0, 0],
                "symbol-placement": "point",
                "symbol-avoid-edges": true,
                "symbol-sort-key": ["get", "ID"],
                "symbol-spacing": 1000,
                "symbol-z-order": "source",
                "text-overlap": "always"

              }}
              paint={{
                "text-color": "#000000",
                "text-halo-color": "#ffffff",
                "text-halo-width": 2,
                "text-halo-blur": 0.5,
              }}
            />
            <RoutesLayer data={RouteingJson} />
            {mapZoom >= 16 && equipmentData && (
              (() => {
                const singleEquipment = equipmentData;
                if (!singleEquipment) return null;

                const markerSize = getMarkerSize(mapZoom);
                const { image } = getEquipmentMarkerImageByDirection(singleEquipment);
                const markerRotation = bearing;

                return (
                  <AnimatedMarker
                    key={singleEquipment.equipmentId}
                    equipmentId={singleEquipment.equipmentId}
                    image={image}
                    rotation={markerRotation}
                    size={markerSize}
                    targetLat={singleEquipment.latitude}
                    targetLng={singleEquipment.longitude}
                  />
                );
              })()
            )}
            <QuayCrane />
            <YardCranesLayer />
          </RMap>
        </div>
      </RMapContextProvider>
    </>
  );
}
