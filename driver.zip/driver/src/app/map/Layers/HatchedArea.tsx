import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MIN_ZOOM, INITIAL_MAX_ZOOM } from "../MapConstants";
import HatchedArea from "@/data/geojsonnew/hatched_area.json";

export default function HatchedAreaLayer() {
  return (
    <GeoJsonLayer
      id="HatchedArea"
      data={HatchedArea}
      minzoom={INITIAL_MIN_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      type="fill"
      paint={{ "fill-color": "red", "fill-opacity": 0.1 }}
    />
  );
}
