import GeoJsonLayer from "../GeoJsonLayer";
import { MODIFIED_MIN_ZOOM, INITIAL_MAX_ZOOM, INITIAL_BEARING } from "../MapConstants";
import RFIDReader from "@/data/geojsonnew/rfid_wifi_pole_v1.json";


export default function RFIDLayer() {
    return (
        <>
            <GeoJsonLayer
                id="RFID"
                data={RFIDReader}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                filter={["==", ["get", "RFID"], "RF8,"]}
                layout={{
                "icon-image": [
                  "match", ["get", "name"],
                  "RFID Reader", "RFIDICON",
                  "wifi-pole", "WIFIICON",
                  "WIFIICON" // <-- Fallback icon name
                ],
                  "icon-size": [
      "interpolate",
      ["linear"],
      ["zoom"],
      16, 0.22,     // Small size at zoom 16
    17, 0.3,
      18,0.8,     // Medium size at zoom 18
      19,1.25,
      20,1.4,
      21,1.7,
      22, 1      // Large size at zoom 22+
    ],
    "icon-allow-overlap": true,
    "icon-anchor": "center",
    "icon-rotate": INITIAL_BEARING,
    "icon-overlap": "always",
    'icon-rotation-alignment': 'map',
    'icon-pitch-alignment': 'map',
  
              }}
              paint={{}}
            />
        </>
    );
}
