import { useState } from "react";
import { RPopup } from "maplibre-react-components";
import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_BEARING, INITIAL_MAX_ZOOM, INITIAL_ZOOM, QuayCranes } from "../MapConstants";

export default function QuayCrane({ active = [], showPop=false, bearing=INITIAL_BEARING }) {
    const [hoveredFeature, setHoveredFeature] = useState(null);
    const [popupCoords, setPopupCoords] = useState<[number, number] | null>(null);

    const quayCranesData = {
        type: "FeatureCollection",
        features: QuayCranes.map((crane) => ({
            type: "Feature",
            geometry: {
                type: "Point",
                coordinates: [crane.longitude, crane.latitude],
            },
            properties: {
                id: crane.id,
                isActive: active.includes(crane.id),
            },
        })),
    };

    const iconLayout = {
        "icon-image": [
            "case",
            ["boolean", ["get", "isActive"], false],
            "quay-crane-active",
            "quay-crane",
        ],
        "icon-size": [
            "interpolate",
            ["linear"],
            ["zoom"],
            16, 0.22,
            17, 0.3,
            18, 0.8,
            19, 1.25,
            20, 1.4,
            21, 1.7,
            22, 2,
        ],
        "icon-allow-overlap": true,
        "icon-anchor": "center",
        // "icon-rotate": bearing!==INITIAL_BEARING?bearing : bearing,
        "icon-rotate": INITIAL_BEARING,
        "icon-overlap": "always",
       'icon-rotation-alignment': 'map',
        'icon-pitch-alignment': 'map',
    };

    return (
        <>
            <GeoJsonLayer
                id="Quay-cranes-layer"
                data={quayCranesData}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={iconLayout}
                paint={{}}
                onHover={(e) => {
                    if(showPop){
                    if (e.features?.length > 0) {
                        const feature = e.features[0];
                        const coords = feature.geometry.coordinates;
                        setHoveredFeature(feature);
                        setPopupCoords(coords);
                    } else {
                        setHoveredFeature(null);
                        setPopupCoords(null);
                    }
                }
                }}
            />
            {hoveredFeature && popupCoords && (
                <RPopup
                    longitude={popupCoords[0]}
                    latitude={popupCoords[1]}
                    
                >
                    <button
                        className="maplibregl-popup-close-button text-lg font-bold w-5 !right-5"
                        onClick={() => {
                                    setHoveredFeature(null);
                                    setPopupCoords(null);
                                }}
                    >
                        ×
                    </button>
                    <div style={{ padding: "4px 8px" }}>
                        <div><strong>ID:</strong> {hoveredFeature.properties.id}</div>
                        <div><strong>Status:</strong> {hoveredFeature.properties.isActive ? "Active" : "Inactive"}</div>
                    </div>
                </RPopup>
            )}
        </>
    );
}
