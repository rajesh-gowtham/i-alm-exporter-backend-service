import GeoJsonLayer from "../GeoJsonLayer";
import { MODIFIED_MIN_ZOOM, INITIAL_MAX_ZOOM } from "../MapConstants";
import Platforms from "@/data/geojsonnew/platfroms.json";

export default function PlatformLayer() {
  return (
    <GeoJsonLayer
                id="Platforms"
                data={Platforms}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                  "fill-color":"#71797E", 
                  "fill-opacity": .5,
                  "fill-pattern":
                  "platform-stripe"
                }}
                beforeId="Containers-layer"
              />
  );
}