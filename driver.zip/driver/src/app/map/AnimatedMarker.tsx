import { useEffect, useRef, useState } from "react";
import { RMarker } from "maplibre-react-components";

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export function AnimatedMarker({
  equipmentId,
  image,
  rotation,
  targetLat,
  targetLng,
  size,
  duration = 1000,
}: {
  equipmentId: number;
  image: string;
  rotation: number;
  targetLat: number;
  targetLng: number;
  size: number;
  duration?: number;
}) {
  const [position, setPosition] = useState({ lat: targetLat, lng: targetLng });
  const startRef = useRef<{ lat: number; lng: number }>({ lat: targetLat, lng: targetLng });
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    const animate = (timestamp: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = timestamp;
        startRef.current = position;
      }

      const elapsed = timestamp - startTimeRef.current;
      const t = Math.min(1, elapsed / duration);

      const newLat = lerp(startRef.current.lat, targetLat, t);
      const newLng = lerp(startRef.current.lng, targetLng, t);

      setPosition({ lat: newLat, lng: newLng });

      if (t < 1) {
        requestAnimationFrame(animate);
      } else {
        startTimeRef.current = null;
      }
    };

    requestAnimationFrame(animate);
  }, [targetLat, targetLng]);

  return (
    <RMarker
      key={equipmentId}
      longitude={position.lng}
      latitude={position.lat}
      rotation={rotation}
      anchor="center"
    >
      <div
        style={{
          width: `${size}px`,
          height: `${size}px`,
          backgroundImage: `url(${image})`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          pointerEvents: "none",
        }}
      />
    </RMarker>
  );
}
