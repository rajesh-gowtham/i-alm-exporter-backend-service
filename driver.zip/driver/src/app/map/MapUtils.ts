import * as turf from '@turf/turf';
 // Adjust the import path as necessary
import {EquipmentState, RouteSegmentType } from "@/lib/models";
// Simulated mapping of RouteSegmentType to imported GeoJSONs
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";
/* import ITV from "@/data/geojsonnew/flat-bed-truck Left.png";
import ITV2 from "@/data/geojsonnew/flat-bed-truck Right.png";
import IVTL2R from "@/data/geojsonnew/itvL2R.png";
import ITVR2L from "@/data/geojsonnew/itvR2L.png";
import SITV from "@/data/geojsonnew/delivery-truck Active1.png";
import SITV2 from "@/data/geojsonnew/delivery-truck_Active.png";
*/
import ITV from "@/data/geojsonnew/arrow.png";
import IVTL2R from "@/data/geojsonnew/arroworrange.png";
import SITV from "@/data/geojsonnew/arroworrange.png";

import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";
import { INITIAL_BEARING } from './MapConstants';

interface Properties {
    [key: string]: any;
}

interface Feature {
    type: "Feature";
    geometry: any;
    properties: Properties;
}

interface FeatureCollection {
    type: string;
    features: Feature[];
}

export function getCentroidsFeatureCollection(featureCollection: FeatureCollection): FeatureCollection {
    return turf.featureCollection(
        featureCollection.features.map(feature =>
            turf.centroid(feature, { properties: feature.properties })
        )
    );
}


interface Crane {
  id: string | number;
  longitude: number;
  latitude: number;
  yard: string;
}

interface SnappedFeatureProperties {
  id: string | number;
  originalLongitude: number;
  originalLatitude: number;
  yardNo: string;
}

export function snapPointsToLine(
  points: Crane[],
  line: turf.Feature<turf.LineString> | turf.LineString,
  options: turf.NearestPointOnLineOptions = { units: 'meters' }
): turf.Feature<turf.Point, SnappedFeatureProperties>[] {
  return points.map((point) => {
    const targetPoint = turf.point([point.longitude, point.latitude]);
    const snapped = turf.nearestPointOnLine(line, targetPoint, options);

    return {
      type: 'Feature',
      geometry: snapped.geometry,
      properties: {
        id: point.id,
        originalLongitude: point.longitude,
        originalLatitude: point.latitude,
        yardNo: point.yard,
      },
    };
  });
}



export function loadSpriteImgs(
  name: string,
  imageSrc: string,
  imgWidth: number,
  imgHeight: number,
  map: maplibregl.Map | null
): void {
  if (!map || map.hasImage(name)) return;

  const image = new Image(imgWidth, imgHeight);
  image.onload = (): void => {
    map.addImage(name, image, { pixelRatio: 1, sdf: false });
  };
  image.onerror = (err) => {
    console.error(`Failed to load sprite image: ${imageSrc}`, err);
  };
  image.src = imageSrc;
}


export const routeSegmentGeoJsonMap: Record<RouteSegmentType, any> = {
  [RouteSegmentType.ParkingToSTS01]: RouteParkingToLane1,
  [RouteSegmentType.ParkingToSTS02]: RouteParkingToLane2,
  [RouteSegmentType.STS01ToYard]: RouteLane1ToBlock1EW,
  [RouteSegmentType.STS02ToYard]: RouteLate2ToBlock1EW,
  [RouteSegmentType.YardToParkingLane1]: RouteBlock1EWToParking,
  [RouteSegmentType.YardToParkingLane2]: RouteBlock1EWToParking2,
  [RouteSegmentType.YardToSTS01]: Route1EBlockToLane1,
  [RouteSegmentType.YardToSTS02]: Route1EBlockToLane2
};

export function convertToGeoJSON(equipmentList: EquipmentState[]) {
 
  return {
    type: "FeatureCollection",
    features: equipmentList.map((item) => {
      let matchedLayer = item.parameters?.LAYER ?? "L to R";
      // item.routeSegment = RouteSegmentType.ParkingToLane1;
      if (item.routeSegment && routeSegmentGeoJsonMap[item.routeSegment]) {
        const geojson = routeSegmentGeoJsonMap[item.routeSegment];
        // console.log(item.routeSegment,item.routeSegment);
        // console.log('routesegment',item);
        const point = turf.point([item.longitude, item.latitude]);
        // const point = turf.point([76.994199763873112, 8.372674922999661]);
        for (const feature of geojson.features) {
          const featureGeom = turf.getGeom(feature);
          const isMatch = turf.booleanEqual(featureGeom, point) || turf.distance(point, featureGeom, { units: "meters" }) < 1;
          
          if (isMatch && feature.properties?.Direction) {
            matchedLayer = feature.properties.Direction;
            break;
          }
        }
      }
// console.log("matchedLayer", matchedLayer);
      return {
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: [item.longitude, item.latitude],
        },
        properties: {
          equipmentId: item.equipmentId,
          equipmentName: item.equipmentName,
          equipmentType: item.equipmentType,
          status: item.status,
          message: item.message,
          gpsTime: item.gpsTime,
          altitude: item.altitude,
          heading: item.heading,
          parameters: item.parameters,
          LAYER: matchedLayer,
        },
      };
    }),
  };
}

export const EmptyRouteSegments = new Set<RouteSegmentType>([
  RouteSegmentType.ParkingToSTS01,
  RouteSegmentType.ParkingToSTS02,
  RouteSegmentType.YardToParkingLane1,
  RouteSegmentType.YardToParkingLane2,
  RouteSegmentType.YardToSTS01,
  RouteSegmentType.YardToSTS02
]);

export const ActiveRouteDirectionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: SITV, rotation: 90 },
  "U to D": { image: SITV, rotation: -90 },
  "L to R": { image: SITV, rotation: 180 },
  "R to L": { image: SITV, rotation: 0 },
};

export const EmptyRouteDirectionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: ITV, rotation: 90 },
  "U to D": { image: ITV, rotation: -90 },
  "L to R": { image: ITV, rotation: 180 },
  "R to L": { image: ITV, rotation: 180 },
};

export const directionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: IVTL2R, rotation: 90 },
  "U to D": { image: IVTL2R, rotation: -90 },
  "L to R": { image: IVTL2R, rotation: 180 },
  "R to L": { image: IVTL2R, rotation: 0 },
};

export function getEquipmentMarkerImageByDirection(equipment: {
  latitude: number;
  longitude: number;
  routeSegment: RouteSegmentType;
  equipmentName: string;
  jobStatus: string;
}): { image: string; rotation: number } {
  const routeGeoJson = routeSegmentGeoJsonMap[equipment.routeSegment];
  if (!routeGeoJson || !equipment.latitude || !equipment.longitude) {
    return { image: ITV, rotation: INITIAL_BEARING+50.753 };
  }

  const currentPoint = turf.point([equipment.longitude, equipment.latitude]);

  let nearestIdx = 0;
  let minDistance = Infinity;

  routeGeoJson.features.forEach((feature, index) => {
    if (feature.geometry.type !== "Point") return;

    const point = turf.point(feature.geometry.coordinates);
    const distance = turf.distance(currentPoint, point, { units: "meters" });

    if (distance < minDistance) {
      minDistance = distance;
      nearestIdx = index;
    }
  });

  const nearestFeature = routeGeoJson.features[nearestIdx];
  const direction = nearestFeature?.properties?.direction;
  // console.log('direction', direction);
  const configMap = equipment.jobStatus =='Completed'
    ? EmptyRouteDirectionConfigMap  
    :  !EmptyRouteSegments.has(equipment.routeSegment)
      ? ActiveRouteDirectionConfigMap
      : EmptyRouteSegments.has(equipment.routeSegment)
        ? EmptyRouteDirectionConfigMap 
        : directionConfigMap;

  return  configMap[direction] ?? { image: ITV, rotation: 0 };
}



/*
export function getEquipmentMarkerImageByDirection(equipment: {
  latitude: number;
  longitude: number;
  routeSegment: RouteSegmentType;
  equipmentName: string;
  jobStatus: string;
}, bearing: number): { image: string; rotation: number } {
  const routeGeoJson = routeSegmentGeoJsonMap[equipment.routeSegment];
  if (!routeGeoJson || !equipment.latitude || !equipment.longitude) {
    return { image: ITV, rotation: bearing };
  }

  const currentPoint = turf.point([equipment.longitude, equipment.latitude]);

  let nearestIdx = 0;
  let minDistance = Infinity;

  routeGeoJson.features.forEach((feature, index) => {
    if (feature.geometry.type !== "Point") return;

    const point = turf.point(feature.geometry.coordinates);
    const distance = turf.distance(currentPoint, point, { units: "meters" });

    if (distance < minDistance) {
      minDistance = distance;
      nearestIdx = index;
    }
  });

  const nearestFeature = routeGeoJson.features[nearestIdx];
  const direction = nearestFeature?.properties?.direction;
  // console.log('direction', direction);
 
   return getImageAndRotation(equipment, direction, bearing);
}

function getImageAndRotation(equipment : {
  latitude: number;
  longitude: number;
  routeSegment: RouteSegmentType;
  equipmentName: string;
  jobStatus: string;
}, direction: string, bearing: number): { image: string; rotation: number } {
  const config = equipment.jobStatus === 'Completed'
                  ? EmptyRouteDirectionConfigMap[direction]
                     : EmptyRouteSegments.has(equipment.routeSegment)
                        ? EmptyRouteDirectionConfigMap[direction]
                        : directionConfigMap[direction];
  if (!config) return { image: ITV, rotation: bearing };
  
  return {
    image: config.image,
    rotation: config.rotation,
  };
}
*/

/**
 * Calculates the initial bearing (forward azimuth) from one coordinate to another.
 *
 * @param lat1 - Latitude of the start point in decimal degrees.
 * @param lon1 - Longitude of the start point in decimal degrees.
 * @param lat2 - Latitude of the end point in decimal degrees.
 * @param lon2 - Longitude of the end point in decimal degrees.
 * @returns Bearing in degrees from north (0° ≤ bearing < 360°).
 */
export function calculateBearing(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  // Convert degrees to radians
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δλ = toRad(lon2 - lon1);

  // Calculate components
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x =
    Math.cos(φ1) * Math.sin(φ2) -
    Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);

  // Compute bearing
  const θ = Math.atan2(y, x);

  // Convert radians back to degrees and normalize to [0, 360)
  const toDeg = (rad: number) => (rad * 180) / Math.PI;
  return (toDeg(θ) + 360) % 360;
}




interface GeoJSONFeatureCollection {
  type: "FeatureCollection";
  features: GeoJSON.Feature[];
}

function sortGeoJsonByProperty(
  geojson: GeoJSONFeatureCollection,
  propertyName: string,
  ascending: boolean = true
): GeoJSONFeatureCollection {
  const sortedFeatures = [...geojson.features].sort((a, b) => {
    const valA = a.properties?.[propertyName];
    const valB = b.properties?.[propertyName];

    // Handle undefined/null
    if (valA == null) return 1;
    if (valB == null) return -1;

    if (valA < valB) return ascending ? -1 : 1;
    if (valA > valB) return ascending ? 1 : -1;
    return 0;
  });

  return {
    ...geojson,
    features: sortedFeatures,
  };
}



export function sortGeoJsonByTime(geojson: GeoJSON.FeatureCollection | undefined): GeoJSON.FeatureCollection {
  if (!geojson || !geojson.features || !Array.isArray(geojson.features)) {
    console.warn("Invalid GeoJSON FeatureCollection passed to sortGeoJsonByTime");
    return { type: "FeatureCollection", features: [] };
  }

  const sortedFeatures = [...geojson.features].sort((a, b) => {
    const timeA = a.properties?.time_sec ?? 0;
    const timeB = b.properties?.time_sec ?? 0;
    return timeA - timeB;
  });

  return {
    ...geojson,
    features: sortedFeatures,
  };
}


export function createLineGeoJsonByDirectionChange(geojson: GeoJSON.FeatureCollection): GeoJSON.FeatureCollection {
  if (!geojson || !geojson.features || geojson.features.length === 0) {
    return turf.featureCollection([]);
  }

  const lineFeatures: GeoJSON.Feature[] = [];
  let currentGroup: any[] = [];
  let currentDirection = geojson.features[0].properties?.direction;

  for (let i = 0; i < geojson.features.length; i++) {
    const feature = geojson.features[i];
    const direction = feature.properties?.direction;

    if (direction !== currentDirection && currentGroup.length > 1) {
      // Finalize current group as a LineString
      lineFeatures.push(
        turf.lineString(currentGroup, { direction: currentDirection })
      );
      
      // Start new group with last coordinate of previous group
      currentGroup = [currentGroup[currentGroup.length - 1]];
    }

    if (feature.geometry.type === 'Point') {
      currentGroup.push((feature.geometry as GeoJSON.Point).coordinates);
    }
    currentDirection = direction;
  }

  // Push the final group
  if (currentGroup.length > 1) {
    lineFeatures.push(
      turf.lineString(currentGroup, { direction: currentDirection })
    );
  }

  return turf.featureCollection(lineFeatures);
}