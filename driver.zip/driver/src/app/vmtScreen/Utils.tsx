import { AlertTriangle } from "lucide-react";
import truckimg from '../../assets/truck-img-3.png'
import { cn } from "@/lib/utils";
import { JobDetail } from "@/lib/models";
// import { Card, CardContent } from "@/components/ui/card";

export const AlertUI = ({ open, setOpen }: {
    open: boolean; setOpen: ((open: boolean) => void);
}) => {
    const errors = [
        "Speed Limit Exceeded",
        "Route Deviation",
        "Unauthorized Stop Detected",
        "Geofence Breach",
        "Prolonged Idle Time",
        "ETA Delay Detected",
    ]
    return (
        <div className="items-center justify-center w-full h-full p-2 ease-in-out delay-700 border border-red-700 rounded shadow-lg">
            <span className="flex justify-end ">
                <span onClick={() => { setOpen(!open) }} className="border border-black/30 rounded-full px-2 cursor-pointer hover:bg-gray-200 py-0.5">X</span>
            </span>
            <div className="flex flex-col h-full px-3 py-2 space-y-3 overflow-y-auto">
                {errors.map((err, idx) => (
                    <div
                        key={idx}
                        className="inline-flex items-center gap-1 px-3 py-2.5 bg-red-100 text-red-700 text-sm rounded-full border border-red-200"
                    >
                        <AlertTriangle className="w-3 h-3" />
                        {err}
                    </div>
                ))}
            </div>
        </div>)
}

export const RouteMapUI = () => {
    return (<div className="w-full delay-700 ease-in-out h-[60%] p-2 items-center justify-center flex ">

        {/* <img src="https://static1.makeuseofimages.com/wordpress/wp-content/uploads/2022/07/route-marked-on-a-map.jpg?q=50&fit=crop&w=1140&h=&dpr=1.5" alt="" /> */}
    </div>)
}


// const ContainerBox = ({
//     container,
// }: {
//     container: JobDetail;
// }) => {
//     const isTwentyFt = container.iso === "22G1";
//     const width = isTwentyFt ? "w-[49%]" : "w-full";
//     const cntAlignment = isTwentyFt && Number(container.posOnChassis) === 1 ? " left-0 " : "right-0"

//     if (!container.containerId) {
//         return
//     }

//     return (
//         <Card
//             className={`absolute bottom-[30%] pl-1 ${width} ${isTwentyFt ? cntAlignment : ' left-0 '} h-[60%] bg-red-800 border-red-900 border-4 rounded shadow-lg`}
//         >
//             <CardContent className="relative w-full h-full p-1">
//                 <div className="absolute inset-0 flex items-center justify-evenly">
//                     {Array.from({ length: isTwentyFt ? 6 : 10 }).map((_, i) => (
//                         <div key={i} className="w-[4px] h-full bg-red-900 opacity-40" />
//                     ))}
//                 </div>
//                 {/* <div className="absolute px-2 py-1 text-xl font-bold text-center text-blue-800 bg-white rounded shadow left-1/3">
//                     {container.containerId}
//                 </div> */}
//                 <div className="absolute top-1 right-2 border font-bold border-blue-700 text-blue-700 px-1 py-0.5 text-lg md:text-lg rounded bg-white">
//                     {container.type === "Discharge" ? "DS" : "LD"}
//                 </div>
//                 {/* <div className="absolute flex items-center justify-center w-full gap-2 px-2 py-1 text-sm font-bold text-center text-white top-1/3 text-wrap md:text-base lg:text-xl ">
//                     <span className="">{container.containerId}</span>
//                 </div> */}
//                 <div className="absolute flex items-center justify-center w-full px-2 py-1 font-bold text-white top-1/3">
//                     <span
//                         className="w-full tracking-wider text-center"
//                         style={{
//                             fontSize: 'clamp(12px, 4vw, 24px)',
//                             wordBreak: 'break-word',
//                             letterSpacing: '0.20em',
//                         }}
//                     >
//                         {container.containerId}
//                     </span>
//                 </div>


//                 <div className="absolute font-mono text-white bottom-1 left-2 text-md">
//                     {isTwentyFt ? "20'" : "40'"}
//                 </div>
//                 {/* <div className="absolute bottom-1 left-1/2 text-white text-md font-mono border border-white p-1 px-1.5 rounded-full">
//                     {container.type === "Discharge" ? "DS" : "LD"}
//                 </div> */}
//                 <div className="absolute font-mono text-white bottom-1 right-2 text-md">
//                     {` ${container.weight / 1000}T`}
//                 </div>
//             </CardContent>
//         </Card>
//     );
// };
// export const TruckWithContainers = ({ jobs }: {jobs:JobDetail[]}) => {
//     return (
//         <Card className="relative w-[50%] h-full items-center justify-center aspect-[2.5] bg-gray-200 border shadow-inner p-2">
//             {/* <div className="absolute bottom-[30%] left-0 w-[15%] h-[60%] bg-blue-800 rounded-t-2xl shadow-lg flex items-center justify-center text-white font-bold">
//                 TT04
//             </div> */}
//             <CardContent className="relative h-full">
//                 <div className="absolute bottom-[8%] left-0 w-full h-[20%] bg-blue-900 rounded-md shadow-md" />

//                 <div className="absolute bottom-0 left-[10%] w-10 h-10 rounded-full border-4 border-gray-400 bg-gray-800 shadow-inner flex items-center justify-center">
//                     {/* <div className="w-3 h-3 rounded-full bg-white" /> */}
//                 </div>
//                 <div className="absolute bottom-0 right-[10%] w-10 h-10 rounded-full border-4 border-gray-400 bg-gray-800 shadow-inner flex items-center justify-center">
//                     {/* <div className="w-3 h-3 rounded-full bg-white" /> */}
//                 </div>

//                 <div className="absolute bottom-[12%] left-[25%]  text-white items-center text-center" >
//                     <span className="text-xl font-bold">1</span>
//                 </div>
//                 <div className="absolute bottom-[12%] left-[75%]  text-white items-center text-center" >
//                     <span className="text-xl font-bold">3</span>
//                 </div>

//                 <div className=" flex h-full  ">
//                     {jobs && jobs.length > 0 && jobs.map((job) => (
//                         <ContainerBox
//                             key={job.containerId}
//                             container={job}
//                         />
//                     ))}
//                 </div>
//             </CardContent>
//         </Card>
//     );
// };




export const Container = ({ container }: { container: JobDetail; }) => {
    const isTwentyFt = container?.iso?.startsWith("2");
    
    const leftOffset = isTwentyFt && parseInt(container.posOnChassis) === 1 ? "left-[31%]" :
        (isTwentyFt && parseInt(container.posOnChassis) === 2 ? "right-[28%]" : "right-[16%]");
    if (!container.containerId) {
        return
    }
    return (
        <div
            className={cn(
                "absolute top-[18%] h-[37%] md:h-[37%] rounded shadow-xl border-4 border-red-900 bg-red-800 overflow-hidden",
                isTwentyFt ? (parseInt(container.posOnChassis) === 2 ? "w-[28%]" : "w-[26%]") : "w-[48%]",
                isTwentyFt ? leftOffset : "right-[20%]"
            )}
        >
            <div className="absolute inset-0 flex justify-evenly">
                {Array.from({ length: isTwentyFt ? 6 : 12 }).map((_, i) => (
                    <div key={i} className="w-[4px] bg-red-900 opacity-50" />
                ))}
            </div>
            <div className="absolute inset-0 flex justify-evenly items-center">
                {Array.from({ length: isTwentyFt ? 6 : 12 }).map((_, i) => (
                    <div key={i} className="w-[4px] h-full bg-red-900 opacity-40" />
                ))}
            </div>
            <div className="absolute top-1 right-2 border font-bold border-blue-700 text-blue-700 px-1 py-0.5 text-lg md:text-lg rounded bg-white">
                {container.type === "Discharge" ? "DS" : "LD"}
            </div>
            <div className="absolute w-full top-1/3 px-2 py-1 flex justify-center items-center text-white font-bold">
                <span
                    className="w-full text-center tracking-wider"
                    style={{
                        fontSize: isTwentyFt ? 'clamp(14px, 5vw, 24px)' : 'clamp(16px, 5vw, 30px)',
                        wordBreak: 'break-word',
                        letterSpacing: isTwentyFt ? '0.20em' : '0.30em',
                    }}
                >
                    {container.containerId}
                </span>
            </div>
            <div className="absolute bottom-1 left-2 text-white text-md font-mono">
                {isTwentyFt ? "20'" : "40'"}
            </div>
            <div className="absolute bottom-1 right-2 text-white text-md font-mono">
                {` ${container.weight / 1000}T`}
            </div>


        </div>
    );
};

export const TruckWithContainers = ({ jobs }: { jobs: JobDetail[] }) => {
    return (
        <div className="flex h-full flex-col items-center pb-3 px-2">
            <div
                className="relative w-full h-full aspect-[2.5] bg-contain bg-no-repeat bg-center"
                style={{ backgroundImage: `url(${truckimg})`, width: "75vw" }}
            >
                {jobs?.find(item => item?.iso === "22T1" || item?.iso?.includes("4")) ?
                    <div className="absolute top-1/2 left-[57%]  bg-blue-900 rounded-full  z-[999]  px-2  text-white items-center text-center" >
                        <span className="text-xl font-bold">2</span>
                    </div>
                    :
                    jobs?.some(item => item.containerId) && <>
                        <div className="absolute top-1/2 left-[43%]  bg-blue-900 rounded-full  z-[999]  px-2  text-white items-center text-center" >
                            <span className="text-xl font-bold">1</span>
                        </div>
                        <div className="absolute top-1/2  bg-blue-900 rounded-full  z-[999]  px-2 left-[70%]  text-white items-center text-center" >
                            <span className="text-xl font-bold">3</span>
                        </div>
                    </>
                }
                {jobs.map((job) => (
                    <Container key={job.containerId} container={job} />
                ))}
            </div>
        </div>
    );
};





// PLAIN OLD ONE

// interface ConatinerUIProps {
//     job: {
//         containerId: string;
//         iso: string;
//         weight: string;
//     }
// }

// const Conatiner = ({ job }: ConatinerUIProps) => {
//     return (<div className="flex items-center justify-center h-full bg-gray-100" >
//         <div className="relative w-[720px] h-[190px] bg-red-800 border-4 border-red-900 rounded-sm shadow-2xl overflow-hidden">
//             <div className="absolute inset-0 flex justify-evenly">
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//                 <div className="w-[6px] bg-red-900 opacity-50"></div>
//             </div>
//             {/* <div className="absolute top-[30%] left-[18%] text-white text-md font-mono tracking-wider">
//         <div className="flex items-center py-4 space-x-0 text-2xl font-bold text-blue-700 bg-white border border-gray-300 rounded shadow-md">
//           <span>MSCU1985426</span>
//           <span className="text-gray-300">|</span>
//           <span>22G1</span>
//           <span className="text-gray-300">|</span>
//           <span>25T</span>
//           <span className="text-gray-300">|</span>
//           <span>AFT(3)</span>
//         </div>
//       </div> */}
//             <div className="absolute top-[35%] left-[35%] text-white text-md font-mono tracking-wider">
//                 <div className="flex items-center px-1 text-3xl font-bold text-blue-700 bg-white border border-gray-300 rounded shadow-md">
//                     <span>{job.containerId}</span>
//                 </div>
//             </div>
//             <div className="absolute p-1 font-mono text-xs tracking-wider text-white border border-white rounded bottom-2 left-3">
//                 {job.iso}
//             </div>

//             <div className="absolute p-1 font-mono text-xs tracking-wider text-white border border-white rounded bottom-2 right-3">
//                 {job.weight}
//             </div>
//         </div>
//     </div>
//     )
// }

// interface AlertUIProps {
//     open: boolean;
//     setOpen: ((open: boolean) => void);
// }
// const AlertUI = ({ open, setOpen }: AlertUIProps) => {
//     const errors = [
//         "Speed Limit Exceeded",
//         "Route Deviation",
//         "Unauthorized Stop Detected",
//         "Geofence Breach",
//         "Prolonged Idle Time",
//         "ETA Delay Detected",
//     ]
//     return (
//         <div className="w-[30%] delay-700 ease-in-out h-full p-2 items-center shadow-lg border border-red-700 rounded justify-center">
//             <span className="flex justify-end ">
//                 <span onClick={() => { setOpen(!open) }} className="border border-black/30 rounded-full px-2 cursor-pointer hover:bg-gray-200 py-0.5">X</span>
//             </span>
//             <div className="flex flex-col h-full px-3 py-2 space-y-3 overflow-y-auto">
//                 {errors.map((err, idx) => (
//                     <div
//                         key={idx}
//                         className="inline-flex items-center gap-1 px-3 py-2.5 bg-red-100 text-red-700 text-sm rounded-full border border-red-200"
//                     >
//                         <AlertTriangle className="w-3 h-3" />
//                         {err}
//                     </div>
//                 ))}
//             </div>
//         </div>)
// }