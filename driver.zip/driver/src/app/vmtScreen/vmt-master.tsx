/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { Check } from 'lucide-react';
import { SetStateAction, useRef, useState } from 'react';
import { BiPowerOff } from 'react-icons/bi';
import { FaCircle } from 'react-icons/fa6';
import { GiCancel } from 'react-icons/gi';
import { ImNext2 } from 'react-icons/im';
import { PiWarningDiamondLight } from "react-icons/pi";
import { Navigate } from 'react-router';
import useSWR from 'swr'; 
import Map from "@/app/map/ITVMap";
import UserProfile from '@/components/user-profile';
import { JobStatus } from '@/lib/models';
import { logOutAPICALL, vmtFetchTriggerAPICALL } from '@/lib/services/vmt-driver-service';
import useAuthStore from '@/lib/stores/auth-stores';
import { cn } from '@/lib/utils';
import { FaMapMarkerAlt } from 'react-icons/fa';
import { toast } from 'sonner';
import {  TruckWithContainers } from './Utils';

type FetchResponse = JobStatus;

export default function VmtMaster() {
    const authStore = useAuthStore();
    const isAuthorized = authStore.getIsAuthorized();
    const [isPanelOpen, setIsPanelOpen] = useState(false);
    const [buttonTrigger, setButtonTrigger] = useState("");
     const [resetTime, setResetTime] = useState(80);
    const time = getCurrentTime();
    const date=getCurrentDate();
    const userObj = {
                cheId: localStorage.getItem("cheId") ?? "",
                userId: localStorage.getItem("userId") ?? ""
            };
     const { data, mutate } = useSWR<FetchResponse>(
        isAuthorized ? ['VMT', userObj, buttonTrigger] : null,
        isAuthorized ? () => vmtFetchTriggerAPICALL(userObj, buttonTrigger) : null,
        {
            refreshInterval: 500,
            revalidateOnFocus: true,
            revalidateOnReconnect: true,
        }
    );

    const logout = async () => {
        try {
            await logOutAPICALL({
                cheId: localStorage.getItem("cheId") ?? "",
                userId: localStorage.getItem("userId") ?? ""
            });
            authStore.logout();
        } catch (error) {
            console.error(error);
        }
    };

    const onButtonClick = async (btnLabel: string) => {
        if (btnLabel === "Logout") {
            logout();
        } else if (btnLabel === "Unavailable" || btnLabel === "Available"){
            setButtonTrigger(btnLabel);
            // vmtJobActionTrigger(btnLabel);
        }else{
              setButtonTrigger("");
        }
    };
  

    if (!isAuthorized) {
        return <Navigate to="/login" replace />;
    }
    if (!data) {
        return <FullPageLoader />
    }
    return (
         <div className="flex flex-col w-full h-screen">
            <header className="flex items-center justify-between px-5 py-3 bg-blue-900 ">
                <div className='flex justify-between w-1/2'>
                    <div className="flex items-center justify-center space-x-2 text-lg font-semibold">
                        <button title={data.status} className={`text-sm ${data.status === "Idle" ? " text-orange-400 " : " text-green-500"}`}>
                            <FaCircle size={22} />
                        </button>
                        <span className='space-x-1 text-white'>
                            <span className="font-bold text-white">{localStorage.getItem("cheId")}</span>
                            <span>/</span>
                            <span className="font-bold text-white">{localStorage.getItem("userId")}</span>
                        </span>
                    </div>
                    <span className='flex items-center px-2 text-lg font-semibold text-white'>
                        <span>{`GPS Time - ${time} ${date}`}</span>
                        {/* <Clock size={20} className="text-blue-600" /> */}
                        {/* <span>-{time}</span> */}
                    </span>
                    {/* <div className="flex items-center w-[70px] text-blue-600 bg-white justify-center py-1 rounded-md shadow-sm font-mono text-lg">
                        <span>
                            {resetTime === 80 ? "00:00" : `00:${resetTime.toString().padStart(2, '0')}`}
                        </span>
                    </div> */}
                </div>
                <div className="flex items-center space-x-3 text-white ">
                    <button title='Profile' className="text-sm text-white rounded-full">
                        <UserProfile />
                    </button>
                </div>
            </header>
             <div className="flex flex-1 overflow-auto bg-blue-100">
                <div className={cn(
                    'transition-all flex flex-col justify-around space-y-1 overflow-y-auto duration-500 ease-in-out px-3 h-full',
                    'w-full md:w-full',
                    isPanelOpen ? 'md:w-[70%]' : 'md:w-full'
                )}>
                    <div className="flex justify-end w-full cursor-pointer" >
                        <span className='flex items-center space-x-2'>
                            <PiWarningDiamondLight onClick={() => { toast.error("No Alerts !", { style: { color: "white", backgroundColor: "red" } }) }} size={32} color='red' />
                            <FaMapMarkerAlt onClick={() => setIsPanelOpen(!isPanelOpen)} size={32} color='blue' />
                        </span>
                    </div>
                    <div className="text-blue-900 h-[15%]">
                        <div className="flex flex-col items-center justify-center text-6xl font-bold">
                            <span>
                                 {data.jobDetails.length > 0
                                    ? data?.instruction
                                    : (data.status === "Idle" ? "You Are IDLE" : "Waiting for Job")} 
                               {/* {displayMessage!=""?displayMessage:data?.instruction} */}
                            </span>
                           {/*  {displayMessage!="" && displayMessage.includes("Arrived at")?
                            (<span className='text-3xl font-semibold'>
                                    {displayMessage.includes("Arrived at STS") ? "Waiting for container set Down" :
                                        "Waiting for lift complete"}
                                </span>
                            ): */}
                             { data?.rfidMessage && data.rfidMessage?.length > 0 &&
                                <span className='text-3xl font-semibold'>
                                   {data.rfidMessage}
                                </span>
                               }
                            
                        </div>
                    </div>

                    {(data?.jobDetails?.length > 0 && (data.jobDetails.find(item => item.containerId)) || data.instruction.toLowerCase().includes("waiting for pickup")) && (
                        // <div className='flex items-center justify-center w-full h-[50%] px-4'>
                            <div className='flex items-center justify-center w-full h-[70%] px-4'>
                            <TruckWithContainers jobs={data?.jobDetails} />
                        </div>
                    )}

                    <div className='w-full pt-4 h-[30%]'>
                        <div className="w-full flex h-[30%] justify-center pb-4 items-center space-x-3">
                            {(data.status !== "Idle" && data?.jobDetails?.length === 0)
                                ? getButtonsByStatus("", onButtonClick)
                                : getButtonsByStatus(data.status, onButtonClick)
                            }
                        </div>
                    </div>
                </div>

                <div className={cn(
                    'transition-all duration-500 ease-in-out h-full overflow-hidden',
                    isPanelOpen
                        ? 'md:w-[50%] bg-gray-200  border-l border-gray-300 opacity-100'
                        : 'w-0 p-0 border-0 opacity-0'
                )}>
                    {isPanelOpen && (
                        <div className='h-full p-2 bg-slate-100'>
                            <Map />
                            {/* <RouteMapUI />
                            <AlertUI open={isPanelOpen} setOpen={setIsPanelOpen} /> */}
                        </div>
                    )}
                </div>
            </div>



        </div>
    );
       
}


function getCurrentTime(): string {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

function getCurrentDate(): string {
  const now = new Date();
  const day = now.getDate().toString().padStart(2, '0');
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const year = now.getFullYear();
  return `${day}-${month}-${year}`;
}


const buttonStyles = {
    NEXT: {
        label: "NEXT",
        className: "bg-blue-900 hover:bg-blue-700 text-white",
        icon: <ImNext2 className="text-white" />,
    },
    CANCEL: {
        label: "CANCEL",
        className: "bg-gray-200 hover:bg-gray-400 text-blue-950",
        icon: <GiCancel className="text-blue-950" />,
    },
    Available: {
        label: "Available",
        className: "bg-blue-900 hover:bg-blue-600 text-white",
        icon: <Check className="text-white" />,
    },
    Unavailable: {
        label: "Unavailable",
        className: "bg-gray-500 hover:bg-gray-700 text-white",
        icon: <GiCancel className="text-white" />,
    },
    Logout: {
        label: "Logout",
        className: "bg-gray-500 hover:bg-gray-700 text-white",
        icon: <BiPowerOff className="text-white" />,
    },
};

const renderButton = (key: keyof typeof buttonStyles, onButtonClick: (label: string) => void) => {
    // console.log(key)
    const { label, className } = buttonStyles[key];
    return (
        <span
            key={key}
            onClick={() => onButtonClick(label)}
            className={`${label.length > 5 ? '  ' : 'w-[25%]'} text-5xl text-nowrap flex justify-center items-center space-x-1.5 cursor-pointer py-2.5 px-5 rounded-lg text-center font-semibold transition-colors ${className}`}
        >
            <span className="uppercase ">{label}</span>
            {/* {icon} */}
        </span>
    );
};

function getButtonsByStatus(status: string, onButtonClick: (label: string) => void) {
    switch (status) {
        case "Idle":
            return (
                <>
                    {renderButton("Logout", onButtonClick)}
                    {renderButton("Available", onButtonClick)}
                </>
            );
        case "Available":
            return (
                <>
                    {renderButton("NEXT", onButtonClick)}
                    {renderButton("Unavailable", onButtonClick)}
                </>
            );
        case "":
            return <>{renderButton("Unavailable", onButtonClick)}</>;
        default:
            return renderButton(status as keyof typeof buttonStyles, onButtonClick);
    }
}

const FullPageLoader = () => (
    <div className="fixed z-50 flex items-center justify-center inset-60 bg-gradient-to-br from-blue-100 via-white to-blue-200 bg-opacity-90 backdrop-blur-lg">
        <div className="relative">
            <div className="absolute inset-0 bg-blue-300 rounded-full opacity-30 blur-2xl animate-pulse"></div>
            <div className="z-10 w-16 h-16 border-t-4 border-blue-500 border-opacity-75 rounded-full animate-spin"></div>
        </div>
    </div>
);