import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { InputLogin } from "@/components/ui/input";

import axiosInstance from "@/lib/http-client";
import { JobStatus } from "@/lib/models";
import { fetchEquipments } from "@/lib/services/vmt-driver-service";
import useAuthStore from "@/lib/stores/auth-stores";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Navigate, useNavigate } from "react-router";
import { toast } from "sonner";
import { z } from "zod";
import igoLogo from '../../src/assets/igo_logo.png';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";


const formSchema = z.object({
  cheId: z.string().min(1, "Required!"),
  userId: z.string().min(1, { message: "Required!" }),
});
type CHEItems = {
  label: string;
  value: string;
}
export function LoginForm() {
  const [CHEItems, setCHEItems] = useState<CHEItems[]>([]);
  const navigate = useNavigate();
  const authStore = useAuthStore();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cheId: "",
      userId: ""
    },
  });

  useEffect(() => {
    fetchEquipmentData()
  }, []);

  const fetchEquipmentData = async () => {
    try {
      const data = await fetchEquipments(0, 100, "");
      const CHEItems = data.items.filter(item => item.equipmentType?.toLowerCase()?.trim() === "Terminal Truck".toLowerCase())
      console.log("data", data, CHEItems);
      const CHEItemsOptions = CHEItems?.map(item => ({
        label: item.equipmentName,
        value: item.equipmentName
      }))
      setCHEItems(CHEItemsOptions);
    } catch (error) {
      console.error(error);

    }
  };
  async function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    try {
      const response = await axiosInstance.post<JobStatus>(
        "/vmt/login",
        values
      );
      console.log("response ", response);
      if (response.status === 200) {
        authStore.logIn(values.cheId, values.userId, response.data);
        navigate("/");
      } else {
        // Handle error
      }
    } catch (error) {
      console.error(error);
      toast.error(error?.response?.data)
    }
  }

  return authStore.getIsAuthorized() ? (
    <Navigate to="/" replace />
  ) : (
    <div
      style={{ backgroundColor: "#dff5f6" }}
      className="min-h-screen"
    >
      <div className="min-h-screen flex items-center justify-center px-4 bg-blue-100">
        <div className="bg-white rounded-3xl shadow-lg w-[440px]  flex flex-col md:flex-row overflow-hidden lg:h-[450px]">
          {/* Right Panel */}
          <div className=" p-10 w-full flex flex-col justify-between h-full space-y-6">
            {/* Header */}
            <div className="space-y-4">
              <div className="flex justify-center">
                <img src={igoLogo} alt="Logo" className="object-cover w-20 h-auto" />
              </div>
              <h2 className="text-center text-2xl font-bold text-blue-900">
                RTLS VMT
              </h2>
            </div>

            {/* Form */}
            <div className="flex-grow">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="mt-8 space-y-10">
                  <FormField
                    control={form.control}
                    name="cheId"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Select
                            value={field.value}
                            onValueChange={(value) => {
                              field.onChange(value);
                              form.clearErrors("cheId");
                            }}
                          >
                            <SelectTrigger
                              className={cn(
                                "w-full border-0 pl-0 border-b-2 border-black/20 focus:outline-none focus:ring-0 focus:border-blue-500 placeholder:text-gray-400 text-gray-900 bg-transparent rounded-none shadow-none",
                                field.value ? "" : "text-gray-400"
                              )}
                            >
                              <SelectValue placeholder="Select CHE" />
                            </SelectTrigger>
                            <SelectContent>
                              {CHEItems?.map((item) => (
                                <SelectItem key={item.value} value={item.value}>
                                  {item.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <InputLogin
                            placeholder="User ID"
                            className="focus:outline-none focus:border-b-2 focus:border-b-blue-500 placeholder:text-md placeholder:font-light"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full h-8 text-base font-semibold">
                    Login
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
