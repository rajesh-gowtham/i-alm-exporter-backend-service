import useAuthStore from "@/lib/stores/auth-stores";
import { LogOut } from "lucide-react";
import { FaRegUserCircle } from "react-icons/fa";
import { useNavigate } from "react-router";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "./ui/dropdown-menu";
import { logOutAPICALL } from "@/lib/services/vmt-driver-service";

type User = {
  name: string;
  email: string;
  // avatar: string;
};

export default function UserProfile() {
  const navigate = useNavigate();
  const authStore = useAuthStore();

  const user: User = {
    name: localStorage.getItem("cheId") ?? "",
    email: localStorage.getItem("userId") ?? "",
  };

  // const initials = user.name
  //   .split(' ')
  //   .map(word => word[0])
  //   .join('')
  //   .toUpperCase()
  //   .slice(0, 2);
  const logout = () => {
    try {
      const res = logOutAPICALL({ cheId: localStorage.getItem("cheId") ?? "", userId: localStorage.getItem("userId") ?? "" })
      console.log(res);
      authStore.logout();
    } catch (error) {
      console.error(error);
    }
  }
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger>
          <div
            className="flex items-center justify-center  font-semibold overflow-hidden"
          >
            {/* <span>{initials}</span> */}
            <FaRegUserCircle size={28} />
          </div>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="w-[--radix-dropdown-menu-trigger-width] min-w-40 rounded-lg"
          side="bottom"
          align="end"
          sideOffset={4}
        >
          <DropdownMenuLabel className="p-0 font-normal">
            <div className="flex items-center p-2">
              <div className="grid flex-1 text-sm leading-tight text-left">
                <span className="font-semibold truncate">{user.name}</span>
                <span className="text-xs truncate">{user.email}</span>
              </div>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="cursor-pointer"
            onClick={logout}
          >
            <LogOut />
            Log out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
