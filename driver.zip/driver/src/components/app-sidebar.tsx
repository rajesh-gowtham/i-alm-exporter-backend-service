import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "./ui/sidebar";
import { NavLink } from "react-router";
import React, { memo, useState } from "react";
import { RouteItem, routesList } from "@/routes";
import { ChevronDown, ChevronRight } from "lucide-react";

const FakeLink = memo(({ title, url, icon }: RouteItem) => {
  const ItemIcon = icon;
  return (
    <SidebarMenuButton
      asChild
      tooltip={{
        children: (
          <div className="flex items-center space-x-2">
            <span>{title}</span>
          </div>
        ),
        className: "bg-muted text-muted-foreground dark:text-muted-foreground",
      }}
    >
      <NavLink
        to={url}
        className={({ isActive }) => (isActive ? "text-primary" : "")}
      >
        <ItemIcon />
        <span>{title}</span>
      </NavLink>
    </SidebarMenuButton>
  );
});

const SidebarSubMenu = memo(({ item }: { item: RouteItem }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <SidebarMenuButton
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between w-full"
      >
        <div className="flex items-center justify-center space-x-2">
          <item.icon />
          <span>{item.title}</span>
        </div>
        {isOpen ? <ChevronDown /> : <ChevronRight />}
      </SidebarMenuButton>
      {isOpen && (
        <div className="pl-3">
          {item.subItems?.map((subItem) => (
            <SidebarMenuItem key={subItem.url}>
              <FakeLink {...subItem} />
            </SidebarMenuItem>
          ))}
        </div>
      )}
    </div>
  );
});

const AppSidebarV2 = memo(function AppSidebarV2() {
  return (
    <Sidebar className="border-none" variant="sidebar" collapsible="icon">
      <SidebarHeader />
      <SidebarContent>
        <SidebarGroup>
          {/* <SidebarGroupLabel>Application</SidebarGroupLabel> */}
          <SidebarGroupContent>
            <SidebarMenu>
              {routesList.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.subItems ? (
                    <SidebarSubMenu item={item} />
                  ) : (
                    <FakeLink {...item} />
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter />
    </Sidebar>
  );
});

export default AppSidebarV2;
