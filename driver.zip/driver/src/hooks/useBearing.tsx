interface Coordinates {
  latitude: number;
  longitude: number;
}

/**
 * Calculate bearing to face north from given coordinates
 * @param coords - Current coordinates (latitude, longitude)
 * @returns Bearing in degrees (0-360) where 0 = North
 */
export const calculateBearingToNorth = (coords: Coordinates): number => {
  const { latitude, longitude } = coords;
  
  // North pole coordinates
  const northLat = 90;
  const northLng = longitude; // Same longitude as current position
  
  // Convert to radians
  const lat1 = (latitude * Math.PI) / 180;
  const lat2 = (northLat * Math.PI) / 180;
  const deltaLng = ((northLng - longitude) * Math.PI) / 180;
  
  // Calculate bearing using spherical trigonometry
  const x = Math.sin(deltaLng) * Math.cos(lat2);
  const y = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLng);
  
  let bearingRad = Math.atan2(x, y);
  
  // Convert to degrees and normalize to 0-360
  let bearingDeg = (bearingRad * 180) / Math.PI;
  bearingDeg = (bearingDeg + 360) % 360;
  
  return bearingDeg;
};