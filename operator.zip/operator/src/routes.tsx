import DashboardPage from "@/app/dashboard/dashboard-page";
import LoginPage from "@/app/login/login-page";
import MainLayout from "@/components/main-layout.tsx";
import { CircleGauge, Cog, LucideProps, Telescope } from "lucide-react";
import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
} from "react-router";

import EquipmentMaster from "@/app/management/Equipment/equipment-master";
import ManagementPage from "@/app/management/management-page";
import VesselBerthingMaster from "@/app/management/VesselBerthingMaster/vessel-berthing-master";
import VesselMaster from "@/app/management/VesselMaster/vessel-master";
import VesselVisitMaster from "@/app/management/VesselVisitMaster/vessel-visit-master";
import WorkInstructionMaster from "@/app/management/WorkInstruction/work-instruction-master";
import Profile from "@/app/profile/profile";
import EquipmentPoolMaster from "./app/management/EquipmentPool/equipmentpool-master";
import PointofWorkImport from "./app/management/PointofWork/pointofwork-import";
import PointofWorkMaster from "./app/management/PointofWork/pointofwork-master";
// import TermainalMaster from "./app/management/Terminal/terminal-master";
import WorkAssignmentMaster from "./app/management/WorkAssignments/workassignments-master";
import Sample from "./app/management/WorkAssignments/sample";
// import WorkInstructionImport from "./app/management/WorkInstruction/work-instruction-import";
import ErrorPage from "./components/ErrorBoundary";
import { privateRoute, publicRoute, sidebarHeaderTitle } from "./lib/constants";
import Waterside from "./app/dashboard/waterside/waterside";
import Landside from "./app/dashboard/landside/landside";
import InventoryMaster from "./app/management/ContainerInventory/inventory-master";
import RTLSAssetMaster from "./app/management/RTLSAssets/rtls-asset-master";
import EmissionsPage from "./app/emissions/emissions-page";
import TestMapComponent from "./app/map/TestMap";
import MapSandboxPage from "./app/map/MapSandboxPage";
export const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route path={publicRoute._Login} element={<LoginPage />} />
      <Route
        path={publicRoute._DefaultPath}
        errorElement={<ErrorPage />}
        element={<MainLayout />}
      >
        <Route index path="/" element={<DashboardPage />} />
        <Route index path={privateRoute._Profile} element={<Profile />} />
        <Route
          index
          path={privateRoute._RTLS + privateRoute._Waterside}
          element={<Waterside />}
        />
        <Route
          index
          path={privateRoute._RTLS + privateRoute._Landside}
          element={<Landside />}
        />
        <Route
          index
          path={privateRoute._RTLS + privateRoute._DeCarbonization}
          element={<EmissionsPage />}
        />
        <Route
          index
          path={privateRoute._Configuration}
          element={<ManagementPage />}
        />
        <Route
          index
          path={privateRoute._Configuration + privateRoute._Vessel}
          element={<VesselMaster />}
        />
        <Route
          index
          path={privateRoute._Configuration + privateRoute._Vesselvisit}
          element={<VesselVisitMaster />}
        />
        <Route
          index
          path={privateRoute._Configuration + privateRoute._Berthing}
          element={<VesselBerthingMaster />}
        />
        <Route
          index
          path={privateRoute._Configuration + privateRoute._Equipment}
          element={<EquipmentMaster />}
        />
        <Route
          index
          path={privateRoute._Configuration + privateRoute._RTLS}
          element={<RTLSAssetMaster />}
        />
        {/* <Route index path={privateRoute._Configuration + privateRoute._Containeryard_Inventory} element={<ContainerYardInventoryMaster />} /> */}
        <Route
          index
          path={privateRoute._Operation + privateRoute._Equipmentpool}
          element={<EquipmentPoolMaster />}
        />
        <Route
          index
          path={privateRoute._Operation + privateRoute._Pointofwork}
          element={<PointofWorkMaster />}
        />
        <Route
          index
          path={privateRoute._Operation + privateRoute._Pointofwork_Import}
          element={<PointofWorkImport />}
        />
        <Route
          index
          path={privateRoute._Operation + privateRoute._Workinstruction}
          element={<WorkInstructionMaster />}
        />
        <Route
          index
          path={privateRoute._Operation + privateRoute._WorkAssignment}
          element={<WorkAssignmentMaster />}
        />
        <Route
          index
          path={privateRoute._Operation + privateRoute._Inventory}
          element={<InventoryMaster />}
        />
        <Route index path="/sample" element={<Sample />} />
        {/* <Route index path={"testmap"} element={<TestMapComponent />} /> */}
        <Route index path={"testmap"} element={<MapSandboxPage />} />
      </Route>
    </>
  )
);

export interface RouteItem {
  title: string;
  url: string;
  icon?: React.ForwardRefExoticComponent<
    Omit<LucideProps, "ref"> & React.RefAttributes<SVGSVGElement>
  >;
  subItems?: RouteItem[];
}

export const routesList: RouteItem[] = [
  {
    title: sidebarHeaderTitle._Dashboard,
    url: publicRoute._DefaultPath,
    icon: CircleGauge,
  },
  {
    title: sidebarHeaderTitle._Operations,
    url: privateRoute._Configuration + privateRoute._Operation,
    icon: Telescope,
    subItems: [
      {
        title: sidebarHeaderTitle._Vesselvisit,
        url: privateRoute._Configuration + privateRoute._Vesselvisit,
      },
      {
        title: sidebarHeaderTitle._Berthing,
        url: privateRoute._Configuration + privateRoute._Berthing,
      },
      {
        title: sidebarHeaderTitle._ManageEquip,
        url: privateRoute._Operation + privateRoute._Equipmentpool,
      },
      {
        title: sidebarHeaderTitle._POW,
        url: privateRoute._Operation + privateRoute._Pointofwork,
      },
      {
        title: sidebarHeaderTitle._WorkAssignment,
        url: privateRoute._Operation + privateRoute._WorkAssignment,
      },
      {
        title: sidebarHeaderTitle._Container_Inventory,
        url: privateRoute._Operation + privateRoute._Inventory,
      },
    ],
  },
  // {
  //   title: sidebarHeaderTitle._Management,
  //   url: privateRoute._Configuration,
  //   icon: Cog,
  //   subItems: [
  //     {
  //       title: sidebarHeaderTitle._Asset,
  //       url: privateRoute._Configuration + privateRoute._Berthing,
  //       subItems: [
  //         {
  //           title: sidebarHeaderTitle._Terminal,
  //           url: privateRoute._Configuration + privateRoute._Equipment, //need to create one route

  //         },
  //         {
  //           title: sidebarHeaderTitle._RTLS,
  //           url: privateRoute._Configuration + privateRoute._RTLS,
  //         }
  //       ]
  //     }, {
  //       title: sidebarHeaderTitle._Vessel,
  //       url: privateRoute._Configuration + privateRoute._Vessel,
  //     }
  //     ,  {
  //       title: sidebarHeaderTitle._WorkInstruction,
  //       url: privateRoute._Operation + privateRoute._Workinstruction,
  //     },
  //   ]

  // }
];
