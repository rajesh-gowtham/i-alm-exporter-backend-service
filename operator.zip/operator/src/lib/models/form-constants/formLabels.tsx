export const VesselFields = {
    _Name: "Name",
    _VesselClass: "Vessel Class",
    _LineOperator: "Line Operator",
    _LOAInCm: "LOA (cm)",
    _RadioCallSign: "Radio CallSign",
    _LloydsIdentity: "Lloyds Identity",
    _Notes: "Notes"
} as const;

export const VesselVistLabels = {
    _VisitRef: "Visit Ref",
    _VesselName: "Vessel Name",
    _Phase: "Phase",
    _Inbound_Voyage: "Inbound Voyage",
    _Outbound_Voyage: "Outbound Voyage",
    _LineOperator: "Line Operator",
    _ETA: "ETA",
    _ETD: "ETD",
    _ATA: "ATA",
    _ATD: "ATD",
    _StartWorkTime: "Start Work Time",
    _EndWorkTime: "End Work Time",
    _Classification: "Classification",
    _Service: "Service",
} as const;
export const BerthingLabels = {
    _Quay: "Quay",
    _Side_To: "Side To",
    _BerthETA: "Berth ETA",
    _BerthETD: "Berth ETD",
    _BerthATA: "Berth ATA",
    _StartWorkTime: "Start Work Time",
    _StartBollard: "Start Bollard",
    _EndBollard: "End Bollard",
    _VisitRef: "Visit Ref"
} as const;
export const EquipmentLabels = {
    _EquipmentName: "Name",
    _EquipmentType: "Type",
    _MaxWeightInTon: "Max Weight (Ton)",
    _MaxTEU: "Max TEU",
    _Model: "Model",
    _Make: "Make",
    _RFIDTag1: "RFID Tag 1",
    _RFIDTag2: "RFID Tag 2",

} as const;
export const RTLSAssetLabels = {
    _Reader_IP: "Reader_IP",
    _ReadPoint_Name: "Read Point_Name",
    _Antenna_ID: "Antenna_ID",
    _ITV_ID: "ITV_ID",
    _Reader_Type: "Reader_Type",
    _Reader_Model: "Reader_Model",
    _location_ID: "location_ID",
    _Latitude: "Latitude",
    _Longitude: "Longitude",
    _UserId: "User Id",
} as const;

export const EquipmentPoolLabels = {
    _PoolName: "Pool Name",
} as const;

export const WorkInstructionLabels = {
    _ContainerID: "Container ID",
    _ISO: "ISO",
    _MoveType: "Move Type",
    _Mode: "Mode",
    _InboundLocationType: "IB Location Type",
    _VisitRef: "IB Carrier",
    _OutboundLocationType: "OB Location Type",
    _OutboundCarrier: "OB Carrier",
    _From: "From",
    _To: "To",
    _POW: "POW",
    _CHEPut: "CHE Put",
    _CHECarry: "CHE Carry",
    _PosOnChassis: "Pos on Chassis",
    _Status: "Status",
    _JobSteppingStatus: "Job Stepping Status",
    _Deck: "Deck",
    _Weight: "Weight (kg)",
    _AssignedLane: "Assigned Lane",
    _Sequence: "Sequence"
} as const;

export const ContainerInventoryLabels = {
    _ContainerId: "Container ID",
    _ISO_Code: "ISO",
    _Block: "Block",
    _Location: "Current Position"
} as const;

export const VesselInventoryLabels = {
    _VisitRef: "visit Ref",
    _VesselName: "vessel Name",
    _VesselClass: "vessel Class",
    _LineOperator: "line Operator",
    _Hatch: "hatch",
} as const;