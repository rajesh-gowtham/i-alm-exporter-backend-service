export const Env = {
  ApiUrl: import.meta.env.VITE_API_URL,
  GoogleMapsUrl: import.meta.env.VITE_GOOGLE_MAPS_KEY,
  PocketBaseUrl: import.meta.env.VITE_POCKET_BASE_URL,
  PocketBaseToken: import.meta.env.VITE_POCKET_BASE_TOKEN,
};
export const DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm";
export const publicRoute = {
  _Login: "/login",
  _DefaultPath: "/",
}
export const privateRoute = {
  _RTLS: '/rtls',
  _Dashboard: "/dashboard",
  _Profile: "/profile",
  _Waterside: "/waterside",
  _Landside: "/landside",
   _DeCarbonization: "/decarbonization",
  _Configuration: "/management",
  _Vessel: "/vessels",
  _Vessel_Import: "/vessels/import",
  _Vesselvisit: "/vesselvisit",
  _Vesselvisit_Import: "/vesselvisit/import",
  _Berthing: "/berthing",
  _Berthing_Import: "/berthing/import",
  _Equipment: "/equipment",
  _Equipment_Import: "/equipment/import",
  _Containeryard_Inventory: "/containeryardinventory",
  _Equipmentpool: "/equipmentpool",
  _Equipmentpool_Import: "/equipmentpool/import",
  _Pointofwork: "/pointofwork",
  _Pointofwork_Import: "/pointofwork/import",
  _Workinstruction: "/workinstruction",
  _Workinstruction_Import: "/workinstruction/import",
  _Operation: "/operation",
  _Map: "/map",
  _Terminal: "/terminal",
  _WorkAssignment: "/workqueue",
  _Inventory: "/inventory"
}
export const sidebarHeaderTitle = {
  _Dashboard: "Dashboard",
  _Operations: "Operations",
  _POW: "POW",
  _Pools_Equipment: "Pools & Equipment",
  _WorkInstruction: "Work Instruction",
  _WorkAssignment: "Work Queue",
  _Container_Inventory: "History & Events",
  _Management: "Data Management",
  _Vessel: "Vessel",
  _Vesselvisit: "Vessel Visit",
  _Berthing: "Berthing",
  _Terminal: "Terminal",
  _Asset: "Asset",
  _RTLS: "RTLS",
  _ManageEquip: "Manage Equipment"
}

export const ReadableDateFormat = "DD-MMM-YYYY, hh:mm A";
export const ReadableDateFormatSeconds = "DD-MM-YYYY HH:mm:ss A";

export const equipmentOptionList = [
  { value: "STS", label: "STS" },
  { value: "Yard Crane ", label: "Yard Crane " },
  { value: "Terminal Truck", label: "Terminal Truck" },
];

export const vesselVisitPhasesOptionList = [
  { value: "Inbound", label: "Inbound" },
  { value: "Arrived", label: "Arrived" },
  { value: "Working", label: "Working" },
  { value: "Completed", label: "Completed" },
  { value: "Departed", label: "Departed" },
];

export const visitClassificationOptionList = [
  { value: "Deepsea", label: "Deepsea" },
  { value: "Barge", label: "Barge" },
  { value: "Feeder", label: "Feeder" },
];

export const berthingSideOptionList = [
  { value: "Starboard", label: "Starboard" },
  { value: "Port", label: "Port" },
];
export const TransModeOptionList = [
  { value: "Single", label: "Single" },
  { value: "Twin", label: "Twin" },
];
export const ibOblocationTypeOptionList = [
  { value: "Vessel", label: "Vessel" },
  { value: "Truck", label: "Truck" },
];
export const outboundCarrierOptionList = [
  { value: "Vessel", label: "Vessel" },
  { value: "Truck", label: "Truck" },
];
export const workQueueStatus = {
  _PLANNED: 'Planned',
  _INPROGRESS: 'Inprogress',
  _SUSPENDED: 'Suspended',
  _COMPLETED: 'Completed'
}
export const deckOptionLists = [
  { value: "A", label: "A" },
  { value: "B", label: "B" },
];