import { fetchEquipmentPools } from "@/lib/services/equipmentpool-services";
import { Equipment, EquipmentPool, PointofWork, Vessel, VesselBerthing, VesselVisit, WorkInstruction } from "@/lib/models";
import { fetchVesselBerthings, fetchVessels, fetchVesselVisits } from "./services/vessels-services";
import { fetchEquipments } from "./services/equipment-services";
import { fetchPointofWorks } from "./services/pointofwork-services";
import { fetchWorkInstruction, fetchWorkInstructions } from "./services/work-instruction-services";

export const vesselFetcher = async () => {
    const [data] = await fetchVessels();
    return {
        items: data.items as Vessel[],
        totalCount: data.totalCount,
    };
}

export const vesselVisitFetcher = async () => {
    const [data] = await fetchVesselVisits();
    return {
        items: data.items as VesselVisit[],
        totalCount: data.totalCount,
    };
}

export const vesselBerthigFetcher = async () => {
    const [data] = await fetchVesselBerthings();
    return {
        items: data.items as VesselBerthing[],
        totalCount: data.totalCount,
    };
}

export const equipmentFetcher = async () => {
    const [data] = await fetchEquipments();
    return {
        items: data.items as Equipment[],
        totalCount: data.totalCount,
    };
}

export const equipmentPoolFetcher = async () => {
    const [data] = await fetchEquipmentPools();
    return {
        items: data.items as EquipmentPool[],
        totalCount: data.totalCount,
    };
};

export const pointofWorkFetcher = async () => {
    const [data] = await fetchPointofWorks();
    return {
        items: data.items as PointofWork[],
        totalCount: data.totalCount,
    };
}

export const workInstructionsFetcher = async () => {
    const [data] = await fetchWorkInstructions();
    return {
        items: data.items as WorkInstruction[],
        totalCount: data.totalCount,
    };
}

