// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { PaginatedPointOfWorkResponse, PointofWork } from '../models';

export async function fetchPointofWorks(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedPointOfWorkResponse> {

  const PointofWorks = await axiosInstance.get<PaginatedPointOfWorkResponse>("/pointofwork", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });
  if (PointofWorks.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return PointofWorks.data;

  /* try {
    const PointofWorks = await pocketbase.collection('PointofWork').getFullList<PointofWork>(200, {
      sort: '-created',
    });
    return PointofWorks;
  } catch (error) {
    console.error('Error fetching PointofWorks:', error);
    return [];
  } */
}

export async function fetchPointofWorkById(id: string): Promise<PointofWork | null> {
  const PointofWorks = await axiosInstance.get<PointofWork>(`/pointofwork/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (PointofWorks.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return PointofWorks.data;
  /* try {
    const PointofWork = await pocketbase.collection('PointofWork').getOne<PointofWork>(id);
    return PointofWork;
  } catch (error) {
    console.error(`Error fetching PointofWork with ID ${id}:`, error);
    return null;
  } */
}

export async function addPointofWork(PointofWorkData: Omit<PointofWork, 'id' | 'created' | 'updated'>): Promise<PointofWork | null> {

  const PointofWorks = await axiosInstance.post<PointofWork>("/pointofwork", PointofWorkData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (PointofWorks.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return PointofWorks.data;

  /* try {
    const newPointofWork = await pocketbase.collection('PointofWork').create<PointofWork>(PointofWorkData);
    return newPointofWork;
  } catch (error) {
    console.error('Error adding PointofWork:', error);
    return null;
  } */
}

export async function addPointofWorkInBatch(PointofWorkData: Omit<PointofWork, 'id' | 'created' | 'updated'>[]): Promise<PointofWork[] | null> {
  const PointofWorks = await axiosInstance.post<PointofWork[]>("/pointofwork/batch", PointofWorkData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (PointofWorks.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return PointofWorks.data;

  /* try {
    const newPointofWork = await pocketbase.collection('PointofWork').create<PointofWork>(PointofWorkData);
    return newPointofWork;
  }
  catch (error) {
    console.error('Error adding PointofWork:', error);
    return null;
  } */
}

export async function editPointofWork(id: string, PointofWorkData: Partial<Omit<PointofWork, 'id' | 'created' | 'updated'>>): Promise<PointofWork | null> {

  const PointofWorks = await axiosInstance.put<PointofWork>(`/pointofwork/`, PointofWorkData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (PointofWorks.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return PointofWorks.data;

  /* try {
    const updatedPointofWork = await pocketbase.collection('PointofWork').update<PointofWork>(id, PointofWorkData);
    return updatedPointofWork;
  } catch (error) {
    console.error(`Error editing PointofWork with ID ${id}:`, error);
    return null;
  } */
}

export async function deletePointofWork(id: string): Promise<boolean> {

  const PointofWorks = await axiosInstance.delete<PointofWork>(`/pointofwork/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (PointofWorks.status !== 204) {
    throw new Error("Failed to fetch data");
  }
  return true;

  /* try {
    await pocketbase.collection('PointofWork').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting PointofWork with ID ${id}:`, error);
    return false;
  } */
}

