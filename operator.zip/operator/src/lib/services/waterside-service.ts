// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { PaginatedqcDetailsResponse } from '../models';
// import { PaginatedPointOfWorkResponse, PointofWork } from '../models';


export async function fetchWatersideData(payload:any){
  const{cardName,skip,take}=payload
  console.log(cardName)
  const waterSide = await axiosInstance.get(`/dashboard/waterSide?cardName=${cardName}&skip=${skip}&take=${take}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (waterSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return waterSide.data;
}
export async function fetchWatersideGridData(payload:any):Promise<PaginatedqcDetailsResponse>{
  const waterSide = await axiosInstance.post<PaginatedqcDetailsResponse>('/dashboard/waterSide',payload, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (waterSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return waterSide.data;
}


