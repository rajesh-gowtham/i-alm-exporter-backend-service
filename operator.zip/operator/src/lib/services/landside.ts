// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { PaginatedqcDetailsResponse } from '../models';
// import { PaginatedPointOfWorkResponse, PointofWork } from '../models';


export async function fetchLandsideData(skip: number | undefined,take: number | undefined){
  const landSide = await axiosInstance.get(`/dashboard/landSide?skip=${skip}&take=${take}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (landSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return landSide.data;
}
export async function fetchLandsideGridData(payload:any):Promise<PaginatedqcDetailsResponse>{
  const landSide = await axiosInstance.post<PaginatedqcDetailsResponse>('/dashboard/landside',payload, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (landSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return landSide.data;
}


