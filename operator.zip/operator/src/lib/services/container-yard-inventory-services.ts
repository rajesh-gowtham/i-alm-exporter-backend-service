import pocketbase from '../api/pb';
import { ContainerYardInventory } from '../models';

export async function fetchContainerYardInventorys(): Promise<ContainerYardInventory[]> {
  try {
    const ContainerYardInventorys = await pocketbase.collection('ContainerYardInventory').getFullList<ContainerYardInventory>(200, {
      sort: '-created',
    });
    return ContainerYardInventorys;
  } catch (error) {
    console.error('Error fetching ContainerYardInventorys:', error);
    return [];
  }
}

export async function addContainerYardInventory(ContainerYardInventoryData: Omit<ContainerYardInventory, 'id' | 'created' | 'updated'>): Promise<ContainerYardInventory | null> {
  try {
    const newContainerYardInventory = await pocketbase.collection('ContainerYardInventory').create<ContainerYardInventory>(ContainerYardInventoryData);
    return newContainerYardInventory;
  } catch (error) {
    console.error('Error adding ContainerYardInventory:', error);
    return null;
  }
}

export async function editContainerYardInventory(id: string, ContainerYardInventoryData: Partial<Omit<ContainerYardInventory, 'id' | 'created' | 'updated'>>): Promise<ContainerYardInventory | null> {
  try {
    const updatedContainerYardInventory = await pocketbase.collection('ContainerYardInventory').update<ContainerYardInventory>(id, ContainerYardInventoryData);
    return updatedContainerYardInventory;
  } catch (error) {
    console.error(`Error editing ContainerYardInventory with ID ${id}:`, error);
    return null;
  }
}

export async function deleteContainerYardInventory(id: string): Promise<boolean> {
  try {
    await pocketbase.collection('ContainerYardInventory').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting ContainerYardInventory with ID ${id}:`, error);
    return false;
  }
}

