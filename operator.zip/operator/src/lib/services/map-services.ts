// services/map-services.ts

import axiosInstance from "../http-client";
import { EquipmentState } from "../models";

export async function fetchEquipmentStates(): Promise<EquipmentState[]> {
  try {
    const { data, status } = await axiosInstance.get<EquipmentState[]>("/equipment/states", {
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (status !== 200) {
      throw new Error(`Error ${status}: Failed to fetch equipment states.`);
    }

    return data;
  } catch (error: any) {
    console.error("fetchEquipmentStates error:", error);
    throw new Error(
      error?.response?.data?.message || "Unexpected error while fetching equipment states"
    );
  }
}

export async function fetchEquipmentStateByName(name: string): Promise<EquipmentState | null> {
  try {
    const { data, status } = await axiosInstance.get<EquipmentState>(`/equipment/${name}/state`, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (status !== 200) {
      throw new Error(`Error ${status}: Failed to fetch equipment state for name ${name}.`);
    }

    return data;
  } catch (error: any) {
    console.error(`fetchEquipmentState error for name ${name}:`, error);
    throw new Error(
      error?.response?.data?.message || `Unexpected error while fetching equipment state for name ${name}`
    );
  }
}


