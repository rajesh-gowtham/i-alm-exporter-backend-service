import pocketbase from '../api/pb';

export interface Todo {
    id: string;
    title: string;
    isComplete: boolean;
    created: string;
    updated: string;
}

export async function fetchTodos(): Promise<Todo[]> {
    try {
        // Replace 'todos' with your actual collection name.
        const todos = await pocketbase.collection('todos').getFullList<Todo>(200, {
            sort: '-created',
        });
        return todos;
    } catch (error) {
        console.error('Error fetching todos:', error);
        return [];
    }
}