/* eslint-disable @typescript-eslint/no-explicit-any */
import axiosInstance from "../http-client";
import { PaginatedWorkAssignmentResponse, PaginatedWorkInstructionResponse, workQueueResponse } from "../models";

export async function fetchWorkAssignmentWithPowAPICALL(skip: number, take: number, search: string): Promise<PaginatedWorkAssignmentResponse> {
    try {
        const response = await axiosInstance.get<PaginatedWorkAssignmentResponse>(
            `/workassignment?skip=${skip}&take=${take}&search=${encodeURIComponent(search)}`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function fetchWorkQueuesByPowAPICALL(vesselVisitId: string, powId: string): Promise<workQueueResponse[]> {
    try {
        const response = await axiosInstance.get<workQueueResponse[]>(
            `/workassignment/pow/${vesselVisitId}/${powId}`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function fetchWorkInstructionsByWQAPICALL(skip: number, take: number, search: string, workQueue: number): Promise<PaginatedWorkInstructionResponse> {
    try {
        const response = await axiosInstance.get<PaginatedWorkInstructionResponse>(
            `/workinstructions/workQueue/${workQueue}?skip=${skip}&take=${take}&search=${encodeURIComponent(search)}`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function triggerWQJobOperationAPICALL(action: string, workQueue: number) {
    try {
        const response = await axiosInstance.post(
            `/workassignment/operation/${workQueue}?action=${action}`

        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function AppendQueue(payload: any) {
  try {
    const response = await axiosInstance.post(`workInstructions/append`, payload);
    if (response.status !== 200) {
      throw new Error("Failed to add data");
    }
    return response;
  } catch (error: any) {
    throw {
      status: error?.response?.status,
      message: error?.response?.data?.message || "An unexpected error occurred",
      data: error?.response?.data,
    };
  }
};

