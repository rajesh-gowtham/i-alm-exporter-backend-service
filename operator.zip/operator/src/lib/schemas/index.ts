import { z } from 'zod';

const optionalMeta = {
  createdBy: z.string().nullable().optional(),
  updatedBy: z.string().nullable().optional(),
  createdAt: z.string().nullable().optional(),
  updatedAt: z.string().nullable().optional()
};

const optionalId = {
  id: z.number().optional()
};

export const vesselSchema = z.object({
  ...optionalId,
  vesselName: z.string().min(1, "Vessel name is required"),
  vesselClass: z.string().min(1, "Vessel class is required"),
  operator: z.string().min(1, "Operator is required"),
  overallLength: z.coerce.number().min(1, "Overall length is required"),
  radioCallSign: z.string().min(1, "Radio call sign is required"),
  lloydsIdentity: z.string().min(1, "Lloyds identity is required"),
  notes: z.string().nullable().optional(),
  ...optionalMeta
});

export const VesselVisitSchema = z.object({
  ...optionalId,
  visitRef: z.string().min(1, "Visit Ref is required"),
  vesselId: z.preprocess(
    (val) => {
      const num = typeof val === "string" ? parseInt(val, 10) : val;
      return isNaN(num as number) ? undefined : num;
    },
    z.number().min(1, "Vessel is required")
  ),
  phase: z.string().min(1, "Vessel Visit Phase is required"),
  inboundVoyage: z.string().min(1, "Inbound Voyage is required"),
  outboundVoyage: z.string().min(1, "Outbound Voyage is required"),
  lineOperator: z.string().min(1, "Operator is required"),
  eta: z.string().min(1, "ETA is required"),
  etd: z.string().min(1, "ETD is required"),
  ata: z.string().nullable().optional(),
  atd: z.string().nullable().optional(),
  startWorkTime: z.string().nullable().optional(),
  endWorkTime: z.string().nullable().optional(),
  classification: z.string().nullable().optional(),
  service: z.string().nullable().optional(),
  ...optionalMeta
});

export const VesselVisitImportSchema = z.object({
  ...optionalId,
  visitRef: z.string().min(1, "Visit Ref is required"),
  vesselId: z.string().min(1, "Vessel is required"),
  phase: z.string().min(1, "Vessel Visit Phase is required"),
  inboundVoyage: z.string().min(1, "Inbound Voyage is required"),
  outboundVoyage: z.string().min(1, "Outbound Voyage is required"),
  lineOperator: z.string().min(1, "Operator is required"),
  eta: z.string().min(1, "ETA is required"),
  etd: z.string().min(1, "ETD is required"),
  ata: z.string().nullable().optional(),
  atd: z.string().nullable().optional(),
  startWorkTime: z.string().nullable().optional(),
  endWorkTime: z.string().nullable().optional(),
  classification: z.string().nullable().optional(),
  service: z.string().nullable().optional(),
  ...optionalMeta
});

export const VesselBerthingSchema = z.object({
  ...optionalId,
  quay: z.string().min(1, "Quay is required"),
  berthingSide: z.string().min(1, "Berthing Side is required"),
  berthEta: z.string().min(1, "ETA is required"),
  berthEtd: z.string().min(1, "ETD is required"),
  berthAta: z.string().optional().nullable(),
  startWorkTime: z.string().optional().nullable(),
  startBollard: z.string().min(1, "StartBollard is required"),
  endBollard: z.string().min(1, "EndBollard is required"),
  vesselVisitId: z.preprocess(
    (val) => {
      const num = typeof val === "string" ? parseInt(val, 10) : val;
      return isNaN(num as number) ? undefined : num;
    },
    z.number().min(1, "Visit Ref is required")
  ),
  ...optionalMeta
});

export const VesselBerthingImportSchema = z.object({
  ...optionalId,
  quay: z.string().min(1, "Quay is required"),
  berthingSide: z.string().min(1, "Berthing Side is required"),
  berthEta: z.string().min(1, "ETA is required"),
  berthEtd: z.string().min(1, "ETD is required"),
  berthAta: z.string().optional().nullable(),
  startWorkTime: z.string().optional().nullable(),
  startBollard: z.string().min(1, "StartBollard is required"),
  endBollard: z.string().min(1, "EndBollard is required"),
  vesselVisitId: z.string().min(1, "Visit Ref is required"),
  ...optionalMeta
});

export const EquipmentSchema = z.object({
  ...optionalId,
  equipmentName: z.string().min(1, "Name is required"),
  equipmentType: z.string().min(1, "Type is required Or Invalid"),
  maxWeight: z.preprocess((val) => {
    const num = parseFloat(val as string);
    return isNaN(num) ? undefined : num;
  }, z.number().optional()),
  maxTeu: z.preprocess((val) => {
    const num = parseFloat(val as string);
    return isNaN(num) ? undefined : num;
  }, z.number().optional()),
  model: z.string().optional().nullable(),
  make: z.string().optional().nullable(),
  rfidTag1: z.string().optional().nullable(),
  rfidTag2: z.string().optional().nullable(),
  ...optionalMeta
});

export const RTLSAssetSchema = z.object({
  ...optionalId,
  readerIp: z.string().min(1, "required"),
  readPointName: z.string().min(1, "required"),
  antennaId: z.string().min(1, "required"),
  itvId: z.number().min(1, "required"),
  readerType: z.string().min(1, "required"),
  readerModel: z.string().min(1, "required"),
  locationId: z.number().min(1, "required"),
  latitude: z.string().min(1, "required"),
  longitude: z.string().min(1, "required"),
  userId: z.string().min(1, "required"),
  ...optionalMeta
});

export const EquipmentPoolSchema = z.object({
  ...optionalId,
  poolName: z.string().min(1, "Pool Name is required"),
  // dispatchState: z.string().optional(),
  // operatingMode: z.string().optional(),
  // jobStartPosition: z.string().optional(),
  ...optionalMeta
});
export const PointofWorkSchema = z.object({
  ...optionalId,
  name: z.string().min(1, { message: "POW Name is required" }),
  pool: z.string().min(1, { message: "POW Name is required" }),
  ...optionalMeta
});


export const WorkInstructionSchema = z.object({
  ...optionalId,
  weight: z.number().min(1, "Weight is required"),
  containerId: z.string()
    .length(11, "Container ID must be exactly 11 characters")
    .refine(
      (val) => /^[a-zA-Z]{4}\d{7}$/.test(val),
      "First 4 letters, last 7 digits required"
    )
    .transform((val) => val.toUpperCase()),
  isoCode: z.string().min(1, "Equipement type is required"),
  moveType: z.string().min(1, "Move type is required"),
  mode: z.string().min(1, "Mode is required"),
  inboundLocationType: z.string().nullable().optional(),
  vesselVisitId: //z.number().min(1, "Vessel Visit is required"),
    z.preprocess(
      (val) => {
        // Accept strings or numbers and try to convert to number
        const num = typeof val === "string" ? parseInt(val, 10) : val;
        return isNaN(num as number) ? undefined : num;
      },
      z.number().min(1, "Visit Ref is required")
    ),
  outboundLocationType: z.string().nullable().optional(),
  outboundCarrier: z.string().nullable().optional(),
  fromLocation: z.string().min(1, "From Location is required"),
  targetLocation: z.string().min(1, "To Location is required"),
  pointOfWorkId: z.preprocess(
    (val) => {
      // Accept strings or numbers and try to convert to number
      const num = typeof val === "string" ? parseInt(val, 10) : val;
      return isNaN(num as number) ? undefined : num;
    },
    z.number().min(1, "POW is required")
  ),
  assignedChe: z.string().min(1, "CHE put is required"),
  cheCarry: z.string().min(1, "CHE Carry is required"),
  positionOnCarriage: z.string().min(1, "Pos On Chassis is required"),
  workInstructionStatus: z.string().min(1, "Status is required"),
  jobSteppingStatus: z.string().min(1, "Job Stepping Status is required"),
  deck: z.string().min(1, "Deck is required"),
  assignedLane: z.string().min(1, "Assigned Lane is required"),
  ...optionalMeta,
});


export const WorkInstructionImportSchema = z.object({
  ...optionalId,
  containerId: z.string()
    .length(11, "Container ID must be exactly 11 characters")
    .refine(
      (val) => /^[a-zA-Z]{4}\d{7}$/.test(val),
      "First 4 letters, last 7 digits required"
    )
    .transform((val) => val.toUpperCase()),
  isoCode: z.string().min(1, "Equipement type is required"),
  moveType: z.string().min(1, "Move type is required"),
  mode: z.string().min(1, "Mode is required"),
  inboundLocationType: z.string().nullable().optional(),
  vesselVisitId: z.string().min(1, "IB Carrier is required"),
  // z.preprocess(
  //   (val) => {
  //     // Accept strings or numbers and try to convert to number
  //     const num = typeof val === "string" ? parseInt(val, 10) : val;
  //     return isNaN(num as number) ? undefined : num;
  //   },
  //   z.number().min(1, "Visit Ref is required")
  // ),
  outboundLocationType: z.string().nullable().optional(),
  outboundCarrier: z.string().nullable().optional(),
  fromLocation: z.string().min(1, "From Location is required"),
  targetLocation: z.string().min(1, "To Location is required"),
  pointOfWorkId: z.string().min(1, "POW is required"),
  //   (val) => {
  // Accept strings or numbers and try to convert to number
  //     const num = typeof val === "number" ? parseInt(val, 10) : val;
  //     return isNaN(num as number) ? undefined : num;
  //   },
  //   z.number().min(1, "POW is required")
  // ),
  assignedChe: z.string().min(1, "CHE put is required"),
  cheCarry: z.string().min(1, "CHE Carry is required"),
  positionOnCarriage: z.string().min(1, "Pos On Chassis is required"),
  workInstructionStatus: z.string().min(1, "Status is required"),
  jobSteppingStatus: z.string().min(1, "Job Stepping Status is required"),
  deck: z.string().min(1, "Deck is required"),
  assignedLane: z.string().min(1, "Assigned Lane is required"),
  weight: z.number().min(1, "Weight is required"),
  ...optionalMeta
});

export const PowAssignmentSchema = z.object({
  ...optionalId,
  powId: z.number().min(1, "POW is required"),
  equipmentPoolId: z.number().min(1, "Equipment Pool is required"),
  equipmentPoolStatus: z.boolean(),
  ...optionalMeta
});

export const EquipmentPoolAssignmentSchema = z.object({
  ...optionalId,
  equipmentPoolId: z.number().min(1, "Equipment Pool is required"),
  equipmentId: z.number().min(1, "Equipment is required"),
  assignmentStatus: z.boolean(),
  equipmentAssignedDate: z.string().min(1, "Assigned Date is required"),
  ...optionalMeta
});


export const FileImportSchema = z.object({
  file: z
    .instanceof(FileList)
    .refine((files) => files.length === 1, "File is required")
    .refine(
      (files) =>
        files[0]?.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Invalid file type. Please upload an Excel file."
    ),
});