import { RouteItem, routesList } from "@/routes";
import { ChevronDown, ChevronRight } from "lucide-react";
import { memo, useContext, useState } from "react";
import { NavLink } from "react-router";
import {
  Sidebar,
  SidebarContent,
  SidebarContext,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger
} from "./ui/sidebar";
import logo from '../../src/asset/Igo_Nlogo_alone.png'
const FakeLink = memo(({ title, url, icon, subItems }: RouteItem) => {
  const ctx = useContext(SidebarContext)
  const { open, setOpen, toggleSidebar } = ctx
  const ItemIcon = icon;
  return (
    <SidebarMenuButton
      asChild
      tooltip={{
        children: (
          <div className="flex items-center space-x-1">
            <span>{title}</span>
          </div>
        ),
        className: "bg-muted text-muted-foreground dark:text-muted-foreground ",
      }}
    >
      <NavLink
        to={url}
        // onClick={toggleSidebar}
        className={({ isActive }) => (isActive ? "text-primary hover:" : "")}
      >
        {ItemIcon && (
          <ItemIcon
            className="ml-0.5 text-[#FFA500] font-extrabold hover:text-[#D66D1A] hover:scale-110 transition-all duration-200 ease-in-out"
            size={16}
          />
        )}
        <span className="hover-text-black">{title}</span>
      </NavLink>
    </SidebarMenuButton>
  );
});

const SidebarSubMenus = ({ item, isOpen, setIsOpen }) => {
  const ctx = useContext(SidebarContext)
  const { open, setOpen, toggleSidebar } = ctx
  const hasSubItems = item?.subItems && item?.subItems?.length > 0;
  if (!open) {
    setIsOpen(false)
  }
  return (
    <div>
      <SidebarMenuButton
        onClick={() => {
          // if (!isOpen) {
          setOpen(true);
          setIsOpen(!isOpen);
          // }

        }}

        className="flex justify-between w-full"
      >
        <div className="flex  space-x-1">
          {item.icon && <item.icon size={19} className="mr-0.5 text-[#FFA500] font-extrabold hover:text-[#D66D1A] hover:scale-110 transition-all duration-200 ease-in-out"
          />}
          <span className="pl-0.5 whitespace-nowrap">{item.title}</span>
        </div>
        {hasSubItems && (isOpen ? <ChevronDown /> : <ChevronRight />)}
      </SidebarMenuButton>
      {hasSubItems && isOpen && (
        <div className={!open ? "pl-1" : (item.title === "Asset" ? "pl-3" : "pl-9")}>
          {item?.subItems?.map((subItem: unknown) => (
            <SidebarNestedItem key={subItem.url} item={subItem} />
          ))}
        </div>
      )}
    </div>
  );
};

const SidebarNestedItem = ({ item }) => {
  const [isOpen, setIsOpen] = useState(false);
  const hasSubItems = item.subItems && item.subItems.length > 0;
  console.log(" hasSubItems ", hasSubItems, item);

  if (!hasSubItems) {
    return (
      <SidebarMenuItem key={item.url} >
        <FakeLink {...item} />
      </SidebarMenuItem>
    );
  }
  return <SidebarSubMenus item={item} isOpen={isOpen} setIsOpen={setIsOpen} />;
};

const AppSidebarV2 = memo(function AppSidebarV2() {
   const ctx = useContext(SidebarContext)
  const { open } = ctx
  return (
    <div className="bg-[#2C427E]">
      <Sidebar variant="sidebar" collapsible="icon" className="border-none  fixed ">
  <SidebarHeader className="h-[64px] w-full  bg-white">
          <div className="flex items-center h-full">
            {open ? (
              <div className="flex items-center transition-all duration-300 ease-in-out">
                <img
                  src={logo}
                  className="h-16 mr-2 object-cover transform transition-all duration-300 ease-in-out"
                  alt="Full Logo"
                />
                <span className="text-lg font-semibold text-blue-900 inline-flex items-center">
                  <span className="relative inline-block w-[0.6ch] align-middle">
                    <span className="absolute  left-1/3 transform -translate-x-1/3 w-[5px] h-[5px] bg-orange-500 rounded-full"></span>
                    <span className="text-[20px] font-bold pb-2">l</span>
                  </span>
                  <span className="pb-0.5"><span className="text-[24px] font-bold ">go</span> Solutions</span>
                </span>

              </div>
            ) : (
              <div
                className="flex items-center transition-all duration-300 ease-in-out"
                role="group"
              >
                <img
                  src={logo}
                  className="h-[40px] bg-transparent object-fit w-[50px] transform transition-all duration-300 ease-in-out"
                  alt="Icon Logo"
                />
              </div>
            )}
          </div>
        </SidebarHeader>
        <SidebarContent>
          
          <SidebarGroup>
            {/* <SidebarGroupLabel className="text-slate-400">Application</SidebarGroupLabel> */}
            <SidebarGroupContent>
              <SidebarMenu>
                {routesList.map((item) => (
                  <SidebarMenuItem key={item.title} className="text-white">
                    {item.subItems ? (
                      <SidebarNestedItem item={item} />
                    ) : (
                      <FakeLink {...item} />
                    )}
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter />
      </Sidebar>
    </div>

  );
});



export default AppSidebarV2