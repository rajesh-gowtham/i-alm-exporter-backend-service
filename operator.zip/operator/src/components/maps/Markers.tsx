import { memo } from "react";
import { AdvancedMarker } from "@vis.gl/react-google-maps";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type LocationMarkerProps<T = any> = {
  latitude: number;
  longitude: number;
  data?: T;
  title?: string | null;
  color?: string;
  size?: number;
  onClick?: (lat: number, lng: number, data?: T) => void;
};

export const LocationMarker = ({
  latitude,
  longitude,
  data,
  title,
  color = "#1dbe80",
  size = 8,
  onClick,
}: LocationMarkerProps) => {
  return (
    <AdvancedMarker
      onClick={() => onClick && onClick(latitude, longitude, data)}
      position={{ lat: latitude, lng: longitude }}
      title={title}
    >
      <MarkerShape color={color} size={size} />
    </AdvancedMarker>
  );
};

const MarkerShape = memo(function MarkerShape({
  color,
  size,
}: {
  color: string;
  size: number;
}) {
  return (
    <div
      style={{
        width: size,
        height: size,
        position: "absolute",
        top: 0,
        left: 0,
        background: color,
        border: `1px solid ${color}`,
        borderRadius: "50%",
        transform: "translate(-50%, -50%)",
      }}
    />
  );
});
