import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { InputLogin } from "@/components/ui/input";

import axiosInstance from "@/lib/http-client";
import { AuthResponse } from "@/lib/models";
import useAuthStore from "@/lib/stores/auth-stores";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Navigate, useNavigate } from "react-router";
import { toast } from "sonner";
import { z } from "zod";
import igoLogo from '../../src/asset/igo-logo.png';
import rtlsImage from '../../src/asset/loginlogo.png';
import { PasswordField } from "./password-field";

const formSchema = z.object({
  email: z.string().email({ message: "Invalid email address." }),
  password: z.string().min(6, { message: "Password must be at least 6 characters." }),
});

export function LoginForm() {
  const navigate = useNavigate();
  const authStore = useAuthStore();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "operator@rtls.com",
      password: "Safety@2025",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      const response = await axiosInstance.post<AuthResponse>("/auth/login", values);
      if (response.status === 200) {
        authStore.logIn(response.data.accessToken);
        navigate('/');
      } else {
        toast.error("Login failed. Please check your credentials.");
      }
    } catch (error) {
      toast.error("An unexpected error occurred.");
      console.error(error);
    }
  }

  return authStore.getIsAuthorized() ? (
    <Navigate to="/" replace />
  ) : (
    <div style={{ backgroundColor: "#dff5f6" }} className="min-h-screen">
      <div className="min-h-screen flex items-center justify-center relative">

        {/* Full-screen image */}
        <img
          src={rtlsImage}
          alt="RTLS"
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />

        {/* Overlay with the text */}
        <div className="absolute inset-0 bg-white bg-opacity-5 flex flex-col pt-12 text-white">
          <h1 className="text-5xl font-extrabold mb-6 text-center bg-[#2A4682] bg-clip-text text-transparent">
            RTLS
          </h1>
          <div className="flex space-x-4 text-[24px] items-center justify-center font-bold pb-3 -mt-4">
            <span className="text-[#2A4682] hover:text-[#1B2B56] transition-colors cursor-default">Track</span>
            <span className="text-[#EA8328]">|</span>
            <span className="text-[#2A4682] hover:text-[#1B2B56] transition-colors cursor-default">Monitor</span>
            <span className="text-[#EA8328]">|</span>
            <span className="text-[#2A4682] hover:text-[#1B2B56] transition-colors cursor-default">Optimize</span>
            <span className="text-[#EA8328]">|</span>
            <span className="text-[#2A4682] hover:text-[#1B2B56] transition-colors cursor-default">Decarbonize</span>
          </div>
        </div>

        {/* Form container */}
        <div className="absolute inset-0 flex items-center justify-center px-4 pt-20">
          <div className="bg-white rounded-3xl shadow-lg w-full max-w-md p-8">
            {/* Header */}
            <div className="flex flex-col items-center space-y-4 mb-6">
              <img src={igoLogo} alt="Logo" className="w-20 h-auto object-cover op" />
              <h2 className="text-center text-2xl font-bold text-blue-900">RTLS OPERATOR</h2>
            </div>

            {/* Form */}
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-10">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <InputLogin placeholder="Email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <PasswordField placeholder="Password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full h-8 text-base font-semibold">
                  Login
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>

  );
}
