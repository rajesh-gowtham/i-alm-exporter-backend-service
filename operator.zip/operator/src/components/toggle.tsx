import { cn } from "@/lib/utils";
import { ClassValue } from "clsx";
import { ToggleLeft, ToggleRight } from "lucide-react";
import { useState } from "react";

type ToggleProps = {
  onToggle?: (state: boolean) => void;
  className?: ClassValue;
};

export function Toggle({ onToggle, className }: ToggleProps) {
  const [isToggled, setIsToggled] = useState<boolean>(false);

  const handleToggle = () => {
    const newState = !isToggled;
    setIsToggled(newState);
    onToggle?.(newState);
  };

  return (
    <div
      className={cn("relative cursor-pointer", className)}
      onClick={handleToggle}
    >
      <ToggleLeft
        className={cn(
          "absolute w-full h-full transition-all duration-150",
          isToggled ? "fade-out-0 scale-0" : "fade-in-100 scale-100"
        )}
        strokeWidth={1}
      />
      <ToggleRight
        className={cn(
          "absolute w-full h-full transition-all duration-150",
          isToggled ? "fade-in-100 scale-100" : "fade-out-0 scale-0"
        )}
        strokeWidth={1}
      />
    </div>
  );
}
