import * as React from "react";
import { addDays, format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { DateRange } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

type Props = {
  dateRange?: DateRange | undefined;
  onDateRangeChange?: (dateRange: DateRange | undefined) => void;
  disabled?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;

export function DatePickerWithRange({
  dateRange,
  onDateRangeChange,
  className,
  disabled = false,
}: Props) {
  const [date, setDate] = React.useState<DateRange | undefined>(dateRange);
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <div className={cn("flex justify-end", className)}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-[300px] justify-start text-left font-normal rounded-3xl",
              !date && "text-muted-foreground"
            )}
            disabled={disabled}
          >
            <CalendarIcon />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, "LLL dd, y")} -{" "}
                  {format(date.to, "LLL dd, y")}
                </>
              ) : (
                format(date.from, "LLL dd, y")
              )
            ) : (
              <span>Pick a date</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            max={31}
            selected={date}
            disabled={(date) => {
              return date > new Date();
            }}
            onSelect={(range, selectedDay, modifiers) => {
              // console.log("[range] range", range);
              // console.log("[range] selectedDay", selectedDay);
              // console.log("[range] modifiers", modifiers);
              setDate(range);
            }}
            numberOfMonths={1}
            footer={
              <div className="flex justify-center space-x-2">
                <Button
                  variant="ghost"
                  onClick={() => {
                    setDate(undefined);
                    onDateRangeChange?.(undefined);
                  }}
                >
                  Clear
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => {
                    onDateRangeChange?.(date);
                    setIsOpen(false);
                  }}
                >
                  Apply
                </Button>
              </div>
            }
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
