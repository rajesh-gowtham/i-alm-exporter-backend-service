"use client";

import { CalendarIcon } from "@radix-ui/react-icons";
import { format } from "date-fns";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { InputTime } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { DATE_TIME_FORMAT } from "@/lib/constants";

type DateTimePickerProps = {
  date: Date | null;
  onDateChange: (date: Date) => void;
  error?: boolean;
};

export function DateTimePicker({ date, onDateChange, error }: DateTimePickerProps) {
  const [isOpen, setIsOpen] = React.useState<boolean>(false);
  const [time, setTime] = React.useState<string>(
    date ? format(date, "HH:mm") : "00:00"
  );
  React.useEffect(() => {
    if (date) {
      const formattedTime = format(date, "HH:mm");
      setTime(formattedTime);
    }
  }, [date]);

  const handleDateSelect = (selectedDate?: Date) => {
    if (selectedDate) {
      const finalDate = new Date(selectedDate);
      if (time) {
        const [hh, mm] = time.split(":").map(Number);
        finalDate.setHours(hh || 0, mm || 0);
      }
      onDateChange(finalDate);
    }
  };

  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTime(value);

    if (date) {
      const [hh, mm] = value.split(":").map(Number);
      const updatedDate = new Date(date);
      updatedDate.setHours(hh || 0, mm || 0);
      onDateChange(updatedDate);
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "w-full justify-start text-left font-normal",
            !date && "text-muted-foreground",
            error
              ? "border-red-400 focus-visible:ring-[0.5px] focus-visible:ring-red-300 focus-visible:border-red-500"
              : "border-input focus-visible:ring-1 focus-visible:ring-ring"
          )}
        >
          <CalendarIcon color="#9ca3af" className="mr-2 h-4 w-4" />
          {date
            ? format(date, DATE_TIME_FORMAT)
            : <span className="text-gray-400 text-xs lowercase">{DATE_TIME_FORMAT}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <div className="sm:flex">
          <Calendar
            mode="single"
            selected={date ?? undefined}
            onSelect={handleDateSelect}
            initialFocus
          />
          <div className="flex flex-col items-center justify-start px-4 pt-4 w-full sm:w-40">
            <label htmlFor="time-input" className="text-sm mb-2 font-semibold">
              Time (HH:mm)
            </label>
            <InputTime
              type="text"
              value={time}
              onChange={(e) => { setTime(e.target.value) }}
              onBlur={handleTimeChange}
            />
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

// "use client";

// import * as React from "react";
// import { CalendarIcon } from "@radix-ui/react-icons";
// import { format } from "date-fns";

// import { cn } from "@/lib/utils";
// import { Button } from "@/components/ui/button";
// import { Calendar } from "@/components/ui/calendar";
// import {
//   Popover,
//   PopoverContent,
//   PopoverTrigger,
// } from "@/components/ui/popover";
// import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

// type DateTimePickerProps = {
//   date: Date | null;
//   onDateChange: (date: Date) => void;
// };

// export function DateTimePicker({ date, onDateChange }: DateTimePickerProps) {
//   const [isOpen, setIsOpen] = React.useState<boolean>(false);

//   const hours: number[] = Array.from({ length: 12 }, (_, i) => i + 1);

//   const handleDateSelect = (selectedDate?: Date) => {
//     if (selectedDate) {
//       onDateChange(selectedDate);
//     }
//   };

//   const handleTimeChange = (type: "hour" | "minute" | "ampm", value: string) => {
//     if (date) {
//       const newDate = new Date(date);
//       if (type === "hour") {
//         newDate.setHours((parseInt(value, 10) % 12) + (newDate.getHours() >= 12 ? 12 : 0));
//       } else if (type === "minute") {
//         newDate.setMinutes(parseInt(value, 10));
//       } else if (type === "ampm") {
//         const currentHours = newDate.getHours();
//         newDate.setHours(value === "PM" ? (currentHours % 12) + 12 : currentHours % 12);
//       }
//       onDateChange(newDate);
//     }
//   };

//   return (
//     <Popover open={isOpen} onOpenChange={setIsOpen}>
//       <PopoverTrigger asChild>
//         <Button
//           variant="outline"
//           className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
//         >
//           <CalendarIcon color="#9ca3af" className="mr-2 h-4 w-4" />
//           {date ? format(date, "MM/dd/yyyy hh:mm aa") : <span className="text-gray-400 text-xs">MM/DD/YYYY hh:mm aa</span>}
//         </Button>
//       </PopoverTrigger>
//       <PopoverContent className="w-auto p-0">
//         <div className="sm:flex">
//           <Calendar mode="single" selected={date ?? undefined} onSelect={handleDateSelect} initialFocus />
//           <div className="flex flex-col sm:flex-row sm:h-[300px] divide-y sm:divide-y-0 sm:divide-x">
//             {/* Hours */}
//             <ScrollArea className="w-64 sm:w-auto">
//               <div className="flex sm:flex-col p-2">
//                 {hours.reverse().map((hour) => (
//                   <Button
//                     key={hour}
//                     size="icon"
//                     variant={date && date.getHours() % 12 === hour % 12 ? "default" : "ghost"}
//                     className="sm:w-full shrink-0 aspect-square"
//                     onClick={() => handleTimeChange("hour", hour.toString())}
//                   >
//                     {hour}
//                   </Button>
//                 ))}
//               </div>
//               <ScrollBar orientation="horizontal" className="sm:hidden" />
//             </ScrollArea>

//             {/* Minutes */}
//             <ScrollArea className="w-64 sm:w-auto">
//               <div className="flex sm:flex-col p-2">
//                 {Array.from({ length: 12 }, (_, i) => i * 5).map((minute) => (
//                   <Button
//                     key={minute}
//                     size="icon"
//                     variant={date && date.getMinutes() === minute ? "default" : "ghost"}
//                     className="sm:w-full shrink-0 aspect-square"
//                     onClick={() => handleTimeChange("minute", minute.toString())}
//                   >
//                     {minute}
//                   </Button>
//                 ))}
//               </div>
//               <ScrollBar orientation="horizontal" className="sm:hidden" />
//             </ScrollArea>

//             {/* AM/PM */}
//             <ScrollArea>
//               <div className="flex sm:flex-col p-2">
//                 {["AM", "PM"].map((ampm) => (
//                   <Button
//                     key={ampm}
//                     size="icon"
//                     variant={
//                       date && ((ampm === "AM" && date.getHours() < 12) || (ampm === "PM" && date.getHours() >= 12))
//                         ? "default"
//                         : "ghost"
//                     }
//                     className="sm:w-full shrink-0 aspect-square"
//                     onClick={() => handleTimeChange("ampm", ampm)}
//                   >
//                     {ampm}
//                   </Button>
//                 ))}
//               </div>
//             </ScrollArea>
//           </div>
//         </div>
//       </PopoverContent>
//     </Popover>
//   );
// }
