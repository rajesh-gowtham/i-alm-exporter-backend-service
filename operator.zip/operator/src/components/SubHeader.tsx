import { Upload } from "lucide-react";
import React from "react";
import { BiSolidError } from "react-icons/bi";
import { Button } from "./ui/button";
import { SearchInput } from "./ui/input";

interface HeaderProps {
    placeholder: string;
    searchValue: string;
    onSearchChange: (value: string) => void;
    addButtonLabel: string;
    isButtonDisabled?: boolean;
    importNavigationUrl?: string
    onAddClickOpen?: (value: boolean) => void;
    setComponentToEdit?: (value: undefined) => void;
    openCloseImport?: (arg: string) => void;
    isImportError?: boolean;
    errorList?: any[];
    isAddBtnDisabled?: boolean;
    isImportBtnDisabled?: boolean;
    // importErrorOnclick: () => void;
}

const SubHeader: React.FC<HeaderProps> = ({
    placeholder,
    searchValue,
    onSearchChange,
    addButtonLabel,
    isButtonDisabled,
    importNavigationUrl,
    onAddClickOpen,
    setComponentToEdit,
    openCloseImport,
    isImportError,
    errorList,
    isAddBtnDisabled,
    isImportBtnDisabled
}) => {
    // const navigate = useNavigate();

    return (
        <div className="flex justify-between mb-2 px-4 space-x-2 mt-1">
            <SearchInput
                type="search"
                placeholder={placeholder}
                value={searchValue}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => onSearchChange(e.target.value)}
                className="w-1/3 placeholder:text-black/40"
            />
            <div className="flex space-x-2">
                {isImportError && <Button
                    title={`${errorList?.length} Errors`}
                    size="sm"
                    variant="outline"
                    className="text-red-700 space-x-0 hover:text-white bg-red-300 hover:bg-red-600"
                    // onClick={() => navigate(`${importNavigationUrl}`)}
                    onClick={() => { openCloseImport("") }}
                >
                    <span className="flex">
                        <BiSolidError title={`${errorList?.length} Errors`} />
                        <span className="-mt-1.5 ">{errorList?.length}</span>
                    </span>

                </Button>
                }
                {/* {(!isImportBtnDisabled) && <Button
                    title="Import"
                    size="sm"
                    variant="outline"
                    disabled={isButtonDisabled}
                    className="hover:bg-[#EE9028]"
                    // onClick={() => navigate(`${importNavigationUrl}`)}
                    onClick={openCloseImport}
                >
                    <Upload />
                </Button>
                }
                {
                    (!isAddBtnDisabled) &&
                    <Button
                        title="Add"
                        size="sm"
                        disabled={isButtonDisabled}
                        className="bg-[#2C427D] text-white hover:bg-[#EE9028] text-lg pb-1  flex justify-center items-center"
                        onClick={() => {
                            onAddClickOpen(true);
                            setComponentToEdit(undefined);
                        }}
                    >
                        {addButtonLabel}
                    </Button>

                } */}
            </div>
        </div>
    );
};

export default SubHeader;
