import { useState } from "react";

export const EditableCell = ({
  value: initialValue,
  row: { index },
  column: { id },
  isNumeric,
  updateData,
}: {
  value: any;
  row: { index: number };
  column: { id: string };
  isNumeric: boolean;
  updateData: (rowIndex: number, columnId: string, value: any) => void;
}) => {
  const [value, setValue] = useState(initialValue);

  const handleBlur = () => {
    const processedValue = isNumeric ? 
      Number(value.toString().replace(/[^0-9.]/g, '')) : 
      value;
    updateData(index, id, processedValue);
  };

  return (
    <input
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onBlur={handleBlur}
      className={`w-full p-2 bg-muted border focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
        isNumeric ? "text-right font-mono" : ""
      }`}
      type={isNumeric ? "number" : "text"}
    />
  );
};
