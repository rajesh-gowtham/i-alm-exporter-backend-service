import { DialogDescription, DialogTitle } from '@radix-ui/react-dialog';
import { ReloadIcon } from '@radix-ui/react-icons';
import { Info } from 'lucide-react'; // or any icon of your choice
import React, { useState } from 'react';
import 'react-resizable/css/styles.css';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface Column {
  Header: string;
  accessor: string;
  width?: number;
}

interface EditableCellProps {
  value: any;
  row: { index: number };
  column: { id: string };
  isNumeric: boolean;
  updateData: (rowIndex: number, columnId: string, value: any) => void;
  error?: string;
}


const EditableCell: React.FC<EditableCellProps> = ({
  value,
  row,
  column,
  isNumeric,
  updateData,
  error,
}) => {
  return (
    <div className="relative w-full flex items-center group">
      <input
        type={isNumeric ? 'number' : 'text'}
        className={`w-full px-2 py-1 outline-none pr-6 ${error ? 'border border-red-500' : 'border border-gray-300'
          }`}
        value={value ?? ''}
        onChange={(e) =>
          updateData(
            row.index,
            column.id,
            isNumeric ? Number(e.target.value) : e.target.value
          )
        }
      />

      {/* Error icon + tooltip */}
      {error && (
        <div className="absolute z-50 right-1 top-1/2 -translate-y-1/2 flex items-center">
          <div className="relative group">
            <Info className="w-4 h-4 text-red-500 cursor-pointer" />

            {/* Tooltip */}
            <div className="absolute z-[999] w-max max-w-xs p-2 text-xs text-white bg-red-600 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 -top-2 left-5">
              {error}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


interface Props {
  columns: Column[];
  tableData: any[];
  updateData: (rowIndex: number, columnId: string, value: any) => void;
  validationErrors: any[];
  validRecords: any[];
  batchProcessing: boolean;
  setShowConfirmModal: React.Dispatch<React.SetStateAction<boolean>>;
  importProgress: number;
  batchInsert: (arg: any[]) => void;
  numericFields?: string[]
}

const FileImportManipulate: React.FC<Props> = ({
  columns,
  tableData,
  updateData,
  validationErrors,
  validRecords,
  batchProcessing,
  setShowConfirmModal,
  importProgress,
  batchInsert,
  numericFields
}) => {
  const [isErrorViewClicked, setisErrorViewClicked] = useState(false)
  const [colWidths, setColWidths] = useState<Record<string, number>>(
    () => Object.fromEntries(columns.map((col) => [col.accessor, col.width ?? 200]))
  );

  const handleMouseDown = (accessor: string, e: React.MouseEvent) => {
    const startX = e.clientX;
    const startWidth = colWidths[accessor];

    const onMouseMove = (e: MouseEvent) => {
      const newWidth = Math.max(80, startWidth + (e.clientX - startX));
      setColWidths((prev) => ({ ...prev, [accessor]: newWidth }));
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };
  function getFieldError(rowError: any, accessor: string): string | undefined {
    const rawErrors = rowError?.original?.__rowErrors;
    console.log("rowError ", rowError, accessor);
    // if (rowError?.issues) {
    const findItem = rowError?.issues?.find(item => item?.path?.includes(accessor));
    console.log("vesselVisitId findItem ", findItem);
    if (findItem) {
      return findItem?.message
    }
    // }
    // Case 1: ZodIssue[]
    if (Array.isArray(rawErrors)) {
      const issue = rawErrors.find((err) => Array.isArray(err.path) && err.path[0] === accessor);
      return issue?.message;
    }

    // Case 2: Record<string, string[]>
    if (rawErrors && typeof rawErrors === 'object') {
      const fieldErrors = rawErrors[accessor];
      return Array.isArray(fieldErrors) ? fieldErrors[0] : undefined;
    }
    console.log(rowError, accessor);
    return undefined;
  }
  return (

    <div>
      <div className="p-6 border-b">
        <DialogTitle className="text-lg font-semibold">
          Manipulate Data
        </DialogTitle>
        <DialogDescription>
          Edit cells directly and review errors before import
        </DialogDescription>
      </div>
      <div className="gap-6 p-6 space-y-4 overflow-auto lg:grid-cols-2">
        <div className="flex flex-col w-full space-y-4 space-x-3 overflow-hidden">
          <div className="p-2 w-1/3 border border-gray-200 rounded-lg bg-muted">
            <h3 className="mb-3 font-medium text-gray-700">Validation Summary</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Row(s) Processed:</span>
                <span className="font-medium text-green-600">{validRecords.length}</span>
              </div>
              <div onClick={() => setisErrorViewClicked(prev => !prev)} className="flex items-center underline decoration-blue-700 cursor-pointer justify-between">
                <span className="text-gray-600 ">Errors:</span>
                <span className="font-medium text-red-600">{validationErrors.length}</span>
              </div>
            </div>
          </div>
          {validationErrors.length > 0 && isErrorViewClicked && (
            <div className="p-4 w-2/3 overflow-auto border border-red-200 rounded-lg bg-muted">
              <h4 className="mb-3 font-medium text-red-700">Validation Errors</h4>
              <div className="space-y-3">
                {validationErrors.map((error, index) => (
                  <div key={index} className="p-3 border border-red-100 rounded bg-muted">
                    <div className="flex flex-col items-start mb-2">
                      <span className="mr-2 font-mono whitespace-normal text-red-600">Row {error.row - 1}:</span>
                      <div className="flex flex-wrap gap-1">
                        {error.issues.map((issue: any) => (
                          <span
                            key={issue.path.join(".")}
                            className="px-2 py-1 text-xs text-red-800 bg-red-100 rounded"
                          >
                            {issue.code === 'invalid_type' ?
                              `Invalid type for ${issue.path.join('.')}` :
                              issue.message}
                          </span>
                        ))}
                      </div>
                    </div>
                    {/* <div className="space-y-1 text-sm text-gray-600">
                          {Object.entries(error.original).map(([key, value]) => (
                            <div key={key} className="flex items-baseline">
                              <span className="w-24 font-medium text-gray-500 truncate">{key}:</span>
                              <span className="flex-1 ml-2 font-mono text-gray-700">{String(value)}</span>
                            </div>
                          ))}
                        </div> */}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col h-full border lg:border-0">
          <div className="p-4 border-b border-gray-200 bg-muted">
            <h3 className="font-medium text-gray-700">
              Excel Preview
              <span className="ml-2 text-sm font-normal text-gray-500">(Editable cells)</span>
            </h3>
          </div>

          <div className="overflow-auto max-h-[500px] max-w-full border border-gray-300 rounded">
            <table className="table-fixed border-collapse min-w-max">
              <thead>
                <tr>
                  <th className="sticky top-0 bg-gray-100 border border-gray-300 text-left px-2 w-20 z-10">
                    Sl. No
                  </th>
                  {columns.map((column) => (
                    <th
                      key={column.accessor}
                      className="sticky top-0 bg-gray-100 border border-gray-300 text-left px-2 z-10 relative group"
                      style={{ width: colWidths[column.accessor] }}
                    >
                      <div className="flex justify-between items-center pr-2">
                        <span>{column.Header}</span>
                        <div
                          className="w-2 h-full cursor-col-resize absolute right-0 top-0 group-hover:bg-blue-200"
                          onMouseDown={(e) => handleMouseDown(column.accessor, e)}
                        />
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {tableData.map((row, rowIndex) => {
                  const rowError = validationErrors.find((e) => e.row === rowIndex + 2);
                  return (
                    <tr
                      key={rowIndex}
                      className={rowError ? 'bg-red-100 ' : 'hover:bg-gray-50'}
                    >
                      <td className="border border-gray-200 px-2 text-sm text-gray-600">
                        {rowIndex + 1}
                      </td>
                      {columns.map((column) => {
                        // const error = rowError?.original?.__rowErrors[column.accessor];
                        const error = getFieldError(rowError, column.accessor);
                        console.log(numericFields, row, column);

                        const isNumeric = numericFields ? numericFields?.includes(column.accessor) : typeof row[column.accessor] === 'number';
                        return (
                          <td
                            key={column.accessor}
                            className="border border-gray-200"
                            style={{ width: colWidths[column.accessor] }}
                          >
                            <EditableCell
                              value={row[column.accessor]}
                              row={{ index: rowIndex }}
                              column={{ id: column.accessor }}
                              isNumeric={isNumeric}
                              updateData={updateData}
                              error={error}
                            />
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-3 p-4 border-t bg-muted">
        <div className="flex justify-end gap-3">
          <Button
            variant="outline"
            onClick={() => setShowConfirmModal(false)}
            className="px-4 text-gray-700 border-gray-300 hover:bg-muted"
            disabled={batchProcessing}
          >
            Cancel
          </Button>
          <Button
            onClick={() => batchInsert(validRecords)}
            className="px-6 text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
            disabled={validRecords.length === 0 || batchProcessing}
          >
            {batchProcessing ? (
              <div className="flex items-center gap-2">
                <ReloadIcon className="w-4 h-4 animate-spin" />
                Importing ({Math.round(importProgress)}%)
              </div>
            ) : (
              `File Import`
            )}
          </Button>
        </div>
        {batchProcessing && (
          <div className="w-full mt-2">
            <Progress value={importProgress} className="h-2" />
            <p className="mt-1 text-xs text-center text-gray-500">
              {Math.round(importProgress)}% completed
            </p>
          </div>
        )}
      </div>
    </div>


  );
};

export default FileImportManipulate;