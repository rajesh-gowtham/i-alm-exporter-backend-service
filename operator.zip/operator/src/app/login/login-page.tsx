import { LoginForm } from "@/components/login-form";
import { useEffect } from "react";
import { GlobeDemo } from "./globe-bg";

export default function LoginPage() {
  useEffect(() => { }, []);

  return (
    <div className="bg-white dark:bg-black">
          <LoginForm />
    </div>
  );
}
