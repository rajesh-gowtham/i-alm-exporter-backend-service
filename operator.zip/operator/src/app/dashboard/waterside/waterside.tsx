'use client'
import { DataTable } from "@/app/management/data-table";
import Map from "@/app/map/WaterSideDashboardMap";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CardType, ChartComponentProps, ChartItem, CustomLabelProps, DashboardPayload, LayoutProps, QcDetails, StyledGaugeFullProps, VesselInfo } from "@/lib/models";
import { fetchWatersideData } from "@/lib/services/waterside-service";
import { formatCustomDateTime, formatHeader } from "@/lib/utils";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { memo, useContext, useEffect, useMemo, useRef, useState } from "react";
import {
    Bar,
    BarChart,
    Cell,
    Legend,
    Pie,
    PieChart,
    ResponsiveContainer,
    Tooltip,
    TooltipProps,
    XAxis,
    YAxis
} from 'recharts';
import useSWR, { mutate } from "swr";
import { BarChart2 } from "../chart-preview";
import { SidebarContext } from "@/components/ui/sidebar";
// import { Bar} from 'react-chartjs-2';

const Waterside = () => {
    const [loading, setLoading] = useState(false);
    const [title, setTitle] = useState('');
    const [activeQCs, setActiveQCs] = useState<string[]>([])
    const [paged, setPaged] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 5,
        search: ""
    });
    const fetchData = async (payload: DashboardPayload): Promise<{
        card: CardType[];
        jobInfos: ChartItem[];
        vesselInfo: VesselInfo[];
        QcDetails: QcDetails;
    }> => {
        console.log(payload)
        const data = await fetchWatersideData(payload);
        const cardKeys = {
            activeQc: "Asset",
            vesselOnBerth: "Vessel(s) on Berth",
            totalJobs: "Total Jobs",
            assignedItvs: "Assigned ITV's",
            alerts: "Alerts",
        };
        const barchartKeys = {
            movesCompleted: "Moves Completed",
            movesPending: "Moves Pending"
        }
        const card = Object.keys(cardKeys).map(key => ({
            title: cardKeys[key as keyof typeof cardKeys],
            value: data[key as keyof typeof cardKeys]
        }));

        const jobInfos = (Object.keys(barchartKeys) as (keyof typeof barchartKeys)[]).map((key) => ({
            title: barchartKeys[key],
            value: data.jobInfos[key]
        }));
        const active = data.qcDetails.items
            .filter((item: any) => item.ignition === "ON")
            .map((item: any) => item.asset);
        setActiveQCs(active);
        return {
            card,
            jobInfos,
            vesselInfo: data.vesselInfo,
            QcDetails: data.qcDetails
        };
    };
    const payload = {
        skip: 0,
        take: 5,
        cardName: title
    };

    const { data, isLoading } = useSWR(payload, fetchData, {
        refreshInterval: 25000
    });

    const getSWRKey = (payload: DashboardPayload) =>
        `dashboard-${payload.cardName}-${payload.skip}-${payload.take}`;

    const changegridData = async (title: ChartItem['title'], index: number): Promise<void> => {
        setTitle(title);

        if (index !== 1 && index !== 5 && index !== 3) {
            try {
                setLoading(true);
                const newPayload: DashboardPayload = {
                    cardName: title,
                    skip: 0,
                    take: 5,
                };
                const gridData = await fetchWatersideData(newPayload);
                const swrKey = getSWRKey(newPayload);
                const currentData = await mutate(swrKey, undefined, false);
                mutate(
                    swrKey,
                    {
                        ...(currentData ?? {}),
                        QcDetails: gridData.qcDetails,
                    },
                    false
                );
            } catch (error) {
                console.error("Error updating QC details:", error);
            } finally {
                setLoading(false);
            }
        }
    };

    if (isLoading || !data) return <FullPageLoader />;
    const { card, jobInfos, vesselInfo, QcDetails } = data;
    const qcDetails = QcDetails?.items ?? [];
    const totalCount = QcDetails?.totalCount ?? 0;
    const ctx = useContext(SidebarContext) ?? { open: false };
    const { open } = ctx

    return (
        <>
            <body className="bg-[rgb(244,247,254)]">
                <div className="flex  bg-[rgb(244,247,254)]">
                    {/* <!-- Main Content --> */}
                    <div className="flex flex-col flex-1">
                        {/* <!-- Content --> */}
                        <main className="flex-1 p-2">
                            {/* DASHBOARD  */}
                            <div>
                                <div className="gap-6 grid grid-cols-1 sm:grid-cols-6 lg:grid-cols-6 px-1 pt-1">
                                    {[...card, { title: 'Avg MPH', value: '21' }].map((item, index) => (
                                        <Card
                                            key={index}
                                            className={`h-32 flex bottom-2 flex-col justify-between  bg-[#34658A] ${index !== 1 && index !== 5 && index !== 3 ? 'cursor-pointer' : 'cursor-default'
                                                }`}
                                            onClick={() => {
                                                if (index !== 1 && index !== 5 && index !== 3) {
                                                    changegridData(item.title, index);
                                                }
                                            }}
                                        >
                                            <CardHeader className="flex flex-row items-center justify-between">
                                                <CardTitle className={`${open ? 'text-[14px]' : ''} text-white font-normal`}>{item.title}</CardTitle>
                                                {/* <item.icon className={`h-6 w-6 ${item.color}`} /> */}
                                            </CardHeader>
                                            <CardContent>
                                                <p className="text-4xl font-semibold text-white">{item.value}</p>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>

                            </div>
                            <Layout
                                jobInfos={jobInfos}
                                gridData={qcDetails}
                                getDashboardType={'waterside'}
                                barData={vesselInfo}
                                isloading={loading}
                                totalCount={totalCount}
                                changegridData={changegridData}
                                title={title}
                                activeQCs={activeQCs}
                                setPaged={setPaged}
                            />
                        </main>
                    </div>
                </div>
            </body>
        </>
    );
};

export const Layout = memo((props: LayoutProps) => {
    const { gridData, barData, title, totalCount, isloading, activeQCs, jobInfos, setPaged } = props;
    console.log(title);
    const [paged, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 5,
        search: ""
    });
    const isFirstRender = useRef(true);
    const [tableData, setTableData] = useState(gridData ?? []);
    useEffect(() => {
        isFirstRender.current = true;
        setTableData(gridData ?? []);
        setPagination(prev => ({ ...prev, pageIndex: 0 }));
    }, [gridData, title]);


    const allColumnSets: Record<string, { key: string; title: string; hidden: boolean }[]> = {
        "Active QC's": [
            { key: "qcName", title: "QC Name", hidden: false },
            { key: "berth", title: "Berth", hidden: false },
            { key: "activity", title: "Activity", hidden: false },
            { key: "job", title: "Job", hidden: false },
            { key: "estCompletionTime", title: "Estimated Completion Time", hidden: false },
            { key: "gpsTime", title: "GPS Time", hidden: false },
            { key: "totalMovesCompleted", title: "Total Moves Completed", hidden: false },
            { key: "totalMovesPending", title: "Total Moves Pending", hidden: false },
            { key: "active", title: "Active Time", hidden: false },
            { key: "make", title: "Make", hidden: false },
        ],
        "Total Jobs": [
            { key: "qcName", title: "QC Name", hidden: false },
            { key: "berth", title: "Berth", hidden: false },
            { key: "activity", title: "Activity", hidden: false },
            { key: "job", title: "Job", hidden: false },
            { key: "currentPosition", title: "Current Position", hidden: false },
            { key: "workInstructionStatus", title: "WI Status", hidden: false },
            { key: "jobSteppingStatus", title: "Job Stepping Status", hidden: true },
            { key: "make", title: "Make", hidden: false },
             { key: "startTime", title: "Start Time", hidden: false },
            { key: "endTime", title: "End Time", hidden: false },
            { key: "AssignedItv", title: "Assigned ITV", hidden: false },
        ],
        "Assigned ITV's": [
            { key: "asset", title: "Asset", hidden: false },
            { key: "berth", title: "Berth", hidden: false },
            { key: "activity", title: "Activity", hidden: false },
            { key: "job", title: "Job", hidden: false },
            { key: "estCompletionTime", title: "Estimated Completion Time", hidden: false },
            { key: "gpsTime", title: "GPS Time", hidden: false },
            { key: "assignedItvs", title: "Assigned ITV", hidden: false },
            { key: "make", title: "Make", hidden: false },
        ],
    };

    const columnsConfig = useMemo(() => {
        return allColumnSets[title] || allColumnSets["Active QC's"];
    }, [title]);

   const columns: ColumnDef<any>[] = useMemo(() => {
        const hasData = gridData?.length > 0;
        const keysToUse = hasData
            ? Object.keys(gridData[0])
            : columnsConfig.map(col => col.key);
        let filteredKeys = keysToUse.filter(
            key => !["ignition", "id","notes"].includes(key.toLowerCase())
        );
        const eventNameKey = keysToUse.find(k => k.toLowerCase() === "eventname");
        const gpsTimeKey = keysToUse.find(k => k.toLowerCase() === "gpstime");
        const assignedItv = keysToUse.find(k => k.toLowerCase() === "assigneditv");

        filteredKeys = filteredKeys.filter(k => !["eventname", "gpstime","assigneditv"].includes(k.toLowerCase()));
        const typeIndex = filteredKeys.findIndex(k => k.toLowerCase() === "type");
        if (typeIndex !== -1 && eventNameKey) {
            filteredKeys.splice(typeIndex + 1, 0, eventNameKey);
        }
        const makeIndex = filteredKeys.findIndex(k => k.toLowerCase() === "make");
        if (makeIndex !== -1 && gpsTimeKey) {
            filteredKeys.splice(makeIndex + 1, 0, gpsTimeKey);
        }
         const jobIndex = filteredKeys.findIndex(k => k.toLowerCase() === "job");
        if (jobIndex !== -1 && assignedItv) {
            filteredKeys.splice(jobIndex + 1, 0, assignedItv);
        }
        return filteredKeys.map((item): ColumnDef<any> => {
            const lowerItem = item.toLowerCase();
            const hiddenColumns = ["startTime", "endTime"];
            const baseColumn: ColumnDef<any> = {
                accessorKey: item,
                header: formatHeader(item),
                enableHiding: true,
                meta: { hidden: hiddenColumns.includes(item) }
            };

            if (lowerItem === "asset") {
                return {
                    ...baseColumn,
                    cell: ({ row }) => {
                        const assetValue: string = row.getValue("asset");
                        const ignitionValue = row.original?.ignition;
                        const isOn = ignitionValue?.toString().toLowerCase() === "on";

                        return (
                            <span className="flex items-center space-x-2">
                                {(title === "Active QC's" || title === '') && (
                                    <span className={`w-2 h-2 rounded-full ${isOn ? "bg-green-700" : "bg-slate-400"} inline-block`} />
                                )}
                                <span>{assetValue}</span>
                            </span>
                        );
                    }
                };
            }

            if (["gpstime", "estcompletiontime", "starttime", "endtime"].includes(lowerItem)) {
                return {
                    ...baseColumn,
                    cell: ({ row }) => {
                        const value = row.getValue(item);
                        return <span>{formatCustomDateTime(value, "")}</span>;
                    }
                };
            }

            return baseColumn;
        });
    }, [gridData, columnsConfig, title]);

    const prevPagination = useRef<PaginationState | null>(null);
    const hasMounted = useRef(false);

    function handlePaginationChange(newPagination: PaginationState) {
        if (!hasMounted.current) {
            hasMounted.current = true;
            prevPagination.current = newPagination;
            return;
        }
        if (
            prevPagination.current &&
            newPagination.pageIndex === prevPagination.current.pageIndex &&
            newPagination.pageSize === prevPagination.current.pageSize
        ) {
            return;
        }

        prevPagination.current = newPagination;
        console.log(newPagination.pageSize, newPagination.pageIndex)
        // const skip = newPagination.pageIndex * newPagination.pageSize;
        // // const skip = 0;
        // const take =newPagination.pageSize;
        const skip = 0;
        const take = newPagination.pageIndex * newPagination.pageSize + 5;
        setPaged((prev: any) => ({
            ...prev,
            pageIndex: 1,
            pageSize: (newPagination.pageIndex * newPagination.pageSize) + 5
        }));

        const payload: DashboardPayload = {
            cardName: title?.trim() || '',
            skip,
            take,
        };
        fetchWatersideData(payload).then((gridData) => {
            const items = gridData?.qcDetails?.items ?? [];
            setTableData(items);
        });
        setPagination(newPagination);
    }


    return (
        <div className="pt-2">
            <div className="flex pt-2 space-x-2">
                <div className="w-4/5 h-[300px] bg-white p-1 text-black">
                    {barData?.length ? (
                        <div className="flex h-full space-x-2">
                            <div className="w-[67%] flex flex-col justify-center items-center mt-3 p-2">
                                <span className="text-[15px] font-bold text-gray-600  text-center">
                                    QC Utilization And Vessel Job Distribution
                                </span>
                                <div className="w-full h-[260px] flex-1">
                                    <ChartComponent data={barData} />
                                </div>
                            </div>
                            <div className="w-[33%] h-[253px] p-1 mt-1">
                                <BarChart2 />
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center w-full h-full p-6 text-gray-600 bg-gray-100 rounded-lg">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="w-16 h-16 mb-4 text-blue-400"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M12 21a9 9 0 110-18 9 9 0 010 18z" />
                            </svg>
                            <p className="mt-1 text-sm text-center">
                                We couldn’t find any data to display.
                            </p>
                        </div>
                    )}
                </div>
                <div className="w-1/5 h-[300px] bg-white p-2 flex flex-col">
                    <div className="">
                        <div className="text-[15px] font-bold text-gray-600 pt-2.5 text-center">
                            Job Progress Status
                        </div>
                        <StyledGaugeFull jobInfos={jobInfos} />
                    </div>
                </div>

            </div>
            <div className="flex pt-2 space-x-2">
                <div className="w-3/5 h-[350px] p-2 shadow-md  rounded-lg">
                    <div className="h-full ">
                        {isloading ? (
                            <div className="flex justify-center w-full h-full">
                                <div className="w-8 h-8 border-t-4 border-orange-500 border-opacity-75 rounded-full animate-spin"></div>
                            </div>
                        ) : (
                            <div className="h-full overflow-auto">
                                <DataTable
                                    columns={columns}
                                    data={tableData ?? []}
                                    totalRecords={totalCount}
                                    pagination={paged}
                                    onPaginationChange={handlePaginationChange}
                                    isRowsHidden={true}
                                />
                            </div>
                        )}
                    </div>
                </div>
                <div className="w-2/5 h-[300px]">
                    <Map active={activeQCs} />
                </div>
            </div>
        </div>
    );
});

const COLORS = {
    'Moves Completed': '#0088FE',
    'Moves Pending': '#E0E0E0',
} as const;

const renderCustomLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    value,
}: CustomLabelProps) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) / 2;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
        <text
            x={x}
            y={y}
            fill="#333"
            textAnchor="middle"
            dominantBaseline="central"
            fontSize="12"
            fontWeight="500"
        >
            {value}
        </text>
    );
};

const StyledGaugeFull = memo(({ jobInfos }: StyledGaugeFullProps) => {
    const total = jobInfos?.reduce((sum, item) => sum + item.value, 0);

    return (
        <div className="flex flex-col items-center justify-between h-full py-6">
            {/* Chart */}
            <div className="w-full max-w-xs flex justify-center relative mb-6">
                <ResponsiveContainer width={200} height={120}>
                    <PieChart>
                        <Pie
                            data={jobInfos}
                            cx="50%"
                            cy="100%"
                            startAngle={180}
                            endAngle={0}
                            innerRadius={60}
                            outerRadius={100}
                            dataKey="value"
                            paddingAngle={0} // ensure there’s no gap
                            isAnimationActive={false}
                            labelLine={false}
                            label={renderCustomLabel} // Custom label for displaying the value inside the chart
                        >
                            {jobInfos?.map((entry, index) => (
                                <Cell
                                    key={`cell-${index}`}
                                    fill={COLORS[entry.title as keyof typeof COLORS] ?? '#ccc'}
                                />
                            ))}
                        </Pie>
                    </PieChart>
                </ResponsiveContainer>
                <div
                    className="absolute text-center text-2xl font-bold text-gray-800"
                    style={{
                        top: '70%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                    }}
                >
                    {total}
                </div>
            </div>




            {/* Footer */}
            <div className="w-full text-center text-sm text-gray-500">
                {/* Your footer content here */}
                <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-xs text-gray-600 w-full max-w-xs mb-6">
                    {jobInfos?.map((entry, index) => (
                        <div key={index} className="flex items-center space-x-1 min-w-[70px] justify-center">
                            <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: COLORS[entry.title as keyof typeof COLORS] ?? '#ccc' }}
                            />
                            <span className="truncate">{entry.title}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

});



export const typeColors = {
    Discharge: "#ffc107",
    Load: "#2196f3",      // blue
} as const;


const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
    console.log(active, payload)
    if (!active || !payload?.length) return null;
    const entry = payload[0];
    const asset = entry.name;
    const jobs = entry.value;
    const type = entry.payload[`${asset}_type`];
    const completedJobs = entry.payload[`${asset}_completed`];
    // const typeColor = typeColors[type];
    const typeColor = '#ffc107';

    return (
        <div
            style={{
                background: "#fff",
                border: `1px solid ${typeColor}`,
                borderRadius: 8,
                boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                padding: "12px 14px",
                minWidth: 60,
                fontFamily: "Arial, sans-serif",
            }}
        >
            <p style={{ margin: 0, fontWeight: "bold", fontSize: 14, color: "#333" }}>
                QC: <span style={{ color: "#555" }}>{asset}</span>
            </p>
            <p style={{ margin: "6px 0", fontSize: 13 }}>
                <strong>Type:</strong>{" "}
                <span style={{ color: typeColor, fontWeight: "bold" }}>{type}</span>
            </p>
            <p style={{ margin: 0, fontSize: 13 }}>
                <strong>Jobs:</strong> <span style={{ color: "#333" }}>{jobs}</span>
            </p>
            <p style={{ margin: '6px 0', fontSize: 13 }}>
                <strong>Completed Jobs:</strong> <span style={{ color: "#333" }}>{completedJobs}</span>
            </p>
        </div>
    );
};

export const ChartComponent: React.FC<ChartComponentProps> = ({ data }) => {
    const { chartData, assetInfo } = useMemo(() => {
        const assetSet = new Set();
        const assetTypes: Record<string, string> = {};
        const transformed: Record<string, any>[] = [];
        data.forEach((vessel) => {
            const row: Record<string, any> = { vesselName: vessel.vesselName };
            vessel.qcs.forEach((qc) => {
                row[qc.asset] = qc.activeJobs;
                row[`${qc.asset}_type`] = qc.type;
                row[`${qc.asset}_label`] = qc.asset;
                row[`${qc.asset}_completed`] = qc.completedJobs;
                assetSet.add(qc.asset);
                assetTypes[qc.asset] = qc.type;
            });
            transformed.push(row);
        });

        return {
            chartData: transformed,
            assetInfo: Array.from(assetSet).map((asset: any) => ({
                asset,
                type: assetTypes[asset],
            })),
        };
    }, [data]);
    const { yMax, yTicks } = useMemo(() => {
        const allJobs = data.flatMap(d => d.qcs.map(qc => qc.activeJobs));
        const max = Math.max(1, ...allJobs);
        const roundedMax = Math.ceil(max / 2) * 2;
        let ticks = [];
        for (let i = 2; i <= roundedMax + 3; i += 2) {
            ticks.push(i);
        }
        const adjustedYMax = roundedMax + 3;
        if (!ticks.includes(adjustedYMax)) {
            ticks.push(adjustedYMax);
            ticks.sort((a, b) => a - b);
        }
        return { yMax: adjustedYMax, yTicks: ticks };
    }, [data]);

    return (

        <div style={{ width: "100%", height: 360 }}>
            <ResponsiveContainer>
                <BarChart
                    data={chartData}
                    margin={{ top: 20, right: 0, left: 0, bottom: 80 }}
                    barGap={10}
                    barCategoryGap="15%"
                >
                    <XAxis
                        dataKey="vesselName"
                        interval={0}
                        tickLine={false}
                        axisLine={true}
                        height={60}
                        tick={({ x, y, payload, index }) => {
                            const vessel = chartData[index];
                            const assets = assetInfo.filter(({ asset }) => vessel.hasOwnProperty(asset)).map(({ asset }) => asset);
                            const barWidth = 28;
                            const barGap = 15;
                            const groupWidth = assets.length * barWidth + (assets.length - 1) * barGap;
                            const groupStartX = x - groupWidth / 2;

                            return (
                                <g transform={`translate(${groupStartX},${y})`}>
                                    {/* Asset */}
                                    {assets.map((asset, i) => (
                                        <text
                                            key={asset}
                                            x={i * (barWidth + barGap) + barWidth / 2 + 1}
                                            y={10}
                                            fontSize={13}
                                            fill="#666"
                                            textAnchor="middle"
                                            fontWeight="normal"
                                        >
                                            {asset}
                                        </text>
                                    ))}

                                    {/* Vessel */}
                                    <text
                                        x={groupWidth / 2}
                                        y={30}
                                        fontSize={12}
                                        fill="#333"
                                        fontWeight="bold"
                                        textAnchor="middle"
                                    >
                                        {payload.value}
                                    </text>
                                </g>
                            );
                        }}
                    />

                    <YAxis
                        label={{
                            value: "Active Jobs",
                            angle: -90,
                            position: "middle",
                            offset: 10,
                            fontSize: 11,
                            fontWeight: "bold",
                        }}
                        domain={[0, yMax]}
                        ticks={yTicks}
                        fontSize={11}
                        tickFormatter={(tick) => tick}
                    />
                    <Tooltip content={<CustomTooltip />} shared={false} isAnimationActive={false} />
                    <Legend
                        layout="horizontal"   // change to horizontal
                        verticalAlign="top" // align it at the bottom
                        align="end"         // align the legend to the center
                        wrapperStyle={{
                            fontSize: 13,
                            top: 40, // Adjust this value based on your needs
                            left: '50%',
                            transform: 'translateX(-50%)', // To center the legend horizontally
                        }}
                        payload={[
                            { value: "Discharge", type: "square", color: typeColors.Discharge },
                            { value: "Load", type: "square", color: typeColors.Load },
                        ]}
                    />

                    {assetInfo.map(({ asset, type }) => (
                        <Bar
                            key={asset}
                            dataKey={asset}
                            name={asset}
                            fill={'#ffc107'}
                            // fill={typeColors[type]}
                            barSize={28}
                        >

                            {/* <LabelList
                                dataKey={`${asset}_label`}
                                position="top"
                                content={({ x, y, value }: LabelProps) => {
                                    const safeX = Number(x ?? 0);
                                    const safeY = Number(y ?? 0);

                                    return (
                                        <text
                                            x={safeX + 15}
                                            y={safeY - 5}
                                            fill="#333"
                                            fontSize={10}
                                            textAnchor="middle"
                                            fontWeight={600}
                                        >
                                            {value}
                                        </text>
                                    );
                                }}
                            /> */}

                        </Bar>
                    ))}
                    {/* {assetInfo.map(({ asset, type }) => (
                        <Bar
                            key={asset}
                            dataKey={asset}
                            name={asset}
                            fill={'#ffc107'}
                            barSize={28}
                        >

                            <LabelList
                                dataKey={`${asset}_label`}
                                position="top"
                                content={({ x, y, value }: LabelProps) => {
                                    const safeX = Number(x ?? 0);
                                    const safeY = Number(y ?? 0);

                                    return (
                                        <text
                                            x={safeX + 15}
                                            y={safeY - 5}
                                            fill="#333"
                                            fontSize={10}
                                            textAnchor="middle"
                                            fontWeight={600}
                                        >
                                            {value}
                                        </text>
                                    );
                                }}
                            />

                        </Bar>
                    ))} */}
                </BarChart>
            </ResponsiveContainer>

        </div>
    );
};

const FullPageLoader = () => (
    <div className="fixed z-50 flex items-center justify-center inset-60 bg-gradient-to-br from-blue-100 via-white to-blue-200 bg-opacity-90 backdrop-blur-lg">
        <div className="relative">
            <div className="absolute inset-0 bg-blue-300 rounded-full opacity-30 blur-2xl animate-pulse"></div>
            <div className="z-10 w-16 h-16 border-t-4 border-blue-500 border-opacity-75 rounded-full animate-spin"></div>
        </div>
    </div>
);

export default memo(Waterside);
