import { memo, useEffect, useMemo, useRef, useState } from "react";
import { Bar } from "react-chartjs-2";
// import map from '../map3.png'
import { DataTable } from "@/app/management/data-table";
import Map from "@/app/map/LandSideDashboardMap";
import { useMapPopupStore, useAssetDetailsStore } from "@/app/map/useMapPopupStore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type {
    AssertDetails,
    ChartItem,
    DashboardPayload,
    EcuStatsChartProps,
    EcuStatus,
    ItvActivity,
    ItvDashboardData,
    ItvDistribution,
    LandBarchartSimpleProps,
    LandStackedChartProps,
    LayoutLandsideProps
} from '@/lib/models';
import { fetchLandsideData } from "@/lib/services/landside-service";
import { formatCustomDateTime, formatHeader } from "@/lib/utils";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { TooltipItem } from "chart.js";
import { format, parseISO } from "date-fns";
import { MapPinned } from "lucide-react";
import useSWR, { mutate } from "swr";
import { FiRefreshCw } from "react-icons/fi";

const barChartColors = [
    "#A5B4FC", // Softer Indigo (Indigo-300)
    "#FCD34D", // Softer Amber (Amber-300)
    "#6EE7B7", // Softer Emerald (Emerald-300)
    "#FCA5A5", // Softer Red (Red-300)
    "#93C5FD", // Softer Blue (Blue-300)
];

const Landside = () => {
    const [loading, setLoading] = useState(false);
    const [title, setTitle] = useState('');
    const fetchData = async (payload: DashboardPayload): Promise<{
        card: ChartItem[];
        itvDistribution: ItvDistribution;
        itvActivity: ItvActivity[];
        ecuStatus: EcuStatus;
        AssertDetails: AssertDetails;
    }> => {
        const data: ItvDashboardData = await fetchLandsideData(payload);

        const cardKeys = {
            asserts: "Assets",
            active: "Active",
            idling: "Idling",
            stoppage: "Stoppage",
            alerts: "Alerts",
            avgCycleTime: "Avg.Cycle Time",
        } as const;

        const card: ChartItem[] = Object.keys(cardKeys).map((key) => ({
            title: cardKeys[key as keyof typeof cardKeys],
            value: data[key as keyof typeof cardKeys] as number,
        }));

        return {
            card,
            itvDistribution: data.itvDistribution,
            itvActivity: data.itvActivity,
            ecuStatus: data.ecuStatus,
            AssertDetails: data.assertDetails,
        };
    };
    const payload = {
        skip: 0,
        take: 5,
        cardName: title
    };
    const { data, isLoading } = useSWR(payload, fetchData, {
        refreshInterval: 25000
    });


    if (isLoading || !data) return <FullPageLoader />;

    const { card, itvDistribution, itvActivity, ecuStatus, AssertDetails } = data;
    const assertDetails = AssertDetails?.items ?? [];
    const totalCount = AssertDetails?.totalCount ?? 0;
    const getSWRKey = (payload: DashboardPayload) =>
        `dashboard-${payload.cardName}-${payload.skip}-${payload.take}`;

    const changegridData = async (title: ChartItem['title'], index: number): Promise<void> => {
        setTitle(title);

        if (index !== 5) {
            try {
                setLoading(true);
                const newPayload: DashboardPayload = {
                    cardName: index === 0 ? '' : title,
                    skip: 0,
                    take: 5,
                };
                const gridData = await fetchLandsideData(newPayload);
                const swrKey = getSWRKey(newPayload);
                const currentData = await mutate(swrKey, undefined, false);
                mutate(
                    swrKey,
                    {
                        ...(currentData ?? {}),
                        AssertDetails: gridData.assertDetails,
                    },
                    false
                );
            } catch (error) {
                console.error("Error updating QC details:", error);
            } finally {
                setLoading(false);
            }
        }
    };

    return (
        <>
            {/* <CostomModelTest /> */}
            <body className="bg-[rgb(244,247,254)] ">
                <div className="flex  bg-[rgb(244,247,254)]">
                    {/* <!-- Main Content --> */}
                    <div className="flex flex-col flex-1">
                        {/* <!-- Content --> */}
                        <main className="flex-1 p-2">
                            {/* DASHBOARD  */}
                            <div>
                                <div className="grid grid-cols-1 gap-6 px-1 pt-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6">

                                    {card.map((item, index) => (
                                        <Card
                                            key={index}
                                            className={`flex flex-col justify-between bg-[#34658A] ${index === 0 || index === 1 || index === 2 ? 'cursor-pointer' : 'cursor-default'
                                                } h-32`}
                                            onClick={() => {
                                                if (index === 0 || index === 1 || index === 2) {
                                                    changegridData(item.title, index);
                                                }
                                            }}
                                        >
                                            <CardHeader className="flex flex-row items-center justify-between">
                                                <CardTitle className="font-normal text-white">
                                                    {item.title}
                                                </CardTitle>
                                                {/* Optionally show icon */}
                                                {/* <item.icon className={`h-6 w-6 ${item.color}`} /> */}
                                            </CardHeader>

                                            <CardContent>
                                                <p
                                                    className={`text-3xl font-semibold ${item.title === 'Stoppage' ? 'text-[#FF1D0D]' : 'text-white'
                                                        }`}
                                                >
                                                    {item.value}
                                                    <span className="ml-1 text-sm font-bold">
                                                        {item.title === 'Stoppage' && (
                                                            <span className="text-sm font-normal text-white">hrs</span>
                                                        )}
                                                        {item.title === 'Avg.Cycle Time' && (
                                                            <span className="text-sm font-normal text-white">mins</span>
                                                        )}
                                                    </span>
                                                </p>
                                            </CardContent>
                                        </Card>
                                    ))}

                                </div>

                            </div>
                            <Layout
                                getDashboardType={'landside'}
                                title={title}
                                itvDistribution={itvDistribution}
                                itvActivity={itvActivity}
                                ecuStatus={ecuStatus}
                                gridData={assertDetails}
                                isloading={loading}
                                totalCount={totalCount} barData={[]} />
                        </main>
                    </div>
                </div>
            </body>
        </>
    );
};

const Layout = memo((props: LayoutLandsideProps) => {
    let { gridData, barData, title, totalCount, isloading } = props;
    const setPopupInfo = useMapPopupStore((state) => state.setPopupInfo);
    const setAssetDetails = useAssetDetailsStore((state) => state.setAssetDetails);
    // console.log(gridData)
    if (gridData.length > 0) {
        gridData[0] = { ...gridData[0], Map: '' };
    }
    // console.log(title);
    const [paged, setPaged] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 5,
        search: ""
    });
    const isFirstRender = useRef(true);
    const [tableData, setTableData] = useState(gridData ?? []);
    if(title === 'Idling'){
                    const updatedData = gridData.map(item => ({
                                ...item,
                                operationStatus: "inactive", 
                                ignition: "OFF" 
                                }));
                    setAssetDetails(updatedData);
                }else{
                     setAssetDetails(gridData);
                }

    const handleMapClick = (row: any) => {
        // console.log("Map clicked for row:", row);
        // Set the popup info with the row data
        setPopupInfo({
            longitude: row.longitude || 77.594566, // Default longitude if not available
            latitude: row.latitude || 8.373240026063501, // Default latitude if not available
            properties: {
                equipmentName: row.asset,
                ignition: row.ignition || "OFF",
                operationalState: row.operationStatus || "Inactive",
                gpsTime: format(parseISO(row.gpsTime), 'yyyy-MM-dd HH:mm:ss a'),
            },
        });
    };

    useEffect(() => {
        isFirstRender.current = true;
        setTableData(gridData ?? []);
        if(title === 'Idling'){
                    const updatedData = gridData.map(item => ({
                                ...item,
                                operationStatus: "inactive", 
                                ignition: "OFF" 
                                }));
                    setAssetDetails(updatedData);
                }else{
                     setAssetDetails(gridData);
                }
        // setAssetDetails(gridData??[]);
        setPaged(prev => ({ ...prev, pageIndex: 0 }));
    }, [gridData, title]);

    const allColumnSets: Record<string, { key: string; title: string; hidden: boolean }[]> = {

        "Active QC's": [
            { key: "asset", title: "Asset", hidden: false },
            { key: "type", title: "Type", hidden: false },
            { key: "operationStatus", title: "Operation Status", hidden: false },
            { key: "gpsTime", title: "GPS Time", hidden: false },
            { key: "ignition", title: "Ignition", hidden: false }, { key: "make", title: "Make", hidden: false },
        ],

        "Idling": [
            { key: "asset", title: "Asset", hidden: false },
            { key: "type", title: "Type", hidden: false },
            { key: "idling", title: "Idling Time", hidden: false }, { key: "make", title: "Make", hidden: false },
        ],
        "Movement State": [
            { key: "asset", title: "Asset", hidden: false },
            { key: "type", title: "Type", hidden: false },
            { key: "movementState", title: "Movement State", hidden: false },
            { key: "active", title: "Active Time", hidden: false }, { key: "make", title: "Make", hidden: false },
        ],
    };

    const columnsConfig = useMemo(() => {
        return allColumnSets[title] || allColumnSets["Active QC's"];
    }, [title]);


    const columns: ColumnDef<any>[] = useMemo(() => {
        const hasData = gridData?.length > 0;
        const keysToUse = hasData
            ? Object.keys(gridData[0])
            : columnsConfig.map(col => col.key);

        let operationStatusColumn: ColumnDef<any> | null = null;
        let idlingColumn: ColumnDef<any> | null = null;

        const processedColumns = keysToUse.reduce<ColumnDef<any>[]>((acc, item) => {
            const lowerItem = item.toLowerCase();
            if (["ignition", "rfidtag2", "longitude", "latitude", "rfidtag1", "status","active"].includes(lowerItem)) return acc;

            const baseColumn: ColumnDef<any> = {
                accessorKey: item,
                header: formatHeader(item),
                enableHiding: true,
            };

            if (lowerItem === "asset") {
                acc.push({
                    ...baseColumn,
                    cell: ({ row }) => {
                        const assetValue: string = row.getValue("asset");
                        const ignitionValue = row.original?.ignition;
                        const isOn = ignitionValue?.toString().toLowerCase() === "on";

                        return (
                            <span className="flex items-center space-x-2">
                                {(title === "Active QC's" || title === '') && (
                                    <span className={`w-2 h-2 rounded-full ${isOn ? "bg-green-700" : "bg-slate-400"} inline-block`} />
                                )}
                                <span>{assetValue}</span>
                            </span>
                        );
                    },
                });
            } else if (["gpstime", "estcompletiontime", "starttime", "endtime"].includes(lowerItem)) {
                acc.push({
                    ...baseColumn,
                    cell: ({ row }) => {
                        const assetValue = row?.getValue(item);
                        return <span>{formatCustomDateTime(assetValue, "")}</span>;
                    },
                });
            } else if (lowerItem === "map") {
                if (operationStatusColumn) {
                    acc.push(operationStatusColumn);
                    operationStatusColumn = null; 
                }
                if (idlingColumn) {
                    acc.push(idlingColumn);
                    idlingColumn = null; 
                }
                acc.push({
                    accessorKey: 'map',
                    header: 'Map',
                    cell: ({ row }) => <span role="img" aria-label="map" className="cursor-pointer" onClick={() => {
                        console.log("Map icon clicked");
                        handleMapClick(row.original);
                    }}><MapPinned size={24} className="pl-2 text-center" /></span>,
                    enableHiding: true,
                });
            } else if (lowerItem === "operationstatus") {
                operationStatusColumn = baseColumn;
            } else if (lowerItem === "idling") {
                idlingColumn = baseColumn;
            } else {
                acc.push(baseColumn);
            }

            return acc;
        }, []);

        return processedColumns;
    }, [gridData]);

    const prevPagination = useRef<PaginationState | null>(null);
    const hasMounted = useRef(false);

    function handlePaginationChange(newPagination: PaginationState) {
        if (!hasMounted.current) {
            hasMounted.current = true;
            prevPagination.current = newPagination;
            return;
        }
        if (
            prevPagination.current &&
            newPagination.pageIndex === prevPagination.current.pageIndex &&
            newPagination.pageSize === prevPagination.current.pageSize
        ) {
            return;
        }
        prevPagination.current = newPagination;
        // const skip = newPagination.pageIndex * newPagination.pageSize;
        const skip = 0;
        const take = newPagination.pageIndex * newPagination.pageSize + 5;
        const payload = {
            cardName: title?.trim() || '',
            skip,
            take,
        };
        fetchLandsideData(payload).then((gridData) => {
            const items = gridData?.assertDetails?.items ?? [];
            setTableData(items);
            if(title === 'Idling'){
                    const updatedData = items.map(item => ({
                                ...item,
                                operationStatus: "inactive", 
                                ignition: "OFF" 
                                }));
                    setAssetDetails(updatedData);
                }else{
                     setAssetDetails(items);
                }
            // setAssetDetails(items);
        });
        setPaged(newPagination);
        setPaged(newPagination);
    }

    return (
        <>
            <div className="pt-2">
                <div className="">
                    <div className="flex space-x-1 h-[300px]">
                        <div className="w-[50%] h-full shadow-lg bg-white rounded-lg">
                            <h2 className="font-semibold text-center pt-7">ITV Distribution</h2>
                            <LandBarchartSimple chartData={props.itvDistribution} themeCode={''} />
                        </div>

                        <div className="w-[50%]  h-full shadow-lg bg-white rounded-lg">
                            <h2 className="font-semibold text-center pt-7 ">ITV Activity</h2>
                            <LandStackedChart chartData={props.itvActivity} themeCode={''} />
                        </div>

                        <div className="w-[40%] h-full shadow-lg bg-white rounded-lg flex flex-col space-y-2">
                            <EcuStatsChart ecuStatus={props.ecuStatus} />
                        </div>
                    </div>
                </div>
                {/* LAYOUT 3 */}
                <div className="flex pt-2 space-x-2">
                    <div className="w-3/5 h-[280px] p-2shadow-2xl rounded-lg ">
                        <div className="max-h-64">
                            {isloading ? (
                                <div className="flex justify-center w-full h-full">
                                    <div className="w-8 h-8 border-t-4 border-orange-500 border-opacity-75 rounded-full animate-spin"></div>
                                </div>
                            ) : (
                                <DataTable
                                    columns={columns}
                                    data={tableData ?? []}
                                    totalRecords={totalCount}
                                    pagination={paged}
                                    onPaginationChange={handlePaginationChange}
                                    isRowsHidden={true}
                                />
                            )}
                        </div>
                    </div>
                    <div className="w-2/5 h-[200px]">
                        <Map />
                    </div>
                </div>
            </div>

        </>
    );
});


export const LandBarchartSimple = memo(({ chartData, themeCode }: LandBarchartSimpleProps) => {
    //   const themeCode = useTheme(); // or however you get it
    //   const axisColor = themeCode === "dark" ? "#ffffff" : "#000000";
    const axisColor = themeCode === "dark" ? "#ffffff" : "#000000";

    console.log(chartData)

    const labels = [
        "Idle",
        "Moving to Quay",
        "At Quay",
        "Moving to Yard",
        "At Yard",
    ];

    const labelKeys = [
        "idle",
        "movingToQuay",
        "atQuay",
        "movingToYard",
        "atYard",
    ];

    const truncatedLabels = labels.map((label) =>
        label.length > 4 ? label.substring(0, 4) + ".." : label
    );

    const barData = labelKeys.map((key) => chartData?.[key] ?? 0);
    console.log(barData)
    const data = {
        labels: truncatedLabels,
        datasets: [
            {
                label: "ITV Count",
                data: barData,
                backgroundColor: barChartColors,
                barPercentage: 1.0,
                categoryPercentage: 0.5,
                borderRadius: 6,
            },
        ],
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                ticks: { color: axisColor },
                grid: { display: false },
            },
            y: {
                beginAtZero: true,
                min: 0,
                suggestedMax: 4,
                ticks: { stepSize: 1, color: axisColor },
                grid: { display: false },
            },
        },
        plugins: {
            legend: {
                display: false,
                labels: { color: axisColor },
            },
            title: {
                display: false,
                text: "ITV Distribution",
                color: axisColor,
                font: { size: 12, weight: "bold" },
            },
            tooltip: {
                callbacks: {
                    title: function (context: TooltipItem<'bar'>[]) {
                        const index = context[0].dataIndex;
                        return labels[index];
                    },
                },
            },
        },
    };
    console.log(data)
    return (
        <div style={{ width: "100%", height: "230px" }}>
            <Bar data={data} options={options} />
        </div>
    );
});

export const LandStackedChart = memo(({ chartData, themeCode }: LandStackedChartProps) => {
    const axisColor = themeCode === "dark" ? "#ffffff" : "#000000";
    const borderLineColor = themeCode === "dark" ? "#ffffff" : "#c2c4c3";
    const labels = chartData?.map(item => item.itv);
    const data = {
        labels,
        datasets: [
            {
                label: "Idling",
                data: chartData?.map(item => item.idling),
                backgroundColor: "#9e9e9e",
                borderRadius: 6, // Roun // Gray
            },
            {
                label: "Stoppage",
                data: chartData?.map(item => item.stoppage),
                backgroundColor: "#f44336",
                borderRadius: 6, // Roun // Red
            },
            {
                label: "Active",
                data: chartData?.map(item => item.active),
                backgroundColor: "#4a90e2",
                borderRadius: 6, // Roun // Blue
            },
        ],
    };
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
            padding: {
                bottom: 40,
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    color: axisColor,
                    stepSize: 5,
                    precision: 0,
                },
                grid: {
                    display: false,
                },
                border: {
                    color: borderLineColor,
                },
            },
            x: {
                ticks: {
                    display: true, // Hide x-axis labels
                },
                grid: {
                    display: false,
                },
                border: {
                    color: borderLineColor,
                },
            },
        },
        plugins: {
            legend: {
                display: true,
                position: "right",
                labels: {
                    boxWidth: 12,
                },
            },
            title: {
                display: false,
                text: "ITV Activity",
                color: axisColor,
            },
            tooltip: {
                callbacks: {
                    label: function (tooltipItem: TooltipItem<'bar'>) {
                        return `${tooltipItem.dataset.label}: ${tooltipItem.raw} hrs`;
                    },
                },
            },
        },
    };
    return (
        <div style={{ width: "100%", height: "269px" }}>
            <Bar data={data} options={options} />
        </div>
    );
});

export const EcuStatsChart = memo(({ ecuStatus }: EcuStatsChartProps) => {
    const ecuStats = [
        { label: "Engine Hours", value: ecuStatus?.engineHours ?? 0, color: "#60A5FA" },
        { label: "Idle Hours", value: ecuStatus?.idleHours ?? 0, color: "#34D399" },
        { label: "Stoppage Hours", value: ecuStatus?.stoppageHours ?? 0, color: "#FBBF24" },
        { label: "Fuel Consumption", value: ecuStatus?.fuelConsumpion ?? 0, color: "#F87171" },
    ];
    const maxValue = Math.max(...ecuStats.map(item => item.value), 1);

    return (
        <div className="flex flex-col h-full px-2 py-1 overflow-hidden text-sm">
            <div className="py-[20px]">
                <div className="">
                    <h2 className="pb-1 text-lg font-semibold text-center ">ECU Stats</h2>
                </div>
                <div className="pt-8 space-y-4">
                    {ecuStats.map((item) => (
                        <div key={item.label} className="flex items-center gap-2">
                            <div className="w-[150px] text-base font-medium whitespace-nowrap mb-2">
                                {item.label}
                            </div>
                            <div className="flex-1 bg-gray-100 h-[1.5rem] rounded overflow-hidden">
                                <div
                                    className="h-full transition-all duration-300 rounded"
                                    style={{
                                        width: `${(item.value / maxValue) * 100}%`,
                                        backgroundColor: item.color,
                                    }}
                                />
                            </div>
                            <div className="text-sm font-medium ml-2 w-[40px]">{item.label === 'Fuel Consumption'
                                ? `${Math.floor(item.value)}(Lt)`
                                : Math.floor(item.value)}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
});

const FullPageLoader = () => (
    <div className="fixed z-50 flex items-center justify-center inset-60 bg-gradient-to-br from-blue-100 via-white to-blue-200 bg-opacity-90 backdrop-blur-lg">
        <div className="relative">
            <div className="absolute inset-0 bg-blue-300 rounded-full opacity-30 blur-2xl animate-pulse"></div>
            <div className="z-10 w-16 h-16 border-t-4 border-blue-500 border-opacity-75 rounded-full animate-spin"></div>
        </div>
    </div>
);

export default memo(Landside);
