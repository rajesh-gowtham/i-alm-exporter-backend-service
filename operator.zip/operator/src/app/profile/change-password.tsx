import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const passwordSchema = z
  .object({
    currentPassword: z.string().min(6, "Current password is required"),
    newPassword: z
      .string()
      .min(8, "New password must be at least 8 characters"),
    confirmPassword: z
      .string()
      .min(8, "Confirm password must match new password"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export default function ChangePasswordForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(passwordSchema),
  });

  const onSubmit = (formData: any) => {
    console.log("Password Change Submitted:", formData);
  };

  return (
    <div className="p-6 mx-auto mt-10">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="grid grid-cols-1 gap-4"
      >
        <div className="flex flex-col">
          <Label htmlFor="currentPassword" className="text-left">
            Current Password
          </Label>
          <Input
            id="currentPassword"
            type="password"
            {...register("currentPassword")}
            className="mt-1 bg-muted"
          />
          {errors.currentPassword && (
            <span className="text-sm text-red-500">
              {errors.currentPassword.message}
            </span>
          )}
        </div>
        <div className="flex flex-col">
          <Label htmlFor="newPassword" className="text-left">
            New Password
          </Label>
          <Input
            id="newPassword"
            type="password"
            {...register("newPassword")}
            className="mt-1 bg-muted"
          />
          {errors.newPassword && (
            <span className="text-sm text-red-500">
              {errors.newPassword.message}
            </span>
          )}
        </div>
        <div className="flex flex-col">
          <Label htmlFor="confirmPassword" className="text-left">
            Confirm Password
          </Label>
          <Input
            id="confirmPassword"
            type="password"
            {...register("confirmPassword")}
            className="mt-1 bg-muted"
          />
          {errors.confirmPassword && (
            <span className="text-sm text-red-500">
              {errors.confirmPassword.message}
            </span>
          )}
        </div>
        <div>
          <Button type="submit" className="w-full">
            Update Password
          </Button>
        </div>
      </form>
    </div>
  );
}
