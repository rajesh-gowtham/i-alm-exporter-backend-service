import { AccessorKeyColumnDef } from "@tanstack/react-table";

export type EmissionsTableRow = {
    assetId: string;
    date: string;
    state: "Idle" | "Active";
    coPercent: number | null;
    co2Percent: number | null;
    hcPpm: number | null;
    noPpm: number | null;
    no2Ppm: number | null;
    noxPpm: number | null;
    pmUgM3: number | null;
    pnCm3: number | null;

    co2KgH: number | null;
    coGH: number | null;
    hcGH: number | null;
    noGH: number | null;
    no2GH: number | null;
    noxGH: number | null;
    pmGH: number | null;
    pnH: number | null;

    avgEngineLoad: number | null;
    timeMinutes: number | null;

    co2KgGal: number | null;
    coGGal: number | null;
    hcGGal: number | null;
    noGGal: number | null;
    no2GGal: number | null;
    noxGGal: number | null;
    pmGGal: number | null;
    pnGal: number | null;
};

export const columns: AccessorKeyColumnDef<EmissionsTableRow>[] = [
    {
        accessorKey: "date",
        header: "Date",
        cell: (info) => {
            const value = info.getValue();
            return value ? new Date(value as string).toLocaleDateString() : "";
        },
        enableHiding: false,
    },
    {
        accessorKey: "state",
        header: "State",
        enableHiding: false,
    },
    { accessorKey: "coPercent", header: "CO (%)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "co2Percent", header: "CO₂ (%)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "hcPpm", header: "HC (ppm)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noPpm", header: "NO (ppm)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "no2Ppm", header: "NO₂ (ppm)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noxPpm", header: "NOₓ (ppm)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pmUgM3", header: "PM (µg/m³)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pnCm3", header: "PN (#/cm³)", cell: (info) => info.getValue() ?? "N/A" },

    { accessorKey: "co2KgH", header: "CO₂ (kg/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "coGH", header: "CO (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "hcGH", header: "HC (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noGH", header: "NO (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "no2GH", header: "NO₂ (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noxGH", header: "NOₓ (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pmGH", header: "PM (g/h)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pnH", header: "PN (#/h)", cell: (info) => info.getValue() ?? "N/A" },

    { accessorKey: "avgEngineLoad", header: "Engine Load (%)", cell: (info) => info.getValue() ?? "N/A" },
    {
        accessorKey: "timeMinutes",
        header: "Duration",
        cell: (info) => {
            const minutes = info.getValue<number>();
            if (minutes == null) return "N/A";
            const hrs = Math.floor(minutes / 60);
            const mins = Math.round(minutes % 60);
            if (hrs > 0) {
                return `${hrs}h ${mins}m`;
            }
            return `${mins}m`;
        },
    },

    { accessorKey: "co2KgGal", header: "CO₂ (kg/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "coGGal", header: "CO (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "hcGGal", header: "HC (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noGGal", header: "NO (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "no2GGal", header: "NO₂ (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "noxGGal", header: "NOₓ (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pmGGal", header: "PM (g/gal)", cell: (info) => info.getValue() ?? "N/A" },
    { accessorKey: "pnGal", header: "PN (#/gal)", cell: (info) => info.getValue() ?? "N/A" },
];
