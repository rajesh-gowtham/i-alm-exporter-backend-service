export interface EmissionMetric {
    key: string;          // The main metric key (e.g., CO2_percent)
    label: string;        // Label for legend/tooltip/axis
}

export type EmissionGroups = {
    carbonOxides: EmissionMetric[];
    nitrogenGases: EmissionMetric[];
    particulates: EmissionMetric[];
};


export const emissionGroups: EmissionGroups = {
    carbonOxides: [
        { key: "CO2_percent", label: "CO₂ (%)" },
        { key: "CO_percent", label: "CO (%)" },
        { key: "HC_ppm", label: "HC (ppm)" },
        { key: "CO2_kg_per_hr", label: "CO₂ (kg/h)" },
        { key: "CO_g_per_hr", label: "CO (g/h)" },
        { key: "HC_g_per_hr", label: "HC (g/h)" },
        { key: "CO2_kg_per_gal_fuel", label: "CO₂ (kg/gal)" },
        { key: "CO_g_per_gal_fuel", label: "CO (g/gal)" },
        { key: "HC_g_per_gal_fuel", label: "HC (g/gal)" }
    ],
    nitrogenGases: [
        { key: "NO_ppm", label: "NO (ppm)" },
        { key: "NO2_ppm", label: "NO₂ (ppm)" },
        { key: "NO_g_per_hr", label: "NO (g/h)" },
        { key: "NO2_g_per_hr", label: "NO₂ (g/h)" },
        { key: "NO_g_per_gal_fuel", label: "NO (g/gal)" },
        { key: "NO2_g_per_gal_fuel", label: "NO₂ (g/gal)" }
    ],
    particulates: [
        { key: "PM_ug_per_m3", label: "PM (µg/m³)" },
        { key: "PN_num_per_cm3", label: "PN (#/cm³)" },
        { key: "PM_g_per_hr", label: "PM (g/h)" },
        { key: "PN_num_per_hr", label: "PN (#/h)" },
        { key: "PM_g_per_gal_fuel", label: "PM (g/gal)" },
        { key: "PN_num_per_gal_fuel", label: "PN (#/gal)" }
    ]
};
