import React, { useRef, useState, useMemo } from "react";
import { Clock, Leaf, TrendingUp, PieChart, LucideIcon } from "lucide-react";
import { useEmissionsChartsStore } from "./emissions-charts-store";

export interface EmissionRecord {
  date: string;
  totalActiveHours?: number;
  totalIdleHours?: number;
  engineLoadPercent?: number;
  CO2_kg_per_hr?: number;
  [key: string]: any;
}
export interface AssetEmissions {
  assetId: number;
  emissions: {
    active: EmissionRecord[];
    idle: EmissionRecord[];
  };
}
export interface SummaryCardData {
  title:
    | "Total CO₂ (kg)"
    | "Idle Hours"
    | "Active Hours"
    | "Idle %"
    | "Active %";
  value: string | number | { value: number; unit: string };
  unit?: string;
}

const cardMeta: Record<
  SummaryCardData["title"],
  { icon: LucideIcon; color: string }
> = {
  "Total CO₂ (kg)": { icon: Leaf, color: "text-green-700 dark:text-green-300" },
  "Idle Hours": { icon: Clock, color: "text-yellow-800 dark:text-yellow-300" },
  "Active Hours": {
    icon: TrendingUp,
    color: "text-blue-700 dark:text-blue-300",
  },
  "Idle %": { icon: PieChart, color: "text-pink-700 dark:text-pink-300" },
  "Active %": { icon: PieChart, color: "text-blue-700 dark:text-blue-300" },
};

const EmissionSummaryCards: React.FC = () => {
  const { selectedAssetId, emissionsData } = useEmissionsChartsStore();

  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const dragOverIdx = useRef<number | null>(null);

  const asset = emissionsData[selectedAssetId] as AssetEmissions | undefined;

  const cards: SummaryCardData[] = useMemo(() => {
    if (!asset || !asset.emissions) {
      return [
        {
          title: "Total CO₂ (kg)",
          value: "-",
        },
        {
          title: "Idle Hours",
          value: "-",
        },
        {
          title: "Active Hours",
          value: "-",
        },
        {
          title: "Idle %",
          value: "-",
        },
        {
          title: "Active %",
          value: "-",
        },
      ];
    }

    const idleRecords: EmissionRecord[] = asset.emissions.idle ?? [];
    const activeRecords: EmissionRecord[] = asset.emissions.active ?? [];

    const idleHours = idleRecords.reduce<number>(
      (acc, cur) => acc + (cur.totalIdleHours ?? 0),
      0
    );
    const activeHours = activeRecords.reduce<number>(
      (acc, cur) => acc + (cur.totalActiveHours ?? 0),
      0
    );

    const totalCO2 =
      activeRecords.reduce<number>(
        (acc, cur) =>
          acc + (cur.CO2_kg_per_hr ?? 0) * (cur.totalActiveHours ?? 0),
        0
      ) +
      idleRecords.reduce<number>(
        (acc, cur) =>
          acc + (cur.CO2_kg_per_hr ?? 0) * (cur.totalIdleHours ?? 0),
        0
      );

    const totalHours = idleHours + activeHours;
    const idlePercentage =
      totalHours > 0 ? Math.round((idleHours / totalHours) * 100) : 0;
    const activePercentage =
      totalHours > 0 ? Math.round((activeHours / totalHours) * 100) : 0;

    return [
      {
        title: "Total CO₂ (kg)",
        value: Math.round(totalCO2 * 10) / 10,
      },
      {
        title: "Idle Hours",
        value: Math.round(idleHours * 10) / 10,
      },
      {
        title: "Active Hours",
        value: Math.round(activeHours * 10) / 10,
      },
      {
        title: "Idle %",
        value: idlePercentage,
      },
      {
        title: "Active %",
        value: activePercentage,
      },
    ];
  }, [asset]);

  const [orderedCards, setOrderedCards] = useState<SummaryCardData[] | null>(
    null
  );

  const handleDragStart = (idx: number) => setDraggedIdx(idx);
  const handleDragEnter = (idx: number) => {
    dragOverIdx.current = idx;
  };
  const handleDragEnd = () => {
    if (
      draggedIdx !== null &&
      dragOverIdx.current !== null &&
      draggedIdx !== dragOverIdx.current
    ) {
      const newCards = [...(orderedCards ?? cards)];
      const [removed] = newCards.splice(draggedIdx, 1);
      newCards.splice(dragOverIdx.current, 0, removed);
      setOrderedCards(newCards);
    }
    setDraggedIdx(null);
    dragOverIdx.current = null;
  };

  const visibleCards = orderedCards ?? cards;

  return (
    <div
      className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5"
      role="list"
      aria-label="Summary KPIs"
    >
      {visibleCards.map((card, idx) => {
        const meta = cardMeta[card.title];

        function isValueUnitObject(
          val: unknown
        ): val is { value: number; unit: string } {
          return (
            typeof val === "object" &&
            val !== null &&
            "value" in val &&
            "unit" in val
          );
        }

        let valueDisplay: string | number = "";
        if (isValueUnitObject(card.value)) {
          valueDisplay = `${card.value.value.toLocaleString()} ${
            card.value.unit
          }`;
        } else if (
          typeof card.value === "string" ||
          typeof card.value === "number"
        ) {
          valueDisplay = card.value;
        } else {
          valueDisplay = "";
        }

        return (
          <div
            key={card.title}
            draggable
            tabIndex={0}
            aria-grabbed={draggedIdx === idx}
            aria-label={`Drag to reorder ${card.title} card`}
            role="listitem"
            onDragStart={() => handleDragStart(idx)}
            onDragEnter={() => handleDragEnter(idx)}
            onDragEnd={handleDragEnd}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                handleDragStart(idx);
              }
            }}
            className={`transition-shadow focus-visible:ring-2 focus-visible:ring-blue-400 ${
              draggedIdx === idx ? "ring-2 ring-blue-400" : ""
            }`}
            style={{ cursor: "grab" }}
          >
            <StatCard
              icon={meta.icon}
              value={valueDisplay}
              label={card.title}
              iconColor={meta.color}
            />
          </div>
        );
      })}
    </div>
  );
};

interface StatCardProps {
  icon: LucideIcon;
  value: string | number;
  label: string;
  iconColor?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  icon: Icon,
  value,
  label,
  iconColor = "text-gray-800",
}) => {
  return (
    <div className="flex items-center p-6 rounded-2xl shadow-sm min-w-[14rem]">
      <div className={`flex-shrink-0 ${iconColor}`}>
        <Icon className="w-8 h-8" />
      </div>
      <div className="ml-6">
        <div className="text-3xl font-semibold text-gray-900 dark:text-primary-foreground">
          {value}
        </div>
        <div className="text-base text-gray-500 dark:text-muted-foreground">
          {label}
        </div>
      </div>
    </div>
  );
};

export default EmissionSummaryCards;
