import { AccessorKeyColumnDef } from "@tanstack/react-table";

export type EmissionsTableRow = {
    assetId: string;
    date: string;
    state: "Idle" | "Active";
    coPercent: number;
    co2Percent: number;
    co2KgH: number;
    coGH: number;
    noGH: number;
    no2GH: number;
    noxGH: number;
    avgEngineLoad: number;
    timeMinutes: number;
};

export const columns: AccessorKeyColumnDef<EmissionsTableRow>[] = [
    // {
    //     accessorKey: "assetId",
    //     header: "Asset ID",
    //     enableHiding: false,
    // },
    {
        accessorKey: "date",
        header: "Date",
        cell: (info) => {
            const value = info.getValue();
            return value ? new Date(value as string).toLocaleDateString() : "";
        },
        enableHiding: false,
    },
    {
        accessorKey: "state",
        header: "State",
        enableHiding: false,
    },
    {
        accessorKey: "coPercent",
        header: "CO (%)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "co2Percent",
        header: "CO₂ (%)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "co2KgH",
        header: "CO₂ (kg/h)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "coGH",
        header: "CO (g/h)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "noGH",
        header: "NO (g/h)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "no2GH",
        header: "NO₂ (g/h)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "noxGH",
        header: "NOₓ (g/h)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "avgEngineLoad",
        header: "Engine Load (%)",
        cell: (info) => info.getValue() ?? "N/A",
    },
    {
        accessorKey: "timeMinutes",
        header: "Duration",
        cell: (info) => {
            const minutes = info.getValue<number>();
            if (minutes == null) return "N/A";
            const hrs = Math.floor(minutes / 60);
            const mins = Math.round(minutes % 60);
            if (hrs > 0) {
                return `${hrs}h ${mins}m`;
            }
            return `${mins}m`;
        },
    }
];