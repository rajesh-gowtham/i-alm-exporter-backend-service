/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CellContext,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  PaginationState,
  SortingState,
  useReactTable,
  getFilteredRowModel,
} from "@tanstack/react-table";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import * as XLSX from "xlsx";
import useEmissionsStore from "@/lib/stores/emissions-store";
import { columns, EmissionsTableRow } from "./columns";
import { Skeleton } from "@/components/ui/skeleton";
import useSWR from "swr";
import { getEmissionsTableData1 } from "@/lib/api/emissions-endpoints";

const isCellFunction = (
  cell: any
): cell is (info: CellContext<EmissionsTableRow, unknown>) => string => {
  return typeof cell === "function";
};

const generateExcelData = (records: EmissionsTableRow[]) => {
  return records.map((record) =>
    columns.reduce((acc, column) => {
      const key = column.accessorKey as keyof EmissionsTableRow;
      const value = record[key];
      const header = column.header as string;

      // Create proper cell context
      const context = {
        getValue: () => value,
        row: { original: record },
        column: column,
      } as unknown as CellContext<EmissionsTableRow, unknown>;

      // Use type guard to safely call cell function
      acc[header] =
        column.cell && isCellFunction(column.cell)
          ? column.cell(context)
          : value;

      return acc;
    }, {} as Record<string, unknown>)
  );
};

const EMISSION_THRESHOLD_TOTAL = 100; // TODO: Adjust as needed or move to config

export default function EmissionsTable() {
  const { filters, tableRows, setTableRows } = useEmissionsStore();
  const [total, setTotal] = useState(0);

  // Table states: sorting (unused) and pagination state
  const [sorting, setSorting] = useState<SortingState>([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [columnFilters, setColumnFilters] = useState<any[]>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0, // zero-based
    pageSize: 20,
  });
  const [isExporting, setIsExporting] = useState(false);

  const { data: pagedResponse, isLoading } = useSWR(
    filters.asset
      ? [
          `/emissions/${filters.asset}/table`,
          filters.asset,
          filters.dateRange!.from,
          filters.dateRange!.to,
          pagination.pageIndex,
          pagination.pageSize,
        ]
      : null,
    async ([_, vid, from, to, pageIndex, pageSize]) => {
      const offset = pageIndex * pageSize;
      const response = await getEmissionsTableData1(
        vid,
        from!,
        to!,
        offset,
        pageSize
      );
      return response;
    },
    {
      refreshInterval: 300_000,
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    }
  );

  const memoizedColumns = useMemo(() => columns, []);

  useEffect(() => {
    if (pagedResponse) {
      setTotal(pagedResponse.total);
      // Update the table rows with the fetched data
      setTableRows(pagedResponse.records);
    }
  }, [pagedResponse, setTableRows]);

  // Compute total page count
  const pageCount = useMemo(
    () => Math.ceil(total / pagination.pageSize),
    [total, pagination.pageSize]
  );

  const table = useReactTable<EmissionsTableRow>({
    data: tableRows,
    columns: memoizedColumns,
    manualPagination: true,
    pageCount,
    state: { sorting, globalFilter, columnFilters, pagination },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnFiltersChange: setColumnFilters,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    // getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    globalFilterFn: (row, columnId, filterValue) => {
      const val = row.getValue(columnId);
      return String(val).toLowerCase().includes(filterValue.toLowerCase());
    },
  });

  // Excel export: fetch all data from server (without pagination) and generate Excel file
  const handleExportExcel = useCallback(async () => {
    if (!filters.asset || isExporting) return;
    setIsExporting(true); // Start loading
    try {
      // Fetch the entire dataset (all records) without pagination parameters.
      const response = await getEmissionsTableData1(
        filters.asset,
        filters.dateRange!.from!,
        filters.dateRange!.to!
      );

      const worksheet = XLSX.utils.json_to_sheet(
        generateExcelData(response.records),
        {
          header: columns.map((c) => c.header as string),
        }
      );

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Emissions Data");
      XLSX.writeFile(
        workbook,
        `emissions-${new Date().toISOString().slice(0, 10)}.xlsx`
      );
    } catch (err) {
      console.error("Error exporting Excel:", err);
    } finally {
      setIsExporting(false); // End loading regardless of outcome
    }
  }, [filters.asset, filters.dateRange, isExporting]);

  if (isLoading) {
    // Render a skeleton table while loading
    return (
      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Emissions Table</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {/* Search UI skeleton */}
          <div className="flex items-center gap-2">
            <Skeleton className="h-8 w-44" />
            <Skeleton className="h-8 w-28" />
          </div>

          {/* Table skeleton */}
          <div className="overflow-x-auto">
            <Table className="min-w-[800px] sm:min-w-full">
              <TableHeader>
                <TableRow>
                  {columns.map((col) => (
                    <TableHead key={col.accessorKey}>
                      <Skeleton className="w-16 h-4" />
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...Array(5)].map((_, idx) => (
                  <TableRow key={idx}>
                    {columns.map((col) => (
                      <TableCell key={col.accessorKey}>
                        <Skeleton className="w-full h-4" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Pagination skeleton */}
          <div className="flex items-center justify-between pt-2">
            <Skeleton className="h-5 w-28" />
            <div className="flex gap-1">
              <Skeleton className="w-16 h-8" />
              <Skeleton className="w-16 h-8" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-none">
      <CardHeader>
        <CardTitle>Emissions Table</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {/* Search row */}
        <div className="flex items-center gap-2">
          <Input
            placeholder="Search any column..."
            value={globalFilter}
            onChange={(e) => setGlobalFilter(e.target.value)}
            className="max-w-sm"
          />
          {/* <Button variant="secondary" onClick={handleExportExcel}>
            Export Excel
          </Button> */}

          {/* Export Excel Button */}
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              onClick={handleExportExcel}
              disabled={isExporting}
            >
              {isExporting ? (
                <div className="flex items-center gap-2">
                  <span>Exporting...</span>
                  <svg
                    className="w-4 h-4 text-current animate-spin"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                </div>
              ) : (
                "Export Excel"
              )}
            </Button>
          </div>

          {/* Columns filter */}
          <div className="flex items-center justify-between min-h-16">
            {/* Column visibility */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="justify-start ml-auto">
                  Columns
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.columnDef.header?.toString() ?? column.id}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          {/*
            TODO: Virtualization for large datasets.
            For full virtualization support, install @tanstack/react-virtual:
            npm install @tanstack/react-virtual
            Then, use useVirtualizer to render only visible rows.
          */}
          <Table className="min-w-[800px] sm:min-w-full">
            <TableHeader>
              <TableRow>
                {table.getFlatHeaders().map((header) => (
                  <TableHead key={header.id}>
                    {header.column.getCanSort() ? (
                      <Button
                        variant="ghost"
                        onClick={() => header.column.toggleSorting()}
                        className="p-0 text-sm font-medium"
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        {{
                          asc: " ▲",
                          desc: " ▼",
                        }[header.column.getIsSorted() as string] ?? null}
                      </Button>
                    ) : (
                      flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )
                    )}
                    {/* Per-column filter UI */}
                    {/* {header.column.getCanFilter() && (
                      <div className="mt-1">
                        {header.column.id === "state" ? (
                          <select
                            className="border rounded px-1 py-0.5 text-xs w-full dark:bg-background"
                            value={
                              (table
                                .getColumn(header.column.id)
                                ?.getFilterValue() as string) || ""
                            }
                            onChange={(e) =>
                              table
                                .getColumn(header.column.id)
                                ?.setFilterValue(e.target.value)
                            }
                          >
                            <option value="">All</option>
                            <option value="Active">Active</option>
                            <option value="Idle">Idle</option>
                          </select>
                        ) : header.column.id === "date" ? (
                          <Input
                            type="date"
                            className="text-xs"
                            value={
                              (table
                                .getColumn(header.column.id)
                                ?.getFilterValue() as string) || ""
                            }
                            onChange={(e) =>
                              table
                                .getColumn(header.column.id)
                                ?.setFilterValue(e.target.value)
                            }
                          />
                        ) : typeof table
                            .getColumn(header.column.id)
                            ?.getFilterValue() === "number" ||
                          [
                            "co2_kg_h",
                            "avg_engine_load",
                            "minutes",
                            // "co2_kg_total", // Removed: replaced by calculation from co2KgH and timeMinutes
                            "fuel_gal",
                          ].includes(header.column.id) ? (
                          <Input
                            type="number"
                            className="text-xs"
                            placeholder="Filter"
                            value={
                              (table
                                .getColumn(header.column.id)
                                ?.getFilterValue() as string) || ""
                            }
                            onChange={(e) =>
                              table
                                .getColumn(header.column.id)
                                ?.setFilterValue(e.target.value)
                            }
                          />
                        ) : (
                          <Input
                            className="text-xs"
                            placeholder="Filter"
                            value={
                              (table
                                .getColumn(header.column.id)
                                ?.getFilterValue() as string) || ""
                            }
                            onChange={(e) =>
                              table
                                .getColumn(header.column.id)
                                ?.setFilterValue(e.target.value)
                            }
                          />
                        )}
                      </div>
                    )} */}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {table.getRowModel().rows.length ? (
                table.getRowModel().rows.map((row) => {
                  // Row highlighting for emission threshold
                  const co2Total =
                    (row.original?.co2KgH ?? 0) *
                    ((row.original?.timeMinutes ?? 0) / 60);
                  const highlight =
                    typeof co2Total === "number" &&
                    co2Total > EMISSION_THRESHOLD_TOTAL;
                  return (
                    <TableRow
                      key={row.id}
                      className={
                        highlight ? "bg-red-200 dark:bg-red-900/70" : ""
                      }
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id} className="text-sm">
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    {/* Friendly empty state message */}
                    <div className="flex flex-col items-center justify-center py-4">
                      <span className="text-base font-medium text-muted-foreground">
                        No emissions data found for the current filters.
                      </span>
                      <span className="text-xs text-muted-foreground">
                        Try adjusting your filters or date range.
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination Controls */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex-1 text-sm text-muted-foreground">
            Page {table.getState().pagination.pageIndex + 1} of{" "}
            {table.getPageCount()}
          </div>
          <div className="space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
