import React, { useEffect } from "react";
import useEmissionsStore from "@/lib/stores/emissions-store";
import axiosInstance from "@/lib/http-client";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { DatePickerWithRange } from "@/components/range-date-picker";
import { DateRange } from "react-day-picker";
import VehicleSelect from "@/components/vehicle-select";
import {
  Calendar,
  CalendarIcon,
  FuelIcon,
  SettingsIcon,
  Timer,
  WrenchIcon,
  XCircleIcon,
} from "lucide-react";
import AssetSelector from "./asset-select";

export type Vehicle = {
  name?: string;
  asset?: string;
  id?: string;
};

export type EmissionsFilters = {
  asset: string;
  state: "Active" | "Idle" | "Both";
  utilizationRange: [number, number];
  fuelRange: [number, number];
  dateRange: DateRange | undefined;
  assetOptions: string[];
};

const FiltersBar: React.FC = () => {
  const { filters, setFilters, resetFilters } = useEmissionsStore();

  // Fetch asset options from API
  useEffect(() => {
    async function fetchAssets() {
      try {
        const res = await axiosInstance.get("/overview/vehicles");
        const options = Array.isArray(res.data)
          ? res.data.map((v: Vehicle) => v.name || v.asset || v.id || String(v))
          : [];
        setFilters({ ...filters, assetOptions: options });
      } catch {
        // fallback to mock options on error
      }
    }
    fetchAssets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleInput = (
    field: keyof EmissionsFilters,
    value:
      | string
      | [number, number]
      | DateRange
      | undefined
      | "Active"
      | "Idle"
      | "Both"
      | string[]
  ) => {
    setFilters({ ...filters, [field]: value });
  };

  // Predefined options for utilization and fuel ranges
  const utilizationOptions = [
    { label: "Any", value: [0, 12] },
    { label: "0-2 hrs", value: [0, 2] },
    { label: "2-4 hrs", value: [2, 4] },
    { label: "4-6 hrs", value: [4, 6] },
    { label: "6-8 hrs", value: [6, 8] },
    { label: "8+ hrs", value: [8, 12] },
  ];

  const fuelOptions = [
    { label: "Any", value: [0, 50] },
    { label: "0-10 gal", value: [0, 10] },
    { label: "10-20 gal", value: [10, 20] },
    { label: "20-30 gal", value: [20, 30] },
    { label: "30+ gal", value: [30, 50] },
  ];

  // Find the current label for selected ranges
  const selectedUtilizationLabel =
    utilizationOptions.find(
      (option) =>
        option.value[0] === filters.utilizationRange[0] &&
        option.value[1] === filters.utilizationRange[1]
    )?.label || "Custom";

  const selectedFuelLabel =
    fuelOptions.find(
      (option) =>
        option.value[0] === filters.fuelRange[0] &&
        option.value[1] === filters.fuelRange[1]
    )?.label || "Custom";

  return (
    <div className="flex flex-wrap items-center w-full gap-x-3 gap-y-2">
      {/* Asset Selector */}
      <div className="flex items-center w-64 gap-2 px-2 py-1">
        <VehicleSelect
          value={filters.asset}
          onChange={(value) => handleInput("asset", value.id)}
          aria-label="Asset"
        />
      </div>

      <div className="flex items-center w-64 gap-2 px-2 py-1">
        <AssetSelector />
      </div>

      {/* State Selector */}
      {/* <div className="flex items-center gap-2 px-2 py-1 border border-green-100 rounded-full bg-green-50/50 dark:bg-gray-700/50 dark:border-gray-600">
        <span className="text-green-700 dark:text-green-300" aria-hidden="true">
          <SettingsIcon className="w-4 h-4" />
        </span>
        <div className="flex gap-1" role="group" aria-label="State">
          {["Active", "Idle", "Both"].map((state) => (
            <Button
              key={state}
              type="button"
              size="sm"
              variant="ghost"
              className={`px-1.5 py-0 h-6 text-xs font-medium rounded-md ${
                filters.state === state
                  ? "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300"
                  : "text-green-700 hover:bg-green-50 dark:text-green-300 dark:hover:bg-gray-700/50"
              }`}
              aria-pressed={filters.state === state}
              aria-label={state}
              tabIndex={0}
              onClick={() => handleInput("state", state)}
            >
              {state}
            </Button>
          ))}
        </div>
      </div> */}

      {/* Utilization Range Select */}
      {/* <div className="flex items-center gap-2 px-2 py-1 border border-purple-100 rounded-full bg-purple-50/50 dark:bg-gray-700/50 dark:border-gray-600">
        <span
          className="text-purple-500 dark:text-purple-300"
          aria-hidden="true"
        >
          <Timer className="w-4 h-4" />
        </span>
        <Select
          value={JSON.stringify(filters.utilizationRange)}
          onValueChange={(value) =>
            handleInput("utilizationRange", JSON.parse(value))
          }
        >
          <SelectTrigger
            id="utilizationRange"
            name="utilizationRange"
            className="w-24 text-xs bg-transparent border-0 shadow-none h-7 focus:ring-0 focus:ring-offset-0 dark:text-gray-200"
            aria-label="Utilisation"
          >
            <SelectValue placeholder={selectedUtilizationLabel} />
          </SelectTrigger>
          <SelectContent>
            {utilizationOptions.map((option) => (
              <SelectItem
                key={option.label}
                value={JSON.stringify(option.value)}
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div> */}

      {/* Fuel Range Select */}
      {/* <div className="flex items-center gap-2 px-2 py-1 border border-blue-100 rounded-full bg-blue-50/50 dark:bg-gray-700/50 dark:border-gray-600">
        <span className="text-blue-700 dark:text-blue-300" aria-hidden="true">
          <FuelIcon className="w-4 h-4" />
        </span>
        <Select
          value={JSON.stringify(filters.fuelRange)}
          onValueChange={(value) => handleInput("fuelRange", JSON.parse(value))}
        >
          <SelectTrigger
            id="fuelRange"
            name="fuelRange"
            className="w-24 text-xs bg-transparent border-0 shadow-none h-7 focus:ring-0 focus:ring-offset-0 dark:text-gray-200"
            aria-label="Fuel"
          >
            <SelectValue placeholder={selectedFuelLabel} />
          </SelectTrigger>
          <SelectContent>
            {fuelOptions.map((option) => (
              <SelectItem
                key={option.label}
                value={JSON.stringify(option.value)}
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div> */}

      {/* Date Range Picker */}
      <div className="flex items-center gap-2 px-2 py-1">
        <DatePickerWithRange
          className=""
          dateRange={filters.dateRange}
          onDateRangeChange={(range) => handleInput("dateRange", range)}
          aria-label="Date Range"
        />
      </div>

      {/* Clear Filters Button - Push to far right */}
      {/* <div className="flex items-center ml-auto">
        <Button
          type="button"
          size="sm"
          variant="ghost"
          className="px-3 py-0 text-xs bg-gray-100 rounded-full h-7 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-200"
          onClick={resetFilters}
          aria-label="Clear Filters"
        >
          <XCircleIcon className="w-4 h-4" />
          <span className="sr-only">Clear Filters</span>
        </Button>
      </div> */}
    </div>
  );
};

export default FiltersBar;
