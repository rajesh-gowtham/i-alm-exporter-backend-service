import React, { useEffect, useRef, useState } from "react";
import {
  Clock,
  Leaf,
  TrendingUp,
  // Trophy, // Removed unused import as Top Emitters card was removed
  PieChart,
  LucideIcon,
} from "lucide-react";
import useEmissionsStore from "@/lib/stores/emissions-store";
import useSWR from "swr";
import { getEmissionsSummary1 } from "@/lib/api/emissions-endpoints";

// Robust type for summary card data
export interface SummaryCardData {
  title: "Total CO₂ (kg)" | "Idle Hours" | "Active Hours" | "Idle %";
  value: string | number | { value: number; unit: string };
  unit?: string;
}

// Icon and color mapping for each card
const cardMeta: Record<
  SummaryCardData["title"],
  { icon: LucideIcon; color: string }
> = {
  "Total CO₂ (kg)": { icon: Leaf, color: "text-green-700 dark:text-green-300" },
  "Idle Hours": { icon: Clock, color: "text-yellow-800 dark:text-yellow-300" },
  "Active Hours": {
    icon: TrendingUp,
    color: "text-blue-700 dark:text-blue-300",
  },
  "Idle %": { icon: PieChart, color: "text-pink-700 dark:text-pink-300" },
};

const EmissionSummaryCards: React.FC = () => {
  const { filters, summaryCards } = useEmissionsStore();
  const [cards, setCards] = useState<SummaryCardData[]>(summaryCards);

  const { data, isLoading } = useSWR(
    filters.asset
      ? [
          `/emissions/${filters.asset}/summary`,
          filters.asset,
          filters.dateRange!.from,
          filters.dateRange!.to,
        ]
      : null,
    async ([_, vid, from, to]) => {
      const response = await getEmissionsSummary1(vid, from!, to!);
      return response;
    },
    {
      refreshInterval: 300_000,
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    }
  );

  useEffect(() => {
    if (data && !isLoading) {
      const newCards: SummaryCardData[] = [
        {
          title: "Total CO₂ (kg)",
          value: data.totalEmissionsKg,
        },
        {
          title: "Idle Hours",
          value: Math.round(data.idleHours * 10) / 10,
        },
        {
          title: "Active Hours",
          value: Math.round(data.activeHours * 10) / 10,
        },
        {
          title: "Idle %",
          value: data.idlePercentage,
        },
      ];
      setCards(newCards);
    }
  }, [data]);

  // Drag-and-drop state
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const dragOverIdx = useRef<number | null>(null);

  const handleDragStart = (idx: number) => setDraggedIdx(idx);
  const handleDragEnter = (idx: number) => {
    dragOverIdx.current = idx;
  };
  const handleDragEnd = () => {
    if (
      draggedIdx !== null &&
      dragOverIdx.current !== null &&
      draggedIdx !== dragOverIdx.current
    ) {
      const newCards = [...cards];
      const [removed] = newCards.splice(draggedIdx, 1);
      newCards.splice(dragOverIdx.current, 0, removed);
      setCards(newCards);
    }
    setDraggedIdx(null);
    dragOverIdx.current = null;
  };

  return (
    <div
      className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4"
      role="list"
      aria-label="Summary KPIs"
    >
      {cards.map((card, idx) => {
        const meta = cardMeta[card.title];

        function isValueUnitObject(
          val: unknown
        ): val is { value: number; unit: string } {
          return (
            typeof val === "object" &&
            val !== null &&
            "value" in val &&
            "unit" in val
          );
        }

        let valueDisplay: string | number = "";
        if (isValueUnitObject(card.value)) {
          valueDisplay = `${card.value.value.toLocaleString()} ${
            card.value.unit
          }`;
        } else if (
          typeof card.value === "string" ||
          typeof card.value === "number"
        ) {
          valueDisplay = card.value;
        } else {
          valueDisplay = "";
        }

        return (
          <div
            key={card.title}
            draggable
            tabIndex={0}
            aria-grabbed={draggedIdx === idx}
            aria-label={`Drag to reorder ${card.title} card`}
            role="listitem"
            onDragStart={() => handleDragStart(idx)}
            onDragEnter={() => handleDragEnter(idx)}
            onDragEnd={handleDragEnd}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                handleDragStart(idx);
              }
            }}
            className={`transition-shadow focus-visible:ring-2 focus-visible:ring-blue-400 ${
              draggedIdx === idx ? "ring-2 ring-blue-400" : ""
            }`}
            style={{ cursor: "grab" }}
          >
            <StatCard
              icon={meta.icon}
              value={valueDisplay}
              label={card.title}
              iconColor={meta.color}
            />
          </div>
        );
      })}
    </div>
  );
};

interface StatCardProps {
  icon: LucideIcon;
  value: string | number;
  label: string;
  iconColor?: string; // Tailwind color class for the icon
}

export const StatCard: React.FC<StatCardProps> = ({
  icon: Icon,
  value,
  label,
  iconColor = "text-gray-800",
}) => {
  return (
    <div className="flex items-center p-6 rounded-2xl shadow-sm min-w-[14rem]">
      <div className={`flex-shrink-0 ${iconColor}`}>
        <Icon className="w-8 h-8" />
      </div>
      <div className="ml-6">
        <div className="text-3xl font-semibold text-gray-900 dark:text-primary-foreground">
          {value}
        </div>
        <div className="text-base text-gray-500 dark:text-muted-foreground">
          {label}
        </div>
      </div>
    </div>
  );
};

export default EmissionSummaryCards;
