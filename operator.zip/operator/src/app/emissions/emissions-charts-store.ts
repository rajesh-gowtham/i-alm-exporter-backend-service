/* eslint-disable @typescript-eslint/no-explicit-any */
import { create } from 'zustand';

export type EmissionGroup = 'carbonOxides' | 'nitrogenGases' | 'particulates';
export type EmissionsView = 'active' | 'idle';

interface EmissionsStore {
    selectedGroup: EmissionGroup;
    setSelectedGroup: (g: EmissionGroup) => void;
    selectedAssetId: number;
    setSelectedAssetId: (id: number) => void;
    viewMode: EmissionsView;
    setViewMode: (v: EmissionsView) => void;
    emissionsData: Record<number, any>; // key: assetId, value: full asset data
    setEmissionsData: (data: Record<number, any>) => void;
}

export const useEmissionsChartsStore = create<EmissionsStore>((set) => ({
    selectedGroup: 'carbonOxides',
    setSelectedGroup: (selectedGroup) => set({ selectedGroup }),
    selectedAssetId: 154, // default asset
    setSelectedAssetId: (selectedAssetId) => set({ selectedAssetId }),
    viewMode: 'active',
    setViewMode: (viewMode) => set({ viewMode }),
    emissionsData: {},
    setEmissionsData: (emissionsData) => set({ emissionsData }),
}));
