import React from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChevronDown } from "lucide-react";

interface Metric {
  key: string;
  label: string;
}

interface ChartFilterDropdownProps {
  metrics: Metric[];
  visibleKeys: string[];
  setVisibleKeys: (keys: string[]) => void;
}

export const ChartFilterDropdown: React.FC<ChartFilterDropdownProps> = ({
  metrics,
  visibleKeys,
  setVisibleKeys,
}) => {
  const allKeys = metrics.map((m) => m.key);

  const handleToggle = (key: string) => {
    setVisibleKeys(
      visibleKeys.includes(key)
        ? visibleKeys.filter((k) => k !== key)
        : [...visibleKeys, key]
    );
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className="flex items-center gap-1 px-3 py-2 text-sm font-medium"
        >
          Show/Hide Charts{" "}
          <span className="ml-1 text-xs text-muted-foreground">
            ({visibleKeys.length}/{metrics.length})
          </span>
          <ChevronDown className="w-4 h-4 ml-1" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3" align="start" sideOffset={6}>
        <div className="flex gap-2 mb-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setVisibleKeys(allKeys)}
          >
            Show All
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setVisibleKeys([])}>
            Hide All
          </Button>
        </div>
        <ScrollArea className="max-h-[calc(100vh-8rem)] pr-2">
          <div className="flex flex-col gap-1">
            {metrics.map((m) => (
              <label
                key={m.key}
                className="flex items-center gap-2 px-1 py-1 text-sm rounded cursor-pointer hover:bg-muted"
                htmlFor={`chart-checkbox-${m.key}`}
              >
                <Checkbox
                  id={`chart-checkbox-${m.key}`}
                  checked={visibleKeys.includes(m.key)}
                  onCheckedChange={() => handleToggle(m.key)}
                  className="mr-1"
                />
                {m.label}
              </label>
            ))}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
};
