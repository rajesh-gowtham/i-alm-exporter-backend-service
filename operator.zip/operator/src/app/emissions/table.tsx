import { useMemo, useState } from "react";
import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  getFilteredRowModel,
  SortingState,
  PaginationState,
} from "@tanstack/react-table";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { columns as allColumns, EmissionsTableRow } from "./columns";
import { useEmissionsChartsStore } from "./emissions-charts-store";

const ROWS_PER_PAGE = 20;

const emissionGroupColumnKeys: Record<string, string[]> = {
  carbonOxides: [
    "date",
    "state",
    "co2Percent",
    "coPercent",
    "co2KgH",
    "coGH",
    "avgEngineLoad",
    "timeMinutes",
    "co2KgGal",
    "coGGal",
    "hcGGal",
  ],
  nitrogenGases: [
    "date",
    "state",
    "noGH",
    "no2GH",
    "noxGH",
    "avgEngineLoad",
    "timeMinutes",
    "noGGal",
    "no2GGal",
    "noxGGal",
  ],
  particulates: [
    "date",
    "state",
    "pmUgM3",
    "pnCm3",
    "pmGH",
    "pnH",
    "pmGGal",
    "pnGal",
    "avgEngineLoad",
    "timeMinutes",
  ],
};

export default function EmissionsTable() {
  const { selectedAssetId, emissionsData, viewMode, selectedGroup } =
    useEmissionsChartsStore();

  // 1. Get records for selected asset and view
  const asset = emissionsData[selectedAssetId];
  const rows: EmissionsTableRow[] = useMemo(() => {
    if (!asset || !asset.emissions) return [];
    const arr = asset.emissions[viewMode] || [];
    // Map to your table row format (adapt keys as needed)
    return arr.map((r: any) => ({
      assetId: selectedAssetId.toString(),
      date: r.date,
      state: viewMode === "active" ? "Active" : "Idle",
      co2Percent: r.CO2_percent ?? null,
      coPercent: r.CO_percent ?? null,
      co2KgH: r.CO2_kg_per_hr ?? null,
      coGH: r.CO_g_per_hr ?? null,
      noGH: r.NO_g_per_hr ?? null,
      no2GH: r.NO2_g_per_hr ?? null,
      noxGH: r.NOx_g_per_hr ?? null,
      pmUgM3: r.PM_ug_per_m3 ?? null,
      pnCm3: r.PN_num_per_cm3 ?? null,
      pmGH: r.PM_g_per_hr ?? null,
      pnH: r.PN_num_per_hr ?? null,
      avgEngineLoad: r.engineLoadPercent ?? null,
      timeMinutes:
        viewMode === "active"
          ? (r.totalActiveHours ?? 0) * 60
          : (r.totalIdleHours ?? 0) * 60,
      // for fuel
      co2KgGal: r.CO2_kg_per_gal_fuel ?? null,
      coGGal: r.CO_g_per_gal_fuel ?? null,
      hcGGal: r.HC_g_per_gal_fuel ?? null,
      noGGal: r.NO_g_per_gal_fuel ?? null,
      no2GGal: r.NO2_g_per_gal_fuel ?? null,
      noxGGal: r.NOx_g_per_gal_fuel ?? null,
      pmGGal: r.PM_g_per_gal_fuel ?? null,
      pnGal: r.PN_num_per_gal_fuel ?? null,
    }));
  }, [asset, selectedAssetId, viewMode]);

  // 2. Only show columns for the current group
  const groupKeys = emissionGroupColumnKeys[selectedGroup];
  const columns = useMemo(
    () => allColumns.filter((c) => groupKeys.includes(c.accessorKey as string)),
    [selectedGroup]
  );

  // 3. Table state and TanStack table
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<any[]>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: ROWS_PER_PAGE,
  });

  const table = useReactTable<EmissionsTableRow>({
    data: rows,
    columns,
    manualPagination: false,
    state: { sorting, columnFilters, pagination },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    globalFilterFn: (row, columnId, filterValue) => {
      const val = row.getValue(columnId);
      return String(val).toLowerCase().includes(filterValue.toLowerCase());
    },
  });

  return (
    <Card className="shadow-none">
      <CardHeader className="pb-0">
        <div className="flex items-center gap-3 mb-2">
          <CardTitle>Emissions Table</CardTitle>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="justify-start">
                Columns
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              {table
                .getAllColumns()
                .filter((column) => column.getCanHide())
                .map((column) => (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) =>
                      column.toggleVisibility(!!value)
                    }
                  >
                    {column.columnDef.header?.toString() ?? column.id}
                  </DropdownMenuCheckboxItem>
                ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        {/* Table */}
        <div className="overflow-x-auto">
          <Table className="min-w-[800px] sm:min-w-full">
            <TableHeader>
              <TableRow>
                {table.getFlatHeaders().map((header) => (
                  <TableHead key={header.id}>
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {table.getRowModel().rows.length ? (
                table.getRowModel().rows.map((row) => (
                  <TableRow key={row.id}>
                    {row.getVisibleCells().map((cell) => (
                      <TableCell key={cell.id} className="text-sm">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    <div className="flex flex-col items-center justify-center py-4">
                      <span className="text-base font-medium text-muted-foreground">
                        No emissions data found for the current
                        asset/group/view.
                      </span>
                      <span className="text-xs text-muted-foreground">
                        Try adjusting your filters or date range.
                      </span>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        {/* Pagination Controls */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex-1 text-sm text-muted-foreground">
            Page {table.getState().pagination.pageIndex + 1} of{" "}
            {Math.ceil(rows.length / ROWS_PER_PAGE)}
          </div>
          <div className="space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                setPagination((p) => ({
                  ...p,
                  pageIndex: Math.max(0, p.pageIndex - 1),
                }))
              }
              disabled={pagination.pageIndex === 0}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                setPagination((p) => ({
                  ...p,
                  pageIndex: p.pageIndex + 1,
                }))
              }
              disabled={
                (pagination.pageIndex + 1) * ROWS_PER_PAGE >= rows.length
              }
            >
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
