import { create } from "zustand";
import { Vessel } from "@/lib/models";

type State = {
  vessels: Vessel[];
  selectedVessel: Vessel | null;
};

type Actions = {
  setVessels: (vessels: Vessel[]) => void;
  addVessel: (vessel: Vessel) => void;
  updateVessel: (id: string, updatedVessel: Vessel) => void;
  deleteVessel: (id: string) => void;
  setSelectedVessel: (vessel: Vessel | null) => void;
};

const initialState: State = {
  vessels: [],
  selectedVessel: null,
};

const useVesselStore = create<State & Actions>()((set) => ({
  ...initialState,

  setVessels: (vessels) => set({ vessels }),

  addVessel: (vessel) =>
    set((state) => ({ vessels: [...state.vessels, vessel] })),

  updateVessel: (id, updatedVessel) =>
    set((state) => ({
      vessels: state.vessels.map((v) => (v.id === id ? updatedVessel : v)),
    })),

  deleteVessel: (id) =>
    set((state) => ({
      vessels: state.vessels.filter((v) => v.id !== id),
    })),

  setSelectedVessel: (vessel) => set({ selectedVessel: vessel }),
}));

export default useVesselStore;
