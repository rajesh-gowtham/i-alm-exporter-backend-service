import { create } from "zustand";
import { PointofWork } from "@/lib/models";

type State = {
  pointofWorks: PointofWork[];
  selectedPointofWork: PointofWork | null;
};

type Actions = {
  setPointofWorks: (pointofWorks: PointofWork[]) => void;
  addPointofWork: (pointofWork: PointofWork) => void;
  updatePointofWork: (id: string, updatedPointofWork: PointofWork) => void;
  deletePointofWork: (id: string) => void;
  setSelectedPointofWork: (pointofWork: PointofWork | null) => void;
};

const initialState: State = {
  pointofWorks: [],
  selectedPointofWork: null,
};

const usePointofWorkStore = create<State & Actions>()((set) => ({
  ...initialState,

  setPointofWorks: (pointofWorks) => set({ pointofWorks }),

  addPointofWork: (pointofWork) =>
    set((state) => ({ pointofWorks: [...state.pointofWorks, pointofWork] })),

  updatePointofWork: (id, updatedPointofWork) =>
    set((state) => ({
      pointofWorks: state.pointofWorks.map((v) => (v.id === id ? updatedPointofWork : v)),
    })),

  deletePointofWork: (id) =>
    set((state) => ({
      pointofWorks: state.pointofWorks.filter((v) => v.id !== id),
    })),

  setSelectedPointofWork: (PointofWork) => set({ selectedPointofWork: PointofWork }),
}));

export default usePointofWorkStore;
