import { create } from "zustand";
import { WorkInstruction } from "@/lib/models";

type State = {
  WorkInstructions: WorkInstruction[];
  selectedWorkInstruction: WorkInstruction | null;
};

type Actions = {
  setWorkInstructions: (WorkInstructions: WorkInstruction[]) => void;
  addWorkInstruction: (WorkInstruction: WorkInstruction) => void;
  updateWorkInstruction: (id: string, updatedWorkInstruction: WorkInstruction) => void;
  deleteWorkInstruction: (id: string) => void;
  setSelectedWorkInstruction: (WorkInstruction: WorkInstruction | null) => void;
};

const initialState: State = {
  WorkInstructions: [],
  selectedWorkInstruction: null,
};

const useWorkInstructionStore = create<State & Actions>()((set) => ({
  ...initialState,

  setWorkInstructions: (WorkInstructions) => set({ WorkInstructions }),

  addWorkInstruction: (WorkInstruction) =>
    set((state) => ({ WorkInstructions: [...state.WorkInstructions, WorkInstruction] })),

  updateWorkInstruction: (id, updatedWorkInstruction) =>
    set((state) => ({
      WorkInstructions: state.WorkInstructions.map((v) => (v.id === id ? updatedWorkInstruction : v)),
    })),

  deleteWorkInstruction: (id) =>
    set((state) => ({
      WorkInstructions: state.WorkInstructions.filter((v) => v.id !== id),
    })),

  setSelectedWorkInstruction: (WorkInstruction) => set({ selectedWorkInstruction: WorkInstruction }),
}));

export default useWorkInstructionStore;
