import { create } from "zustand";
import { ContainerYardInventory } from "@/lib/models";

type State = {
  containerYardInventorys: ContainerYardInventory[];
  selectedContainerYardInventory: ContainerYardInventory | null;
};

type Actions = {
  setContainerYardInventorys: (containerYardInventorys: ContainerYardInventory[]) => void;
  addContainerYardInventory: (containerYardInventory: ContainerYardInventory) => void;
  updateContainerYardInventory: (id: string, updatedContainerYardInventory: ContainerYardInventory) => void;
  deleteContainerYardInventory: (id: string) => void;
  setSelectedContainerYardInventory: (containerYardInventory: ContainerYardInventory | null) => void;
};

const initialState: State = {
  containerYardInventorys: [],
  selectedContainerYardInventory: null,
};

const useContainerYardInventoryStore = create<State & Actions>()((set) => ({
  ...initialState,

  setContainerYardInventorys: (containerYardInventorys) => set({ containerYardInventorys }),

  addContainerYardInventory: (containerYardInventory) =>
    set((state) => ({ containerYardInventorys: [...state.containerYardInventorys, containerYardInventory] })),

  updateContainerYardInventory: (id, updatedContainerYardInventory) =>
    set((state) => ({
      containerYardInventorys: state.containerYardInventorys.map((v) => (v.id === id ? updatedContainerYardInventory : v)),
    })),

  deleteContainerYardInventory: (id) =>
    set((state) => ({
      containerYardInventorys: state.containerYardInventorys.filter((v) => v.id !== id),
    })),

  setSelectedContainerYardInventory: (containerYardInventory) => set({ selectedContainerYardInventory: containerYardInventory }),
}));

export default useContainerYardInventoryStore;
