import { DateTimePicker } from "@/components/datetimepicker";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownWhite, ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { DATE_TIME_FORMAT, vesselVisitPhasesOptionList, visitClassificationOptionList } from "@/lib/constants";
import { VesselVisit } from "@/lib/models";
import { VesselVistLabels } from "@/lib/models/form-constants/formLabels";
import { VesselVisitSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";
import useVesselStore from "../store/vesselStore";
import { formatCustomDateTime, safeParseDate } from "@/lib/utils";

interface VesselVisitFormProps {
  vesselVisit?: VesselVisit;
  onClose: () => void;
  onSubmit: (data: VesselVisit) => void;
}

export default function VesselVisitForm({
  vesselVisit,
  onClose,
  onSubmit,
}: VesselVisitFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  const vesselStore = useVesselStore();
  // console.log("vessel", vesselStore.vessels);
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    clearErrors,
    setError,
    formState: { errors },
  } = useForm<z.infer<typeof VesselVisitSchema>>({
    resolver: zodResolver(VesselVisitSchema),
    defaultValues: vesselVisit
      ? {
        ...vesselVisit,
        id:
          typeof vesselVisit.id === "string"
            ? parseInt(vesselVisit.id)
            : vesselVisit.id,
        eta:
          vesselVisit.eta instanceof Date
            ? vesselVisit.eta.toISOString()
            : vesselVisit.eta,
        etd:
          vesselVisit.etd instanceof Date
            ? vesselVisit.etd.toISOString()
            : vesselVisit.etd,
        ata:
          vesselVisit.ata instanceof Date
            ? vesselVisit.ata.toISOString()
            : vesselVisit.ata,
        atd:
          vesselVisit.atd instanceof Date
            ? vesselVisit.atd.toISOString()
            : vesselVisit.atd,
        startWorkTime:
          vesselVisit.startWorkTime instanceof Date
            ? vesselVisit.startWorkTime.toISOString()
            : vesselVisit.startWorkTime,
        endWorkTime:
          vesselVisit.endWorkTime instanceof Date
            ? vesselVisit.endWorkTime.toISOString()
            : vesselVisit.endWorkTime,
      }
      : undefined,
  });
  const phase = watch("phase");
  const eta = watch("eta");
  const etd = watch("etd");
  const ata = watch("ata");
  const atd = watch("atd");
  const startWorkTime = watch("startWorkTime");
  const endWorkTime = watch("endWorkTime");

  const vesselVisitMemo = useMemo(() => vesselVisit, [vesselVisit]);

  const selectedVesselId = watch("vesselId"); // Watch for vessel ID change

  useEffect(() => {
    console.log(" selectedVesselId ", selectedVesselId);
    const selectedVessel = vesselStore?.vessels?.find((item) => item.id === Number(selectedVesselId));
    console.log(" selectedVessel ", selectedVessel);
    if (selectedVessel) {
      setValue("lineOperator", selectedVessel.operator || "", { shouldValidate: true });
    } else {
      setValue("lineOperator", "",);
    }
  }, [selectedVesselId, setValue, vesselStore.vessels]);


  useEffect(() => {
    if (vesselVisitMemo) {
      reset({
        ...vesselVisitMemo,
        id:
          typeof vesselVisitMemo.id === "string"
            ? parseInt(vesselVisitMemo.id)
            : vesselVisitMemo.id,
        eta:
          vesselVisitMemo.eta instanceof Date
            ? vesselVisitMemo.eta.toISOString()
            : vesselVisitMemo.eta,
        etd:
          vesselVisitMemo.etd instanceof Date
            ? vesselVisitMemo.etd.toISOString()
            : vesselVisitMemo.etd,
        ata:
          vesselVisitMemo.ata instanceof Date
            ? vesselVisitMemo.ata.toISOString()
            : vesselVisitMemo.ata,
        atd:
          vesselVisitMemo.atd instanceof Date
            ? vesselVisitMemo.atd.toISOString()
            : vesselVisitMemo.atd,
        startWorkTime:
          vesselVisitMemo.startWorkTime instanceof Date
            ? vesselVisitMemo.startWorkTime.toISOString()
            : vesselVisitMemo.startWorkTime,
        endWorkTime:
          vesselVisitMemo.endWorkTime instanceof Date
            ? vesselVisitMemo.endWorkTime.toISOString()
            : vesselVisitMemo.endWorkTime,
      });
    }
  }, [vesselVisitMemo, reset]);

  function isValidDate(dateStr: string | undefined | null): boolean {
    if (!dateStr || typeof dateStr !== "string") return false;
    const date = new Date(dateStr);
    return !isNaN(date.getTime());
  }
  const getIsValidrecordByPhase = (phase: string) => {
    console.log("phase: string ", phase);

    if (phase === "Arrived") {
      const isvalidStartworktime = (ata && isValidDate(ata));
      if (!isvalidStartworktime) {
        setError("ata", {
          message: "required"
        })
      }
      clearErrors("atd")
      clearErrors("startWorkTime")
      clearErrors("endWorkTime")
      return isvalidStartworktime
    } else if (phase === "Working") {
      const isvalidStartworktime = (startWorkTime && isValidDate(startWorkTime));
      console.log(" isvalidStartworktime", isvalidStartworktime);
      if (!isvalidStartworktime) {
        setError("startWorkTime", {
          message: "required"
        })
      }
      clearErrors("ata")
      clearErrors("atd")
      clearErrors("endWorkTime")
      return isvalidStartworktime
    } else if (phase === "Completed") {
      const isvalidEndworktime = (endWorkTime && isValidDate(endWorkTime));
      if (!isvalidEndworktime) {
        setError("endWorkTime", {
          message: "required"
        })
      }
      clearErrors("ata")
      clearErrors("atd")
      clearErrors("startWorkTime")
      return isvalidEndworktime
    } else if (phase === "Departed") {
      const isvalidAtd = (atd && isValidDate(atd));
      if (!isvalidAtd) {
        setError("atd", {
          message: "required"
        })
      }
      clearErrors("ata")
      clearErrors("startWorkTime")
      clearErrors("endWorkTime")
      return isvalidAtd
    } else {
      clearErrors("ata")
      clearErrors("atd")
      clearErrors("startWorkTime")
      clearErrors("endWorkTime")
    }
  }

  const submitHandler = async (formData: z.infer<typeof VesselVisitSchema>) => {
    console.log("Submit handler called", formData);
    const isvalid = getIsValidrecordByPhase(formData.phase);
    console.log("isValid", isvalid);
    if (formData.phase !== "Inbound" && (!isvalid)) {
      return
    }
    setIsLoading(true); // Set loading to true
    try {
      const payload = {
        ...formData,
        eta: new Date(formData?.eta).toISOString(),
        etd: new Date(formData?.etd).toISOString(),
        atd: formData?.atd ? new Date(formData?.atd).toISOString() : null,
        ata: formData?.ata ? new Date(formData?.ata).toISOString() : null,
        startWorkTime: formData.startWorkTime ? new Date(formData.startWorkTime).toISOString() : null,
        endWorkTime: formData.endWorkTime ? new Date(formData.endWorkTime).toISOString() : null,
      };
      await onSubmit(payload as VesselVisit);
    } catch (error) {
      console.log("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  console.log("formerrors", errors);
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-1">
      <div className="overflow-y-auto max-h-[450px] p-1">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
          <div>
            <Label>{VesselVistLabels._VisitRef}</Label>
            {(!VesselVisitSchema.shape.visitRef.isOptional()) && <MandatoryIcon />}
            <Input {...register("visitRef")}
              disabled={vesselVisit !== undefined}
              readOnly={vesselVisit !== undefined}
              error={!!errors.visitRef}
            />
          </div>
          <div>
            <Label>{VesselVistLabels._VesselName}</Label>
            {(!VesselVisitSchema.shape.vesselId.isOptional()) && <MandatoryIcon />}
            <DropdownWhite
              Label_Placeholder={VesselVistLabels._VesselName}
              fieldName="vesselId"
              fieldValue={vesselVisit?.vesselId + ""}
              setValue={setValue}
              clearErrors={clearErrors}
              optionsList={vesselStore?.vessels?.map(item => ({ label: item.vesselName, value: (item.id) + "" }))}
              error={!!errors.vesselId}
            />
          </div>
          <div>
            <Label>{VesselVistLabels._Phase}</Label>
            {(!VesselVisitSchema.shape.phase.isOptional()) && <MandatoryIcon />}
            <DropdownWhite
              Label_Placeholder={VesselVistLabels._Phase}
              fieldName="phase"
              fieldValue={vesselVisit?.phase || ""}
              setValue={setValue}
              clearErrors={clearErrors}
              optionsList={vesselVisitPhasesOptionList}
              error={!!errors.phase}
            />
          </div>

          <div>
            <Label>{VesselVistLabels._Inbound_Voyage}</Label>
            {(!VesselVisitSchema.shape.inboundVoyage.isOptional()) && <MandatoryIcon />}
            <Input {...register("inboundVoyage")}
              error={!!errors.inboundVoyage}
            />
          </div>

          <div>
            <Label>{VesselVistLabels._Outbound_Voyage}</Label>
            {(!VesselVisitSchema.shape.outboundVoyage.isOptional()) && <MandatoryIcon />}
            <Input {...register("outboundVoyage")}
              error={!!errors.outboundVoyage}
            />
          </div>

          <div>
            <Label>{VesselVistLabels._LineOperator}</Label>
            {(!VesselVisitSchema.shape.lineOperator.isOptional()) && <MandatoryIcon />}
            <Input {...register("lineOperator")}
              readOnly
              error={!!errors.lineOperator}
            />
          </div>
          <div>
            <Label>{VesselVistLabels._ETA}</Label>
            {(!VesselVisitSchema.shape.eta.isOptional()) && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={safeParseDate(eta)}
                onDateChange={(date) =>
                  setValue("eta",
                    format(date, DATE_TIME_FORMAT),
                    { shouldValidate: true }
                  )}
                error={!!errors.eta}
              />
            </div>
          </div>

          <div>
            <Label>{VesselVistLabels._ETD}</Label>
            {(!VesselVisitSchema.shape.etd.isOptional()) && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={etd && typeof etd === "string" ? new Date(etd) : null}
                onDateChange={(date) =>
                  setValue("etd",
                    formatCustomDateTime(date, ""),
                    { shouldValidate: true })
                }
                error={!!errors.etd}
              />
            </div>
          </div>

          <div>
            <Label>{VesselVistLabels._ATA}</Label>
            {phase === "Arrived" && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={ata && typeof ata === "string" ? new Date(ata) : null}
                onDateChange={(date) =>
                  setValue("ata",
                    formatCustomDateTime(date, ""),
                    { shouldValidate: true })
                }
                error={!!errors.ata}
              />
            </div>
          </div>

          <div>
            <Label>{VesselVistLabels._ATD}</Label>
            {phase === "Departed" && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={atd && typeof atd === "string" ? new Date(atd) : null}
                onDateChange={(date) =>
                  setValue("atd",
                    formatCustomDateTime(date, ""),
                    { shouldValidate: true })
                }
                error={!!errors.atd}
              />
            </div>
          </div>

          <div>
            <Label>{VesselVistLabels._StartWorkTime}</Label>
            {phase === "Working" && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={
                  startWorkTime && typeof startWorkTime === "string"
                    ? new Date(startWorkTime)
                    : null
                }
                onDateChange={(date) =>
                  setValue("startWorkTime",
                    formatCustomDateTime(date, ""),
                    { shouldValidate: true })
                }
                error={!!errors.startWorkTime}
              />
            </div>
          </div>

          <div>
            <Label>{VesselVistLabels._EndWorkTime}</Label>
            {phase === "Completed" && <MandatoryIcon />}
            <div className="w-[210px]">
              <DateTimePicker
                date={
                  endWorkTime && typeof endWorkTime === "string"
                    ? new Date(endWorkTime)
                    : null
                }
                onDateChange={(date) =>
                  setValue("endWorkTime",
                    formatCustomDateTime(date, ""),
                    { shouldValidate: true })
                }
                error={!!errors.endWorkTime}
              />
            </div>
          </div>
          <div>
            <Label>{VesselVistLabels._Classification}</Label>
            {(!VesselVisitSchema.shape.classification.isOptional()) && <MandatoryIcon />}
            <DropdownWhite
              Label_Placeholder={VesselVistLabels._Classification}
              fieldName="classification"
              fieldValue={vesselVisit?.classification || ""}
              setValue={setValue}
              clearErrors={clearErrors}
              optionsList={visitClassificationOptionList}
            />
          </div>

          <div>
            <Label>{VesselVistLabels._Service}</Label>
            {(!VesselVisitSchema.shape.service.isOptional()) && <MandatoryIcon />}
            <Input {...register("service")} />
          </div>
        </div>
      </div>

      <FormActions
        isEdit={vesselVisit?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>

  );
}
