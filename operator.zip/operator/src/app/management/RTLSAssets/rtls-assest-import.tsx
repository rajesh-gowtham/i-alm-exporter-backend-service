import FileImportManipulate from "@/components/FileImportManipulate";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ErrorToaster, FileImport, SuccessToaster } from "@/components/UtilComp";
import { RTLSAssetLabels } from "@/lib/models/form-constants/formLabels";
import { FileImportSchema, RTLSAssetSchema } from "@/lib/schemas";
import { addRTLSAssetsInBatch } from "@/lib/services/rtls-asset-service";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as XLSX from "xlsx";
import { z } from "zod";
const requiredBackendFields = ["readerIp", "readPointName", "antennaId", "itvId", "readerType", "readerModel", "locationId", "latitude", "longitude", "userId"];
const headerMap: Record<typeof RTLSAssetLabels[keyof typeof RTLSAssetLabels], string> = {
  [RTLSAssetLabels._Antenna_ID]: "antennaId",
  [RTLSAssetLabels._ITV_ID]: "itvId",
  [RTLSAssetLabels._Latitude]: "latitude",
  [RTLSAssetLabels._Longitude]: "longitude",
  [RTLSAssetLabels._ReadPoint_Name]: "readPointName",
  [RTLSAssetLabels._Reader_Type]: "readerType",
  [RTLSAssetLabels._UserId]: "userId",
  [RTLSAssetLabels._location_ID]: "locationId",
  [RTLSAssetLabels._Reader_IP]: "readerIp",
  [RTLSAssetLabels._Reader_Model]: "readerModel",
};


const numericFields = ['itvId', 'locationId'];
type RTLSAssetRecord = z.infer<typeof RTLSAssetSchema>;
type FormData = z.infer<typeof FileImportSchema>;
interface RTLSAssetsImportProps {
  handleImportError: (arg: any[]) => void;
  errorList: any[];
  setColumns: (arg: any) => void;
  setTableData: (arg: any) => void;
  columns: any[];
  tableData: any[];
  openCloseImport: (arg: string) => void;
  setIsImportError: (arg: boolean) => void;
}
export default function RTLSAssetsImport({ handleImportError, errorList, setColumns, setTableData, columns, tableData, openCloseImport, setIsImportError }: RTLSAssetsImportProps) {

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<RTLSAssetRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(errorList.length > 0);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);


  const batchInsert = async (records: RTLSAssetRecord[]) => {
    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;
      for (let i = 0; i < records.length; i += batchSize) {
        const batch = records.slice(i, i + batchSize);
        await addRTLSAssetsInBatch(batch);
        const progress = Math.min(100, ((i + batch.length) / totalRecords) * 100);
        setImportProgress(progress);
        await new Promise((r) => setTimeout(r, 100));
      }
      SuccessToaster("Import Completed", `${totalRecords} RTLS Assets imported successfully`);
      // navigate(privateRoute._Configuration + privateRoute._RTLSAsset);
      openCloseImport("CLEAR-SUCCESS");
      setIsImportError(false);
    } catch (error) {
      ErrorToaster("Import Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
      setShowConfirmModal(true);
    } finally {
      setBatchProcessing(false);
      setImportProgress(0);
      // setShowConfirmModal(false);
      reset();
    }
  };

  const updateData = (rowIndex: number, columnId: string, value: any) => {
    setTableData(prev =>
      prev.map((row, index) => {
        if (index === rowIndex) {
          return {
            ...row,
            [columnId]: value,
          };
        }
        return row;
      })
    );
  };

  useEffect(() => {
    if (tableData.length === 0) return;

    const validationResults = tableData.map((row, index) => {
      const result = RTLSAssetSchema.safeParse(row);
      return {
        row: index + 2,
        valid: result.success,
        errors: result.success ? [] : result.error.errors,
        data: result.success ? result.data : null
      };
    });

    const valid = validationResults.filter(r => r.valid).map(r => r.data) as RTLSAssetRecord[];
    const errors = validationResults.filter(r => !r.valid).map(r => ({
      row: r.row,
      issues: r.errors,
      original: tableData[r.row - 2]
    }));

    setValidRecords(valid);
    setValidationErrors(errors);
  }, [tableData]);

  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const [headerRow, ...rows] = jsonData;
        const headers = headerRow as string[];

        const errors: string[] = [];

        for (const readableHeader in headerMap) {
          const backendKey = headerMap[readableHeader];
          if (!headers.includes(readableHeader)) {
            if (requiredBackendFields.includes(backendKey)) {
              errors.push(`Missing required column: ${readableHeader}`);
            }
          }
        }

        const unknownHeaders = headers.filter(h => !headerMap[h]);
        if (unknownHeaders.length > 0) {
          unknownHeaders.forEach(h => errors.push(`Unknown column found: ${h}`));
        }

        if (errors.length > 0) {
          ErrorToaster("File validation failed:\n" + errors.join("\n"));
        }

        // 1. Extract raw data even if invalid
        const extractedData = rows.map((row) =>
          headers.reduce((obj, readableHeader, idx) => {
            const backendKey = headerMap[readableHeader];
            if (backendKey) {
              obj[backendKey] = row[idx] ?? '';
            }
            return obj;
          }, {} as Record<string, any>)
        );

        let errorCount = 0;
        const validRowsToInsert = [];
        const validatedRows = extractedData.map((row, index) => {
          console.log(" row ", row);

          if ("latitude" in row) {
            row["latitude"] = String(row["latitude"] ?? "");
          }
          if ("longitude" in row) {
            row["longitude"] = String(row["longitude"] ?? "");
          }
          const result = RTLSAssetSchema.safeParse(row);
          console.log(" result ", result);
          if (result.success) {
            validRowsToInsert.push(result.data);
            return { ...result.data, __rowValid: true };
          } else {
            errorCount += 1;
            return {
              ...row,
              __rowValid: false,
              __rowErrors: result.error.flatten().fieldErrors,
              __rowIndex: index + 2, // Excel row index
            };
          }
        });

        // 3. Set for editable table
        const newColumns = Object.keys(headerMap).map((readableHeader) => ({
          Header: readableHeader,
          accessor: headerMap[readableHeader],
        }));

        setColumns(newColumns);
        setTableData(validatedRows);
        // setShowConfirmModal(true);
        console.log("validatedRows", errorCount, validatedRows);
        if (errorCount === 0) {
          batchInsert(validRowsToInsert as RTLSAssetRecord[])
        } else {
          handleImportError(validatedRows);
        }
      } catch (error) {
        console.error(error);
        ErrorToaster("Failed to process file: " + (error as any).message);
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };



  return (

    < div >
      <FileImport
        errors={errors}
        handleSubmit={handleSubmit}
        processExcelFile={processExcelFile}
        register={register}
        setUploading={setUploading}
        uploading={uploading}
        backToParent={openCloseImport}
        filename="rtlsassetmaster.xlsx"
      />

      <Dialog
        open={showConfirmModal}
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
        <DialogContent className="max-w-[95vw] h-[85vh] flex flex-col p-0">
          <FileImportManipulate
            columns={columns}
            tableData={tableData}
            updateData={updateData}
            validationErrors={validationErrors}
            validRecords={validRecords}
            batchProcessing={batchProcessing}
            setShowConfirmModal={setShowConfirmModal}
            importProgress={importProgress}
            batchInsert={batchInsert}
            numericFields={numericFields}
          />
        </DialogContent>
      </Dialog>
    </div >
  );
}