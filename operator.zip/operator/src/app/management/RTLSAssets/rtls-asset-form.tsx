import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { RTLSAsset } from "@/lib/models";
import { RTLSAssetLabels } from "@/lib/models/form-constants/formLabels";
import { RTLSAssetSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";

interface RTLSAssetFormProps {
  RTLSAsset?: RTLSAsset;
  onClose: () => void;
  onSubmit: (data: RTLSAsset) => void;
}

export default function RTLSAssetForm({
  RTLSAsset,
  onClose,
  onSubmit,
}: RTLSAssetFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<z.infer<typeof RTLSAssetSchema>>({
    resolver: zodResolver(RTLSAssetSchema),
    defaultValues: RTLSAsset ? { ...RTLSAsset, id: Number(RTLSAsset.id) } : {},
  });

  const RTLSAssetMemo = useMemo(() => RTLSAsset, [RTLSAsset]);

  useEffect(() => {
    if (RTLSAssetMemo) {
      reset({
        ...RTLSAssetMemo,
        id: RTLSAssetMemo.id ? Number(RTLSAssetMemo.id) : undefined,
      });
    }
  }, [RTLSAssetMemo, reset]);

  const submitHandler = async (formData: z.infer<typeof RTLSAssetSchema>) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      await onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">

        <div>
          <Label>{RTLSAssetLabels._Antenna_ID}</Label>
          {(!RTLSAssetSchema.shape.antennaId.isOptional()) && <MandatoryIcon />}
          <Input {...register("antennaId")}
            error={!!errors.antennaId}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._ITV_ID}</Label>
          {(!RTLSAssetSchema.shape.itvId.isOptional()) && <MandatoryIcon />}
          <Input type="number" {...register("itvId", { valueAsNumber: true })}
            error={!!errors.itvId}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._Latitude}</Label>
          {(!RTLSAssetSchema.shape.latitude.isOptional()) && <MandatoryIcon />}
          <Input {...register("latitude")}
            error={!!errors.latitude}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._Longitude}</Label>
          {(!RTLSAssetSchema.shape.longitude.isOptional()) && <MandatoryIcon />}
          <Input {...register("longitude")}
            error={!!errors.longitude}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._ReadPoint_Name}</Label>
          {(!RTLSAssetSchema.shape.readPointName.isOptional()) && <MandatoryIcon />}
          <Input {...register("readPointName")}
            error={!!errors.readPointName}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._Reader_IP}</Label>
          {(!RTLSAssetSchema.shape.readerIp.isOptional()) && <MandatoryIcon />}
          <Input {...register("readerIp")}
            error={!!errors.readerIp}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._Reader_Model}</Label>
          {(!RTLSAssetSchema.shape.readerModel.isOptional()) && <MandatoryIcon />}
          <Input {...register("readerModel")}
            error={!!errors.readerModel}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._Reader_Type}</Label>
          {(!RTLSAssetSchema.shape.readerType.isOptional()) && <MandatoryIcon />}
          <Input {...register("readerType")}
            error={!!errors.readerType}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._UserId}</Label>
          {(!RTLSAssetSchema.shape.userId.isOptional()) && <MandatoryIcon />}
          <Input {...register("userId")}
            error={!!errors.userId}
          />
        </div>
        <div>
          <Label>{RTLSAssetLabels._location_ID}</Label>
          {(!RTLSAssetSchema.shape.locationId.isOptional()) && <MandatoryIcon />}
          <Input {...register("locationId", { valueAsNumber: true })}
            type="number"
            error={!!errors.locationId}
          />
        </div>
      </div>
      <FormActions
        isEdit={RTLSAsset?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
