import SubHeader from "@/components/SubHeader";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { RTLSAsset } from "@/lib/models";
import { RTLSAssetLabels } from "@/lib/models/form-constants/formLabels";
import {
  addRTLSAsset,
  addRTLSAssetsInBatch,
  deleteRTLSAsset,
  editRTLSAsset,
  fetchRTLSAssets
} from "@/lib/services/rtls-asset-service";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useRTLSAssetStore from "../store/RTLSAssetsStore";
import RTLSAssetsImport from "./rtls-assest-import";
import RTLSAssetForm from "./rtls-asset-form";

export default function RTLSAssetMaster() {
  const [RTLSAsset, setRTLSAsset] = useState<RTLSAsset[]>([]);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [RTLSAssetToEdit, setRTLSAssetToEdit] = useState<RTLSAsset | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [RTLSAssetToDelete, setRTLSAssetToDelete] = useState<RTLSAsset | undefined>(undefined);
  const RTLSAssetStore = useRTLSAssetStore();
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const columnsConfig = [
    { key: "antennaId", title: RTLSAssetLabels._Antenna_ID, hidden: false },
    { key: "itvId", title: RTLSAssetLabels._ITV_ID, hidden: false },
    { key: "latitude", title: RTLSAssetLabels._Latitude, hidden: false },
    { key: "longitude", title: RTLSAssetLabels._Longitude, hidden: false },
    // { key: "readPointName", title: RTLSAssetLabels._ReadPoint_ID, hidden: true },
    { key: "readPointName", title: RTLSAssetLabels._ReadPoint_Name, hidden: true },
    { key: "readerIp", title: RTLSAssetLabels._Reader_IP, hidden: true },
    { key: "readerModel", title: RTLSAssetLabels._Reader_Model, hidden: true },
    { key: "readerType", title: RTLSAssetLabels._Reader_Type, hidden: true },
    { key: "userId", title: RTLSAssetLabels._UserId, hidden: true },
    { key: "locationId", title: RTLSAssetLabels._location_ID, hidden: true },
  ];

  const columns: ColumnDef<RTLSAsset>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: false,
      // enableSorting: false,
      meta: { hidden }
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: RTLSAsset } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];
  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  };

  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchRTLSAssets(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setRTLSAsset(items as RTLSAsset[]);
      RTLSAssetStore.setRTLSAsset(items as RTLSAsset[]);
    }
    finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [paged]);

  const handleEdit = (RTLSAsset: RTLSAsset) => {
    setRTLSAssetToEdit(RTLSAsset);
    setOpen(true);
  };

  const handleDeleteClick = (RTLSAsset: RTLSAsset) => {
    setRTLSAssetToDelete(RTLSAsset);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (RTLSAssetToDelete?.id) {
        // setLoading(true);
        await deleteRTLSAsset(RTLSAssetToDelete.id.toString());
      }
      setLoading(false);
      await fetchData();
      SuccessToaster("", "RTLS Asset deleted successfully");
      mutate("RTLSAsset");
    }
    catch (error) {
      console.error(error);
      ErrorToaster("RTLS Asset Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally {
      setConfirmDeleteOpen(false);
    }

  };

  const handleSubmit = async (data: Omit<RTLSAsset, "id" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt">
  ) => {
    try {
      if (RTLSAssetToEdit?.id) {
        // SuccessToaster("", "RTLSAsset updated successfully");
      } else {
        // await (data);
        await addRTLSAssetsInBatch([data]);
        SuccessToaster("", "RTLS Asset created successfully");
      }
      setOpen(false);
      setRTLSAssetToEdit(undefined);
      await fetchData();
      mutate("RTLSAsset");
    } catch (error) {
      ErrorToaster(error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  }

  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?

        <div>
          <SubHeader
            placeholder="RTLS Asset Name..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            onAddClickOpen={setOpen}
            setComponentToEdit={setRTLSAssetToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={RTLSAsset || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={RTLSAssetToDelete?.readPointName || ""}
            />
          }
          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setRTLSAssetToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {RTLSAssetToEdit ? "Edit RTLS Asset" : "Add RTLS Asset"}
              </DialogTitle>
              <RTLSAssetForm
                RTLSAsset={RTLSAssetToEdit}
                onClose={() => {
                  setOpen(false);
                  setRTLSAssetToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog>
        </div>
        :
        <RTLSAssetsImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
