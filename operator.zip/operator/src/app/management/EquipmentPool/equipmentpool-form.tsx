import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { EquipmentPool } from "@/lib/models";
import { EquipmentPoolLabels } from "@/lib/models/form-constants/formLabels";
import { EquipmentPoolSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { EditIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";

interface EquipmentPoolFormProps {
  EquipmentPool?: EquipmentPool;
  onClose: () => void;
  onSubmit: (data: EquipmentPool) => void;
  openEditEquipPoolManage: () => void; //  func to trigger manage equip form
}

export default function EquipmentPoolForm({
  EquipmentPool,
  onClose,
  onSubmit,
  openEditEquipPoolManage
}: EquipmentPoolFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<z.infer<typeof EquipmentPoolSchema>>({
    resolver: zodResolver(EquipmentPoolSchema),
    defaultValues: EquipmentPool
      ? {
        ...EquipmentPool,
        id:
          typeof EquipmentPool.id === "string"
            ? parseInt(EquipmentPool.id)
            : EquipmentPool.id,
      }
      : {},
  });

  const EquipmentPoolMemo = useMemo(() => EquipmentPool, [EquipmentPool]);

  useEffect(() => {
    if (EquipmentPoolMemo) {
      reset({
        ...EquipmentPoolMemo,
        id:
          typeof EquipmentPoolMemo.id === "string"
            ? parseInt(EquipmentPoolMemo.id)
            : EquipmentPoolMemo.id,
      });
    }
  }, [EquipmentPoolMemo, reset]);

  const submitHandler = async (
    formData: z.infer<typeof EquipmentPoolSchema>
  ) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      await onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <div>
      {EquipmentPool && (
        <div className="flex justify-end">
          <Button
            className="bg-[#0d5ab4] h-[30px] flex items-center gap-2 text-white text-xs mb-3"
            onClick={openEditEquipPoolManage}
          >
            <EditIcon size={16} /> Manage Equipments
          </Button>
        </div>
      )}
      <form
        // onSubmit={handleSubmit(submitHandler)}
        onSubmit={handleSubmit(submitHandler, handleError)}
        className="space-y-4 pb-5">
        <div className="grid grid-cols-1 w-[70%] space-y-1">
          <div>
            <Label>{EquipmentPoolLabels._PoolName}</Label>
            {(!EquipmentPoolSchema.shape.poolName.isOptional()) && <MandatoryIcon />}
            <Input {...register("poolName")}
              disabled={EquipmentPool !== undefined}
              error={!!errors.poolName}
            />
          </div>
        </div>
        {
          !EquipmentPool &&
          <div className="pt-1">
            <FormActions
              isEdit={false}
              isLoading={isLoading}
              onClose={onClose}
            />
          </div>
        }
      </form>
    </div>
  );
}
