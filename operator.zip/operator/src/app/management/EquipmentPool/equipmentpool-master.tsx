import SubHeader from "@/components/SubHeader";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { Equipment, EquipmentPool } from "@/lib/models";
import { EquipmentPoolLabels } from "@/lib/models/form-constants/formLabels";
import { fetchEquipments } from "@/lib/services/equipment-services";
import {
  addEquipmentPool,
  deleteEquipmentPool,
  editEquipmentPool,
  fetchAssignedData,
  fetchEquipmentPools,
} from "@/lib/services/equipmentpool-services";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { Wrench } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useEquipmentPoolStore from "../store/EquipmentPoolStore";
import useEquipmentStore from "../store/EquipmentStore";
import EquipmentPoolForm from "./equipmentpool-form";
import EquipmentPoolManagement from "./equipmentpool-management";
import EquipmentPoolImport from "./equipmentpool-import";



export default function EquipmentPoolMaster() {
  const [EquipmentPools, setEquipmentPools] = useState<EquipmentPool[]>([]);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  // const [filteredEquipmentPools, setFilteredEquipmentPools] = useState<EquipmentPool[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [EquipmentPoolToEdit, setEquipmentPoolToEdit] = useState<
    EquipmentPool | undefined
  >(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [EquipmentPoolToDelete, setEquipmentPoolToDelete] = useState<
    EquipmentPool | undefined
  >(undefined);
  const [isEquipPoolManageOpen, setIsEquipPoolManageOpen] = useState(false);
  const [assignedEquipments, setAssignedEquipments] = useState<Equipment[]>([]);

  const [unAssignedEquipments, setUnAssignedEquipments] = useState<Equipment[]>([]);
  const EquipmentPoolStore = useEquipmentPoolStore();
  const EquipmentStore = useEquipmentStore();
  // const [selectedPool, setSelectedPool] = useState<EquipmentPool | null>(null);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [EquipmentData, setEquipmentData] = useState([])
  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const handleViewClick = async (pool: EquipmentPool) => {
    console.log(pool)
    try {
      const poolId = pool?.id;
      if (!poolId) return;
      const responseData = await fetchAssignedData(String(poolId));
      if (!responseData) return;
      const equipmentData = responseData.assignedPools.map(item => ({
        equipmentName: item?.equipment?.equipmentName,
      }));
      setEquipmentData(equipmentData);
      setViewModalOpen(true);
    } catch (error) {
      console.error(error);      
      ErrorToaster('', "Failed to load Equipment Data")
      return
    }
  };


  const columnsConfig = [
    { key: "poolName", title: EquipmentPoolLabels._PoolName, hidden: false },
    // { key: "dispatchState", title: "Dispatch State Type", hidden: true },
    // { key: "operatingMode", title: "Operating Mode", hidden: false },
    // { key: "jobStartPosition", title: "Job Start Position", hidden: false },
  ];

  const columns: ColumnDef<EquipmentPool>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: true,
      enableSorting: false,
      meta: { hidden },
      // cell: ({ row }: { row: { original: EquipmentPool } }) => (
      //   <div className="flex items-center gap-2">
      //     <span>{row.original.poolName}</span>
      //     <button
      //       onClick={() => handleViewClick(row.original)}
      //       className="inline-flex items-center justify-center rounded-md p-1.5 text-muted-foreground hover:text-primary hover:bg-muted"
      //       title="View Equipments"
      //     >
      //       <Wrench size={16} color="grey" />
      //     </button>
      //   </div>
      // )
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: EquipmentPool } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
          isEquipment={true}
          handleViewClick={handleViewClick}
        />
      ),
    },
  ];

  const handlePaginationChange = (newPagination: PaginationState) => {
    // console.log("newPagination", newPagination);
    setPaged(newPagination);
  }
  const fetchEquipmentsData = async () => {
    try {
      const data = await fetchEquipments();
      EquipmentStore.setEquipments(data["items"] as Equipment[]);
    } finally {
      setLoading(false);
    }
  };

  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchEquipmentPools(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setEquipmentPools(items as EquipmentPool[]);
      EquipmentPoolStore.setEquipmentPools(items as EquipmentPool[])
    } finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  useEffect(() => {
    fetchData();
    fetchEquipmentsData();
  }, [paged]);

  const handleEdit = (EquipmentPool: EquipmentPool) => {
    setEquipmentPoolToEdit(EquipmentPool);
    setOpen(true);
  };

  const handleDeleteClick = (EquipmentPool: EquipmentPool) => {
    setEquipmentPoolToDelete(EquipmentPool);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (EquipmentPoolToDelete?.id) {
        setLoading(true);
        await deleteEquipmentPool(EquipmentPoolToDelete.id.toString());
        mutate("equipmentPools");
        setLoading(false);
        await fetchData();
        SuccessToaster("", "Equipment Pool deleted successfully");
      }
      setConfirmDeleteOpen(false);
    } catch (error) {
      console.error(error);
      setLoading(false)
    }
  };

  const handleSubmit = async (
    data: Omit<EquipmentPool, "id" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt">
  ) => {
    setLoading(true); 
    // const isPoolNameExists = EquipmentPools?.some(
    //   item => (item.poolName === data.poolName)
    // );
    // if (isPoolNameExists) {
    //   ErrorToaster('', '"Pool Name already exists"')
    //   setLoading(false);
    //   return;
    // }

    try {
      if (EquipmentPoolToEdit?.id) {
        await editEquipmentPool(EquipmentPoolToEdit.id.toString(), data);
      } else {
        await addEquipmentPool(data);
      }
      await fetchData();
      SuccessToaster("", "Equipment Pool created successfully");
      mutate("equipmentPools");
      // setOpen(false);
    } catch (error) {
      ErrorToaster("Equipment Pool creation failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }  finally {
      setLoading(false);
    }
  };

  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredEquipmentPools(EquipmentPools);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = EquipmentPools.filter(
  //       (EquipmentPool) =>
  //         EquipmentPool.poolName.toLowerCase().includes(lowerCasedQuery)
  //     );
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     setFilteredEquipmentPools(filtered.slice(start, end));

  //   }
  // }, [searchQuery, EquipmentPools, paged]);


  //func to open/close and fetching assigned and unassigned equipments to pool
  const openEditEquipPoolManage = async () => {
    try {
      setOpen(true);
      if (isEquipPoolManageOpen) {
        setIsEquipPoolManageOpen(prev => !prev)
        return;
      }
      const responseData = await fetchAssignedData(EquipmentPoolToEdit?.id + "");
      console.log(responseData);
      const equipmentData = responseData.unAssignedPools;

      const filteredUnAssingedData = equipmentData?.filter(el => el.assignedPool !== EquipmentPoolToEdit?.poolName && el.equipmentType === "Terminal Truck")

      console.log("responseData?.assignedPools ", responseData?.assignedPools);

      const assignedData = responseData?.assignedPools.map(item => {
        return (
          {
            ...item,
            equipmentName: item.equipment.equipmentName
          }
        )
      })
      console.log("assignedData", assignedData)
      setAssignedEquipments(assignedData ?? [])
      setUnAssignedEquipments(filteredUnAssingedData ?? [])
      setIsEquipPoolManageOpen(prev => !prev)
      console.log("filteredUnAssingedData", filteredUnAssingedData, "assignedData", responseData?.assignedPools);

    } catch (error) {
      console.error(error);

    }
    // setEquipmentPools(data.records);
  };

  // Import rework
  const openCloseImport = (type: string) => {
    console.log("triggered");

    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false);
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?
        <div>
          <SubHeader
            placeholder="Pool Name..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Operation + privateRoute._Equipmentpool_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setEquipmentPoolToEdit}
            errorList={errorList}
            isImportError={isImportError}
            openCloseImport={openCloseImport}
          />
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={EquipmentPools}
              pagination={paged}
              totalRecords={totalRecord}
              onPaginationChange={handlePaginationChange}
            />
          )}
          {viewModalOpen && (
            <PoolViewModal
              open={viewModalOpen}
              onClose={() => setViewModalOpen(false)}
              pool={EquipmentData}
            />
          )}
          {/* component for manage equipments to pool*/}
          {isEquipPoolManageOpen &&
            <EquipmentPoolManagement
              isEquipPoolManageOpen={isEquipPoolManageOpen}
              EquipmentPoolToEdit={EquipmentPoolToEdit }
              openEditEquipPoolManage={openEditEquipPoolManage}
              assignedEquipments={assignedEquipments}
              unAssignedEquipments={unAssignedEquipments}
              setUnAssignedEquipments={setUnAssignedEquipments}
              setAssignedEquipments={setAssignedEquipments}
              setFormOpen={setOpen}
              setIsEquipPoolManageOpen={setIsEquipPoolManageOpen}
            />
          }
          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={EquipmentPoolToDelete?.poolName || ""}
            />
          }
          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              // if (!isOpen) setEquipmentPoolToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {EquipmentPoolToEdit ? "Edit EquipmentPool" : "Add EquipmentPool"}
              </DialogTitle>
              <EquipmentPoolForm
                EquipmentPool={EquipmentPoolToEdit}
                onClose={() => {
                  setOpen(false);
                  // setEquipmentPoolToEdit(undefined);
                }}
                onSubmit={handleSubmit}
                openEditEquipPoolManage={openEditEquipPoolManage}
              />
            </DialogContent>
          </Dialog>
        </div>
        :
        <EquipmentPoolImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }

    </div>
  );
}

interface PoolViewModalProps {
  open: boolean;
  onClose: () => void;
  pool: string[];
}

export function PoolViewModal({ open, onClose, pool }: PoolViewModalProps) {
  const showScroll = pool?.length > 5;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Equipment Pool</DialogTitle>
          <DialogDescription>
            List of Assigned ITVs
          </DialogDescription>
        </DialogHeader>

        <div
          className={`mt-4 ${showScroll ? "max-h-48 overflow-y-auto" : "max-h-fit"
            }`}
        >
          <ul className="list-disc pl-5 space-y-1">
            {pool?.length > 0 ? (
              pool.map((item, index) => (
                <li key={index} className="text-sm">
                  {item.equipmentName}
                </li>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No equipment assigned.</p>
            )}
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
}

