/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Input, SearchInput } from "@/components/ui/input";
import { ErrorToaster } from "@/components/UtilComp";
import { WorkAssignment, WorkAssignmentPOW, WorkInstruction, workQueueResponse } from "@/lib/models";
import { fetchPointofWorks } from "@/lib/services/pointofwork-services";
import { fetchWorkAssignmentWithPowAPICALL, fetchWorkInstructionsByWQAPICALL, fetchWorkQueuesByPowAPICALL, triggerWQJobOperationAPICALL } from "@/lib/services/workassignment-services";
import { PaginationState, Row } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import usePointofWorkStore from "../store/PointofWorkStore";
import { WorkAssignmentsTableUI, WorkInstructionListUI, WorkQueueListUI } from "./workassignment-components";
import { IoMdRefresh } from "react-icons/io";

// interface paginationData {
//   rowStart: number;
//   rowEnd: number;
//   searchValue: string;
//   pageIndex: number;
//   rowCountPerPage: number;
//   totalRows: number;
// }
export default function WorkAssignmentMaster() {
  const [search, setSearch] = useState("");
  const [expandedRows, setExpandedRows] = useState<string[]>([]);
  const [workAssignmentsList, setworkAssignmentsList] = useState<WorkAssignment[]>([]);
  const [workQueueList, setWorkQueueList] = useState<workQueueResponse[]>([]);
  const [workQueuePOWList, setworkQueuePOWList] = useState<WorkAssignmentPOW[]>([]);
  const [filterWorkQueueList, setFilterWorkQueueList] = useState<workQueueResponse[]>([]);
  const [workInstructionList, setWorkInstructionList] = useState<WorkInstruction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  // const [isWorkAssHistory, setIsWorkAssHistory] = useState(false);
  const [totalRecordWorkAssignData, setTotalRecordWorkAssignData] = useState(0);
  const [selectedVessVisit, setSelectedVessVisit] = useState<WorkAssignment>({} as WorkAssignment);
  const [selectedPow, setSelectedPow] = useState<WorkAssignmentPOW>({} as WorkAssignmentPOW);
  const [selectedWorkQueue, setSelectedWorkQueue] = useState<workQueueResponse>({} as workQueueResponse);
  const [targetPageName, setTargetPageName] = useState("workAssignment");
  // const [paginationMetaData, setPaginationMetaData] = useState<paginationData>({ rowStart: 0, rowEnd: 9, searchValue: "", pageIndex: 0, rowCountPerPage: 10, totalRows: 0 })
  const [breadcrumbData, setBreadcrumbData] = useState<string[]>([]);
  const PointofWorkStore = usePointofWorkStore();
  const [previousRows, setPreviousRows] = useState<Row<WorkAssignment>>()
  const [workAssignPaged, setWorkAssignPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [workInstPaged, setWorkInstPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const toggleRow = async (visitRef: string, vesselVisit: WorkAssignment, row: Row<WorkAssignment>) => {
    console.log("item ", vesselVisit, vesselVisit.pointOfWork);
    console.log(visitRef);
    previousRows?.toggleExpanded(false);
    if (expandedRows.includes(visitRef)) {
      row.toggleExpanded(false)
      setSelectedVessVisit(vesselVisit);
      handleUpdateBreadcrumbData(vesselVisit.vesselRef, -1)
      setExpandedRows([])
    }
    else {
      setExpandedRows([visitRef])
      row.toggleExpanded(true);
      setSelectedVessVisit(vesselVisit);
      handleUpdateBreadcrumbData(vesselVisit.vesselRef, 0)
    }
    setPreviousRows(row)
  };
  const fetchPointofWorksData = async () => {
    try {
      const data = await fetchPointofWorks();
      PointofWorkStore.setPointofWorks(data["items"]);
    } finally {
      //
    }
  };
  const fetchWorkAssignmentsData = async () => {
    setIsLoading(true);
    try {
      // const { rowStart, rowEnd, searchValue } = paginationMetaData;
      // console.log(paginationMetaData);
      const skip = workAssignPaged.pageIndex * workAssignPaged.pageSize;
      const take = workAssignPaged.pageSize;
      const search = workAssignPaged.search;
      const data = await fetchWorkAssignmentWithPowAPICALL(skip, take, search);
      setTotalRecordWorkAssignData(data["totalCount"] as number);
      setworkAssignmentsList(data["items"] as WorkAssignment[]);
      setIsLoading(false);
    } catch (error) {
      console.error(error)
      setIsLoading(false);
    }
    finally {
      setIsLoading(false);
    }
  };

  const onPOWItemOnClick = async (powItem: WorkAssignmentPOW, callBy: string, powList: WorkAssignmentPOW[]) => {
    console.log(powItem, powList);
    // setIsLoading(true)
    // const filteredPowList=powList.filter(el=>el.id!==powItem.id)
    // console.log(filteredPowList)
    try {
      setSelectedPow(powItem);
      handleUpdateBreadcrumbData(powItem.name, 1)
      const data = await fetchWorkQueuesByPowAPICALL(selectedVessVisit?.vesselVisitId, powItem.id);
      const sortedWQData = data.sort((a, b) => {
        const workQueueA = parseInt(a.name);
        const workQueueB = parseInt(b.name);
        if (workQueueA !== workQueueB) {
          return workQueueA - workQueueB;
        }
        if (a.type === b.type) return 0;
        if (a.type === 'Load') return -1;
        if (b.type === 'Load') return 1;
        return 0;
      });

      console.log(data, sortedWQData);
      setWorkQueueList(sortedWQData);
      setworkQueuePOWList(powList)
      setFilterWorkQueueList(sortedWQData);
      setIsLoading(false);
      if (callBy !== "JOB_OPERATION") {
        setTargetPageName("workQueue")
      }
    } catch (error) {
      console.error(error);
      setIsLoading(false);
    }
  }

  const onJobOperationClick = async (selWorkQueue: workQueueResponse, action: string) => {
    console.log(action, selWorkQueue, selectedVessVisit);
    if (action === "Inprogress" && selectedVessVisit.vesselVisitPhase !== "Working") {
      ErrorToaster("Visit Phase should be in Working!");
      return;
    }
    try {
      const response = await triggerWQJobOperationAPICALL(action, selWorkQueue.id);
      console.log("response ", response);
      await onPOWItemOnClick(selectedPow, "JOB_OPERATION");
    } catch (error) {
      console.error(error);
      ErrorToaster(error?.data ? error?.data : "Unknown error occurred")
    }
  }
  const onViewWorkInstructionClick = async (selWorkQueue: workQueueResponse = selectedWorkQueue) => {
    console.log(selWorkQueue, workQueuePOWList);
    if (!(selWorkQueue?.type)) {
      console.log("undefined call");
      return
    }
    setworkQueuePOWList(workQueuePOWList)
    setIsLoading(true)
    try {
      setTargetPageName("workInstruction");
      setSelectedWorkQueue(selWorkQueue);
      handleUpdateBreadcrumbData(selWorkQueue.name + selWorkQueue.deck + '/' + selWorkQueue.type[0], 2)
      // const rowStart = reqPagMetaData ? reqPagMetaData.rowStart : 0,
      // rowEnd = reqPagMetaData ? reqPagMetaData.rowEnd : 9,
      // searchValue = reqPagMetaData ? reqPagMetaData.searchValue : "";
      const skip = workInstPaged.pageIndex * workInstPaged.pageSize;
      const take = workInstPaged.pageSize;
      const search = workInstPaged.search;
      const responseData = await fetchWorkInstructionsByWQAPICALL(skip, take, search, selWorkQueue.id)
      console.log(responseData)
      const items = responseData?.items ?? [];
      setWorkInstructionList(items as WorkInstruction[]);
      setTimeout(() => {
        setIsLoading(false);
      }, 500);
    } catch (error) {
      console.error(error);
      setIsLoading(false);
    }
  }

  function handleUpdateBreadcrumbData(item: string, index: number) {
    console.log(item, index);
    if (index === -1) {
      setBreadcrumbData([])
      return
    }
    setBreadcrumbData((prev: string[]) => {
      if (index < prev.length) {
        return prev.map((el: string, idx: number) => (idx === index ? item : el));
      } else {
        return [...prev, item];
      }
    });
  }
  const handleBreadcrumbDataHref = (index: number) => {
    const pageMap = ["workAssignment", "workQueue", "workInstruction"];
    const targetPage = pageMap[index] || "workAssignment";
    setTargetPageName(targetPage);
    if (index === 0) {
      setBreadcrumbData([]);
      setExpandedRows([])
      return;
    }
    const constructBreadCrumbData = breadcrumbData.slice(0, index === 0 ? 1 : index + 1)
    setBreadcrumbData(constructBreadCrumbData)
  };
  const handleSearch = async (searchText: string,) => {
    console.log(searchText, targetPageName);
    if (targetPageName === "workAssignment") {
      setWorkAssignPaged((prev => ({
        ...prev,
        search: searchText
      })))
    } else if (targetPageName === "workInstruction") {
      setWorkInstPaged((prev => ({
        ...prev,
        search: searchText
      })))
    }
    else {
      setSearch(searchText);
      const filteredWQ = workQueueList.filter((workQueue) =>
        (`${selectedVessVisit.vesselRef}-${workQueue.name}${workQueue.deck}/${workQueue.type === "Load" ? "L" : "D"}`).toLowerCase()
          .includes(searchText.toLowerCase())
        ||
        (`${workQueue.name}${workQueue.deck}/${workQueue.type === "Load" ? "L" : "D"}`)
          .includes(searchText.toLowerCase())
      );
      setFilterWorkQueueList(filteredWQ);
    }
  }
  useEffect(() => {
    fetchPointofWorksData();
    fetchWorkAssignmentsData();
  }, []);

  useEffect(() => {
    if (workAssignPaged.search.length === 0 || workAssignPaged.search.length > 2)
      fetchWorkAssignmentsData();
  }, [workAssignPaged.search, workInstPaged.pageIndex, workAssignPaged.pageSize]);

  useEffect(() => {
    if (workInstPaged.search.length === 0 || workInstPaged.search.length > 2)
      onViewWorkInstructionClick();
  }, [workInstPaged.search, workInstPaged.pageIndex, workInstPaged.pageSize]);


  const handlePaginationChange = (newPagination: PaginationState) => {
    if (targetPageName === "workAssignment") {
      setWorkAssignPaged(newPagination);
    }
    else if (targetPageName === "workInstruction") {
      setWorkInstPaged(newPagination);
    }
  }
  const handleRefreshData = () => {
    if (targetPageName === "workAssignment") {
      fetchWorkAssignmentsData();
    } else if (targetPageName === "workInstruction") {
      onViewWorkInstructionClick();
    }
    else {
      onPOWItemOnClick(selectedPow, "", workQueuePOWList)
    }
  }
  // const workAssignHistoryOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  //   const isChecked = e.target.checked;
  //   console.log(" isChecked ", isChecked);
  //   if (isChecked) {

  //   }
  //   setIsWorkAssHistory(isChecked)

  // }
  return (
    <div className="">
      <div className="mb-5 mt-1 pl-4 flex justify-between">
        <SearchInput
          type="search"
          placeholder={targetPageName === "workAssignment" ? "Visit Ref/Visit Phase..." : (targetPageName === "workQueue" ? "Work Queue" : "Container ID/Visit Ref/Status...")}
          value={targetPageName === "workAssignment" ? workAssignPaged.search : (targetPageName === "workQueue" ? search : workInstPaged.search)}
          onChange={(e) => handleSearch(e.target.value)}
          className="w-1/3 placeholder:text-gray-400"
        />
        <span className="pr-5  flex justify-center space-x-2 items-center">
          {/* {targetPageName === "workInstruction" && <span>
            <input
              type="checkbox"
              className="w-4 h-4 pr-2 cursor-pointer items-center"
              checked={isWorkAssHistory}
              onChange={workAssignHistoryOnChange}
            />
            <label className="pl-2 cursor-pointer">Show History</label>
          </span>} */}
          <IoMdRefresh size={20} onClick={handleRefreshData} title="refresh" className="cursor-pointer" color="blue" />
        </span>
      </div>
      <div className="mb-2  pl-4">
        <Breadcrumb>
          <BreadcrumbList className="flex items-center text-sm text-gray-700 ">
            {breadcrumbData.map((item, index) => {
              const isLast = index === breadcrumbData.length - 1;
              return (
                <BreadcrumbItem key={index} className="flex items-center">
                  <BreadcrumbLink
                    onClick={() => !isLast && handleBreadcrumbDataHref(index)}
                    className={`cursor-pointer transition-colors duration-300 
                ${isLast ? 'text-blue-600 font-semibold pointer-events-none' : 'hover:text-blue-600 hover:underline'}`}
                  >
                    {item}
                  </BreadcrumbLink>
                  {!isLast && (
                    <BreadcrumbSeparator className="text-gray-400 mx-2">/</BreadcrumbSeparator>
                  )}
                </BreadcrumbItem>
              );
            })}
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      {targetPageName === "workAssignment" &&
        <WorkAssignmentsTableUI
          isLoading={isLoading}
          // expandedRows={expandedRows}
          onPOWItemOnClick={onPOWItemOnClick}
          toggleRow={toggleRow}
          workAssignmentsList={workAssignmentsList}
          onPaginationChange={handlePaginationChange}
          paged={workAssignPaged}
          totalRecordWorkAssignData={totalRecordWorkAssignData}
        />
      }
      {targetPageName === "workQueue" &&
        <WorkQueueListUI
          selectedVessVisit={selectedVessVisit}
          workQueueList={filterWorkQueueList}
          onJobOperationClick={onJobOperationClick}
          onViewWorkInstructionClick={onViewWorkInstructionClick}
          isLoading={isLoading}
          workQueuePOWList={workQueuePOWList}
        />}
      {
        targetPageName === "workInstruction" &&
        <WorkInstructionListUI
          selectedVessVisit={selectedVessVisit}
          workInstructionList={workInstructionList}
          isLoading={isLoading}
          onPaginationChange={handlePaginationChange}
          paged={workInstPaged}
          totalRecords={selectedWorkQueue.totalPlannedMoves}
          workQueuePOWList={workQueuePOWList}
          selectedWorkQueue={selectedWorkQueue}
          onViewWorkInstructionClick={onViewWorkInstructionClick}
        />
      }

    </div>
  );
}