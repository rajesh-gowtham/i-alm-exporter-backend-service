import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Link as LinkIcon } from "lucide-react";

const mockVisits = [
  { sequence: 1, vesselName: "Ocean Star", berth: "B1", visitPhase: "Loading", pairContainer: "group1" },
  { sequence: 2, vesselName: "Ocean Star", berth: "B3", visitPhase: "Unloading", pairContainer: "group1" },
  { sequence: 3, vesselName: "Blue Tide", berth: "B2", visitPhase: "Docking", pairContainer: "" },
  { sequence: 4, vesselName: "Red Dolphin", berth: "C1", visitPhase: "Departing", pairContainer: "" },
  { sequence: 5, vesselName: "Red Dolphin", berth: "C2", visitPhase: "Unmooring", pairContainer: "" },
];

export default function Sample() {
  const [search, setSearch] = useState("");

  const filtered = mockVisits.filter((v) =>
    v.vesselName.toLowerCase().includes(search.toLowerCase())
  );

  // Group rows by pairContainer when it's not null
  const groups: Record<string, number[]> = {};
  filtered.forEach((v, idx) => {
    if (v.pairContainer) {
      if (!groups[v.pairContainer]) groups[v.pairContainer] = [];
      groups[v.pairContainer].push(idx);
    }
  });

  return (
    <div className="p-4">
      <Input
        type="text"
        placeholder="Search Vessel"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-4 w-full max-w-sm"
      />

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader className="">
              <TableRow>
                <TableHead className="w-20">Sequence</TableHead>
                <TableHead>Vessel Name</TableHead>
                <TableHead>Berth</TableHead>
                <TableHead>Visit Phase</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {filtered.map((visit, idx) => {
                const group = visit.pairContainer ? groups[visit.pairContainer] : null;
                const isGrouped = group && group.length > 1;
                const isFirstInGroup = isGrouped && group[0] === idx;

                if (isGrouped && !isFirstInGroup) return null;

                if (isFirstInGroup) {
                  const rows = group.map((groupIdx) => filtered[groupIdx]);

                  return rows.map((row, rowIdx) => (
                    <TableRow
                      key={row.sequence}
                      className={` ${
                        rowIdx > 0 ? "border-t border-green-200" : ""
                      } transition-colors`}
                    >
                      {rowIdx === 0 && (
                        <TableCell
                          rowSpan={rows.length}
                          className="relative py-1 px-3 font-mono text-sm border-b border-gray-300 align-middle"
                          style={{
                            minWidth: 80,
                            verticalAlign: "middle",
                            textAlign: "center",
                          }}
                        >
                          <div className="flex flex-col items-center justify-center h-full relative z-10">
                            {rows.map((r, i) => (
                              <React.Fragment key={r.sequence}>
                                <div className="bg-white px-1 z-10">{r.sequence}</div>

                                {i < rows.length - 1 && (
                                  <div className="flex flex-col items-center relative z-10">
                                    {/* Short vertical line above and below icon */}
                                    <div className="w-px h-2 bg-green-500" />
                                    {/* <LinkIcon
                                      size={18}
                                      className="text-emerald-600 bg-white z-10"
                                      style={{ transform: "rotate(90deg)" }}
                                    /> */}
                                    <div className="w-px h-2 bg-green-500" />
                                  </div>
                                )}
                              </React.Fragment>
                            ))}
                          </div>
                        </TableCell>
                      )}
                      <TableCell className="py-1 px-3 border-b border-gray-300">
                        {row.vesselName}
                      </TableCell>
                      <TableCell className="py-1 px-3 border-b border-gray-300">
                        {row.berth}
                      </TableCell>
                      <TableCell className="py-1 px-3 border-b border-gray-300">
                        {row.visitPhase}
                      </TableCell>
                    </TableRow>
                  ));
                }

                return (
                  <TableRow key={visit.sequence} className="hover:bg-gray-50 transition-colors even:bg-gray-50">
                    <TableCell
                      className="relative py-1 px-3 font-mono text-sm border-b border-gray-300 align-middle text-center"
                      style={{ minWidth: 80 }}
                    >
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        <span className="bg-white px-1">{visit.sequence}</span>
                      </div>
                    </TableCell>
                    <TableCell className="py-1 px-3 border-b border-gray-300">
                      {visit.vesselName}
                    </TableCell>
                    <TableCell className="py-1 px-3 border-b border-gray-300">
                      {visit.berth}
                    </TableCell>
                    <TableCell className="py-1 px-3 border-b border-gray-300">
                      {visit.visitPhase}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
