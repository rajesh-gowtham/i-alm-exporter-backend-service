import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ErrorToaster, SuccessToaster } from "@/components/UtilComp";
import { workQueueStatus } from "@/lib/constants";
import { VesselVisit, WorkAssignment, WorkAssignmentPOW, WorkAssWorkInstruction, WorkInstruction, workQueueResponse } from "@/lib/models";
import { WorkInstructionLabels } from "@/lib/models/form-constants/formLabels";
import { AppendQueue, fetchWorkQueuesByPowAPICALL } from "@/lib/services/workassignment-services";
import { cn, convertTime } from "@/lib/utils";
import { ColumnDef, PaginationState, Row } from "@tanstack/react-table";
import { ChevronDown, ChevronUp, Ellipsis, Eye } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { CiPause1 } from "react-icons/ci";
import { FaChevronDown } from "react-icons/fa";
import { IoTriangle } from "react-icons/io5";
import { MdOutlineStopCircle } from "react-icons/md";
import { RxResume } from "react-icons/rx";
import { VscDebugStart } from "react-icons/vsc";
import { DataTable } from "../data-table";
import usePointofWorkStore from "../store/PointofWorkStore";



interface WorkQueueListUIProps {
    workQueueList: workQueueResponse[];
    onJobOperationClick: (data: workQueueResponse, action: string) => void;
    onViewWorkInstructionClick: (data: workQueueResponse) => void;
    isLoading: boolean;
    selectedVessVisit: WorkAssignment;
    workQueuePOWList: WorkAssignmentPOW;
}
export function WorkQueueListUI({ workQueueList, isLoading, onJobOperationClick, onViewWorkInstructionClick, selectedVessVisit, workQueuePOWList }: WorkQueueListUIProps) {
    console.log(workQueuePOWList);

    const getShoeIconsListByStatus = (status: string) => {
        console.log(status)
        const startIcon = {
            icon: <VscDebugStart title="Start" color="green" />,
            actionName: workQueueStatus._INPROGRESS
        };
        const pauseIcon = {
            icon: <CiPause1 title="Pause" color="blue" />,
            actionName: workQueueStatus._SUSPENDED
        };
        const resumeIcon = {
            icon: < RxResume title="Resume" color="blue" />,
            actionName: workQueueStatus._INPROGRESS
        };
        const endIcon = {
            icon: < MdOutlineStopCircle title="Stop" color="red" />,
            actionName: workQueueStatus._PLANNED
        };
        const resultIconList = [];
        switch (status) {
            case workQueueStatus._PLANNED:
                resultIconList.push(startIcon);
                break;
            case workQueueStatus._INPROGRESS:
                resultIconList.push(pauseIcon);
                resultIconList.push(endIcon);
                break;
            case workQueueStatus._SUSPENDED:
                resultIconList.push(resumeIcon);
                resultIconList.push(endIcon);
                break;
            default:
                console.log("default case ", status);
                // resultIconList.push(startIcon)
                break;
        }
        return resultIconList;
    }
    console.log(" selectedVessVisit ", selectedVessVisit);
    const statusColor = (status: string) => {
        switch (status) {
            case workQueueStatus._INPROGRESS:
                return {
                    bgColor: "bg-yellow-200",
                    textColor: "text-yellow-400",
                }
            case workQueueStatus._PLANNED:
                return {
                    bgColor: "bg-green-100",
                    textColor: "text-green-600",
                };
            case workQueueStatus._SUSPENDED:
                return {
                    bgColor: "bg-orange-100",
                    textColor: "text-orange-500",
                }
            case workQueueStatus._COMPLETED:
                return {
                    bgColor: "bg-green-100",
                    textColor: "text-green-800",
                }

            default:
                break;
        }
    }

    const columns: ColumnDef<workQueueResponse>[] = [
        {
            accessorKey: "wqOrder",
            header: "WQ Order",
            cell: ({ row }) => row.index + 1,
        },
        {
            accessorKey: "queue",
            header: "Queue",
            cell: ({ row }) => {
                const item = row.original;
                console.log(item)
                return (
                    <div
                        onClick={() => onViewWorkInstructionClick(item)}
                        className="group inline-flex items-center space-x-1 cursor-pointer"
                    >
                        <span className="text-blue-600 hover:font-medium hover:underline">
                            {`${selectedVessVisit.vesselRef}-${row.original.name}${row.original.deck}/${row.original.type === "Load" ? "L" : "D"}`}
                        </span>
                        {/* <span className="flex items-center">
                            <ExternalLink
                                className="text-blue-600 relative bottom-[1px]"
                                size={16}
                            />
                        </span> */}
                    </div>
                );
            },
        },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const item = row.original;
                return (
                    <span className={`${statusColor(item.status)?.textColor}   px-1 rounded`}>
                        <span title={item.status} className="flex items-center space-x-3">
                            <span>{item.status}</span>
                        </span>
                    </span>
                );
            },
        },
        {
            accessorKey: "pendingMoves",
            header: "Moves to do",
            cell: ({ row }) => {
                const item = row.original;
                return (
                    <div className="flex items-center justify-center h-full">
                        <div className="flex flex-col items-center justify-center  pl-3">
                            <span className={`${statusColor(item.status)?.textColor}`}>
                                {item.moveType === "Load" ? (
                                    <IoTriangle className="rotate-180" size={12} />
                                ) : (
                                    <IoTriangle size={12} />
                                )}
                            </span>
                            <span className="text-sm pl-0.1">{item.pendingMoves}</span>
                        </div>
                    </div>
                );
            }

        },
        {
            accessorKey: "totalPlannedMoves",
            header: "Total",
            cell: ({ row }) => <span className="pl-2">{row.original.totalPlannedMoves}</span>,
        },
        {
            accessorKey: "action",
            header: "Action",
            cell: ({ row }) => {
                const item = row.original;
                return (
                    <div className="flex justify-center items-center space-x-1.5">
                        {getShoeIconsListByStatus(item.status).map((data, idx) => (
                            <span
                                key={idx}
                                onClick={() => onJobOperationClick(item, data.actionName)}
                                className="p-1.5 cursor-pointer shadow-md hover:scale-110 delay-75 bg-black/5 ease-in-out rounded"
                            >
                                {data.icon}
                            </span>
                        ))}
                    </div>
                );
            },
        },
    ];

    const [totalRecord, setTotalRecord] = useState(workQueueList ? workQueueList.length : 0);
    const [paged, setPaged] = useState({
        pageIndex: 0,
        pageSize: 20,
    });
    const handlePaginationChange = (newPagination: PaginationState) => {
        setPaged(newPagination);
    }
    return (
        <div>
            {
                isLoading ?
                    <div className="space-y-2">
                        {[...Array(5)].map((_, i) => (
                            <Skeleton key={i} className="w-full h-8" />
                        ))}
                    </div>
                    :
                    <DataTable
                        columns={columns}
                        data={workQueueList}
                        totalRecords={totalRecord}
                        pagination={paged}
                        onPaginationChange={handlePaginationChange}
                    />

            }
        </div>
    );
}
interface workInstructionListProps {
    workInstructionList: WorkInstruction[];
    isLoading: boolean;
    onPaginationChange: (pagination: PaginationState) => void;
    paged: PaginationState;
    totalRecords: number;
    workQueuePOWList: WorkAssignmentPOW[];
    selectedVessVisit: WorkAssignment;
    selectedWorkQueue: workQueueResponse;
    onViewWorkInstructionClick: () => void;
}

export function WorkInstructionListUI({ workInstructionList, isLoading, onPaginationChange, paged, totalRecords, workQueuePOWList, selectedVessVisit, selectedWorkQueue, onViewWorkInstructionClick }: workInstructionListProps) {
    const PointofWorkStore = usePointofWorkStore();
    // const [paged, setPaged] = useState({
    //     pageIndex: 0,
    //     pageSize: 10,
    // });
    const [isAppendModalOpen, setIsAppendModalOpen] = useState(false);
    const [selectedWI, setSelectedWI] = useState<WorkAssWorkInstruction>({} as WorkAssWorkInstruction);
    const options = ['Append']
    console.log(workQueuePOWList)
    const columnsConfig = [
        { key: "sequence", title: WorkInstructionLabels._Sequence, hidden: false },
        { key: "containerId", title: WorkInstructionLabels._ContainerID, hidden: false },
        { key: "isoCode", title: WorkInstructionLabels._ISO, hidden: false },
        { key: "moveType", title: WorkInstructionLabels._MoveType, hidden: true },
        { key: "mode", title: WorkInstructionLabels._Mode, hidden: false },
        { key: "inboundLocationType", title: WorkInstructionLabels._InboundLocationType, hidden: true },
        { key: "vesselVisitId", title: WorkInstructionLabels._VisitRef, hidden: false },
        { key: "outboundLocationType", title: WorkInstructionLabels._OutboundLocationType, hidden: true },
        { key: "outboundCarrier", title: WorkInstructionLabels._OutboundCarrier, hidden: true },
        { key: "deck", title: WorkInstructionLabels._Deck, hidden: true },
        { key: "fromLocation", title: WorkInstructionLabels._From, hidden: false },
        { key: "targetLocation", title: WorkInstructionLabels._To, hidden: false },
        { key: "pointOfWorkId", title: WorkInstructionLabels._POW, hidden: false },
        { key: "assignedChe", title: WorkInstructionLabels._CHEPut, hidden: true },
        { key: "cheCarry", title: WorkInstructionLabels._CHECarry, hidden: false },
        { key: "assignedLane", title: WorkInstructionLabels._AssignedLane, hidden: true },
        { key: "positionOnCarriage", title: WorkInstructionLabels._PosOnChassis, hidden: true },
        { key: "weight", title: WorkInstructionLabels._Weight, hidden: false },
        { key: "workInstructionStatus", title: WorkInstructionLabels._Status, hidden: false },
        { key: "jobSteppingStatus", title: WorkInstructionLabels._JobSteppingStatus, hidden: false },
    ];
    const [openDropdownIndex, setOpenDropdownIndex] = useState<number | null>(null);
    const dropdownRef = useRef<HTMLDivElement | null>(null);
    
    const handleDropdownToggle = (index: number) => {
        setOpenDropdownIndex(prev => (prev === index ? null : index));
    };
    const columns: ColumnDef<WorkAssWorkInstruction>[] = [
        ...columnsConfig.map(({ key, title, hidden }) => {
            const column: ColumnDef<WorkAssWorkInstruction> = {
                accessorKey: key,
                header: title,
                enableSorting: false,
                meta: { hidden },
            };
            if (key === "vesselVisitId") {
                column.cell = ({ row }) => row.original.vesselVisit.visitRef;
            }
            if (key === "pointOfWorkId") {
                column.cell = ({ row }) =>
                    PointofWorkStore.pointofWorks.length > 0
                        ? PointofWorkStore.pointofWorks.find(
                            (pointofWork) => pointofWork.id === row.original.pointOfWorkId
                        )?.name ?? "N/A" : "N/A";
            }
            return column;
        }),
        {
            accessorKey: "actions",
            header: "Action",
            enableSorting: false,
            enableHiding: false,
            size: 150,
            meta: { hidden: false },
            cell: ({ row }) => {
                const handleAction = () => {
                    if (row.original.workInstructionStatus === "Inprogress") {
                        ErrorToaster("Active workinstruction can not be append");
                        return;
                    }
                    setOpenDropdownIndex(null);
                    setSelectedWI(row.original);
                    setIsAppendModalOpen(true);
                };

                if (row.original.jobSteppingStatus === 'Completed') {
                    return null;
                }
                useEffect(() => {
                    const handleClickOutside = (event: MouseEvent) => {
                        if (
                            dropdownRef.current &&
                            !dropdownRef.current.contains(event.target as Node)
                        ) {
                            setOpenDropdownIndex(null);
                        }
                    };

                    document.addEventListener('mousedown', handleClickOutside);
                    return () => {
                        document.removeEventListener('mousedown', handleClickOutside);
                    };
                }, []);

                return (
                    <div className="flex space-x-2">
                        <Button
                            size="icon"
                            variant="outline"
                            className="text-center"
                            onClick={() => handleDropdownToggle(row.index)} // Pass row index
                        >
                            <Ellipsis className="w-2 h-2" />
                        </Button>
                        {openDropdownIndex === row.index && ( // Show dropdown only if the row's dropdown is open
                            <div ref={dropdownRef}  className="origin-top-right absolute z-10 right-2 mb-12 w-20 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                                <div className="py-1">
                                    {options.map((option, idx) => (
                                        <button
                                            key={idx}
                                            className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                                            onClick={() => handleAction()}
                                        >
                                            {option}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                );
            }
        },
    ];
    return (
        <div>
            {isLoading ? (
                <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                        <Skeleton key={i} className="w-full h-8" />
                    ))}
                </div>
            ) : (
                <DataTable
                    columns={columns}
                    data={workInstructionList ?? []}
                    totalRecords={totalRecords}
                    pagination={paged}
                    onPaginationChange={onPaginationChange}
                />

            )}
            {isAppendModalOpen && (
                <AppendModal
                    open={isAppendModalOpen}
                    onClose={() => { setIsAppendModalOpen(false) }}
                    data={workQueuePOWList}
                    selectedVessVisit={selectedVessVisit}
                    selectedWorkInstruction={selectedWI}
                    selectedWorkQueue={selectedWorkQueue}
                    onViewWorkInstructionClick={onViewWorkInstructionClick}
                />
            )}
        </div>
    );
}
interface WorkAssinPOWProps {
    powList: WorkAssignmentPOW[];
    onPOWItemOnClick: (data: WorkAssignmentPOW, callBy: string, powList: string[]) => void;
}
export const WorkAssinPOWUI = ({ powList, onPOWItemOnClick }: WorkAssinPOWProps) => {
    console.log("powList", powList)
    const getStatusByMoves = (pointOfWork: WorkAssignmentPOW) => {

        if (pointOfWork.totalPlannedMoves === pointOfWork.completedMoves) {
            return {
                status: 'Completed',
                bgColor: "bg-green-100",
                textColor: "text-green-800",
            }
        } else if (pointOfWork.completedMoves === 0) {
            return {
                status: 'Yet to Start',
                bgColor: "bg-gray-100",
                textColor: "text-gray-600",
            }
        }
        else
            return {
                status: 'Working',
                bgColor: "bg-blue-100",
                textColor: "text-blue-600",
            }
    }
    const headers = ['POW', 'Pool', 'Status', 'Work Queue']
    return (

        <div className="w-full mt-4 border rounded shadow-sm overflow-hidden">
            {
                powList.length > 0 ? (
                    <div className="w-full">
                        <div className="grid grid-cols-4 bg-[#2C427E]   text-gray-700 font-bold text-sm px-4 py-2 border-b">
                            {headers.map((header, idx) => (
                                <div key={idx} className="text-left text-white">{header}</div>

                            ))}
                        </div>

                        {powList.map((item) => (
                            <div
                                key={item.id}
                                className="grid grid-cols-4 bg-grey-50 items-center px-4 py-3 border-b hover:bg-gray-100 transition duration-150 ease-in-out cursor-pointer"
                            >
                                <div className="flex flex-col">
                                    <span className=" text-black">{item.name} ({item.completedMoves} / {item.totalPlannedMoves})</span>
                                    {/* <span className="text-xs text-gray-600">
               
              </span> */}
                                </div>
                                <div className="text-sm  text-gray-800">
                                    {item.pool}
                                </div>
                                <div className={`text-sm  py-0.5 rounded  text-center w-fit  ${getStatusByMoves(item).textColor}`}>
                                    {getStatusByMoves(item).status}
                                </div>
                                <div
                                    onClick={() => { onPOWItemOnClick(item, "", powList) }}
                                    className="text-blue-500 hover:underline text-sm flex items-center text-center space-x-1 pl-7"
                                >
                                    <span className="text-center" title="view"><Eye size={16} /></span>
                                    {/* <ArrowRightFromLine color="blue" /> */}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="p-4 text-center text-gray-500">No POW Data Found.</div>
                )
            }
        </div>

    )
}

export function WorkAssignmentsTableUI({
    workAssignmentsList,
    toggleRow,
    onPOWItemOnClick,
    isLoading,
    paged,
    onPaginationChange,
    totalRecordWorkAssignData
}: {
    workAssignmentsList: WorkAssignment[];
    toggleRow: (id: string, item: WorkAssignment, row: Row<WorkAssignment>) => void;
    onPOWItemOnClick: (powItem: WorkAssignmentPOW, callBy: string) => void;
    isLoading: boolean;
    paged: PaginationState;
    onPaginationChange: (pagination: PaginationState) => void;
    totalRecordWorkAssignData: number;
}) {
    // const ITEMS_PER_PAGE = 10;
    // const [currentPage, setCurrentPage] = useState(1);
    // const totalPages = Math.ceil(workAssignmentsList.length / ITEMS_PER_PAGE);
    // console.log(workAssignmentsList)
    const columnsConfig = [
        { key: "vesselRef", title: "Visit Ref.", hidden: false },
        { key: "vesselName", title: "Vessel Name", hidden: false },
        { key: "quay", title: "Berth", hidden: false },
        { key: "vesselVisitPhase", title: "Phase", hidden: false },
        { key: "eta", title: "ETA", hidden: true },
        { key: "etd", title: "ETD", hidden: true },
        { key: "ata", title: "ATA", hidden: true },
        { key: "atd", title: "ATD", hidden: true },
        { key: "totalPlannedMoves", title: "Total Planned Moves", hidden: false },
        { key: "completedMoves", title: "Total Moves Completed", hidden: false },
    ];
    const columns: ColumnDef<WorkAssignment>[] = [
        ...columnsConfig.map(({ key, title, hidden }) => {
            const column: ColumnDef<WorkAssignment> = {
                accessorKey: key,
                header: title,
                // header: ({ column }) => SortableHeader({ column, title }),
                // enableSorting: sortable,
                enableHiding: true,
                meta: { hidden },
            };
            if (["eta", "etd", "ata", "atd", "startWorkTime", "endWorkTime"].includes(key)) {
                column.cell = ({ row }) => {
                    const value = row?.getValue(key);
                    if (!value) return '';

                    const [date, time] = convertTime(value).split(' ');

                    return (
                        <div className="flex flex-col items-start">
                            <span className="">{date}</span>
                            <span className="">{time}</span>
                        </div>
                    );
                };
            }

            return column;
        }),
        {
            accessorKey: "actions",
            header: "Action",
            enableSorting: false,
            enableHiding: false,
            meta: {
                hidden: false,
            },
            cell: ({ row }) => {
                const item = row.original;
                const isExpanded = row.getIsExpanded();
                // console.log(isExpanded)
                return (
                    <button
                        onClick={() => {
                            toggleRow(item.vesselVisitId, item, row);
                        }}
                        className="flex"
                    >
                        {isExpanded ? (
                            <ChevronUp className="text-gray-400" />
                        ) : (
                            <ChevronDown className="text-gray-400" />
                        )}
                    </button>
                );
            },

        },
    ];
    return (
        <>
            {isLoading ? (
                <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                        <Skeleton key={i} className="w-full h-8" />
                    ))}
                </div>
            ) : (
                <>
                    <DataTable
                        columns={columns}
                        data={workAssignmentsList || []}
                        totalRecords={totalRecordWorkAssignData}
                        pagination={paged}
                        onPaginationChange={onPaginationChange}
                        onPOWItemOnClick={onPOWItemOnClick}
                    />
                </>
            )}
        </>
    );
}


interface AppendModalProps {
    open: boolean;
    onClose: () => void;
    data: WorkAssignmentPOW[];
    selectedVessVisit: VesselVisit;
    selectedWorkInstruction: WorkInstruction;
    selectedWorkQueue: workQueueResponse;
    onViewWorkInstructionClick: () => void;
}


export function AppendModal({ open, onClose, data, selectedVessVisit, selectedWorkInstruction, selectedWorkQueue, onViewWorkInstructionClick }: AppendModalProps) {
    const [expanded, setExpanded] = useState(false);
    const [selectedQueue, setSelectedQueue] = useState<workQueueResponse | null>(null);
    const [queueList, setQueueList] = useState<workQueueResponse[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [activePOW, setActivePOW] = useState<workQueueResponse | null>(null);
    console.log(selectedWorkQueue)
    useEffect(() => {
        if (data?.length > 0 && open) {
            const powItem = data[0];
            setActivePOW(powItem);
            const fetchQueues = async () => {
                try {
                    setIsLoading(true);
                    const response = await fetchWorkQueuesByPowAPICALL(selectedVessVisit?.vesselVisitId, powItem.id);
                    const filteredResponse = response.filter(el => el.id !== selectedWorkQueue.id)
                    console.log(filteredResponse)
                    setQueueList(filteredResponse ?? []);
                } catch (error) {
                    console.error("error", error);
                } finally {
                    setIsLoading(false);
                }
            };
            fetchQueues();
        }
    }, [data, selectedVessVisit, open]);

    const handleUpdateClick = async () => {
        if (!selectedQueue || !activePOW) return;
        const payload = {
            workInstructionId: selectedWorkInstruction.id,
            powId: activePOW.id,
            workQueueId: selectedQueue.id
        };

        try {
            const response = await AppendQueue(payload);
            if (response.status === 200) {
                SuccessToaster("", "Work Instruction Appended successfully");
                onViewWorkInstructionClick()
                onClose();
            }
        } catch (error: any) {
            console.error(error);
            ErrorToaster("Queue Instruction Append Failed", error?.message ?? "Unknown error occurred");
        }
    };
    const handleDropdownToggle = () => {
        setExpanded((prev) => !prev);
    };
    const handleSelectQueue = useCallback((item: workQueueResponse) => {
        setSelectedQueue(prev => (prev?.id === item.id ? null : item));
    }, []);

    const handlePOWSelect = useCallback(async (item: WorkAssignmentPOW) => {
        setActivePOW(item);
        setExpanded(false);
        setSelectedQueue(null);
        try {
            setIsLoading(true);
            const response = await fetchWorkQueuesByPowAPICALL(selectedVessVisit?.vesselVisitId, item.id);
            setQueueList(response ?? []);
        } catch (error) {
            console.error("error", error);
        } finally {
            setIsLoading(false);
        }
    }, [selectedVessVisit]);



    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="p-4 max-w-md">
                <DialogHeader>
                    <DialogTitle className="text-base">Queue List</DialogTitle>
                    <DialogDescription className="text-sm text-muted-foreground">
                        Select a queue from the list below
                    </DialogDescription>
                </DialogHeader>
                {/* POW */}
                <div className="relative">
                    <div
                        className="border rounded px-3 py-1.5 cursor-pointer text-sm flex justify-between items-center"
                        onClick={handleDropdownToggle}
                    >
                        <span>{activePOW?.name || "Select"}</span>
                        <FaChevronDown className={cn("transition-transform", { "rotate-180": expanded })} />
                    </div>

                    {expanded && (
                        <div className="absolute z-10 w-full mt-1 bg-white border rounded shadow max-h-48 overflow-y-auto text-sm">
                            {data.length > 0 ? (
                                data.map((item) => (
                                    <div
                                        key={item.id}
                                        onClick={() => handlePOWSelect(item)}
                                        className={cn(
                                            "px-3 py-2 hover:bg-gray-100 cursor-pointer",
                                            activePOW?.id === item.id && "bg-blue-50 font-semibold"
                                        )}
                                    >
                                        {item.name}
                                    </div>
                                ))
                            ) : (
                                <div className="px-3 py-2 text-gray-400">No POWs available</div>
                            )}
                        </div>
                    )}
                </div>

                {/* Queue */}
                {activePOW && (
                    <div className="mt-2 space-y-1 border rounded p-1.5 max-h-52 overflow-y-auto text-sm">
                        {isLoading ? (
                            <p className="text-center text-xs text-gray-500">Loading...</p>
                        ) : queueList.length > 0 ? (
                            queueList
                                .filter(item => item.id !== selectedWorkQueue.id)
                                .map(item => (
                                    <div
                                        key={item.id}
                                        onClick={() => handleSelectQueue(item)}
                                        className={cn(
                                            "p-1.5 rounded cursor-pointer hover:bg-gray-100",
                                            selectedQueue?.id === item.id && "bg-blue-100 text-blue-700 font-semibold"
                                        )}
                                    >
                                        {`${selectedVessVisit.vesselRef}-${item.name}${item.deck}/${item.type === "Load" ? "L" : "D"}`}
                                    </div>
                                ))
                        ) : (
                            <p className="text-xs text-gray-400">No queues found.</p>
                        )}
                    </div>
                )}

                <div className="mt-3 flex justify-end">
                    <Button size="sm" onClick={handleUpdateClick} disabled={!selectedQueue}>
                        Update
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}



