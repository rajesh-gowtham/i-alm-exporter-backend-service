import { useEffect, useState } from "react";
import {
    ColumnDef,
    flexRender,
    SortingState,
    VisibilityState,
    ColumnFiltersState,
    getCoreRowModel,
    getSortedRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    useReactTable,
    RowData,
} from "@tanstack/react-table";

import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";

import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { ArrowUpDown } from "lucide-react";

interface DataTableProps<TData, TValue> {
    columns: ColumnDef<TData, TValue>[];
    data: TData[];
    scrollAreaClassName?: string | null;
    handlePaginationControl: (controlType: string, ctrlValue: number) => void;
}

export function DataTablePagination<TData, TValue>({
    columns,
    data,
    scrollAreaClassName,
    handlePaginationControl
}: DataTableProps<TData, TValue>) {
    const [sorting, setSorting] = useState<SortingState>([]);
    const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);

    const initialVisibility = columns.reduce((acc, column) => {
        if (column.meta?.hidden && (column as any)?.accessorKey) {
            acc[(column as any).accessorKey as string] = false;
        }
        return acc;
    }, {} as VisibilityState);

    const [columnVisibility, setColumnVisibility] =
        useState<VisibilityState>(initialVisibility);
    const [tableData, setTableData] = useState(data);
    const table = useReactTable({
        data: tableData,
        columns,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
        },
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onColumnVisibilityChange: setColumnVisibility,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
    });
    console.log(data, table.getRowModel().rows?.length, table.getPageCount(), table.getPaginationRowModel());

    // update data when props.tableData changes
    useEffect(() => {
        setTableData(data);
    }, [data]);

    return (
        <div className="w-full py-3 px-4">
            <ScrollArea
                type="always"
                className={cn("rounded-md border", scrollAreaClassName)}
            >
                <Table>
                    <TableHeader className="sticky top-0 bg-blue-600/80 text-white">
                        {table.getHeaderGroups().map((headerGroup) => (
                            <TableRow key={headerGroup.id}>
                                {headerGroup.headers.map((header) => (
                                    <TableHead className="text-white" key={header.id}>
                                        {header.isPlaceholder
                                            ? null
                                            : flexRender(
                                                header.column.columnDef.header,
                                                header.getContext()
                                            )}
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map((row) => (
                                <TableRow
                                    key={row.id}
                                    data-state={row.getIsSelected() && "selected"}
                                    className="h-10 hover:bg-gray-100 border-b border-gray-200 transition-colors duration-150"
                                >
                                    {row.getVisibleCells().map((cell) => (
                                        <TableCell
                                            key={cell.id}
                                            className="px-4 py-3 h-10 text-center align-middle text-sm text-gray-800"
                                        >
                                            <div className="flex items-center h-full w-full overflow-hidden text-ellipsis whitespace-nowrap">
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </div>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell
                                    colSpan={columns.length}
                                    className="h-24 text-center"
                                >
                                    No results.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
                <ScrollBar orientation="horizontal" />
            </ScrollArea>

            <div className="flex justify-between items-center flex-wrap gap-4 mt-4">
                {/* Column Visibility */}
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="justify-start">
                            Columns
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start">
                        {table
                            .getAllColumns()
                            .filter((column) => column.getCanHide())
                            .map((column) => (
                                <DropdownMenuCheckboxItem
                                    key={column.id}
                                    className="capitalize"
                                    checked={column.getIsVisible()}
                                    onCheckedChange={(value) =>
                                        column.toggleVisibility(!!value)
                                    }
                                >
                                    {column.id}
                                </DropdownMenuCheckboxItem>
                            ))}
                    </DropdownMenuContent>
                </DropdownMenu>

                {/* Pagination + Page Size */}
                {/* <div className="flex items-center gap-4 ml-auto">
                    <div className="flex items-center gap-2">
                        <span>Rows per page:</span>
                        <select
                            className="border rounded px-2 py-1 text-sm"
                            value={table.getState().pagination.pageSize}
                            onChange={(e) => {
                                table.setPageSize(Number(e.target.value));
                                handlePaginationControl("rowCount", parseInt(e.target.value))
                            }}
                        // onChange={(e) => { handlePaginationControl("rowCount", parseInt(e.target.value)) }}
                        >
                            {[5, 10, 20, 50, 100].map((pageSize) => (
                                <option key={pageSize} value={pageSize}>
                                    {pageSize}
                                </option>
                            ))}
                        </select>
                    </div>

                    <Button
                        variant="outline"
                        size="sm"
                        // onClick={() => table.previousPage()}
                        onClick={() => { handlePaginationControl("prevPage", 0) }}
                        disabled={!table.getCanPreviousPage()}
                    >
                        Previous
                    </Button>
                    <Button
                        variant="outline"
                        size="sm"
                        // onClick={() => table.nextPage()}
                        onClick={() => { handlePaginationControl("nextPage", 0) }}
                        disabled={!table.getCanNextPage()}
                    >
                        Next
                    </Button>
                </div> */}
            </div>
        </div>
    );
}

export const SortableHeader = ({
    column,
    title,
}: {
    column: any;
    title: string;
}) => (
    <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        className="px-1"
    >
        {title}
        <ArrowUpDown className="w-4 h-4 ml-1" />
    </Button>
);

declare module "@tanstack/react-table" {
    interface ColumnMeta<TData extends RowData, TValue> {
        hidden?: boolean;
    }
}