import SubHeader from "@/components/SubHeader";
import { Skeleton } from "@/components/ui/skeleton";
import { CustomModelDialog, DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { VesselBerthing } from "@/lib/models";
import { BerthingLabels } from "@/lib/models/form-constants/formLabels";
import {
  addVesselBerthing,
  deleteVesselBerthing,
  editVesselBerthing,
  fetchVesselBerthings,
  fetchVesselVisits,
} from "@/lib/services/vessels-services";
import { convertTime } from "@/lib/utils";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useVesselBerthingStore from "../store/VesselBerthingStore";
import useVesselVisitStore from "../store/VesselVisitStore";
import VesselBerthingForm from "./vessel-berthing-form";
import VesselBerthingImport from "./vessel-berthing-import";

export default function VesselBerthingMaster() {
  const [VesselBerthings, setVesselBerthings] = useState<VesselBerthing[]>([]);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  // const [filteredVesselBerthings, setFilteredVesselBerthings] = useState<VesselBerthing[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [VesselBerthingToEdit, setVesselBerthingToEdit] = useState<VesselBerthing | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [VesselBerthingToDelete, setVesselBerthingToDelete] = useState<VesselBerthing | undefined>(undefined);
  const vesselBerthingStore = useVesselBerthingStore();
  const vesselVisitStore = useVesselVisitStore();
  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const columnsConfig = [
    { key: "quay", title: BerthingLabels._Quay, hidden: false },
    { key: "berthingSide", title: BerthingLabels._Side_To, hidden: false },
    { key: "berthEta", title: BerthingLabels._BerthETA, hidden: true, transform: "time" },
    { key: "berthEtd", title: BerthingLabels._BerthETD, hidden: true, transform: "time" },
    { key: "berthAta", title: BerthingLabels._BerthATA, hidden: false, transform: "time" },
    { key: "startWorkTime", title: BerthingLabels._StartWorkTime, hidden: true, transform: "time" },
    { key: "startBollard", title: BerthingLabels._StartBollard, hidden: false },
    { key: "endBollard", title: BerthingLabels._EndBollard, hidden: false },
    { key: "vesselVisitId", title: BerthingLabels._VisitRef, hidden: false },
  ];
  const columns: ColumnDef<VesselBerthing>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => {
      const column: ColumnDef<VesselBerthing> = {
        accessorKey: key,
        header: title,
        // header: ({ column }) => SortableHeader({ column, title }),
        // enableSorting: sortable,
        // enableHiding: true,
        meta: { hidden },
      };
      if (key === "vesselVisitId") {
        column.cell = ({ row }) =>
          vesselVisitStore.vesselVisits.length > 0
            ? vesselVisitStore.vesselVisits.find((vesselVisit) => vesselVisit.id === row.original.vesselVisitId)?.visitRef ?? 'N/A'
            : 'N/A'
      }
      if (["berthAta", "startWorkTime", "berthEtd", "berthEta"].includes(key)) {
        column.cell = ({ row }) => row.getValue(key) ? convertTime(row.getValue(key)) : '';
      }
      return column;
    }),

    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: { hidden: false },
      cell: ({ row }: { row: { original: VesselBerthing } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];


  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  }

  const fetchVesselVisitsData = async () => {
    try {
      const data = await fetchVesselVisits();

      vesselVisitStore.setVesselVisits(data["items"]);
    } finally {
      //
    }
  };
  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchVesselBerthings(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setVesselBerthings(items as VesselBerthing[]);
      setTotalRecord(totalCount as number);
      vesselBerthingStore.setVesselBerthings(items as VesselBerthing[]);
    } finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  useEffect(() => {
    fetchData();
    fetchVesselVisitsData();
  }, [paged]);

  const handleEdit = (VesselBerthing: VesselBerthing) => {
    setVesselBerthingToEdit(VesselBerthing);
    setOpen(true);
  };

  const handleDeleteClick = (VesselBerthing: VesselBerthing) => {
    setVesselBerthingToDelete(VesselBerthing);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    if (VesselBerthingToDelete?.id) {
      setLoading(true);
      await deleteVesselBerthing(VesselBerthingToDelete.id.toString());
      await fetchData();
      mutate("vesselBerthing");
      setLoading(false);
      SuccessToaster('', "Berthing deleted successfully");
    }
    setConfirmDeleteOpen(false);
  };

  const handleSubmit = async (
    data: Omit<
      VesselBerthing,
      | "id"
      | "createdBy"
      | "updatedBy"
      | "createdAt"
      | "updatedAt"
      | "vesselVisit"
    >
  ) => {

    try {
      // setLoading(true);

      if (VesselBerthingToEdit?.id) {
        await editVesselBerthing(VesselBerthingToEdit.id + "", data);
        SuccessToaster('', "Berthing updated successfully");
      } else {
        await addVesselBerthing(data);
        setLoading(true)
        SuccessToaster('', "Berthing created successfully");
      }
      setOpen(false);
      setVesselBerthingToEdit(undefined);
      await fetchData();
      mutate("vesselBerthing");
      setLoading(false);
    } catch (error) {
      console.error(error);
      ErrorToaster("Berthing creation Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  };
  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredVesselBerthings(VesselBerthings);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = VesselBerthings?.filter(
  //       (VesselBerthing) =>
  //         vesselVisitStore.vesselVisits.some(
  //           (visit) =>
  //             visit.visitRef.toLowerCase() === lowerCasedQuery &&
  //             visit.id === VesselBerthing.vesselVisitId
  //         ) ||
  //         VesselBerthing.quay?.toLowerCase().includes(lowerCasedQuery) ||
  //         (convertTime(VesselBerthing.berthEta)?.toLowerCase() || "").includes(
  //           lowerCasedQuery
  //         )
  //     );
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     setFilteredVesselBerthings(filtered.slice(start, end));
  //   }
  // }, [searchQuery, VesselBerthings]);
  // Import rework
  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false);
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?
        <div>
          <SubHeader
            placeholder="Visit Ref/Quay..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Configuration + privateRoute._Berthing_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setVesselBerthingToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={VesselBerthings || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}
          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={VesselBerthingToDelete?.quay + "" || ""}
            />
          }

          {/* Vessel Form Modal */}
          {/* <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setVesselBerthingToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {VesselBerthingToEdit
                  ? "Edit Vessel Berthing"
                  : "Add Vessel Berthing"}
              </DialogTitle>
              <VesselBerthingForm
                VesselBerthing={VesselBerthingToEdit}
                onClose={() => {
                  setOpen(false);
                  setVesselBerthingToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog> */}

          <CustomModelDialog
            isOpen={open}
            onClose={setOpen}
            title={VesselBerthingToEdit ? "Edit Vessel Berthing" : "Add Vessel Berthing"}>
            <VesselBerthingForm
              VesselBerthing={VesselBerthingToEdit}
              onClose={() => {
                setOpen(false);
                setVesselBerthingToEdit(undefined);
              }}
              onSubmit={handleSubmit}
            />
          </CustomModelDialog>

        </div>
        :
        <VesselBerthingImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
