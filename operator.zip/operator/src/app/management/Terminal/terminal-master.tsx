import SubHeader from "@/components/SubHeader";

export default function TermainalMaster() {

  return (
    <SubHeader
        placeholder="Terminal..."
        searchValue={''}
        onSearchChange={()=>{}}
        addButtonLabel="+"
        isButtonDisabled={false}
        importNavigationUrl={''}
        onAddClickOpen={()=>{}}
        setComponentToEdit={()=>{}}
      />
  );
}
