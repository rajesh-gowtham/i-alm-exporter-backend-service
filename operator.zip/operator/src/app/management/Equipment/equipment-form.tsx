import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownWhite, ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { equipmentOptionList } from "@/lib/constants";
import { Equipment } from "@/lib/models";
import { EquipmentLabels } from "@/lib/models/form-constants/formLabels";
import { EquipmentSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";

interface EquipmentFormProps {
  Equipment?: Equipment;
  onClose: () => void;
  onSubmit: (data: Equipment) => void;
}

export default function EquipmentForm({
  Equipment,
  onClose,
  onSubmit,
}: EquipmentFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const {
    register,
    reset,
    handleSubmit,
    setValue,
    clearErrors,
    getValues,
    formState: { errors },
  } = useForm<z.infer<typeof EquipmentSchema>>({
    resolver: zodResolver(EquipmentSchema),
    defaultValues: Equipment ? { ...Equipment, id: Number(Equipment.id) } : {},
  });

  const EquipmentMemo = useMemo(() => Equipment, [Equipment]);

  useEffect(() => {
    if (EquipmentMemo) {
      reset({
        ...EquipmentMemo,
        id: EquipmentMemo.id ? Number(EquipmentMemo.id) : undefined,
      });
    }
  }, [EquipmentMemo, reset]);

  const submitHandler = async (formData: z.infer<typeof EquipmentSchema>) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      await onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* ... (input fields) ... */}

        <div>
          <Label>{EquipmentLabels._EquipmentName}</Label>
          {(!EquipmentSchema.shape.equipmentName.isOptional()) && <MandatoryIcon />}
          <Input {...register("equipmentName")}
            disabled={Equipment !== undefined}
            readOnly={Equipment !== undefined}
            error={!!errors.equipmentName}
          />
        </div>
        <div>
          <Label>{EquipmentLabels._EquipmentType}</Label>
          {(!EquipmentSchema.shape.equipmentType.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={EquipmentLabels._EquipmentType}
            fieldName="equipmentType"
            fieldValue={Equipment?.equipmentType || ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={equipmentOptionList}
            error={!!errors.equipmentType}
          />
        </div>
        <div>
          <Label>{EquipmentLabels._MaxWeightInTon}</Label>
          {(!EquipmentSchema.shape.maxWeight.isOptional()) && <MandatoryIcon />}
          <Input
            type="number"
            {...register("maxWeight", { valueAsNumber: true })}
            error={!!errors.maxWeight}
          />
        </div>
        <div>
          <Label>{EquipmentLabels._MaxTEU}</Label>
          {(!EquipmentSchema.shape.maxTeu.isOptional()) && <MandatoryIcon />}
          <Input
            type="number"
            {...register("maxTeu", { valueAsNumber: true })}
            error={!!errors.maxTeu}
          />
        </div>
        <div>
          <Label>{EquipmentLabels._Make}</Label>
          {(!EquipmentSchema.shape.make.isOptional()) && <MandatoryIcon />}
          <Input {...register("make")} />
        </div>
        <div>
          <Label>{EquipmentLabels._Model}</Label>
          {(!EquipmentSchema.shape.model.isOptional()) && <MandatoryIcon />}
          <Input {...register("model")} />
        </div>
        {getValues("equipmentType") === "Terminal Truck" && <>
          <div>
            <Label>{EquipmentLabels._RFIDTag1}</Label>
            {(!EquipmentSchema.shape.rfidTag1.isOptional()) && <MandatoryIcon />}
            <Input {...register("rfidTag1")} />
          </div>
          <div>
            <Label>{EquipmentLabels._RFIDTag2}</Label>
            {(!EquipmentSchema.shape.rfidTag2.isOptional()) && <MandatoryIcon />}
            <Input {...register("rfidTag2")} />
          </div></>

        }
      </div>
      <FormActions
        isEdit={Equipment?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
