import SubHeader from "@/components/SubHeader";
import { Skeleton } from "@/components/ui/skeleton";
import { CustomModelDialog, DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { Vessel } from "@/lib/models";
import { VesselFields } from "@/lib/models/form-constants/formLabels";
import {
  addVessel,
  deleteVessel,
  editVessel,
  fetchVessels,
} from "@/lib/services/vessels-services";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useCallback, useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useVesselStore from "../store/vesselStore";
import VesselForm from "./vessel-form";
import VesselImport from "./vessel-import";

export default function VesselMaster() {
  const [vessels, setVessels] = useState<Vessel[]>([]);

  const [totalRecord, setTotalRecord] = useState(0);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  // const [filteredVessels, setFilteredVessels] = useState<Vessel[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [vesselToEdit, setVesselToEdit] = useState<Vessel | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [vesselToDelete, setVesselToDelete] = useState<Vessel | undefined>(undefined);

  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const vesselStore = useVesselStore();

  const columnsConfig = [
    { key: "vesselName", title: VesselFields._Name, hidden: false },
    { key: "vesselClass", title: VesselFields._VesselClass, hidden: false },
    { key: "operator", title: VesselFields._LineOperator, hidden: false },
    { key: "overallLength", title: VesselFields._LOAInCm, hidden: false },
    { key: "radioCallSign", title: VesselFields._RadioCallSign, hidden: false },
    { key: "lloydsIdentity", title: VesselFields._LloydsIdentity, hidden: false },
    { key: "notes", title: VesselFields._Notes, hidden: true },
  ];

  const columns: ColumnDef<Vessel>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: true,
      enableSorting: false,
      size: 200,
      meta: { hidden: hidden },
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      size: 150,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: Vessel } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];

  const fetchData = useCallback(async () => {
    setOpen(false);
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchVessels(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setVessels(items as Vessel[]);
      vesselStore.setVessels(items as Vessel[]);
    } finally {
      setOpen(false);
    }
  }, [paged]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);


  const handleEdit = (vessel: Vessel) => {
    setVesselToEdit(vessel);
    setOpen(true);
  };
  const handlePaginationChange = (newPagination: PaginationState) => {
    // console.log("newPagination", newPagination);
    setPaged(newPagination);
  };
  const handleDeleteClick = (vessel: Vessel) => {
    setVesselToDelete(vessel);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (vesselToDelete?.id) {
        setLoading(true);
        await deleteVessel(vesselToDelete.id.toString());
        await fetchData();
        mutate("vessels");
        setLoading(false);
        SuccessToaster('', "Vessel deleted successfully");
      }
      setConfirmDeleteOpen(false);
    } catch (error) {
      console.error(error);
      ErrorToaster("Vessel Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
  };

  // const handleSubmit = async (data: Omit<Vessel, "id" | "created" | "updated">) => {
  //   setLoading(true);
  //   if (vesselToEdit?.id) {
  //     await editVessel(vesselToEdit.id.toString(), data);
  //     SuccessToaster('', "vessel created successfully");
  //   } else {
  //     const isvesselExists = vessels?.some(item => (item.vesselName?.toLowerCase()?.trim() === data.vesselName?.toLowerCase().trim()));
  //     console.log(isvesselExists, data);
  //     if (isvesselExists) {
  //       ErrorToaster("Vessel already exists");
  //       setLoading(false);
  //       return;
  //     }
  //     await addVessel(data);
  //   }
  //   setOpen(false);
  //   setVesselToEdit(undefined);
  //   await fetchData();
  //   mutate("vessels");
  //   setLoading(false);
  // };

  const handleSubmit = async (data: Omit<Vessel, "id" | "created" | "updated">) => {
    // setLoading(true);
    console.log(" submission data", data);
    try {
      if (vesselToEdit?.id) {
        await editVessel(vesselToEdit.id.toString(), data);
        SuccessToaster('', "Vessel updated successfully");
      } else {
        // const isVesselExists = vessels?.some(
        //   item => item.vesselName?.toLowerCase().trim() === data.vesselName?.toLowerCase().trim()
        // );
        // if (isVesselExists) {
        //   ErrorToaster("Vessel already exists");
        //   return;
        // }
        await addVessel(data);
        SuccessToaster('', "Vessel created successfully");
      }
      setOpen(false);
      setVesselToEdit(undefined);
      await fetchData();
      mutate("vessels");
    } catch (error) {
      console.error(error);
      ErrorToaster("Vessel Creation Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  };
  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredVessels(vessels);
  //     // setTotalRecord(totalRecord);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = vessels.filter(
  //       (vessel) =>
  //         vessel.vesselName.toLowerCase().includes(lowerCasedQuery) ||
  //         vessel.vesselClass.toLowerCase().includes(lowerCasedQuery));
  //     // vessel.operator.toLowerCase().includes(lowerCasedQuery));
  //     // Apply pagination
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     //  setDisplayedVessels();
  //     // setTotalRecord(filtered.length); // 
  //     setFilteredVessels(filtered.slice(start, end));
  //   }
  // }, [searchQuery, vessels, paged]);
  // Import rework
  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false);
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false);
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?
        <div>
          <SubHeader
            placeholder="Vessel Name/Class..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Configuration + privateRoute._Vessel_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setVesselToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={vessels || []}
              pagination={paged}
              totalRecords={totalRecord}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={vesselToDelete?.vesselName || ""}
            />
          }

          {/* Vessel Form Modal */}
          {/* <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setVesselToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {vesselToEdit ? "Edit Vessel" : "Add Vessel"}
              </DialogTitle>
              <VesselForm
                vessel={vesselToEdit}
                onClose={() => {
                  setOpen(false);
                  setVesselToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog> */}
          <CustomModelDialog
            isOpen={open}
            onClose={setOpen}
            title={vesselToEdit ? "Edit Vessel" : "Add Vessel"}>
            <VesselForm
              vessel={vesselToEdit}
              onClose={() => {
                setOpen(false);
                setVesselToEdit(undefined);
              }}
              onSubmit={handleSubmit}
            />
          </CustomModelDialog>
        </div>
        :
        <VesselImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
