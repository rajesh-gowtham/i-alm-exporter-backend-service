// WaterSideDashboardMap.tsx
import { useEffect, useState, useRef } from "react";
import {
  RMap,
  RMapContextProvider} from "maplibre-react-components";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  googleProtocol,
  createGoogleStyle
} from "maplibre-google-maps";

// GeoJSON Data
import IVTL2R from "@/data/geojsonnew/itvL2R.png";
import ITVR2L from "@/data/geojsonnew/itvR2L.png";
import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import QuayCraneActive from "@/data/geojsonnew/quay crane deep Blue- yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";

// Components
import ContainerYard from "@/data/geojsonnew/container_yards.json";
import ContainerYardCentroids from "@/data/geojsonnew/container_yards_point.json";
import Road from "@/data/geojsonnew/road_v1.json";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import DividerLayer from "./Layers/DividerLayer";
import TruckTraffic from "@/data/geojsonnew/truck_traffic_polygon.json";

import {
  INITIAL_BEARING,
  INITIAL_MAX_ZOOM, 
  INITIAL_MIN_ZOOM,
  YardCranes
} from "./MapConstants";
import { loadSpriteImgs } from "./MapUtils";
import GeoJsonLayer from "./GeoJsonLayer";


maplibregl.addProtocol("google", googleProtocol);



export default function WaterSideDashboardMap({active}) {
  const [showBaseMap, setShowBaseMap] = useState(false);
  const mapRef = useRef<any>(null);
  // console.log("active", active);



  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs('quay-crane', QuayCraneImg, 150, 380, map);
      loadSpriteImgs('quay-crane-active', QuayCraneActive, 150, 380, map);
      loadSpriteImgs('single-side-yard-crane', SingleSideYardCarneImg, 40, 205, map);
      loadSpriteImgs('double-side-yard-crane', DoubleSideYardCraneImg, 40, 225, map);
      loadSpriteImgs("itvL2R", IVTL2R, 32, 32, map);
      loadSpriteImgs("itvR2L", ITVR2L, 32, 32, map);
    });
  }, []);



  return (
    <RMapContextProvider>
      <div className="relative">
        
        <RMap
          ref={mapRef}
          style={{
            width: "100%",
            minHeight: "400px",
            height: "100%",
            backgroundColor: showBaseMap ? "transparent" : "white"
          }}
          mapStyle={
            showBaseMap
              ? createGoogleStyle("google", "roadmap", "AIzaSyBiurjht6cC9wpq3EbU9TIMNxE9cGiafqQ")
              : {
                  version: 8,
                  sources: {},
                  layers: [],
                  glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf"
                }
          }
          initialCenter={ [76.99675, 8.3685]}
          initialZoom={16}
          initialAttributionControl={false}
          initialBearing={INITIAL_BEARING}
          initialPitch={0}
          dragRotate={false}
          touchZoomRotate={false}
          initialCanvasContextAttributes={{
              antialias: true,
            }}
        >
            
         
            <GeoJsonLayer
                id="ContainerYard"
                data={ContainerYard}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                    "fill-outline-color": "#5f5f5f",
                    "fill-color": "#5f5f5f",
                    "fill-opacity": 0.1
                }}
                
            />
          <GeoJsonLayer
                id="Road"
                data={Road}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={{
                    "line-color": [
                        "match",
                        ["get", "LAYER"],
                        "Centerline", "transparent",
                        "Service Lane", "transparent",
                        "centre line truck traffic", "transparent",
                        "#c2d1fa"
                    ],
                    "line-width": 1
                }}
                filter={["in", ["get", "LAYER"], ["literal", ["MA_ROAD MARKING", "MA_ROAD"]]]}
            />
         
          <DividerLayer />
          <GeoJsonLayer
            id="TruckTraffic"
            data={TruckTraffic}
            minzoom={INITIAL_MIN_ZOOM}
            maxzoom={INITIAL_MAX_ZOOM}
            type="fill"
            paint={{
              "fill-color": "#5f5f5f",
              "fill-opacity": 0.1
            }}
            layout={{
             
            }}
          />

         <GeoJsonLayer
                id="ContainerYardLabel"
                data={ContainerYardCentroids}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                    "text-size": 14,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "ID"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always"
                    
                }}
                paint={{
                    "text-color": "#000000",
                    "text-halo-color": "#ffffff",
                    "text-halo-width": 2,
                    "text-halo-blur": 0.5,
                }}
            />
                   
          <YardCranesLayer yardCranes ={YardCranes} />
       
         <QuayCrane active={active} showPop={true} />
        </RMap>
      </div>
    </RMapContextProvider>
  );
}
