import React, { useEffect, useRef } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

const TerminalMap = () => {
  const mapContainerRef = useRef(null);
  const mapRef = useRef<maplibregl.Map | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: {
        version: 8,
        sources: {},
        layers: [],
      },
      center: [120.3, 22.6],
      zoom: 15,
    });

    mapRef.current = map;

    map.on("load", () => {
      // Load GeoJSON file
      map.addSource("terminal-map", {
        type: "geojson",
        data: "/terminal_layout.json",
      });
    });

    return () => map.remove();
  }, []);

  return (
    <div style={{ width: "100vw", height: "100vh" }} ref={mapContainerRef} />
  );
};

export default TerminalMap;
