// LandSideDashboardMap.tsx
import { useEffect, useState, useRef } from "react";
import {
  RMap,
  RMapContextProvider,
 RPopup,
  gradientMarkerPopupOffset
} from "maplibre-react-components";
import { format, parseISO  } from "date-fns";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  googleProtocol,
  createGoogleStyle
} from "maplibre-google-maps";

// GeoJSON Data
import IVTL2R from "@/data/geojsonnew/toptruckwithcontainermodified.png";
import ITVR2L from "@/data/geojsonnew/toptruckwithcontainermodified.png";
import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";
import SingleSideYardCarneActiveImg from "@/data/geojsonnew/SingleSideYardCrane_DeepYellow.png";
import DoubleSideYardCraneActiveImg from "@/data/geojsonnew/DoubleSideYardCrane-Yellow.png";
// Components
import ContainerYard from "@/data/geojsonnew/container_yards.json";
import ContainerYardCentroids from "@/data/geojsonnew/container_yards_point.json";
import Road from "@/data/geojsonnew/road_v1.json";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import DividerLayer from "./Layers/DividerLayer";
import TruckTraffic from "@/data/geojsonnew/truck_traffic_polygon.json";
import { useMapPopupStore, useAssetDetailsStore } from "@/app/map/useMapPopupStore";
import ITV from "@/data/geojsonnew/toptruckwithcontainermodified.png"; 

import {
  INITIAL_CENTER,
  INITIAL_BEARING,
  INITIAL_MAX_ZOOM, 
  INITIAL_MIN_ZOOM,
  YardCranes,
  INITIAL_ZOOM,
} from "./MapConstants";
import {  loadSpriteImgs } from "./MapUtils";
import GeoJsonLayer from "./GeoJsonLayer";
import EnhancedAnimatedMarker from "./EnhancedRouteFollowingMarker";


maplibregl.addProtocol("google", googleProtocol);



export default function LandSideDashboardMap() {
  const [showBaseMap, setShowBaseMap] = useState(false);
  const { items } = useAssetDetailsStore();
   const { popupInfo, setPopupInfo, clearPopupInfo } = useMapPopupStore();
   const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);
  console.log('assetItems', items);
  const mapRef = useRef<any>(null);

  let IVTGEOJSON = null;
 
  if (
    items &&
    Array.isArray(items) &&
    items.length > 0
  ) {
    console.log('items',items);
    IVTGEOJSON = {
      type: "FeatureCollection",
      features: items.map(item => ({
        type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [item.longitude, item.latitude]
      },
      properties: {
        asset: item.asset,
        type: item.type,
        operationStatus: item.operationStatus,
        gpsTime: item.gpsTime,
        ignition: item.ignition
      }
    }))
  };
} 


  
  const handleClick = (e, item) => {
    const { lngLat } = e;
    if (!lngLat) return;
       
    setPopupInfo({
      longitude: lngLat.lng,
      latitude: lngLat.lat,
      properties: {
        equipmentName: item.asset,
        ignition: item.ignition,
        operationalState: item.operationStatus,
        gpsTime: format(parseISO(item.gpsTime), 'yyyy-MM-dd HH:mm:ss a'),
      },
    });
  };



  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs('quay-crane', QuayCraneImg, 150, 380, map);
      loadSpriteImgs('single-side-yard-crane', SingleSideYardCarneImg, 40, 205, map);
      loadSpriteImgs('single-side-yard-crane-active', SingleSideYardCarneActiveImg, 40, 205, map);
      loadSpriteImgs('double-side-yard-crane', DoubleSideYardCraneImg, 40, 225, map);
      loadSpriteImgs('double-side-yard-crane-active', DoubleSideYardCraneActiveImg, 40, 225, map);  
      loadSpriteImgs("itvL2R", IVTL2R, 32, 32, map);
      loadSpriteImgs("itvR2L", ITVR2L, 32, 32, map);
    });
  }, []);
const getMarkerSize = (zoom: number) => {
    const baseWidth = 15; // width at zoom 16
    const baseHeight = 5; // maintains original image aspect ratio
    const scale =
      zoom <= 17
        ? 1 + (zoom - 16) * 0.3 // zoom 16 → 1.0, zoom 17 → 1.3
        : 1.4 + (zoom - 17) * 0.6; // zoom 18 → 1.9, zoom 19 → 2.5, zoom 20 → 3.1
    const clampedScale = Math.min(scale, 3); // prevent excessive size at high zoom
    return {
      width: baseWidth * clampedScale,
      height: baseHeight * clampedScale,
    }; // scales between 12px and 48px
  };
 useEffect(() => {
    if (!mapRef.current) return;
    if(popupInfo) {
      mapRef.current?.flyTo({
          center: [ popupInfo.longitude, popupInfo.latitude ],
          zoom: 18,
          duration: 1000
        });
    }
  }, [popupInfo]);

  return (
    <RMapContextProvider>
      <div className="relative">
        
        <RMap
          ref={mapRef}
          style={{
            width: "100%",
            minHeight: "400px",
            height: "100%",
            backgroundColor: showBaseMap ? "transparent" : "white"
          }}
          mapStyle={
            showBaseMap
              ? createGoogleStyle("google", "roadmap", "AIzaSyBiurjht6cC9wpq3EbU9TIMNxE9cGiafqQ")
              : {
                  version: 8,
                  sources: {},
                  layers: [],
                  glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf"
                }
          }
          initialCenter={INITIAL_CENTER}
          initialZoom={16}
          initialAttributionControl={false}
          initialBearing={INITIAL_BEARING}
          initialPitch={0}
          dragRotate={false}
          touchZoomRotate={false}
          initialCanvasContextAttributes={{
              antialias: true,
            }}
        >
         
            <GeoJsonLayer
                id="ContainerYard"
                data={ContainerYard}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                    "fill-outline-color": "#5f5f5f",
                    "fill-color": "#5f5f5f",
                    "fill-opacity": 0.1
                }}
            />
          <GeoJsonLayer
                id="Road"
                data={Road}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={{
                    "line-color": [
                        "match",
                        ["get", "LAYER"],
                        "Centerline", "transparent",
                        "Service Lane", "transparent",
                        "centre line truck traffic", "transparent",
                        "#c2d1fa"
                    ],
                    "line-width": 1,
                    
                }}
                filter={["in", ["get", "LAYER"], ["literal", ["MA_ROAD MARKING", "MA_ROAD"]]]}
                beforeId="ContainerYard-layer"
            />
         
          <DividerLayer />
          <GeoJsonLayer
            id="TruckTraffic"
            data={TruckTraffic}
            minzoom={INITIAL_MIN_ZOOM}
            maxzoom={INITIAL_MAX_ZOOM}
            type="fill"
            paint={{
              "fill-color": "#5f5f5f",
              "fill-opacity": 0.1
            }}
             beforeId="Road-layer"
          
          />
            
         <GeoJsonLayer
                id="ContainerYardLabel"
                data={ContainerYardCentroids}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                    "text-size": 14,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "ID"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always"
                    
                }}
                paint={{
                    "text-color": "#000000",
                }}
                beforeId="ContainerYard-layer"
            />
         
          
           <QuayCrane />
          <YardCranesLayer  yardCranes ={YardCranes}  />
        
         {/* <GeoJsonLayer
      id="itv-layer"
      data={IVTGEOJSON}
      minzoom={INITIAL_MIN_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      type="symbol"
      layout={iconLayout}
      paint={{}}
      onClick={(e) => handleClick(e, e.features?.[0]?.properties)}
    /> */}

    {items && items.map((item,index) => {
                  const markerSize = getMarkerSize(mapZoom);
                 const image =ITV;
                 const rotation = 0;
    
                  return (
                    <EnhancedAnimatedMarker
                      key={`${item.asset}-${index}`}
                      equipmentId={index}
                      image={image}
                      rotation={rotation}
                      size={markerSize}
                      targetLat={item.latitude}
                      targetLng={item.longitude}
                      onClick={(e) => handleClick(e, item)}
                    />
                  );
                })}
{popupInfo && (
        <RPopup
          longitude={popupInfo.longitude}
          latitude={popupInfo.latitude}
          offset={gradientMarkerPopupOffset}
          className="opacity-75 color-black font-bolder"
         
        >
           <button
            className="maplibregl-popup-close-button text-lg font-bold w-5 !right-5"
            onClick={clearPopupInfo}
          >
            ×
          </button>
          <div style={{ fontSize: "14px" }}>
            <div><strong>Equipment Name:</strong> {popupInfo.properties.equipmentName}</div>
            <div><strong>Ignition:</strong> {popupInfo.properties.ignition}</div>
            <div><strong>Operational State:</strong> {popupInfo.properties.operationalState}</div>
            <div><strong>GPS Time:</strong> {popupInfo.properties.gpsTime}</div>
          </div>
        </RPopup>
      )}
     
        </RMap>
      </div>
    </RMapContextProvider>
  );
}
