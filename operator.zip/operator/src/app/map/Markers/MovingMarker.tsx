import { RMarker } from "maplibre-react-components";
import { useUltraSmooth } from "./hooks";

export default function MovingMarker({
  nextLocation, // [lng, lat] prop you pass in
  duration = 1000, // how long (ms) each move should take
}: {
  nextLocation: [number, number];
  duration?: number;
}) {
  const [lng, lat] = useUltraSmooth(nextLocation, duration);

  return (
    <RMarker longitude={lng} latitude={lat} rotation={0} draggable={false} />
  );
}
