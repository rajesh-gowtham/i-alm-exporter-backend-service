import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Types
type LocationData = {
  name: string;
  description: string;
  latitude: number;
  longitude: number;
};

// Form validation schema
const locationSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  latitude: z.number(),
  longitude: z.number(),
});
type LocationFormValues = z.infer<typeof locationSchema>;

interface LocationFormProps {
  selectedPoint: { lat: number; lng: number } | null;
  onSave: (data: LocationData) => void;
  isSaving: boolean;
  onClose: () => void;
}

const LocationForm: React.FC<LocationFormProps> = ({ selectedPoint, onSave, isSaving, onClose }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<LocationFormValues>({
    resolver: zodResolver(locationSchema),
    defaultValues: selectedPoint ? { latitude: selectedPoint.lat, longitude: selectedPoint.lng } : undefined,
  });

  const onSubmit = (data: LocationFormValues) => {
    if (selectedPoint) {
      onSave({ ...data, latitude: selectedPoint.lat, longitude: selectedPoint.lng });
      reset();
      onClose();
    }
  };

  return (
    <div className="absolute p-6 text-white bg-black rounded-lg shadow-lg top-14 left-10 bg-opacity-70 backdrop-blur-lg w-80">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Add Location</h3>
        <button onClick={onClose} className="text-xl text-gray-300 hover:text-white">✖</button>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3 mt-3">
        <input {...register("name")} placeholder="Name" className="w-full px-3 py-2 text-black rounded-md" />
        {errors.name && <p className="text-sm text-red-400">{errors.name.message}</p>}
        <input {...register("description")} placeholder="Description" className="w-full px-3 py-2 text-black rounded-md" />
        {errors.description && <p className="text-sm text-red-400">{errors.description.message}</p>}
        <button type="submit" disabled={isSaving} className={`w-full py-2 rounded-md text-white flex justify-center items-center ${isSaving ? "bg-gray-500 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"}`}>
          {isSaving ? <span className="mr-2 animate-spin">🔄</span> : null}
          {isSaving ? "Saving..." : "Submit"}
        </button>
      </form>
    </div>
  );
};

export default LocationForm;