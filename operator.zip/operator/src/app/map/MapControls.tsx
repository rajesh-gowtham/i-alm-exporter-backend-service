import React from "react";
import {
  RNavigationControl,
  RFullscreenControl,
  RScaleControl,
  RAttributionControl,
} from "maplibre-react-components";
import { FiHome } from "react-icons/fi";

interface MapControlsProps {
  onResetView: () => void;
}

const MapControls: React.FC<MapControlsProps> = ({ onResetView }) => {
  return (
    <>
      <RNavigationControl showCompass={false} showZoom />
      <RFullscreenControl />
      <div className="absolute rounded border-2 border-gray-300  top-[110px] right-2 z-10">
        <button onClick={onResetView} className="block p-1 text-gray-600 bg-white rounded-md shadow-md hover:bg-gray-100" title="Reset">
          <FiHome size={18} />
        </button>
      </div>
      <RScaleControl position="bottom-right" unit="imperial" />
      <RAttributionControl position="bottom-left" customAttribution="IGO RTLS" />
    </>
  );
};

export default MapControls;