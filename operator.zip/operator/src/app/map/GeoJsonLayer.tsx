import React from "react";
import { RLayer, RSource } from "maplibre-react-components";
import { FeatureCollection } from "geojson";
import { FilterSpecification } from "maplibre-gl";
import { number } from "zod";

interface GeoJsonLayerProps {
  id: string;
  data: FeatureCollection;
  minzoom: number;
  maxzoom: number;
  type: "fill" | "line" | "circle" | "symbol";
  paint?: Record<string, any>;
  layout?: Record<string, any>;
  onClick?: (e: any) => void;
  onHover?: (e: any) => void;
  filter?: FilterSpecification;
  beforeId?: string;

}

const GeoJsonLayer: React.FC<GeoJsonLayerProps> = ({ id, data, minzoom, maxzoom, type, paint, layout, onClick, filter, onHover, beforeId }) => {
  return (
    <>
      <RSource id={id} type="geojson" data={data} />
      <RLayer 
        id={`${id}-layer`} 
        type={type} 
        source={id} 
        paint={paint} 
        layout={layout ? layout : {}} 
        minzoom={minzoom} 
        maxzoom={maxzoom} 
        onClick={onClick}
        onMouseOver={onHover}
        filter={filter || ["none"]} 
        beforeId={beforeId}
      />
      {layout?.["text-field"] && (
        <RLayer 
          id={`${id}-labels`} 
          type="symbol" 
          source={id} 
          layout={layout} 
          paint={paint} 
          minzoom={minzoom} 
          maxzoom={maxzoom} 
          onClick={onClick} 
          onMouseOver={onHover}
        filter={filter || ["none"]} 
        beforeId={beforeId}
        />
      )}
    </>
  );
};

export default GeoJsonLayer;