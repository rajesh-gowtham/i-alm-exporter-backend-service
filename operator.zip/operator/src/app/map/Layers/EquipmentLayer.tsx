// EquipmentLayer.tsx
import React from "react";
import GeoJsonLayer from "../GeoJsonLayer";
import { iconLayout, INITIAL_ZOOM, INITIAL_MAX_ZOOM } from "../MapConstants";

function EquipmentLayer({ data }) {
  return (
    <GeoJsonLayer
      id="itv-layers"
      data={data}
      minzoom={INITIAL_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      type="symbol"
      layout={iconLayout}
      paint={{}}
    />
  );
}

export default React.memo(EquipmentLayer);
