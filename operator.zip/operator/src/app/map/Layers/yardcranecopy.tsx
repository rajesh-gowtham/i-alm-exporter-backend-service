/* import { useState, useRef, useEffect } from "react";
import GeoJsonLayer from "../GeoJsonLayer";
import ContainerCenereLine from "@/data/geojsonnew/centerline_yard.json"
import { INITIAL_MIN_ZOOM, INITIAL_MAX_ZOOM, INITIAL_ZOOM } from "../MapConstants";
import { snapPointsToLine } from "../MapUtils";
import * as turf from '@turf/turf';


const CRANE_CONFIGURATIONS = {
  DOUBLE_SIDED_YARDS: ['1D', '2D', '3D', '1E', '2E', '3E'],
  ROTATED_YARDS: {
    '1A': 179.5, '1C': 179.5, '2A': 179.5,
    '2C': 179.5, '3A': 179.5, '3C': 179.5
  },
  OFFSET_YARDS: {
    GROUP1: ['1A', '1C', '2A', '2C', '3A', '3C'],
    GROUP2: ['1B', '2B', '3B']
  }
};

const ZOOM_SCALE = [
  { zoom: 16, size: 0.20 },
  { zoom: 17, size: 0.33 },
  { zoom: 18, size: 0.75 },
  { zoom: 19, size: 1.55 },
  { zoom: 20, size: 3.03 },
  { zoom: 21, size: 6.3 },
  { zoom: 22, size: 12.5 }
]; 

export default function YardCranesLayer({ YardCranes }) {
  const [animatedFeatures, setAnimatedFeatures] = useState([]);
  const prevFeaturesRef = useRef([]);
  const animationFrame = useRef();

  const SPEED_MPS = 3;

  useEffect(() => {
    if (!YardCranes || YardCranes.length === 0) return;

    const snapped = snapPointsToLine(YardCranes, ContainerCenereLine);

    const startFeatures = prevFeaturesRef.current.length === snapped.length
      ? prevFeaturesRef.current
      : snapped;

    const startCoords = startFeatures.map(f => turf.point(f.geometry.coordinates));
    const endCoords = snapped.map(f => turf.point(f.geometry.coordinates));
    const distances = startCoords.map((start, i) => turf.distance(start, endCoords[i])); // in km
    const maxDistance = Math.max(...distances); // to base duration
    const durationMs = (maxDistance * 1000) / SPEED_MPS * 1000; // sec to ms

    const startTime = performance.now();

    function animate(now) {
      const elapsed = now - startTime;
      const t = Math.min(elapsed / durationMs, 1);

      const interpolated = snapped.map((endFeature, i) => {
        const start = startCoords[i];
        const end = endCoords[i];
        const totalDistance = distances[i];

        const interpolatedPoint = turf.along(
          turf.lineString([start.geometry.coordinates, end.geometry.coordinates]),
          totalDistance * t
        );

        return {
          ...endFeature,
          geometry: {
            type: "Point",
            coordinates: interpolatedPoint.geometry.coordinates
          }
        };
      });

      setAnimatedFeatures(interpolated);

      if (t < 1) {
        animationFrame.current = requestAnimationFrame(animate);
      } else {
        prevFeaturesRef.current = snapped;
      }
    }

    cancelAnimationFrame(animationFrame.current);
    animationFrame.current = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame.current);
  }, [YardCranes]);

  return (
    <>
      <GeoJsonLayer
        id="craneCenterLine"
        data={ContainerCenereLine}
        minzoom={INITIAL_MIN_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="line"
         paint={{ "line-color": "#c0d1f7", "line-width": 3 }}
        layout={{ visibility: "none" }}
        beforeId="yard-cranes-layer-layer"
      />
      <GeoJsonLayer
        id="yard-cranes-layer"
        data={{
          type: 'FeatureCollection',
          features: animatedFeatures
        }}
        minzoom={INITIAL_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="symbol"
        layout={{
          'icon-image': ['match', ['get', 'yardNo'], 
            ...CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.flatMap(yard => [yard, 'double-side-yard-crane']),
            'single-side-yard-crane'
          ],
          'icon-rotate': ['match', ['get', 'yardNo'],
            ...Object.entries(CRANE_CONFIGURATIONS.ROTATED_YARDS).flat(),
            -0.5
          ],
          'icon-size': ['interpolate', ['linear'], ['zoom'],
            ...ZOOM_SCALE.flatMap(({ zoom, size }) => [zoom, size])
          ],
          'icon-offset': ['match', ['get', 'yardNo'],
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.map(yard => [yard, ['literal', [0, 10]]]).flat(),
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.map(yard => [yard, ['literal', [0, 7]]]).flat(),
            ['literal', [0, 0]]
          ],
          'icon-allow-overlap': true,
          
          'icon-anchor': 'center',
        }}
        paint={{}}
        beforeId="Quay-cranes-layer"
      />
    </>
  );
}
*/

import { useEffect, useRef, useState } from "react";
import * as turf from "@turf/turf";
import ContainerCenereLine from "@/data/geojsonnew/centerline_yard.json";
import YardCranesRoute from "@/data/geojsonnew/Ycrane_point_route.json";
import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, INITIAL_ZOOM } from "../MapConstants";

// Crane Type
type Crane = {
  id: string;
  yard: string;
  longitude: number;
  latitude: number;
};

type SnappedFeatureProperties = {
  id: string;
  yardNo: string;
  originalLongitude: number;
  originalLatitude: number;
};

// Crane Config
const CRANE_CONFIGURATIONS = {
  DOUBLE_SIDED_YARDS: ['1D', '2D', '3D', '1E', '2E', '3E'],
  ROTATED_YARDS: {
    '1A': 179.5, '1C': 179.5, '2A': 179.5,
    '2C': 179.5, '3A': 179.5, '3C': 179.5
  },
  OFFSET_YARDS: {
    GROUP1: ['1A', '1C', '2A', '2C', '3A', '3C'],
    GROUP2: ['1B', '2B', '3B']
  }
};

// Zoom scale
const ZOOM_SCALE = [
  { zoom: 16, size: 0.20 },
  { zoom: 17, size: 0.33 },
  { zoom: 18, size: 0.75 },
  { zoom: 19, size: 1.55 },
  { zoom: 20, size: 3.03 },
  { zoom: 21, size: 6.3 },
  { zoom: 22, size: 12.5 }
];

// Animate function
function animateCraneMovement(
  start: [number, number],
  end: [number, number],
  duration: number,
  onUpdate: (coords: [number, number]) => void,
  onComplete?: () => void
) {
  const startTime = performance.now();
  const routeLine = turf.lineString([start, end]);
  const totalDistance = turf.length(routeLine, { units: 'meters' });

  function step(now: number) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const distanceAlong = progress * totalDistance;
    const currentPoint = turf.along(routeLine, distanceAlong, { units: 'meters' });
    onUpdate(currentPoint.geometry.coordinates as [number, number]);

    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      onComplete?.();
    }
  }

  requestAnimationFrame(step);
}

// Snap cranes
function snapPointsToLine(
  points: Crane[],
  line: turf.Feature<turf.LineString> | turf.LineString,
  options: turf.NearestPointOnLineOptions = { units: 'meters' }
): turf.Feature<turf.Point, SnappedFeatureProperties>[] {
  return points.map((point) => {
    const targetPoint = turf.point([point.longitude, point.latitude]);
    const snapped = turf.nearestPointOnLine(line, targetPoint, options);

    return {
      type: 'Feature',
      geometry: snapped.geometry,
      properties: {
        id: point.id,
        originalLongitude: point.longitude,
        originalLatitude: point.latitude,
        yardNo: point.yard,
      },
    };
  });
}

export default function YardCranesLayer() {
  const initialCranes: Crane[] = [
    { id: 'CRMG-E01', yard: "1E", longitude: 76.9970, latitude: 8.3727 },
    { id: 'CRMG-E02', yard: "1E", longitude: 76.9961, latitude: 8.3738 },
    { id: 'CRMG-E03', yard: "2E", longitude: 76.9982, latitude: 8.3712 },
    { id: 'CRMG-E04', yard: "2E", longitude: 76.9988, latitude: 8.3705 },
    { id: 'CRMG-E05', yard: "3E", longitude: 76.9995, latitude: 8.3696 },
    { id: 'CRMG-E06', yard: "3E", longitude: 77.0008, latitude: 8.3680 }
  ];

  const [cranes, setCranes] = useState<Crane[]>(initialCranes);
  const craneRef = useRef<Crane | null>(initialCranes[0]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Keep ref updated with latest crane position
  useEffect(() => {
    const current = cranes.find(c => c.id === 'CRMG-E01');
    if (current) craneRef.current = current;
  }, [cranes]);

  // Animate CRMG-E01 every minute
  useEffect(() => {
    const routeCoords = YardCranesRoute.features.map(f => f.geometry.coordinates);
    if (!Array.isArray(routeCoords) || routeCoords.length === 0) return;

    intervalRef.current = setInterval(() => {
  const randomCoord: [number, number] = routeCoords[Math.floor(Math.random() * routeCoords.length)];

  const currentCrane = craneRef.current;
  if (!currentCrane) return;

  const start: [number, number] = [currentCrane.longitude, currentCrane.latitude];
  const end: [number, number] = [randomCoord[0], randomCoord[1]];

  const route = turf.lineString([start, end]);
  const distance = turf.length(route, { units: 'meters' });

  const duration = (distance / 1.3) * 1000; // 6.5m per 5s = 1.3 m/s

  console.log(`[SIM] Animating CRMG-E01 from ${start} to ${end} over ${duration.toFixed(0)}ms (${distance.toFixed(2)} m)`);

  animateCraneMovement(start, end, duration, (coords) => {
    setCranes(prev =>
      prev.map(c =>
        c.id === 'CRMG-E01'
          ? { ...c, longitude: coords[0], latitude: coords[1] }
          : c
      )
    );
  });
}, 5000); // Every 1 minute

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const snappedCranes = snapPointsToLine(cranes, ContainerCenereLine);

  return (
    <>
      <GeoJsonLayer
        id="craneCenterLine"
        data={ContainerCenereLine}
        minzoom={INITIAL_MIN_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="line"
        paint={{ "line-color": "#c0d1f7", "line-width": 3 }}
        layout={{ "visibility": "none" }}
        beforeId="yard-cranes-layer-layer"
      />
      <GeoJsonLayer
        id="yard-cranes-layer"
        data={{
          type: 'FeatureCollection',
          features: snappedCranes
        }}
        minzoom={INITIAL_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="symbol"
        layout={{
          'icon-image': ['match', ['get', 'yardNo'],
            ...CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.flatMap(yard => [yard, 'double-side-yard-crane']),
            'single-side-yard-crane'
          ],
          'icon-rotate': ['match', ['get', 'yardNo'],
            ...Object.entries(CRANE_CONFIGURATIONS.ROTATED_YARDS).flat(),
            -0.5
          ],
          'icon-size': [
            'interpolate', ['linear'], ['zoom'],
            ...ZOOM_SCALE.flatMap(({ zoom, size }) => [zoom, size])
          ],
          'icon-offset': ['match', ['get', 'yardNo'],
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.map(yard => [yard, ['literal', [0, 10]]]).flat(),
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.map(yard => [yard, ['literal', [0, 7]]]).flat(),
            ['literal', [0, 0]]
          ],
          'icon-allow-overlap': true,
          'icon-ignore-placement': true,
          'icon-anchor': 'center',
        }}
        paint={{}}
        beforeId="Quay-cranes-layer"
      />
    </>
  );
}

