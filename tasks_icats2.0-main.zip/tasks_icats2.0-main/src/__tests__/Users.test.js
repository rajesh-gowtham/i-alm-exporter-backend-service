import React from "react";
import UserDetail from "../Components/Users/UserDetail";
import { shallow, configure } from "enzyme";
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

describe('User module', () => {
    it('renders checking', () => {
        const wrapper = shallow(<UserDetail />);
        expect(wrapper.exists()).toBe(true);
    });

    // it('', () => {
    //     const wrapper = shallow(<UserDetail />);
    //     const instance = wrapper.instance();

    //     instance.GetAllUserByOrg()
    // })
})