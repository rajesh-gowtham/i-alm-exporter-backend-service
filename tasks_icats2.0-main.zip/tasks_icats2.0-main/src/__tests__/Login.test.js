import React from 'react';
import Login from '../Components/Login/Login';
import { shallow, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

// Configure Enzyme adapter
configure({ adapter: new Adapter() });

describe('onLogin Function', () => {
  it('should set local store and fetch organization details for valid user', async () => {

    const wrapper = shallow(<Login />);
    const instance = wrapper.instance();

    const email = 'nagarasu.v@igosolutions.eu';
    const password = 'Admin@123'
    let e = { preventDefault: () => { }, target: {} }
    e.target = { name: 'email', value: email },
      instance.handleChange(e)
    e.target = { name: 'password', value: password },
      instance.handleChange(e)

    // Trigger the function
    await instance.onLogin(new MouseEvent('click'));

    // Verify local store is set and organization details are fetched
    expect(localStorage.getItem('LoginUserName')).toEqual('Nagarasu V');

  });
});
