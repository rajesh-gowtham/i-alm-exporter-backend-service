import React from 'react'
import { Link } from 'react-router-dom';
//SCREEN ID -3030
class ErrorBoundary extends React.Component {
    constructor(props) {
      super(props);
      this.state = { hasError: false, error: '', info: '', stack: '' }
    }
  
    static getDerivedStateFromError(error) {
      // Update state so the next render will show the fallback UI.
      return { hasError: true };
    }
  
    // added by Mubarak -12-04-2023  
    // componentDidCatch(error, errorInfo) {
    //   // You can also log the error to an error reporting service
    //   // logErrorToMyService(error, errorInfo)
    //   this.setState({error, info: errorInfo, stack: error.stack})
    //  // console.log("error"+JSON.stringify(error))
    //   console.log("errorInfo"+JSON.stringify(errorInfo))
    // }
  
    render() {
      if (this.state.hasError) {
        // You can render any custom fallback UI
        return    <div>
                        
        {/* <div class="bg-gradient-to-r from-purple-300 to-blue-200">

          <div class="w-9/12 m-auto py-16 min-h-screen flex items-center justify-center">
            <div class="bg-white shadow overflow-hidden sm:rounded-lg pb-8">
              <div class="border-t border-gray-200 text-center pt-8">

                <h1 class="text-9xl font-bold text-blue-800"><span class="text-orange-500">4</span>01</h1>
                <h1 class="text-6xl font-medium py-8"><span class="text-orange-600">Unauthorized!</span> Authentication failed</h1>
                <p class="text-2xl pb-8 px-12 font-medium">Make sure that you have registered an account with the service you are trying to connect to. If you do not have an account, most services will not allow you to connect.</p>
                <a href='/login'>
                  <button class='px-6 py-2.5 bg-[#089de3] text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out' >
                   Login
                  </button>
                  </a>
                <button class='px-6  py-2.5  bg-[#F6AE2D]  text-white  font-medium  text-xs  leading-tight  uppercase  rounded shadow-md  hover:bg-red-500 hover:shadow-lg focus:bg-red-500 focus:shadow-lg focus:outline-none focus:ring-0  active:bg-red-500 active:shadow-lg  transition  duration-150  ease-in-out  ml-1'>
                  Contact Us
                </button>
              </div>
            </div>
          </div>
          <p class="text-2xl pb-8 text-red-500 px-12 font-medium">{JSON.stringify(this.state.info)}.</p>
        </div> */}

      </div>;
      }
  
      return this.props.children; 
    }
}

export default ErrorBoundary