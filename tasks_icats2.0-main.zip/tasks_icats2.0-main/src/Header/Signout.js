import React, { useState, useEffect } from "react";
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../CSS/Model.css';
import { getControlsConstants } from "../CommonUtils/getlocalizeData";
import userimg from '../Images/userImg.png';
import { capitalizeString } from "../CommonUtils/getLocalizeFunction";
import { deleteUser, signOut } from "firebase/auth";
import { auth } from '../firebase/firebase';
const localControlsConstant = getControlsConstants();
//SCREEN ID -3075
const Signout = () => {

    const [isSIgnout, setIsSignout] = useState(false);
    const [Organization, setOrg] = useState('');
    useEffect(() => {
        //GetOrgNamebyID
        setOrg(window.localStorage.getItem("OrganizationName"));
    }, []);
    const LogOffYes = () => {
        window.localStorage.removeItem('uid')
        window.localStorage.removeItem('useremail')
        window.localStorage.removeItem('stsTokenManager')
        window.localStorage.removeItem('lastLoginAt')
        window.localStorage.removeItem('MasterBizUitKey')
        window.localStorage.removeItem('OrganizationName')
        window.localStorage.removeItem('Auth Token')
        window.localStorage.removeItem('user Details')
        window.localStorage.removeItem('LoginUserName')
        window.localStorage.removeItem('navpath')
        window.localStorage.removeItem('RoleName');
        window.localStorage.removeItem('RoleGkey');
        window.localStorage.removeItem('expirationTime');
        
        signOut(auth).then(() => {
            //  signOut(auth);
            window.location = '/';
        }).catch((error) => {
            // An error happened.
        });
    }
    const handleSignout = () => {
        setIsSignout(true);
    }
    const handleClose = () => {
        setIsSignout(false);
    }

    return (
        <div class="absolute z-50 right-[40px] top-[60px] w-[200px] h-[100px] text-black">
            <div class="bg-white rounded overflow-hidden shadow-lg">
                <div>
                    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
                    <div >
                        <div class="text-sm pl-2">
                            <div class="relative border-b-2 border-transparent py-3" >
                                <div class="flex justify-center items-center space-x-3 cursor-pointer">
                                    <div class="w-12 h-12 rounded-full p-2 bg-[#ebeef6] overflow-hidden border-2 border-gray-500">
                                        <img src={userimg} alt='user' />
                                    </div>
                                    <div class=" dark:text-white text-gray-900 text-sm">
                                        <div class="cursor-pointer">{capitalizeString(window.localStorage.getItem("RoleName"))}</div>
                                    </div>
                                </div>
                                <div >
                                    <ul class="space-y-3 dark:text-white">
                                        <li>
                                            <div class="flex  transform transition-colors duration-200 border-r-4 border-transparent hover:border-indigo-700">
                                                <div class=" mt-1 text-[#089de3] text-xs ">
                                                    Organization:<span class="text-black">{Organization}</span>
                                                </div>
                                            </div>
                                        </li>
                                        <hr class="dark:border-gray-700" />
                                        <li class="font-sm cursor-pointer">
                                            <div class="flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-indigo-700">
                                                <div class="mr-3">
                                                    <svg class="w-[20px] h-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                                </div>
                                                Manage Account
                                            </div>
                                        </li>
                                        <li class="font-sm cursor-pointer" onClick={handleSignout}>
                                            <div class="flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-red-600">
                                                <div class="mr-3 text-red-600">
                                                    <svg class="w-[20px] h-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                                                </div>
                                                Logout
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    {isSIgnout == true &&
                        <div class="max-lg:p-10">
                            <ReactDialogBox
                                closeBox={handleClose}
                                modalWidth={localControlsConstant.Model.modalWidth}
                                headerBackgroundColor={localControlsConstant.Model.headerbg}
                                headerTextColor={localControlsConstant.Model.bodybg}
                                headerHeight={localControlsConstant.Model.headerheight}
                                closeButtonColor={localControlsConstant.Model.closebtncolor}
                                bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                headerText={localControlsConstant.Model.modelConfirm}
                            >
                                <div>
                                    <div class='flex items-center h-16 pl-7 max-lg:h-8 max-lg:pl-2'>
                                        <h1>Are you sure you want to logout?</h1>
                                    </div>
                                    <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                                        <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                            onClick={LogOffYes} >Yes</button>
                                        <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                            onClick={handleClose}>Cancel
                                        </button>
                                    </div>

                                </div>
                            </ReactDialogBox>
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}

export default Signout;