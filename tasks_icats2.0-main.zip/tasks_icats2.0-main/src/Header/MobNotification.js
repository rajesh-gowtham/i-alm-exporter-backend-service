import React, { useState, useEffect } from "react";
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../CSS/Model.css';
import { getControlsConstants } from "../CommonUtils/getlocalizeData";
import userimg from '../Images/userImg.png';
import { capitalizeString } from "../CommonUtils/getLocalizeFunction";
import { BsCheckAll } from 'react-icons/bs';
const localControlsConstant = getControlsConstants();
//SCREEN ID -3075
const MobNotification = (props) => {
  const [isOpen, setIsOpen] = React.useState(true)
  const [Org, setOrg] = React.useState()

  return (
    <div>
      <div class="relative z-10" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
        <div class="fixed inset-0 overflow-hidden">
          <div class="absolute inset-0 overflow-hidden">
            <div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <div class="pointer-events-auto w-screen max-w-md">
                <div class="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
                  <div class="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
                    <div class="flex items-start justify-between">
                      <h2 class="text-lg font-medium text-gray-900" id="slide-over-title">Notification</h2>
                      <div class="ml-3 flex h-7 items-center">
                        <button type="button" class="-m-2 p-2 text-gray-400 hover:text-gray-500" onClick={props.Onchange_Notication}>
                          <span class="sr-only">Close panel</span>
                          <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div class="mt-4">
                      <div class="flow-root">
                        <div>
                          <div >
                          </div>
                          <div className="notifications">
                            <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>
                            <span>
                              <div class="pb-5px">message received from Mr.Ramakrishnan</div>
                              <div class="text-[10px]">10 mins ago</div>
                            </span>
                          </div>
                          <div className="notifications">
                            <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>

                            <span>
                              <div class="pb-5px">message received from Mr.Ravikumar</div>
                              <div class="text-[10px]">35 mins ago</div>
                            </span>
                          </div>
                          <div className="notifications">
                            <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>
                            <span>
                              <div class="pb-5px">message received from Ms.Renuka</div>
                              <div class="text-[10px]">1hr and 10mins ago</div>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="border-t border-gray-200 px-4 py-6 sm:px-6">
                    <div class="flex justify-between text-base font-medium text-gray-900">
                      <span class="flex items-center cursor-pointer"><BsCheckAll color="#a5eb9d" size={18} fill="green" /><span>Mark all as read</span></span>
                    </div>
                    <div class="flex mt-6 text-mob-txt-md justify-center">
                      <p>Last Updted At:10.20</p>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MobNotification;