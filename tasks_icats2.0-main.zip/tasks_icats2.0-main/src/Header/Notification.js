import React from "react";
import { BsCheckAll } from 'react-icons/bs';
//SCREEN ID -3074
const Notification = () => {
    return (
        <div className="notification-box ">
            <div className="notification-head">
                <span>Notifications</span>
                <span class="flex items-center cursor-pointer"><BsCheckAll color="#a5eb9d" size={18} /><span>Mark all as read</span></span>
            </div>
            <div className="notifications">
                <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>
                <span>
                    <div class="pb-5px">message received from Mr.Ramakrishnan</div>
                    <div class="text-[10px]">10 mins ago</div>
                </span>
            </div>
            <div className="notifications">
                <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>

                <span>
                    <div class="pb-5px">message received from Mr.Ravikumar</div>
                    <div class="text-[10px]">35 mins ago</div>
                </span>
            </div>
            <div className="notifications">
                <span><img src="https://cdn-icons-png.flaticon.com/512/552/552486.png" alt="senderimg" /> </span>
                <span>
                    <div class="pb-5px">message received from Ms.Renuka</div>
                    <div class="text-[10px]">1hr and 10mins ago</div>
                </span>
            </div>
            <div className="showall">view all notifications</div>
        </div>
    )
}

export default Notification;