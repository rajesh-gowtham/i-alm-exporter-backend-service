import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = window.localStorage.getItem("Auth Token");
//SCREEN ID -3032
class OrganizationService {
  GetAllOrg() {
    console.log(baseAPIURL + "GetAllOrg" + "/token/" + userToken);
    return axios.get(baseAPIURL + "GetAllOrg" + "/token/" + userToken)
  }
  GetOrgIDByName(Name) {
    console.log(baseAPIURL + "GetOrgIDbyName/Name/CTS" + "/token/" + userToken);
    return axios.get(baseAPIURL + "GetOrgIDbyName/Name/" + Name + "/token/" + userToken)
  }
  GetOrgIDByEmail(email) {
    console.log(baseAPIURL + "GetOrgByEmail/email/" + "/token/" + userToken);
    return axios.get(baseAPIURL + "GetOrgByEmail/email/" + email + "/token/" + userToken)
  }
  GetOrgNamebyID(Name) {
    console.log(baseAPIURL + "GetOrgNamebyID/ID/" + "/token/" + userToken);
    return axios.get(baseAPIURL + "GetOrgNamebyID/ID/" + Name + "/token/" + userToken)
  }

  GetOrgDetailsbyEmail(email) {
    console.log(baseAPIURL + "GetOrgDetailsByEmail/email/" + "/token/" + userToken);
    return axios.get(baseAPIURL + "GetOrgDetailsByEmail/email/" + email + "/token/" + userToken)
  }

}
export default new OrganizationService();