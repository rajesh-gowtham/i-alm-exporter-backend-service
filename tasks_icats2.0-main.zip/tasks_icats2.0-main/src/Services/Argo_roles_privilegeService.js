import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3031
class Argo_roles_privilegeService {
  CreateManyPrivilegeByRole(PrivilegeData) {
    console.log("PrivilegeData IS:" + JSON.stringify(PrivilegeData))
    return axios.post(baseAPIURL + "SetPrivilageToRole/", {
      content: PrivilegeData,
      submittedBy: userdetaile
    });
  }
  
  GetPrivilageToRole() {
    return axios.get(baseAPIURL + "GetPrivilageToRole/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }


  //add by nagarasu --> Updated By Rajesh 05-07-23 For Remove allprevileges By Role's Gkey
  DeletPrivilageToRoleByGkey(RoleGkey) {
    return axios.delete(baseAPIURL + "DeletPrivilageToRoleByGkey/RoleGkey/" + RoleGkey + "/token/" + userToken)
  }
  
  // //add by nagarasu
  // DeletPrivilageToRoleByName(RoleName) {
  //   console.log('DeletPrivilageToRoleByName',RoleName)
  //   // DeletPrivilageToRoleByName/RoleName/:RoleName/token/:token
  //   return axios.delete(baseAPIURL + "DeletPrivilageToRoleByName/RoleName/" + RoleName + "/token/" + userToken)
  // }

}
export default new Argo_roles_privilegeService();