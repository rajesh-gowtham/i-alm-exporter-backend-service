import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3033
class PrivilageService {
  BulkPrivilageInsert(PrivilageData) {
    console.log("roledetails" + JSON.stringify(PrivilageData))
    return axios.post(baseAPIURL + "CreateBulkprivilegesByOrg/", {
      content: PrivilageData,
      submittedBy: userdetaile
    });
  }
  GetAllPrivilages() {
    return axios.get(baseAPIURL + "GetprivilegesbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }
  UpdatePrivilegesbyGkey(privilegeData) {
    console.log(privilegeData)
    return axios.put(baseAPIURL + "UpdatePrivilegesbyGkey/", {
      content: privilegeData,
      submittedBy: userdetaile
    });
  }
  // Added By Mubarak 25-04-2023
  UpdateprivilegesStatusByGkey(privilegeData) {
    console.log(privilegeData)
    //status,gkey JSON 
    return axios.put(baseAPIURL + "UpdateprivilegesStatusByGkey/", {
      content: privilegeData,
      submittedBy: userdetaile
    });
  }


  UpdateprivilegesNamebyGkey(privilegeData) {
    console.log(privilegeData)
    return axios.put(baseAPIURL + "UpdateprivilegesNamebyGkey/", {
      content: privilegeData,
      submittedBy: userdetaile
    });
  }

}
export default new PrivilageService();