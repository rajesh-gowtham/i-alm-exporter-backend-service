import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3035
class Argo_Users_roles_detailsService {

  GetRoleDetailsByUserGkey(gkey) {
    return axios.get(baseAPIURL + "GetRoleByUser/gkey/" + gkey + "/token/" + userToken)
  }
}
export default new Argo_Users_roles_detailsService();