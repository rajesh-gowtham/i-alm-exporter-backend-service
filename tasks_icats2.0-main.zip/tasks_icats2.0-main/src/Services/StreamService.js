import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3037
class StreamService {
  CreateStreamByOrg(Streamdata) {
    return axios.post(baseAPIURL + "CreateStreamByOrg/", {
      content: Streamdata,
      submittedBy: userdetaile
    });
  }
  UpdateStreamByOrg(Streamdata) {
    return axios.put(baseAPIURL + "UpdateStreamByOrg/", {
      content: Streamdata,
      submittedBy: userdetaile
    });
  }
  getStreamByOrg() {
    const MasterBizUitKey = window.localStorage.getItem("MasterBizUitKey")
    return axios.get(baseAPIURL + "GetStreamDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }
  DeleteStreamByOrg(gkey) {
    return axios.delete(baseAPIURL + "DeleteStream/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new StreamService();