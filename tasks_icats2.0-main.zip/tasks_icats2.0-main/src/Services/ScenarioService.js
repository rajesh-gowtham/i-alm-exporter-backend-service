import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetail = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3036
class ScenarioService {
    CreateScenarioByOrg(Scenariodata) {
        return axios.post(baseAPIURL + "CreatescenarioByOrg/", {
            content: Scenariodata,
            submittedBy: userdetail
        });
    }
    UpdateScenarioByOrg(Scenariodata) {
        console.log('service', JSON.stringify(Scenariodata))
        return axios.put(baseAPIURL + "UpdatescenarioByOrg/", {
            content: Scenariodata,
            submittedBy: userdetail
        });
    }

    GetScenariosByOrg() {
        const MasterBizUitKey = window.localStorage.getItem("MasterBizUitKey")
        return axios.get(baseAPIURL + "GetscenarioDetailsbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
    }

    DeleteScenarioByOrg(gkey) {
        try {
            return axios.delete(baseAPIURL + "Deletescenario/gkey/" + gkey + "/token/" + userToken)
        }
        catch (err) {
            console.log("err", err)
            throw Error(err)
        }
    }

    map_scenario_sequence(data) {
        return axios.post(baseAPIURL + "map_scenario_sequence/", {
            content: data,
            submittedBy: userdetail
        })
    }

    Update_map_scenario_sequence(data){
        console.log('service result', data)
        return axios.put(baseAPIURL + "Update_map_scenario_sequence/", {
            content: data,
            submittedBy: userdetail
        })
    }

    DeletemapScenarioSequence(scenario_key) {
        return axios.delete(baseAPIURL + "DeletemapScenarioSequence/" + scenario_key + "/token/" + userToken)
    }

    Updatemap_autapp_scenarios(data){
        console.log('service result', data)
        return axios.put(baseAPIURL + "Updatemap_autapp_scenarios/", {
            content: data,
            submittedBy: userdetail
        })
    }
    
    map_autapp_scenario(data) {
        return axios.post(baseAPIURL + "map_autapp_scenario/", {
            content: data,
            submittedBy: userdetail
        })
    }

    Deletemap_autapp_scenario(scenario_key){
        console.log('DeletemapScenarioSequence', scenario_key)
        return axios.delete(baseAPIURL + "DeleteMapautappScenario/" + scenario_key + "/token/" + userToken)
    }

}
export default new ScenarioService();