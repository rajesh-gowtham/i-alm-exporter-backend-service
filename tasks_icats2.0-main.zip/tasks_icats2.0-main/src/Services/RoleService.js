import axios from "axios";
import { geAxiosConstants } from "../CommonUtils/getlocalizeData";
const localConstant = geAxiosConstants();
const baseAPIURL = localConstant.AxiosBase.ApiBaseUrl;
const userToken = localConstant.AxiosBase.userToken;
const MasterBizUitKey = localConstant.AxiosBase.MasterBizUitKey;
const userdetaile = localConstant.AxiosBase.userdetaile;
//SCREEN ID -3035
class RoleService {
  CreateRoleByOrg(roledetails) {
    console.log("roledetails" + JSON.stringify(roledetails))
    let temproledetail={
      role:roledetails.role,
      description:roledetails.description,
      MasterBizUitKey:MasterBizUitKey
    }
    return axios.post(baseAPIURL + "CreaterolesByOrg/", {
      content: temproledetail,
      submittedBy: userdetaile
    });
  }

  UpdateRoleByOrg(roledetails) {
    console.log("UpdaterolesByOrg" + JSON.stringify(roledetails))
    return axios.put(baseAPIURL + "UpdaterolesByOrg/", {
      content: roledetails,
      submittedBy: userdetaile
    });
  }
  getRoleByOrg() {
    const MasterBizUitKey = window.localStorage.getItem("MasterBizUitKey")
    return axios.get(baseAPIURL + "GetrolesbyOrg/MasterBizUitKey/" + MasterBizUitKey + "/token/" + userToken)
  }

  DeleteRoleByOrg(gkey) {
    return axios.delete(baseAPIURL + "Deleteroles/gkey/" + gkey + "/token/" + userToken)
  }

}
export default new RoleService();