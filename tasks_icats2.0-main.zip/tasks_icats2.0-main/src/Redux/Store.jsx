import { legacy_createStore as createStore } from 'redux';
import { GetAllPrivilages } from '../CommonUtils/UiltPrivilages';

export const GetPrivilegesByStore = async () => {
    try {
        const { privilagesdata, privilages, modules } = await GetAllPrivilages();
        initailState.allPrivileges = privilagesdata;
        initailState.privilegeRawData = privilages;
        initailState.moduleRawData = modules;
        return privilagesdata;
    } catch (error) {
        console.error(error);
    }
}
const initailState = {
    privilegedata: {
        privilege: {}
    },
    allPrivileges: GetPrivilegesByStore(),//.then(data=>{initailState.allPrivileges= data.privilagesdata}),
    privilegeRawData: {},
    moduleRawData: {},
}

const rootReducer = (state = initailState, action) => {
    switch (action.type) {
        case 'ADD_NEW_ROLE':
            return {
                ...state,
                privilegedata: {
                    ...state.privilegedata,
                    privilege: {
                        ...state.privilegedata.privilege,
                        [action.payload]: [{}]
                    }
                }
            }
        case 'ADD_UPDATE_PRIVILEGES': { console.log("action ", action.payload.role, action.payload.allPrivileges) }
            return {
                ...state,
                privilegedata: {
                    ...state.privilegedata,
                    privilege: {
                        ...state.privilegedata.privilege,
                        [action.payload.role]: action.payload.allPrivileges
                    }
                }
            }
        case 'UPDATE_ROLE': { console.log(action.payload, "action ", action.payload.oldrole, action.payload.newrole, action.payload.allPrivileges) }
            const newState = { ...state };
            const newPrivilege = { ...newState.privilegedata.privilege };
            newPrivilege[action.payload.newrole] = newPrivilege[action.payload.oldrole];
            delete newPrivilege[action.payload.oldrole];
            newState.privilegedata.privilege = newPrivilege;
            return newState;

        case 'DELETE_ROLE':
            const newStates = { ...state };
            delete newStates.privilegedata.privilege[action.payload.role]
            return newStates;

        case 'ADD_ROLE_PRIVILAGE':

            return {
                ...state,
                privilegedata: {
                    ...state.privilegedata,
                    privilege: action.payload
                }
            }
        case 'SET_ALLPRIVILAGE':

            return {
                ...state,
                allPrivileges: action.payload
            }
        default:
            return state;
    }
};
export default createStore(rootReducer)