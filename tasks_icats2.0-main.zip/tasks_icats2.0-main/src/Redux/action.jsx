const ADD_NEW_ROLE = 'ADD_NEW_ROLE';
const ADD_PRIVILEGES = 'ADD_UPDATE_PRIVILEGES';
const UPDATE_ROLE = 'UPDATE_ROLE';
const DELETE_ROLE = 'DELETE_ROLE';
const ADD_ROLE_PRIVILAGE = 'ADD_ROLE_PRIVILAGE';
const SET_ALLPRIVILAGE = 'SET_ALLPRIVILAGE';
export function addNewRole(role) {
   let payload = role;
   return {
      type: ADD_NEW_ROLE,
      payload
   }
};
export function addAndUpdatePrivileges(role, allPrivileges) {
   let payload = { role, allPrivileges };
   return {
      type: ADD_PRIVILEGES,
      payload
   }
};
export function updateRoleByName(oldrole, newrole, allPrivileges) {
   console.log(oldrole, newrole, allPrivileges)
   let payload = { oldrole, newrole, allPrivileges };
   return {
      type: UPDATE_ROLE,
      payload
   }
};
export function deleteRoleByName(role) {
   console.log(role)
   let payload = { role };
   return {
      type: DELETE_ROLE,
      payload
   }
};
export function addRolePrivilage(rolePrivilageData) {
   let payload = rolePrivilageData;
   return {
      type: ADD_ROLE_PRIVILAGE,
      payload
   }
};
export function addAllPrivlages(allPrivileges) {

   let payload = allPrivileges;
   return {
      type: SET_ALLPRIVILAGE,
      payload
   }
};


