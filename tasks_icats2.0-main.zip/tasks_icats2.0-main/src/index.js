import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import ErrorBoundary from './404/ErrorBoundary';
import EditOrder from './Components/__Trent_UploadDocument/FileUplodEncode';

const masterOrderStatusOptions = [
  {"label": "PO Generated", "value": "PO Generated"},
  {"label": "PO Accepted", "value": "PO Accepted"},
  {"label": "PO Rejected", "value": "PO Rejected"},
  {"label": "Cancelled", "value": "Cancelled"},
  {"label": "Completed", "value": "Completed"},
  {"label": "Ready For Shipment", "value": "Ready For Shipment"},
  {"label": "Logistics Confirmed", "value": "Logistics Confirmed"},
  {"label": "In Transit", "value": "In Transit"},
  {"label": "Arrived at Destination", "value": "Arrived at Destination"},
  {"label": "Delivered to Buyer", "value": "Delivered to Buyer"}
]
//SCREEN ID -3047
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
      {/* <EditOrder
      selectedorderRequestNumber={23000001}
      masterOrderStatusOptions={masterOrderStatusOptions} /> */}
    </ErrorBoundary>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
