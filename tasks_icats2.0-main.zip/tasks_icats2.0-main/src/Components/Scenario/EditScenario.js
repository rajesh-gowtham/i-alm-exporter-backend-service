import React from 'react';
import editScenarioicon from '../../Images/editScenarioIcon.svg';
import manageSequenceicon from '../../Images/managesequenceicon.svg';
import manageDataseticon from '../../Images/manageDataset.svg';
import { ManageDataSet, ManageSequence } from './SequenceGrids';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import FormScenario from './FormScenario';


class EditScenario extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            editDataFlag: 'scenario'
        }
    }

    manageData = {
        scenario: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
        manageSequence: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
        manageDataset: {
            image: <img src={editScenarioicon} width='124' height='125' />,
            title: 'Why using scenarios?',
            description: 'Using scenarios helps understand user behavior, identify needs, and inform design. They provide context for designing interfaces, ensuring the final product meets user expectations. Scenarios aid in testing, problem-solving, and creating user-centric solutions by simulating real-life situations.',
        },
    };

    editDataBtn = (flag) => {
        this.setState({ editDataFlag: flag });
    };

    render() {
        const { editDataFlag } = this.state;
        return (

            <div className='px-5 pb-2 pt-[30px]'>
                <div className='h-[120px]  flex  bg-blue-800 bg-opacity-10 rounded-[10px] py-2 px-5 relative'>
                    <div className='w-[30%] flex justify-center'>
                        <div className='absolute -top-3'>
                            {this.manageData[editDataFlag].image}
                        </div>
                    </div>
                    <div className='w-full flex flex-col justify-center space-y-2 px-10'>
                        <h1 className='text-blue-800 text-[22px] font-semibold leading-7'>{this.manageData[editDataFlag].title}</h1>
                        <p className='text-black text-sm font-normal leading-tight'>{this.manageData[editDataFlag].description}</p>
                    </div>
                </div>

                <div className='h-[75%]  flex pt-5 px-5 '>
                    <div className='  w-[30%]'>
                        <div className="flex pl-[30px]">
                            <div className="border-l-2 border-gray-100">
                                <div onClick={() => this.editDataBtn('scenario')} className={`cursor-pointer hover:bg-[#E3EEFF] text-black text-lg font-medium px-[10px] py-[6px] ${this.state.editDataFlag === 'scenario' ? 'border-l-[4px] border-blue-800 text-blue-800 bg-[#E3EEFF]' : 'border-l-[4px] border-transparent'} p-[10px]`}>
                                    Edit Scenario
                                </div>
                                <div className="text-zinc-500 text-base font-light cursor-pointer">
                                    <div onClick={() => this.editDataBtn('manageSequence')} className={`hover:bg-[#E3EEFF] px-[10px] py-[6px] ${this.state.editDataFlag === 'manageSequence' ? 'border-l-[4px] border-blue-800 text-blue-800 font-normal bg-[#E3EEFF]' : 'border-l-[4px] border-transparent'} pl-[25px]`}>
                                        Manage Sequence
                                    </div>
                                    <div onClick={() => this.editDataBtn('manageDataset')} className={`hover:bg-[#E3EEFF] px-[10px] py-[6px] ${this.state.editDataFlag === 'manageDataset' ? 'border-l-[4px] border-blue-800 text-blue-800 font-normal bg-[#E3EEFF]' : 'border-l-[4px] border-transparent'} pl-[25px]`}>
                                        Manage DataSet
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <div className="flex  ">
                            <div className=" border-gray-100 w-full ">
                                <div onClick={() => this.editDataBtn('scenario')} className={`px-2 cursor-pointer hover:bg-[#ebf0f88e  py-[6px] border-b-[1px] ${this.state.editDataFlag === 'scenario' ? ' font-medium bg-[#E3EEFF]' : ' font-normal text-zinc-400 '} `}>
                                    Edit Scenario
                                </div>
                                <div>
                                    <div onClick={() => this.editDataBtn('manageSequence')} className={`hover:bg-[#ebf0f88e] cursor-pointer px-2 py-[6px] border-b-[1px] ${this.state.editDataFlag === 'manageSequence' ? '  font-medium bg-[#E3EEFF]' : ' text-zinc-400 marker:font-normal '} `}>
                                        Manage Sequence
                                    </div>
                                    <div onClick={() => this.editDataBtn('manageDataset')} className={`hover:bg-[#ebf0f88e] cursor-pointer px-2 py-[6px] border-b-[1px] ${this.state.editDataFlag === 'manageDataset' ? '  font-medium bg-[#E3EEFF]' : 'text-zinc-400 font-normal '} `}>
                                        Manage DataSet
                                    </div>
                                </div>
                            </div>
                        </div> */}
                    </div>

                    <div className='px-10 w-full'>
                        {this.state.editDataFlag === 'scenario' &&
                            <div className='w-[80%]'>
                                <FormScenario
                                    onValueOnChange={this.props.onValueOnChange}
                                    records={this.props.records}
                                    errors={this.props.errors}
                                    Header={this.props.modelheader}
                                    streamOptions={this.props.streamOptions}
                                    streamRef={this.props.streamRef}
                                    editScenario_onClick={this.props.editScenario_onClick}
                                    reset_onClick={this.props.reset_onClick}
                                    addScenarioFlag={this.props.addScenarioFlag}
                                />
                                {/* <div className=" flex-[2] modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pb-0 p-4 rounded-b-md space-x-3">
                                    <button type="button" onClick={this.props.editScenario_onClick} className={ControlsConstants.Buttons.btnPrimaryBlue} >Update</button>
                                    <button type="button" onClick={this.props.reset_onClick} className={ControlsConstants.Buttons.btnresetempty}  >Reset</button>
                                </div> */}
                            </div>
                        }

                        {this.state.editDataFlag === 'manageSequence' &&
                            <div className='w-[80%]'>
                                <ManageSequence
                                    allSequenceData={this.props.allSequenceData}
                                    records={this.props.records}
                                    ref={this.props.ref}
                                    applyTo_Options={this.props.applyTo_Options}
                                    manageSequence_onClick={this.props.manageSequence_onClick}
                                    backToScenario_onClick={this.props.backToScenario_onClick}
                                />
                            </div>
                        }
                        {this.state.editDataFlag === 'manageDataset' &&
                            <div className='w-[80%]'>
                                <ManageDataSet
                                    allColumnsData={this.props.allColumnsData}
                                    records={this.props.records}
                                    manageDataset_onClick={this.props.manageDataset_onClick}
                                    backToScenario_onClick={this.props.backToScenario_onClick}
                                />
                            </div>
                        }
                    </div>

                </div>
            </div>
        )
    }
}

export default EditScenario;


