import React from "react";
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localConstants = getlocalizeData();
const localControlsConstant = getControlsConstants();
//SCREEN ID -3005

const FormScenario = (props) => {
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const { records, errors, Header, streamOptions } = props;
    return (
        <div>
            <div class="mt-2">
                <form class="font-[Verdana]">
                    <div class="flex items-center mb-[15px]">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="displayName" class={localControlsConstant.label.label14}>{localConstants.SCENARIO.DISPLAY_NAME}</label>
                        </span>
                        <span class='flex-[2]'>
                            <input
                                class={errors.displayName.length > 0 ? borderRed : borderGrey}
                                type="text"
                                placeholder="Enter display name"
                                name="displayName"
                                value={records.displayName}
                                onChange={props.onValueOnChange}
                            />
                            {errors.displayName.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.displayName}</span>
                            }
                        </span>
                    </div>
                    <div class="flex items-center  mb-[15px]">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="longName" class={localControlsConstant.label.label14}>{localConstants.SCENARIO.LONG_NAME}</label>
                        </span>
                        <span class='flex-[2]'>
                            <input
                                class={errors.longName.length > 0 ? borderRed : borderGrey}
                                type="text"
                                placeholder="Enter long name"
                                name="longName"
                                value={records.longName}
                                onChange={props.onValueOnChange}
                            />
                            {errors.longName.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.longName}</span>
                            }
                        </span>
                    </div>

                    <div class="flex items-center  mb-[15px]">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="Stream_gkey" class={localControlsConstant.label.label14}>{localConstants.SCENARIO.STREAM}</label>
                        </span>
                        <span class='flex-[2]'>
                            <Select
                                name="Stream_gkey"
                                onChange={props.onValueOnChange}
                                options={streamOptions}
                                ref={props.streamRef}
                                defaultValue={
                                    streamOptions.filter(option =>
                                        option.value === records.Stream_gkey
                                    )
                                }
                                styles={errors.stream.length > 0 ? dropDownStylesRed : dropDownStylesGrey}

                            />
                            {errors.stream.length > 0 &&
                                <span class='text-error-red text-[11px]'>{errors.stream}</span>
                            }
                        </span>
                    </div>
                    <div class="flex items-center  mb-[15px]">
                        <span class='flex-1 text-right mr-[30px]'>
                            <label for="description" class={localControlsConstant.label.label14}>{localConstants.SCENARIO.DESCRIPTION}</label>
                        </span>
                        <span class='flex-[2]'>
                            <textarea
                                class={ControlsConstants.TextBox.textarea + 'h-[75px]'}
                                type="text"
                                placeholder="Enter Description"
                                name="description"
                                value={records.description}
                                onChange={props.onValueOnChange}
                            />
                        </span>
                    </div>
                    <div class="flex items-center  mt-[35px]">
                        <span class='flex-1 text-right mr-[30px]'>
                        </span>
                        <span class='flex-[2]'>
                            <div className=" flex-[2] modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pb-0  rounded-b-md space-x-3">
                              {  props.addScenarioFlag ?
                                <button type="button" onClick={props.addScenario_onClick}
                                    className={ControlsConstants.Buttons.btnPrimary} >ADD</button> :
                                    <button type="button" onClick={props.editScenario_onClick}
                                    className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button> 
                              }
                                <button type="button"
                                    onClick={props.reset_onClick}
                                    className={ControlsConstants.Buttons.btnSecondary}  >RESET</button>
                            </div>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default FormScenario;

