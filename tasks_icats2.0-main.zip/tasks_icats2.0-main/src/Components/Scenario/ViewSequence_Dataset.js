import React from "react";
import { useState } from "react";
import { ArrangeSequence, ViewDataSet } from "./SequenceGrids";

const ViewSequence_DataSet = (props) => {
    const [viewDataFlag, setViewDataFlag] = useState(true)
    return (
        <div>
            <div className='flex pt-5'>
                <div className=' pl-8 w-[30%]'>
                    <div className="flex">
                        <div className="border-l-2 border-gray-100">
                            <div className="text-zinc-500 text-base font-light cursor-pointer">
                                <div onClick={() => setViewDataFlag(true)} className={`hover:bg-[#E3EEFF] px-[10px] py-[6px] ${viewDataFlag ? 'border-l-[4px] border-blue-800 text-blue-800 font-normal bg-[#E3EEFF]' : 'border-l-[4px] border-transparent'} pl-[25px]`}>
                                    Arrange Sequence
                                </div>
                                <div onClick={() => setViewDataFlag(false)} className={`hover:bg-[#E3EEFF] px-[10px] py-[6px] ${viewDataFlag ? 'border-l-[4px] border-transparent' : 'border-l-[4px] border-blue-800 text-blue-800 font-normal bg-[#E3EEFF]'} pl-[25px]`}>
                                    View DataSet
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='px-10 w-full'>
                    {viewDataFlag ?
                        <ArrangeSequence
                            allSequenceData={props.allSequenceData}
                            records={props.records}
                            applyTo_Options={props.applyTo_Options}
                            arrangeSequence_onClick={props.arrangeSequence_onClick}
                            backToScenario_onClick={props.backToScenario_onClick}
                        />
                        : <ViewDataSet
                            records={props.records}
                            allColumnsData={props.allColumnsData}
                        />
                    }
                </div>
            </div>
        </div>
    )
}

export default ViewSequence_DataSet;