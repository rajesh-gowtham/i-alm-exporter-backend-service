import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { AgGridReact } from "ag-grid-react";
import { HiChevronDoubleDown, HiChevronDoubleUp, HiChevronDown, HiChevronRight, HiOutlineSearch } from "react-icons/hi";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';

const localControlsConstant = getControlsConstants();

export const AllScenarioGrid = (props) => {

    const columnDefs = [
        {
            headerName: "ID", minWidth: 120, suppressMovable: true, flex: 1,
            cellRenderer: (params) => {
                const id = `300${params.rowIndex + 1}`.slice(-4);
                return <span className=' text-blue-600 cursor-pointer underline underline-offset-1' onClick={(e) => props.addEditScenario_Open(e, params.data)}> {'SC' + id}</span>
            },
        },
        { headerName: "Display Name", field: "displayName", suppressMovable: true, minWidth: 150, flex: 2, },
        { headerName: "Long Name", field: "longName", suppressMovable: true, minWidth: 200, flex: 2, },
        {
            headerName: "Stream", field: "Stream_gkey", suppressMovable: true, minWidth: 200, flex: 2,
            cellRenderer: (params) => {
                let result = props.streamOptions.find(({ value }) => value === params.value);
                return result.label
            }
        },
        {
            headerName: "Action", field: "Action", suppressMovable: true, minWidth: 150, flex: 1,
            cellRendererFramework: (params) =>
                <div class='flex w-full h-full items-center space-x-4'>
                    <button onClick={(e) => props.viewSequence_DataSet_Open(e, params.data)} >
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 26 26" fill="none">
                            <g clip-path="url(#clip0_287_8131)">
                                <path d="M24.9718 12.7344C24.053 10.3575 22.4578 8.30204 20.3834 6.82194C18.309 5.34184 15.8464 4.50201 13.3 4.40625C10.7535 4.50201 8.2909 5.34184 6.21654 6.82194C4.14218 8.30204 2.54698 10.3575 1.6281 12.7344C1.56604 12.906 1.56604 13.094 1.6281 13.2656C2.54698 15.6425 4.14218 17.698 6.21654 19.1781C8.2909 20.6582 10.7535 21.498 13.3 21.5938C15.8464 21.498 18.309 20.6582 20.3834 19.1781C22.4578 17.698 24.053 15.6425 24.9718 13.2656C25.0339 13.094 25.0339 12.906 24.9718 12.7344ZM13.3 20.0312C9.15935 20.0312 4.78435 16.9609 3.19841 13C4.78435 9.03906 9.15935 5.96875 13.3 5.96875C17.4406 5.96875 21.8156 9.03906 23.4015 13C21.8156 16.9609 17.4406 20.0312 13.3 20.0312Z" fill="#B1B1BE" />
                                <path d="M13.3 8.3125C12.3729 8.3125 11.4666 8.58742 10.6957 9.10249C9.92488 9.61756 9.32408 10.3496 8.96929 11.2062C8.6145 12.0627 8.52168 13.0052 8.70254 13.9145C8.88341 14.8238 9.32985 15.659 9.98541 16.3146C10.641 16.9701 11.4762 17.4166 12.3855 17.5974C13.2948 17.7783 14.2373 17.6855 15.0938 17.3307C15.9503 16.9759 16.6824 16.3751 17.1975 15.6042C17.7126 14.8334 17.9875 13.9271 17.9875 13C17.9875 11.7568 17.4936 10.5645 16.6145 9.68544C15.7355 8.80636 14.5432 8.3125 13.3 8.3125ZM13.3 16.125C12.6819 16.125 12.0777 15.9417 11.5638 15.5983C11.0499 15.255 10.6494 14.7669 10.4129 14.1959C10.1763 13.6249 10.1144 12.9965 10.235 12.3903C10.3556 11.7842 10.6532 11.2273 11.0903 10.7903C11.5273 10.3533 12.0841 10.0556 12.6903 9.93505C13.2965 9.81447 13.9248 9.87635 14.4959 10.1129C15.0669 10.3494 15.5549 10.7499 15.8983 11.2638C16.2417 11.7777 16.425 12.3819 16.425 13C16.425 13.8288 16.0957 14.6237 15.5097 15.2097C14.9236 15.7958 14.1288 16.125 13.3 16.125Z" fill="#B1B1BE" />
                            </g>
                            <defs>
                                <clipPath id="clip0_287_8131">
                                    <rect width="25" height="25" fill="white" transform="translate(0.799973 0.5)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </button>
                    <button onClick={(e) => props.addEditScenario_Open(e, params.data)}>
                        <EditLogo />
                    </button>
                    <button onClick={() => props.deleteScenario_Open(params.data)} >
                        <TrashLogo />
                    </button>
                </div>
        }
    ];

    return (
        <div id="AGGrid">
            <div id='CustomAgGrid'>
                <CustomAgGrid
                    rowData={props.scenarioData}
                    columnDefs={columnDefs}
                    onGridReady={() => { console.log('eee') }}
                    filterValue={props.filterValue}
                />
            </div>
        </div>
    )
};

export const ScenariosByStream = (props) => {

    const groupByStream = props.scenarioData;
    const [groupFlags, setGroupFlags] = useState([]);

    const closeListPanel = (e, index) => {
        e.preventDefault();
        const updatedGroupFlags = [...groupFlags];
        updatedGroupFlags[index] = false;
        setGroupFlags(updatedGroupFlags);
    };

    const openListPanel = (e, index) => {
        e.preventDefault();
        let updatedGroupFlags = [];
        for (let i = 0; i <= index; i++) {
            i === index ? updatedGroupFlags[i] = true : updatedGroupFlags[i] = false
        }
        setGroupFlags(updatedGroupFlags);
    };

    return (
        <div className="font-roboto text-lg flex flex-col p-7 ">
            {/* {Object.keys(groupByStream).map((stream, ind) =>
                <div key={ind} className="flex justify-center pt-2 h-4/5">
                    <div className=" w-full bg-transparent font-[12px]">
                        <div className='bg-white border-b-[1px] p-1 py-2 '>
                            <div className="flex justify-between font-roboto font-bold text-[17px] text-[#89879fd3]">
                                <div className="flex items-center mx-4  rounded cursor-pointer" >
                                    {groupFlags[ind] ?
                                        <HiChevronDown size={22} color='#89879fd3' onClick={(e) => closeListPanel(e, ind)} />
                                        :
                                        <HiChevronRight size={22} color='#89879fd3' onClick={(e) => openListPanel(e, ind)} />
                                    }
                                    <span className='ml-3 mr-1'>{stream}</span>
                                    <span className='text-sm'>({groupByStream[stream].length})</span>
                                </div>
                            </div>
                        </div>
                        <div >
                            {(groupFlags[ind]) ?
                                <AllScenarioGrid
                                    scenarioData={groupByStream[stream]}
                                    addEditScenario_Open={props.addEditScenario_Open}
                                    isGridView={props.isGridView}
                                    applyTo_Options={props.applyTo_Options}
                                    deleteScenario_Open={props.deleteScenario_Open}
                                    streamOptions={props.streamOptions}
                                    dataSetOpen={props.dataSetOpen}
                                    viewSequence_DataSet_Open={props.viewSequence_DataSet_Open}
                                />
                                :
                                null
                            }
                        </div>
                    </div>
                </div>
            )} */}
            {Object.keys(groupByStream).map((stream, ind) => (
                <div className="pt-2 h-4/5 w-full border-2px border-solid "  >
                    <div className="flex justify-center">
                        <div className="p-1 mb-2 w-full bg-transparent">
                            <div className={(!groupFlags[ind]) ? ' border-[4px] solid  border-[#33658A]  rounded-md font-[12px]   ' : 'border-[4px] solid  border-[#33658A]  rounded-md font-[12px]'}>
                                <div className='bg-[#33658A] p-2  '>
                                    <div className="flex justify-between items-center  gap-2 text-slate-50">
                                        <span className="flex items-center">
                                            {groupFlags[ind] ?
                                                <span id="arrowShadow">
                                                    < HiChevronDoubleUp size={20} onClick={(e) => closeListPanel(e, ind)} />
                                                </span> :

                                                <span id="arrowShadow">
                                                    <HiChevronDoubleDown size={20} onClick={(e) => openListPanel(e, ind)} />
                                                </span>
                                            }
                                            <span className='ml-3 mr-1'>{stream}</span>
                                            <span className='text-sm'>({groupByStream[stream].length})</span>
                                        </span>

                                    </div>
                                </div>
                                <div>
                                    {(groupFlags[ind]) ?
                                        <div className='pb-3 bg-[#f6fcfd]' >
                                            <AllScenarioGrid
                                                scenarioData={groupByStream[stream]}
                                                addEditScenario_Open={props.addEditScenario_Open}
                                                isGridView={props.isGridView}
                                                applyTo_Options={props.applyTo_Options}
                                                deleteScenario_Open={props.deleteScenario_Open}
                                                streamOptions={props.streamOptions}
                                                dataSetOpen={props.dataSetOpen}
                                                viewSequence_DataSet_Open={props.viewSequence_DataSet_Open}
                                            />
                                        </div>
                                        : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export const ArrangeSequence = (props) => {
    const allSequenceData = props.allSequenceData;
    const scenarioSequenceData = props.records.scen_seqs;
    const gridApiRef = useRef(null);
    const [gridApi, setGridApi] = useState();
    const [rowData, setRowData] = useState();
    const [columnDefs] = useState([
        {
            headerName: "Label", field: 'lable', rowDrag: true, suppressMovable: true, flex: 2,
        },
        {
            headerName: "Apply To", field: "aut_app_gkey", suppressMovable: true, flex: 2,
            cellRenderer: (params) => {
                const result = props.applyTo_Options.find(({ value }) => value === params.value);
                return result.label
            }
        },
        {
            headerName: "Parameterizable", field: 'Parameterizable', flex: 2, suppressMovable: true,
            // singleClickEdit: true,
            // editable: (params) => params.data.Parameterizable !== false,
            cellRenderer: (params) => {
                const paramValue = params.data.Parameterizable;
                return (
                    <div className="flex items-center justify-around cursor-pointer">
                        <div className="overflow-clip">{paramValue === false || paramValue === 'false' ? "-" : paramValue == ""
                            ?
                            <span class='text-red-400'>Error</span> : paramValue}
                        </div>
                        {/* {paramValue === false ? null : paramValue == "" ?
                            <div className="w-1/3"><BiError color='red' size={15} /></div>
                            :
                            <div className="w-1/3"><BiEditAlt color='blue' size={15} /></div>
                        } */}
                    </div>
                )
            }
        },
    ]);

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            filter: false,
        };
    }, []);

    useEffect(() => {
        let tempRowData = [];
        scenarioSequenceData.map(item => (
            allSequenceData.map(value => {
                if (value.gkey == item.sequence_gkey) {
                    tempRowData.push(value);
                }
            })));
        setRowData(tempRowData);
    }, []);

    const onGridReady = useCallback((params) => {
        const gridApi = params.api;
        gridApiRef.current = gridApi;
        setGridApi(gridApiRef.current);
    }, []);

    const gridOptions = {
        rowStyle: { background: 'white' }
    };

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (
        <>
            <div class="bg-white  ">
                <div className='bg-white rounded'>
                    <div className="ag-theme-alpine h-[50vh]  rounded" id="secondaryGridBorder"  >
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            headerHeight={35}
                            animateRows={true}
                            defaultColDef={defaultColDef}
                            rowDragManaged={true}
                            rowDragMultiRow={true}
                            onGridReady={onGridReady}
                            rowHeight={35}
                            // getRowStyle={getRowStyle}
                            pagination={false}
                            rowSelection={'multiple'}
                            gridOptions={gridOptions}
                            suppressRowClickSelection={true}
                            suppressRowHoverHighlight={true}
                            overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                            overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                        />
                    </div>
                </div>
                <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center pt-5  rounded-b-md space-x-3">
                    <button type="button" onClick={(e) => { props.arrangeSequence_onClick(e, gridApi) }}
                        className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                    <button type="button" onClick={props.backToScenario_onClick}
                        className={ControlsConstants.Buttons.btnSecondary} >CANCEL</button>
                </div>
            </div>
        </>
    );
};

export const ManageSequence = (props) => {
    const [gridApi, setGridApi] = useState()
    const rowData = props.allSequenceData;
    const scenarioSequenceData = props.records.scen_seqs;
    const [columnDefs] = useState([
        {
            field: '', width: 50, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true,
        },
        {
            headerName: "Label", field: "lable", suppressMovable: true, flex: 1,
        },
        {
            field: 'Parameterizable', flex: 1, suppressMovable: true,//singleClickEdit: true,
            // editable: (params) => params.data.Parameterizable !== false,
            cellRenderer: (params) => {
                return (
                    <span className=' justify-center '>{params.data.Parameterizable === false || params.data.Parameterizable === 'false' ? "-" : params.data.Parameterizable}</span>
                )
            }
        },
        {
            headerName: "Apply To", field: "aut_app_gkey", suppressMovable: true, flex: 1,
            cellRenderer: (params) => {
                const result = props.applyTo_Options.find(({ value }) => value === params.value);
                return result.label
            }
        },
    ]);

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            filter: false,
        };
    }, []);

    const gridOptions = {
        rowStyle: { background: 'white' },
    };

    const onGridReady = (params) => {
        setGridApi(params.api);
        const seqGkeys = scenarioSequenceData == undefined ? [] : scenarioSequenceData.map(item => item.sequence_gkey);
        params.api.forEachLeafNode((node) => {
            if (seqGkeys.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (

        <div class="bg-white ">
            <div className='bg-white rounded'>
                <div className="ag-theme-alpine h-[35vh]  rounded" id="secondaryGridBorder"  >
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        animateRows={true}
                        defaultColDef={defaultColDef}
                        headerHeight={35}
                        rowHeight={35}
                        pagination={false}
                        rowSelection={'multiple'}
                        gridOptions={gridOptions}
                        suppressRowClickSelection={true}
                        onGridReady={onGridReady}
                        // getRowStyle={getRowStyle}
                        suppressRowHoverHighlight={true}
                        overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center mt-5  rounded-b-md space-x-3">
                <button type="button" onClick={(e) => { props.manageSequence_onClick(e, gridApi) }}
                    className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                <button type="button" onClick={props.backToScenario_onClick}
                    className={ControlsConstants.Buttons.btnSecondary}  >CANCEL</button>
            </div>
        </div>
    );

};

export const ViewDataSet = (props) => {

    const allColumnsData = props.allColumnsData;
    const scenarioDatasetData = props.records.scen_auts;
    const [rowData, setRowData] = useState();
    const [columnDefs] = useState([
        {
            headerName: 'Label', field: 'shortName', flex: 2, suppressMovable: true,
        },
        {
            headerName: 'Display Name', field: 'displayName', flex: 2, suppressMovable: true,
        },
        {
            headerName: "control", field: "control", flex: 1, suppressMovable: true,
        }
    ]);

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            filter: false,
        };
    }, []);

    const gridOptions = {
        rowStyle: { background: 'white' }
    };

    useEffect(() => {
        let tempRowData = [];
        allColumnsData.map(item => (
            scenarioDatasetData.map(value => {
                if (item.gkey == value.aut_app_gkey) {
                    tempRowData.push(item);
                }
            })))
        setRowData(tempRowData)
    }, []);

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (
        <>
            <div class="bg-white">
                <div className='bg-white rounded'>
                    <div className="ag-theme-alpine h-[50vh] rounded" id="secondaryGridBorder"  >
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            animateRows={true}
                            defaultColDef={defaultColDef}
                            headerHeight={35}
                            rowHeight={35}
                            pagination={false}
                            rowSelection={'multiple'}
                            gridOptions={gridOptions}
                            // getRowStyle={getRowStyle}
                            suppressRowClickSelection={true}
                            suppressRowHoverHighlight={true}
                            overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                            overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                        />
                    </div>
                </div>
                <div className=" modal-footer flex flex-shrink-0 flex-wrap items-center justify-center mt-5  rounded-b-md space-x-5">
                    <span className='text-md text-black font-semibold'>Total Dataset Records: {scenarioDatasetData.length}</span>
                </div>
            </div>
        </>
    );
};

export function ManageDataSet(props) {

    const [gridApi, setGridApi] = useState()
    //Get Data from Redux
    const rowData = props.allColumnsData;
    const scenarioDatasetData = props.records.scen_auts;
    const [columnDefs] = useState([
        {
            headerName: 'Short Name', field: 'shortName', suppressMovable: true, flex: 2, headerCheckboxSelectionFilteredOnly: true, headerCheckboxSelection: true,
            checkboxSelection: true,
        },
        { headerName: 'Display Name', field: 'displayName', flex: 2, suppressMovable: true, },
        { headerName: 'Control', field: 'control', flex: 2, suppressMovable: true, },

    ]);

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            filter: false,
        };
    }, []);

    const gridOptions = {
        rowStyle: { background: 'white' }
    };

    const onGridReady = (params) => {
        setGridApi(params.api);
        const dataSetGkeys = scenarioDatasetData?.map(item => item.aut_app_gkey);
        params.api.forEachLeafNode((node) => {
            if (dataSetGkeys.includes(node.data.gkey))
                node.setSelected(true);
        });
    };

    // const getRowStyle = params => {
    //     if (params.node.rowIndex % 2 === 0) {
    //         return { background: 'white' };
    //     } else {
    //         return { background: '#F0F0F0' };
    //     }
    // };

    return (
        <div class="bg-white ">
            <div className='bg-white rounded'>
                <div className="ag-theme-alpine h-[35vh]  rounded" id="secondaryGridBorder"  >
                    <AgGridReact
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={defaultColDef}
                        animateRows={true}
                        headerHeight={35}
                        rowHeight={35}
                        pagination={false}
                        rowSelection={'multiple'}
                        gridOptions={gridOptions}
                        onGridReady={onGridReady}
                        suppressRowClickSelection={true}
                        suppressRowHoverHighlight={true}
                        // getRowStyle={getRowStyle}
                        overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
                        overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    />
                </div>
            </div>
            <div className=" modal-footer  flex flex-shrink-0 flex-wrap items-center justify-center  mt-5 rounded-b-md space-x-3">
                <button type="button" onClick={(e) => { props.manageDataset_onClick(e, gridApi) }}
                    className={ControlsConstants.Buttons.btnPrimary} >UPDATE</button>
                <button type="button" onClick={props.backToScenario_onClick}
                    className={ControlsConstants.Buttons.btnSecondary} >CANCEL</button>
            </div>
        </div>
    );
};

//     const rowDatas = [
//         { userName: 'Aravind', selected: true },
//         { userName: 'Ivan Lendil', selected: true },
//         { userName: 'Akash', selected: true },
//         { userName: 'Naveen Kumar', selected: true },
//         { userName: 'Gokul', selected: true },
//         { userName: 'Mubarak', selected: false },
//         { userName: 'Rajesh', selected: false },
//         { userName: 'Nagarasu', selected: false },

//     ]
//     const gridApiRef = useRef(null);
//     const [userData, setUserData] = useState();
//     const [assignUsers, setAssignUsers] = useState('selectedUsers')
//     const [gridApi, setGridApi] = useState();
//     const [columnDefs] = useState([
//         {
//             headerName: 'User Name', field: 'userName', flex: 3, suppressMovable: true,
//         },

//         {
//             field: '', minWidth: 80, flex: 1, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true,
//         }


//     ]);

//     const defaultColDef = useMemo(() => {
//         return {
//             sortable: true,
//             filter: false,
//         };
//     }, []);



//     useEffect(() => {
//         let tempUserData = [];
//         rowDatas.map((val) => {
//             if (val.selected === true) tempUserData.push(val)
//         })
//         setUserData(tempUserData);
//     }, []);

//     const gridOptions = {
//         rowStyle: { background: 'white' }
//     };

//     const assignUsersToggle = (e) => {
//         let toggleValue = e.target.value;
//         setAssignUsers(toggleValue)
//         if (toggleValue == 'allUsers') {
//             gridApi.setRowData(rowDatas);
//         } else {
//             let tempUserData = [];
//             rowDatas.map((val) => {
//                 if (val.selected === true) tempUserData.push(val)
//             })
//             gridApi.setRowData(tempUserData);

//         }
//         gridApi.forEachLeafNode((node) => {
//             node.setSelected(node.data.selected);
//         });
//     }

//     const onGridReady = (params) => {
//         setGridApi(params.api)
//         params.api.forEachLeafNode((node) => {
//             node.setSelected(node.data.selected);
//         });
//     };

//     const onFilterTextBoxChanged = () => {
//         gridApi.Refcurrent.api.setQuickFilter(
//             document.getElementById('filter-text-box').value
//         );
//     };

//     return (
//         <>
//             <div className="flex  justify-around text-black font-roboto font-[600] items-center  my-3">
//                 <div className={`flex items-center p-2 rounded w-[40%] border-2 ${assignUsers == 'selectedUsers' ? ' border-blue-400' : ' bg-gray-100  border-transparent'}`}>
//                     <input type="radio" id="selectedUsers" name="assignUsers" checked={assignUsers == 'selectedUsers' && true} value="selectedUsers" onClick={(e) => assignUsersToggle(e)} />
//                     <label for="selectedUsers" className=" ml-2 text-sm">Selected Users {'(5)'}</label>
//                 </div>
//                 <div className={`flex items-center p-2 rounded w-[40%] border-2 ${assignUsers == 'allUsers' ? ' border-blue-400' : 'bg-gray-100  border-transparent'}`}>
//                     <input type="radio" id="allUsers" name="assignUsers" checked={assignUsers == 'allUsers' && true} value="allUsers" onClick={(e) => assignUsersToggle(e)} />
//                     <label for="allUsers" className=" ml-2 text-sm">All Users {'(8)'}</label>
//                 </div>
//             </div>

//             <div class=" p-2 h-[50vh] ">
//                 <div class='flex justify-end mb-1'>
//                     <div id="manage-priv-search">
//                         <div class="relative  flex items-center  h-8 rounded-lg border-2 border-gray- w-full bg-white overflow-hidden">
//                             <div class="grid place-items-center h-full w-12 text-search-text">
//                                 <HiOutlineSearch size={localControlsConstant.Icon.search.size} />
//                             </div>
//                             <input
//                                 id="filter-text-box"
//                                 onInput={onFilterTextBoxChanged}
//                                 class="peer text-search-text bg-white h-full w-full max-sm:w-[100px] outline-none text-search-text-size placeholder-search-text  pr-2"
//                                 type="text"
//                                 placeholder="Search..." />
//                         </div>
//                     </div>
//                 </div>
//                 {/* <div className='text-[12px] font-semibold text-blue-600 space-x-5 text-end py-1'>
//                     <span className='cursor-pointer'>Select All</span>
//                     <span className='cursor-pointer'>Deselect All</span>
//                 </div> */}
//                 <div className='bg-white rounded'>
//                     <div className="ag-theme-alpine h-[40vh] p-2  rounded" id="secondaryGrid"  >
//                         <AgGridReact
//                             rowData={userData}
//                             columnDefs={columnDefs}
//                             defaultColDef={defaultColDef}
//                             animateRows={true}
//                             ref={gridApiRef}
//                             headerHeight={35}
//                             rowHeight={35}
//                             pagination={false}
//                             rowSelection={'multiple'}
//                             gridOptions={gridOptions}
//                             onGridReady={onGridReady}
//                             suppressRowClickSelection={true}
//                             suppressRowHoverHighlight={true}
//                             overlayNoRowsTemplate={'<span class="ag-overlay-loading-center mb-6">No Records Found !</span>'}
//                             overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
//                         />
//                     </div>
//                 </div>
//                 <div className="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end shadow-[0px_2px_1px_#3c40434c_inset] pb-0 p-4   rounded-b-md">
//                     {assignUsers == 'allUsers' &&
//                         <button type="button" className={ControlsConstants.Buttons.btnSecondary}>Update</button>
//                     }
//                 </div>
//             </div>
//         </>
//     );
// };


