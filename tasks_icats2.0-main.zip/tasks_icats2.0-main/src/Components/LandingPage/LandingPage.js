import React from "react";
import CommonLanding from "./CommonLanding";
import { HiChevronDoubleUp } from 'react-icons/hi';
import '../../CSS/LandingPage.css';
import { BrowserView, MobileView, isBrowser, isMobile } from 'react-device-detect';
import { LandingConstants } from "../../Constants/LandingConstants";

//SCREEN ID -3015
const LandingPage = () => {

  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction();
  };

  const scrollFunction = () => {
    const mybutton = document.getElementById("btn-back-to-top");
    // console.log("mybutton", document.body.scrollTop, "  ", document.documentElement.scrollTop)
    if (
      document.body.scrollTop > 20 ||
      document.documentElement.scrollTop > 350
    ) {
      mybutton.style.display = "block";
    } else {
      mybutton.style.display = "none";
    }
  }
  const backToTop = () => {
    window.scrollTo({ left: 0, top: 0, behavior: 'smooth' })
  }
  return (
    <div >
      <CommonLanding>
        {/* Image content */}
        <div className="imageContent relative font-roboto max-lg:h-[40vh] max-lg:w-[100vh] h-[90vh] max-w-[100vw] ">
          <div className="imageContentText">
            <h1 class=' max-lg:text-[5.5vw]  text-[4vw] mb-4  font-teko'>{LandingConstants.HOME.MAIN_SLOGAN}</h1>
            <div class='subcontent max-lg:text-[3.5vw] text-[1.5vw]'>{LandingConstants.HOME.SUB_SLOGAN_1}</div>
            <div class='subcontent max-lg:text-[3.5vw] text-[1.5vw] mb-6'>{LandingConstants.HOME.SUB_SLOGAN_2}</div>
            <div class="reference-btn ">
              <a type="button" class="inline-block max-lg:mob-txt-md px-6 py-2 border-2 border-white text-white font-medium text-xs leading-tight uppercase rounded hover:bg-[#ffffff] hover:text-black focus:outline-none focus:ring-0 transition duration-150 ease-in-out" href="#!" role="button" data-mdb-ripple="true" data-mdb-ripple-color="light">{LandingConstants.HOME.READ_MORE}</a>
            </div>
          </div>
        </div>
        <div class="max-lg:pt-6 max-lg:pb-2 max-lg:px-16 pt-20  pb-5 px-40  relative" >
          <div className=' w-3/5 max-lg:w-full relative'>
            <div id='summary'></div>
            <p class="max-lg:mob-txt-sm md:text-lg leading-8  text-justify max-lg:pl-4 pl-8 pb-4">
              {LandingConstants.HOME.iCATS_SUMMARY_1}
            </p>
            <p class="max-lg:mob-txt-sm md:text-lg leading-8 text-justify max-lg:pl-4 pl-8" >
              {LandingConstants.HOME.iCATS_SUMMARY_2}
            </p>
          </div>
        </div>
        {/* STATISTICS */}
        <div class=" flex max-lg:flex-col  items-center justify-around space-x-5 max-lg:px-4 max-lg:space-y-5 max-lg:mob-txt-sm px-8 h-56 max-lg:h-auto my-5">
          <div class="flex-1 text-center sm:mt-0 sm:ml-2 sm:text-left border-r-2 max-lg:border-r-0 border-blue-100">
            <p class="text-center max-lg:text-3xl  max-lg:pb-0    md:text-5xl   text-blue-700 pb-4">
              {LandingConstants.HOME.STATISTICS_PERC.PERC_1}</p>
            <h3 class="text-center  max-lg:text-mob-txt-1xl md:text-2xl  leading-6 font-medium text-gray-600 whitespace-pre-line  font-teko" >
              {LandingConstants.HOME.STATISTICS_DESC.DESC_1}</h3>
          </div>
          <div class="flex-1 text-center sm:mt-0 sm:ml-2 sm:text-left border-r-2 max-lg:border-r-0 border-blue-100">
            <p class="text-center ] max-lg:text-3xl  max-lg:pb-0  md:text-5xl  text-blue-700 pb-4">
              {LandingConstants.HOME.STATISTICS_PERC.PERC_2}</p>
            <h3 class="text-center  max-lg:text-mob-txt-1xl md:text-2xl   leading-6 font-medium text-gray-600 whitespace-pre-line  font-teko">
              {LandingConstants.HOME.STATISTICS_DESC.DESC_2}</h3>
          </div>
          <div class="flex-1 text-center sm:mt-0 sm:ml-2 sm:text-left ">
            <p class="text-center max-lg:text-3xl  max-lg:pb-0 md:text-5xl  text-blue-700 pb-4">
              {LandingConstants.HOME.STATISTICS_PERC.PERC_3}</p>
            <h3 class="text-center  max-lg:text-mob-txt-1xl md:text-2xl   leading-6 font-medium text-gray-600 whitespace-pre-line  font-teko" >
              {LandingConstants.HOME.STATISTICS_DESC.DESC_3}</h3>
          </div>
        </div>
        <div id="btn-back-to-top" title='back to top' onClick={(e) => backToTop(e)} class='flex justify-end max-lg:mb-2 max-lg:mr-2  mb-7 mr-10 ' >
          <div class='w-5 h-5 p-4 rounded bg-orange-500 flex items-center justify-center cursor-pointer relative' >
            <span> <HiChevronDoubleUp color='white' size={20} /></span>
            <div class='absolute'>
              <span class="relative flex h-6 w-6 -z-10">
                <span id='ping-btn' class=" absolute inline-flex h-full w-full rounded bg-blue-500 "></span>
                <span class="relative inline-flex rounded-full h-6 w-6 bg-sky-500"></span>
              </span>
            </div>
          </div>
        </div>
      </CommonLanding>
    </div>
  )
}

export default LandingPage;

