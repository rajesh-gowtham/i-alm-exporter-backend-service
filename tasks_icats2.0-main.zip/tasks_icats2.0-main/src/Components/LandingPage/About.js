import React from "react";
import CommonLanding from "./CommonLanding";
//SCREEN ID -3019
const About = () => {
    return (
        <div>
            <CommonLanding>
                <div>
                    <img class="px-2 pb-4" src="https://igosolutions.eu/img/about_us.jpg" />
                    <div class="px-32">
                        <h2 class="mb-2 text-lg font-bold text-gray-900 dark:text-white">ABOUT</h2>
                        <ul class=" space-y-1 text-gray-500 list-inside dark:text-gray-400">
                            <li class="flex pb-2">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>IGO Solutions, a leading provider of Technology driven Business Solutions has been solving problems for Port, Shipping and Logistics customers for almost two decades. IGO carries an impressive 400+ man-years of specialist experience in the Global Ports, Shipping and Logistics Domain.</p>
                            </li>
                            <li class="flex pb-2">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>The IGO specialists conduct a range of Operational and IT improvement services, aimed at all levels of our client’s Operating Model.</p>
                            </li>
                            <li class="flex pb-2">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>IGO Solutions is a global company with business interests worldwide. IGO has a physical presence with offices in United Arab Emirates, United Kingdom, Australia, India and has in addition executed projects in many other countries including Netherlands, Turkey, Namibia, Philippines and New Zealand.</p>
                            </li>
                        </ul>

                        <h2 class="mb-2 text-lg font-bold text-gray-900 dark:text-white pt-6">WHO WE ARE</h2>
                        <ul class=" space-y-1 pb-5 text-gray-500 list-inside dark:text-gray-400">
                            <li class="flex pb-2">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>Two decades of experience in providing Terminal Business Consultancy, Business Process Mapping, Development, Testing. Software Support Solutions, Business Intelligence Services, Process Training.</p>
                            </li>
                            <li class="flex pb-2">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>IGO Solutions is a specialist provider of software life-cycle services. We offer a complete software testing and validation service, including fully managed services with comprehensive reporting.</p>
                            </li>
                            <li class="flex">
                                <svg class="w-4 h-4 mr-1.5 text-green-500 dark:text-green-400 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                <p>Highly specialized service ensuring the software being tested is not just for ‘fit for purpose’ but also, has the required level of quality and reliability.Software migration and consultancy service with complete end to end support. Customized service to special customer segments.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </CommonLanding>
        </div>
    )
}
export default About;