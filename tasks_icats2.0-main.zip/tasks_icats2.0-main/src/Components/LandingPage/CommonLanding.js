import Footer from "./Footer";
import Header from "./Header";
import "../../CSS/LandingPage.css"
//SCREEN ID -3018
function CommonLanding({ children }) {
  return (
    <div class="bg-gray-50">
      <Header />
      {children}
      <Footer />
    </div>
  )
}
export default CommonLanding;
