import React from "react";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { getlocalizeData } from '../../CommonUtils/getlocalizeData';

const localConstants = getlocalizeData();

//SCREEN ID -3010
const EditRole = (props) => {
  return (

    <div className="mt-3">
      <form id='addRoleForm' class="flex font-[Verdana] flex-col py-[5px] px-[30px] rounded-b-lg"></form>
      <div class="d-inline-block position-relative mb-3">
        <label for="role" class={ControlsConstants.label.label14}>{localConstants.ROLE.ROLE_NAME}</label><br />
        <input
          class={props.error.length > 0 ? ControlsConstants.TextBox.borderRed : ControlsConstants.TextBox.textbox}
          type="text"
          placeholder="Enter RoleName"
          name="name"
          value={props.records.name}
          onChange={props.handleOnChange} >
        </input>
        {props.error.length > 0 &&
          <span class='text-error-red text-[12px] ml-4'>{props.error}</span>
        }
      </div>
      <div class="d-inline-block position-relative mb-3">
        <label for="descripton" class={ControlsConstants.label.label14}>{localConstants.ROLE.DESCRIPTION}</label><br />
        <textarea
          class={ControlsConstants.TextBox.textarea + 'h-[75px]'}
          type="textarea"
          placeholder="Enter Description"
          name="description"
          onChange={props.handleOnChange}
          value={props.records.description}
        >
        </textarea>
      </div>
      <div class="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end mt-2 pb-0 p-4 space-x-3 border-t border-gray-200 rounded-b-md">
        <button type="button" class={ControlsConstants.Buttons.btnPrimary} onClick={props.onEditRole_ClickSave}>{localConstants.COMMON_CONST.UPDATE}</button>
        <button type="button" class={ControlsConstants.Buttons.btnSecondary} onClick={props.dialogBoxClose} >{localConstants.COMMON_CONST.CANCEL}</button>
      </div>
    </div>
  )
}
export default EditRole;