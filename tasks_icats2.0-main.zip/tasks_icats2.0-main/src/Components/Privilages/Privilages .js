import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import PrivilageService from '../../Services/PrivilageService';
import { ReactDialogBox } from 'react-js-dialog-box';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import EditPrivilegeForm from './EditPrivilegeForm';
import { GetPrivilegesByStore } from '../../Redux/Store';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();
//SCREEN ID -3012

class Privilages extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            deletePrivilegeflag: false,
            editPrivilegeflag: false,
            deleteDetails: {},
            editDetails: {},
            rowData: [],
            error: '',
            navPath: ['Privileges'],
            columnDefs: [
                {
                    field: '', width: 100, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true,
                },
                {
                    headerName: "ID", field: "id", suppressMovable: true, minWidth: 100, flex: 2,
                    cellRenderer: (params) => {
                        const id = `300${params.rowIndex + 1}`.slice(-4);
                        return <a href="#" target="_parent" className=' text-blue-600' onClick={() => this.editPrivilege_Open(params)}> {"P" + id}</a>
                    },
                },
                {
                    headerName: "Privilege", field: "Privilege_Name", suppressMovable: true, minWidth: 150, flex: 2,
                },
                {
                    headerName: "Module", field: "module_name", suppressMovable: true, minWidth: 150, flex: 2,
                },
                {
                    headerName: "Action", field: "Action", suppressMovable: true, minWidth: 100, flex: 1,
                    cellRendererFramework: (params) =>
                        <div class='flex w-full h-full items-center space-x-4'>
                            <button onClick={() => this.editPrivilege_Open(params)}><EditLogo /></button>
                            <button onClick={() => this.deleteOpenClick(params)}>< TrashLogo /></button>
                        </div>
                }
            ],
            defaultColDef: {
                sortable: true,
            },
        };
        this.editPrivilegeOnChange = this.editPrivilegeOnChange.bind(this);
    };


    componentDidMount() {
        //Do Not Un Command By Mybarak
        // this.BulkPrivilageInsert(LocalColumnData.ColumnData.Data)
        //GetAllPrivilages
        this.GetPrivilegesByOrg();
    }

    GetPrivilegesByOrg = async () => {
        try {
            //  const reduxPrivilagesdata = Store.getState().allPrivileges; 
            //  Added by rajesh for to get get privleage data with Sync          
            GetPrivilegesByStore().then(data => {
                console.log( this.gridApi);
                this.gridApi.setRowData(data);
                this.gridApi.forEachLeafNode((node) => {
                    node.setSelected(node.data.Status);
                });
                this.setState({
                    rowData: data
                })
                console.log('GetPrivileges', data)
            });
        } catch (error) {
            console.error(error);
            // Handle the error 
        }
    };

    BulkPrivilageInsert(BulkPrivilage) {
        PrivilageService.BulkPrivilageInsert(BulkPrivilage).
            then(
                respons => {
                    if (respons.status == 200 || respons.status == 201) {
                        toast.success("Privilage Data Inserted successfully")
                        return;
                    } else {
                        toast.error("InValid Privilages Data (STATUS)" + respons.status);
                    }
                }
            );
    }

    editPrivilege_Open = (event) => {
        this.setState({
            editPrivilegeflag: true,
            editDetails: event.data,
            error: ''
        })
    }

    editPrivilegeOnChange = (e) => {
        e.preventDefault();
        let name = e.target.name.trim();
        let value = e.target.value;
        this.setState(prevState => ({
            editDetails: {
                ...prevState.editDetails,
                [name]: value,
            }
        })
        )
        // console.log('edit', this.state.editDetails.Privilege_Name)
        let error = this.state.error;
        switch (name) {
            case 'Privilege_Name':
                error =
                    value.length < 1
                        ? "Privilege Name can't be empty ! "
                        : '';
                break;
            default:
                break;
        }
        this.setState({ error: error });
    };

    editPrivilegeOn_Click = (e) => {
        e.preventDefault();
        const isValid = this.validateAllfields(this.state.editDetails);
        console.log('this.state.editDetails', this.state.editDetails)
        console.log('isValidisValidisValidisValid', this.validateAllfields(this.state.editDetails))
        //UpdateprivilegesNamebyGkey
        if (isValid) {
            PrivilageService.UpdateprivilegesNamebyGkey(this.state.editDetails).
                then(
                    respons => {
                        if (respons.status == 200 || respons.status == 201) {
                            toast.success("Privilages Updated successfully")
                            this.setState({
                                editPrivilegeflag: false
                            })
                            // console.log('privilege edit', respons.data)
                            GetPrivilegesByStore().then(data => {
                                this.gridApi.setRowData(data);
                                this.gridApi.forEachLeafNode((node) => {
                                    node.setSelected(node.data.Status);
                                });
                                // console.log('UpdateprivilegesNamebyGkey  ', data)
                            });
                            return;
                        } else {
                            toast.error("InValid Privilages Data (STATUS)" + respons.status);
                        }
                    }
                );
            // console.log('updates privilege data', this.state.editDetails);
        } else {
            console.log(" inValid ", this.state.records)
        }

    };

    validateAllfields(records) {
        if (records.Privilege_Name.length != 0 && records.Privilege_Name.trim().length == 0) {
            records.Privilege_Name = records.Privilege_Name.trim();
            this.setState({ error: "Space can't be taken as a Privilege Name" })
            return false;
        }

        if (records.Privilege_Name == undefined || records.Privilege_Name == "" || this.state.error != "") {
            let err = records.Privilege_Name == undefined || records.Privilege_Name == "" ? ' Please enter Privilege Name  ' : this.state.error;
            this.setState({
                error: err
            });
            return false;
        }
        return true;
    };

    deleteOpenClick = (event) => {
        if (event.data.Status) {
            this.setState({
                deleteDetails: event.data,
                deletePrivilegeflag: true,
            })
        }
        else {
            toast.error("Privilege Already disabled ! ")
        }
    };

    deletePrivOnClick = async (e) => {
        e.preventDefault();
        let tempData = { gkey: '', status: false };
        tempData["gkey"] = this.state.deleteDetails["gkey"];
        tempData["status"] = false;
        try {
            const resp = await PrivilageService.UpdateprivilegesStatusByGkey(tempData);
            toast.success(resp.data.Privilege_Name + " Privilege disabled successfully ")
            const data = await GetPrivilegesByStore();
            this.gridApi.setRowData(data);
            this.gridApi.forEachLeafNode((node) => {
                node.setSelected(node.data.Status);
            });
            this.setState({ deletePrivilegeflag: false })
        } catch (error) {
            console.log(error);
        }
    };

    resetOn_Click = (e) => {
        e.preventDefault();
        this.setState({
            error: ''
        })
        this.setState(prevState => ({
            editDetails: {
                ...prevState.editDetails,
                Privilege_Name: ''
            }
        }))
    };

    onGridReady = (params) => {
        this.gridApi = params.api;
        this.gridApi.forEachLeafNode((node) => {
            node.setSelected(node.data.status);
        });
    };

    OnCheckBoxSelection = (params) => {
        let tempData = { gkey: '', status: false };
        tempData["gkey"] = params.data.gkey;
        tempData["status"] = params.node.selected;
        if (params.node.selected != params.data.Status) {
            PrivilageService.UpdateprivilegesStatusByGkey(tempData).then(
                resp => {
                    GetPrivilegesByStore().then(data => {
                        this.gridApi.setRowData(data);
                        this.gridApi.forEachLeafNode((node) => {
                            node.setSelected(node.data.Status);
                        });
                    });
                })
        }
    };

    onFilterTextBoxChanged = () => {
        let filterValue = document.getElementById('filter-text-box').value;
        this.setState({
            filterValue: filterValue
        })
    };

    backToMainScreen = (e) => {
        this.setState({
            navPath: ['Privileges'],
            deletePrivilegeflag: false,
            editPrivilegeflag: false
        })
    };

    render() {
        return (
            <AuthCommonLayout>
                <div>
                    <div id='screenHeader'>
                        <ComponentHeader
                            isSearchable={true}
                            path={this.state.navPath}
                            backToParentClass={this.backToMainScreen}
                            onFilterTextBoxChanged={this.onFilterTextBoxChanged}
                        />
                    </div>
                    <div className='screenBody'>
                        <div id='CustomAgGrid'>
                            <CustomAgGrid
                                rowData={this.state.rowData}
                                columnDefs={this.state.columnDefs}
                                onGridReady={this.onGridReady}
                                filterValue={this.state.filterValue}
                                OnCheckBoxSelection={this.OnCheckBoxSelection}
                            />
                        </div>
                        {this.state.editPrivilegeflag ?
                            <ReactDialogBox
                                closeBox={this.backToMainScreen}
                                modalWidth={localControlsConstant.Model.modalWidthUser}
                                headerBackgroundColor={ControlsConstants.Model.headerbg}
                                headerTextColor={localControlsConstant.Model.bodybg}
                                headerHeight={localControlsConstant.Model.headerheight}
                                closeButtonColor={localControlsConstant.Model.closebtncolor}
                                bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                headerText='Edit Privilege'
                            >
                                <div>
                                    <EditPrivilegeForm
                                        privilegeData={this.state.editDetails}
                                        editPrivilegeOnChange={this.editPrivilegeOnChange}
                                        error={this.state.error}
                                        editPrivilegeOn_Click={this.editPrivilegeOn_Click}
                                        resetOn_Click={this.resetOn_Click}
                                    />
                                </div>
                            </ReactDialogBox>
                            : null
                        }

                        {this.state.deletePrivilegeflag ?
                            <div>
                                <ReactDialogBox
                                    closeBox={this.backToMainScreen}
                                    modalWidth={localControlsConstant.Model.modalWidth}
                                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                                    headerTextColor={localControlsConstant.Model.bodybg}
                                    headerHeight={localControlsConstant.Model.headerheight}
                                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                    headerText='Delete Privilege'
                                >
                                    <div>
                                        <div class='flex items-center h-16 pl-7 '>
                                            <h1>{localConstant.PRIVILEGES.DISABLE_PRIVILEGE_CONTENT} <span class='text-delete-user-text text-[18px] font-semibold'> {this.state.deleteDetails["Privilege_Name"]}</span>?</h1>
                                        </div>
                                        <div class="modal-footer flex flex-shrink-0 flex-wrap items-center justify-end pb-0 p-4 border-t border-footer-border space-x-3 rounded-b-md">
                                            <button type="button" class={ControlsConstants.Buttons.btnPrimary} onClick={this.deletePrivOnClick}>{localConstant.COMMON_CONST.YES}</button>
                                            <button type="button" class={ControlsConstants.Buttons.btnSecondary} onClick={this.backToMainScreen}>{localConstant.COMMON_CONST.NO}</button>
                                        </div>
                                    </div>
                                </ReactDialogBox>
                            </div>
                            : null
                        }
                        <ToastContainer limit={2} autoClose={2000} />
                    </div>
                </div>
            </AuthCommonLayout>
        )
    }
}

export default Privilages;
