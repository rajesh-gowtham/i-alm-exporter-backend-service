import React from 'react';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import { HiPlus } from 'react-icons/hi';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import 'react-toastify/dist/ReactToastify.css';
import StreamService from '../../Services/StreamService';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import AddStream from './AddStream';
import EditStream from './EditStream';
import { EditLogo, TrashLogo } from '../../CommonUtils/getLocalizeFunction';
import CustomAgGrid from '../../CommonUtils/UtilCustomAgGridComp';
import ComponentHeader from '../../CommonUtils/ComponentHeader';

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
// var newStreamData = [{ MasterBizUitKey: window.localStorage.getItem("MasterBizUitKey"), streamname: '', description: '' }];

//SCREEN ID -3071
class StreamGroup extends React.Component {
  constructor() {
    super()
    this.state = {
      StreamForm: true,
      addStreamFlag: false,
      editStreamFlag: false,
      deleteStreamFlag: false,
      selecteddeleteindex: '',
      editdetails: '',
      errors: {},
      newStreamData: {},
      navPath: ['Streams'],
      modelheader: '',
      columnDefs: [
        {
          headerName: "ID", field: "gkey", suppressMovable: true, minWidth: 120, flex: 1,
          cellRenderer: (params) => {
            const id = `300${params.rowIndex + 1}`.slice(-4);
            return <span className=' text-blue-600 cursor-pointer' onClick={(e) => this.addEditStreamOpen(e,params)}> {'ST' + id}</span>
          }
        },
        { headerName: "Name", field: "name", suppressMovable: true, minWidth: 150, flex: 2 },
        { headerName: "Description", field: "description", suppressMovable: true, minWidth: 150, flex: 2 },
        {
          headerName: "Action", field: "Active", suppressMovable: true, minWidth: 100, flex: 1,
          cellRendererFramework: (params) =>
            <div class='flex w-full h-full items-center space-x-4'>
              <button onClick={(e) => this.addEditStreamOpen(e, params)}><EditLogo /></button>
              <button onClick={() => this.deleteStramOpen(params)} >< TrashLogo /></button>
            </div>
        }
      ],
      defaultColDef: {
        sortable: true,
      },
      rowData: [],
      newStreamRecords: []
    };
    this.addStreamOnChange = this.addStreamOnChange.bind(this);
    this.addStreamOn_Click = this.addStreamOn_Click.bind(this);
  };

  componentDidMount() {
    this.getStreamsByOrg();
  };

  getStreamsByOrg() {
    StreamService.getStreamByOrg().
      then(
        response => {
          console.log(response.data)
          this.setState({
            rowData: response.data,
          })
        }
      );
  };

  addEditStreamOpen = (event, item) => {
    // event.preventDefault()
    if (item == undefined || item == null) {
      this.setState({
        addStreamFlag: true,
        modelheader: 'Add Stream',
        newStreamData: {
          name: '',
          description: ''
        },
        errors: {
          name: '',
        }
      })
    } else {
      console.log('editStreamFlag',item)
      this.setState({
        editStreamFlag: true,
        editdetails: item.data,
        modelheader: 'Edit Stream',
        errors: {
          name: '',
        }
      })
    }
  };

  addStreamOnChange(e) {
    let name = e.target.name.trim();
    let value = e.target.value.trim();
    this.setState(prevState => ({
      newStreamData: {
        ...prevState.newStreamData,
        [name]: value,
      }
    }))
    let errors = this.state.errors
    switch (name) {
      case 'name':
        errors.name = value.length < 1 ? " Stream name can't be empty !" : "";
        break;
      default:
        break;
    }
  };

  addStreamOn_Click = event => {
    event.preventDefault();
    let newRecords = this.state.newStreamData;
    newRecords["MasterBizUitKey"] = window.localStorage.getItem("MasterBizUitKey");
    console.log('MasterBizUitKey', newRecords);
    if (this.validateStreamField(newRecords)) {
      for (var i = 0; i < this.state.rowData.length; i++) {
        if (this.state.rowData[i].name.toUpperCase() == newRecords.name.toUpperCase()) {
          toast.error("Already exist!");
          return;
        }
      }
      event.currentTarget.disabled = true;
      StreamService.CreateStreamByOrg(newRecords).
        then(
          response => {
            if (response.status === 201 || response.status === 200) {
              toast.success("Stream Added Successfully!");
              this.getStreamsByOrg();
              this.dialougeBox_close();
            }
          }
        );
    }
  };

  editStreamOnChagne = (e) => {
    e.preventDefault();
    let name = e.target.name.trim();
    let value = e.target.value.trim();
    console.log('editStreamOnChagne', name, value)
    this.setState(prevState => ({
      editdetails: {                   // object that we want to update
        ...prevState.editdetails,    // keep all other key-value pairs
        [name]: value       // update the value of specific key
      }
    }))
    console.log('editStreamOnChagne',this.state.editdetails)
    let errors = this.state.errors
    switch (name) {
      case 'name':
        errors.name = value.length < 1 ? " Stream name can't be empty !" : "";
        break;
      default:
        break;
    }
  };

  editStreamOn_Click = (e) => {
    e.preventDefault();
    e.currentTarget.disabled = true;
    let newRecords = this.state.editdetails;
    if (this.validateStreamField(newRecords)) {
      e.currentTarget.disabled = true;
      StreamService.UpdateStreamByOrg(newRecords).
        then(
          response => {
            if (response.status == 200 || response.status == 201) {
              toast.success("Stream Updated Successfully")
              this.getStreamsByOrg();
              this.dialougeBox_close();
            } else {
              e.currentTarget.disabled = false;
              toast.error("Stream Updated Failed")
            }
          }
        )
      return
    }
    else {
      console.log("In Valid Data ", newRecords)
    }
  };

  validateStreamField = (records) => {
    if (records.name == undefined || records.name == "" || this.state.errors.name != "") {
      let err = records.name == undefined || records.name == "" ? ' Please enter Stream Name' : this.state.errors.name;
      this.setState(prevState => ({
        errors: {
          ...prevState.errors,
          name: err
        },
      }));
      return false;
    }
    return true;
  }


  reset_onClick = (e) => {
    e.preventDefault();
    this.setState({
      newStreamData: {
        name: '',
        description: ''
      }
    })
    if (this.state.editStreamFlag) {
      this.setState(prevState => ({
        editdetails: {
          ...prevState.editdetails,
          name: "",
          description: ""
        }
      }))

    }
  }

  deleteStramOpen = (event) => {
    this.setState({
      deleteStreamFlag: true,
      selecteddeleteindex: event.rowIndex
    })
  };

  deleteStramOn_Click = (e) => {
    e.currentTarget.disabled = true;
    StreamService.DeleteStreamByOrg(this.state.rowData[this.state.selecteddeleteindex]["gkey"]).
      then(
        response => {
          if (response.status === 200) {
            toast.success("Stream Deleted Successfully!");
            this.getStreamsByOrg();
            this.setState({
              deleteStreamFlag: false
            })
          }
        }
      );
  };

  dialougeBox_close = () => {
    this.setState({
      addStreamFlag: false,
      editStreamFlag: false,
      deleteStreamFlag: false
    })
  }

  onFilterTextBoxChanged = () => {
    let filterValue = document.getElementById('filter-text-box').value;
    this.setState({
      filterValue: filterValue
    })

  };

  onGridReady = (params) => {
    this.gridApi = params.api;
  };

  render() {
    return (
      <AuthCommonLayout>
        <div>

          <div className='screenHeader'>
            <ComponentHeader
              isSearchable={true}
              path={this.state.navPath}
              backToParentClass={this.dialougeBox_close}
              onFilterTextBoxChanged={this.onFilterTextBoxChanged}
            />
          </div>

          <div className='screenBody'>

            <div id='CustomAgGrid'>
              <CustomAgGrid
                rowData={this.state.rowData}
                columnDefs={this.state.columnDefs}
                onGridReady={this.onGridReady}
                filterValue={this.state.filterValue}
              />
            </div>

            <div className="fixed bottom-6 right-10"  >
              <button onClick={(e) => this.addEditStreamOpen(e)} class={localControlsConstant.ToolTip.addbutton}>
                <HiPlus className={localControlsConstant.ToolTip.iconsize} aria-hidden="true" />
                <div class={localControlsConstant.ToolTip.tooltipGroup}>
                  <span class={localControlsConstant.ToolTip.tooltiptext}>{localConstant.STREAMS.ADD_STREAM}</span>
                  <div class={localControlsConstant.ToolTip.tooltipArrow}></div>
                </div>
              </button>
            </div>


            {this.state.addStreamFlag || this.state.editStreamFlag ?
              <div>
                <ReactDialogBox
                  closeBox={(e) => this.dialougeBox_close(e)}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  headerText={this.state.modelheader}
                >
                  <div>

                    {this.state.addStreamFlag ?
                      <AddStream
                        addStreamOnChange={this.addStreamOnChange}
                        addStreamOn_Click={this.addStreamOn_Click}
                        newStreamData={this.state.newStreamData}
                        reset_onClick={this.reset_onClick}
                        errors={this.state.errors}
                      />
                      :
                      <EditStream
                        streamgroupdetails={this.state.editdetails}
                        editStreamOnChagne={this.editStreamOnChagne}
                        editStreamOn_Click={this.editStreamOn_Click}
                        reset_onClick={this.reset_onClick}
                        errors={this.state.errors}
                      />
                    }

                  </div>
                </ReactDialogBox>
              </div>
              : null
            }

            {this.state.deleteStreamFlag ?
              <div>
                <ReactDialogBox
                  closeBox={this.dialougeBox_close}
                  modalWidth={localControlsConstant.Model.modalWidth}
                  headerBackgroundColor={localControlsConstant.Model.headerbg}
                  headerTextColor={localControlsConstant.Model.bodybg}
                  headerHeight={localControlsConstant.Model.headerheight}
                  closeButtonColor={localControlsConstant.Model.closebtncolor}
                  bodyBackgroundColor={localControlsConstant.Model.bodybg}
                  bodyTextColor={localControlsConstant.Model.bodytextcolor}
                  //   bodyHeight='150px'
                  headerText='Delete Stream'
                >
                  <div>
                    <div class='flex items-center h-16 pl-7'>
                      <h1>{localConstant.STREAMS.DELETE_STREAMS_CONTENT} <span class='text-delete-user-text'>{this.state.rowData[this.state.selecteddeleteindex]["name"]}</span>?</h1>
                    </div>
                    <div class="modal-footer flex flex-shrink-0 flex-wrap items-center space-x-3 justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                      <button type="button" class={localControlsConstant.Buttons.btnPrimary}
                        onClick={this.deleteStramOn_Click}>{localConstant.COMMON_CONST.DELETE}</button>
                      <button type="button" class={localControlsConstant.Buttons.btnSecondary}
                        onClick={this.dialougeBox_close}>{localConstant.COMMON_CONST.CANCEL}</button>
                    </div>
                  </div>
                </ReactDialogBox>
              </div>
              : null
            }
            <ToastContainer limit={2} autoClose={2000} />
          </div>
        </div>
      </AuthCommonLayout>
    )
  }
}
export default StreamGroup;
