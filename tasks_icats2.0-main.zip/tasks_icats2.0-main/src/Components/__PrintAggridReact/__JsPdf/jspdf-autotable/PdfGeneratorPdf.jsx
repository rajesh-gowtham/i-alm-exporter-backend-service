import React from 'react';
import jsPDF from 'jspdf';
import 'jspdf-autotable'; // Import the jspdf-autotable plugin

export const PdfGeneratorPdfWithImage = ({ data }) => {
  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(6);
    console.log(" doc ", doc);
    const tableHeaders = ['Image', 'Product Description', 'size', 'comments', 'netPrice',];

    const tableData = [];
    // tableData.push(tableHeaders); // Add headers as the first row

    data.forEach(item => {

      const rowData = [
        // item.buyerCode,
        // item.productName,
        // item.supplierName || '-',
        // item.quantity,
        // item.image,
        // item.size,
        // item.comments,
        null,
        item.brandName,
        item.productDescription,
        item.netPrice,
      ];
      tableData.push(rowData);
    });
    // Use the autoTable function from jspdf-autotable
    // doc.autoTable({
    //   head: [tableHeaders],
    //   body: tableData,
    // });
    // var base64 = getBase64Image(document.getElementById("imageid"));

    const tableOptions = {
      startY: 5, // Adjust the Y position
      startX: 5, // Adjust the X position
      head: [tableHeaders],
      body: tableData,
      didDrawCell: (item) => {
        console.log(item);
        // Check if it's the cell where you want to add the image
        if (item.section === 'body' && item.column.index === 0) {
          // Add the image to the cell
          // const imageUrl = 'https://play-lh.googleusercontent.com/npT0tPtiygkDE--y1f6rEGMWFliCPQm9fVB0g72ufN1XGcWimUpVmGaM4lZsr3U_z7MQ'
          console.log("iii ", data[item.row.index]);
          const imageUrl = data[item.row.index]?.image // data[index]

          doc.addImage(imageUrl == null || imageUrl == undefined ? 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALwAAAELCAMAAABULxzgAAAAclBMVEX///9UVFRNTU1SUlJGRkbGxsbR0dFISEjX19eHh4egoKBERERLS0v8/PxBQUFWVlby8vJbW1thYWHr6+u5ublsbGx7e3t1dXXDw8NkZGTg4OCmpqZtbW329va2traMjIysrKyAgICWlpaioqI4ODg1NTWh3CQuAAATBklEQVR4nO1dCZuyOs+GBq0jlAqMCypuM+f//8UvSdl0QEDxgff6uK9z5nFp692QbkmbWtaECRMmTJgwYcKECZ+AUvh/tJiPBIuI+LSnvzhr13XGAem6+rxoTT3a+AJsbY8DoDUIfxO14z6TYmjCfyHkjNW5ibtv67FIvQx31sRcWXvXpAUQIwGkKuzuG8nHwCml2HyNBBuQRpxhk+h3DnEH57tD3/RpqJNkibq7hoRroEqKpif0j7HH3g91Z/28u48cpK6dWZdB4fNQ1twnfZDP+8udxOcD639EqgNYI+Rzvbl4pDSHf8SoAw409niXp2mWlMZp7FH/PWbU44jl0zT/++TlRL5fTOSHwkR+KEzkh8JEfihM5IfCGMm3XvOMkXxrjIn84rBZx8evU0s72IjIq4NwBCCE5x9nVhtL2GjIz22Zm8G0cDarNpo/CvLKuvj3Zjxh71vIfhTkkfujIRTkvln2IyDPBpg/VlwIW5h/R0BeVVrPxa0x5wjIWz+i0mnRaAAeA3kFUCV523vOyhoF+blb7bYA2dRkR0B+6VVyt7XfpDcjIL+t1ppGE+ooyAd15MWlIecIyNc66rwmw/QIyIe15E8NOUdAfgM1sm/8yRGQP9T2Nk0T+xGQXzjV5EE35eyf/H437+h4q1Z63eCvsT5Afuc7/rVd0gwnWUEdbG/VlLFv8ntaVcjmCeEdwqqe3mnqa3onn2ibiDjf7VgzlNpXiF5s/+1iBNdtGzM1B3/RyeM8f1gF4jK2xVqkX/LWj8xm5qK1/YIzzr37BYmzTVrk61Vt5n463qDyxKqT7KONK0xObKvCbeex7pN8VB5txKYTeRT+RkqPttK44tZ6+1Vv5NW61GloWzYuhO4yY01Xs8PtfDstWu/b65H8+X6Y1+7u09tE+iN/ch86DNtvYXp5C72R31fMUCD6LPu+yCe6YpQUsWpjL30ZvZBHgttqw9H1o6LvifyPU72gcD66xagftZnVmF5wQfFJ+2wv5CNZZwDAfPvPKU4f5FXllDZHm1nKa3ibPMr1SzzbZyzWrVw0r6AHyT+OTo9qL8+f6nLeJ7+o8AyUAdq59E7b4G3yUYt99f6HNsO+Tf7Y5lCA/Mw25PfIK+tWsfysUp3kE432TcnvnjfWgn2L5fS/Ja+sqmV/jeLcPsD+LcknNd6kKrin/tm/Rb56KlkDf94399fJoxh/WisNQ0R9i/4Nyc/++NyfA4LxkMd1X51XoE703awhHyOvmqaSlehmDfkYecu6ei+cWHO7GGA/R/5S485oQEcDLI8lp9pu6kXyf8y6rUBHKbsYYAkn3/M3fZJXkejYVnN0soYoWtljN1VnhHiN/AuNNYPXwRqC8z4+X2bjeqY38rjue5U7EvlpTV19OSaPdiqnRq+Qf7GxZmhtgFXbYgivtNi/QH5RY2BqC3DaLU2S8jpHuxX+ta7klRV1m9FUsYc2uyZX4d20DyrGiM7kVfx6Y80gjo3UrSi479B0xZHpjuQVNta3uWOX8/WcuTKHXe8B7vzhgXUjr6zL20rDcC/P2S/cvwOJBvkQ6aATeWXN3+tocvyVYgn0M1W6qeHBCtFN8u831ow8PNs1uaudfMi7BU03ydduB3uBvq41wJ58u8YIp0GXd1N0Ir/pM+pEzeYCnM48M6eIoNTNdiHfzsDUErUTlttzU5CIiyfWnvx8V+f+eBX+peLHzvLpr2gcJLpLXtxk39E+tPtnmaE2NRvOShD59L41ebt6q/V7eIxZoNZt5qtetpOqPflPAIK7lckqbvdLmbtiWPL31pCVBminmuk+sIHJl7ej7TtYPuWB1ohDk7f9bKa79zqMgBp7qhGQN9YQ1dUeoanSw5Mna4iydl1nfORbH548b0c7+d1nTe5iPjx5W1wbXLnVAM+MnoOS1xpesXvSTIGyDSz59zCRHwoT+aEwJHnoMKOpxIDkYX08vresH448bMMwPOp31jnDkQ+OcbgO3jJ/9kxet4ptyUn0cR0E6xGR13Yct0hFyybb3gZBHNcesGuDviUftiAPEJPA9fEY22/Ffu2PvMY1dUjkIaAKBGFANjr8B9J3YYjLVA06DO0wxsaKCemkfah1zAZ5+qKbiaVPyYdBECL5AP+BONBYFYi1TVUJ6Z2tY+zY8W2siWWIH1E6rhQ+CU5gd2oCPZInMih5lGUI+GJt40uNIg4CmwSNCo6vsDoxfh2HMSdCacf0DYo/DNb0FIYhD8TSZp0QKOo4iFHwQQD4HOgjIotPhBLgnxiFjYlQ+uk3QaCxcnE3B3WPkg/pt5EW9iDIOlxrViRD3vynQwDuXygVfs7kgb8JuOvpuhGmR7VBMkiJ2h0qMCLW1AgCfhjUMPElPRCgusUBV4YSY3VYtSg3ZuzAv0fy1LMgS3sd00EvEibrP2k3do0xv4mp96FGbLofahN2uMZvAmytqDnAndQA5KnJktjSRhdQE6ABibpM+kfbYZoiT2n+wwysMEEAdX6Rf0HeTinlf9Oa8Mk5eq0f0ucVyD8YmPwjP52zfByDiqq+Ns5OK6mhMJEfChP5oTCRHwoT+aEwkR8KE/mhMJEfChP5oTCRHwoN5C/Nm9YGREN4wtnz3YIDoyEISfTKnox/Brfh8NKxvy3EfUND00GCtoelB4BuuvOH7lAbmmQdIG4QPN3lNVL2j8cBqiRvzd1Rsn96AKLAXPw9gTI0QHitzpUra3V1xjVWgXCvraLUM/a3cDS3lLquG972nS5ZtVb7xUiwX3U9Tj6qewOt8fGZMGHChAkTJkyY8P8ZfLryE1PU1uGh30PSGKl/SCzo5vvrt5GEul6/riYKBYXRvmyF73vr5cPSLMEsVzbjRpsr5c5WzDN+d1VF2fTB5sGQsfjZhNoOjucThwwwiQyu1SfIazF3AYRwE0NeCDAB/vHtQXq8xwqE/3UXESDxBZjIHnt8hcv97BDxl4f5wc8T/0i6ue4+3NZ34AuyrmM+6dOvzny+344hwo7k+fR9esOWAtuW5jhocsQvwAbelifuojYlPkdMtPILOUCln7PhuTCShkA7iCEoskZrsnSZQNMa+Nz3rHT6EV4iTzdsKb7CSntG8hzCT4jtVkiOq5AUilOQ58zadky4DqShy+Qjc6C0dAvT3ghdOq7jO1JecvKeS7YD12+8haSSvDn9XpA/0MfuATUgWbo2aFHSxoL8TvLGv9SPQbFadOmmsZNni3OAZWcheJKATlTLcLdPktX+e73IqiyWmQXjJfK2Py9LfuWDrbPrLTgIS+kSq4L8t7Thqo1hVKHOwQ3oVGia7gi2N7tixY/c/pV18yguyUM0IZJ84z1NT8iHZ2HULSd/8HTKj0DR/0teooL8RWBr2QCwpswdW868wquxwpKd6CJRrYwisRr9ufCDJf8GeXshTUNF4RnyZP4uXCs7jzbdVpD/QcW4LYXJcxO2TxFbsru6SKfA2ruQ9QFYVQoGUoJKyTdfWlNPXlhbwB4gycmT0LTMuzzuRpyoeJuRR75iOfNMv6EBjpZb3BiFTYBaiuCg74Qtlv5wC5lK1eaW6nzHUHREXiZzpOcdLGUbtaEusNxt0b7bInZNQf4Ktjis6NcViliLg0WiMAG+VEr1jA/RITko6iGNCJLDxcBKexvBnY372zGGIZNfWUebf0IbyVOBUHrApPRO3hMU5LdEnu5Lc/bWSWpsqiJtHcpa4EPwVxQJPtXAhAzSHve40a/wEDK07vt5r+l2uAryKI4FEvJ+rKCafFxDHiuFbQ2bO/7d4FNTFuQD3k1oHoYTehjnjLww5E1sF1hn5EEwukaPTMmTEEFYMVbh23zIJTOURQ+8Sm1C1LITtmdbfFkCvBsrGDPlPHCd7XYzqrmgbDRAOTzRi/5z3TJ5OKZzm47xajPyqLKoohuj8xGHNczGVLWiX5L5/LIgD9y3rPB9vJe2nJsZATVPtadQ5CClZOcLP7Yg78LUfh9Ryox8cStct5kykedu+gsLO54NedO2cjFQHIWShy4nr6RhE+NAhB2PY7EiGScq9YvFHntsBxwtTUMeX/GO/KUT57/kSX4Qp/08qrFd/A75m0URJDAnnzhGpktiRarDSU03RXmA+xCcimn8TBntzmP3lMi/NUiZqdQPu6cMeXrodBUN45t+tHTrXE6e2h1NGxbc/iQFTtwQZ8vEF4PtnoHTOr4Yhp+nLeafIG/iWKcTM46xxdMQhVMb0OVLyHLye9dUSvGMDAc1ZV2FaZ0468k1mR4jKwYHPQbnRrcEJUGpwYplZOq577ZwK8hbJ1GQXwk6VSlhuwGPJpWxqpgSY1du7gGkqprZOem1m36SzeVog4nRJYoRiqsDF8VBsWMy8qhyxqvn/9etu8l6G0JQkDdBAs1iBEfKsCyRnDzFzeN1E05+Nc+NaMJAHylWpFJ684SspZ+fOcLxsOjnU2jZkTwuAzN9nvm0akuXgdHWN2focRl4u+vBkl9cBhL5bwfz0lf7X0+aQpYeF0clefkSYIMLPbq3Dp/ePPSN55qXgUzehQIdA5Mv1tvt2pDHzmy73R7zBfjiHEpXeuufh+lSglm2xOz7iMnZPPKN4O9ORy7uhwrKvfC7Y5qBPtgfNqHtQbC9nfh+pDl9meHYaTVSFmmm1qXPVlH0NxqfSlOruhJUVfq7T5Jug1EtVPGbjyX+rYyVJ1SG/H0eY4Iw9Sq+qYtZXFGpj172NGHChAkTJkyYMGFCFaITLSROtMxTil6f8qXHnt6aa95mlOi72Bi+o4Q0f51lmSvKzFYCKlnsTpflcvlzma3SmfDqdFceLmxKOLW9ne3gk8mTg6oqa4sLJz810OC6ykm/sJSQZBfNbWhWTF8RuS2++O9+pUUrVUr+m3P7xlUi2yKldFPHZvTreU75UndNWVL8Nmyfz0ERj3VqomODRW6jJMMoGNtiGqG+sLWS2Zjt92wleLSq840l2s5vAtjx+RR2DWphxBG5+LJ8VUA5aFvbW+0jn65X12A8CSv6lcwoSYyFqdRS8CXshWunIE8GpeixTArmDlrma1i6SVzgBywDtojQkZW/5I2tWLSV/Deu9olAanM4QuGWISuGNOoUgBZXKNkrn5I/eTaXmVv2yMFDLkE118YErmrIHwyWrXSezXNyFqJcz9nv5mWSFcd4s/e+DcHcg8Kj+pT8FsDboeqIzMpG5I05iDwOrJeV5KEN5wKJSyanG5nHjNWf7EPCShmnVjA6EAbXBGuQe1SfkV+hkjgr8uZkLuGCvHK40BrJQ7flN5mrNJuwfdMYY8g81hdPZxqEVL0T/iUTl2okj80TbNRHO7+CgXTe2LJmDhZ6seokn3sEWpEnj90XW7fTxkin7jyOiU3G6rQZu+wX+fGwXqsm8myGRyXEMrV3yMmz5JMdqXygaiWfqAwtuCtt2if5dMwzJts2tkuFDx8yF+Q32b7ZQ5YZMp9JPhGQeRzsuCBv6yDwqOGu2U5W3WCNFTN/vs+ReewuRW9NAe7I8Dor3MFXs/VAAWSN4Bn5OT0nLPNQlMnkjc0WNoqZVZO3M/JtgP03d39kaE8N/HTUlEjTLgiPtYYGK4eqQXb21LP8hDz2sOzY2eMIkjZwJk8OP+7Ks0HqXfLUny1VkiQh0Hk8ldXjbBlnnhGlQ7sHVKJIfdLx4Al5FLD4wTJVkLtDqcHC9fDzBbQvyP+u0XmsrCQ4YRu12fugcbz2XT7tld6VoHl7D3WU6Sh9posZHN/3vcxP+Yw8Vd7GMn3ebGNmF9xgWQWX5GegjA29TQvyJ+OF0iYOqPzmLKg34Ef0VbrfiqclHJOMdg0Jlko9+YNIQ5jZqZ/KKvfzvP+AdLCSvOjSzxMFYEc6Re9OGyM1YjmnTSymbNqHoAWmMk4BMx7Uk+cyPSqUNfz6QH6Z+qfeHqRox4MdX2g28UO/5PL2BovmactAk9ZQYSRKcaNEl03unC+Rv59VEik4FmWyMEvkv8D46d4mz/OlSyEwJ9NxbfNDNFrDW29MqTwzCerJo6pymelgEGee6J3M9t3x7h7y3XAl6+c2zbW4lnYU8EYeU9jc4fiMaV/Dv5L27uSyNDPaO/I41fV5w8mZ3+usMj/YwnkKyduGlov57sw7DsK0t8H5g8F/CyYPEGiDrfUcKvW7pnWk3iV9bMarmt3yRS3XbMOzTE/PrvA78hmQKE30IJuPkW8ZICWvheNKQeEK+Z67qHxbHknQhCZMt1c2naKmqyi0XWzao8zpBPzMIRGchDe10cwhv1Zvl6206sibbUtZmeRrpQa+y29Owl4+4MLuyDv7+5VU4xFw5Og7zm++O+fmO65vrlCc/ZI/1+w8iOh1rosrzOLQkjWmvLyG9WV2qFL6Z+vLd+R/s/IvYJnW7tecunSc4Cv9MvotTmNKUhsoH89s3BuqVgR1/9a41/hlovLXuRnAyvLkeZNVCclDmUlapqKDn/P5onDOp7+RQT28b3Li30+dcy9madO5+rNRvGngU6pc8mPZ5nWVh/HvFHhyCk6YMGHChAkTJowU/wdOoFtF0kURVQAAAABJRU5ErkJggg=='
            : imageUrl, 'JPEG', item.cell.x + 2, item.cell.y + 2, 8, 8); // Adjust coordinates and size as needed
        }
      },
      // fontSize:6,
      // fontSize:7,

    };
    doc.autoTable(tableOptions);
    doc.setFontSize(8);
    doc.setTextColor("#000")
    console.log(" inside ", doc)
    doc.save('table.pdf');
  };
  const getBase64FromUrl = async (url) => {
    const data = await fetch(url);
    const blob = await data.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => {
        const base64data = reader.result;
        resolve(base64data);
      }
    });
  }

  return (
    <button onClick={generatePDF}>Export PDF</button>
  );
};


export const PdfGeneratorAs5Columns = ({ data }) => {
  const generatePDF = () => {
    const doc = new jsPDF();
    const tableHeaders = ['Buyer Item Code', ' Brand Name', 'Product Description', 'Lead Time', 'Net Price'];
    const tableData = [];

    data.forEach(item => {
      const rowData = [
        item.buyerItemCode || '-',
        item.brandName || '-',
        item.productDescription || '-',
        item.leadTime || '-',
        item.netPrice || '-',
      ];
      tableData.push(rowData);
    });

    const tableOptions = {
      startY: 5, // Adjust the Y position
      startX: 5, // Adjust the X position
      head: [tableHeaders],
      body: tableData,
      didDrawCell: (item) => {
        console.log(item);
        if (true) {
        }
      },

    };
    doc.autoTable(tableOptions);
    doc.setFontSize(8);
    doc.setTextColor("#000")
    console.log(" inside ", doc)
    doc.save('table.pdf');
  };
  return (
    <div>
      <button onClick={generatePDF}>Export PDF 5</button>
    </div>
  )
}
