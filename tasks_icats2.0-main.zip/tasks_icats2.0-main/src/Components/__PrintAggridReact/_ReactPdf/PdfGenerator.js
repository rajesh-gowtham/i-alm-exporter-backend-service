import React from 'react';
import { PDFDownloadLink, Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#E4E4E4',
    padding: 10,
  },
  header: {
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'center',
  },
  footer: {
    position: 'absolute',
    fontSize: 10,
    bottom: 10,
    left: 0,
    right: 0,
    textAlign: 'center',
    color: 'grey',
  },
  table: {
    width: '100%',
    flexDirection: 'column',
    borderWidth: 1,
    borderColor: '#333',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  tableCell: {
    flexGrow: 1,
    padding: 6,
    borderRightWidth: 1,
    borderRightColor: '#333',
    overflow: 'hidden',
  },
  lastCell: {
    borderRightWidth: 0,
  },
});

const PdfGenerator = ({ data }) => {
  const calculateCellHeight = (text) => {
    const lineHeight = 15; // Adjust this based on font size and line height
    const textHeight = Math.ceil(text.length / 40) * lineHeight; // Assuming each cell can fit 40 characters per line
    return textHeight;
  };

  const rowsPerPage = 25; // Adjust this based on the number of rows per page

  const pageCount = Math.ceil(data.length / rowsPerPage);

  const pages = Array.from({ length: pageCount }, (_, pageIdx) => {
    const startIdx = pageIdx * rowsPerPage;
    const endIdx = startIdx + rowsPerPage;
    const pageData = data.slice(startIdx, endIdx);

    return (
      <Page size="A4" style={styles.page} key={pageIdx}>
        {/* Header */}
        <Text style={styles.header}>Table PDF Example</Text>

        {/* Table */}
        <View style={styles.table}>
          {/* Table header */}
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Buyer Code</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Product Name</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Supplier Name</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Brand Name</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Product Description</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Quantity</Text>
          </View>
          <View style={[styles.tableRow, styles.tableCell, styles.lastCell]}>
            <Text>Net Price</Text>
          </View>

          {/* Table data */}
          {pageData.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.buyerCode}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.productName}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.supplierName || '-'}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.brandName}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.productDescription}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.quantity}</Text>
              </View>
              <View style={[styles.tableCell, styles.lastCell]} fixed>
                <Text>{item.netPrice}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Footer with page number */}
        <Text style={styles.footer} render={({ pageNumber }) => (
          `Page ${pageNumber} of ${pageCount}`
        )} fixed />
      </Page>
    );
  });

  return (
    <PDFDownloadLink
      document={
        <Document>{pages}</Document>
      }
      fileName="table.pdf"
    >
      {({ blob, url, loading, error }) =>
        loading ? 'Loading document...' : 'Export PDF'
      }
    </PDFDownloadLink>
  );
};

export default PdfGenerator;
