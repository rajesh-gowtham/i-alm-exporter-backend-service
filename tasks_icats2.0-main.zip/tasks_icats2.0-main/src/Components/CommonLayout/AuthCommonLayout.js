import React, { useState,useEffect } from "react";
import SideBar from "../Sidebar/Sidebar";
import Header from "../../Header/Header";
import MobHeader from "../../Header/MobHeader";
import { BrowserView, MobileView, isBrowser, isMobile } from 'react-device-detect';
import { useLocation } from "react-router-dom";
//localStorage.getItem('Auth Token')
//SCREEN ID -3053
function AuthCommonLayout({ children }) {
    const [toggle, setToggle] = useState(false);
    const location = useLocation();
    const [moduleName, setModuleName] = useState('')

    useEffect(() => {
        const currentPath = location.pathname;
        let firstWordValue = currentPath.split('/')[1];
        if (firstWordValue == 'dashboard') {
            setModuleName('dashboard')
        }
        else if (firstWordValue == 'privilages' || firstWordValue == 'Roles' || firstWordValue == 'users') {
            setModuleName('Security')
        }
        else if (firstWordValue == 'fields_columns' || firstWordValue == 'transactions' || firstWordValue == 'Settings') {
            setModuleName('Settings')
        }
        else if (firstWordValue == 'streamgroup' || firstWordValue == 'systemreference') {
            setModuleName('Others')
        }
        else if (firstWordValue == 'TestGroup' || firstWordValue == 'Scenario'|| firstWordValue == 'Sequence') {
            setModuleName('Test Group')
        }

    }, [location.pathname])

    return (
        <div class="h-screen w-full flex antialiased text-gray-200 bg-white overflow-hidden">
            <div class="flex-1 flex flex-col">
                <main class='flex-grow flex flex-row min-h-0'>
                    {/* SIDEBAR */}
                    <section class="flex flex-col flex-none transition-all duration-300 ease-in-out">
                        <div class="contacts flex-1  max-h-[100vh]">
                            <SideBar toggle={toggle} />
                        </div>
                    </section>
                    <section class="flex flex-col flex-auto">
                        {/* HEADER */}
                        <div class="">
                            <BrowserView><Header setToggle={setToggle} toggle={toggle} moduleName={moduleName}/></BrowserView>
                            <MobileView><MobHeader setToggle={setToggle} toggle={toggle} /></MobileView>
                        </div>
                        {/* MAIN PAGE */}
                        {moduleName == "dashboard" ?
                            <div class=" bg-[#ebeef6] chat-body flex-1 overlay px-2 py-5 max-sm:px-0 max-sm:py-2">
                                <div class='rounded-md p-7'>
                                    {children}
                                </div>
                            </div>
                            :
                            <div class=" bg-[#ebeef6] chat-body flex-1 overlay p-5 max-sm:p-2">
                                <div class='bg-white min-h-full rounded-md max-sm:px-2 pb-[15px]'>
                                    {children}
                                </div>
                            </div>
                        }
                    </section>
                </main>
            </div>
        </div>
    )
}
export default AuthCommonLayout;
