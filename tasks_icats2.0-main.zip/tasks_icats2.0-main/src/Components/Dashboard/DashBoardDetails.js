import React from "react";
import { GoDatabase, GoDotFill } from "react-icons/go";
import { TbRefresh } from "react-icons/tb";
import { getlocalizeGridData } from "../../CommonUtils/getlocalizeData";
import { AgGridReact } from "ag-grid-react";
import ReactApexChart from "react-apexcharts";
import GaugeChart from "react-gauge-chart";
import { connect } from 'react-redux';
import '../../CSS/Dashboard.css';
import { isMobile } from "react-device-detect";
const localConstantAGGrid = getlocalizeGridData();
//SCREEN ID -3025
class DashBoardDetails extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            UserRole: window.localStorage.getItem("RoleName"),
        }
    }
    render() {
        const UserChart = {
            options: {
                legend: {
                    show: false
                },
                plotOptions: {
                    bar: {
                        distributed: true
                    }
                },
                chart: {
                    id: 'column-chart'
                },
                toolbar: {
                    show: false
                },
                xaxis: {
                    categories: ['Acive', 'In Active', 'Created']
                },
                colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0']
            },
            series: [
                {
                    name: '',
                    data: [6, 3, 2]
                }
            ]
        };
        const ScenarioChart = {
            Series: [3, 2, 2],
            Options: {
                dataLabels: {
                    enabled: false
                },
                labels: ["WS ", "LS", "HK"],
                chart: { type: 'donut', },
                responsive: [{
                    breakpoint: 480,
                    options: {
                        chart: { width: 200 },
                        legend: { position: 'bottom' }
                    }
                }],
                plotOptions: {
                    pie: {
                        //   size: '100%' 
                        expandOnClick: false,

                        donut: {
                            size: '65%',
                            background: 'transparent',
                            labels: {
                                show: true,
                                name: {
                                    show: false,
                                    fontSize: '22px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 600,
                                    color: "black",
                                    offsetY: -10,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                value: {
                                    show: false,
                                    fontSize: '16px',
                                    fontFamily: 'Helvetica, Arial, sans-serif',
                                    fontWeight: 400,
                                    color: "black",
                                    offsetY: 16,
                                    formatter: function (val) {
                                        return val
                                    }
                                },
                                total: {
                                    show: false,
                                    showAlways: false,
                                    label: 'Totalss',
                                    fontSize: '16px',
                                    fontFamily: 'Roboto, sans-serif',
                                    fontWeight: 600,
                                    color: '#373d3f',
                                    formatter: function (w) {
                                        return w.globals.seriesTotals.reduce((a, b) => {
                                            return a + b
                                        }, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };
        const GroupChart = {
            options: {
                legend: {
                    show: false
                },
                plotOptions: {
                    bar: {
                        distributed: true
                    }
                },
                chart: {
                    id: 'column-chart'
                },
                toolbar: {
                    show: false
                },
                xaxis: {
                    categories: ['Regression', 'Sanity']
                },
                colors: ['#008FFB', '#00E396', '#FEB019', '#FF4560', '#775DD0']
            },
            series: [
                {
                    name: '',
                    data: [5, 2]
                }
            ]
        };

        const { UserRole } = this.state;

        return (

            <div className="w-full  my-auto ">
            <div class="First Row" className="flex  justify-between h-[170px] max-sm:flex-col max-sm:h-auto max-sm:space-y-7 max-sm:space-x-0 space-x-8  mb-8 ">
                <div className="COL-1 w-1/4 max-sm:w-full bg-white  rounded-[10px] group">
                    {UserRole == "Admin" ? <USERACTIVITY Header={"USER ACTIVITY "} value={45} /> : null}
                </div>
                <div className="COL-2 w-1/4  max-sm:w-full bg-white  rounded-[10px] group">
                    {UserRole == "Admin" ? <CLOUDUTILIZATION Header={"CLOUD UTILIZATION "} value={24} /> : null}
                </div>
                <div className="COL-3 flex flex-col items-center  w-1/4  max-sm:w-full bg-white  rounded-md">
                    {UserRole == "Admin" ?
                        <TOTALBARCHART Header={"TOTAL USERS "} options={UserChart.options} series={UserChart.series} />
                        :
                        <TOTALBARCHART Header={"TOTAL GROUPS "} options={GroupChart.options} series={GroupChart.series} />
                    }
                </div>
                <div className="COL-4 flex flex-col items-center  w-1/4  max-sm:w-full bg-white  rounded-md">
                    <TOTALSCENARIOS Header={"TOTAL SCENARIOS"} options={ScenarioChart.Options} series={ScenarioChart.Series} />
                </div>
            </div>
            <div class="Second Row" className="flex  justify-between  h-[380px] max-sm:flex-col max-sm:h-auto max-sm:space-y-7 space-x-8 max-sm:space-x-0 mb-8">
                <div className="COL-1 max-sm:w-full w-1/3 bg-white rounded-md">
                    <TIMELINE />
                </div >
                <div className="COL-2  max-sm:w-full  w-2/3 bg-white rounded-md">
                    <EXE_HISTORY />
                </div>
            </div>
        </div>



        );
    };
};
export default connect()(DashBoardDetails);


export const USERACTIVITY = ({ Header, value }) => {

    return (
        <>
            <div className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header} </div>
            <div className="flex justify-center pt-4 max-sm:pb-3 ">
                <div class="self-center">
                    <div className="gauge-container" style={{ width: isMobile ? '250px' : '180px', height: '100px' }}>
                        <GaugeChart
                            id="gauge-chart"
                            nrOfLevels={2}
                            arcWidth={0.14}
                            // arcWidth={0.2}
                            percent={value * 0.01}
                            textColor="white"
                            text="disable"
                            needleColor="blue"
                            needleBaseColor="gray"
                            startColor="#3f51b5"
                            endColor="#ff9800"
                            arcPadding={0.00}
                            cornerRadius={0}
                            // formatTextValue={value => value * 1}
                            minValue={0}
                            maxValue={100}
                            hideText={true}
                            // needleBaseColor={'#000'}
                            // needleColor={'#f00'}
                            needleBaseRadius={0}
                        // needleLength={2}
                        // arcPadding={0.02}
                        // cornerRadius={3}
                        // textColor={'#000'}

                        />
                    </div>
                    <div className="flex justify-around text-start text-sm">
                        <span className="text-[#13bf1b]  ">Low</span>
                        <span className="text-blue-800 text-xs font-semibold ">{value}GB</span>
                        <span className="text-[#f33819]">High</span>
                    </div>
                </div>
            </div>
        </>
    )
}

export const CLOUDUTILIZATION = ({ Header, value }) => {
    return (
        <>
            <div className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header} </div>
            <div className="flex justify-around mt-4">
                <GoDatabase color="#feb019" size={isMobile ? 70 : 60} />
                <div class=" text-[#252422] text-base font-roboto font-medium">
                    <div className="text-right self-end">Capacity</div>
                    <div class=" text-[#252422] font-roboto font-medium text-lg">{value}GB/80GB</div>
                </div>
            </div>
            <div className="flex border-t-[1px] pt-1 max-sm:py-2 space-x-2 mt-4 mx-4  border-[#a49e93] text-[#a49e93] text-base items-center text-center max-sm:justify-center">
                <TbRefresh color="#a49e93" size={isMobile ? 35 : 30} />
                <div>Updated Now</div>
            </div>
        </>
    )
}

export const TOTALBARCHART = ({ Header, options, series }) => {
    return (
        <>
            <span className="text-black font-roboto text-center self-center mt-2 font-semibold">{Header}<span class="text-blue-600 text-xl">/11</span></span>
            <div id="ActiveUserChart " className="flex-1 mb-1">
                <ReactApexChart options={options} series={series} type="bar" height={isMobile ? '180px' : '135px'} />
            </div>
        </>
    )
}

export const TOTALSCENARIOS = ({ Header, options, series }) => {
    console.log(" mobile " , isMobile)
    return (
        <>
            <div className="text-black font-roboto text-center self-center mt-1 font-semibold">{Header}<span class="text-blue-600 text-lg">/07</span> </div>
            <div id='scenariosChart' className="flex-1 max-sm:pb-6 max-sm:pt-1">
                <ReactApexChart options={options} series={series} type="donut"  height={isMobile ? '225px' : '135px'}/>
            </div>

        </>
    )
}

export const TIMELINE = () => {
    const data = [
        { time: '1 hour', content: 'Aravindh has tested regression testing', status: 'Passed' },
        { time: '1 day', content: 'Ivan lendil has tested sanity testing', status: 'Passed' },
        { time: '2 day', content: 'Aravindh has tested integration testing', status: 'Failed' },
    ]

    return (
        <div class="mt-1">
            <h1 class="text-xl text-center font-semibold text-black">Timeline</h1>
            <div class="container my-4">
                <div class="flex flex-col md:grid grid-cols-12 text-gray-50  max-sm:ml-10">

                    {data.map(item => <div class="flex max-sm:justify-center  md:contents">
                        <div class="col-start-2 col-end-4 mr-10 max-sm:mr-8 md:mx-auto relative ">
                            <div class="h-full w-[2px] flex items-center justify-center">
                                <div class="h-full w-1 bg-gray-300 pointer-events-none"></div>
                            </div>

                            <div class={`w-6 h-6 absolute top-1/2 -mt-3 -ml-[11px]  bg-white rounded-full flex items-center justify-center border-2 border-${item.status == "Passed" ? '[#a7dff3]' : '[#f5a1aa]'} shadow text-center`}>
                                <span><GoDotFill color={item.status === "Passed" ? '#3a7afe' : '#f25767'} size={20} /></span>
                            </div>
                        </div>
                        <div id={item.status == "Passed" ? 'timelinearrow1' : "timelinearrow3"} class={`h-[70px] relative border-l-4 border-l-${item.status == "Passed" ? '[#3a7afe]' : '[#f25767]'} col-start-4 col-end-12 px-2 pl-3  my-4 mr-auto  w-full max-sm:w-2/3`}>
                            <h3 class="font-semibold text-sm mb-1 text-[#89879f]">{item.time} ago</h3>
                            <p class=" text-sm  w-full text-[#3d4465] font-medium">
                                {item.content} <span className={`text-${item.status == "Passed" ? 'blue-500' : '[#f25767]'} font-semibold`}>{item.status}</span>
                            </p>
                        </div>
                    </div>
                    )}

                </div>
            </div>
        </div>
    )
}

export const EXE_HISTORY = () => {
    const rowData = [
        { name: "Aravindh", orderid: "#756", role: "Tester", date: "06-04-2023/11:07 AM", status: 'Passed' },
        { name: "Ivan Lendil", orderid: "#757", role: "Analyst", date: "06-04-2023/09:54 AM", status: 'Aborted' },
        { name: "Akash", orderid: "#786", role: "Tester", date: "06-04-2023/08:30 AM", status: 'Failed' },
        { name: "Naveen ", orderid: "#758", role: "Tester", date: "05-04-2023/04:04 PM", status: 'Passed' },
        { name: "Naveen ", orderid: "#758", role: "Tester", date: "05-04-202301:20 PM", status: 'Passed' }
    ];
    const columnDefs = [
        { headerName: "USER ID", field: "orderid", minWidth: 100, flex:1 },
        {
            headerName: "NAME", field: "name", minWidth: 150, flex:2,
            cellStyle: { color: '#212845', fontWeight: '400' }
        },
        { headerName: "ROLE", field: "role", minWidth: 130, flex:1 },
        { headerName: "DATE", field: "date", minWidth: 150, flex:2 },
        {
            headerName: "EXE. STATUS", field: "status", minWidth: 130, flex:1,

            cellRenderer: (params) => {
                if (params.value == "Passed") {
                    return <span class="text-[#13bf1b] bg-[#13bf1b26] text-xs py-[3px] px-2 rounded ">Completed</span>;
                }
                else if (params.value == "Failed") {
                    return <span class="text-[#f33819] bg-[#f3381926] text-xs py-[3px] px-2 rounded ">Failed</span>;
                }
                else
                    return <span class="text-orange-100 bg-[#ec842e] text-xs py-[3px] px-2 rounded ">Aborted</span>;
            }
        }
    ];
    return (
        <div>
            <h1 class="text-lg text-left ml-5 p-2 font-semibold font-roboto mt-1  text-black">Recent Execution History</h1>
            <div className="ag-theme-alpine relative p-2" id='secondaryGridBorder'>
                <AgGridReact
                    rowData={rowData} // Row Data for Rows
                    columnDefs={columnDefs} // Column Defs for Columns
                    animateRows={true} // Optional - set to 'true' to have rows animate when sorted
                    suppressMenuHide={true}
                    rowSelection='multiple' // Options - allows click selection of rows
                    sideBar={'filters'}
                    pagination={false}
                    rowHeight={localConstantAGGrid.AGGrid.RowHeight}
                    cacheQuickFilter={true}
                    domLayout='autoHeight'
                    gridOptions={localConstantAGGrid.AGGrid.gridOptions}
                    suppressRowClickSelection={true}
                    suppressRowHoverHighlight={true}
                />
            </div>
        </div>
    )
}