import React from "react";
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import '../../CSS/Model.css';
import '../../CSS/Login.css';
import { signInWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../../firebase/firebase';
import { BsKey } from 'react-icons/bs';
import { HiOutlineAtSymbol } from 'react-icons/hi';
import { getlocalizeData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import { AiOutlineEyeInvisible, AiOutlineEye } from 'react-icons/ai';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { validEmailRegex, SetLocalStore } from "../../CommonUtils/getLocalizeFunction";
import { GetOrgDetailsbyEmail, SetMasterBizUnit } from '../../CommonUtils/UtilOrganization';
import icatlogo from "../../Images/icatSidebar.png";

const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
var userlogin = { email: "", password: "" };
let resetEmail = '';
//SCREEN ID -3014
class Login extends React.Component {
    constructor() {
        super()
        this.state = {
            passwordEye: false,
            isValid: false,
            resetpassword: false,
            PageProcess: false,
            processtext: 'Loading.',
        }
    };

    componentDidMount() {
        window.localStorage.removeItem('uid');
        window.localStorage.removeItem('useremail');
        window.localStorage.removeItem('stsTokenManager');
        window.localStorage.removeItem('lastLoginAt');
        window.localStorage.removeItem('MasterBizUitKey');
        window.localStorage.removeItem('OrganizationName');
        window.localStorage.removeItem('Auth Token');
        window.localStorage.removeItem('user Details');
        window.localStorage.removeItem('LoginUserName');
        window.localStorage.removeItem('expirationTime');
        window.localStorage.removeItem('RoleName');
        window.localStorage.removeItem('RoleGkey');
        window.localStorage.setItem('navpath', "dashboard");
        this.setState({ PageProcess: false })
    };

    onLongPress = (e) => {
        e.preventDefault();
        const password = document.querySelector('#pass');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        if (type === "password") {
            this.setState({
                passwordEye: false,
            })
        } else {
            this.setState({
                passwordEye: true,
            })
        }
    };

    onLogin = async (e) => {
        e.preventDefault();
        let email = userlogin.email.trim().toLowerCase();
        let password = userlogin.password;
        try {
            if (validEmailRegex(email)) {
                if (!(password == undefined || password == null || password == "")) {
                    const userCredential = await signInWithEmailAndPassword(auth, userlogin.email, userlogin.password);
                    const user = userCredential.user;
                    if (userCredential.user.emailVerified == false) {
                        toast.warning("Email Not Verified!");
                        return;
                    }
                    SetLocalStore(user);
                    await GetOrgDetailsbyEmail(userlogin.email);
                } else {
                    toast.error("Enter password");
                }
            } else {
                toast.error("Enter valid email address");
            }
        } catch (error) {
            const errorCode = error.code;
            this.setState({ PageProcess: false });
            toast.error(errorCode);
        }
    };

    ResetPasswordClick = () => {
        try {
            if (resetEmail == "" || resetEmail == undefined || resetEmail == null) {
                toast.error("email is mandatory");
                return;
            }
            sendPasswordResetEmail(auth, resetEmail);
            // sendPasswordResetEmail(auth, window.localStorage.getItem("resetuseremail"));
            toast.success("Password reset link sent!");
            this.setState({
                resetpassword: false,
            })
        } catch (err) {
            console.error(err);
            alert(err.message);
        }
        resetEmail = '';
    };

    ForgotPasswordClick = () => {
        this.setState({
            resetpassword: true,
        })
    };

    handleClose = () => {
        this.setState({
            resetpassword: false,
        })
    };

    passwordEyeHandle = () => {
        this.setState({
            passwordEye: !this.state.passwordEye
        })
    };

    handleChange = (e) => {
        e.preventDefault();
        let name = e.target.name;
        let value = e.target.value;
        if (name === 'email') {
            value = value.toLowerCase().trim();
            userlogin.email = value;
        }
        if (name === 'resetemail') {
            value = value.toLowerCase().trim();
            // window.localStorage.setItem("resetuseremail", value);
            resetEmail = value
        }
        else if (name === 'password') {
            userlogin.password = value;
        }
        console.log('userlogin.email', userlogin.email, 'userlogin.password', userlogin.password)
    };

    render() {
        return (
            <div class="login-page">
                {/* absolute bg-gradient-to-b from-blue-600 to-orange-600 opacity-75 inset-0 z-0 */}
                <div class="absolute bg-gradient-to-b from-blue-600 to-orange-600 opacity-75 inset-0 z-0"></div>
                <section class="flex flex-col h-screen overflow-auto z-50">
                    <div class="relative block pl-8 pt-4">
                        <a href='/'>
                            <div class="flex items-center pr-8" role="group">
                                <img src={icatlogo} class="max-lg:h-6 max-lg:w-8 h-12 w-18 pl-0"></img>
                                <h3 class="max-lg:text-mob-txt-lg text-2xl font-medium text-white pl-2"><span class="text-logo-orange"><span class="max-lg:text-[10px] text-[30px] font-medium ">i</span></span>CATS</h3>
                            </div>
                        </a>
                    </div>
                    <div class="flex-1 flex items-center justify-center pb-4 z-10 max-lg:p-6">
                        <div class=" w-full  rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 ">
                            <div class="flex  bg-[rgb(215,232,236,0.7)] rounded-2xl justify-center self-center ">
                                <div class="max-lg:px-6 max-lg:py-2 max-lg:w-50  px-12 py-4 mt-5 mx-auto rounded-2xl w-100  ">
                                    <div class="mb-">
                                        {/* <h3 class="font-semibold text-2xl text-gray-800">Sign In </h3> */}
                                    </div>
                                    <div class="space-y-2 max-lg:space-y-0">
                                        <div class="space-y-0">
                                            <label class="relative block">
                                                <label class="max-lg:text-mob-txt-lg text-sm font-medium text-gray-800 tracking-wide">{localConstant.LOGIN.EMAIL}</label>
                                                <span class="flex items-center bg-white pl-3 pr-2 pb-1 pt-1 border-2 border-gray-300 rounded-md text-base whitespace-no-wrap text-gray-600">
                                                    <span class="mr-2">  <HiOutlineAtSymbol /></span>
                                                    <input name="email" class=" max-lg:text-mob-txt-lg w-full bg-white placeholder:font-italitc rounded-md py-2 pl-3 pr-10 focus:outline-none" type="" placeholder="john@gmail.com" onChange={this.handleChange} />
                                                </span>
                                            </label>
                                        </div>
                                        <div class="space-y-0">
                                            <label class="relative block">
                                                <label class="max-lg:text-mob-txt-lg text-sm font-medium text-gray-700 tracking-wide">{localConstant.LOGIN.PASSWORD}</label>
                                                <span class="flex items-center bg-white pl-3 pr-2 pb-1 pt-1 border-2 border-gray-300 rounded-md text-base whitespace-no-wrap text-gray-600">
                                                    <span class="mr-2"><BsKey /></span>
                                                    <input name="password"
                                                        // id="txt_psw_field"
                                                        class="max-lg:text-mob-txt-lg w-full bg-white placeholder:font-italitc rounded-md py-2 pl-3 pr-10 focus:outline-none"
                                                        placeholder="Password" type="password" id="pass" onChange={this.handleChange} />
                                                    <span class="absolute inset-y-0 right-0 flex items-center pr-3 pt-6">
                                                        {this.state.passwordEye ? <AiOutlineEye onMouseUp={(e) => this.onLongPress(e)} />
                                                            : <AiOutlineEyeInvisible onMouseUp={(e) => this.onLongPress(e)} />}
                                                    </span>
                                                </span>
                                            </label>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div class="text-sm mt-4">      <label class="relative block">
                                                <a href="#" class="max-lg:text-mob-txt-sm text-blue-600 hover:underline" id="btnforgotemail" onClick={this.ForgotPasswordClick}>
                                                    {/* <a href="#" class="text-[#ec842a] hover:text-blue-600"> */}
                                                    {localConstant.LOGIN.FORGET_PASSWORD}
                                                </a>
                                            </label>
                                            </div>
                                        </div>
                                        <div>       <label class="relative block">
                                            <button type="submit" class="max-lg:text-mob-txt-lg w-full flex justify-center bg-blue-600  hover:bg-blue-500 text-gray-100 p-3   tracking-wide font-semibold  shadow-lg cursor-pointer transition ease-in duration-200" onClick={(e) => this.onLogin(e)}>
                                                {localConstant.LOGIN.BTN_LOGIN}
                                            </button>
                                        </label>
                                        </div>
                                    </div>
                                    <div class="max-lg:pt-1 max-lg:text-mob-txt-sm pt-5 text-center text-gray-700 text-xs">
                                        <span>
                                            {localConstant.LOGIN.COPY_RIGHTS_1}
                                            <a href="https://codepen.io/uidesignhub" rel="" target="_blank" title="Ajimon" class="text-green hover:text-blue-500  ml-2">{localConstant.LOGIN.COPY_RIGHTS_2}</a></span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                {this.state.resetpassword == true ?
                    <div class="z-50">
                        <ReactDialogBox
                            closeBox={this.handleClose}
                            modalWidth={localControlsConstant.Model.modalWidth}
                            headerBackgroundColor={localControlsConstant.Model.headerbg}
                            headerTextColor={localControlsConstant.Model.bodybg}
                            headerHeight={localControlsConstant.Model.headerheight}
                            closeButtonColor={localControlsConstant.Model.closebtncolor}
                            bodyBackgroundColor={localControlsConstant.Model.bodybg}
                            bodyTextColor={localControlsConstant.Model.bodytextcolor}
                            headerText={localControlsConstant.Model.resetpassword}

                        >
                            <div>
                                <p class="max-lg:mob-txt-sm8px max-lg:px-5">
                                    {localConstant.LOGIN.RESET_PASSWORD_CONTENT}
                                </p>
                                <div class="space-y-0 pl-4 pr-4 pb-1 pt-2 max-lg:pt-0 max-lg:pl-5">
                                    <label class=" relative block ">
                                        <label class="max-lg:mob-txt-sm text-sm font-medium text-gray-700 tracking-wide ">{localConstant.LOGIN.EMAIL}</label>
                                        <span class="flex items-center bg-gray-100 max-lg:mob-txt-sm max-lg:pl-0 max-lg:pr-0 pl-3 pr-2 pb-1 pt-1 border-solid border-2 border-indigo-300 rounded-md text-base whitespace-no-wrap text-gray-600 max-lg:w-50 ">
                                            <span class="mr-4 max-lg:mr-0">  <HiOutlineAtSymbol class="text-gray-800" /></span>
                                            <input name="resetemail" class="max-lg:mob-txt-sm w-full bg-white placeholder:font-italitc rounded-md  pl-3 pr-10 focus:outline-none" type="" placeholder="john@gmail.com" onChange={this.handleChange} />
                                        </span>
                                    </label>

                                </div>
                                <div class="modal-footer flex flex-shrink-0 flex-wrap items-center max-lg:justify-center justify-end pb-0 p-4 border-t border-footer-border rounded-b-md">
                                    <button type="button" class={localControlsConstant.Buttons.btnPrimary} onClick={this.ResetPasswordClick} >{localConstant.COMMON_CONST.RESET}</button>
                                    <button type="button" class={localControlsConstant.Buttons.btnSecondary} onClick={this.handleClose}>{localConstant.COMMON_CONST.CANCEL}</button>
                                </div>
                            </div>
                        </ReactDialogBox>
                    </div>
                    : null}
                <ToastContainer limit={2} autoClose={2000} />
            </div>
        )
    };
};
export default Login;