import React from "react";
import "../../CSS/SideBar.css";
import { Link } from "react-router-dom";
import { Menu, MenuItem, ProSidebar, SidebarHeader, SubMenu, SidebarFooter } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import { AxiosConstants } from "../../Constants/AxiosConstants";
import SideBarItems from './SideBarData';
import helpIcon from "../../Images/helpIcon.png";
import icatSidebar from "../../Images/icatSidebar.png";
import dashboardIcon from "../../Images/dashboardIcon.png";

//SCREEN ID -3069
const Sidebar = (props) => {
  const dashbordurl = '/dashboard/organization/' + AxiosConstants.AxiosBase.OrganizationName + '/Role/' + AxiosConstants.AxiosBase.RoleName;
  const setNavPath = (path) => {
    window.localStorage.setItem("navpath", path)
  };
  return (
    <ProSidebar collapsed={props.toggle} >
      <SidebarHeader class='max-lg:h-10 h-20 w-[100%] border-b-[1px]  bg-[#3a7afe]'>
        <div class='flex items-center justify-center h-[100%]'>
          {props.toggle ?
            <img src={icatSidebar} class="max-lg:h-8 max-lg:w-6 h-12 w-18 mr-2 "></img>
            :
            <div class="flex items-center  pr-8" role="group">
              <img src={icatSidebar} class="max-lg:h-8 max-lg:w-8 h-12 w-18  pl-0"></img>
              <h3 class="max-lg:mob-txt-sm md:text-2xl max-lg::pl-0 font-medium text-white pl-2"><span class="text-logo-orange"><span class="  text-[30px] font-medium ">i</span></span>CATS</h3>
            </div>}
        </div>
      </SidebarHeader>
      <SidebarHeader>
        <Menu>
          {!props.toggle && <div class="max-lg:mx-[15px] max-lg:pt-[10px] max-lg:mob-txt-lg  mx-[30px] pt-[25px] pb-[10px] text-[12px] font-semibold text-[#999999]" style={{ fontFamily: "'Roboto', sans-serif" }}>MAIN MENU
          </div>}
          <MenuItem onClick={() => setNavPath("dashboard")} icon={<img src={dashboardIcon} alt="" height={20} width={20} />} >
            Dashboard
            <Link to={dashbordurl} />
          </MenuItem>
        </Menu>
      </SidebarHeader>
      <Menu className="Main-Menu overflow-y-auto pt-10 mt-5 " id='sidebarScroll' >
        {!props.toggle && <div class=" max-lg:mx-[15px] max-lg:pt-[10px] max-lg:mob-txt-lg  mx-[30px] pt-[25px] pb-[10px] text-[12px] font-semibold text-[#999999]" style={{ fontFamily: "'Roboto', sans-serif" }}>APPLICATIONS
        </div>}
        {SideBarItems.MainMenu.SubMenu.map((item) => {
          return (
            <SubMenu className="sub" title={item.title} icon={item.icon} >

              {item.MenuItem.map((menuItem) => {
                return (
                  <MenuItem icon={menuItem.icon} className='NavSubtxt' onClick={() => setNavPath(menuItem.link)}>{menuItem.title}
                    <Link to={menuItem.link} />
                  </MenuItem>
                )
              })}
            </SubMenu>
          )
        })}
      </Menu>
      <SidebarFooter className="overflow-hidden" >
        <Menu>
          <MenuItem icon={<img src={helpIcon} alt="" height={30} width={30} />} >
            Help
          </MenuItem>
        </Menu>
      </SidebarFooter>
    </ProSidebar>
  )
}
export default Sidebar;