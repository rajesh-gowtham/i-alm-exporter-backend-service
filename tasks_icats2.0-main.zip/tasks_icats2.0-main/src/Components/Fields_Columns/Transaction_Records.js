import React from "react";
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ReactDialogBox } from 'react-js-dialog-box';
import 'react-js-dialog-box/dist/index.css';
import { EditLogo } from '../../CommonUtils/getLocalizeFunction';
import EditTransaction_Columns from './EditTransaction_Columns';
import { getlocalizeData, getlocalizeGridData, getControlsConstants, } from "../../CommonUtils/getlocalizeData";
import '../../CSS/Model.css';
import '../../CSS/AgGrid.css';
import StreamService from '../../Services/StreamService';
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { InsetBulkColumn } from "../../CommonUtils/UtilColumn";
import ColumnServices from "../../Services/ColumnServices";

const localConstantAGGrid = getlocalizeGridData();
const localConstant = getlocalizeData();
const localControlsConstant = getControlsConstants();
var StreamData = [];

//SCREEN ID -3065
class Transaction_Records extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            rowData: props.RowData,
            transactionEditFlag: false,
            editRowData: {},
            groupselect: [],
            rawInValidData: this.props.inValidData,
            errors: {
                shortName: '',
                displayName: '',
                control: '',
                group: ''
            },
            columnDefs: [
                {
                    field: '', width: 50, suppressMovable: true, headerCheckboxSelection: true, checkboxSelection: true, showDisabledCheckboxes: true,
                },
                { field: 'shortName', minWidth: 120, flex: 2, suppressMovable: true, headerName: 'Label' },
                { field: 'displayName', minWidth: 130, flex: 2, suppressMovable: true, headerName: 'Display Name' },
                { field: 'control', minWidth: 120, flex: 1, suppressMovable: true, headerName: 'Control' },
                {
                    field: 'status', minWidth: 100, flex: 1, suppressMovable: true, headerName: 'Status',
                    cellRenderer: (params) => {
                        if (params.value == 'success') {
                            return <span class="text-[#13bf1b] text-center font-semibold text-sm  ">SUCCESS</span>;
                        }
                        else {
                            return <span class="text-[#f33819] text-sm font-semibold  ">FAILED</span>;
                        }
                    }
                },
                {
                    field: 'remarks', minWidth: 180, flex: 3, suppressMovable: true, headerName: 'Remarks',
                    cellRendererFramework: (params) => {
                        let remarks = '';
                        if (params.data.displayName == '' || params.data.displayName == 'N/A') {
                            if (params.data.shortName == '' || params.data.shortName == 'N/A') {
                                if (params.data.control == '' || params.data.control == 'N/A') {
                                    if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                        remarks = 'Label Name, Display Name, Control Name & Group name is mandatory '
                                    }
                                    else {
                                        remarks = 'Label Name, Display Name & Control Name  is mandatory';
                                    }
                                } else if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                    remarks = 'Label Name, Display Name & Group Name  is mandatory';

                                } else {
                                    remarks = 'Label Name & Display Name is mandatory';
                                }
                            } else if (params.data.control == '' || params.data.control == 'N/A') {
                                if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                    remarks = 'Display Name, Control Name & Group Name  is mandatory';

                                } else {
                                    remarks = 'Display Name & Control Name is mandatory';
                                }
                            } else if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                remarks = 'Display Name & Group Name  is mandatory';
                            } else {
                                remarks = 'Display Name is mandatory';
                            }
                        } else if (params.data.shortName == '' || params.data.shortName == 'N/A') {
                            if (params.data.control == '' || params.data.control == 'N/A') {
                                if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                    remarks = 'Label Name, Control Name & Group Name  is mandatory';
                                }
                                else {
                                    remarks = 'Label Name & Control Name is mandatory';
                                }
                            } else if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                remarks = 'Label Name & Group Name is mandatory';
                            } else {
                                remarks = "Label Name is mandatory";
                            }
                        } else if (params.data.control == '' || params.data.control == 'N/A') {
                            if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                                remarks = 'Label Name & Control Name & Group Name is mandatory';
                            } else {
                                remarks = 'Control Name is mandatory';
                            }

                        } else if (params.data.Applie_To == '' || params.data.Applie_To == 'N/A') {
                            remarks = "Group Name is mandatory'";
                        } else {

                            remarks = "";
                        }
                        return (
                            <div class='h-[100%] max-w-[100%]  flex items-center text-xs text-[#f33819] whitespace-normal '>
                                {remarks}
                            </div>
                        )
                    }
                },
                {
                    headerName: "Edit", field: "edit", suppressMovable: true, minWidth: 80, flex: 1,
                    cellRendererFramework: (params) => {
                        return (
                            <div class='flex w-full h-full items-center '>
                                <button onClick={() => this.editTransactionRow(params.data)}><EditLogo /></button>
                            </div>
                        )
                    },
                }
            ],
        };
        this.gridRef = React.createRef();
    }

    LoadGroupField = async () => {
        try {
            const response = await StreamService.getStreamByOrg();
            const options = response.data.map((datas, index) => ({
                "value": datas.gkey,
                "label": response.data[index]["name"]
            }));
            this.setState({
                groupselect: options
            });
        } catch (error) {
            console.log(error);
            // Handle error here
        }
    };

    customHeaderCheckboxSelectionFunc = (params) => {
        const rows = params.api.getModel().rowsToDisplay;
        let allSelected = true;
        for (let i = 0; i < rows.length; i++) {
            if (!rows[i].isSelected()) {
                allSelected = false;
                break;
            }
        }
        if (allSelected) {
            params.node.setSelected(true);
        } else {
            params.node.setSelected(false);
        }
    };

    editTransactionRow = (editData) => {
        if (editData.status == 'failed') {
            this.setState({
                editRowData: editData,
                transactionEditFlag: true,
                errors: {
                    shortName: '',
                    displayName: '',
                    control: '',
                    group: ''
                },
            })
            // console.log('editRowData', this.state.editRowData)
            this.LoadGroupField();
        }
        else {
            toast.warning(" Selected row data already saved !")
        }
    };

    editTransactionRowClose = (e) => {
        e.preventDefault();
        this.setState({
            transactionEditFlag: false
        })
    };

    editTransactionColumn_OnChange = (e, obj) => {
        try {
            e.preventDefault();
        } catch (error) {
            if (e == null)
                return;
        }
        let name, value;
        let errors = this.state.errors;
        if (e.target == undefined) {
            name = obj.name;
            value = e.value;
            errors[name] = "";
        }
        else {
            name = e.target.name;
            value = e.target.value.trim();
        }
        this.setState(prevState => ({
            editRowData: {
                ...prevState.editRowData,
                [name]: value,
            }
        }))

        switch (name) {
            case 'shortName':
                errors.shortName =
                    value.length < 1
                        ? "Label name can't be empty ! "
                        : '';
                break;
            case 'displayName':
                errors.displayName =
                    value.length < 1
                        ? "Display name can't be empty ! "
                        : '';
                break;
            case 'control':
                errors.control =
                    value.length < 1
                        ? "Control name can't be empty ! "
                        : '';
                break;
            case 'Applie_To':
                errors.group =
                    value.length < 1
                        ? "Group name can't be empty ! "
                        : '';
                break;
            default:
                break;
        }
        this.setState({ errors, [name]: value });
    };

    editFields_Columns_Click = (event) => {
        event.preventDefault();
        let updatedData = this.state.editRowData;
        let tempInvalidData = this.state.rowData;
        // console.log('updatedData', updatedData);
        // console.log('tempInvalidData', tempInvalidData);
        if (this.validateAllData(updatedData)) {
            tempInvalidData.map((item, ind) => {
                if (item.gkey == updatedData.gkey) {
                    tempInvalidData[ind] = updatedData;
                }
            })
            this.setState({
                rowData: tempInvalidData,
                transactionEditFlag: false
            })
            alert(JSON.stringify(this.gridApi))
            this.gridApi.setRowData(tempInvalidData);
            this.gridApi.forEachLeafNode((node) => {
                node.setSelected(node.data.status == "failed");
            });
            // console.log('After inValidData', tempInvalidData);
        }
    };

    addTransactionOnClick = async () => {
        let tempAllinvalids = [];
        this.gridApi.getSelectedRows().map((item) => {
            if (item.status == 'failed') {
                let temp = {
                    "Label": item.shortName == "" ? undefined : item.shortName,
                    "Display Name": item.displayName == "" ? undefined : item.displayName,
                    "Control": item.control == "" ? undefined : item.control,
                    "Group": item.Applie_To == "" ? undefined : item.Applie_To,
                }
                tempAllinvalids.push(temp)
            }
        })

        // console.log('Re transaction ' ,(tempAllinvalids));
        try {
            // for (var i = 0; i < this.state.rowData.length; i++) {
            //     if (this.state.rowData[i].shortName.toUpperCase() == tempAllinvalids[i].Label.toUpperCase()) {
            //         toast.error(tempAllinvalids[i].Label + " Already exist!");
            //         return;
            //     }
            // }
            const response = await this.insertValidAndTransaction(tempAllinvalids);
            this.props.transactionBackClick();
            console.log('Transaction inserted successfully.');
        } catch (error) {
            console.log('Error occurred while inserting transaction:', error);
        }
    };

    async insertValidAndTransaction(rows) {
        let tempAllTransData = [];
        let ValidDatas = [];

        rows.map((item) => {
            let Columns = { shortName: "", displayName: "", control: "", Applie_To: "", mode: "", value: "", status: "", updatedBy: "", bizunit_gkey: "" };
            let rowDummy;
            Columns.shortName = item["Label"] == undefined ? (rowDummy = "N/A") : item["Label"];
            Columns.displayName = item["Display Name"] == undefined ? (rowDummy = "N/A") : item["Display Name"];
            Columns.control = item["Control"] == undefined ? (rowDummy = "N/A") : item["Control"];
            Columns.Applie_To = item["Group"] == undefined ? (rowDummy = "N/A") : item["Group"];
            Columns.mode = "Browse";
            Columns.value = "N/A";
            Columns.status = rowDummy == undefined ? "success" : "failed";
            Columns.updatedBy = window.localStorage.getItem("LoginUserName");
            Columns.bizunit_gkey = window.localStorage.getItem("MasterBizUitKey");

            if (!rowDummy) {
                ValidDatas.push(Columns);
            }
            tempAllTransData.push(Columns);
        });
        //insert valid column data into field columns
        if (ValidDatas.length > 0) {
            // console.log("Valid Records", ValidDatas);
            await InsetBulkColumn(ValidDatas);
        }
        if (tempAllTransData.length > 0) {
            //insert all excel data into transaction table(valid and invalid)
            // console.log("all excel records ", tempAllTransData);
            await this.ExportTransactionColumnByOrg(tempAllTransData);
        }
        // console.log("all excel trans records ", tempAllTransData);
    };

    async ExportTransactionColumnByOrg(tempAllTransData) {
        try {
            // console.log('tempAllTransData :', (tempAllTransData))
            const response = await ColumnServices.ExportTransactionColumnByOrg(tempAllTransData);
            if (response.status === 200 || response.status === 201) {
                toast.success("Transaction added successfully")
            }
        } catch (error) {
            console.error(error);
            toast.error("An error occurred while adding transaction");
        }
    };

    validateAllData(records) {
        if (records.shortName == undefined || records.shortName == "" || this.state.errors.shortName != "") {
            let err = records.shortName == undefined || records.shortName == "" ? ' Please Enter Label Name  ' : this.state.errors.shortName;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    shortName: err                   // update the value of specific key                                                      
                },
            }));
            return false;
        }
        if (records.displayName == undefined || records.displayName == "" || this.state.errors.displayName) {
            let err = records.displayName == undefined || records.displayName == "" ? ' Please Enter Display Name  ' : this.state.errors.displayName;
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    displayName: err                    // update the value of specific key                                                      
                },
            }));
            return false;
        }
        if (records.control == undefined || records.control == '') {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    control: ' Please Select Control Name '      // update the value of specific key
                },

            }));
            return false;
        }
        if (records.Applie_To == undefined || records.Applie_To == '') {
            this.setState(prevState => ({
                errors: {                                            // object that we want to update
                    ...prevState.errors,                             // keep all other key-value pairs
                    group: ' Please Select Group Name '      // update the value of specific key
                },
            }));
            return false;
        }
        return true;
    };

    isSelectable = (rowNode) => {
        const selectable = (rowNode.data.status === "failed");
        return selectable;
    };

    onGridReady = (params) => {
        this.gridApi = params.api;
        console.log("this.gridApi" , this.gridApi );
        this.gridRef.current.api.forEachNode((node) =>
            node.setSelected(node.data.status == "failed")
        );
    };

    getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'white' };
        } else {
            return { background: '#F0F0F0' };
        }
    };


    render() {
        console.log("this.gridApi" , this.gridApi );
        return (
            <div className='bg-white rounded'>
                {/* <div className='flex justify-between px-7 pt-5'>
                        <h1 class={localControlsConstant.Responsive.textboxResponsive.text_header}>{localConstant.TRANSACTION_RECORDS.HEADER}<span class='text-blue-600'> {"(35100" + this.props.selectedRowIndex + ")"}</span></h1>
                        <div className='flex items-end space-x-5 text-gray-500'>
                            <h2 className='font-semibold'>Total Datas ({this.props.RowData.length})</h2>
                            <h2 className='font-semibold'>Valid Datas ({this.props.RowData.length - this.state.rawInValidData.length})</h2>
                            <h2 className='font-semibold'>Invalid Datas ({this.state.rawInValidData.length})</h2>
                        </div>
                    </div> */}
                <div className="ag-theme-alpine px-7 pt-7 pb-2 rounded h-[50vh]" Id="secondaryGrid"  >
                    <AgGridReact
                        ref={this.gridRef}
                        rowData={this.state.rowData}
                        columnDefs={this.state.columnDefs}
                        // domLayout='autoHeight'
                        headerHeight={35}
                        rowHeight={38}
                        pagination={false}
                        rowSelection={'multiple'}
                        cacheQuickFilter={true}
                        paginationPageSize='7'
                        getRowStyle={this.getRowStyle}
                        // gridOptions={localConstantAGGrid.AGGrid.gridOptions}
                        suppressRowClickSelection={true}
                        suppressRowHoverHighlight={true}
                        onGridReady={this.onGridReady}
                        isRowSelectable={this.isSelectable}
                    />
                </div>
                {this.props.inValidData.length > 0 &&
                    <div className="flex  justify-end mt-5 mr-5">
                        <button className={ControlsConstants.Buttons.btnPrimary + ' h-8 ml-2 '} onClick={this.addTransactionOnClick}>{localConstant.COMMON_CONST.SAVE}</button>
                    </div>}


                {this.state.transactionEditFlag ?
                    <ReactDialogBox
                        closeBox={this.editTransactionRowClose}
                        modalWidth={localControlsConstant.Model.modalWidth}
                        headerBackgroundColor={localControlsConstant.Model.headerbg}
                        headerTextColor={localControlsConstant.Model.bodybg}
                        headerHeight={localControlsConstant.Model.headerheight}
                        closeButtonColor={localControlsConstant.Model.closebtncolor}
                        bodyBackgroundColor={localControlsConstant.Model.bodybg}
                        bodyTextColor={localControlsConstant.Model.bodytextcolor}
                        //   bodyHeight='150px'
                        headerText='Edit Transaction Column'
                    >
                        <EditTransaction_Columns
                            editTransactionData={this.state.editRowData}
                            groupselect={this.state.groupselect}
                            editTransactionColumn_OnChange={this.editTransactionColumn_OnChange}
                            editFields_Columns_Click={this.editFields_Columns_Click}
                            editTransactionRowClose={this.editTransactionRowClose}
                            errors={this.state.errors}
                        />
                    </ReactDialogBox>
                    : null
                }
            </div>
        )
    }
}

export default Transaction_Records;