import { getlocalizeData, getlocalizeGridData, getControlsConstants } from "../../CommonUtils/getlocalizeData";
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localConstant = getlocalizeData();
const localConstantAGGrid = getlocalizeGridData();
const localControlsConstant = getControlsConstants();
var ControlOptions = [{ label: 'Text', value: 'Text' }, { label: 'List', value: 'List' }];

//SCREEN ID -3023
const EditFields_Columns = (props) => {
    const dropDownStylesRed = ControlsConstants.Select.dropDownStylesRed;
    const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
    const borderRed = localControlsConstant.TextBox.textboxRed;
    const borderGrey = localControlsConstant.TextBox.textbox;
    console.log("propssss",props.columnEditData    );
    return (
        <div className="mt-5">
            {/* <div class='flex justify-center mb-5 w-full max-w-sm  max-lg:max-w-sm'> */}
                {/* NEED TO ADD BELOW  Mubarak */}
                {/* ({props.columnEditData.gkey.toString().substring(0, 7)}) */}
                {/* <h1 class={localControlsConstant.Responsive.textboxResponsive.text_header}>{localConstant.FIELD_COLUMNS.EDIT_COLUMN}</h1> */}
            {/* </div> */}

            {/* RESPONSIVE START */}
            <form class="w-full max-w-sm  max-lg:max-w-sm">
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.FIELD_COLUMNS.LABEL}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.shortName.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter label name"
                            name="shortName"
                            value={props.columnEditData.shortName}
                            onChange={props.editColumn_OnChange}
                        />
                        {props.errors.shortName.length > 0 ?
                            <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.shortName}</span>
                            : null}
                    </div>
                </div>

                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.FIELD_COLUMNS.DISPLAY_NAME}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input
                            class={props.errors.displayName.length > 0 ? localControlsConstant.Responsive.textboxResponsive.textbox_b_red : localControlsConstant.Responsive.textboxResponsive.textbox_b_gray}
                            type="text"
                            placeholder="Enter display name"
                            name="displayName"
                            value={props.columnEditData.displayName}
                            onChange={props.editColumn_OnChange}
                        />
                        {props.errors.displayName.length > 0 ?
                            <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.displayName}</span>
                            : null}
                    </div>
                </div>

                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.FIELD_COLUMNS.CONTROL}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <Select
                            options={ControlOptions}
                            ref={props.controlSelect}
                            name="control"
                            value={{ label: props.columnEditData.control, value: props.columnEditData.control }}
                            onChange={props.editColumn_OnChange}
                            styles={props.errors.control.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                        />
                        {props.errors.control.length > 0 ?
                            <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.control}</span>
                            : null}
                    </div>
                </div>
                <div class="md:flex md:items-center max-lg:mb-3 mb-6">
                    <div class="md:w-1/3">
                        <label class={localControlsConstant.Responsive.labelResponsive.label} for="inline-full-name">
                            {localConstant.FIELD_COLUMNS.GROUP}
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <Select
                            options={props.groupselect}
                            ref={props.groupSelect}
                            value={
                                props.groupselect.filter(option =>
                                    option.value === props.columnEditData.Applie_To)
                            }
                            onChange={props.editColumn_OnChange}
                            name="Applie_To"
                            styles={props.errors.group.length > 0 ? dropDownStylesRed : dropDownStylesGrey}
                        />
                        {props.errors.group.length > 0 ?
                            <span id='isError' class='text-error-red max-lg:mob-txt-sm  mob-txt-md'>{props.errors.group}</span>
                            : null}
                    </div>
                </div>
                <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                        onClick={(e) => props.editColumns_OnClick(e)}>{localConstant.COMMON_CONST.UPDATE}</button>
                    <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                        onClick={(e) => props.resetOn_Click(e)}>{localConstant.COMMON_CONST.RESET}</button>
                </div>
            </form>
            {/* RESPONSIVE END */}
        </div>
    )
}
export default EditFields_Columns;

