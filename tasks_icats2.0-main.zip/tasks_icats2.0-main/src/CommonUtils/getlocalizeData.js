import { allLocalConstants } from "../Constants/allLocalConstants";
import { GridConstants } from "../Constants/GridConstants";
import { ControlsConstants } from "../Constants/ControlsConstants";
import { ImgageConstants } from "../Constants/ImgageConstants";
import { LandingConstants } from "../Constants/LandingConstants";
import { AxiosConstants } from "../Constants/AxiosConstants";
import { ColorConstants } from "../Constants/ColorConstants";

//SCREEN ID -3048

export const getlocalizeData = () => {
    return allLocalConstants;
};
export const getlocalizeGridData = () => {
    return GridConstants;
};

export const getControlsConstants = () => {
    return ControlsConstants;
};

export const getImgageConstants = () => {
    return ImgageConstants;
};
export const getLandingConstants = () => {
    return LandingConstants;
};

export const geAxiosConstants= () => {
    return AxiosConstants;
};

export const getColorConstants= () => {
    return ColorConstants;
};


