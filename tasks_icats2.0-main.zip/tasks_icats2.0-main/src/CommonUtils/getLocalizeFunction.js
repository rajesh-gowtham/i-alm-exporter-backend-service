//Common util function page for project 
import { ColorConstants } from "../Constants/ColorConstants";
import { getControlsConstants } from "./getlocalizeData";
const localConstant = getControlsConstants()
//SCREEN ID -3049
export function validEmailRegex(email) {
    const validEmail = RegExp(
        localConstant.RegExp.emailRegExp
    );
    return validEmail.test(email);
}
export function digitsRegExp(value) {
    const regExp = RegExp(
        localConstant.RegExp.digitRegExp
    );
    return regExp.test(value);
}
export function specialCharRegExp(value) {
    const regExp = RegExp(
        localConstant.RegExp.specialCharRegExp
    );
    return regExp.test(value);
}
export function capitalizeString(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
};

// export function EditLogo({ color }) {
//     return (
//         <div class=" bg-[#3a7afe] rounded p-[4px] hover:bg-[#286df7]" >
//             <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-edit" width="18" height="18" stroke={color ? color : ColorConstants.Icon.editLogoWhite} viewBox="0 0 24 24" stroke-width="2.0" fill="none" stroke-linecap="round" stroke-linejoin="round">
//                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
//                 <path d="M9 7h-3a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-3" />
//                 <path d="M9 15h3l8.5 -8.5a1.5 1.5 0 0 0 -3 -3l-8.5 8.5v3" />
//                 <line x1="16" y1="5" x2="19" y2="8" />
//             </svg>
//         </div>
//     )
// };

// export function TrashLogo({ color }) {
//     return (
//         <div class="  bg-orange-500 rounded p-[4px] hover:bg-orange-600">
//             <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="18" height="18" stroke={color ? color : ColorConstants.Icon.editLogoWhite} viewBox="0 0 24 24" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
//                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
//                 <line x1="4" y1="7" x2="20" y2="7" />
//                 <line x1="10" y1="11" x2="10" y2="17" />
//                 <line x1="14" y1="11" x2="14" y2="17" />
//                 <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
//                 <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
//             </svg>
//         </div>
//     )
// };

export function EditLogo({ color }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 26 26" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M23.1489 6.14171C23.2479 6.29193 23.292 6.47169 23.2738 6.65066C23.2556 6.82962 23.1761 6.99681 23.0489 7.124L13.4729 16.699C13.3749 16.7969 13.2527 16.867 13.1187 16.9021L9.13018 17.9438C8.99833 17.9782 8.85979 17.9775 8.7283 17.9418C8.5968 17.9061 8.47693 17.8366 8.38059 17.7403C8.28424 17.6439 8.21477 17.524 8.17906 17.3926C8.14336 17.2611 8.14267 17.1225 8.17705 16.9907L9.21872 13.0032C9.24913 12.8835 9.30649 12.7723 9.38643 12.6782L18.9979 3.07296C19.1444 2.92666 19.3429 2.84448 19.55 2.84448C19.757 2.84448 19.9556 2.92666 20.1021 3.07296L23.0489 6.01879C23.0863 6.0563 23.1198 6.09748 23.1489 6.14171ZM21.3916 6.57088L19.55 4.73025L10.6771 13.6032L10.026 16.0959L12.5187 15.4448L21.3916 6.57088Z" fill="#B1B1BE" />
            <path d="M21.2594 18.3749C21.5441 15.9415 21.635 13.4894 21.5312 11.0416C21.529 10.9839 21.5386 10.9264 21.5596 10.8726C21.5806 10.8189 21.6124 10.77 21.6531 10.7291L22.6781 9.70409C22.7061 9.67592 22.7417 9.65644 22.7805 9.64799C22.8193 9.63954 22.8597 9.64247 22.8969 9.65645C22.9341 9.67042 22.9664 9.69483 22.9901 9.72675C23.0137 9.75867 23.0277 9.79674 23.0302 9.83638C23.2231 12.7439 23.1499 15.663 22.8114 18.5572C22.5656 20.6635 20.8739 22.3145 18.7771 22.5489C15.1368 22.952 11.4632 22.952 7.8229 22.5489C5.72706 22.3145 4.03435 20.6635 3.78852 18.5572C3.35665 14.8649 3.35665 11.1349 3.78852 7.44263C4.03435 5.33638 5.72602 3.68534 7.8229 3.45096C10.5858 3.14459 13.3695 3.07037 16.1448 3.22909C16.1845 3.23194 16.2226 3.24612 16.2545 3.26993C16.2864 3.29375 16.3108 3.32622 16.3248 3.36349C16.3389 3.40075 16.3419 3.44126 16.3336 3.48021C16.3253 3.51916 16.3061 3.55492 16.2781 3.58326L15.2437 4.61659C15.2032 4.65695 15.1549 4.68859 15.1017 4.70955C15.0484 4.73051 14.9915 4.74035 14.9344 4.73846C12.6185 4.65974 10.2999 4.74851 7.99685 5.00409C7.32388 5.07858 6.69566 5.37776 6.21368 5.85331C5.73171 6.32886 5.42412 6.953 5.3406 7.62492C4.92295 11.1961 4.92295 14.8038 5.3406 18.3749C5.42412 19.0468 5.73171 19.671 6.21368 20.1465C6.69566 20.6221 7.32388 20.9213 7.99685 20.9958C11.4916 21.3864 15.1083 21.3864 18.6041 20.9958C19.2771 20.9213 19.9053 20.6221 20.3873 20.1465C20.8693 19.671 21.1758 19.0468 21.2594 18.3749Z" fill="#B1B1BE" />
        </svg>
    )
};

export function TrashLogo({ color }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 26 26" fill="none">
            <path d="M11.2166 5.70833H15.3833C15.3833 5.1558 15.1638 4.62589 14.7731 4.23519C14.3824 3.84449 13.8525 3.625 13.3 3.625C12.7474 3.625 12.2175 3.84449 11.8268 4.23519C11.4361 4.62589 11.2166 5.1558 11.2166 5.70833ZM9.65413 5.70833C9.65413 5.22956 9.74844 4.75547 9.93166 4.31313C10.1149 3.8708 10.3834 3.46889 10.722 3.13034C11.0605 2.79179 11.4624 2.52324 11.9048 2.34002C12.3471 2.1568 12.8212 2.0625 13.3 2.0625C13.7787 2.0625 14.2528 2.1568 14.6952 2.34002C15.1375 2.52324 15.5394 2.79179 15.878 3.13034C16.2165 3.46889 16.4851 3.8708 16.6683 4.31313C16.8515 4.75547 16.9458 5.22956 16.9458 5.70833H22.9354C23.1426 5.70833 23.3413 5.79064 23.4878 5.93716C23.6343 6.08367 23.7166 6.28238 23.7166 6.48958C23.7166 6.69678 23.6343 6.8955 23.4878 7.04201C23.3413 7.18852 23.1426 7.27083 22.9354 7.27083H21.5604L20.3416 19.8865C20.2481 20.8531 19.7979 21.7503 19.0788 22.4029C18.3597 23.0556 17.4232 23.417 16.4521 23.4167H10.1479C9.17691 23.4168 8.2407 23.0553 7.52179 22.4026C6.80288 21.7499 6.35282 20.8529 6.25934 19.8865L5.03955 7.27083H3.66455C3.45735 7.27083 3.25864 7.18852 3.11212 7.04201C2.96561 6.8955 2.8833 6.69678 2.8833 6.48958C2.8833 6.28238 2.96561 6.08367 3.11212 5.93716C3.25864 5.79064 3.45735 5.70833 3.66455 5.70833H9.65413ZM11.7375 10.6562C11.7375 10.449 11.6552 10.2503 11.5086 10.1038C11.3621 9.95731 11.1634 9.875 10.9562 9.875C10.749 9.875 10.5503 9.95731 10.4038 10.1038C10.2573 10.2503 10.175 10.449 10.175 10.6562V18.4688C10.175 18.6759 10.2573 18.8747 10.4038 19.0212C10.5503 19.1677 10.749 19.25 10.9562 19.25C11.1634 19.25 11.3621 19.1677 11.5086 19.0212C11.6552 18.8747 11.7375 18.6759 11.7375 18.4688V10.6562ZM15.6437 9.875C15.8509 9.875 16.0496 9.95731 16.1961 10.1038C16.3427 10.2503 16.425 10.449 16.425 10.6562V18.4688C16.425 18.6759 16.3427 18.8747 16.1961 19.0212C16.0496 19.1677 15.8509 19.25 15.6437 19.25C15.4365 19.25 15.2378 19.1677 15.0913 19.0212C14.9448 18.8747 14.8625 18.6759 14.8625 18.4688V10.6562C14.8625 10.449 14.9448 10.2503 15.0913 10.1038C15.2378 9.95731 15.4365 9.875 15.6437 9.875ZM7.81455 19.7365C7.87074 20.3163 8.14085 20.8544 8.57223 21.2459C9.0036 21.6375 9.56533 21.8543 10.1479 21.8542H16.4521C17.0346 21.8543 17.5963 21.6375 18.0277 21.2459C18.4591 20.8544 18.7292 20.3163 18.7854 19.7365L19.9916 7.27083H6.6083L7.81455 19.7365Z" fill="#B1B1BE" />
        </svg>
    )
};

export function SetLocalStore(user) {
    const uid = user.uid;
    const useremail = user.email;
    const stsTokenManager = user.stsTokenManager;
    const lastLoginAt = user.lastLoginAt;
    window.localStorage.setItem('uid', uid);
    window.localStorage.setItem('useremail', useremail);
    window.localStorage.setItem('stsTokenManager', JSON.stringify(stsTokenManager));
    window.localStorage.setItem('lastLoginAt', lastLoginAt);
    window.localStorage.setItem('expirationTime', stsTokenManager.expirationTime);
    window.localStorage.setItem('Auth Token', user.accessToken);
    window.localStorage.setItem('user Details', JSON.stringify(user));
    return true;
};

