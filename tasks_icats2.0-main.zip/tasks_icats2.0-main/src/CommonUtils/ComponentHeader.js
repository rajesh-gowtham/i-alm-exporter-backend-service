import React from 'react'
import { Link } from 'react-router-dom'
import { HiOutlineSearch } from 'react-icons/hi'


function ComponentHeader(props) {
    return (
        <div >
            <div id='Header' class='font-roboto w-full flex justify-between items-center py-4 px-3  border-b-[1.5px] border-[#00000028]'>
                <nav className='flex items-center space-x-1'>
                    <Link to="/dashboard/organization/:organization/Role/:Role" >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <g clip-path="url(#clip0_287_8398)">
                                <path d="M22.4733 11.5266L12.4733 1.52663C12.3484 1.40246 12.1795 1.33276 12.0034 1.33276C11.8272 1.33276 11.6583 1.40246 11.5334 1.52663L1.53335 11.5266C1.42413 11.6542 1.36706 11.8182 1.37354 11.986C1.38002 12.1538 1.44958 12.3129 1.56831 12.4317C1.68704 12.5504 1.8462 12.62 2.01398 12.6264C2.18177 12.6329 2.34582 12.5758 2.47335 12.4666L12 2.93996L21.5267 12.4733C21.6542 12.5825 21.8183 12.6396 21.9861 12.6331C22.1538 12.6266 22.313 12.5571 22.4317 12.4383C22.5505 12.3196 22.62 12.1604 22.6265 11.9927C22.633 11.8249 22.5759 11.6608 22.4667 11.5333L22.4733 11.5266Z" fill="#6C7178" />
                                <path d="M18.6667 21.3334H15.3333V14.6668H8.66667V21.3334H5.33333V12.0001L4 13.3334V21.3334C4 21.687 4.14048 22.0262 4.39052 22.2762C4.64057 22.5263 4.97971 22.6668 5.33333 22.6668H10V16.0001H14V22.6668H18.6667C19.0203 22.6668 19.3594 22.5263 19.6095 22.2762C19.8595 22.0262 20 21.687 20 21.3334V13.1734L18.6667 11.8401V21.3334Z" fill="#6C7178" />
                            </g>
                            <defs>
                                <clipPath id="clip0_287_8398">
                                    <rect width="24" height="24" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                    </Link>

                    {props.path.map((item, index) =>
                        <nav className='flex items-center space-x-1'>
                            <span className='mt-[2px]'>
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64237 1.7263L11.4368 7.5311C11.4889 7.58094 11.5303 7.64094 11.5584 7.7074C11.5865 7.77386 11.6006 7.84536 11.6 7.9175C11.6002 8.06638 11.5415 8.2093 11.4368 8.3151C9.34077 10.3599 7.32077 12.3335 5.37677 14.2359C5.27677 14.3295 4.87677 14.5623 4.56797 14.2167C4.25917 13.8703 4.44637 13.5687 4.56797 13.4439L10.2224 7.9175L4.82477 2.5103C4.62797 2.2391 4.64397 1.9887 4.87277 1.7591C5.10157 1.5295 5.35837 1.5183 5.64237 1.7263Z" fill="#CDD2DA" />
                                </svg>
                            </span>
                            <nav onClick={props.path.length - 1 == index ? null : props.backToParentClass}>
                                <h1 className={`font-roboto ${props.path.length - 1 == index ? 'text-page-header-2xl text-page-header' : 'text-[17px] cursor-pointer font-normal text-zinc-500'}`}>{item}</h1>
                            </nav>
                        </nav>
                    )
                    }
                </nav>

                <div className='flex items-center h-8'>
                    <div id="scenario-search">
                        {props.isSearchable ?
                            <div class="relative rounded-md border border-black border-opacity-5 flex items-center h-8 bg-search-bg overflow-hidden">
                                <div class="grid place-items-center h-full w-12 text-search-text">
                                    <HiOutlineSearch color='#0000004D' size={24} />

                                </div>
                                <input
                                    id="filter-text-box"
                                    onInput={props.onFilterTextBoxChanged}
                                    class="peer text-search-text bg-search-bg h-full w-full max-sm:w-[100px] outline-none text-search-text-size placeholder-[#0000004D]  placeholder:text-xs placeholder:font-normal pr-2"
                                    type="text"
                                    placeholder="Search..." />
                            </div>
                            : null}
                    </div>
                </div>

            </div>
        </div>
    )
}

export default ComponentHeader
