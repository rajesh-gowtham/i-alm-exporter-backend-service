    //SCREEN ID -3054
    export const AxiosConstants = {
        AxiosBase:{
            ApiBaseUrl:'http://10.1.1.154:8281/icats/v1/',
            userToken:window.localStorage.getItem("Auth Token"),
            userdetaile:window.localStorage.getItem("user Details"),
            MasterBizUitKey:window.localStorage.getItem("MasterBizUitKey"),
            RoleName:window.localStorage.getItem("RoleName"),
            OrganizationName:window.localStorage.getItem("OrganizationName")
        },  
    };
