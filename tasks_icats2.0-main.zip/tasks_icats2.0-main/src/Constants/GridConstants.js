//SCREEN ID -3059
export const GridConstants = {
    AGGrid: {
        RowHeight: 50,
        RowHeightExcel: 25,
        paginationPageSize: 6,
        sno: 1,
        gridOptions: {
            // set background colour on every row, this is probably bad, should be using CSS classes 
            // rowStyle: { background: 'white' }
            defaultColDef: {
                sortable: true,
            }
        },
    },
};
