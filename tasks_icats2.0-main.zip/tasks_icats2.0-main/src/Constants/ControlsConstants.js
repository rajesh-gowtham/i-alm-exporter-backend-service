//SCREEN ID -3057
export const ControlsConstants = {
    Buttons: {
        //   BUTTON
        btnPrimary: 'w-[120px] h-[40px] px-5 py-2.5 text-white text-xs font-medium bg-blue-800 rounded-md border border-blue-800 flex justify-center items-center',
        btnSecondary:'w-[120px] h-[40px] px-5 py-2.5 rounded-md border border-black border-opacity-50 hover:border-opacity-80 justify-center items-center gap-2.5 inline-flex text-black text-opacity-50 hover:text-opacity-80 text-xs font-medium   transition duration-150 ease-in-out',
        // btnPrimary: 'px-6 py-2.5 bg-[#089de3] text-white max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out',
        // btnSecoundary: 'px-6 py-2.5 bg-gray-400 text-white max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-gray-700 hover:shadow-lg focus:bg-gray-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-gray-800 active:shadow-lg transition duration-150 ease-in-out',
        // btnSecondary: 'px-6  py-2.5  bg-[#F6AE2D]  text-white  max-lg:mob-txt-sm font-medium  text-xs  leading-tight  uppercase  rounded shadow-md  hover:bg-red-500 hover:shadow-lg focus:bg-red-500 focus:shadow-lg focus:outline-none focus:ring-0  active:bg-red-500 active:shadow-lg  transition  duration-150  ease-in-out  ml-1',
        // btnUpdate: 'px-6 py-2.5 bg-[#F6AE2D] text-white  max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-green-500 hover:text-white hover:shadow-lg focus:bg-gray-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-green-500 active:shadow-lg transition duration-150 ease-in-out',
        // btnNextstp: 'px-6 py-2.5 bg-gray-200 text-black  max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover: bg-gray-100 hover:shadow-lg focus: bg-gray-300 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-green-500 active:shadow-lg transition duration-150 ease-in-out',
        // btnSuccess: 'px-6  py-2.5  bg-green-600  text-white  max-lg:mob-txt-sm font-medium  text-xs  leading-tight  uppercase  rounded shadow-md  hover:bg-green-400 hover:shadow-lg focus:bg-green-500 focus:shadow-lg focus:outline-none focus:ring-0  active:bg-green-700 active:shadow-lg  transition  duration-150  ease-in-out  ml-1',
    },
    TextBox: {
        //   TEXT BOX
        textbox: 'w-[100%] text-[12px] bg-blue-800 bg-opacity-10 rounded-md  h-10 text-black font-normal  py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border focus:border-blue-800',
        textboxRed: 'w-[100%] text-[12px] border-[1px] border-[#f74a73] bg-[#eaf1fa] rounded-md h-10 text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px] flex-shrink flex-grow flex-1  relative self-center outline-none',
        textarea: 'w-[100%] text-[12px]  bg-blue-800 bg-opacity-10 rounded-md  h-[100px] text-black font-normal  p-2.5 px-[10px] placeholder:text-[11px] focus:outline-none focus:border focus:border-blue-800 ',
        
        // textbox: 'w-[100%] text-[12px] border-[1px] border-[#cecef8] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px]',
        // textboxRed: 'w-[100%] text-[12px] border-[1px] border-[#f74a73] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px] flex-shrink flex-grow flex-1  relative self-center outline-none'
        // textbox12px: 'text-[12px] border-[1px] border-[#cecef8] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px]',
        // gridtextbox11px: 'text-[11px] border-[1px] border-[#cecef8] bg-[#eaf1fa] rounded-[6px] h-[25px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px]',
        // textbox13px: 'text-[13px] border-[1px] border-[#cecef8] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px]',
        // textbox14px: 'text-[14px] border-[1px] border-[#cecef8] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px]',
        // borderRed: "w-[100%] text-[12px] border-[1px] border-[#f74a73] bg-[#eaf1fa]  h-[35px] text-[#2a2e34] py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border-[2px] flex-shrink flex-grow flex-1  relative self-center outline-none",
    },
    label: {
        label14: 'flex-1 text-[color:#292d34] text-[14px]',
        // label14: 'flex-1 flex justify-between text-[color:#292d34] text-[14px] pr-1',
    },

    Responsive: {
        labelResponsive: {
            label: 'block text-[color:#292d34  md:text-right mb-1 md:mb-0 pr-4 max-lg:mob-txt-md text-[14px] ',
        },
        textboxResponsive: {
            text_header: 'max-lg:mob-txt-md max-lg:font-bold   md:text-page-header-2xl text-page-header  pb-1',
            textbox_b_red: 'bg-[#eaf1fa] text-[12px] h-10 text-black bg-blue-800 bg-opacity-10 rounded-md appearance-none border-[1px] border-[#f74a73] max-lg:w-md w-full  max-lg:py-0 placeholder:text-[11px] max-lg:px-2 py-2 px-[10px] leading-tight',
            textbox_b_gray: 'text-[12px] text-black h-10 bg-blue-800 bg-opacity-10 rounded-md appearance-none max-lg:w-md w-full  max-lg:py-0  placeholder:text-[11px] max-lg:px-2 py-2 px-[10px]  leading-tight focus:outline-none focus:border focus:border-blue-800',
            textarea: 'text-[12px] text-black bg-blue-800 bg-opacity-10 rounded-md appearance-none h-[100px]  max-lg:rounded-[5px]  max-lg:w-md w-full placeholder:text-[11px]  max-lg:py-0 max-lg:px-2 py-2 px-4 text-black focus:outline-none focus:border focus:border-blue-800 leading-tight',
            // textbox_b_red: 'bg-[#eaf1fa] appearance-none border-[1px] border-[#f74a73] max-lg:w-md w-full  max-lg:py-0 placeholder:text-[11px] max-lg:px-2 py-2 px-4 text-gray-700 leading-tight',
            // textbox_b_gray: 'bg-[#eaf1fa] appearance-none border-[1px] border-[#cecef8]  max-lg:w-md w-full  max-lg:py-0  placeholder:text-[11px] max-lg:px-2 py-2 px-4 text-gray-700 leading-tight',
            // textarea: 'bg-[#eaf1fa] appearance-none   border-[1px] border-[#f74a73] max-lg:rounded-[5px]  max-lg:w-md w-full placeholder:text-[11px]  max-lg:py-0 max-lg:px-2 py-2 px-4 text-gray-700 leading-tight'
        },
        btnResponsive: {
            btn_from_footer: 'flex items-center space-x-3 py-2 max-lg:justify-center justify-end border-t border-footer-border rounded-b-md',
            btn_success: 'flex-shrink-0 bg-blue-800 text-white font-medium text-xs  max-lg:m-2 m-2 max-lg:px-4 px-6 py-2.5 rounded shadow-md transition duration-150 ease-in-out" type="button',
            btn_warning: 'flex-shrink-0 border border-black border-opacity-50 hover:border-opacity-80  text-black text-opacity-50 hover:text-opacity-80 font-medium text-xs max-lg:px-4 px-6 py-2.5  rounded shadow-md   transition duration-150 ease-in-out',
            // btn_success: 'flex-shrink-0 bg-[#089de3] text-white font-medium text-xs  max-lg:m-2 m-2 max-lg:px-4 px-6 py-2.5 uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out" type="button',
            // btn_warning: 'flex-shrink-0 bg-[#F6AE2D] text-white font-medium text-xs max-lg:px-4 px-6 py-2.5 uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out',
        }
    },
    checkbox: {
        checkbox14: 'flex-1 text-[color:#292d34] text-[14px]',
        checkbox17: 'flex-1 flex justify-between text-[color:#292d34] text-[14px] pr-1',
    },
    Switch: {
        SwitchToggel: 'w-8 h-4 bg-gray-400 rounded-full peer  peer-focus:ring-green-300  peer-checked:after:translate-x-full peer-checked:after:border-white after:content after:absolute after:top-[1px] after:left-[0px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[14px] after:w-[14px] after:transition-all peer-checked:bg-[#F6AE2D]',
        // SwitchToggel:'w-11 h-6 bg-gray-400 rounded-full peer  peer-focus:ring-green-300  peer-checked:after:translate-x-full peer-checked:after:border-white after:content after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#F6AE2D]',
    }, 
    Model: {
        //  Model POPUP 33658A
        headerbg: '#3266b9',
        headerbgexcel: '#1D6F42',
        modalWidth: '30vw max-lg:10vw',
        modalWidth50: '50vw max-lg:15vw',
        modalWidthProcessscreen: '60vw max-lg:25vw',
        closebtncolorProcessscreen: 'White',
        headerbgProcessscreen: 'White',
        modalWidthUser: '30vw max-lg:10vw',
        bodybg: 'White',
        bodytextcolor: 'Black',
        // closebtncolor: '#fc581c',
        closebtncolor: '#002867',
        headerheight: '40px',
        modelConfirm: 'Confirm',
        resetpassword: 'Reset Your Password',
        Manageprivilages: 'Manage Privilages',
    },
    RegExp: {
        emailRegExp: /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i,
        digitRegExp: /(?=.*?[0-9])/,
        specialCharRegExp: /(?=.*?[#?!@$%^&*-])/,
    },
    ToolTip: {
        error: 'absolute  right-[-200px] text-center border-[1px] border-red-500 top-[] p-2 rounded-lg w-[200px]  bg-white text-[#5e5c5c] text-[11px]',
        hover: 'opacity-100 bg-[#F6AE2D] hover:bg-[#F6AE2D] focus:ring-[#3266b9] inline-flex items-center rounded-full p-3 text-white shadow-sm transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        hoverflex: 'fixed bottom-6 right-6',

        iconsize: 'h-7 w-7',
        addbutton: 'w-[50px] h-[50px] relative flex flex-col items-center group opacity-100 bg-[#1F52A3]  focus:ring-[#089de3]  rounded-full p-3 text-white shadow-[#696969] shadow-lg transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        tooltiptext: 'rounded-md  relative min-w-[100px] z-10 py-2 text-sm font-bold leading-none text-white  bg-[#089de3]',
        tooltipGroup: 'absolute bottom-7 flex-col items-center hidden mb-6 group-hover:flex',
        tooltipArrow: 'w-3 h-3 -mt-2 rotate-45 bg-[#089de3]'
    }, Icon: {
        search: {
            size: 20
        }
    },
    Select: {
        textbox: 'w-[100%] text-[12px]  bg-blue-800 bg-opacity-10 rounded-md   h-10 text-black font-normal  py-0 px-[10px] placeholder:text-[11px] focus:outline-none focus:border focus:border-blue-800',
        dropDownStyles: {
            control: (base, state) => ({
                ...base,
                background: "#1f52a31a",
                fontSize: '12px',
                borderRadius: "6px",
                border: 'none',
                '&:hover': { borderColor: '#cecef8', border: '1px solid #1F52A3' }, // border style on hover
                // default border color
                boxShadow: 'none', // no box-shadow 
                minHeight: '40px',
                // height: '35px',
                color: "black",
            }),
            menuList: styles => ({
                ...styles,
                //    background: 'papayawhip' ,
            }),
            option: (provided, state) => ({
                ...provided,
                //fontWeight: state.isSelected ? "bold" : "normal",
                color: "black",
                //   height: 10,
                //   width: 300,
                padding: 4,
                // backgroundColor: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            singleValue: (provided, state) => ({
                ...provided,
                color: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            menu: base => ({
                ...base,
                zIndex: 100
            }),
            placeholder: (defaultStyles) => ({
                ...defaultStyles,
                // color: '#eaf1fa',
                fontSize: '12px',
            })
        },
        dropDownStylesRed: {
            control: (base, state) => ({
                ...base,
                background: "#eaf1fa",
                fontSize: '13px',
                // borderRadius: "8px",
                border: '1px solid #f74a73',
                '&:hover': { borderColor: '#f74a73', border: '1px solid #f74a73' }, // border style on hover
                // default border color
                boxShadow: 'none', // no box-shadow 
                minHeight: '30px',
                // height: '35px',
            }),
            menuList: styles => ({
                ...styles,
                //    background: 'papayawhip' ,
            }),
            option: (provided, state) => ({
                ...provided,
                //fontWeight: state.isSelected ? "bold" : "normal",
                color: "black",
                //   height: 10,
                //   width: 300,
                padding: 4,
                // backgroundColor: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            singleValue: (provided, state) => ({
                ...provided,
                color: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            menu: base => ({
                ...base,
                zIndex: 100
            }),
            placeholder: (defaultStyles) => ({
                ...defaultStyles,
                // color: '#eaf1fa',
                fontSize: '13px',

            })
        }
    },
};
// bg-[#1f52a3] BLUE COLOR