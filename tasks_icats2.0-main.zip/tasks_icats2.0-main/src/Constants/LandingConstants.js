//SCREEN ID -3061
export const LandingConstants = {
    HOME: {
        MAIN_SLOGAN: 'Robotization: Embracing Smart Automated Testing',
        SUB_SLOGAN_1: 'With good automated testing solution not only ensuring',
        SUB_SLOGAN_2: 'absence of bugs but also ensuring presence of value.',
        READ_MORE:'Read More',
        iCATS_SUMMARY_1: 'iCATS, a collection of automated functional test scripts purely focused on the automated integrated testing of all applications in use to confirm the quality and stability of frequent application releases.iCATS, a unique that contains end-to-end business scenarios which will cut across all applications in use.',
        iCATS_SUMMARY_2: 'iCATS provides a standardized and consistent automation approach with high reusability, ease of maintenance and lower upfront costs.',
        STATISTICS_PERC: {
            PERC_1: '75-80%',
            PERC_2: '50-60%',
            PERC_3: '70-80%',
        },
        STATISTICS_DESC: {
            DESC_1: 'Reduce test execution turnaround \n by at least',
            DESC_2: 'Reduce testing costs \n by at least',
            DESC_3: 'Increase test coverage \n by at least',
        },
    },
    NAVBAR: {
        HOME: 'Home',
        ABOUT: 'About',
        SIGN_IN: 'Sign In',
    },
    FOOTER: {
        CopyRight: '© 2023 Igosolutions™. All Rights Reserved. V-0.0.1'
    },
}