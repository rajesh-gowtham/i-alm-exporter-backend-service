/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      keyframes: {
        poppup: {
          "0%": {
            transform: "scale(0.8,0.8)",
            // "animation-timing-function": "cubic-bezier(0.8, 0, 1, 1)"
          },
          "100%": {
            transform: "scale(1,1)",
            // "animation-timing-function": "cubic-bezier(0.8, 0, 0.2, 1)"
          }
        },
        falldown: {
          "0%": {
            transform: "translateY(-15%)",
            opacity: 0 ,
            // "animation-timing-function": "cubic-bezier(0, 0, 0, 1)"
          },
          "70%": {
            opacity: 0 ,
            // "animation-timing-function": "cubic-bezier(0.7, 0, 1, 1)"
          },
          "100%": {
            transform: "translateY(0%)",
            opacity: 1,
            // "animation-timing-function": "cubic-bezier(1, 0, 1, 1)"
          }
        },
       
        dropdown: {
          "0%": {
            height: "10%",
            // "animation-timing-function": "cubic-bezier(0, 0, 0, 1)"
            // opacity: 0
          },
          "100%": {
            height: '100%',
            // opacity: 1 ,
            // "animation-timing-function": "cubic-bezier(0, 0, 1, 1)"
          }
        }
      },
      animation: {
        poppup: 'poppup 0.4s ease-in-out ',
        falldown: 'falldown 0.4s ease-in-out both ',
        dropdown: 'dropdown 0.4s ease-in-out forwards',

      },
      backgroundImage: {
        'login-img': "url('https://wpassets.porttechnology.org/wp-content/uploads/2020/02/25161441/iStock-906577826.jpg')",
        'card-img': "url('./images/circle.png)"
      },
      colors: {
        // 'page-header': "#181c32",
        'page-header': "#1F52A3",
        'search-border': "#b7b7f7",
        'search-text': '#181c32',
        'search-bg': '#ebeef6',
        'delete-user-text': '#ea4e54',
        'footer-border': '#e5e7eb',
        'error-red': '#f86868',
        'logo-blue': '#1f52a3',
        'logo-orange': '#ec842a',
        blue: {
          950: '#17275c',
        },
      },
      fontSize: {
        // 'page-header-2xl': ['1.5rem', {
        //   lineHeight: '2rem',
        //   letterSpacing: '-0.01em',
        //   fontWeight: '700',
        //   fontWeight: '700',
        // }],
        'page-header-2xl': ['18px' /* 18px */, {
          lineHeight: 'normal'/* 28px */,
          letterSpacing: '-0.01em',
          fontWeight: '500',
        }],

        'search-text-size': ['0.875rem', {
          lineHeight: '1.25rem',
          letterSpacing: '-0.01em',
          fontWeight: '400',
        }],
        'mob-txt-sm8px': ['8px', {}],
        'mob-txt-sm': ['10px', {}],
        'mob-txt-md': ['12px', {}],
        'mob-txt-lg': ['15px', {}],
        'mob-txt-1xl': ['20px', {}],
        'mob-txt-10xl': ['100px', {}]
      },
      fontFamily: {
        'teko': 'Teko, sans-serif',
        'roboto': 'Roboto, sans-serif'
      },

    }
  },
  plugins: [],
}
