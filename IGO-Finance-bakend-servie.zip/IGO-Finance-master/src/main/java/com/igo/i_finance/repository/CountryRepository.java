package com.igo.i_finance.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.igo.i_finance.model.Countries;

@Repository
public interface CountryRepository extends JpaRepository<Countries, Long> {

	@Query("SELECT s FROM Countries s WHERE s.continents.continentId = :continentId")
	List<Countries> findByContinentId(@Param("continentId")Long continentId);
	
	@Query("SELECT s FROM Countries s WHERE s.continentRegions.continentRegionId = :continentRegId")
	List<Countries> findByContinentRegionId(@Param("continentRegId")Long continentRegId);

}
