package com.igo.i_finance.serviceimpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.igo.i_finance.exception.UnknownException;
import com.igo.i_finance.model.City;
import com.igo.i_finance.model.ContinentRegions;
import com.igo.i_finance.model.Continents;
import com.igo.i_finance.model.Countries;
import com.igo.i_finance.model.CountriesRegions;
import com.igo.i_finance.model.States;
import com.igo.i_finance.repository.CityRepository;
import com.igo.i_finance.repository.ContinentRegRepository;
import com.igo.i_finance.repository.ContinentRepository;
import com.igo.i_finance.repository.CountryRegRepository;
import com.igo.i_finance.repository.CountryRepository;
import com.igo.i_finance.repository.StatesRepository;
import com.igo.i_finance.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService {
	
	@Autowired
	private ContinentRepository continentRepository;
	
	@Autowired
	private CountryRepository countryRepository;
	
	@Autowired
	private ContinentRegRepository continentRegRepository ;
	
	@Autowired
	private CountryRegRepository countryRegRepository;
	
	@Autowired
	private StatesRepository statesRepository;
	
	@Autowired
	private CityRepository cityRepository;
	

	@Override
	public List<Map<String, Object>> getAllContinents() {
		try {
			List<Continents> continents = continentRepository.findAll();
			if(continents.isEmpty())
				return Collections.emptyList();
			
			return continents.stream()
					.sorted((cont1, cont2) -> cont1.getContinentName().compareTo(cont2.getContinentName()))
					.map(continent -> {
						Map<String, Object> map = new LinkedHashMap<>();
						map.put("continentId", continent.getContinentId());
						map.put("continentName", continent.getContinentName());
						map.put("continentCode", continent.getContinentCode());
						return map;
					}).toList();

		} catch (Exception e) {
			throw new UnknownException(e.getMessage());
		}
	}
    
	@Override
	public List<Map<String, Object>> getContRegs(Long continentId) {
		try {
			List<ContinentRegions> continentRegions = continentRegRepository.findByContinentId(continentId);
			if (continentRegions.isEmpty())
				return Collections.emptyList();
			
			return continentRegions.stream()
					.sorted((cr1, cr2) -> cr1.getContinentRegionName().compareTo(cr2.getContinentRegionName()))
					.map(contReg -> {
						Map<String, Object> map = new LinkedHashMap<String, Object>();
						map.put("contRegId", contReg.getContinentRegionId());
						map.put("contRegName", contReg.getContinentRegionName());
						map.put("continentId", contReg.getContinents().getContinentId());
						return map;
					}).toList();
		} catch (Exception e) {
			System.out.println("-------------------------------------");
			throw new UnknownException(e.getMessage());
		}
	}

	@Override
	public List<Map<String, Object>> getCountries(String type, Long id) {
		try {

			List<Countries> countryList = new ArrayList<Countries>();

			switch (type.toLowerCase()) {

			case "continent":
				countryList = countryRepository.findByContinentId(id);
				break;
			case "continent-region":
				countryList = countryRepository.findByContinentRegionId(id);
				break;

			}
			if (countryList.isEmpty())
				return Collections.emptyList();

			List<Map<String, Object>> countries = countryList.stream()
					.sorted((country1, country2) -> country1.getCountryName().compareTo(country2.getCountryName()))
					.map(country -> {
						Map<String, Object> map = new LinkedHashMap<String, Object>();
						map.put("countryId", country.getCountryId());
						map.put("countryName", country.getCountryName());
						map.put("countryCode", country.getCountryCode());
						map.put("countryDialCode", country.getCountryDialCode());
						if(country.getContinents().getContinentId()!=null)
						map.put("continentId", String.valueOf(country.getContinents().getContinentId()));
						if(country.getContinentRegions().getContinentRegionId()!=null)
						map.put("continentRegId", String.valueOf(country.getContinentRegions().getContinentRegionId()));
						return map;
					}).toList();
			return countries;
		} catch (Exception e) {
			throw new UnknownException(e.getMessage());
		}

	}

	
	@Override
	public List<Map<String, Object>> getCounReg(Long countryId) {
		try {
		List<CountriesRegions> countRegList = countryRegRepository.findByCountryId(countryId);
		if (countRegList.isEmpty())
			Collections.emptyList();

		return countRegList.stream().sorted(Comparator.comparing(CountriesRegions::getCountryRegionName)).map(cr -> {
			Map<String, Object> map = new LinkedHashMap<String, Object>();
			map.put("countryRegionId", cr.getCountryRegionId());
			map.put("countryRegionName", cr.getCountryRegionName());
			map.put("countryId", cr.getCountry().getCountryId());

			return map;

		}).toList();
		}catch(Exception e) {
			throw new UnknownException(e.getMessage());
		}

	}

	@Override
	public List<Map<String, Object>> getStates(String type, Long id) {
		List<States> states = new ArrayList<States>();
		try {

			switch (type.toLowerCase()) {
			case "country":
				states = statesRepository.findStatesByCountryId(id);
				break;
			case "country-reg":
				states = statesRepository.findByCountryRegId(id);
				break;
			default:
				break;
			}

			if (states.isEmpty())
				Collections.emptyList();

			return states.stream().sorted(Comparator.comparing(States::getStateName)).map(st -> {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				map.put("stateId", st.getStateId());
				map.put("stateName", st.getStateName());
				if (st.getCountry().getCountryId() != null)
					map.put("countryId", st.getCountry().getCountryId());
				if (st.getCountryRegion().getCountryRegionId() != null)
					map.put("countryRegId", st.getCountryRegion().getCountryRegionId());
				return map;
			}).toList();

		} catch (Exception e) {
			throw new UnknownException(e.getMessage());
		}

	}

	@Override
	public List<Map<String, Object>> getCities(String type, Long id) {
		List<City> cities = new ArrayList<City>();
		try {

			switch (type.toLowerCase()) {
			case "country":
				cities = cityRepository.findCitiesByCountryId(id);
				break;
			case "country-reg":
				cities = cityRepository.findCitiesByCountryRegId(id);
				break;
			case "state":
				cities = cityRepository.findCitiesByStateId(id);
				break;
			default:
				break;
			}

			if (cities.isEmpty())
				Collections.emptyList();

			return cities.stream().sorted(Comparator.comparing(City::getCityName)).map(ct -> {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				map.put("cityId", ct.getCityId());
				map.put("cityName", ct.getCityName());
				if (ct.getCountry().getCountryId() != null)
					map.put("countryId", ct.getCountry().getCountryId());
				if (ct.getCountryRegion().getCountryRegionId() != null)
					map.put("countryRegId", ct.getCountryRegion().getCountryRegionId());
				if(ct.getState().getStateId()!=null)
					map.put("stateId", ct.getState().getStateId());
				return map;
			}).toList();

		} catch (Exception e) {
			throw new UnknownException(e.getMessage());
		}

	}

}
