package com.igo.i_finance.enums;

public enum Role {

	ADMIN,
    SUPERADMIN
}

