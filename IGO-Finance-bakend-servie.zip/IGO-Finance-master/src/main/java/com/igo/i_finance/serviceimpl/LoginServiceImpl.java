package com.igo.i_finance.serviceimpl;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.ott.InvalidOneTimeTokenException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.igo.i_finance.exception.InvalidCredentialsException;
import com.igo.i_finance.exception.OtpExpiredException;
import com.igo.i_finance.model.Session;
import com.igo.i_finance.model.User;
import com.igo.i_finance.repository.SessionRepository;
import com.igo.i_finance.repository.UserRepository;
import com.igo.i_finance.service.LoginService;
import com.igo.i_finance.utils.AsyncEmailService;
import com.igo.i_finance.utils.CommonUtils;
import com.igo.i_finance.utils.JwtService;

@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private CommonUtils commonUtils;
	
	@Autowired
	private AsyncEmailService asyncEmailService;
	
	@Autowired
	private SessionRepository sessionRepository;
	
	@Autowired
	private JwtService jwtService;

	@Override
	@Transactional
	public Map<String, Object> validateUser(Map<String, String> request) {
		
		Map<String,Object> map = new HashMap<String, Object>();
		
		try {
			
			User user = userRepository.findByEmail(request.get("email"));
				if(user==null) {
					throw new InvalidCredentialsException("Invalid email or password");
				}
		
			if(!passwordEncoder.matches(request.get("password"),user.getPassword())) {
				throw new InvalidCredentialsException("Invalid email or password");
			}
		String otp = commonUtils.generateOtp();	
		
		map.put("userId",user.getUserId());
		map.put("firstName",user.getFirstName());
		map.put("lastName",user.getLastName());
		map.put("email",user.getEmail());
		map.put("phoneNumber",user.getPhoneNumber());
		map.put("resetToken",null);
		map.put("otp",otp);
		
		String emailBody = "Dear "+user.getFirstName()+",<br><br>" +
			    "Enter the one time password to continue your login " + otp + ".<br><br>" ;
		
		user.setOtp(passwordEncoder.encode(otp));
		user.setOtpStatus("Pending");
		userRepository.save(user);
		
		asyncEmailService.sendMailLink(user.getEmail(), "One time password", emailBody);
				
		}catch (InvalidCredentialsException e) {
	        throw e;
	    } catch (Exception e) {
	        throw new RuntimeException("An unexpected error occurred while validating user",e);
	    }		
		return map;
	}


	@Override
	@Transactional
	public Map<String, Object> validOtp(Map<String, String> request) {
		String token = null;
		try {
		
		Map<String,Object> map = new HashMap<String, Object>();
				
		User user = userRepository.findByEmail(request.get("email"));
		
		if(user==null){
			throw new UsernameNotFoundException("User not exist with : "+request.get("email"));
		}
		
		if (!passwordEncoder.matches(request.get("otp"),user.getOtp()) 
		        || !LocalDateTime.now().isBefore(user.getUpdatedAt().plusMinutes(2))) {
		    throw new InvalidOneTimeTokenException("Invalid Otp");
		}

		
		else if(LocalDateTime.now().isAfter(user.getUpdatedAt().plusMinutes(2))) {
			throw new OtpExpiredException("Otp expired");
		}
		else if(passwordEncoder.matches(request.get("otp"),user.getOtp())) {
			
			  try {
				token = jwtService.generateToken(user.getEmail());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  Session sessions = sessionRepository.findByEmail(user.getEmail());
				if(sessions!=null) {
					sessionRepository.deleteByEmail(user.getEmail()); // Invalidate previous session
					sessionRepository.flush();
				}
		        Session session = new Session();
		        session.setEmail(user.getEmail());
		        session.setToken(token);
		        session.setExpiryDate(LocalDateTime.now().plusHours(24));
		        
		        sessionRepository.save(session);
		        map.put("userId", String.valueOf(user.getUserId()));
		        map.put("accessToken", token);
		        map.put("email", user.getEmail());
		    	map.put("firstName",user.getFirstName());
				map.put("lastName",user.getLastName());
				map.put("phoneNumber",user.getPhoneNumber());
		        
		        
		        user.setOtpStatus("Verfied");
		        userRepository.save(user);
				
		}
		return map;
		
		}catch(InvalidOneTimeTokenException e) {
			throw e;
		}catch(OtpExpiredException e) {
			throw e;
		}
		catch(Exception e) {
	        throw new RuntimeException("An unexpected error occurred while validating otp",e);
		}
		
	}
	
	public boolean validateToken(String token) {
        return sessionRepository.findByToken(token)
                .filter(session -> session.getExpiryDate().isAfter(LocalDateTime.now()))
                .isPresent();
    }

}
