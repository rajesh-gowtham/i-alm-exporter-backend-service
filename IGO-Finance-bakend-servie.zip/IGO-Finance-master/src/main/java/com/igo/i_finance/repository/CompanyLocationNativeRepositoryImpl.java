package com.igo.i_finance.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class CompanyLocationNativeRepositoryImpl implements CompanyLocationNativeRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Map<String, Object>> fetchCompanyLocationHierarchy(String companyName) {

		String sql = """
				SELECT
	c.company_id AS companyId, 
	c.company_name AS companyName,

	bu.bu_id AS businessUnitId, 
	bu.bu_name AS businessUnitName,

	ct.continent_id AS continentId, 
	ct.continent_name AS continentName,

	ctr.continent_region_id AS continentRegionId, 
	ctr.continent_region_name AS continentRegionName,

	cn.country_id AS countryId, 
	cn.country_name AS countryName,

	cr.country_region_id AS countryRegionId, 
	cr.country_region_name AS countryRegionName,

	s.state_id AS stateId, 
	s.state_name AS stateName,

	ci.city_id AS cityId, 
	ci.city_name AS cityName

FROM facilities f
JOIN company c ON f.company_id = c.company_id
JOIN business_units bu ON f.bu_id = bu.bu_id

LEFT JOIN city ci ON f.city_id = ci.city_id
LEFT JOIN states s ON ci.state_id = s.state_id

LEFT JOIN countries_regions cr 
    ON s.country_region_id = cr.country_region_id 
    OR ci.country_region_id = cr.country_region_id

LEFT JOIN countries cn 
    ON s.country_id = cn.country_id 
    OR cr.country_id = cn.country_id 
    OR ci.country_id = cn.country_id

LEFT JOIN continent_regions ctr 
    ON cn.continent_region_id = ctr.continent_region_id

LEFT JOIN continents ct 
    ON ctr.continent_id = ct.continent_id 
    OR cn.continent_id = ct.continent_id

WHERE LOWER(c.company_name) = LOWER(:companyName)
				""";
		@SuppressWarnings("unchecked")
		List<Object[]> rows = entityManager.createNativeQuery(sql)
				.setParameter("companyName", companyName)
				.getResultList();

		List<Map<String, Object>> result = new ArrayList<>();
		List<String> columnNames = List.of(
				"companyId", "companyName", "businessUnitId", "businessUnitName",
				"continentId", "continentName", "continentRegionId", "continentRegionName",
				"countryId", "countryName", "countryRegionId", "countryRegionName",
				"stateId", "stateName", "cityId", "cityName"
		);

		for (Object[] row : rows) {
			Map<String, Object> map = new LinkedHashMap<>();
			for (int i = 0; i < row.length; i++) {
				map.put(columnNames.get(i), row[i]);
			}
			result.add(map);
		}
		return result;
	}
}
