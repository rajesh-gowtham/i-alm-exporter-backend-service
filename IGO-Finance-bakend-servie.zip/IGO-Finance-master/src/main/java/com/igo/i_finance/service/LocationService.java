package com.igo.i_finance.service;

import java.util.List;
import java.util.Map;

public interface LocationService {

	List<Map<String, Object>> getAllContinents();

	List<Map<String, Object>> getCountries(String type, Long id);

	List<Map<String, Object>> getContRegs(Long continentId);

	List<Map<String, Object>> getCounReg(Long countryId);

	List<Map<String, Object>> getStates(String type, Long id);

	List<Map<String, Object>> getCities(String type, Long id);

}
