package com.igo.i_finance.repository;	
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igo.i_finance.model.City;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

	@Query("SELECT s FROM City s WHERE s.cityName = :cityName AND s.state.stateId = :stateId")
	Optional<City> findByNameAndStateId(@Param("cityName")String cityName, @Param("stateId")Long stateId);
    
	@Query("SELECT s FROM City s WHERE s.cityName = :cityName AND s.countryRegion.countryRegionId = :countryRegionId")
	Optional<City> findByNameAndCountryRegionId(@Param("cityName")String cityName,@Param("countryRegionId") Long countryRegionId);
	
	@Query("SELECT s FROM City s WHERE s.cityName = :cityName AND s.country.countryId = :countryId")
	Optional<City> findByNameAndCountryId(@Param("cityName")String cityName,@Param("countryId") Long countryId);

	@Query("SELECT s FROM City s WHERE s.country.countryId = :countryId")
	List<City> findCitiesByCountryId(@Param("countryId") Long countryId);
    
	@Query("SELECT s FROM City s WHERE s.countryRegion.countryRegionId = :countryRegionId")
	List<City> findCitiesByCountryRegId(@Param("countryRegionId") Long countryRegionId);

	@Query("SELECT s FROM City s WHERE s.state.stateId = :stateId")
	List<City> findCitiesByStateId(@Param("stateId")Long stateId);

}
