package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "company_id")
	private Long companId;
    
	@NotBlank(message = "Company name is required")
	@Column(name = "company_name",nullable = false,unique = true)
	private String companyName;
	
	@Column(name = "company_logo")
	private String logo;
	
	@OneToMany(mappedBy = "company",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<BusinessUnits> businessUnits;
	
	@OneToMany(mappedBy = "company",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Facilities> facilities;
	
	@OneToMany(mappedBy = "company",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<User> users;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

}
