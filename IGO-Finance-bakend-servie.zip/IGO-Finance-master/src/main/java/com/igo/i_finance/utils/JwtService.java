package com.igo.i_finance.utils;

import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

private static final SecretKey key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    
    public String generateToken(String username) throws Exception {
        String token = Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .signWith(key)
                .compact();
        return EncryptDeCrypt.encrypt(token);
    }

    public String extractToken(String encryptedToken) throws Exception {
        String token = EncryptDeCrypt.decrypt(encryptedToken);
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
    
    public boolean validateToken(String encryptedToken) {
        try {
        	String token = EncryptDeCrypt.decrypt(encryptedToken);
            Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            System.out.println("JWT Validation failed: " + e.getMessage());
            return false;
        }
    
    }
}