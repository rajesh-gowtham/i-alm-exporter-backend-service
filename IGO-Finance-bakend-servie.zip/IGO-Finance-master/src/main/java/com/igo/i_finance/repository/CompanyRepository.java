package com.igo.i_finance.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igo.i_finance.model.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Long> {

//	@Query("SELECT s FROM Company s WHERE s.companyName = :companyName")
//	Company findByName(@Param("companyName")String companyName);

    @Query("SELECT c FROM Company c WHERE LOWER(c.companyName) = LOWER(:companyName)")
	Company findByCompanyNameIgnoreCase(@Param("companyName")String companyName);

//	boolean existsByCompanyNameIgnoreCase(String companyName);

}
