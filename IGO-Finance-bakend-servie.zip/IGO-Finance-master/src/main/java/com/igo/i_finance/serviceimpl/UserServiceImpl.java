package com.igo.i_finance.serviceimpl;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igo.i_finance.exception.InvalidCredentialsException;
import com.igo.i_finance.exception.UnknownException;
import com.igo.i_finance.model.User;
import com.igo.i_finance.repository.UserRepository;
import com.igo.i_finance.service.UserService;
import com.igo.i_finance.utils.AsyncEmailService;
import com.igo.i_finance.utils.EncryptDeCrypt;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AsyncEmailService asyncEmailService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	@Transactional
	public void generateResetToken(String email, HttpServletRequest request) throws Exception {
		try {
		User user = userRepository.findByEmail(email);
		if (user != null) {
			String resetToken = generateRandomToken();
			user.setResetToken(resetToken);
			userRepository.save(user);
			try {
				sendResetTokenEmail(user.getFirstName(), user.getEmail(), resetToken, request);
			} catch (Exception e) {
				throw new Exception("Error sending link");
			}
		} else {
			throw new InvalidCredentialsException("Invalid user");
		}
		}catch(InvalidCredentialsException e) {
			e.printStackTrace();
			throw e;		
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new UnknownException(e.getMessage());
		}
	}
	
	private String generateRandomToken() {
		int min = 100000;
		int max = 999999;
		Random random = new Random();

		return String.valueOf(random.nextInt(max - min + 1) + min);
	}
	
	public void sendResetTokenEmail(String userName, String userEmail, String resetToken, HttpServletRequest request)
			throws Exception {
		
		
		String resetUrl = request.getRequestURL().toString().replace(request.getRequestURI(), "") + "/";
		String encryptedResetToken = EncryptDeCrypt.encrypt(resetToken);

		// Construct the reset URL
		String originHeader = request.getHeader("Origin");
		if (originHeader != null && !originHeader.isEmpty()) {
			resetUrl = originHeader;
		} else {
			// If Origin header is not present, construct the URL using scheme, server name,
			// and port
			String scheme = request.getScheme();
			String serverName = request.getServerName();
			int port = request.getServerPort();

			// Construct the reset URL
			resetUrl = scheme + "://" + serverName + (port != 80 && port != 443 ? ":" + port : "");
		}

		resetUrl += "/resetPassword" + "/" + userEmail + "/" + encryptedResetToken;

		String emailContent = "Hi " + userName + ",<br><br>"
				+ "A password change has been requested for your account. If this was you, please use the link below <br>"
				+ "to reset your password.<br>"
				+ "<a href=\"" + resetUrl + "\">ResetPassword</a><br><br>"
				+ "Thanks & regards,<br>"
				+ "I-Finance Admin";
		System.out.println("Resest Url" + resetUrl);		

		asyncEmailService.sendMailLink(userEmail, "Password reset link", emailContent);
		
	}

	@Override
	public void resetPassword(Map<String, String> request) throws Exception  {
		try {
		User user = userRepository.findByEmail(request.get("email"));
		
		String decryptedResetToken =EncryptDeCrypt.decrypt(request.get("resetToken"));

		if (user != null) {
			if (user.getResetToken() != null && user.getResetToken().equals(decryptedResetToken)) {
				user.setPassword(passwordEncoder.encode(request.get("newPassword")));
				user.setResetToken(null);
				userRepository.save(user);
			} else {
				throw new InvalidCredentialsException("Reset token mismatched");
			}
		} else {
			throw new InvalidCredentialsException("Invalid user");
		}
		}catch(InvalidCredentialsException e) {
			e.printStackTrace();
			throw e;
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new UnknownException(e.getMessage());
		}
	}



}
