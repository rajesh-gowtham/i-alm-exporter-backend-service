package com.igo.i_finance.service;
import java.util.Map;
import com.igo.i_finance.dto.UserFacilityRequestDto;
import com.igo.i_finance.dto.UserFacilityResponseDto;

public interface UserCompanyRegistrationService {

	UserFacilityResponseDto registerUserCompany(UserFacilityRequestDto userFacilityRequestDto);

	String isEmailAlreadyExist(String email);

	Map<String, Object> fetchCompanyDetails(String companyName);

}
