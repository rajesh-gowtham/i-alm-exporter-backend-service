package com.igo.i_finance.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igo.i_finance.model.BusinessUnits;

@Repository
public interface BuRepository extends JpaRepository<BusinessUnits, Long> {

	@Query("SELECT s FROM BusinessUnits s WHERE s.buName = :buName AND s.company.companId = :companyId")
	Optional<BusinessUnits> findByNameAndCompanyId(@Param("buName")String buName,@Param("companyId") Long companyId);

}
