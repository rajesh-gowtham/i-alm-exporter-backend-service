package com.igo.i_finance.controller;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.igo.i_finance.service.LocationService;

@RestController
@RequestMapping("/api/location")
public class LocationController {
	
	@Autowired
	private LocationService locationService;
	
	@GetMapping("/getContinents")
	public ResponseEntity<List<Map<String,Object>>> getContinents(){
		
		List<Map<String,Object>> continents = locationService.getAllContinents();
		return new ResponseEntity<>(continents, HttpStatus.OK);
	   
	}
	
	@GetMapping("/getContRegByCont/{continentId}")
	public ResponseEntity<List<Map<String,Object>>> getContinentRegionsByContinent(@PathVariable Long continentId){
		
		List<Map<String,Object>> continentReg = locationService.getContRegs(continentId);
		return new ResponseEntity<List<Map<String,Object>>>(continentReg, HttpStatus.OK);
		
	}
	
	@GetMapping("/getCountriesByContinentOrReg")
	public ResponseEntity<List<Map<String,Object>>> getCountriesByContinentOrReg
	                     (@RequestParam String type,@RequestParam Long id){
		
		List<Map<String,Object>> countries = locationService.getCountries(type,id);
		return new ResponseEntity<List<Map<String,Object>>>(countries, HttpStatus.OK);
		
	}
	
	@GetMapping("/getCountRegByCount/{countryId}")
	public ResponseEntity<List<Map<String,Object>>> getCountRegByCountry(@PathVariable Long countryId){
		
		List<Map<String,Object>> countReg = locationService.getCounReg(countryId);
		return new ResponseEntity<List<Map<String,Object>>>(countReg, HttpStatus.OK);
		
	}
	
	@GetMapping("/getStates")
	public ResponseEntity<List<Map<String,Object>>> getStateByCountOrCountReg
	                     (@RequestParam String type,@RequestParam Long id){
		
		List<Map<String,Object>> states = locationService.getStates(type,id);
		
		return new ResponseEntity<List<Map<String,Object>>>(states, HttpStatus.OK);
		
	}
	
	@GetMapping("/getCities")
	public ResponseEntity<List<Map<String,Object>>> getCityisByCountOrCountRegOrStates
	                     (@RequestParam String type,@RequestParam Long id){
		
		List<Map<String,Object>> cities = locationService.getCities(type,id);
		
		return new ResponseEntity<List<Map<String,Object>>>(cities, HttpStatus.OK);
		
	}
	

}
