package com.igo.i_finance.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igo.i_finance.model.States;

@Repository
public interface StatesRepository extends JpaRepository<States, Long> {

	@Query("SELECT s FROM States s WHERE s.stateName = :stateName AND s.countryRegion.countryRegionId = :countryRegionId")
	Optional<States> findByNameAndCountryRegionId(@Param("stateName")String stateName,@Param("countryRegionId") Long countryRegionId);
	
	@Query("SELECT s FROM States s WHERE s.stateName = :stateName AND s.country.countryId = :countryId")
	Optional<States> findByNameAndCountryId(@Param("stateName")String stateName,@Param("countryId") Long countryId);
	
	@Query("SELECT s FROM States s WHERE s.country.countryId = :countryId")
	List<States> findStatesByCountryId(@Param("countryId") Long countryId);
	
	@Query("SELECT s FROM States s WHERE s.countryRegion.countryRegionId = :countryRegionId")
	List<States> findByCountryRegId(@Param("countryRegionId") Long countryRegionId);

}
