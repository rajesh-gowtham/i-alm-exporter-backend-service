package com.igo.i_finance.dto;
import com.igo.i_finance.enums.Status;
import lombok.Data;

@Data
public class UserFacilityResponseDto {
	
	private Long userId;
	private String userEmail;
	private Status status;

}
