package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Entity
@Data
public class CountriesRegions {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "common_seq")
	@SequenceGenerator(name = "common_seq",sequenceName = "common_id_seq",allocationSize = 1)
	@Column(name = "country_region_id")
	private Long countryRegionId; 
	
	@Column(name = "country_region_name")
	private String countryRegionName;
	
	@ManyToOne
	@JoinColumn(name = "country_id")
	private Countries country;
	
	@OneToMany(mappedBy = "countryRegion",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<States> states;
	
	@OneToMany(mappedBy = "countryRegion",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<City> city;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
