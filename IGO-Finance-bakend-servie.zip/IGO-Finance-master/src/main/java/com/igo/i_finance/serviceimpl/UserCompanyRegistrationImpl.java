package com.igo.i_finance.serviceimpl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.igo.i_finance.dto.UserDto;
import com.igo.i_finance.dto.UserFacilityRequestDto;
import com.igo.i_finance.dto.UserFacilityResponseDto;
import com.igo.i_finance.enums.AccessLevel;
import com.igo.i_finance.enums.Role;
import com.igo.i_finance.enums.Status;
import com.igo.i_finance.exception.AlreadyExistException;
import com.igo.i_finance.exception.UnknownException;
import com.igo.i_finance.model.BusinessUnits;
import com.igo.i_finance.model.City;
import com.igo.i_finance.model.Company;
import com.igo.i_finance.model.Countries;
import com.igo.i_finance.model.CountriesRegions;
import com.igo.i_finance.model.Facilities;
import com.igo.i_finance.model.States;
import com.igo.i_finance.model.User;
import com.igo.i_finance.repository.BuRepository;
import com.igo.i_finance.repository.CityRepository;
import com.igo.i_finance.repository.CompanyLocationNativeRepository;
import com.igo.i_finance.repository.CompanyRepository;
import com.igo.i_finance.repository.CountryRegRepository;
import com.igo.i_finance.repository.CountryRepository;
import com.igo.i_finance.repository.FacilityRepository;
import com.igo.i_finance.repository.StatesRepository;
import com.igo.i_finance.repository.UserRepository;
import com.igo.i_finance.service.UserCompanyRegistrationService;
import com.igo.i_finance.utils.AsyncEmailService;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserCompanyRegistrationImpl implements UserCompanyRegistrationService {

	@Autowired
	private CompanyRepository companyRepository;
	@Autowired
	private BuRepository buRepository;
	@Autowired
	private CountryRepository countryRepository;
	@Autowired
	private CountryRegRepository countryRegionRepository;
	@Autowired
	private StatesRepository statesRepository;
	@Autowired
	private CityRepository cityRepository;
	@Autowired
	private FacilityRepository facilityRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private CompanyLocationNativeRepository companyLocationNativeRepository;	
	@Autowired
	private AsyncEmailService asyncEmailService;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public UserFacilityResponseDto registerUserCompany(UserFacilityRequestDto req) {
		try {

			// Get Country
			Countries country = countryRepository.findById(req.getCountryId())
					.orElseThrow(() -> new EntityNotFoundException("Country not found"));

			// Get or create Country Region
			CountriesRegions countryRegion = null;
			if (req.getCountryRegionId() != null) {
				countryRegion = countryRegionRepository.findById(req.getCountryRegionId())
						.orElseThrow(() -> new EntityNotFoundException("Country Region not found"));
			} else if (req.getCountryRegionName() != null) {
				countryRegion = countryRegionRepository
						.findByNameAndCountryId(req.getCountryRegionName(), country.getCountryId()).orElseGet(() -> {
							CountriesRegions cr = new CountriesRegions();
							cr.setCountryRegionName(req.getCountryRegionName());
							cr.setCountry(country);
							return countryRegionRepository.saveAndFlush(cr);
						});
			}

			// Get or create State (based on Country or CountryRegion)
			States state = null;
			final CountriesRegions finalCountReg = countryRegion;
			if (req.getStateId() != null) {
				state = statesRepository.findById(req.getStateId())
						.orElseThrow(() -> new EntityNotFoundException("State not found"));
			} else if (req.getStateName() != null) {
				if (finalCountReg != null) {
					state = statesRepository
							.findByNameAndCountryRegionId(req.getStateName(), finalCountReg.getCountryRegionId())
							.orElseGet(() -> {
								States st = new States();
								st.setStateName(req.getStateName());
								st.setCountryRegion(finalCountReg);
								return statesRepository.saveAndFlush(st);
							});
				} else {
					state = statesRepository.findByNameAndCountryId(req.getStateName(), country.getCountryId())
							.orElseGet(() -> {
								States st = new States();
								st.setStateName(req.getStateName());
								st.setCountry(country);
								return statesRepository.saveAndFlush(st);
							});
				}
			}

			// Get or create City (based on State > CountryRegion > Country)
			City city = null;
			final States finalStates = state;
			if (req.getCityId() != null) {
				city = cityRepository.findById(req.getCityId())
						.orElseThrow(() -> new EntityNotFoundException("City not found"));
			} else if (req.getCityName() != null) {
				if (finalStates != null) {
					city = cityRepository.findByNameAndStateId(req.getCityName(), finalStates.getStateId())
							.orElseGet(() -> {
								City ct = new City();
								ct.setCityName(req.getCityName());
								ct.setState(finalStates);
								return cityRepository.saveAndFlush(ct);
							});
				} else if (finalCountReg != null) {
					city = cityRepository
							.findByNameAndCountryRegionId(req.getCityName(), finalCountReg.getCountryRegionId())
							.orElseGet(() -> {
								City ct = new City();
								ct.setCityName(req.getCityName());
								ct.setCountryRegion(finalCountReg);
								return cityRepository.saveAndFlush(ct);
							});
				} else {
					city = cityRepository.findByNameAndCountryId(req.getCityName(), country.getCountryId())
							.orElseGet(() -> {
								City ct = new City();
								ct.setCityName(req.getCityName());
								ct.setCountry(country);
								return cityRepository.saveAndFlush(ct);
							});
				}
			}

			Company company;
			company = companyRepository.findByCompanyNameIgnoreCase(req.getCompanyName());
            if(company==null) {
			Company newCompany = new Company();
			newCompany.setCompanyName(req.getCompanyName());
			company = companyRepository.saveAndFlush(newCompany);
            }

			// Business Unit mapping
            final Company comp = company;
			BusinessUnits bu = (req.getBuId() != null)
					? buRepository.findById(req.getBuId())
							.orElseThrow(() -> new EntityNotFoundException("Business Unit not found"))
					: buRepository.findByNameAndCompanyId(req.getBusinessUnitName(), comp.getCompanId())
							.orElseGet(() -> {
								BusinessUnits bs = new BusinessUnits();
								bs.setBuName(req.getBusinessUnitName());
								bs.setCompany(comp);
								return buRepository.saveAndFlush(bs);
							});

			// Get or create Facility
			final City finalCity = city;
			Facilities facility = facilityRepository.findByNameAndCityId(req.getFacilityName(), finalCity.getCityId())
					.orElseGet(() -> {
						Facilities fc = new Facilities();
						fc.setFacilityName(req.getFacilityName());
						fc.setAddressLine1(req.getAddressLine1() != null ? req.getAddressLine1() : null);
						fc.setAddressLine2(req.getAddressLine1() != null ? req.getAddressLine2() : null);
						fc.setPostalCode(req.getPostalCode());
						fc.setCurrencyCode(req.getCurrencyCode() != null ? req.getCurrencyCode() : null);
						fc.setCompany(comp);
						fc.setBusinessUnits(bu);
						fc.setCity(finalCity);
						return facilityRepository.saveAndFlush(fc);
					});

			// Create User
			UserDto userDto = req.getUser();
			User user = new User();
			user.setFirstName(userDto.getFirstName());
			user.setLastName(userDto.getLastName());
			User userEmail = userRepository.findByEmail(userDto.getEmail());
			if (userEmail != null)
				throw new AlreadyExistException("Email already exist : " + userDto.getEmail());
			else
				user.setEmail(userDto.getEmail());
			user.setPhoneNumber(userDto.getPhoneNumber());
			user.setPassword(passwordEncoder.encode(userDto.getPassword()));
			user.setRole(Role.ADMIN);
			user.setStatus(Status.INACTIVE);
			user.setAccessLevel(AccessLevel.FACILITY);
			user.setAccessLevelId(facility.getFacilityId());
			user.setCompany(company);
			user.setBusinessUnit(bu);
			user.setFacilities(facility);
			user = userRepository.saveAndFlush(user);

			UserFacilityResponseDto response = new UserFacilityResponseDto();

			response.setUserId(user.getUserId());
			response.setUserEmail(user.getEmail());
			response.setStatus(Status.INACTIVE);
			
			String emailBody = "Dear " + user.getFirstName() + ",<br><br>" +
				    "A user account has been successfully created for the facility <b>" + req.getFacilityName() + "</b>.<br><br>" +
				    "Please note that your account is currently pending approval from the application administrator.<br>" +
				    "You will be notified once your account has been reviewed and approved.<br><br>" +
				    "Thank you for your patience.<br><br>" +
				    "Thanks & regards,<br>" +
				    "I-Finance Admin";

				asyncEmailService.sendMailLink(user.getEmail(), "User Account Pending Approval", emailBody);


			return response;
		} catch (Exception e) {
			throw new UnknownException(e.getMessage());

		}
	}

	@Override
	public String isEmailAlreadyExist(String email) {
		User isPresent = userRepository.findByEmail(email);
		if (isPresent != null) {
			return "Email already exist : " + email;
		} else {
			return "Email not exist : " + email;
		}
	}

	 public Map<String, Object> fetchCompanyDetails(String companyName) {
		 List<Map<String, Object>> rows = companyLocationNativeRepository.fetchCompanyLocationHierarchy(companyName);

	        if (rows.isEmpty()) {
	            return Map.of(
	                "companyId", "",
	                "companyName", "",
	                "businessUnits", List.of()
	            );
	        }

	        Map<String, Object> response = new LinkedHashMap<>();
	        Map<Long, Map<String, Object>> businessUnitsMap = new LinkedHashMap<>();

	        Map<String, Object> firstRow = rows.get(0);
	        response.put("companyId", firstRow.get("companyId"));
	        response.put("companyName", firstRow.get("companyName"));
	        response.put("businessUnits", new ArrayList<>());

	        for (Map<String, Object> row : rows) {
	            Long buId = getId(row.get("businessUnitId"));
	            if (buId == null) continue;

	            Map<String, Object> buMap = businessUnitsMap.computeIfAbsent(buId, id -> {
	                Map<String, Object> bu = new LinkedHashMap<>();
	                bu.put("businessUnitId", buId);
	                bu.put("businessUnitName", row.get("businessUnitName"));
	                bu.put("continents", new ArrayList<>());
	                return bu;
	            });

	            List<Map<String, Object>> continents = getList(buMap, "continents");
	            addHierarchy(continents, row);
	        }

	        response.put("businessUnits", new ArrayList<>(businessUnitsMap.values()));
	        return response;
	    }

	    @SuppressWarnings("unchecked")
	    private void addHierarchy(List<Map<String, Object>> continents, Map<String, Object> row) {
	        Map<String, Object> continent = findOrCreate(continents, "continentId", row, "continentName", "continentId");
	        List<Map<String, Object>> continentRegions = getList(continent, "continentRegions");

	        Map<String, Object> continentRegion = findOrCreate(continentRegions, "continentRegionId", row, "continentRegionName", "continentRegionId");
	        List<Map<String, Object>> countries = getList(continentRegion, "countries");

	        Map<String, Object> country = findOrCreate(countries, "countryId", row, "countryName", "countryId");
	        List<Map<String, Object>> countryRegions = getList(country, "countryRegions");

	        Map<String, Object> countryRegion = findOrCreate(countryRegions, "countryRegionId", row, "countryRegionName", "countryRegionId");
	        List<Map<String, Object>> states = getList(countryRegion, "states");

	        Map<String, Object> state = findOrCreate(states, "stateId", row, "stateName", "stateId");
	        List<Map<String, Object>> cities = getList(state, "cities");

//	        Long cityId = getId(row.get("cityId"));
//	        if (cityId != null) {
//	            cities.add(Map.of(
//	                "cityId", cityId,
//	                "cityName", row.get("cityName")
//	            ));
//	        }
//	    }
	    

	    Long cityId = getId(row.get("cityId"));
	    if (cityId != null) {
	        boolean cityExists = cities.stream()
	            .anyMatch(city -> cityId.equals(getId(city.get("cityId"))));

	        if (!cityExists) {
	            cities.add(Map.of(
	                "cityId", cityId,
	                "cityName", row.get("cityName")
	            ));
	        }
	    }
	    }

	    private Map<String, Object> findOrCreate(List<Map<String, Object>> list, String idKey, Map<String, Object> row, String nameKey, String rowIdKey) {
	        Long id = getId(row.get(rowIdKey));
	        if (id == null) return Map.of();

	        return list.stream()
	            .filter(item -> id.equals(item.get(idKey)))
	            .findFirst()
	            .orElseGet(() -> {
	                Map<String, Object> map = new LinkedHashMap<>();
	                map.put(idKey, id);
	                map.put(nameKey, row.get(nameKey));
	                list.add(map);
	                return map;
	            });
	    }

	    @SuppressWarnings("unchecked")
	    private List<Map<String, Object>> getList(Map<String, Object> map, String key) {
	        return (List<Map<String, Object>>) map.computeIfAbsent(key, k -> new ArrayList<>());
	    }

	    private Long getId(Object obj) {
	        return (obj instanceof Number num) ? num.longValue() : null;
	    }


}
