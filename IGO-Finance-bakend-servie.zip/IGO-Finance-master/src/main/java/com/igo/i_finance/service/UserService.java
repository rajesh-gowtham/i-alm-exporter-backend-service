package com.igo.i_finance.service;

import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

public interface UserService {

	void generateResetToken(String email, HttpServletRequest request) throws Exception;

	void resetPassword(Map<String, String> requestPayload) throws Exception;

}
