package com.igo.i_finance.exception;
import java.time.LocalDateTime;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import com.igo.i_finance.dto.ErrorResponse;
import jakarta.persistence.EntityNotFoundException;


@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(EntityNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleEntityNotFoundException(EntityNotFoundException ex,WebRequest web) {
		return buildErrorResponse(ex, web, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(UnknownException.class)
	public ResponseEntity<ErrorResponse> handleUnknownException(UnknownException ex,WebRequest web) {
		return buildErrorResponse(ex, web, HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(AlreadyExistException.class)
	public ResponseEntity<ErrorResponse> handleEmailAlreadyException(AlreadyExistException ex,WebRequest web) {
		return buildErrorResponse(ex, web, HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(InvalidCredentialsException.class)
	public ResponseEntity<ErrorResponse> handleInvalidCredentialsException(InvalidCredentialsException ex,WebRequest web) {
		return buildErrorResponse(ex, web, HttpStatus.UNAUTHORIZED);
	}		
	private ResponseEntity<ErrorResponse> buildErrorResponse(Exception ex, WebRequest web, HttpStatus status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setMessage(ex.getMessage());
		errorResponse.setTimeStamp(LocalDateTime.now());
		errorResponse.setError(web.getDescription(false));
		return new ResponseEntity<>(errorResponse, status);
	}
}
