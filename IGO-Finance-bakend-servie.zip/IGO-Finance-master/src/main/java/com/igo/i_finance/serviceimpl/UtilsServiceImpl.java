package com.igo.i_finance.serviceimpl;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Currency;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;
import com.igo.i_finance.service.UtilsService;

@Component
public class UtilsServiceImpl implements UtilsService {

	public List<Map<String, String>> getCurrencies() {
		 Set<String> seen = new HashSet<>();

		    return Arrays.stream(Locale.getISOCountries())
		            .map(code -> {
		                Locale locale = new Locale("", code);
		                try {
		                    Currency currency = Currency.getInstance(locale);
		                    return (currency != null)
		                            ? new AbstractMap.SimpleEntry<>(locale, currency)
		                            : null;
		                } catch (Exception e) {
		                    return null; 
		                }
		            })
		            .filter(Objects::nonNull) 
		            .filter(entry -> entry.getValue() != null) 
		            .filter(entry -> seen.add(entry.getValue().getCurrencyCode())) 
		            .map(entry -> {
		                Map<String, String> map = new LinkedHashMap<>();
		                map.put("currencyCode", entry.getValue().getCurrencyCode());
		                map.put("currencyName", entry.getValue().getDisplayName());
		                map.put("countryName", entry.getKey().getDisplayCountry());
		                return map;
		            })
		            .sorted(Comparator.comparing(m -> m.get("currencyCode")))
		            .collect(Collectors.toList());
    }

}
