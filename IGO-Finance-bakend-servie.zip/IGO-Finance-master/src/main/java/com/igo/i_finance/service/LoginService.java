package com.igo.i_finance.service;

import java.util.Map;

public interface LoginService {

	Map<String, Object> validateUser(Map<String, String> request);

	Map<String, Object> validOtp(Map<String, String> request);

	boolean validateToken(String token);

}
