package com.igo.i_finance.enums;

public enum AccessLevel {

	COMPANY,
	BUSINESS_UNITS,
    CONTINENT,
    CONTINENT_REGION,
    COUNTRY,
    COUNTRY_REGION,
    STATE,
    CITY,
    FACILITY
}
