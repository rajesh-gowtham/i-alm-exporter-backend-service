package com.igo.i_finance.enums;

public enum CustomerType {
	
	BUSINESS,
	INDIVIDUAL

}
