package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Countries {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "common_seq")
	@SequenceGenerator(name = "common_seq",sequenceName = "common_id_seq",allocationSize = 1)
	@Column(name = "country_id")
	private Long countryId;
	
	@NotBlank(message = "Country code is required")
	@Column(name = "country_code",nullable = false)
	private String countryCode;
	
	@NotBlank(message = "Country name is required")
	@Column(name = "country_name",nullable = false,unique = true)
	private String countryName;
	
	@NotBlank(message = "Country dial code is required")
	@Column(name = "country_dial_code",nullable = false,unique = true)
	private String countryDialCode;
	
	@ManyToOne
	@JoinColumn(name = "continent_id")
	private Continents continents;
	
	@ManyToOne
	@JoinColumn(name = "continent_region_id")
	private ContinentRegions continentRegions;
	
	@OneToMany(mappedBy = "country", cascade = CascadeType.ALL,orphanRemoval = true)
	private List<CountriesRegions> countryRegion;
	
	@OneToMany(mappedBy = "country",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<States> states;
	
	@OneToMany(mappedBy = "country",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<City> city;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

}
