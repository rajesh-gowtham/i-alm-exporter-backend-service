package com.igo.i_finance.model;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Entity
@Data
public class Test {
	

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "test_name",nullable = false)
	private String testName;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
	

}
