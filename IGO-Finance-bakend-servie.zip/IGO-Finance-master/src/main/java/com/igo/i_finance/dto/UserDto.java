package com.igo.i_finance.dto;
import lombok.Data;

@Data
public class UserDto {
	
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private String password;
	private String userImage;
	private String role;
	private String status;
	private String accessLevel;
	private Long accessLevelId;
	

}
