package com.igo.i_finance.utils;
import java.util.Random;
import org.springframework.stereotype.Component;

@Component
public class CommonUtils {
public String generateOtp() {
		
		Random rand = new Random();
        int otp = 100000 + rand.nextInt(900000);
        return String.valueOf(otp);
		
		
	}
}
