package com.igo.i_finance.controller;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.igo.i_finance.dto.UserFacilityRequestDto;
import com.igo.i_finance.dto.UserFacilityResponseDto;
import com.igo.i_finance.service.UserCompanyRegistrationService;

@RestController
@RequestMapping("/api/Registration")
public class UserCompanyRegistrationController {
	// The Controller has been created to Register the company and facilities , user.
	
	@Autowired
	private UserCompanyRegistrationService userCompanyRegistrationService;	
	
	@PostMapping("/createCompany")
	public ResponseEntity<Object> userCompanyRegistration(@RequestBody UserFacilityRequestDto UserFacilityRequestDto){
		
		UserFacilityResponseDto userFacilityResponseDto = userCompanyRegistrationService.
				                               registerUserCompany(UserFacilityRequestDto);
		
		return new ResponseEntity<Object>(userFacilityResponseDto, HttpStatus.OK);
		
	}
	
	@GetMapping("/isEmailExist/{email}")
	public ResponseEntity<String> isEmailAlreadyExist(@PathVariable String email){
		
		String isPresent = userCompanyRegistrationService.isEmailAlreadyExist(email);
		return new ResponseEntity<String>(isPresent, HttpStatus.OK);
		
		
	}
	
	@GetMapping("/fetchCompanyDetail/{companyName}")
	public ResponseEntity<Map<String,Object>> getCompanyDetails(@PathVariable String companyName){
		
		
		Map<String,Object> response = userCompanyRegistrationService.fetchCompanyDetails(companyName);
		return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
		
	}

}
