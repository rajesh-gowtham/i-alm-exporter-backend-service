package com.igo.i_finance.exception;

public class OtpExpiredException extends RuntimeException {
	
	public OtpExpiredException(String message) {
		
		super(message);
		
	}

}
