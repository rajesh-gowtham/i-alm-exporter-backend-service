package com.igo.i_finance.dto;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class ErrorResponse {

	private String message;
    private String error;
    private LocalDateTime timeStamp;
}
