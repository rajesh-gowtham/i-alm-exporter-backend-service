package com.igo.i_finance.service;

import java.util.List;
import java.util.Map;

public interface UtilsService {

	List<Map<String, String>> getCurrencies();

}
