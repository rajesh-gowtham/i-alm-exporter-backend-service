package com.igo.i_finance.exception;

public class UnknownException extends RuntimeException {
	
	public UnknownException(String message) {
		
		super(message);
	}

}
