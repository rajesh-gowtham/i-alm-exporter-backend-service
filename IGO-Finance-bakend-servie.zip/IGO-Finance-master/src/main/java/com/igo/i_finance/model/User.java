package com.igo.i_finance.model;
import java.time.LocalDateTime;
import com.igo.i_finance.enums.AccessLevel;
import com.igo.i_finance.enums.Role;
import com.igo.i_finance.enums.Status;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "user_id")
	private Long userId;

	@NotBlank(message = "First name is required")
	@Column(name = "first_name", nullable = false)
	private String firstName;

	@NotBlank(message = "Last name is required")
	@Column(name = "last_name", nullable = false)
	private String lastName;
	
	@Email(message = "Email should be valid")
	@NotBlank(message = "Email is required")
	@Column(name = "email")
	private String email;

	@Size(min = 8,message = "Password must be minimum 8 chracters")
	@Column(name = "password")
	private String password;

	@Size(min = 10,max = 18, message = "Phone number must not exceed 15 characters")
	@Column(name = "phone_number")
	private String phoneNumber;
	
	@Column(name = "otp")
	private String otp;
	
	@Column(name = "otp_status")
	private String otpStatus;
	
	@Column(name = "reset_token")
	private String resetToken;

	@Enumerated(EnumType.STRING)
	@Column(name = "access_level", nullable = false)
	private AccessLevel accessLevel;

	@Column(name = "access_level_id", nullable = false)
	private Long accessLevelId;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Role role;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "company_id")
	private Company company;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bu_id")
	private BusinessUnits businessUnit;
	
	@ManyToOne
	@JoinColumn(name = "facility_id")
	private Facilities facilities;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

}
