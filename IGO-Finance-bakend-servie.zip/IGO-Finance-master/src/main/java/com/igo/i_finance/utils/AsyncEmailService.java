package com.igo.i_finance.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class AsyncEmailService {
	
	@Value("${smtp.email-username}")
    private String fromMail;

    @Autowired
    private JavaMailSender javaMailSender;
    
	
	  @Autowired 
	  public AsyncEmailService(JavaMailSender javaMailSender) {
	  this.javaMailSender = javaMailSender;
	  }
	 
	    
	    @Async
	    public void sendMailLink(MimeMessage message) {
	        javaMailSender.send(message);
	    }
	  
	     @Bean
		  public TaskExecutor taskExecutor() {
		        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		        executor.setCorePoolSize(10); 
		        executor.setMaxPoolSize(20); 
		        executor.setQueueCapacity(100);
		        executor.setThreadNamePrefix("EmailThread-");
		        executor.initialize();
		        return executor;
		    }
	
	    @Async
		public void sendMailLink(String userEmail, String subject, String text) {
			MimeMessage message = javaMailSender.createMimeMessage();
	        try {
	        	
	            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
	            helper.setTo(userEmail);
	            helper.setSubject(subject);
	            helper.setText(text, true);
	            helper.setFrom(fromMail);
	            sendMailLink(message);
	        } catch (MessagingException e) {
	            e.printStackTrace();
	        }
			
		}

}
