//package com.igo.i_finance.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.igo.i_finance.model.Currency;
//
//public interface CuurencyRepository extends JpaRepository<Currency, Long>{
//
//}
