package com.igo.i_finance.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.igo.i_finance.service.UtilsService;

@RestController
@RequestMapping("api/general")
public class UtilsController {
	
	@Autowired
	private UtilsService utilsService;
	
	@GetMapping("currencies")
	public ResponseEntity<List<Map<String,String>>> getCurrencies(){
		
		List<Map<String,String>> currencyList = utilsService.getCurrencies();
		return new ResponseEntity<List<Map<String,String>>>(currencyList, HttpStatus.OK);
		
	}
	
	@GetMapping("/testSecurity")
	public ResponseEntity<Map<String,String>> getDetails(){
		
		Map<String,String> map = new HashMap<String, String>();
		map.put("one", "Yess");
		map.put("two", "Yess");
		map.put("three", "Yess");
		
		return new ResponseEntity<Map<String,String>>(map, HttpStatus.OK);
		
	}

}
