package com.igo.i_finance.utils;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.igo.i_finance.exception.InvalidTokenException;
import com.igo.i_finance.service.LoginService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private JwtService jwtService;

	@Autowired
	@Lazy
	private LoginService loginService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
	        throws ServletException, IOException {

	    String authHeader = request.getHeader("Authorization");

	    try {
	        if (authHeader != null && authHeader.startsWith("Bearer ")) {
	            String token = authHeader.substring(7);
	            
	            System.out.println(token);
	            System.out.println("Inside the first if");

	            if (jwtService.validateToken(token) && loginService.validateToken(token)) {
	            	
	            	System.out.println("Inside the second if");
	                SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
	                        jwtService.extractToken(token), null, new ArrayList<>()));
	            } else {
	                throw new InvalidTokenException("Token is expired or invalid.");
	            }
	        }

	        chain.doFilter(request, response);

	    } catch (ExpiredJwtException e) {
	        sendErrorResponse(response, "JWT token expired. Please login again.", HttpStatus.UNAUTHORIZED.value());
	    } catch (MalformedJwtException e) {
	        sendErrorResponse(response, "Malformed JWT token.", HttpStatus.UNAUTHORIZED.value());
	    } catch (UnsupportedJwtException e) {
	        sendErrorResponse(response, "Unsupported JWT token.", HttpStatus.UNAUTHORIZED.value());
	    } catch (IllegalArgumentException e) {
	        sendErrorResponse(response, "JWT claims string is empty.", HttpStatus.UNAUTHORIZED.value());
	    } catch (InvalidTokenException e) {
	        sendErrorResponse(response, e.getMessage(), HttpStatus.UNAUTHORIZED.value());
	    } catch (Exception e) {
	        sendErrorResponse(response, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
	    }
	}
	
	
	private void sendErrorResponse(HttpServletResponse response, String message, int statusCode) throws IOException {
	    response.setStatus(statusCode);
	    response.setContentType("application/json");

	    String json = new ObjectMapper().writeValueAsString(
	        Map.of(
	            "message", message,
	            "timeStamp", LocalDateTime.now().toString(),
	            "error", "JWT validation error"
	        )
	    );

	    response.getWriter().write(json);
	}


	}
