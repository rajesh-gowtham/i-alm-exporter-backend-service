package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Facilities {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "common_seq")
	@SequenceGenerator(name = "common_seq",sequenceName = "common_id_seq",allocationSize = 1)
	@Column(name = "facility_id")
	private Long facilityId;
	
	@NotBlank(message = "Facility name is required")
	@Column(name = "facility_name",nullable = false)
	private String facilityName;
	
	@Column(name = "facility_address1")
    private String addressLine1;
    
	@Column(name = "facility_address2")
    private String addressLine2;
	
	@Column(name = "postal_code")
	private String postalCode;
	
	@Column(name = "currency_code")
	private String currencyCode;
	
	@ManyToOne
	@JoinColumn(name = "company_id")
	private Company company;
	
	@ManyToOne
	@JoinColumn(name = "bu_id")
	private BusinessUnits businessUnits;
	
	@OneToMany(mappedBy = "facilities",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<User> users;
	
	@OneToMany(mappedBy = "facilities",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Customers> customers;
	
	@ManyToOne
	@JoinColumn(name = "city_id")
	private City city;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
	
	

}
