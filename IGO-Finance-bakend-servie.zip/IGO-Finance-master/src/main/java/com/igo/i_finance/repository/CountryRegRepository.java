package com.igo.i_finance.repository;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.igo.i_finance.model.CountriesRegions;
@Repository
public interface CountryRegRepository extends JpaRepository<CountriesRegions,Long>{

	@Query("SELECT s FROM CountriesRegions s WHERE s.countryRegionName = :countryRegionName AND s.country.countryId = :countryId")
	Optional<CountriesRegions> findByNameAndCountryId(@Param("countryRegionName")String countryRegionName, @Param("countryId")Long countryId);

	@Query("SELECT s FROM CountriesRegions s WHERE s.country.countryId = :countryId")
	List<CountriesRegions> findByCountryId(@Param("countryId") Long countryId);
	
}
