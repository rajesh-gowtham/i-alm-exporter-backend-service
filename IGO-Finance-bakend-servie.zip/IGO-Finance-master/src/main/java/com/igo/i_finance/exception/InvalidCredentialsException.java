package com.igo.i_finance.exception;

public class InvalidCredentialsException extends RuntimeException {
	
	public InvalidCredentialsException(String message) {
		
		super(message);
	}

}
