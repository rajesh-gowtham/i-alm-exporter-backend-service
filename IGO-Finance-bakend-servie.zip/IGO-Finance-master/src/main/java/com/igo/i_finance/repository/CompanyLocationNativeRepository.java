package com.igo.i_finance.repository;
import java.util.List;
import java.util.Map;
import org.springframework.data.repository.query.Param;

public interface CompanyLocationNativeRepository{

	    List<Map<String, Object>> fetchCompanyLocationHierarchy(@Param("companyName") String companyName);
}
