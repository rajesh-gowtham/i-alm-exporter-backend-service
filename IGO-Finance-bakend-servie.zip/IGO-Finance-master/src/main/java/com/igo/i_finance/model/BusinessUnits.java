package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class BusinessUnits {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "bu_id")
	private Long buId;
	
	@NotBlank(message = "business unit name is required")
	@Column(name = "bu_name",nullable = false)
	private String buName;
	
	@ManyToOne
	@JoinColumn(name = "company_id",nullable = false)
	private Company company;

	@OneToMany(mappedBy = "businessUnits",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Facilities> facilities;
	
	@OneToMany(mappedBy = "businessUnit",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<User> users;
    
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
	
	
}
