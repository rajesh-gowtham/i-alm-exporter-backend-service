package com.igo.i_finance.enums;

public enum Status {

	ACTIVE,
    INACTIVE,
    PENDING
}
