package com.igo.i_finance.model;
import java.time.LocalDateTime;
import com.igo.i_finance.enums.CustomerType;
import com.igo.i_finance.enums.Status;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class Customers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "customer_id")
	private Long customerId;
	
	@NotBlank(message = "Customer name is required")
	@Column(name = "customer_name",nullable = false)
	private String customerName;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "customer_status")
	private Status status;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "customer_type")
	private CustomerType customerType;
	
	@Column(name = "payment_terms")
	private String paymentTerms;
	
	@ManyToOne
	@JoinColumn(name = "facility_id")
	private Facilities facilities;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
	

}
