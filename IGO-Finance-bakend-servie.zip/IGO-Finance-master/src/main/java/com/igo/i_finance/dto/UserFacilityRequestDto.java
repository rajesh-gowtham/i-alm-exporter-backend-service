package com.igo.i_finance.dto;
import lombok.Data;

@Data
public class UserFacilityRequestDto {
	
	private Long continentId;
	private String continentRegionName;
	private Long continentRegionId;
	private Long countryId;
	private String countryRegionName;
	private Long countryRegionId;
	private String stateName;
	private Long stateId;
	private String cityName;
	private Long cityId;
	private Long companyId;
	private String companyName;
	private String businessUnitName;
	private Long buId;
	private String facilityName;
	private String addressLine1;
	private String addressLine2;
	private String postalCode;
	private String currencyCode;
	private UserDto user;

}
