package com.igo.i_finance.model;

import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
public class City {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "common_seq")
	@SequenceGenerator(name = "common_seq", sequenceName = "common_id_seq", allocationSize = 1)
	@Column(name = "city_id")
	private Long cityId;
	
	@NotBlank(message = "City name required")
	@Column(name = "city_name",nullable = false)
	private String cityName;
	
	@ManyToOne
	@JoinColumn(name = "state_id")
	private States state;
	
	@ManyToOne
	@JoinColumn(name = "country_region_id")
	private CountriesRegions countryRegion;
	
	@ManyToOne
	@JoinColumn(name = "country_id")
	private Countries country;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

}
