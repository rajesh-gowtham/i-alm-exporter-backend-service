package com.igo.i_finance.model;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Entity
@Data
public class Continents {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "common_seq")
	@SequenceGenerator(name = "common_seq",sequenceName = "common_id_seq",allocationSize = 1)
	@Column(name = "continent_id")
	private Long continentId;
	
	@Column(name = "continent_name")
	private String continentName;
	
	@Column(name = "continent_code")
	private String continentCode;
	
	@OneToMany(mappedBy = "continents",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<ContinentRegions>continentRegions;
	
	@OneToMany(mappedBy = "continents",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Countries> country;
	
	@Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

	@PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
