//package com.igo.i_finance;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class IFinanceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
