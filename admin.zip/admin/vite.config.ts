import path from "path";
import react from "@vitejs/plugin-react-swc";
import { visualizer } from 'rollup-plugin-visualizer';
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  define: {
    "process.env": {},
  },
  build: {
    // assetsInlineLimit: Number.MAX_SAFE_INTEGER,
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('@deck.gl') || id.includes('@luma.gl')) {
              return 'deck-luma';
            }
            if (id.includes('react')) {
              return 'react';
            }
            if (id.includes('three')) {
              return 'three';
            }
            return 'vendor';
          }
        }
      }
    }
  },
  optimizeDeps: {
    esbuildOptions: {
      loader: {
        ".js": "jsx",
      },
    },
    exclude: [],
    include: ["@deck.gl/core", "@luma.gl/webgl", "@luma.gl/core"],
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    allowedHosts: ["localhost", "yaro.mobiliuz.in", ".ngrok.io"],
    port: 5000,
  },
  // css: {
  //   modules: {
  //     localsConvention: "camelCaseOnly",
  //   },
  // },
  assetsInclude: [
    "**/*.png",
    "**/*.jpg",
    "**/*.jpeg",
    "**/*.gif",
    "**/*.svg",
    "**/*.ico",
    "**/*.webp",
    "**/*.xlsx",
  ],
  esbuild: {
    loader: "tsx",
    include: [
      // Business as usual for .jsx and .tsx files
      "src/**/*.jsx",
      "src/**/*.tsx",
      "node_modules/**/*.jsx",
      "node_modules/**/*.tsx",

      // Add these lines to allow all .js files to contain JSX
      "src/**/*.js",
      "node_modules/**/*.js",

      // Add these lines to allow all .ts files to contain JSX
      "src/**/*.ts",
      "node_modules/**/*.ts",
    ],
    exclude: [],
  },
  plugins: [
    react(),
    visualizer({
      filename: 'bundle-report.html',
      open: true,
    }),
  ],

});
