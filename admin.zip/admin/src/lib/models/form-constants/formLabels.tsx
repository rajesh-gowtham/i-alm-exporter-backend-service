export const VesselFields = {
    _Name: "Name",
    _VesselClass: "Vessel Class",
    _LineOperator: "Line Operator",
    _LOAInCm: "LOA (cm)",
    _RadioCallSign: "Radio CallSign",
    _LloydsIdentity: "Lloyds Identity",
    _Notes: "Notes"
} as const;

export const VesselVistLabels = {
    _VisitRef: "Visit Ref",
    _VesselName: "Vessel Name",
    _Phase: "Phase",
    _Inbound_Voyage: "Inbound Voyage",
    _Outbound_Voyage: "Outbound Voyage",
    _LineOperator: "Line Operator",
    _ETA: "ETA",
    _ETD: "ETD",
    _ATA: "ATA",
    _ATD: "ATD",
    _StartWorkTime: "Start Work Time",
    _EndWorkTime: "End Work Time",
    _Classification: "Classification",
    _Service: "Service",
} as const;
export const BerthingLabels = {
    _Quay: "Quay",
    _Side_To: "Side To",
    _BerthETA: "Berth ETA",
    _BerthETD: "Berth ETD",
    _BerthATA: "Berth ATA",
    _StartWorkTime: "Start Work Time",
    _StartBollard: "Start Bollard",
    _EndBollard: "End Bollard",
    _VisitRef: "Visit Ref"
} as const;
export const EquipmentLabels = {
    _EquipmentName: "Name",
    _EquipmentType: "Type",
    _MaxWeightInTon: "Max Weight (Ton)",
    _MaxTEU: "Max TEU",
    _Model: "Model",
    _Make: "Make",
    _RFIDTag1: "RFID Tag 1",
    _RFIDTag2: "RFID Tag 2",

} as const;
export const RTLSAssetLabels = {
    _Reader_IP: "Reader_IP",
    _ReadPoint_Name: "Read Point_Name",
    _Antenna_ID: "Antenna_ID",
    _ITV_ID: "ITV_ID",
    _Reader_Type: "Reader_Type",
    _Reader_Model: "Reader_Model",
    _location_ID: "location_ID",
    _Latitude: "Latitude",
    _Longitude: "Longitude",
    _UserId: "User Id",
} as const;

export const EquipmentPoolLabels = {
    _PoolName: "Pool Name",
} as const;

export const WorkInstructionLabels = {
    _ContainerID: "Container ID",
    _ISO: "ISO",
    _MoveType: "Move Type",
    _Mode: "Mode",
    _InboundLocationType: "IB Location Type",
    _VisitRef: "IB Carrier",
    _OutboundLocationType: "OB Location Type",
    _OutboundCarrier: "OB Carrier",
    _From: "From",
    _To: "To",
    _POW: "POW",
    _CHEPut: "CHE Put",
    _CHECarry: "CHE Carry",
    _PosOnChassis: "Pos on Chassis",
    _Status: "Status",
    _JobSteppingStatus: "Job Stepping Status",
    _Deck: "Deck",
    _Weight: "Weight (kg)",
    _AssignedLane: "Assigned Lane",
    _Sequence: "Sequence"
} as const;

export const ContainerInventoryLabels = {
    _ContainerId: "Container ID",
    _ISO_Code: "ISO",
    _Block: "Block",
    _Location: "Current Position"
} as const;

export const VesselInventoryLabels = {
    _VisitRef: "Visit Ref",
    _VesselName: "Vessel Name",
    _VesselClass: "Vessel Class",
    _LineOperator: "Line Operator",
    _Hatch: "hatch",
} as const;

export const DeviceAssetLabels = {

    /* 
  deviceId: string;
  manufacturer: string;
  model: string;
  firmwareVersion: string;
  deviceType:
    | "ECU Reader"
    | "CAN bus logger"
    | "Speed Sensor"
    | "Battery monitor"
    | string; // allows for future custom types
  communicationProtocol: "CAN Bus" | "RS-232" | "BLE" | "LoRa" | "LTE" | string;
  powerSource: "Vehicle battery" | "External wired" | "Self-powered" | string;
  warrantyStartDate: string;
  warrantyExpiryDate: string;
  */
    _DeviceId: "Device ID",
    _Manufacturer: "Manufacturer",
    _Model: "Model",
    _FirmwareVersion: "Firmware Version",
    _Device_Type: "Device Type",
    _Communication_Protocol: "Communication Protocol",
    _Power_Source: "Power Source",
    _warrantyStartDate: "Warranty Start Date",
    _warrantyExpiryDate: "Warranty Expiry Date",
    // _UserId: "User Id",
} as const;


export const rfidTabs = [
    { id: "leveltemplate", label: "Level Template" },
    { id: "onboarding", label: "OnBoarding" },
];


export const RfidRegisterFormLabels = {
    _ReaderIP: "Reader IP",
    _ReadPointNames: "Read Point Name",
    _AntennaID: "Antenna ID",
    _LevelTemplateValue: "Level Template Value",
    _Zone: "Zone",
    _SubZone:"Sub Zone",
    _ReaderType: "Reader Type",
    _ReaderModal: "Reader Model",
    _Location: "Location",
    _Lat: "Latitude",
    _Lang: "Longitude",
    _readerTypeValue:"Reader Type Value",
    _readerModelValue:"Reader Model Value",
    _readerTypeGPValue:"reader Type GPValue",
    _ltValue:"Level Template",
} as const;
