import { PaginationState } from "@tanstack/react-table";

// Common Interfaces
export interface BaseEntity {
  id?: number;
  createdBy?: string | null;
  updatedBy?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
}

export interface PaginatedResponse<T> {
  totalCount: number;
  items: T[];
}

// Vessel Interface
export interface Vessel extends BaseEntity {
  vesselName: string;
  overallLength: number;
  lloydsIdentity: string;
  vesselClass: string;
  radioCallSign: string;
  operator: string;
  status?: boolean | undefined;
  notes?: string | undefined | null;

}

// Vessel Visit Interface
export interface VesselVisit extends BaseEntity {
  vesselVisitId(vesselVisitId: any, id: any): unknown;
  vesselRef: any;
  visitRef: string;
  // vesselClass: string;
  vesselId: number;
  phase: string;
  inboundVoyage: string;
  outboundVoyage: string;
  lineOperator: string;
  eta: Date | string;
  etd: Date | string;
  ata: Date | string;
  atd: Date | string;
  startWorkTime: Date | string;
  endWorkTime: Date | string;
  classification: string;
  service: string;
  // vessel?: Vessel;
}

// Vessel Berthing Interface
export interface VesselBerthing extends BaseEntity {
  quay: string;
  berthingSide: string;
  berthEta: Date | string;
  berthEtd: Date | string;
  berthAta: Date | string;
  startWorkTime: Date | string;
  startBollard: string;
  endBollard: string;
  vesselVisitId: number;
  vesselVisit?: VesselVisit;
}

// Equipment Interface
export interface Equipment extends BaseEntity {
  equipmentName: string;
  equipmentType: string;
  maxWeight: number | undefined;
  maxTeu: number | undefined;
  status?: boolean;
  model?: string;
  make?: string;
  rfidTag1?: string;
  rfidTag2?: string;
}
export interface RTLSAsset extends BaseEntity {
  readerIp: string;
  readPointName: string;
  antennaId: string;
  itvId: string;
  readerType: string;
  readerModel: string;
  locationId: string;
  latitude: string;
  longitude: string;
  userId: string;
};

// Equipment Pool Interface
export interface EquipmentPool extends BaseEntity {
  poolName: string;
  // dispatchState: string;
  // operatingMode: string;
  // jobStartPosition: string;
  // equipmentId: number;
  equipment?: Equipment;
}

// Point of Work Interface
export interface PointofWork extends BaseEntity {
  name: string;
  pool: string;
}
export interface PowOptionList {
  powId: string | number;
  powName: string;
}
export interface PoolOptionList {
  poolId: string | number;
  pool: string;
}
// Work Instruction Interface
export interface WorkInstruction extends BaseEntity {
  weight: number;
  containerId: string;
  isoCode: string;
  moveType: string;
  mode: string;
  inboundLocationType: string;
  vesselVisitId: number;
  outboundLocationType: string;
  outboundCarrier: string;
  fromLocation: string;
  targetLocation: string;
  pointOfWorkId: number;
  assignedChe: string;
  cheCarry: string;
  positionOnCarriage: string;
  workInstructionStatus: string;
  jobSteppingStatus: string;
  deck: string;
  sequence: number;
  // equipmentId: number;
  // dispatchState: string;
  // assignedLane: string;
  // currentPosition: string;
}

export interface WorkAssWorkInstruction extends BaseEntity {
  vesselVisitId: number;
  vesselVisit: VesselVisit;
  moveType: string;
  equipmentId: number;
  fromLocation: string;
  targetLocation: string;
  // dispatchState: string;
  isoCode: string;
  assignedChe: string;
  assignedLane: string;
  cheCarry: string;
  currentPosition: string;
  positionOnCarriage: string;
  pointOfWorkId: number;
  containerId: string;
  workInstructionStatus: string;
  jobSteppingStatus: string;
}
export interface WorkAssignment extends BaseEntity {
  vesselVisitId: string,
  vesselRef: string;
  vesselName: string,
  quay: string,
  vesselVisitPhase: string,
  eta: string,
  etd: string,
  ata: string,
  atd: string,
  totalPlannedMoves: number,
  completedMoves: number,
  pointOfWork: WorkAssignmentPOW[]
}
export interface WorkAssignmentPOW extends BaseEntity {
  // id: string;
  name: string;
  pool: string;
  status: string;
  totalPlannedMoves: number;
  completedMoves: number;
}

export interface workQueueResponse {
  moveType: string;
  id: number;
  type: string;
  name: string;
  totalPlannedMoves: number;
  pendingMoves: number;
  completedMoves: number;
  status: string;
  deck: string
}

// POW Assignment Interface
export interface PowAssignment extends BaseEntity {
  powId: number;
  equipmentPoolId: number;
  equipmentPoolStatus: boolean;
  pointofwork: PointofWork;
  equipmentPool: EquipmentPool;
}

// Equipment Pool Assignment Interface
export interface EquipmentPoolAssignment extends BaseEntity {
  equipmentPoolId: number;
  equipmentId: number;
  assignmentStatus: boolean;
  equipmentAssignedDate: string;
  equipmentPool: EquipmentPool;
  equipment: Equipment;
}

export type AuthResponse = {
  tokenType: string;
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
};


export interface ContainerYardInventory {
  id?: string;
  created?: Date;
  updated?: Date;
  containerId: string;
  equipmentType: string;
  category: string;
  transitState: number;
  position: number;
  lineOperator: string;
  inboundActualVisit: string;
  outboundActualVisit: string;
  portOfDischarge: string;
  freightKind: string;
  lastMove: Date;
}


export interface PoolDetails {
  powName: string;
  poolName: string;
}

export interface EquipmentPoolAssignmentsResponse {
  assignedPools: Equipment[];
  unAssignedPools: Equipment[];
}

export interface EquipmentPoolAssignmentsRequest {
  equipmentId: number;
  equipmentPoolId: number;
}

export type ContainerHistory = {
  id: number;
  containerId: string;
  isoCode: string;
  block: string;
  location: string;
}
export type VesselInventory = {
  visitRef: string;
  vesselName: string;
  vesselClass: string;
  lineOperator: string;
  hatch: HatchDetail[]
}

export type ContainerDetail = {
  moveType: string;
  vesselRef: string;
  cheCarry: string;
  pow: string;
  mode: string;
  assignedChe: string;
  assignedLane: string;
  block: string;
  position: string;
  positionOnCarriage: number;
  jobCreatedTime: string;
  jobStartTime: string;
  dispatchTime: string;
  timeAtOrigin: string;
  dischargeTime: string;
  timeFacilityIn: string;
  timeAtDestination: string;
  jobCompleteTime: string;
  fromPosition: string;
}
export type HatchDetail = {

  eventName: string;
  equipmentName: string;
  startTime: string;
  endTime: string;
  visitRef: string;
  notes: string;
  workQueue: string;

}

export type VesselInfo = {
  vesselName: string;
  vesselId: number;
  qcs: {
    asset: string;
    type: string;
    activeJobs: number;
    completedJobs: number;
  }[];
};

export type JobInfo = {
  movesCompleted: number;
  movesPending: number;
};
export type ChartItem = {
  title: string;
  value: number;
};
export type QcDetailItem = {
  asset: string;
  berth: string;
  gpsTime: string;
  movesPending: number;
  movesCompleted: number;
  ignition: string;
};

export type QcDetails = {
  totalCount: number;
  items: QcDetailItem[];
};


export type CardType = {
  title: string;
  value: string;
};
export type WaterSide = {
  vesselOnBerth: number;
  activeQc: number;
  totalJobs: number;
  assignedItvs: number;
  alerts: number;
  vesselInfo: VesselInfo[];
  jobInfos: JobInfo[];
  qcDetails: QcDetails;
  lastUpdatedUtc: string;
};
export type DashboardPayload = {
  cardName: string;
  skip: number;
  take: number;
};

export type WaterSideGridResponse = {
  cardName: string;
  skip: number;
  take: number;
  data: {
    totalCount: number;
    items: [];
  }
}
export type LayoutProps = {
  jobInfos: ChartItem[];
  gridData: QcDetailItem[];
  getDashboardType: 'waterside' | 'landside';
  barData: VesselInfo[];
  isloading: boolean;
  totalCount: number;
  changegridData: (title: string, index: number) => void;
  title: string;
  activeQCs: string[];
  setPaged: React.Dispatch<React.SetStateAction<PaginationState>>;
}
export type WatersideGridRow = {
  asset: string;
  ignition?: string;
  [key: string]: any;
}
export type StyledGaugeFullProps = {
  jobInfos: ChartItem[];
};

export type CustomLabelProps = {
  cx: number;
  cy: number;
  midAngle: number;
  innerRadius: number;
  outerRadius: number;
  value: number | string;
};
export type ChartComponentProps = {
  data: VesselInfo[];
};
export interface ItvDashboardData {
  asserts: number;
  active: number;
  idling: number;
  stoppage: number;
  alerts: number;
  avgCycleTime: number;

  itvDistribution: ItvDistribution;
  itvActivity: ItvActivity[];
  ecuStatus: EcuStatus;
  assertDetails: AssertDetails;
}
export interface LayoutLandsideProps {
  getDashboardType: 'landside' | 'waterside';
  title: string;
  itvDistribution: ItvDistribution;
  itvActivity: ItvActivity[];
  ecuStatus: EcuStatus;
  gridData: AssertItem[];
  isloading: boolean;
  totalCount: number;
  barData: string[];
}
export interface ItvDistribution {
  idle: number;
  movingToQuay: number;
  atQuay: number;
  movingToYard: number;
  atYard: number;
}

export interface ItvActivity {
  itv: string;
  idling: number;
  active: number;
  stoppage: number;
}

export interface EcuStatus {
  engineHours: number;
  idleHours: number;
  stoppageHours: number;
  fuelConsumpion: number;
}

export interface AssertDetails {
  totalCount: number;
  items: AssertItem[];
}

export interface AssertItem {
  asset: string;
  type: string;
  operationStatus: string;
  gpsTime: string;
  ignition: 'ON' | 'OFF';
  make: string | null;
  model: string | null;
  rfidTag1: string | null;
  rfidTag2: string | null;
  latitude: number;
  longitude: number;
  status: string;
}

export interface ItvDistribution {
  idle: number;
  movingToQuay: number;
  atQuay: number;
  movingToYard: number;
  atYard: number;
}


export interface ItvActivityItem {
  itv: string;
  idling: number;
  active: number;
  stoppage: number;
}

export interface EcuStatus {
  engineHours: number;
  idleHours: number;
  stoppageHours: number;
  fuelConsumpion: number;
}


export interface LandBarchartSimpleProps {
  chartData: ItvDistribution;
  themeCode: 'dark' | 'light' | string;
}

export interface LandStackedChartProps {
  chartData: ItvActivityItem[];
  themeCode: 'dark' | 'light' | string;
}

export interface EcuStatsChartProps {
  ecuStatus: EcuStatus;
}

// Paginated Interfaces
export type PaginatedVesselResponse = PaginatedResponse<Vessel>;
export type PaginatedVesselVisitResponse = PaginatedResponse<VesselVisit>;
export type PaginatedVesselBerthingResponse = PaginatedResponse<VesselBerthing>;
export type PaginatedEquipmentResponse = PaginatedResponse<Equipment>;
export type PaginatedEquipmentPoolResponse = PaginatedResponse<EquipmentPool>;
export type PaginatedPointOfWorkResponse = PaginatedResponse<PointofWork>;
export type PaginatedWorkInstructionResponse = PaginatedResponse<WorkInstruction>;
export type PaginatedPowAssignmentResponse = PaginatedResponse<PowAssignment>;
export type PaginatedWorkAssignmentResponse = PaginatedResponse<WorkAssignment>;
export type PaginatedContainerInventoryResponse = PaginatedResponse<ContainerHistory>;
export type PaginatedVesselInventoryResponse = PaginatedResponse<VesselInventory>;
export type PaginatedRTLSAssetResponse = PaginatedResponse<RTLSAsset>;
export type PaginatedEquipmentPoolAssignmentResponse = PaginatedResponse<EquipmentPoolAssignment>;
export type PaginatedqcDetailsResponse = WaterSideGridResponse;
export type PaginatedDeviceAssetResponse = PaginatedResponse<DeviceAsset>;

export enum RouteSegmentType {
  ParkingToSTS01 = "ParkingToSTS01",
  ParkingToSTS02 = "ParkingToSTS02",
  STS01ToYard = "STS01ToYard",
  STS02ToYard = "STS02ToYard",
  YardToParkingLane1 = "YardToParkingLane1",
  YardToParkingLane2 = "YardToParkingLane2",
  YardToSTS01 = "YardToSTS01",
  YardToSTS02 = "YardToSTS02",
}

/*
 public const string YET_TO_START = "Yet to Start";
        public const string DISPATCHED = "Dispatched";
        public const string CANCELLED = "Cancelled";
        public const string ARRIVE_TO_ORIGIN = "Arrive to Origin";
        public const string ARRIVED_AT_ORIGIN = "Arrived at Origin";
        public const string ARRIVE_TO_DESTINATION = "Arrive to Destination";
        public const string ARRIVED_AT_BLOCK = "Arrived at Block";
        public const string ARRIVED_AT_DESTINATION = "Arrived at Destination";
        public const string COMPLETED = "Completed";
        public const string SUSPENDED = "Suspended";
        public const string WAITING_PICKUP = "Waiting Pickup";
        public const string WAITING_DROP = "Waiting Drop";

*/

export enum EquipmentJobStatus {
  YET_TO_START = "YET_TO_START",
  DISPATCHED = "DISPATCHED",
  CANCELLED = "CANCELLED",
  ARRIVE_TO_ORIGIN = "ARRIVE_TO_ORIGIN",
  ARRIVED_AT_ORIGIN = "ARRIVED_AT_ORIGIN",
  ARRIVE_TO_DESTINATION = "ARRIVE_TO_DESTINATION",
  ARRIVED_AT_BLOCK = "ARRIVED_AT_BLOCK",
  ARRIVED_AT_DESTINATION = "ARRIVED_AT_DESTINATION",
  COMPLETED = "COMPLETED",
  SUSPENDED = "SUSPENDED",
  WAITING_PICKUP = "WAITING_PICKUP",
  WAITING_DROP = "WAITING_DROP",

}



export interface EquipmentState {
  equipmentId: number;
  equipmentName: string;
  equipmentType: string;
  status: string;
  message: string;
  gpsTime: Date;
  latitude: number;
  longitude: number;
  altitude: number;
  heading: number;
  parameters: Record<string, any>;
  jobDetails: JobDetail[];
  routeSegment: RouteSegmentType | null;
  jobStatus: string | null;
}
export type JobDetail = {
  containerId: string;
  iso: string;
  weight: number;
  type: string;
  posOnChassis: string;
};


export enum DeviceType {
  ECUReader = "ECUReader",
  CANBusLogger = "CANBusLogger",
  SpeedSensor = "SpeedSensor",
  BatteryMonitor = "BatteryMonitor"
}

export enum CommunicationProtocol {
  CANBus = "CANBus",
  RS232 = "RS232",
  BLE = "BLE",
  LoRa = "LoRa",
  LTE = "LTE"
}

export enum PowerSource {
  VehicleBattery = "VehicleBattery",
  ExternalWired = "ExternalWired",
  SelfPowered = "SelfPowered"
}
export interface DeviceAsset extends BaseEntity {
  deviceId: string;
  manufacturer: string;
  model: string;
  firmwareVersion: string;
  deviceType: DeviceType | string;
  communicationProtocol: CommunicationProtocol | string;
  powerSource: PowerSource | string;
  warrantyStartDate: string;
  warrantyExpiryDate: string;
  // userId: string;
};

export const DeviceTypeDisplay: Record<DeviceType, string> = {
  [DeviceType.ECUReader]: "ECU Reader",
  [DeviceType.CANBusLogger]: "CAN bus logger",
  [DeviceType.SpeedSensor]: "Speed Sensor",
  [DeviceType.BatteryMonitor]: "Battery monitor"
};

export const CommunicationProtocolDisplay: Record<CommunicationProtocol, string> = {
  [CommunicationProtocol.CANBus]: "CAN Bus",
  [CommunicationProtocol.RS232]: "RS-232",
  [CommunicationProtocol.BLE]: "BLE",
  [CommunicationProtocol.LoRa]: "LoRa",
  [CommunicationProtocol.LTE]: "LTE"
};

export const PowerSourceDisplay: Record<PowerSource, string> = {
  [PowerSource.VehicleBattery]: "Vehicle battery",
  [PowerSource.ExternalWired]: "External wired",
  [PowerSource.SelfPowered]: "Self-powered"
};

export type ReaderDetail = {
  uniqueId: string;
  name: string;
  // type: string;
  // fixedMob: string;
  readerName: string;
};
 
export interface ReaderType {
  gpid: number;
  gpName: string;
  gpValue: string;
}
 
export interface ReaderModel {
  gpid: number;
  gpName: string;
  gpValue: string;
}
export interface ConfigData {
  readerType: ReaderType[];
  readerModel: ReaderModel[];
  levelTemplate: LevelTemplate[];
  levelTemplateZone?: LevelTemplate[];
}
export interface LevelTemplate {
  ltVID: number;
  ltid: number;
  ltValue: string;
  ltVParentID: number;
  ltVDescription: string;
  childCount: number | null;
  userId: number | null;
}
export interface LevelTemplateBase {
   ltid: number;
  childCount: string;
  userId: string | null;
  ltVID?:number;
  ltValue?:string;
  ltVParentID?:number;
  ltVDescription?:string;
  ltName?:string;
  ltParentID?:number;
}
 
export interface ApiNode {
  ltVID?: number;
  ltid: number;
  ltName?: string;
  ltValue?: string;
  ltParentID?: number;
  ltVParentID?: number;
  ltVDescription?: string;
  childCount?: string | null;
  userId: string | null;
}
 
export interface TreeNode {
  id: string;
  name: string;
  children?: TreeNode[];
  type: string;
  raw: ApiNode;
  isNew?: boolean;
  isLoading?: boolean;
  isExpanded?: boolean;
  hasFetched?: boolean;
  description?: string;
  level?: number;
}