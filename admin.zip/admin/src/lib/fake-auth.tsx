/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect } from "react";

const fakeAuthProvider = {
  isAuthenticated: localStorage.getItem("isAuthenticated") === "true",
  signin(callback: VoidFunction) {
    fakeAuthProvider.isAuthenticated = true;
    localStorage.setItem("isAuthenticated", "true");
    setTimeout(callback, 100); // fake async
  },
  signout(callback: VoidFunction) {
    localStorage.removeItem("isAuthenticated");
    fakeAuthProvider.isAuthenticated = false;
    setTimeout(callback, 100);
  },
};

interface AuthContextType {
  user: any;
  signin: (user: string, callback: VoidFunction) => void;
  signout: (callback: VoidFunction) => void;
}

const AuthContext = React.createContext<AuthContextType>(null!);

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<any>(localStorage.getItem("user"));

  useEffect(() => {
    if (user) {
      localStorage.setItem("user", user);
    }
    else {
      localStorage.removeItem("user");
    }
  }, [user]);

  const signin = (newUser: string, callback: VoidFunction) => {
    return fakeAuthProvider.signin(() => {
      setUser(newUser);
      callback();
    });
  };

  const signout = (callback: VoidFunction) => {
    return fakeAuthProvider.signout(() => {
      setUser(null);
      callback();
    });
  };

  const value = { user, signin, signout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

function useAuth() {
  return React.useContext(AuthContext);
}

export { AuthProvider, useAuth, AuthContext, fakeAuthProvider };