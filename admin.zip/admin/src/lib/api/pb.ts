import { Env } from "../constants";
import PocketBase from 'pocketbase';

const pocketbase = new PocketBase(Env.PocketBaseUrl);
pocketbase.authStore.save(Env.PocketBaseToken, null);

// https://pocketbase.igortls.com/_/
// admin@inmobiliuz.com
// Safety@2025

export default pocketbase;