import { create } from "zustand";
import type { EmissionsFilters } from "@/app/emissions/filters";
import { SummaryCardData } from "@/app/emissions/cards";
import { ChartData } from "@/lib/types/emissions-charts";
import { EmissionsTableRow } from "@/app/emissions/columns";


// specify start and end dates for the date range
// start date should be set to 2025-03-01
// end date should be set to 2025-03-31
const startDate = new Date("2025-03-01");
const endDate = new Date("2025-03-31");

const FILTERS_STORAGE_KEY = "emissions-filters";

function loadFiltersFromSession(): EmissionsFilters {
    try {
        const raw = sessionStorage.getItem(FILTERS_STORAGE_KEY);
        if (!raw) return initialFilters;
        const parsed = JSON.parse(raw);
        return { ...initialFilters, ...parsed };
    } catch {
        return initialFilters;
    }
}

const initialFilters: EmissionsFilters = {
    asset: "",
    state: "Both",
    utilizationRange: [0, 12],
    fuelRange: [0, 50],
    dateRange: { from: startDate, to: endDate },
    assetOptions: [],
};

export type EmissionsState = {
    filters: EmissionsFilters;
    summaryCards: SummaryCardData[];
    chartData: ChartData;
    tableRows: EmissionsTableRow[];
    loading: boolean;
    error: string | null;
};

export type EmissionsActions = {
    setFilters: (filters: EmissionsFilters) => void;
    resetFilters: () => void;
    setSummaryCards: (cards: SummaryCardData[]) => void;
    setChartData: (data: ChartData) => void;
    setTableRows: (rows: EmissionsTableRow[]) => void;
    setLoading: (loading: boolean) => void;
    setError: (error: string | null) => void;
    resetAll: () => void;
    initialize: (state: Partial<EmissionsState>) => void;
    serialize: () => Omit<EmissionsState, "filters"> & { filters: Omit<EmissionsFilters, "assetOptions"> };
};

const initialState: EmissionsState = {
    filters: loadFiltersFromSession(),
    summaryCards: [],
    chartData: {},
    tableRows: [],
    loading: false,
    error: null,
};

const useEmissionsStore = create<EmissionsState & EmissionsActions>()((set, get) => ({
    ...initialState,
    setFilters: (filters) => {
        sessionStorage.setItem(FILTERS_STORAGE_KEY, JSON.stringify(filters));
        set({ filters });
    },
    resetFilters: () => {
        sessionStorage.removeItem(FILTERS_STORAGE_KEY);
        set({ filters: initialFilters });
    },
    setSummaryCards: (cards) => set({ summaryCards: cards }),
    setChartData: (data) => set({ chartData: data }),
    setTableRows: (rows) => set({ tableRows: rows }),
    setLoading: (loading) => set({ loading }),
    setError: (error) => set({ error }),
    resetAll: () => set({ ...initialState }),
    initialize: (state) => set({ ...initialState, ...state }),
    serialize: () => {
        const { filters, summaryCards, chartData, tableRows, loading, error } = get();
        // assetOptions is not serializable (UI only)
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { assetOptions, ...serializableFilters } = filters;
        return {
            filters: serializableFilters,
            summaryCards,
            chartData,
            tableRows,
            loading,
            error,
        };
    },
}));

export default useEmissionsStore;