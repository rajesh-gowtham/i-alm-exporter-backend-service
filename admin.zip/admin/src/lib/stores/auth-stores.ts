import { create } from "zustand";

type AuthState = {
    isAuthorized: boolean;
    token: string | null;
};

type Actions = {
    getIsAuthorized: () => boolean;
    getToken: () => string | null;
    logIn: (token: string) => void;
    logout: () => void;
};

const initialState: AuthState = {
    isAuthorized: false,
    token: null,
};

const useAuthStore = create<AuthState & Actions>()((set, get) => ({
    // state
    ...initialState,
    // actions
    getIsAuthorized() {
        return get().isAuthorized
            ? true
            : localStorage.getItem("isAuthorized") === "true";
    },
    getToken() {
        return get().token || localStorage.getItem("token");
    },
    logIn(token) {
        localStorage.setItem("isAuthorized", "true");
        localStorage.setItem("token", token);
        set({ isAuthorized: true, token });
    },
    logout() {
        localStorage.removeItem("isAuthorized");
        localStorage.removeItem("token");
        set({ isAuthorized: false, token: null });
    },
}));

export default useAuthStore;
