import axiosInstance from '../http-client';
import { PaginatedRTLSAssetResponse, RfidDevice, } from '../models';

export async function fetchRTLSDevice(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedRTLSAssetResponse> {

    const rfidDevice = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
            skip,
            take,
            filter,
            sort,
            search,
            searchFields,
            expand,
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;

}

export async function fetchRTLSDeviceMasterData(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedRTLSAssetResponse> {

    const rfidDevice = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid/masterData", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
            skip,
            take,
            filter,
            sort,
            search,
            searchFields,
            expand,
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;

}

export async function addRTLSDevice(RfidDeviceData: Omit<RfidDevice, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<RfidDevice | null> {
    const rfidDevice = await axiosInstance.post<RfidDevice>("asset/rfid", RfidDeviceData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;
}

export async function editRTLSDevice(id: number, payload: Partial<Omit<RfidDevice, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<RfidDevice | null> {
    const RfidDeviceData = { ...payload, rPID: id }
    const RfidData = await axiosInstance.put<RfidDevice>(`/asset/rfid/`, RfidDeviceData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (RfidData.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return RfidData.data;
}

export async function deleteRTLSDevice(id: number): Promise<boolean> {
    const RTLSDevice = await axiosInstance.delete(`/asset/rfid/${id}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (RTLSDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return RTLSDevice.data;
}





