import axiosInstance from '../http-client';
import { PaginatedDeviceAssetResponse, DeviceAsset } from '../models';

export async function isDeviceIdUnique(deviceId: string, currentId?: string): Promise<boolean> {

    const devices = await axiosInstance.get<DeviceAsset>(`/asset/telematics/${deviceId}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    
    if (devices.status !== 200) {
       // return true; // if not found, it's unique
       throw new Error("Failed to fetch data");
    }
    // console.log("devices.data", devices.data.id);
    // console.log("currentId", currentId);

    if (devices.data === null) return true;
    console.log("isDeviceIdUnique", devices);
    if (devices.data.id !== undefined && currentId !== undefined && devices.data.id.toString() === currentId.toString()) return true; // true if no duplicate
    return false;

}

export async function fetchDeviceAssets(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedDeviceAssetResponse> {

    const devices = await axiosInstance.get<PaginatedDeviceAssetResponse>("/asset/telematics", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
            skip,
            take,
            filter,
            sort,
            search,
            searchFields,
            expand,
        },
    });
    if (devices.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;

}
export async function fetchDeviceAssetsById(id: string): Promise<DeviceAsset | null> {

    const devices = await axiosInstance.get<DeviceAsset>(`/asset/telematics/${id}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (devices.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;
}

export async function addDeviceAsset(EquipmentData: Omit<DeviceAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<DeviceAsset | null> {

    const devices = await axiosInstance.post<DeviceAsset>("/asset/telematics", EquipmentData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (devices.status !== 201) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;
}

export async function addDeviceAssetsInBatch(DeviceAssetData: Omit<DeviceAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<DeviceAsset | null> {
    const devices = await axiosInstance.post<DeviceAsset>("asset/telematics/batch", DeviceAssetData, {
        headers: { "Content-Type": "application/json" },
    });
    if (devices.status !== 201) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;
}



export async function editDeviceAsset(id: string, deviceData: Partial<Omit<DeviceAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<DeviceAsset | null> {

    const devices = await axiosInstance.put<DeviceAsset>(`/asset/telematics/${id}`, deviceData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (devices.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;
}

export async function deleteDeviceAsset(id: string): Promise<boolean> {

    const devices = await axiosInstance.delete(`/asset/telematics/${id}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (devices.status !== 204) {
        throw new Error("Failed to fetch data");
    }
    return devices.data;
}

