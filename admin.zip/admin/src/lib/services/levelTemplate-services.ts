import axiosInstance from '../http-client';
import { LevelTemplateBase, PaginatedRTLSAssetResponse, RfidDevice, } from '../models';

export async function fetchTemplateDetails(): Promise<PaginatedRTLSAssetResponse> {

    const rfidDevice = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid/levelTemplate", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
         
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;

}
export async function fetchTemplateChildren(): Promise<PaginatedRTLSAssetResponse> {

    const rfidDevice = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid/levelTemplate/values", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
         
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;

}

export async function fetchRTLSDeviceMasterData(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedRTLSAssetResponse> {

    const rfidDevice = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid/masterData", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
            skip,
            take,
            filter,
            sort,
            search,
            searchFields,
            expand,
        },
    });
    if (rfidDevice.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return rfidDevice.data;

}

export async function addTemplateValue(TemplateData: Omit<LevelTemplateBase, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<LevelTemplateBase | null> {
    const templateData = await axiosInstance.post<LevelTemplateBase>("/asset/rfid/levelTemplate/values", TemplateData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (templateData.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return templateData.data;
}
export async function EditTemplateValue(TemplateData: Omit<LevelTemplateBase, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<LevelTemplateBase | null> {
    const templateData = await axiosInstance.put<LevelTemplateBase>("/asset/rfid/levelTemplate/values", TemplateData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (templateData.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return templateData.data;
}

export async function addTemplate(TemplateData: Omit<LevelTemplateBase, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<LevelTemplateBase | null> {
    const templateData = await axiosInstance.post<LevelTemplateBase>("/asset/rfid/levelTemplate", TemplateData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (templateData.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return templateData.data;
}

export async function editTemplate(TemplateData: Omit<LevelTemplateBase, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<LevelTemplateBase | null> {
    const templateData = await axiosInstance.put<LevelTemplateBase>("/asset/rfid/levelTemplate", TemplateData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (templateData.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return templateData.data;
}




