// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { PaginatedVesselBerthingResponse, PaginatedVesselResponse, PaginatedVesselVisitResponse, Vessel, VesselBerthing, VesselVisit } from '../models';

export async function fetchVessels(
  skip?: number, take?: number, search?: string, searchFields?: string, filter?: string, sort?: string, expand?: string
): Promise<PaginatedVesselResponse> {

  const vessels = await axiosInstance.get<PaginatedVesselResponse>("/vessels", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },

  });

  if (vessels.status !== 200) {
    throw new Error("Failed to fetch data");
  }

  return vessels.data;
  /*
  try {
    const vessels = await pocketbase.collection('vessels').getFullList<Vessel>(200, {
      sort: '-created',
    });
    return vessels;
  } catch (error) {
    console.error('Error fetching vessels:', error);
    return [];
  } */
}
export async function fetchVesselById(id: string): Promise<Vessel | null> {

  const vessel = await axiosInstance.get<Vessel>(`/vessels/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vessel.status !== 200) {
    throw new Error("Failed to fetch data");
  }

  return vessel.data;
  /* try {
    const vessel = await pocketbase.collection('vessels').getOne<Vessel>(id);
    return vessel;
  } catch (error) {
    console.error(`Error fetching vessel with ID ${id}:`, error);
    return null;
  } */
}

export async function addVessel(vesselData: Omit<Vessel, 'id' | 'created' | 'updated'>): Promise<Vessel | null> {

  const vessel = await axiosInstance.post<Vessel>("/vessels", vesselData, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vessel.status !== 201) {
    throw new Error("Failed to add data");
  }

  return vessel.data;

  /*  try {
    const newVessel = await pocketbase.collection('vessels').create<Vessel>(vesselData);
    return newVessel;
  } catch (error) {
    console.error('Error adding vessel:', error);
    return null;
  } */
}

export async function addVesselInBatch(VesselData: Omit<Vessel, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt' | 'status'>[]): Promise<Vessel[] | null> {

  const vessels = await axiosInstance.post<Vessel[]>("/vessels/batch", VesselData, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vessels.status !== 201) {
    throw new Error("Failed to add data");
  }

  return vessels.data;
  /* try {
    const newVessel = await pocketbase.collection('vessels').create<Vessel>(vesselData);
    return newVessel;
  }
    catch (error) {
    console.error('Error adding vessel:', error);
    return null;
  } */

}

export async function editVessel(id: string, vesselData: Partial<Omit<Vessel, 'id' | 'created' | 'updated'>>): Promise<Vessel | null> {

  const vessel = await axiosInstance.put<Vessel>(`/vessels/${id}`, vesselData, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vessel.status !== 200) {
    throw new Error("Failed to update data");
  }

  return vessel.data;
  /* try {
    const updatedVessel = await pocketbase.collection('vessels').update<Vessel>(id, vesselData);
    return updatedVessel;
  } catch (error) {
    console.error(`Error editing vessel with ID ${id}:`, error);
    return null;
  } */
}

export async function deleteVessel(id: string): Promise<boolean> {

  const vessel = await axiosInstance.delete(`/vessels/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vessel.status !== 204) {
    throw new Error("Failed to delete data");
  }

  return true;

  /* try {
    await pocketbase.collection('vessels').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting vessel with ID ${id}:`, error);
    return false;
  } */
}


export async function fetchVesselVisits(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedVesselVisitResponse> {

  const vesselVisits = await axiosInstance.get<PaginatedVesselVisitResponse>("/vesselvisits", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });

  if (vesselVisits.status !== 200) {
    throw new Error("Failed to fetch data");
  }

  return vesselVisits.data;
  /*
  try {
    const vessels = await pocketbase.collection('vesselVisits').getFullList<VesselVisit>(200, {
      sort: '-created',
    });
    return vessels;
  } catch (error) {
    console.error('Error fetching vessels:', error);
    return [];
  } */
}

export async function fetchVesselVisitById(id: string): Promise<VesselVisit | null> {

  const vesselVisit = await axiosInstance.get<VesselVisit>(`/vesselvisits/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vesselVisit.status !== 200) {
    throw new Error("Failed to fetch data");
  }

  return vesselVisit.data;
  /* try {
    const vessel = await pocketbase.collection('vesselVisits').getOne<VesselVisit>(id);
    return vessel;
  } catch (error) {
    console.error(`Error fetching vessel with ID ${id}:`, error);
    return null;
  } */
}

export async function addVesselVisit(vesselVisitData: Omit<VesselVisit, 'id' | 'vessel' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<VesselVisit | null> {

  const vesselVisit = await axiosInstance.post<VesselVisit>("/vesselvisits", vesselVisitData, {
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (vesselVisit.status !== 201) {
    throw new Error("Failed to add data");
  }
  return vesselVisit.data;
  /* try {
    const newVesselVisit = await pocketbase.collection('vesselVisits').create<VesselVisit>(vesselVisitData);
    return newVesselVisit;
  } catch (error) {
    console.error('Error adding vessel:', error);
    return null;
  } */
}

export async function addVesselVisitInBatch(VesselVisitData: Omit<VesselVisit, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>[]): Promise<VesselVisit[] | null> {

  const vesselVisits = await axiosInstance.post<VesselVisit[]>("/vesselvisits/batch", VesselVisitData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselVisits.status !== 201) {
    throw new Error("Failed to add data");
  }
  return vesselVisits.data;
  /* try {
    const newVesselVisit = await pocketbase.collection('vesselVisits').create<VesselVisit>(vesselVisitData);
    return newVesselVisit;
  } catch (error) {
    console.error('Error adding vessel:', error); 
    return null;
  } */
}

export async function editVesselVisit(id: string, vesselVisitData: Partial<Omit<VesselVisit, 'id' | 'vessel' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<VesselVisit | null> {

  const vesselVisit = await axiosInstance.put<VesselVisit>(`/vesselvisits/${id}`, vesselVisitData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselVisit.status !== 200) {
    throw new Error("Failed to update data");
  }
  return vesselVisit.data;

  /* try {
    const updatedVesselVisit = await pocketbase.collection('vesselVisits').update<VesselVisit>(id, vesselVisitData);
    return updatedVesselVisit;
  } catch (error) {
    console.error(`Error editing vessel with ID ${id}:`, error);
    return null;
  }*/
}

export async function deleteVesselVisit(id: string): Promise<boolean> {

  const vesselVisit = await axiosInstance.delete(`/vesselvisits/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselVisit.status !== 204) {
    throw new Error("Failed to delete data");
  }

  return vesselVisit.data;

  /* try {
    await pocketbase.collection('vesselVisits').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting vessel with ID ${id}:`, error);
    return false;
  } */
}



export async function fetchVesselBerthings(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedVesselBerthingResponse> {

  const vesselBerthings = await axiosInstance.get<PaginatedVesselBerthingResponse>("/vesselberthings", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });
  if (vesselBerthings.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return vesselBerthings.data;

  /* try {
    const vessels = await pocketbase.collection('VesselBerthing').getFullList<VesselBerthing>(200, {
      sort: '-created',
    });
    return vessels;
  } catch (error) {
    console.error('Error fetching vessels:', error);
    return [];
  } */
}

export async function fetchVesselBerthingById(id: string): Promise<VesselBerthing | null> {

  const vesselBerthing = await axiosInstance.get<VesselBerthing>(`/vesselberthings/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselBerthing.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return vesselBerthing.data;

  /* try {
    const vessel = await pocketbase.collection('VesselBerthing').getOne<VesselBerthing>(id);
    return vessel;
  } catch (error) {
    console.error(`Error fetching vessel with ID ${id}:`, error);
    return null;
  } */
}


export async function addVesselBerthing(vesselBerthingData: Omit<VesselBerthing, | "id"
  | "createdBy"
  | "updatedBy"
  | "createdAt"
  | "updatedAt"
  | "vesselVisit">): Promise<VesselBerthing | null> {

  const vesselBerthing = await axiosInstance.post<VesselBerthing>("/vesselberthings", vesselBerthingData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselBerthing.status !== 201) {
    throw new Error("Failed to add data");
  }
  return vesselBerthing.data;

  /* try {
    const newVesselBerthing = await pocketbase.collection('VesselBerthing').create<VesselBerthing>(vesselBerthingData);
    return newVesselBerthing;
  } catch (error) {
    console.error('Error adding vessel:', error);
    return null;
  } */
}

export async function addVesselBerthingInBatch(VesselBerthingData: Omit<VesselBerthing, | "id"
  | "createdBy"
  | "updatedBy"
  | "createdAt"
  | "updatedAt"
  | "vesselVisit">[]): Promise<VesselBerthing[] | null> {

  const vesselBerthings = await axiosInstance.post<VesselBerthing[]>("/vesselberthings/batch", VesselBerthingData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselBerthings.status !== 201) {
    throw new Error("Failed to add data");
  }
  return vesselBerthings.data;
  /* try {
    const newVesselBerthing = await pocketbase.collection('VesselBerthing').create<VesselBerthing>(vesselBerthingData);
    return newVesselBerthing;
  } catch (error) {
    console.error('Error adding vessel:', error);
    return null;
  } */
}



export async function editVesselBerthing(id: string, vesselBerthingData: Partial<Omit<VesselBerthing, | "id"
  | "createdBy"
  | "updatedBy"
  | "createdAt"
  | "updatedAt"
  | "vesselVisit">>): Promise<VesselBerthing | null> {

  const vesselBerthing = await axiosInstance.put<VesselBerthing>(`/vesselberthings/${id}`, vesselBerthingData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselBerthing.status !== 200) {
    throw new Error("Failed to update data");
  }
  return vesselBerthing.data;

  /* try {
    const updatedVesselBerthing = await pocketbase.collection('VesselBerthing').update<VesselBerthing>(id, vesselBerthingData);
    return updatedVesselBerthing;
  } catch (error) {
    console.error(`Error editing vessel with ID ${id}:`, error);
    return null;
  } */
}

export async function deleteVesselBerthing(id: string): Promise<boolean> {

  const vesselBerthing = await axiosInstance.delete(`/vesselberthings/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (vesselBerthing.status !== 204) {
    throw new Error("Failed to delete data");
  }
  return vesselBerthing.data;

  /* try {
    await pocketbase.collection('VesselBerthing').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting vessel with ID ${id}:`, error);
    return false;
  } */
}