import axiosInstance from '../http-client';
import { PaginatedRTLSAssetResponse, RTLSAsset } from '../models';

export async function fetchRTLSAssets(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedRTLSAssetResponse> {

    const equipments = await axiosInstance.get<PaginatedRTLSAssetResponse>("/asset/rfid", {
        headers: {
            "Content-Type": "application/json",
        },
        params: {
            skip,
            take,
            filter,
            sort,
            search,
            searchFields,
            expand,
        },
    });
    if (equipments.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;

}
export async function fetchRTLSAssetsById(id: string): Promise<RTLSAsset | null> {

    const equipments = await axiosInstance.get<RTLSAsset>(`/asset/rfid/${id}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (equipments.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;
}

export async function addRTLSAsset(EquipmentData: Omit<RTLSAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<RTLSAsset | null> {

    const equipments = await axiosInstance.post<RTLSAsset>("/asset/rfid", EquipmentData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (equipments.status !== 201) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;
}

export async function addRTLSAssetsInBatch(RTLSAssetData: Omit<RTLSAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<RTLSAsset | null> {
    const equipments = await axiosInstance.post<RTLSAsset>("asset/rfid/batch", RTLSAssetData, {
        headers: { "Content-Type": "application/json" },
    });
    if (equipments.status !== 201) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;
}



export async function editRTLSAsset(EquipmentData: Partial<Omit<RTLSAsset, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<RTLSAsset | null> {

    const equipments = await axiosInstance.put<RTLSAsset>(`/asset/rfid/`, EquipmentData, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (equipments.status !== 200) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;
}

export async function deleteRTLSAsset(id: string): Promise<boolean> {

    const equipments = await axiosInstance.delete(`/asset/rfid/${id}`, {
        headers: {
            "Content-Type": "application/json",
        },
    });
    if (equipments.status !== 204) {
        throw new Error("Failed to fetch data");
    }
    return equipments.data;
}

