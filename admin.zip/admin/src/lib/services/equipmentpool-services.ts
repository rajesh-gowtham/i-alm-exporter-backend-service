// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { EquipmentPool, EquipmentPoolAssignmentsRequest, EquipmentPoolAssignmentsResponse, PaginatedEquipmentPoolResponse } from '../models';

export async function fetchEquipmentPools(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedEquipmentPoolResponse> {

  const EquipmentPools = await axiosInstance.get<PaginatedEquipmentPoolResponse>("/equipmentpools", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;

  /* try {
    const EquipmentPools = await pocketbase.collection('EquipmentPool').getFullList<EquipmentPool>(200, {
      sort: '-created',
    });
    return EquipmentPools;
  } catch (error) {
    console.error('Error fetching EquipmentPools:', error);
    return [];
  } */
}

export async function fetchEquipmentPoolById(id: string): Promise<EquipmentPool | null> {

  const EquipmentPools = await axiosInstance.get<EquipmentPool>(`/equipmentpools/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;
  /* try {
    const EquipmentPool = await pocketbase.collection('EquipmentPool').getOne<EquipmentPool>(id);
    return EquipmentPool;
  }
  catch (error) {
    console.error(`Error fetching EquipmentPool with ID ${id}:`, error);
    return null;
  } */
}

export async function addEquipmentPool(EquipmentPoolData: Omit<EquipmentPool, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<EquipmentPool | null> {

  const EquipmentPools = await axiosInstance.post<EquipmentPool>("/equipmentpools", EquipmentPoolData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;
  /* try {
    const newEquipmentPool = await pocketbase.collection('EquipmentPool').create<EquipmentPool>(EquipmentPoolData);
    return newEquipmentPool;
  } catch (error) {
    console.error('Error adding EquipmentPool:', error);
    return null;
  } */
}

export async function addEquipmentPoolInBatch(EquipmentPoolData: Omit<EquipmentPool, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>[]): Promise<EquipmentPool[] | null> {
  const EquipmentPools = await axiosInstance.post<EquipmentPool[]>("/equipmentpools/batch", EquipmentPoolData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;
  /* try {
    const newEquipmentPool = await pocketbase.collection('EquipmentPool').create<EquipmentPool>(EquipmentPoolData);
    return newEquipmentPool;
  }
  catch (error) {
    console.error('Error adding EquipmentPool:', error);
    return null;
  } */

}

export async function fetchEquipmentByPoolId(id: string): Promise<EquipmentPool | null> {
  const EquipmentPools = await axiosInstance.get<EquipmentPool>(`/equipmentpools/equipment/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;
  /* try {
    const EquipmentPool = await pocketbase.collection('EquipmentPool').getOne<EquipmentPool>(id);
    return EquipmentPool; 
  }
  catch (error) {
    console.error(`Error fetching EquipmentPool with ID ${id}:`, error);
    return null;
  } */
}

export async function fetchAssignedEquipmentByPoolName(pool: string): Promise<string[]> {
  const EquipmentPools = await axiosInstance.get<string[]>(`/equipmentpoolassignments/assignedPools?equipmentPoolName=${pool}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;

}

export async function editEquipmentPool(id: string, EquipmentPoolData: Partial<Omit<EquipmentPool, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<EquipmentPool | null> {

  const EquipmentPools = await axiosInstance.put<EquipmentPool>(`/equipmentpools/`, EquipmentPoolData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;
  /* 
  try {
    const updatedEquipmentPool = await pocketbase.collection('EquipmentPool').update<EquipmentPool>(id, EquipmentPoolData);
    return updatedEquipmentPool;
  } catch (error) {
    console.error(`Error editing EquipmentPool with ID ${id}:`, error);
    return null;
  }
    */
}

export async function deleteEquipmentPool(id: string): Promise<boolean> {

  const EquipmentPools = await axiosInstance.delete<EquipmentPool>(`/equipmentpools/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 204) {
    throw new Error("Failed to fetch data");
  }
  return true;

  /* try {
    await pocketbase.collection('EquipmentPool').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting EquipmentPool with ID ${id}:`, error);
    return false;
  } */
}

//Api for assigned equipment by pool id

export async function fetchAssignedData(id: string): Promise<EquipmentPoolAssignmentsResponse> {

  const EquipmentPools = await axiosInstance.get<EquipmentPoolAssignmentsResponse>(`/equipmentpoolassignments/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  return EquipmentPools.data
  // if (EquipmentPools.status !== 200) {

  //   throw new Error("Failed to fetch data");
  // }
  // return EquipmentPools.data;

}
//api for update equiment to pool

export async function equipmentPoolAssignments(EquipmentData: Partial<Omit<EquipmentPoolAssignmentsRequest[], 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>, id: string): Promise<EquipmentPool | null> {
  console.log(EquipmentData, id);
  const EquipmentPools = await axiosInstance.post<EquipmentPoolAssignmentsRequest>(`/equipmentpoolassignments/${id}`, EquipmentData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (EquipmentPools.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return EquipmentPools.data;

}
