// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { Equipment, PaginatedEquipmentResponse } from '../models';

export async function fetchEquipments(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedEquipmentResponse> {

  const equipments = await axiosInstance.get<PaginatedEquipmentResponse>("/equipment", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });
  if (equipments.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;

  /* try {
    const Equipments = await pocketbase.collection('Equipment').getFullList<Equipment>(200, {
      sort: '-created',
    });
    return Equipments;
  } catch (error) {
    console.error('Error fetching Equipments:', error);
    return [];
  } */
}

export async function fetchEquipmentById(id: string): Promise<Equipment | null> {

  const equipments = await axiosInstance.get<Equipment>(`/equipment/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (equipments.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;

  /* try {
    const Equipment = await pocketbase.collection('Equipment').getOne<Equipment>(id);
    return Equipment;
  } catch (error) {
    console.error(`Error fetching Equipment with ID ${id}:`, error);
    return null;
  } */
}

export async function addEquipment(EquipmentData: Omit<Equipment, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<Equipment | null> {

  const equipments = await axiosInstance.post<Equipment>("/equipment", EquipmentData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (equipments.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;

  /* try {
    const newEquipment = await pocketbase.collection('Equipment').create<Equipment>(EquipmentData);
    return newEquipment;
  } catch (error) {
    console.error('Error adding Equipment:', error);
    return null;
  }*/
}

export async function addEquipmentInBatch(EquipmentData: Omit<Equipment, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>): Promise<Equipment | null> {
  const equipments = await axiosInstance.post<Equipment>("/equipment/batch", EquipmentData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (equipments.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;
  /* try {
    const newEquipment = await pocketbase.collection('Equipment').create<Equipment>(EquipmentData);
    return newEquipment;
  }
  catch (error) {
    console.error('Error adding Equipment:', error);
    return null;
  }*/
}



export async function editEquipment(id: string, EquipmentData: Partial<Omit<Equipment, 'id' | 'createdBy' | 'updatedBy' | 'createdAt' | 'updatedAt'>>): Promise<Equipment | null> {

  const equipments = await axiosInstance.put<Equipment>(`/equipment/`, EquipmentData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (equipments.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;
  /* try {
    const updatedEquipment = await pocketbase.collection('Equipment').update<Equipment>(id, EquipmentData);
    return updatedEquipment;
  } catch (error) {
    console.error(`Error editing Equipment with ID ${id}:`, error);
    return null;
  } */
}

export async function deleteEquipment(id: string): Promise<boolean> {

  const equipments = await axiosInstance.delete(`/equipment/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (equipments.status !== 204) {
    throw new Error("Failed to fetch data");
  }
  return equipments.data;
  /* try {
    await pocketbase.collection('Equipment').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting Equipment with ID ${id}:`, error);
    return false;
  } */
}

