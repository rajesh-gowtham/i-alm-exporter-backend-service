// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { PaginatedWorkInstructionResponse, WorkInstruction } from '../models';

export async function fetchWorkInstructions(skip?: number, take?: number, search?: string, filter?: string, sort?: string, searchFields?: string, expand?: string): Promise<PaginatedWorkInstructionResponse> {

  const WorkInstructions = await axiosInstance.get<PaginatedWorkInstructionResponse>("/workinstructions", {
    headers: {
      "Content-Type": "application/json",
    },
    params: {
      skip,
      take,
      filter,
      sort,
      search,
      searchFields,
      expand,
    },
  });
  if (WorkInstructions.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return WorkInstructions.data;

  /* try {
    const WorkInstructions = await pocketbase.collection('WorkInstruction').getFullList<WorkInstruction>(200, {
      sort: '-created',
    });
    return WorkInstructions;
  } catch (error) {
    console.error('Error fetching WorkInstructions:', error);
    return [];
  } */
}

export async function fetchWorkInstruction(id: string): Promise<WorkInstruction | null> {

  const WorkInstructions = await axiosInstance.get<WorkInstruction>(`/workinstructions/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (WorkInstructions.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return WorkInstructions.data;

  /* try {
    const WorkInstruction = await pocketbase.collection('WorkInstruction').getOne<WorkInstruction>(id);
    return WorkInstruction;
  } catch (error) {
    console.error(`Error fetching WorkInstruction with ID ${id}:`, error);
    return null;
  } */
}


export async function addWorkInstruction(WorkInstructionData: Omit<WorkInstruction, 'id' | 'created' | 'updated'>): Promise<WorkInstruction | null> {
  console.log(WorkInstructionData);

  const WorkInstructions = await axiosInstance.post<WorkInstruction>("/workinstructions", WorkInstructionData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (WorkInstructions.status !== 201) {
    throw new Error("Failed to fetch data");
  }
  return WorkInstructions.data;

  /* try {
    const newWorkInstruction = await pocketbase.collection('WorkInstruction').create<WorkInstruction>(WorkInstructionData);
    return newWorkInstruction;
  } catch (error) {
    console.error('Error adding WorkInstruction:', error);
    return null;
  } */
}
export async function addWorkInstructionInBatch(WorkInstructionData: Omit<WorkInstruction, 'id' | 'created' | 'updated'>[]): Promise<WorkInstruction[] | null> {
  const WorkInstructions = await axiosInstance.post<WorkInstruction[]>("/workinstructions/batch", WorkInstructionData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (!(WorkInstructions.status === 200 || WorkInstructions.status === 201)) {
    throw new Error("Failed to fetch data");
  }
  return WorkInstructions.data;
  /* try {
    const newWorkInstruction = await pocketbase.collection('WorkInstruction').create<WorkInstruction>(WorkInstructionData);
    return newWorkInstruction;
  } catch (error) {
    console.error('Error adding WorkInstruction:', error);
    return null;
  } */
}

export async function editWorkInstruction(id: string, WorkInstructionData: Partial<Omit<WorkInstruction, 'id' | 'created' | 'updated'>>): Promise<WorkInstruction | null> {

  const WorkInstructions = await axiosInstance.put<WorkInstruction>(`/workinstructions/${id}`, WorkInstructionData, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (WorkInstructions.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return WorkInstructions.data;

  /* try {
    const updatedWorkInstruction = await pocketbase.collection('WorkInstruction').update<WorkInstruction>(id, WorkInstructionData);
    return updatedWorkInstruction;
  } catch (error) {
    console.error(`Error editing WorkInstruction with ID ${id}:`, error);
    return null;
  } */
}

export async function deleteWorkInstruction(id: string): Promise<boolean> {

  const WorkInstructions = await axiosInstance.delete<WorkInstruction>(`/workinstructions/${id}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (WorkInstructions.status !== 204) {
    throw new Error("Failed to fetch data");
  }
  return true;

  /* try {
    await pocketbase.collection('WorkInstruction').delete(id);
    return true;
  } catch (error) {
    console.error(`Error deleting WorkInstruction with ID ${id}:`, error);
    return false;
  } */
}

