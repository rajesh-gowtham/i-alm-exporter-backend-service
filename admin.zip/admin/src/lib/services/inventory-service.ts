/* eslint-disable @typescript-eslint/no-explicit-any */
import axiosInstance from "../http-client";
import { ContainerDetail, PaginatedContainerInventoryResponse, PaginatedVesselInventoryResponse } from "../models";

export async function fetchContainerInventoryAPICALL(skip: number, take: number, search: string): Promise<PaginatedContainerInventoryResponse> {
    try {
        const response = await axiosInstance.get<PaginatedContainerInventoryResponse>(
            `/inventory/container?skip=${skip}&take=${take}&search=${encodeURIComponent(search)}`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function fetchVesselInventoryAPICALL(skip: number, take: number, search: string): Promise<PaginatedVesselInventoryResponse> {
    try {
        const response = await axiosInstance.get<PaginatedVesselInventoryResponse>(
            `/inventory/vessel?skip=${skip}&take=${take}&search=${encodeURIComponent(search)}`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};
export async function fetchConatinerDetailsAPICALL(id: number): Promise<ContainerDetail> {
    try {
        const response = await axiosInstance.get<ContainerDetail>(
            `/inventory/container/` + id
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function clearConatinerInventoryByIdsAPICALL(payload: { ids: number[] }) {
    try {
        const response = await axiosInstance.post(`inventory/container/clear`, payload);
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};

export async function fetchAllContainerInventory(): Promise<PaginatedContainerInventoryResponse> {
    try {
        const response = await axiosInstance.get<PaginatedContainerInventoryResponse>(
            `/inventory/container`
        );
        return response.data;
    } catch (error: any) {
        throw {
            status: error?.response?.status,
            message: error?.response?.data?.message || "An unexpected error occurred",
            data: error?.response?.data,
        };
    }
};