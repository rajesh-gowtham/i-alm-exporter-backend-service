import pb from '../api/pb';

import { DeviceAsset } from '../models';


export async function isDeviceIdUnique(deviceId: string, currentId?: string): Promise<boolean> {
  try {
    const records = await pb.collection("devices").getList(1, 1, {
      filter: `deviceId = "${deviceId}"`,
    });
    if (records.items.length === 0) return true;
    const existing = records.items[0];
    return existing.id === currentId; // true if no duplicate
  } catch (error) {
    console.error("PocketBase check failed:", error);
    return false; // fail safe (treat as duplicate)
  }
}

export async function fetchDeviceAssets(
  page: number = 1,
  perPage: number = 20,
  filter?: string,
  sort?: string,
  expand?: string
) {
   const search = filter ? `deviceId ~ "${filter}" || model ~ "${filter}" || manufacturer ~ "${filter}"` : "";
  const records = await pb.collection('devices').getList<DeviceAsset>(page, perPage, {
    filter: search,
    sort,
    expand
  });
  return records; // contains items, page, perPage, totalPages, totalItems
}

export async function fetchDeviceAssetsById(id: string): Promise<DeviceAsset | null> {
  const record = await pb.collection('devices').getOne<DeviceAsset>(id);
  return record;
}

export async function addDeviceAsset(data: Omit<DeviceAsset, 'id' | 'createdAt' | 'updatedAt'>): Promise<DeviceAsset> {

  console.log("Before Adding new device asset:", data);
  const record = await pb.collection('devices').create<DeviceAsset>(data);
  console.log("Added new device asset:", record);
  return record;
}

export async function addDeviceAssetsInBatch(data: Omit<DeviceAsset, 'id' | 'createdAt' | 'updatedAt'>[]): Promise<DeviceAsset[]> {
  const promises = data.map((d) => pb.collection('devices').create<DeviceAsset>(d));
  const records = await Promise.all(promises);

  return records;
}

export async function editDeviceAsset(id: string, data: Partial<DeviceAsset>): Promise<DeviceAsset> {
  const record = await pb.collection('devices').update<DeviceAsset>(id, data);
  return record;
}

export async function deleteDeviceAsset(id: string): Promise<boolean> {
  await pb.collection('devices').delete(id);
  return true;
}