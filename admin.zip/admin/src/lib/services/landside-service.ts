// import pocketbase from '../api/pb';
import axiosInstance from '../http-client';
import { DashboardPayload, PaginatedqcDetailsResponse } from '../models';
// import { PaginatedPointOfWorkResponse, PointofWork } from '../models';


export async function fetchLandsideData(payload:DashboardPayload){
    const{cardName,skip,take}=payload
  console.log(cardName)
  const landSide = await axiosInstance.get(`/dashboard/landSide?cardName=${cardName}&skip=${skip}&take=${take}`, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (landSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return landSide.data;
}
export async function fetchLandsideGridData(payload:any):Promise<PaginatedqcDetailsResponse>{
  const landSide = await axiosInstance.post<PaginatedqcDetailsResponse>('/dashboard/landside',payload, {
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (landSide.status !== 200) {
    throw new Error("Failed to fetch data");
  }
  return landSide.data;
}


