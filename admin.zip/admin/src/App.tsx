import "@/index.css";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "sonner";
import { RouterProvider } from "react-router";
import { APIProvider } from "@vis.gl/react-google-maps";
import { Env } from "@/lib/constants";
import { router } from "@/routes";
import { AuthProvider } from "./lib/fake-auth";

export default function App() {
  // console.log(router);
  return (
    <>
      <APIProvider apiKey={Env.GoogleMapsUrl}>
        <ThemeProvider defaultTheme="light" storageKey="poe-ui-theme">
          <AuthProvider>
            <RouterProvider router={router} />
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </APIProvider>
    </>
  );
}
