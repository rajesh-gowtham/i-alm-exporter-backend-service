import {
  Navigate,
  Outlet,
  useLocation,
  useMatches,
  useNavigate,
} from "react-router";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebarV2 from "@/components/app-sidebar";
import { AnimatePresence, motion } from "motion/react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "./ui/separator";
// import { ModeToggle } from "./mode-toggle";
// import UserProfile from "./user-profile";
// import NotificationsButton from "./notifications-btn";
import { routesList } from "@/routes";
import useAuthStore from "@/lib/stores/auth-stores";
import { Fragment } from "react/jsx-runtime";
import UserProfile from "./user-profile";
import { publicRoute } from "@/lib/constants";

export default function MainLayout() {
  const location = useLocation();
  const authStore = useAuthStore();

  if (!authStore.getIsAuthorized()) {
    return <Navigate to={publicRoute._Login} replace />;
  }

  return (
    <AnimatePresence>
      <SidebarProvider defaultOpen={false}>
        <AppSidebarV2 />
        <div className="w-full overflow-x-auto overflow-y-hidden bg-muted">
          <main className="w-full h-full p-4 px-1 border shadow-md bg-background shadow-black/5">
            <Header />
            <motion.div
              key={location.pathname}
              exit={{
                y: -20,
                opacity: 0,
                filter: "blur(5px)",
                transition: { ease: "easeIn", duration: 0.22 },
              }}
              initial={{ opacity: 0, y: -15 }}
              animate={{
                opacity: 1,
                y: 0,
                filter: "blur(0px)",
                transition: { type: "spring", duration: 0.7 },
              }}
              className="w-full"
            >
              <Outlet />
            </motion.div>
          </main>
        </div>
      </SidebarProvider>
    </AnimatePresence>
  );
}

function Header() {
  const navigate = useNavigate();
  const matches = useMatches();
  // map of path to name
  const mapping: Record<string, string> = {};

  for (const route of routesList) {
    if (!mapping[route.url]) {
      mapping[route.url] = route.title;
    }
  }

  const crumbs = matches
    .map((match) => match.pathname)
    .filter((value, index, array) => array.indexOf(value) === index);
  console.log(crumbs)
  const breadCrumbItems = (() => {
    const lastPath = crumbs[crumbs.length - 1]; // Get the last path
    const parts = lastPath.split("/").filter(Boolean);
    console.log("parts", parts) // Remove empty segments
    const formattedCrumbs = parts.length === 0 ? ['Dashboard'] : parts.slice(parts.length === 2 && parts[0] === 'rtls' ? 0 : -1);
    console.log("formattedCrumbs", formattedCrumbs)
    return formattedCrumbs.map((crumb, index) => {
      const isLast = index === formattedCrumbs.length - 1;
      const fullPath = "/" + parts.slice(0, index).join("/"); // Construct path for navigation

      return (
        <Fragment key={fullPath}>
          <BreadcrumbItem className={!isLast ? "hidden md:block" : ""}>
            {!isLast ? (
              <BreadcrumbLink
                href="#"
                className="capitalize"
                onClick={(e) => {
                  e.preventDefault();
                  navigate(fullPath);
                }}
              >
                {crumb.toUpperCase()}
              </BreadcrumbLink>
            ) : (
              <BreadcrumbPage className="capitalize">
                {
                  crumb === "workinstruction" ? "Work Instruction" :
                    crumb === "rtls" ? "RTLS" :
                      crumb === "devices" ? "Telematics Devices" :
                        crumb === "vessels" ? "Vessel" :
                          (crumb === "vesselvisit" ? "Vessel Visit" :
                            (crumb === "equipmentpool" ? "Pools & Equipment" :
                              (crumb === "pointofwork" ? "POW" :
                                (crumb === "workqueue" ? "Work Queue" :
                                  crumb))))
                }
              </BreadcrumbPage>
            )}
          </BreadcrumbItem>
          {!isLast && <BreadcrumbSeparator className="hidden md:block" />}
        </Fragment>
      );
    });
  })();

  /*
  const breadCrumbItems = crumbs.map((value, index) => {
    const isLast = index === crumbs.length - 1;

    return (
      <>
        <BreadcrumbItem className={!isLast ? "hidden md:block" : ""}>
          {!isLast ? (
            <BreadcrumbLink
              href="#"
              onClick={(e) => {
                e.preventDefault();
                navigate(value);
              }}
            >
              {mapping[value]}
            </BreadcrumbLink>
          ) : (
            <BreadcrumbPage>
              {value === "/" ? "Dashboard" : mapping[value]}
            </BreadcrumbPage>
          )}
        </BreadcrumbItem>
        {isLast ? <></> : <BreadcrumbSeparator className="hidden md:block" />}
      </>
    );
  }); 
  */

  return (
    <header className="top-0 z-10 flex items-center w-full gap-2 px-4 bg-background/50 backdrop-blur">
      <div className="flex flex-row items-center justify-between w-full">
        <div className="flex items-center basis-1/4 h-11 ">

          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="h-4 mr-2" />
          <Breadcrumb>
            <BreadcrumbList>{breadCrumbItems}</BreadcrumbList>
          </Breadcrumb>
        </div>

        <div className="inline-flex justify-end h-8 space-x-4 basis-1/4">
          {/* <NotificationsButton /> */}
          {/* <ModeToggle /> */}
          <UserProfile />
        </div>
      </div>
    </header>
  );
}
