import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { BadgeCheck, ChevronsUpDown, LogOut } from "lucide-react";
import { useNavigate } from "react-router";
import useAuthStore from "@/lib/stores/auth-stores";
import { SidebarMenuButton, useSidebar } from "./ui/sidebar";

type User = {
  name: string;
  email: string;
};

export default function UserProfile() {
  const navigate = useNavigate();
  const authStore = useAuthStore();
  const { isMobile } = useSidebar();
  const user: User = {
    name: "Admin",
    email: "admin@rtls.com",
    // avatar: "https://github.com/shadcn.png",
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
           <SidebarMenuButton
                        size="lg"
                        className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                      >
          <Avatar className="w-8 h-8 item-center">
            <AvatarImage src="https://avatar.iran.liara.run/public" alt="@shadcn" />
            <AvatarFallback>A</AvatarFallback>
          </Avatar>
           <ChevronsUpDown className="ml-auto size-4" />
          </SidebarMenuButton>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
          side={isMobile ? "bottom" : "right"}
          align="end"
          sideOffset={4}
        >
          <DropdownMenuLabel className="p-0 font-normal">
            <div className="flex items-center p-2">
              <div className="grid flex-1 text-sm leading-tight text-left">
                <span className="font-semibold truncate">{user.name}</span>
                <span className="text-xs truncate">{user.email}</span>
              </div>
            </div>
            
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem
              className="cursor-pointer"
              onClick={() => navigate("/profile")}
            >
              <BadgeCheck />
              Account
            </DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="cursor-pointer"
            onClick={() => {
              authStore.logout();
              // navigate("/login");
            }}
          >
            <LogOut />
            Log out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
