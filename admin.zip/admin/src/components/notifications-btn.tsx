import { Bell } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
} from "@/components/ui/dropdown-menu";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "./ui/button";
type Notification = {
  id: number;
  message: string;
  time: string;
};

export default function NotificationDropdown() {
  const notifications: Notification[] = [];
  return (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <div className="relative w-8 h-full cursor-pointer">
          <Button
            variant="outline"
            size="icon"
            className="w-8 h-full"
            onClick={() => {}}
          >
            <Bell className="h-[1.2rem] w-[1.2rem] " />
            {notifications.length > 0 && (
              <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 " />
            )}
          </Button>
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="w-[--radix-dropdown-menu-trigger-width] min-w-60 rounded-lg bg-card dark:bg-muted"
        side="bottom"
        align="end"
        sideOffset={4}
      >
        <Card className="border-0 shadow-none min-h-28 bg-card dark:bg-muted">
          <CardContent className="p-2 border-0 ">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold text-white-700">
                Notifications
              </h3>
              {notifications.length > 0 && (
                <span className="text-sm cursor-pointer text-white-500">
                  Mark all as read
                </span>
              )}
            </div>
            {notifications.length > 0 ? (
              <ul>
                {notifications.map((notification) => (
                  <li
                    key={notification.id}
                    className="py-2 border-b last:border-none"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-white-600">
                        {notification.message}
                      </p>
                      <span className="text-xs text-white-400">
                        {notification.time}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-dimmed-foreground">No notifications</p>
            )}
          </CardContent>
        </Card>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
