import { useMap } from "@vis.gl/react-google-maps";
import { useEffect, useMemo } from "react";
import { GoogleMapsOverlay } from "@deck.gl/google-maps";
import type { LayersList } from "@deck.gl/core";
import { PickingInfo } from "@deck.gl/core";
import type { TooltipContent } from "node_modules/@deck.gl/core/src/lib/tooltip";

export type DeckglOverlayProps = {
  layers?: LayersList;
  getTooltip?: ((info: PickingInfo) => TooltipContent) | null;
};

export const DeckGlOverlay = ({ layers, getTooltip }: DeckglOverlayProps) => {
  // the GoogleMapsOverlay can persist throughout the lifetime of the DeckGlOverlay
  const deck = useMemo(
    () =>
      new GoogleMapsOverlay({
        interleaved: true,
      }),
    []
  );

  // add the overlay to the map once the map is available
  const map = useMap();
  useEffect(() => {
    map?.setOptions({ draggableCursor: "pointer" });
    deck.setMap(map);
    return () => deck.setMap(null);
  }, [deck, map]);

  // whenever the rendered data changes, the layers will be updated
  useEffect(() => {
    deck.setProps({ layers, getTooltip });
  }, [deck, layers]);

  // no dom rendered by this component
  return null;
};
