import { PropsWithChildren, useEffect, useState } from "react";
import { Map, useMap } from "@vis.gl/react-google-maps";

const defaultCenter = { lat: 47.976253, lng: -122.223782 };

type MapViewComponentProps = {
  id: string;
  disableDefaultUI?: boolean;
  mapTpe?: string;
  className?: string;
};

const MapViewComponent = ({
  id,
  disableDefaultUI = false,
  mapTpe = "roadmap",
  className,
  children,
}: PropsWithChildren<MapViewComponentProps>) => {
  return (
    <Map
      id={id}
      key={id}
      mapId={id}
      defaultZoom={13}
      defaultCenter={defaultCenter}
      disableDefaultUI={disableDefaultUI}
      mapTypeControl={true}
      // mapTypeId={window.google.maps.MapTypeId.SATELLITE}
      mapTypeId={mapTpe}
      gestureHandling={"greedy"}
      streetViewControl={false}
      className={className}
    >
      {children}
    </Map>
  );
};

export function MapViewControl({
  bounds,
  zoom,
  zoomAfterBoundsChange,
  onMapLoaded,
}: {
  bounds?: google.maps.LatLngBounds | null;
  zoom?: number;
  zoomAfterBoundsChange?: boolean;
  onMapLoaded?: () => void;
}) {
  const map = useMap();
  const [mapLoaded, setMapLoaded] = useState(false);

  useEffect(() => {
    const isLoaded = map !== null;
    setMapLoaded(isLoaded);
    if (onMapLoaded) onMapLoaded();
    // set intial zoom
    if (isLoaded && zoom) map.setZoom(zoom);
  }, [map]);

  useEffect(() => {
    if (mapLoaded && bounds) {
      map?.panToBounds(bounds);
      map?.fitBounds(bounds);
      if (zoomAfterBoundsChange && zoom) map?.setZoom(zoom);
    }
  }, [mapLoaded, bounds]);

  return <></>;
}

export default MapViewComponent;
