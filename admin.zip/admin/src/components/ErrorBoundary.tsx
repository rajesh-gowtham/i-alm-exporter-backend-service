// ErrorPage.tsx
import { isRouteErrorResponse, useRouteError } from 'react-router';

const ErrorPage = () => {
    const error = useRouteError();
    if (isRouteErrorResponse(error)) {
        return (
            <div className="text-center p-10">
                <h1 className="text-5xl font-bold text-red-600">{error.status}</h1>
                <p className="mt-4 text-2xl">{error.statusText}</p>
                <p className="mt-2 text-gray-500">{error.data}</p>
            </div>
        );
    }

    return (
        <div className="text-center p-10">
            <h1 className="text-5xl font-bold text-red-600">Unexpected Application Error</h1>
            <p className="mt-4 text-2xl">Something went wrong.</p>
        </div>
    );
};

export default ErrorPage;
