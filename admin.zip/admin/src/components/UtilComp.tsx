import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Cog, Loader2, PenSquare, Trash } from "lucide-react";
import { FieldErrors, UseFormClearErrors, UseFormHandleSubmit, UseFormRegister, UseFormSetValue } from "react-hook-form";
import { IoArrowBackOutline } from "react-icons/io5";
import { toast } from "sonner";
import { Input } from "./ui/input";

export interface optionsListProps {
    label: string;
    value: string;
}
interface DropdownWhiteProps {
    fieldName: string;
    fieldValue: string;
    setValue: UseFormSetValue<T>;
    clearErrors: UseFormClearErrors<T>;
    Label_Placeholder: string;
    optionsList: optionsListProps[];
    disabled?: boolean;
    error?: boolean;
}
export function DropdownWhite({ Label_Placeholder, fieldName, fieldValue, setValue, clearErrors, optionsList, disabled, error }: DropdownWhiteProps) {
    // // console.log(fieldName, fieldValue, optionsList);
    return (
        <Select
            defaultValue={fieldValue}
            disabled={disabled}
            onValueChange={(value) => {
                setValue(fieldName, value, { shouldValidate: true });
                clearErrors(fieldName);
            }}>
            <SelectTrigger error={error} className=" bg-transparent">
                <SelectValue className="placeholder:text-gray-300 text-gray-200" placeholder={`Select ${Label_Placeholder}`} />
            </SelectTrigger>
            <SelectContent >
                {optionsList?.map((item) => (
                    <SelectItem key={item.value} value={item.value}>
                        {item.label}
                    </SelectItem>
                ))}
            </SelectContent>
        </Select>
    );
}

interface TableActionIconsProps<T> {
    loading: boolean;
    handleEditClick: (arg: T) => void;
    handleDeleteClick: (arg: T) => void;
    rowOriginal: T;
    isEquipment?: boolean;
    handleViewClick?: (arg: T) => void;
}


export const TableActionIcons = <T,>({
    loading,
    handleEditClick,
    handleDeleteClick,
    rowOriginal,
    isEquipment,
    handleViewClick
}: TableActionIconsProps<T>) => {
    return (
        <div className="flex space-x-2">
            {/* {isEquipment &&
                <Button
                    size="icon"
                    variant="outline"
                    disabled={loading}
                    className="w-4 h-4"

                    onClick={() => handleViewClick(rowOriginal)}
                >
                    <Cog className="w-6 h-6" />
                </Button>
            } */}
            <Button
                size="icon"
                variant="outline"
                disabled={loading}
                className="w-4 h-4"
                onClick={() => handleEditClick(rowOriginal)}
            >
                <PenSquare className="w-4 h-4" />
            </Button>
            <Button
                size="icon"
                variant="outline"
                disabled={loading}
                className="w-4 h-4"
                onClick={() => handleDeleteClick(rowOriginal)}
            >
                <Trash className="w-4 h-4" />
            </Button>
        </div>
    );
};

type FormActionsProps = {
    isEdit: boolean;
    isLoading: boolean;
    onClose: () => void;
    isSecondStepActive?: boolean;
    onBack?: () => void;
}

export const FormActions = ({
    isEdit,
    isLoading,
    onClose,
    isSecondStepActive,
    onBack
}: FormActionsProps) => {
    return (
        <div className="flex justify-end mt-4 space-x-2">
            {/* { isSecondStepActive && <Button
                type="button"
                onClick={onBack}
            >
                Back
            </Button>} */}
            <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                    </>
                ) : isEdit ? (
                    "Update"
                ) : (
                    "Save"
                )}
            </Button>
            <Button
                type="button"
                variant="secondary"
                onClick={onClose}
                disabled={isLoading}
            >
                Cancel
            </Button>
        </div>
    );
};

type NextActionProps = {
    onClose: () => void;
}
export const NextActions = ({ onClose }: NextActionProps) => {
    return (
        <div className="flex justify-end mt-4 space-x-2">

            <Button
                type="submit"
            >
                Next
            </Button>
        </div>
    );
}

export const SuccessToaster = (header: string, description: string) => {
    toast.success(header, {
        description,
        style: { backgroundColor: '#EC8928', color: 'white' },
    });
};
export const ErrorToaster = (header: string, description?: string) => {
    toast.error(header, {
        description,
        style: { backgroundColor: 'red', color: 'white' },
    });
};

export const MandatoryIcon = () => {
    return <span className="text-red-500 pl-1">*</span>
}
interface DeleteConfirmModelUIProps {
    loading: boolean;
    isModelOpen: boolean;
    setIsModelOpen: (arg: boolean) => void;
    selectedName: string;
    onConfirmDeleteClick: () => void;
}
export const DeleteConfirmModelUI = ({ loading, isModelOpen, setIsModelOpen, selectedName, onConfirmDeleteClick }: DeleteConfirmModelUIProps) => {
    return (
        <div>
            <Dialog open={isModelOpen} onOpenChange={setIsModelOpen}>
                <DialogContent>
                    <DialogTitle>Confirm Deletion</DialogTitle>
                    <p>
                        Are you sure you want to delete  {" "}
                        <b>{selectedName}</b>?
                        <br />
                        <br />
                        <span className="text-sm italic ">This action cannot be undone.</span>
                    </p>
                    <div className="flex justify-end mt-2 space-x-2">
                        <Button
                            variant="outline"
                            disabled={loading}
                            onClick={() => setIsModelOpen(false)}
                        >
                            Cancel
                        </Button>
                        <Button
                            variant="destructive"
                            disabled={loading}
                            onClick={onConfirmDeleteClick}
                        >
                            Delete
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </div>)
}
interface FileImportProps {
    handleSubmit: UseFormHandleSubmit<{
        file: FileList;
    }>;
    setUploading: React.Dispatch<React.SetStateAction<boolean>>;
    uploading: boolean;
    processExcelFile: (file: File) => void;
    register: UseFormRegister<{
        file: FileList;
    }>,
    errors: FieldErrors<{
        file: FileList;
    }>;
    backToParent: (arg: string) => void;
    filename: string;
}
export const FileImport = ({ handleSubmit, setUploading, uploading, processExcelFile, register, errors, filename, backToParent }: FileImportProps) => {
    return (
        <div>
            <Button
                title="Back"
                size="sm"
                variant="outline"
                // onClick={() => navigate(`${importNavigationUrl}`)}
                onClick={() => { backToParent("CLEAR") }}
            >
                <IoArrowBackOutline />

            </Button>
            <div className="max-w-4xl p-6 mx-auto rounded-lg shadow-md bg-muted">
                <form onSubmit={handleSubmit((data) => {
                    setUploading(true);
                    processExcelFile(data.file[0]);
                })} className="space-y-4">
                    <p className="text-sm text-gray-600">
                        Download template:{" "}
                        <a href={`/files/dataimport/${filename}`} className="text-blue-600 hover:underline">
                            {filename}
                        </a>
                    </p>

                    <div className="space-y-2">
                        <Input
                            type="file"
                            accept=".xlsx"
                            {...register("file")}
                            className="w-full p-2 border rounded-md cursor-pointer"
                        />
                        {errors.file && (
                            <p className="mt-1 text-sm text-red-500">{errors.file.message}</p>
                        )}
                    </div>

                    <Button
                        type="submit"
                        disabled={uploading}
                        className="w-full text-white bg-blue-600 hover:bg-blue-700 disabled:bg-muted disabled:cursor-not-allowed"
                    >
                        {uploading ? "Processing..." : "Upload"}
                    </Button>
                </form>
            </div>
        </div>
    )
}