import Map from "@/app/map/Map";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { type ClassValue } from "clsx";
import decarb from '../../asset/decarb.jpg'
import landsideITV from '../../asset/landsideITV.jpg'
import landsideYC from '../../asset/lanside YC.jpg'
import waterside from '../../asset/watwrside.jpg'
import { useNavigate } from "react-router";

const dashboardRegistCatagory = [
  {
    title: "Waterside",
    description: "Area and activities on the landside",
    img: 'waterside',
    footer: 'RTLS Dashboard'

  },
  {
    title: "Landside (ITV)",
    description: "Area and activities on the landside",
    img: 'landsideITV',
    footer: 'RTLS Dashboard'
  },

  {
    title: "Decarb",
    description: "Area and activities on the landside",
    img: 'decarb',
    footer: 'RTLS Dashboard'

  },
];
export default function DashboardPage() {
  const navigate = useNavigate();
  return (
    <div className="px-4 py-4">
      {/* <div className="flex flex-row justify-between">
        <p>Dashboard</p>
        <DatePickerWithRange className="rounded-3xl" />
      </div> */}

      <Tabs defaultValue="overview" className="">
        <TabsList className="inline-flex items-center justify-center h-10 transition-all duration-300 ease-in-out shadow rounded-3xl">
          <TabsTrigger
            className="text-sm tracking-normal rounded-3xl text-[#2c427d] data-[state=active]:bg-[#2c427d] data-[state=active]:text-white"
            value="overview"
          >
            Overview
          </TabsTrigger>

          <TabsTrigger
            className="text-sm tracking-normal rounded-3xl  text-[#2c427d] data-[state=active]:bg-[#2c427d] data-[state=active]:text-white"
            value="map"
          >
            Map
          </TabsTrigger>

          {/* <TabsTrigger
            className="text-sm tracking-normal rounded-3xl"
            value="reports"
            disabled={true}
          >
            Reports
          </TabsTrigger>

          <TabsTrigger
            className="text-sm tracking-normal rounded-3xl"
            value="summary"
            disabled={true}
          >
            Summary
          </TabsTrigger> */}
        </TabsList>

        <TabsContent value="overview">
          <section className="py-5 dark:bg-gray-900">
            <div className="max-w-screen-xl ">
              <div className="flex flex-wrap gap-x-20 gap-y-6 " style={{ maxWidth: '950px' }}>
                {dashboardRegistCatagory.map((item) => {
                  let imgSrc = "";
                  switch (item.img) {
                    case "waterside":
                      imgSrc = waterside;
                      break;
                    case "landsideYC":
                      imgSrc = landsideYC;
                      break;
                    case "landsideITV":
                      imgSrc = landsideITV;
                      break;
                    case "decarb":
                      imgSrc = decarb;
                      break;
                  }

                  return (
                    <div
                      key={item.title}
                      className="flex flex-col items-center w-[370px] cursor-pointer"
                      onClick={() => {
                        if (item.title === "Waterside") {
                          navigate("rtls/waterside");
                        } else if (item.title === "Landside (ITV)") {
                          navigate("rtls/landside");
                        } else if (item.title === "Decarb") {
                          navigate("rtls/decarbonization");
                        }
                      }}
                    >
                      <div className="group w-full rounded-2xl border border-gray-200 dark:border-gray-700 shadow-md hover:shadow-xl transition-all duration-300 bg-white dark:bg-gray-800 overflow-hidden transform hover:scale-[1.02]">
                        <div className="h-56 overflow-hidden">
                          <img
                            src={imgSrc}
                            alt={`${item.title} visual`}
                            className="w-full h-full transition-transform duration-300 group-hover:scale-105"
                          />
                        </div>
                      </div>

                      <div className="mt-3 text-base font-semibold text-center text-gray-800 dark:text-gray-200">
                        {item.title}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

        </TabsContent>
        <TabsContent value="map">
          <Map height={'dashboard'} />
        </TabsContent>
        {/* <TabsContent value="reports"></TabsContent>
        <TabsContent value="summary"></TabsContent> */}
      </Tabs>
    </div>
  );
}

type StatisticsCardProps = {
  title: string;
  icon: JSX.Element;
  value: string;
  valueClassName?: ClassValue;
  onClick?: () => void;
};

function StatisticsCard({
  title,
  icon,
  value,
  valueClassName,
  onClick,
}: StatisticsCardProps) {
  return (
    <>
      <div className="flex flex-col p-4" onClick={onClick}>
        {/* title */}
        <div className="flex flex-row justify-between space-x-2">
          <div className="text-sm font-normal tracking-tight">{title}</div>
          {icon}
        </div>
        {/* value */}
        <div className="pt-4">
          <span className={cn("text-3xl font-normal", valueClassName)}>
            {value}
          </span>
          <p className="text-xs text-muted-foreground">
            +20.1% from last month
          </p>
        </div>
      </div>
    </>
  );
}
