import { memo, useMemo } from "react";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend
);

export const BarChart2 = memo(() => {
  const labels = ['STS01', 'STS02', ];
  const values = [32, 32, 32];
  const edgeValue = 3;
  const axisColor = '#000000';
  const barColor = '#4B9CD3';
  const edgeColor = '#A9A9A9';

  const baseData = useMemo(() =>
    values.map((val, i) => (labels[i] === 'STS04' ? val - edgeValue : val)),
    []
  );

  const edgeData = useMemo(() =>
    labels.map(label => (label === 'STS04' ? edgeValue : 0)),
    []
  );

  const baseColors = labels.map(label =>
    ['STS02', 'STS03', 'STS04', 'STS05'].includes(label) ? '#A9A9A9' : barColor
  );

  const edgeColors = labels.map(label =>
    ['STS03', 'STS04', 'STS05'].includes(label) ? '#A9A9A9' : edgeColor
  );

  const data = {
    labels,
    datasets: [
      {
        label: 'Active',
        data: baseData,
        backgroundColor: baseColors,
        barThickness: 20,
        borderRadius: 5,
        stack: 'combined',
      },
      {
        label: 'Idle',
        data: edgeData,
        backgroundColor: edgeColors,
        barThickness: 25,
        borderRadius: 6,
        stack: 'combined',
      },
    ],
  };

  const options = {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        stacked: true,
        ticks: { display: false },
         grid: { display: false },
        // grid: { color: '#e0e0e0', drawTicks: false },
      },
      y: {
        stacked: true,
        ticks: { color: axisColor },
        // grid: { color: '#f5f5f5' },
        categoryPercentage: 0.6,
        barPercentage: 0.6,
         grid: { display: false },
      },
    },
    plugins: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Crane Active vs Idle Time',
        color: axisColor,
        font: { size: 15, weight: 'bold' },
        padding: {
    top: 0,
    bottom: 17, // Reduce this or set to 0 to move title up
  },
      },
      tooltip: {
        enabled: true,
      },
    },
  };

  return (
 <div className="w-full h-full border-0 border-gray-600 rounded-md pt-2 px-2 shadow-md">
    <Bar data={data} options={options} />
</div>


  );
});
