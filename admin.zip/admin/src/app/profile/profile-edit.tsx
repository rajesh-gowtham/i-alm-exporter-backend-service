import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import useSWR from "swr";
import * as z from "zod";

const timezones = [
  { value: "UTC", label: "Coordinated Universal Time (UTC)" },
  { value: "EST", label: "Eastern Standard Time (EST)" },
  { value: "CST", label: "Central Standard Time (CST)" },
  { value: "MST", label: "Mountain Standard Time (MST)" },
  { value: "PST", label: "Pacific Standard Time (PST)" },
  { value: "IST", label: "Indian Standard Time (IST)" },
  { value: "BST", label: "British Summer Time (BST)" },
];

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email format"),
  mobile: z.number().min(10, "Mobile number is required"),
  timezone: z.string().min(1, "Timezone is required"),
});

export default function ProfileEditForm() {
  const { data, mutate } = useSWR("/api/profile", async () => {
    return { firstName: "", lastName: "", email: "", mobile: "", timezone: "" };
  });

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: data || {},
  });

  const onSubmit = (formData: any) => {
    console.log("Form Data Submitted:", formData);
    mutate(formData, false);
  };

  return (
    <div className="p-6 mx-auto mt-10 ">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="grid grid-cols-1 gap-4 md:grid-cols-2"
      >
        <div className="flex flex-col">
          <Label htmlFor="firstName" className="text-left">
            First Name
          </Label>
          <Input
            id="firstName"
            {...register("firstName")}
            className="mt-1 bg-muted"
          />
          {errors.firstName && (
            <span className="text-sm text-red-500">
              {errors.firstName.message}
            </span>
          )}
        </div>
        <div className="flex flex-col">
          <Label htmlFor="lastName" className="text-left">
            Last Name
          </Label>
          <Input
            id="lastName"
            {...register("lastName")}
            className="mt-1 bg-muted"
          />
          {errors.lastName && (
            <span className="text-sm text-red-500">
              {errors.lastName.message}
            </span>
          )}
        </div>
        <div className="flex flex-col">
          <Label htmlFor="email" className="text-left">
            Email
          </Label>
          <Input
            id="email"
            type="email"
            {...register("email")}
            className="mt-1 bg-muted"
          />
          {errors.email && (
            <span className="text-sm text-red-500">{errors.email.message}</span>
          )}
        </div>
        <div className="flex flex-col">
          <Label htmlFor="mobile" className="text-left">
            Mobile
          </Label>
          <Input
            id="mobile"
            type="tel"
            {...register("mobile")}
            className="mt-1 bg-muted"
          />
          {errors.mobile && (
            <span className="text-sm text-red-500">
              {errors.mobile.message}
            </span>
          )}
        </div>
        <div className="flex flex-col md:col-span-2">
          <Label className="text-left">Timezone</Label>
          <Select onValueChange={(value) => setValue("timezone", value)}>
            <SelectTrigger className="mt-1 bg-muted">
              <SelectValue placeholder="Select your timezone" />
            </SelectTrigger>
            <SelectContent>
              {timezones.map((tz) => (
                <SelectItem key={tz.value} value={tz.value}>
                  {tz.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.timezone && (
            <span className="text-sm text-red-500">
              {errors.timezone.message}
            </span>
          )}
        </div>
        <div className="md:col-span-2">
          <Button type="submit" className="w-full">
            Save Changes
          </Button>
        </div>
      </form>
    </div>
  );
}
