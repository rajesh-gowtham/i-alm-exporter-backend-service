import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProfileEditForm from "./profile-edit";
import ChangePasswordForm from "./change-password";

export default function Profile() {
  return (
    <div className="px-2 m-auto">
      <div style={{ opacity: 1 }}>
        <div className="container max-w-4xl p-4 m-auto sm:p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-normal sm:text-3xl">
                Account Settings
              </h1>
              <p className="text-sm sm:text-base text-muted-foreground">
                Manage your account preferences and settings
              </p>
            </div>
          </div>
          <Tabs defaultValue="account">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="account">Account</TabsTrigger>
              <TabsTrigger value="changepassword">Change Password</TabsTrigger>
            </TabsList>
            <TabsContent value="account">
              <ProfileEditForm />
            </TabsContent>
            <TabsContent value="changepassword">
              <ChangePasswordForm />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
