import { ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Vessel } from "@/lib/models";
import { VesselFields } from "@/lib/models/form-constants/formLabels";
import { vesselSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";

interface VesselFormProps {
  vessel?: Vessel;
  onClose: () => void;
  onSubmit: (data: Vessel) => void;
}

export default function VesselForm({
  vessel,
  onClose,
  onSubmit,
}: VesselFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  console.log("vessel", vessel);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<z.infer<typeof vesselSchema>>({
    resolver: zodResolver(vesselSchema),
    defaultValues: vessel
  });

  const vesselMemo = useMemo(() => vessel, [vessel]);

  useEffect(() => {
    if (vesselMemo) {
      reset({
        ...vesselMemo,
        overallLength: Number(vesselMemo.overallLength),
      });
    }
  }, [vesselMemo, reset]);

  const submitHandler = async (formData: z.infer<typeof vesselSchema>) => {
    console.log("Submit handler called", formData);
    setIsLoading(true); // Set loading to true
    try {
      await onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  // 🔴 New handler to display error toast if required fields are missing
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      onSubmit={(e) => {
        try {
          // handleSubmit(submitHandler)(e);
          handleSubmit(submitHandler, handleError)(e);
        } catch (err) {
          console.error("Submission error", err);
        }
      }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>{VesselFields._Name}</Label>
          {(!vesselSchema.shape.vesselName.isOptional()) && <MandatoryIcon />}
          <Input {...register("vesselName")}
            error={!!errors.vesselName}
            disabled={vessel !== undefined}
            readOnly={vessel !== undefined}
          />
        </div>
        <div>
          <Label>{VesselFields._VesselClass}</Label>
          {(!vesselSchema.shape.vesselClass.isOptional()) && <MandatoryIcon />}
          <Input {...register("vesselClass")}
            error={!!errors.vesselClass}
          />
        </div>
        <div>
          <Label>{VesselFields._LineOperator}</Label>
          {(!vesselSchema.shape.operator.isOptional()) && <MandatoryIcon />}
          <Input {...register("operator")}
            error={!!errors.operator}
          />
        </div>
        <div>
          <Label>{VesselFields._LOAInCm}</Label>
          {(!vesselSchema.shape.overallLength.isOptional()) && <MandatoryIcon />}
          <Input
            type="number"
            {...register("overallLength", { valueAsNumber: true })}
            error={!!errors.overallLength}
          />
        </div>
        <div>
          <Label>{VesselFields._RadioCallSign}</Label>
          {(!vesselSchema.shape.radioCallSign.isOptional()) && <MandatoryIcon />}
          <Input {...register("radioCallSign")}
            error={!!errors.radioCallSign}
          />
        </div>
        <div>
          <Label>{VesselFields._LloydsIdentity}</Label>
          {(!vesselSchema.shape.lloydsIdentity.isOptional()) && <MandatoryIcon />}
          <Input {...register("lloydsIdentity")}
            error={!!errors.lloydsIdentity}
          />
        </div>
      </div>
      <div>
        <Label>{VesselFields._Notes}</Label>
        {(!vesselSchema.shape.notes.isOptional()) && <MandatoryIcon />}
        <Textarea {...register("notes")} />
      </div>
      <FormActions
        isEdit={vessel?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
