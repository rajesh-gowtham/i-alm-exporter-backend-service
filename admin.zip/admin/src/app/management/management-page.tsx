export default function ManagementPage() {
  return <div className="px-2 m-auto">Management</div>;
}
