import SubHeader from "@/components/SubHeader";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { Vessel, VesselVisit } from "@/lib/models";
import {
  addVesselVisit,
  deleteVesselVisit,
  editVesselVisit,
  fetchVessels,
  fetchVesselVisits,
} from "@/lib/services/vessels-services";
import { convertTime } from "@/lib/utils";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useVesselStore from "../store/vesselStore";
import useVesselVisitStore from "../store/VesselVisitStore";
import VesselVisitForm from "./vessel-visit-form";
import { VesselVistLabels } from "@/lib/models/form-constants/formLabels";
import VesselVisitImport from "./vessel-visit-import";

export default function VesselVisitMaster() {
  const [vesselVisits, setVesselVisits] = useState<VesselVisit[]>([]);
  const [paged, setPaged] = useState({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  // const [filteredVesselVisits, setFilteredVesselVisits] = useState<VesselVisit[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [vesselVisitToEdit, setVesselVisitToEdit] = useState<VesselVisit | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [vesselVisitToDelete, setVesselVisitToDelete] = useState<VesselVisit | undefined>(undefined);
  const vesselVistStore = useVesselVisitStore();
  const vesselStore = useVesselStore();

  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const columnsConfig = [
    { key: "visitRef", title: VesselVistLabels._VisitRef, hidden: false },
    { key: "vesselId", title: VesselVistLabels._VesselName, hidden: false },
    // { key: "vesselClass", title: VesselVistLabels._VesselName, hidden: true },
    { key: "inboundVoyage", title: VesselVistLabels._Inbound_Voyage, hidden: false },
    { key: "outboundVoyage", title: VesselVistLabels._Outbound_Voyage, hidden: false },
    { key: "phase", title: VesselVistLabels._Phase, hidden: false },
    { key: "lineOperator", title: VesselVistLabels._LineOperator, hidden: false },
    { key: "eta", title: VesselVistLabels._ETA, hidden: true },
    { key: "etd", title: VesselVistLabels._ETD, hidden: true },
    { key: "ata", title: VesselVistLabels._ATA, hidden: true },
    { key: "atd", title: VesselVistLabels._ATD, hidden: true },
    { key: "startWorkTime", title: VesselVistLabels._StartWorkTime, hidden: true },
    { key: "endWorkTime", title: VesselVistLabels._EndWorkTime, hidden: true },
    { key: "classification", title: VesselVistLabels._Classification, hidden: true },
    { key: "service", title: VesselVistLabels._Service, hidden: true },
  ];

  const columns: ColumnDef<VesselVisit>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => {
      const column: ColumnDef<VesselVisit> = {
        accessorKey: key,
        header: title,
        // header: ({ column }) => SortableHeader({ column, title }),
        // enableSorting: sortable,
        // enableHiding: true,
        size: 200,
        meta: { hidden },
      };
      if (key === "vesselId") {
        column.cell = ({ row }) =>
          vesselStore.vessels.length > 0
            ? vesselStore.vessels.find((vessel) => vessel.id === row.original.vesselId)?.vesselName ?? "N/A" : "N/A";
      }
      if (["vesselClass", "lineOperator"].includes(key)) {
        column.cell = ({ row }) => row.getValue(key) || "N/A";
      }
      if (["eta", "etd", "ata", "atd", "startWorkTime", "endWorkTime"].includes(key)) {
        column.cell = ({ row }) => row.getValue(key) ? convertTime(row.getValue(key)) : '';
      }
      return column;
    }),

    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: { hidden: false },
      size: 150,
      cell: ({ row }: { row: { original: VesselVisit } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];

  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  };

  const fetchVesselsData = async () => {
    try {
      const data = await fetchVessels();
      vesselStore.setVessels(data["items"] as Vessel[]);
    } finally {
      // setLoading(false);
    }
  };
  const fetchData = async () => {
    setOpen(false);
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {

      const data = await fetchVesselVisits(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setVesselVisits(items as VesselVisit[]);
      vesselVistStore.setVesselVisits(items as VesselVisit[]);
    }
    finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  useEffect(() => {
    fetchData();
    fetchVesselsData();
  }, [paged]);

  const handleEdit = (vesselVisit: VesselVisit) => {
    setVesselVisitToEdit(vesselVisit);
    setOpen(true);
  };

  const handleDeleteClick = (vesselVisit: VesselVisit) => {
    setVesselVisitToDelete(vesselVisit);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (vesselVisitToDelete?.id) {
        setLoading(true);
        await deleteVesselVisit(vesselVisitToDelete.id.toString());
        await fetchData();
        mutate("vesselVisit");
        setLoading(false);
        SuccessToaster('', "Visit deleted successfully");
      }
      setConfirmDeleteOpen(false);
    } catch (error) {
      console.error(error);
      ErrorToaster("POW Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
      setLoading(false)
    }
  };

  const handleSubmit = async (
    data: Omit<VesselVisit,
      "id" | "vessel" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt"
    >
  ) => {
    // setLoading(true);
    try {
      if (vesselVisitToEdit?.id) {
        await editVesselVisit(vesselVisitToEdit.id.toString(), data);
        SuccessToaster('', "Vessel visit updated successfully");
      } else {
        // const isvesselVisitExists = vesselVisits?.some(item => (item.visitRef?.toLowerCase()?.trim() === data.visitRef?.toLowerCase().trim()));
        // console.log(isvesselVisitExists);
        // if (isvesselVisitExists) {
        //   ErrorToaster('', "Vessel Visit already exists")
        //   setLoading(false);
        //   return;
        // }
        await addVesselVisit(data);
        SuccessToaster('', "Vessel visit created successfully");
      }
      console.log("called after ");
      setOpen(false);
      setVesselVisitToEdit(undefined);
      await fetchData();
      mutate("vesselVisit");
      setLoading(false);
    } catch (error) {
      console.error(error);
      ErrorToaster("Vessel Visit Creation Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  };
  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredVesselVisits(vesselVisits);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = vesselVisits.filter(
  //       (vesselVisit) =>
  //         vesselVisit.visitRef.toLowerCase().includes(lowerCasedQuery) ||
  //         // vesselVisit.vesselClass.toLowerCase().includes(lowerCasedQuery) ||
  //         vesselVisit.phase.toLowerCase().includes(lowerCasedQuery) ||
  //         vesselVisit.lineOperator.toLowerCase().includes(lowerCasedQuery)
  //     );
  //     const Start = paged.pageIndex * paged.pageSize;
  //     const End = Start + paged.pageSize;
  //     setFilteredVesselVisits(filtered.slice(Start, End));
  //   }
  // }, [searchQuery, vesselVisits]);

  // Import rework
  const openCloseImport = (type: string) => {
    console.log(type);

    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false);
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?
        <div>
          <SubHeader
            placeholder="Visit Ref/Name..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Configuration + privateRoute._Vesselvisit_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setVesselVisitToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={vesselVisits || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={vesselVisitToDelete?.visitRef || ""}
            />
          }

          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setVesselVisitToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {vesselVisitToEdit ? "Edit Vessel Visit" : "Add Vessel Visit"}
              </DialogTitle>
              <VesselVisitForm
                vesselVisit={vesselVisitToEdit}
                onClose={() => {
                  setOpen(false);
                  setVesselVisitToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog>
        </div>
        :
        <VesselVisitImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
