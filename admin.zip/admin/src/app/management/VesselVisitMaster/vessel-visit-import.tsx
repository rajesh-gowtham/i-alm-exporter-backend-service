import FileImportManipulate from "@/components/FileImportManipulate";
import {
  Dialog,
  DialogContent
} from "@/components/ui/dialog";
import { ErrorToaster, FileImport, SuccessToaster } from "@/components/UtilComp";
import { VesselVistLabels } from "@/lib/models/form-constants/formLabels";
import { FileImportSchema, VesselVisitImportSchema } from "@/lib/schemas";
import { addVesselVisitInBatch } from "@/lib/services/vessels-services";
import { toApiDateFormat } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router";
import * as XLSX from "xlsx";
import { z } from "zod";
import useVesselStore from "../store/vesselStore";

const requiredBackendFields = ["visitRef", "vesselId", "phase", "inboundVoyage", "outboundVoyage", "lineOperator", "eta", "etd", "startWorkTime", "endWorkTime", "classification", "service"];
const headerMap: Record<typeof VesselVistLabels[keyof typeof VesselVistLabels], string> = {
  [VesselVistLabels._VisitRef]: "visitRef",
  [VesselVistLabels._VesselName]: "vesselId",
  [VesselVistLabels._Phase]: "phase",
  [VesselVistLabels._Inbound_Voyage]: "inboundVoyage",
  [VesselVistLabels._Outbound_Voyage]: "outboundVoyage",
  [VesselVistLabels._LineOperator]: "lineOperator",
  [VesselVistLabels._ETA]: "eta",
  [VesselVistLabels._ETD]: "etd",
  [VesselVistLabels._ATA]: "ata",
  [VesselVistLabels._ATD]: "atd",
  [VesselVistLabels._StartWorkTime]: "startWorkTime",
  [VesselVistLabels._EndWorkTime]: "endWorkTime",
  [VesselVistLabels._Classification]: "classification",
  [VesselVistLabels._Service]: "service"
};

type VesselVisitRecord = z.infer<typeof VesselVisitImportSchema>;
type FormData = z.infer<typeof FileImportSchema>;

interface VesselVisitImportProps {
  handleImportError: (arg: any[]) => void;
  errorList: any[];
  setColumns: (arg: any) => void;
  setTableData: (arg: any) => void;
  columns: any[];
  tableData: any[];
  openCloseImport: (arg: string) => void;
  setIsImportError: (arg: boolean) => void;
  // openCloseImport: () => void;
}
export default function VesselVisitImport({ handleImportError, errorList, setColumns, setTableData, columns, tableData, openCloseImport, setIsImportError }: VesselVisitImportProps) {

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<VesselVisitRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(errorList.length > 0);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);
  // const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  // const [columns, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const vesselStore = useVesselStore();
  const navigate = useNavigate();

  const batchInsert = async (records: VesselVisitRecord[]) => {
    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;
      console.log("records ", records);
      let isValidRecod = true;
      for (let i = 0; i < records.length; i += batchSize) {

        let batch = records.slice(i, i + batchSize);
        console.log(" batch ", batch);
        batch = batch.map((item) => {
          const vesselNameFromExcel = item["vesselId"]?.toLowerCase();
          const matchedVessel = vesselStore.vessels.find(
            (vessel) => vessel.vesselName?.toLowerCase() === vesselNameFromExcel
          );
          if (!matchedVessel) {
            isValidRecod = false;
          }
          return {
            ...item,
            visitRef: item.visitRef,
            vesselId: matchedVessel ? matchedVessel.id : parseInt(item.vesselId),
            eta: toApiDateFormat(new Date(item.eta)),
            etd: toApiDateFormat(new Date(item.etd)),
            ata: toApiDateFormat(new Date(item.ata ?? "")),
            atd: toApiDateFormat(new Date(item.atd ?? "")),
            startWorkTime: item.startWorkTime ? toApiDateFormat(new Date(item.startWorkTime)) : null,
            endWorkTime: item.endWorkTime ? toApiDateFormat(new Date(item.endWorkTime)) : null,
          };
        });
        console.log("batch ", batch);
        const updatedData = batch.map(({ ...rest }) => rest);
        await addVesselVisitInBatch(updatedData);
        const progress = Math.min(100, ((i + batch.length) / totalRecords) * 100);
        setImportProgress(progress);
        await new Promise((r) => setTimeout(r, 100));
      }

      SuccessToaster("Import Completed", `${totalRecords} vessel visits imported successfully`);
      // navigate(privateRoute._Configuration + privateRoute._Vesselvisit);
      openCloseImport("CLEAR-SUCCESS")
      setIsImportError(false)

    } catch (error) {
      console.error(error);
      setShowConfirmModal(true);
      ErrorToaster("Import Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      // setImportProgress(0);
      setBatchProcessing(false);
      // setShowConfirmModal(false);
      reset();
    }
  };

  const updateData = (rowIndex: number, columnId: string, value: any) => {
    setTableData(prev =>
      prev.map((row, index) => {
        if (index === rowIndex) {
          return {
            ...row,
            [columnId]: value,
          };
        }
        return row;
      })
    );
  };

  useEffect(() => {
    console.log("tableData", tableData);
    if (tableData.length === 0) return;

    const validationResults = tableData.map((itemRow, index) => {
      const row = { ...itemRow }; // Avoid mutating original state row
      const rowErrors: z.ZodIssue[] = [];

      console.log(row["vesselId"], typeof row["vesselId"] === "string");
      if (typeof row["vesselId"] === "string") {
        const vesselName = row["vesselId"].toLowerCase();
        const findItem = vesselStore.vessels.find(
          (item) => item.vesselName?.toLowerCase().trim() === vesselName.toLowerCase().trim()
        );
        console.log("findItem ", findItem);
        if (findItem?.id) {
          // row["vesselId"] = findItem.id + "";
        } else {
          rowErrors.push({
            code: "custom",
            path: ["vesselId"],
            message: `Vessel "${row["vesselId"]}" not found.`,
          });
        }
      }
      const result = VesselVisitImportSchema.safeParse(row);
      const allErrors = result.success ? rowErrors : [...rowErrors, ...result.error.issues];
      // vesselId resolution from vesselName
      console.log(" result ", result.success);
      console.log(allErrors);
      return {
        row: index + 2,
        valid: allErrors.length === 0,
        errors: allErrors,
        data: allErrors.length === 0 ? result.data : null,
      };
    });

    console.log(" validationResults ", validationResults);
    const valid = validationResults.filter((r) => r.valid).map((r) => r.data) as VesselVisitRecord[];

    const errors = validationResults.filter((r) => !r.valid).map((r) => ({
      row: r.row,
      issues: r.errors,
      original: tableData[r.row - 2],
    }));

    setValidRecords(valid);
    setValidationErrors(errors);
  }, [tableData, vesselStore.vessels]);

  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const [headerRow, ...rows] = jsonData;
        const headers = headerRow as string[];

        const errors: string[] = [];

        for (const readableHeader in headerMap) {
          const backendKey = headerMap[readableHeader];
          if (!headers.includes(readableHeader)) {
            if (requiredBackendFields.includes(backendKey)) {
              errors.push(`Missing required column: ${readableHeader}`);
            }
          }
        }

        const unknownHeaders = headers.filter(h => !headerMap[h]);
        if (unknownHeaders.length > 0) {
          unknownHeaders.forEach(h => errors.push(`Unknown column found: ${h}`));
        }

        if (errors.length > 0) {
          ErrorToaster("File validation failed:\n" + errors.join("\n"));
        }

        const extractedData = rows.map((row) =>
          headers.reduce((obj, readableHeader, idx) => {
            const backendKey = headerMap[readableHeader];
            if (backendKey) {
              obj[backendKey] = row[idx] ?? '';
            }
            return obj;
          }, {} as Record<string, any>)
        );

        let errorCount = 0;
        const validRowsToInsert = [];
        const validatedRows = extractedData.map((itemRow, index) => {
          const row = itemRow;
          const result = VesselVisitImportSchema.safeParse(row);
          if (result.success) {
            if (typeof row["vesselId"] === "string") {
              const vesselNameFromExcel = row["vesselId"].toLowerCase();
              const matchedVessel = vesselStore.vessels.find(
                (item) => item.vesselName?.toLowerCase() === vesselNameFromExcel
              );
              if (matchedVessel) {
                validRowsToInsert.push(result.data);
                // row["vesselId"] = matchedVessel.id;
                return { ...row, __rowValid: true };
              } else {
                errorCount += 1;
                return {
                  ...row,
                  __rowValid: false,
                  __rowErrors: { vesselId: [`Vessel "${row["vesselId"]}" not found.`] },
                  __rowIndex: index + 2,
                };
              }
            }
            return { ...row, __rowValid: true };
          } else {
            errorCount += 1;
            return {
              ...row,
              __rowValid: false,
              __rowErrors: result.error.flatten().fieldErrors,
              __rowIndex: index + 2,
            };
          }
        });

        const newColumns = Object.keys(headerMap).map((readableHeader) => ({
          Header: readableHeader,
          accessor: headerMap[readableHeader],
        }));

        setColumns(newColumns);
        setTableData(validatedRows);
        // setShowConfirmModal(true);
        console.log("validatedRows", errorCount, validatedRows);
        if (errorCount === 0) {
          // const dataInset = validatedRows as VesselRecord[]
          batchInsert(validRowsToInsert as VesselVisitRecord[])
        } else {
          handleImportError(validatedRows);
        }
      } catch (error) {
        console.error(error);
        ErrorToaster("Failed to process file: " + (error as any).message);
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };


  // const processExcelFile = (file: File) => {
  //   const reader = new FileReader();
  //   reader.onload = (e) => {
  //     const binary = e.target?.result;
  //     const workbook = XLSX.read(binary, { type: "binary" });
  //     const sheet = workbook.Sheets[workbook.SheetNames[0]];

  //     const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
  //     const [headerRow, ...rows] = jsonData;
  //     const headers = headerRow as string[];

  //     const newColumns = headers.map((header) => ({
  //       Header: header,
  //       accessor: header,
  //     }));
  //     console.log(" newColumns ", newColumns);
  //     setColumns(newColumns);
  //     const rowsItems = rows as string[];
  //     console.log(" rows ", rows, rowsItems, headers);
  //     const newData = rowsItems.map((row) =>
  //       headers.reduce((obj, header, idx) => {
  //         if (header === "vesselId") {
  //           console.log(" row[idx] ", row[idx], vesselStore.vessels);
  //           const findData = vesselStore.vessels.find((item) => item.vesselName?.toLowerCase() === String(row[idx] ?? '').toLowerCase());
  //           obj[header] = findData ? findData.id : '';
  //         } else {
  //           obj[header] = row[idx] ?? '';
  //         }
  //         return obj;
  //       }, {} as Record<string, any>)
  //     );
  //     console.log("newData ", newData);
  //     setTableData(newData);
  //     setShowConfirmModal(true);
  //     setUploading(false);
  //   };
  //   reader.readAsBinaryString(file);
  // };

  // const renderTable = () => (
  //   <div className="overflow-auto">
  //     <table className="w-full border-collapse">
  //       <thead>
  //         <tr>
  //           {columns.map((column) => (
  //             <th
  //               key={column.accessor}
  //               className="sticky top-0 p-2 text-left border border-gray-200 bg-muted"
  //             >
  //               {column.Header}
  //               {/* {numericFields.includes(column.accessor) && (
  //                 <span className="ml-1 text-xs text-gray-500">(number)</span>
  //               )} */}
  //             </th>
  //           ))}
  //         </tr>
  //       </thead>
  //       <tbody>
  //         {tableData.map((row, rowIndex) => {
  //           const isInvalid = validationErrors.some(e => e.row === rowIndex + 2);
  //           return (
  //             <tr
  //               key={rowIndex}
  //               className={isInvalid ? 'bg-muted hover:bg-red-100' : ''}
  //             >
  //               {columns.map((column) => {
  //                 // const isNumeric = numericFields.includes(column.accessor);
  //                 return (
  //                   <td key={column.accessor} className="border border-gray-200">
  //                     <EditableCell
  //                       value={row[column.accessor]}
  //                       row={{ index: rowIndex }}
  //                       column={{ id: column.accessor }}
  //                       isNumeric={false}
  //                       updateData={updateData}
  //                     />
  //                   </td>
  //                 );
  //               })}
  //             </tr>
  //           );
  //         })}
  //       </tbody>
  //     </table>
  //   </div>
  // );

  return (
    <div>
      <FileImport
        errors={errors}
        handleSubmit={handleSubmit}
        processExcelFile={processExcelFile}
        register={register}
        setUploading={setUploading}
        uploading={uploading}
        backToParent={openCloseImport}
        // filename="vesselvisitmaster.xlsx"
        filename="vesselvisitmaster.xlsx"

      />

      <Dialog
        open={showConfirmModal}
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
         <DialogContent className="max-w-[95vw] h-[85vh] overflow-auto flex flex-col p-0">
          <FileImportManipulate
            columns={columns}
            tableData={tableData}
            updateData={updateData}
            validationErrors={validationErrors}
            validRecords={validRecords}
            batchProcessing={batchProcessing}
            setShowConfirmModal={setShowConfirmModal}
            importProgress={importProgress}
            batchInsert={batchInsert}
          />
        </DialogContent>
      </Dialog>
    </div >
  );
}