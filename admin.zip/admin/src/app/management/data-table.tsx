import { useMemo, useState, useEffect } from "react";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import {
  ColumnDef,
  flexRender,
  SortingState,
  VisibilityState,
  ColumnFiltersState,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  useReactTable,
  RowData,
  PaginationState,
} from "@tanstack/react-table";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ArrowUpDown } from "lucide-react";
import React from "react";
import { WorkAssinPOWUI } from "./WorkAssignments/workassignment-components";
import { WorkAssignmentPOW } from "@/lib/models";
import { LiaAngleLeftSolid, LiaAngleRightSolid } from "react-icons/lia";
import { BadgeCheck } from "lucide-react";


interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  scrollAreaClassName?: string | null;
  totalRecords: number;
  pagination: PaginationState;
  onPaginationChange: (pagination: PaginationState) => void;
  onPOWItemOnClick?: (data: WorkAssignmentPOW, callBy: string) => void;
  isRowsHidden?: boolean;
}

export function DataTable<TData extends { pairContainer?: any }, TValue>({
  columns,
  data,
  scrollAreaClassName,
  totalRecords,
  pagination,
  onPaginationChange,
  onPOWItemOnClick,
  isRowsHidden,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  // const [pageInput, setPageInput] = useState("1");

  useEffect(() => {
    onPaginationChange?.(pagination);
    // setPageInput(String(pagination.pageIndex + 1));
  }, [pagination, onPaginationChange]);

  const initialVisibility = columns.reduce((acc, column) => {
    if (column.meta?.hidden && (column as any)?.accessorKey) {
      acc[(column as any).accessorKey as string] = false;
    }
    return acc;
  }, {} as VisibilityState);

  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>(() => {
    const saved = localStorage.getItem("tableColumnVisibility");
    return saved ? JSON.parse(saved) : initialVisibility;
  });

  const pageCount = useMemo(
    () => Math.ceil(totalRecords / pagination.pageSize),
    [totalRecords, pagination.pageSize]
  );

  const table = useReactTable({
    data,
    columns,
    manualPagination: true,
    pageCount,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      pagination,
    },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    onPaginationChange: (updaterOrValue) => {
      onPaginationChange(
        typeof updaterOrValue === "function" ? updaterOrValue(pagination) : updaterOrValue
      );
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  const generatePageSizeOptions = (totalRecords: number): number[] => {
    const allOptions = [10, 25, 50, 100];
    return allOptions.filter((size) => size <= totalRecords || size === allOptions[0]);
  };
  // const startRecord = totalRecords === 0 ? 0 : pagination.pageIndex * pagination.pageSize + 1;
  // const endRecord = Math.min(startRecord + pagination.pageSize - 1, totalRecords);
  // console.log(pagination)
  console.log(pagination.pageIndex)
  const dividerRecord = Math.floor(totalRecords / 5)
  const startRecord = (isRowsHidden && pagination.pageIndex > 0) ? 1 : totalRecords === 0 ? 0 : pagination.pageIndex * pagination.pageSize + 1;
  const endRecord = (isRowsHidden && pagination.pageIndex > 0) ? dividerRecord === pagination.pageIndex ? totalRecords : (pagination.pageIndex * pagination.pageSize + 5) : Math.min(startRecord + pagination.pageSize - 1, totalRecords);
  const pageSizeOptions = generatePageSizeOptions(totalRecords);
  return (
    <div className="w-full px-4 ">
      <div>
        <ScrollArea
          type="always"
          className={cn("rounded-md border", scrollAreaClassName)}
        >
          <Table className="w-full ">
            {/* <TableHeader className="sticky top-0 bg-[#2C417F] text-white">  */}
            <TableHeader className="sticky top-0 bg-secondary">
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id} className="transition-colors">
                  {headerGroup.headers.map((header) => (
                    <TableHead key={header.id} className="text-[#2c427d]">
                      {header.isPlaceholder
                        ? null
                        : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  ))}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody className={`${isRowsHidden ? "overflow-auto" : "overflow-hidden"} border-y border-black/10`}
            >
              {table.getRowModel().rows?.length ? (() => {
                let skipNext = false;

                return table.getRowModel().rows.map((row, index, allRows) => {
                  if (skipNext) {
                    skipNext = false;
                    return null;
                  }

                  const current = row.original;
                  const nextRow = allRows[index + 1];
                  const currentHasPair = !!current?.pairContainer?.trim();
                  const nextHasPair = !!nextRow?.original?.pairContainer?.trim();
                  const isPair = currentHasPair && nextHasPair;
                  if (isPair) skipNext = true;
                  return (
                    <React.Fragment key={row.id}>
                      <TableRow
                        data-state={row.getIsSelected() && "selected"}
                        className="h-10 transition-colors duration-150 border-b border-gray-100"
                      >
                        {row.getVisibleCells().map((cell) => {
                          const isSequenceCell = cell.column.columnDef.accessorKey === "sequence";

                          if (isSequenceCell && isPair) {
                            const nextSequenceCell = nextRow.getVisibleCells().find(
                              (nextCell) => nextCell.column.columnDef.accessorKey === "sequence"
                            );
                            return (
                              <TableCell
                                key={cell.id}
                                rowSpan={2}
                                className="px-2 py-2 text-center align-middle"
                                style={{ minWidth: "80px" }}
                              >
                                <div className="flex flex-col items-center justify-center h-full space-y-1">
                                  <div className="flex items-center justify-center px-3 py-1 text-sm font-medium text-gray-800 bg-gray-200 rounded-full shadow-sm">
                                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                  </div>
                                  <div className="w-[2px] h-5 bg-gray-300 rounded-full" />
                                  {nextSequenceCell && (
                                    <div className="flex items-center justify-center px-3 py-1 text-sm font-medium text-gray-800 bg-gray-200 rounded-full shadow-sm">
                                      {flexRender(nextSequenceCell.column.columnDef.cell, nextSequenceCell.getContext())}
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                            );
                          }

                          if (isSequenceCell && isPair) {
                            return null;
                          }

                          return (
                            <TableCell
                              key={cell.id}
                              className={`text-sm text-gray-800 align-middle ${isSequenceCell ? "text-center" : "text-start"}`}
                            >
                              <div
                                className={
                                  isSequenceCell
                                    ? "px-3 py-1 text-sm font-medium text-gray-800 flex justify-center items-center"
                                    : "flex items-center h-full w-full overflow-hidden text-ellipsis whitespace-nowrap"
                                }
                              >
                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                              </div>
                            </TableCell>
                          );
                        })}
                      </TableRow>

                      {isPair && (
                        <TableRow
                          key={nextRow.id}
                          data-state={nextRow.getIsSelected() && "selected"}
                          className="h-10 transition-colors duration-150 border-b border-gray-100"
                        >
                          {nextRow.getVisibleCells().map((cell) => {
                            if (cell.column.columnDef.accessorKey === "sequence") return null;

                            return (
                              <TableCell
                                key={cell.id}
                                className="text-sm text-gray-800 align-middle text-start"
                              >
                                <div className="flex items-start w-full h-full overflow-hidden text-ellipsis whitespace-nowrap">
                                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                </div>
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      )}

                      {row.getIsExpanded() && (
                        <TableRow className="bg-violet-50">
                          <TableCell colSpan={columns.length}>
                            <div className="space-y-1 rounded-md">
                              {Array.isArray(row.original?.pointOfWork) && row.original.pointOfWork.length > 0 ? (
                                <WorkAssinPOWUI
                                  onPOWItemOnClick={onPOWItemOnClick}
                                  powList={row.original.pointOfWork}
                                />
                              ) : (
                                <div className="flex items-center justify-center text-center text-gray-500">
                                  <span>No POW Data.</span>
                                </div>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </React.Fragment>
                  );
                })
              })() : (
                <TableRow>
                  <TableCell colSpan={table.getAllColumns().length} className="h-6 text-center">
                    No data.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      {/* Pagination & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 mt-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">Columns</Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent style={{ maxHeight: "300px", overflowY: "auto" }} align="start">
            {table
              .getAllColumns()
              .filter((col) => col.getCanHide())
              .map((col) => (
                <DropdownMenuCheckboxItem
                  key={col.id}
                  checked={col.getIsVisible()}
                  onCheckedChange={(value) => col.toggleVisibility(!!value)}
                >
                  {typeof col.columnDef === "string" ? String(col.columnDef.header) : col.columnDef.accessorKey === "containerId" ? "Conatiner ID" : String(col.columnDef.header)}
                </DropdownMenuCheckboxItem>
              ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="flex flex-wrap items-center gap-2">
          {!isRowsHidden && (
            <div className="flex items-center gap-2">
              <label htmlFor="rowsPerPage" className="text-sm text-muted-foreground">
                Rows per page:
              </label>
              <select
                id="rowsPerPage"
                value={pagination.pageSize}
                onChange={(e) =>
                  onPaginationChange({
                    ...pagination,
                    pageSize: Number(e.target.value),
                    pageIndex: 0,
                  })
                }
                className="px-1 py-1 text-sm border rounded"
              >
                {pageSizeOptions.map((size) => (
                  <option key={size} value={size}>
                    {size}
                  </option>
                ))}
              </select>
            </div>

          )}
          <div className="flex items-center space-x-1.5 rounded border border-gray-300 px-2">
            <span className="flex items-center space-x-1">
              <button
                className={`${table.getCanPreviousPage() ? " text-black" : "text-gray-300"} cursor-pointer`}
                onClick={() => table.previousPage()}
                disabled={!table.getCanPreviousPage()}
              >
                <LiaAngleLeftSolid size={18} />
              </button>
              <span className="px-3 py-1 text-sm border-gray-300 border-x">
                <span className="font-semibold">{`${startRecord} - ${endRecord}`}</span>
                <span>{` of ${totalRecords}`}</span>
              </span>
              <button
                className={`${table.getCanNextPage() ? " text-black" : "text-gray-300"} cursor-pointer`}
                onClick={() => table.nextPage()}
                disabled={!table.getCanNextPage()}
              >
                <LiaAngleRightSolid size={18} />
              </button>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export const SortableHeader = ({
  column,
  title,
}: {
  column: any;
  title: string;
}) => (
  <Button
    variant="ghost"
    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
    className="px-1"
  >
    {title}
    <ArrowUpDown className="w-4 h-4 ml-1" />
  </Button>
);

declare module "@tanstack/react-table" {
  interface ColumnMeta<TData extends RowData, TValue> {
    hidden?: boolean;
  }
}   
