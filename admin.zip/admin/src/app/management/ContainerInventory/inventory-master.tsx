/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import SubHeader from "@/components/SubHeader";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster } from "@/components/UtilComp";
import { ContainerDetail, ContainerHistory, VesselInventory } from "@/lib/models";
import { ContainerInventoryLabels, VesselInventoryLabels } from "@/lib/models/form-constants/formLabels";
import { clearConatinerInventoryByIdsAPICALL, fetchConatinerDetailsAPICALL, fetchContainerInventoryAPICALL, fetchVesselInventoryAPICALL } from "@/lib/services/inventory-service";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useMemo, useState } from "react";
import { DataTable } from "../data-table";
import { ConatinerDrawer, HatchDrawer } from "./inventory-drawer";

export default function InventoryMaster() {
    const [isLoading, setIsLoading] = useState(false);
    const [isDrawerOpen, setDrawerOpen] = useState(false);
    const [isHatchDrawerOpen, setIsHatchDrawerOpen] = useState(false);
    const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
    const [selectedContainerMeta, setSelectedContainerMeta] = useState<ContainerHistory>({} as ContainerHistory);
    const [selectedVesselMeta, setSelectedVesselMeta] = useState<VesselInventory>({} as VesselInventory);
    const [containerDetail, setContainerDetail] = useState<ContainerDetail>({} as ContainerDetail);
    const [conatinerHistory, setConatinerHistory] = useState<ContainerHistory[]>([]);
    const [totalRecord, setTotalRecord] = useState(0);
    const [vesselHistory, setVesselHistory] = useState<VesselInventory[]>([]);
    const [vesselTotalRecord, setVesselTotalRecord] = useState(0);
    const [paged, setPaged] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
        search: ""
    });
    const [vesselPaged, setVesselPaged] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
        search: ""
    });
    const [activeTab, setActiveTab] = useState<"container" | "vessel">("container");

    const tabClasses = (tab: string) =>
        `rounded-none border-b-2 px-4 py-2 text-md font-semibold ${activeTab === tab
            ? "border-blue-500 text-blue-600"
            : "border-transparent text-gray-500 hover:text-blue-500"
        }`

    const conatainerColumnsConfig = [
        { key: "containerId", title: ContainerInventoryLabels._ContainerId, hidden: false },
        // { key: "isoCode", title: ContainerInventoryLabels._ISO_Code, hidden: false },
        // { key: "block", title: ContainerInventoryLabels._Block, hidden: false },
        { key: "location", title: ContainerInventoryLabels._Location, hidden: false },
    ];

    const [selectedRowIds, setSelectedRowIds] = useState<Record<string, boolean>>({});

    const toggleAll = (isChecked: boolean, data: ContainerHistory[]) => {
        const updated = data.reduce((acc, _, index) => {
            acc[index] = isChecked;
            return acc;
        }, {} as Record<string, boolean>);
        setSelectedRowIds(updated);
    };

    const conatinerColumns: ColumnDef<ContainerHistory>[] = [
        ...conatainerColumnsConfig.map(({ key, title, hidden }) => {
            const column: ColumnDef<ContainerHistory> = {
                accessorKey: key,
                header: key === "containerId" ? () => (
                    <div className="flex items-center gap-2">
                        <input
                            type="checkbox"
                            className="w-4 h-4"
                            checked={
                                Object.keys(selectedRowIds).length > 0 &&
                                Object.keys(selectedRowIds).length === (paged.pageSize >= totalRecord ? totalRecord : paged.pageSize) &&
                                Object.values(selectedRowIds).every(Boolean)
                            }
                            onChange={(e) => toggleAll(e.target.checked, conatinerHistory)}
                        />
                        <span>{title}</span>
                    </div>
                ) : title,
                size: 200,
                meta: { hidden: hidden },
            };
            if (key === "containerId") {
                column.cell = ({ row }) => (
                    <div className="flex items-center gap-2">
                        <input
                            type="checkbox"
                            className="w-4 h-4"
                            checked={!!selectedRowIds[row.index]}
                            onChange={(e) => {
                                const isChecked = e.target.checked;
                                setSelectedRowIds((prev) => ({
                                    ...prev,
                                    [row.index]: isChecked,
                                }));
                            }}
                        />
                        <span className="text-blue-700 cursor-pointer hover:underline" onClick={() => handleRowClick(row.original)}>{row.original.containerId}</span>
                    </div>
                );
            }

            return column;
        }),
        // {
        //     accessorKey: "actions",
        //     header: "Action",
        //     enableSorting: false,
        //     enableHiding: false,
        //     meta: { hidden: false },
        //     size: 150,
        //     cell: ({ row }: { row: { original: ContainerHistory } }) => (
        //         <div onClick={() => handleRowClick(row.original)}>
        //             clear
        //         </div>
        //     ),
        // },
    ];
    const selectedRows = useMemo(() => conatinerHistory.filter((_, index) => selectedRowIds[index]),
        [conatinerHistory, selectedRowIds]
    );
    console.log("selectedRows", selectedRows, selectedRowIds);

    const vesselColumnsConfig = [
        { key: "vesselName", title: VesselInventoryLabels._VesselName, hidden: false },
        { key: "visitRef", title: VesselInventoryLabels._VisitRef, hidden: false },
        { key: "vesselClass", title: VesselInventoryLabels._VesselClass, hidden: false },
        { key: "lineOperator", title: VesselInventoryLabels._LineOperator, hidden: false },
    ];

    const vesselColumns: ColumnDef<VesselInventory>[] = [
        ...vesselColumnsConfig.map(({ key, title, hidden }) => {
            const column: ColumnDef<VesselInventory> = {
                accessorKey: key,
                header: title,
                size: 200,
                meta: { hidden },
            };

            if (key === "vesselName") {
                column.cell = ({ row }) => (
                    <span className="text-blue-700 cursor-pointer hover:underline" onClick={() => handleVesselRowClick(row.original)}>{row.original.vesselName}</span>
                );
            }

            return column;
        }),

    ];
    const handleRowClick = async (row: ContainerHistory) => {
        await fetchSelContainerDetail(row.id)
        setSelectedContainerMeta(row);
        setDrawerOpen(true);
    }
    const handleVesselRowClick = async (row: VesselInventory) => {
        // await fetchSelContainerDetail(row.id)
        setSelectedVesselMeta(row);
        setIsHatchDrawerOpen(true);
    }
    const fetchContainerData = async () => {
        setIsLoading(true);
        try {
            const skip = paged.pageIndex * paged.pageSize;
            const take = paged.pageSize;
            const search = paged.search;
            const data = await fetchContainerInventoryAPICALL(skip, take, search);
            setTotalRecord(data["totalCount"] as number);
            setConatinerHistory(data["items"])
            setIsLoading(false);
        } catch (error) {
            console.error(error)
            setIsLoading(false);
        }
        finally {
            setIsLoading(false);
        }
    };
    const fetchVesselData = async () => {
        setIsLoading(true);
        try {
            const skip = vesselPaged.pageIndex * vesselPaged.pageSize;
            const take = vesselPaged.pageSize;
            const search = vesselPaged.search;
            const data = await fetchVesselInventoryAPICALL(skip, take, search);
            setVesselTotalRecord(data["totalCount"] as number);
            setVesselHistory(data["items"])
            setIsLoading(false);
        } catch (error) {
            console.error(error)
            setIsLoading(false);
        }
        finally {
            setIsLoading(false);
        }
    };
    const fetchSelContainerDetail = async (id: number) => {
        // setIsLoading(true);
        try {
            const data = await fetchConatinerDetailsAPICALL(id);
            setContainerDetail(data);
            // setIsLoading(false);
        } catch (error) {
            console.error(error)
            // setIsLoading(false);
        }
        finally {
            // setIsLoading(false);
        }
    };


    const handleSearch = async (searchText: string,) => {
        if (activeTab === "container") {
            setPaged((prev => ({
                ...prev,
                search: searchText
            })))
        } else {
            setVesselPaged((prev => ({
                ...prev,
                search: searchText
            })))
        }
    }
    useEffect(() => {
        fetchContainerData();
    }, []);

    useEffect(() => {
        if (paged.search.length === 0 || paged.search.length > 2)
            fetchContainerData();
    }, [paged]);

    useEffect(() => {
        if (vesselPaged.search.length === 0 || vesselPaged.search.length > 2)
            fetchVesselData();
    }, [vesselPaged]);

    const handlePaginationChange = (newPagination: PaginationState) => {
        if (activeTab === "container") {
            setPaged(newPagination);
        } else {
            setVesselPaged(newPagination);
        }
    }

    const toggleTab = async (tab: "container" | "vessel") => {
        setActiveTab(tab);
        if (tab === "vessel") {
            await fetchVesselData()
        }
    };

    const deleteOpenConfirm = () => {
        setConfirmDeleteOpen(true)
    }
    const confirmDelete = async () => {
        try {
            setIsLoading(true);
            const reqIds = selectedRows.map(item => item.id);
            console.log(" reqIds ", reqIds);
            await clearConatinerInventoryByIdsAPICALL({ ids: reqIds });
            await fetchContainerData();
            setIsLoading(false);
            SuccessToaster('', selectedRows.length + "records deleted successfully!");
            setConfirmDeleteOpen(false);
            setSelectedRowIds({});
        } catch (error) {
            console.error(error);
            setIsLoading(false)
            ErrorToaster("Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
        } finally {
            setIsLoading(false)
        }
    };
    return (
        <div>
            <div>
                <SubHeader
                    placeholder={activeTab === "container" ? "Container..." : "Visit Ref."}
                    searchValue={activeTab === "container" ? paged.search : vesselPaged.search}
                    onSearchChange={handleSearch}
                    addButtonLabel="+"
                    isAddBtnDisabled={true}
                    isImportBtnDisabled={true}
                />
                <div className="flex justify-between px-4 pb-2 space-x-2 ">
                    <div className="flex font-bold border-b border-gray-200">
                        <Button
                            variant="ghost"
                            className={tabClasses("container")}
                            onClick={() => toggleTab("container")}
                        >
                            Container
                        </Button>
                        <Button
                            variant="ghost"
                            className={tabClasses("vessel")}
                            onClick={() => toggleTab("vessel")}
                        >
                            Vessel
                        </Button>
                    </div>
                    <div>
                        {selectedRows.length > 0 && activeTab === "container" &&
                            <Button
                                variant="destructive"
                                onClick={deleteOpenConfirm}
                            >
                                Delete ({selectedRows.length})
                            </Button>
                        }
                    </div>
                </div>
                {isLoading ? (
                    <div className="space-y-2">
                        {[...Array(5)].map((_, i) => (
                            <Skeleton key={i} className="w-full h-8" />
                        ))}
                    </div>
                ) : (
                    activeTab === "container" ?
                        <DataTable
                            columns={conatinerColumns}
                            data={conatinerHistory || []}
                            totalRecords={totalRecord}
                            pagination={paged}
                            onPaginationChange={handlePaginationChange}
                        />
                        :
                        <DataTable
                            columns={vesselColumns}
                            data={vesselHistory || []}
                            totalRecords={vesselTotalRecord}
                            pagination={vesselPaged}
                            onPaginationChange={handlePaginationChange}
                        />
                )}
            </div>
            {isDrawerOpen && <ConatinerDrawer
                container={selectedContainerMeta}
                isDrawerOpen={isDrawerOpen}
                setDrawerOpen={setDrawerOpen}
                containerDetail={containerDetail}
            />
            }
            {isHatchDrawerOpen && <HatchDrawer
                isHatchDrawerOpen={isHatchDrawerOpen}
                setIsHatchDrawerOpen={setIsHatchDrawerOpen}
                vessel={selectedVesselMeta}
            />
            }
            {confirmDeleteOpen &&
                <DeleteConfirmModelUI
                    isModelOpen={confirmDeleteOpen}
                    loading={isLoading}
                    onConfirmDeleteClick={confirmDelete}
                    setIsModelOpen={setConfirmDeleteOpen}
                    selectedName={selectedRows.length + " Records"}
                />
            }
        </div>
    );
}