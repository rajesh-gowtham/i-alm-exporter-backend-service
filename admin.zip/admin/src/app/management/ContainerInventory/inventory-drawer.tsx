import { Button } from "@/components/ui/button";
import { DATE_TIME_FORMAT } from "@/lib/constants";
import { ContainerDetail, ContainerHistory, VesselInventory } from "@/lib/models";
import { Dialog, DialogContent } from "@radix-ui/react-dialog";
import { format } from "date-fns";
import { Clock } from "lucide-react";
import { useState } from "react";
// import { GoDotFill } from "react-icons/go";

export function ConatinerDrawer({ container, containerDetail, isDrawerOpen, setDrawerOpen }: { container: ContainerHistory, isDrawerOpen: boolean, containerDetail: ContainerDetail, setDrawerOpen: (arg: boolean) => void }) {
    const [activeTab, setActiveTab] = useState<"timeline" | "details">("details")

    const tabClasses = (tab: string) =>
        `rounded-none border-b-2 px-4 py-2 text-sm font-medium ${activeTab === tab
            ? "border-blue-500 text-blue-600"
            : "border-transparent text-gray-500 hover:text-blue-500"
        }`
    return (
        <Dialog onOpenChange={() => { setDrawerOpen(!isDrawerOpen) }} open={isDrawerOpen}>
            <DialogContent
                className="fixed right-0 top-0 h-[85vh] overflow-y-auto border w-[400px] bg-white p-4 shadow-xl"
            >
                <div className="flex flex-col">
                    <h1 className="items-center justify-center flex font-bold underline">{container.containerId}</h1>
                    <div className="space-x-2 flex border-b border-b-black/20">
                        <div className="flex border-b border-gray-200">
                            <Button
                                variant="ghost"
                                className={tabClasses("details")}
                                onClick={() => setActiveTab("details")}
                            >
                                Details
                            </Button>
                            <Button
                                variant="ghost"
                                className={tabClasses("timeline")}
                                onClick={() => setActiveTab("timeline")}
                            >
                                Move History
                            </Button>
                        </div>
                    </div>
                </div>

                <ContainerDrawer
                    activeTab={activeTab}
                    dataJson={containerDetail}
                />
            </DialogContent>
        </Dialog>

    );
}
export function HatchDrawer({ vessel, isHatchDrawerOpen, setIsHatchDrawerOpen }: { vessel: VesselInventory, isHatchDrawerOpen: boolean, setIsHatchDrawerOpen: (arg: boolean) => void }) {

    return (
        <Dialog onOpenChange={() => { setIsHatchDrawerOpen(!isHatchDrawerOpen) }} open={isHatchDrawerOpen}>
            <DialogContent
                className="fixed right-0 top-0 h-[85vh] border w-[450px] bg-white  p-2 shadow-xl"
            >
                <div className="flex flex-col py-1">
                    <h1 className="items-center justify-center flex font-bold underline">{vessel.vesselName}</h1>
                </div>


                {
                    vessel.hatch?.length > 0 ?
                        <div className="h-[90%] shadow-lg pt-1 overflow-y-auto">
                            {/* <h2 className="text-xl font-semibold">Event Details</h2> */}
                            {vessel.hatch.map((event, index) => (
                                <div key={index} className="border rounded-lg p-4 shadow-sm">
                                    {/* <h3 className="text-md font-semibold mb-2">Event {index + 1}</h3> */}
                                    <div className="grid grid-cols-2 gap-4 text-sm">
                                        <div>
                                            <span className="font-medium text-gray-700">Event Name:</span>
                                            <p>{event.eventName || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">Equipment Name:</span>
                                            <p>{event.equipmentName || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">Start Time:</span>
                                            <p>{(event.startTime && event.startTime !== "" && format(event.startTime, DATE_TIME_FORMAT)) || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">End Time:</span>
                                            <p>{(event.endTime && event.endTime !== "" && format(event.endTime, DATE_TIME_FORMAT)) || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">Visit Ref:</span>
                                            <p>{event.visitRef || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">Notes:</span>
                                            <p>{event.notes || '-'}</p>
                                        </div>
                                        <div>
                                            <span className="font-medium text-gray-700">Work Queue:</span>
                                            <p>{event.workQueue || '-'}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        :
                        <span className="w-full h-1/4 items-center flex justify-center">No Records</span>
                }
            </DialogContent>
        </Dialog>

    );
}

const ContainerDrawer = ({ activeTab, dataJson }: { activeTab: string, dataJson: ContainerDetail }) => {
    function generateTimeline(data: ContainerDetail) {
        return [
            {
                status: "Unit_Created",
                message: "",
                timestamp: data.jobCreatedTime,
            },
            // {
            //     status: "Started",
            //     message: "Job Started",
            //     timestamp: data.jobStartTime,
            // },
            // {
            //     status: "Dispatched",
            //     message: `Job dispatched to ${data.cheCarry}`,
            //     timestamp: data.dispatchTime,
            // },
            // {
            //     status: "Time at Origin",
            //     message: `${data.cheCarry} reached to ${data.pow} - ${data.assignedLane}`,
            //     timestamp: data.timeAtOrigin,
            // },
            {
                status: "Discharge_Confimed",
                message: `from ${data.fromPosition} to ${data.cheCarry}.${data.positionOnCarriage}`,
                timestamp: data.dischargeTime,
            },
            {
                status: "Block_Entry",
                message: ``,
                timestamp: data.timeFacilityIn,
            },
            {
                status: "Bay_Arrival",
                message: ``,
                timestamp: data.timeAtDestination,
            },
            {
                status: "Yard_In",
                message: "",
                timestamp: data.jobCompleteTime,
            },
        ]
    }


    return (<div className="flex pt-4 bg-white md:px-4">
        {activeTab === "timeline" ?

            <div className="relative pl-8 border-l-2 border-dashed space-y-6">
                {generateTimeline(dataJson).map((item, index) => (
                    <div key={index} className="relative flex items-start gap-4">
                        {/* Checkmark aligned on the dashed line */}
                        <div className="absolute -left-[45px] top-2 z-10 bg-white">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 24 24"
                                fill="currentColor"
                                className="h-6 w-6 text-green-600"
                            >
                                <path
                                    fillRule="evenodd"
                                    clipRule="evenodd"
                                    d="M2.25 12c0-5.385 4.365-9.75 
              9.75-9.75s9.75 4.365 9.75 
              9.75-4.365 9.75-9.75 9.75S2.25 
              17.385 2.25 12zm13.36-1.814a.75.75 
              0 10-1.22-.872l-3.236 4.53L9.53 
              12.22a.75.75 0 00-1.06 1.06l2.25 
              2.25a.75.75 0 001.14-.094l3.75-5.25z"
                                />
                            </svg>
                        </div>

                        {/* Text content */}
                        <div className="flex flex-col">
                            <div className="font-semibold text-gray-800">{item.status}</div>
                            <div className="text-gray-700 text-sm">{item.message}</div>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Clock size={16} />
                                <span>{item.timestamp ? format(item.timestamp, DATE_TIME_FORMAT) : ""}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            :

            <div className="w-full max-w-md space-y-2 rounded-md border p-4 shadow-sm">
                {/* {Object.entries(deliveryData).map(([key, value]) => ( */}
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Move Type :</span>
                    <span className="text-right">{dataJson.moveType}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Vessel Ref :</span>
                    <span className="text-right">{dataJson.vesselRef}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">cheCarry :</span>
                    <span className="text-right">{dataJson.cheCarry}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">POW :</span>
                    <span className="text-right">{dataJson.pow}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Mode :</span>
                    <span className="text-right">{dataJson.mode}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">assigned CHE :</span>
                    <span className="text-right">{dataJson.assignedChe}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">assigned Lane :</span>
                    <span className="text-right">{dataJson.assignedLane}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Block :</span>
                    <span className="text-right">{dataJson.block}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Position :</span>
                    <span className="text-right">{dataJson.position}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-700">
                    <span className="font-medium capitalize">Pos On Chassis :</span>
                    <span className="text-right">{dataJson.positionOnCarriage}</span>
                </div>
                {/* ))} */}
            </div>
        }
    </div>)
}

// const TIMELINE = () => {
//     const data = [
//         { time: '1 hour', content: 'Aravindh has tested regression testing', status: 'Passed' },
//         { time: '1 day', content: 'Ivan lendil has tested sanity testing', status: 'Passed' },
//         { time: '1 day', content: 'Ivan lendil has tested sanity testing', status: 'Passed' },
//         { time: '2 day', content: 'Aravindh has tested integration testing', status: 'Failed' },
//     ]

//     return (
//         <div className="mt-1 w-full h-full bg-white ">
//             <h1 className="text-xl text-center font-semibold text-black">Timeline</h1>
//             <div className="container my-4">
//                 <div className="flex flex-col md:grid grid-cols-12 text-gray-50  max-sm:ml-10">

//                     {data.map(item => <div className="flex max-sm:justify-center  md:contents">
//                         <div className="col-start-2 col-end-4 mr-10 max-sm:mr-8 md:mx-auto relative ">
//                             <div className="h-full w-[2px] flex items-center justify-center">
//                                 <div className="h-full w-1 bg-gray-300 pointer-events-none"></div>
//                             </div>

//                             <div className={`w-6 h-6 absolute top-1/2 -mt-3 -ml-[11px]  bg-white rounded-full flex items-center justify-center border-2 border-${item.status == "Passed" ? '[#a7dff3]' : '[#f5a1aa]'} shadow text-center`}>
//                                 <span><GoDotFill color={item.status === "Passed" ? '#3a7afe' : '#f25767'} size={20} /></span>
//                             </div>
//                         </div>
//                         <div id={item.status == "Passed" ? 'timelinearrow1' : "timelinearrow3"} className={`h-[70px] relative border-l-4 border-l-${item.status == "Passed" ? '[#3a7afe]' : '[#f25767]'} col-start-4 col-end-12 px-2 pl-3  my-4 mr-auto  w-full max-sm:w-2/3`}>
//                             <h3 className="font-semibold text-sm mb-1 text-[#89879f]">{item.time} ago</h3>
//                             <p className=" text-sm  w-full text-[#3d4465] font-medium">
//                                 {item.content} <span className={`text-${item.status == "Passed" ? 'blue-500' : '[#f25767]'} font-semibold`}>{item.status}</span>
//                             </p>
//                         </div>
//                     </div>
//                     )}

//                 </div>
//             </div>
//         </div>
//     )
// }