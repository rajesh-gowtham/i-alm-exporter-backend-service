import SubHeader from "@/components/SubHeader";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { Equipment } from "@/lib/models";
import {
  addEquipment,
  deleteEquipment,
  editEquipment,
  fetchEquipments,
} from "@/lib/services/equipment-services";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useEquipmentStore from "../store/EquipmentStore";
import EquipmentForm from "./equipment-form";
import { EquipmentLabels } from "@/lib/models/form-constants/formLabels";
import EquipmentImport from "./equipment-import";

export default function EquipmentMaster() {
  const [Equipments, setEquipments] = useState<Equipment[]>([]);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  // const [filteredEquipments, setFilteredEquipments] = useState<Equipment[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [EquipmentToEdit, setEquipmentToEdit] = useState<Equipment | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [EquipmentToDelete, setEquipmentToDelete] = useState<Equipment | undefined>(undefined);
  const EquipmentStore = useEquipmentStore();
  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const columnsConfig = [
    { key: "equipmentName", title: EquipmentLabels._EquipmentName, hidden: false },
    { key: "equipmentType", title: EquipmentLabels._EquipmentType, hidden: false },
    { key: "make", title: EquipmentLabels._Make, hidden: false },
    { key: "model", title: EquipmentLabels._Model, hidden: false },
    { key: "maxWeight", title: EquipmentLabels._MaxWeightInTon, hidden: true },
    { key: "maxTeu", title: EquipmentLabels._MaxTEU, hidden: true },
    { key: "rfidTag1", title: EquipmentLabels._RFIDTag1, hidden: true },
    { key: "rfidTag2", title: EquipmentLabels._RFIDTag2, hidden: true },
  ];

  const columns: ColumnDef<Equipment>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: false,
      // enableSorting: false,
      meta: { hidden }
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: Equipment } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];
  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  };

  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchEquipments(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setEquipments(items as Equipment[]);
      EquipmentStore.setEquipments(items as Equipment[]);
    }
    finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [paged]);

  const handleEdit = (Equipment: Equipment) => {
    setEquipmentToEdit(Equipment);
    setOpen(true);
  };

  const handleDeleteClick = (Equipment: Equipment) => {
    setEquipmentToDelete(Equipment);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (EquipmentToDelete?.id) {
        // setLoading(true);
        await deleteEquipment(EquipmentToDelete.id.toString());
      }
      setLoading(false);
      await fetchData();
      SuccessToaster("", "Equipment deleted successfully");
      mutate("equipments");
    }
    catch (error) {
      console.error(error);
      ErrorToaster("Equipment Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally {
      setConfirmDeleteOpen(false);
    }

  };

  const handleSubmit = async (data: Omit<Equipment, "id" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt">
  ) => {
    try {
      if (EquipmentToEdit?.id) {
        await editEquipment(EquipmentToEdit.id.toString(), data);
        SuccessToaster("", "Equipment updated successfully");
      } else {
        // const isEquipmentNameExists = Equipments?.some(item => item.equipmentName === data.equipmentName.trim());
        // if (isEquipmentNameExists) {
        //   ErrorToaster('', "Equipment Name already exists")
        //   setLoading(false);
        //   return;
        // }
        await addEquipment(data);
        SuccessToaster("", "Equipment created successfully");
      }
      setOpen(false);
      setEquipmentToEdit(undefined);
      await fetchData();
      mutate("equipments");
    } catch (error) {
      ErrorToaster("Equipment Creation Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  }

  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredEquipments(Equipments);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = Equipments.filter(
  //       (Equipment) =>
  //         Equipment.equipmentName.toLowerCase().includes(lowerCasedQuery) ||
  //         Equipment.equipmentType.toLowerCase().includes(lowerCasedQuery)
  //     );
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     //  setDisplayedVessels();
  //     // setTotalRecord(filtered.length); // U
  //     setFilteredEquipments(filtered.slice(start, end));
  //   }
  // }, [searchQuery, Equipments, paged]);
  // Import rework
  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?

        <div>
          <SubHeader
            placeholder="Equipment Name/Type..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Configuration + privateRoute._Equipment_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setEquipmentToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={Equipments || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={EquipmentToDelete?.equipmentName || ""}
            />
          }
          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setEquipmentToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {EquipmentToEdit ? "Edit Equipment" : "Add Equipment"}
              </DialogTitle>
              <EquipmentForm
                Equipment={EquipmentToEdit}
                onClose={() => {
                  setOpen(false);
                  setEquipmentToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog>
        </div>
        :
        <EquipmentImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
