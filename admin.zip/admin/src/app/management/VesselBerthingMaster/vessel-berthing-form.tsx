import { DateTimePicker } from "@/components/datetimepicker";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownWhite, ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { berthingSideOptionList } from "@/lib/constants";
import { VesselBerthing } from "@/lib/models";
import { BerthingLabels } from "@/lib/models/form-constants/formLabels";
import { VesselBerthingSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";
import useVesselVisitStore from "../store/VesselVisitStore";
import { formatCustomDateTime, toISOStringOrNull } from "@/lib/utils";

interface VesselBerthingFormProps {
  VesselBerthing?: VesselBerthing;
  onClose: () => void;
  onSubmit: (data: VesselBerthing) => void;
}

export default function VesselBerthingForm({
  VesselBerthing,
  onClose,
  onSubmit,
}: VesselBerthingFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  const vesselVisitStore = useVesselVisitStore();
  const {
    register,
    setValue,
    watch,
    reset,
    clearErrors,
    handleSubmit,
    formState: { errors },
  } = useForm<z.infer<typeof VesselBerthingSchema>>({
    resolver: zodResolver(VesselBerthingSchema),
    defaultValues: VesselBerthing
      ? {
        ...VesselBerthing,
        id:
          typeof VesselBerthing.id === "string"
            ? parseInt(VesselBerthing.id)
            : VesselBerthing.id,
        berthEta:
          VesselBerthing.berthEta instanceof Date
            ? VesselBerthing.berthEta.toISOString()
            : VesselBerthing.berthEta,
        berthEtd:
          VesselBerthing.berthEtd instanceof Date
            ? VesselBerthing.berthEtd.toISOString()
            : VesselBerthing.berthEtd,
        berthAta:
          VesselBerthing.berthAta instanceof Date
            ? VesselBerthing.berthAta.toISOString()
            : VesselBerthing.berthAta,
        startWorkTime:
          VesselBerthing.startWorkTime instanceof Date
            ? VesselBerthing.startWorkTime.toISOString()
            : VesselBerthing.startWorkTime,
      }
      : {},
  });

  const berthEta = watch("berthEta");
  const berthEtd = watch("berthEtd");
  const berthAta = watch("berthAta");
  const startWorkTime = watch("startWorkTime");
  const selVesselVisitId = watch("vesselVisitId");

  const VesselBerthingMemo = useMemo(() => VesselBerthing, [VesselBerthing]);

  useEffect(() => {
    if (VesselBerthingMemo) {
      reset({
        ...VesselBerthingMemo,
        id:
          typeof VesselBerthingMemo.id === "string"
            ? parseInt(VesselBerthingMemo.id)
            : VesselBerthingMemo.id,
        berthEta:
          VesselBerthingMemo.berthEta instanceof Date
            ? VesselBerthingMemo.berthEta.toISOString()
            : VesselBerthingMemo.berthEta,
        berthEtd:
          VesselBerthingMemo.berthEtd instanceof Date
            ? VesselBerthingMemo.berthEtd.toISOString()
            : VesselBerthingMemo.berthEtd,
        berthAta:
          VesselBerthingMemo.berthAta instanceof Date
            ? VesselBerthingMemo.berthAta.toISOString()
            : VesselBerthingMemo.berthAta,
        startWorkTime:
          VesselBerthingMemo.startWorkTime instanceof Date
            ? VesselBerthingMemo.startWorkTime.toISOString()
            : VesselBerthingMemo.startWorkTime,
      });
    }
  }, [VesselBerthingMemo, reset]);


  useEffect(() => {
    console.log(" selVesselVisitId ", selVesselVisitId);
    const selectedVesselVisit = vesselVisitStore?.vesselVisits?.find((item) => item.id === Number(selVesselVisitId));
    console.log(" selectedVesselVisit ", selectedVesselVisit);
    if (selectedVesselVisit) {
      setValue("berthEta", selectedVesselVisit.eta instanceof Date
        ? selectedVesselVisit.eta.toISOString()
        : selectedVesselVisit.eta, { shouldValidate: true });
      setValue("berthEtd", selectedVesselVisit.etd instanceof Date
        ? selectedVesselVisit.etd.toISOString()
        : selectedVesselVisit.etd, { shouldValidate: true });
    } else {
      setValue("berthEta", "");
      setValue("berthEtd", "");
    }
  }, [selVesselVisitId, setValue, vesselVisitStore.vesselVisits]);
  const submitHandler = async (formData: z.infer<typeof VesselBerthingSchema>) => {

    setIsLoading(true);
    try {
      const payload = {
        ...formData,
        berthEta: toISOStringOrNull(formData.berthEta),
        berthEtd: toISOStringOrNull(formData.berthEtd),
        startWorkTime: toISOStringOrNull(formData.startWorkTime),
        berthAta: toISOStringOrNull(formData.berthAta),
      };

      console.log("Submit handler called", formData);
      await onSubmit(payload as VesselBerthing);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)} 
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>{BerthingLabels._Quay}</Label>
          {(!VesselBerthingSchema.shape.quay.isOptional()) && <MandatoryIcon />}
          <Input {...register("quay")}
            error={!!errors.quay}
          />
        </div>

        <div>
          <Label>{BerthingLabels._Side_To}</Label>
          {(!VesselBerthingSchema.shape.berthingSide.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={BerthingLabels._Side_To}
            fieldName="berthingSide"
            fieldValue={VesselBerthing?.berthingSide || ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={berthingSideOptionList}
            error={!!errors.berthingSide}
          />
        </div>
        <div>
          <Label>{BerthingLabels._VisitRef}</Label>
          {(!VesselBerthingSchema.shape.vesselVisitId.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={BerthingLabels._VisitRef}
            fieldName="vesselVisitId"
            fieldValue={VesselBerthing?.vesselVisitId + "" || ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={vesselVisitStore?.vesselVisits?.map(item => ({ label: item.visitRef, value: (item.id) + "" }))}
            disabled={VesselBerthing !== undefined}
            error={!!errors.vesselVisitId}
          />
        </div>
        <div>
          <Label>{BerthingLabels._BerthETA}</Label>
          {(!VesselBerthingSchema.shape.berthEta.isOptional()) && <MandatoryIcon />}
          <DateTimePicker
            date={berthEta ? new Date(berthEta) : null}
            onDateChange={(date: string | number | Date) => {
              setValue(
                "berthEta",
                formatCustomDateTime(date, ""),
                { shouldValidate: true }
              );
            }}
            error={!!errors.berthEta}
          />
        </div>
        <div>
          <Label>{BerthingLabels._BerthETD}</Label>
          {(!VesselBerthingSchema.shape.berthEtd.isOptional()) && <MandatoryIcon />}
          <DateTimePicker
            date={berthEtd ? new Date(berthEtd) : null}
            onDateChange={(date: string | number | Date) => {
              setValue(
                "berthEtd",
                formatCustomDateTime(date, ""),
                { shouldValidate: true }
              );
            }}
            error={!!errors.berthEtd}
          />
        </div>
        <div>
          <Label>{BerthingLabels._BerthATA}</Label>
          {(!VesselBerthingSchema.shape.berthAta.isOptional()) && <MandatoryIcon />}
          <DateTimePicker
            date={berthAta ? new Date(berthAta) : null}
            onDateChange={(date: string | number | Date) => {
              setValue(
                "berthAta",
                formatCustomDateTime(date, ""),
                { shouldValidate: true }
              );
            }}
            error={!!errors.berthAta}
          />
        </div>
        <div>
          <Label>{BerthingLabels._StartWorkTime}</Label>
          {(!VesselBerthingSchema.shape.startWorkTime.isOptional()) && <MandatoryIcon />}
          <DateTimePicker
            date={startWorkTime ? new Date(startWorkTime) : null}
            onDateChange={(date: string | number | Date) => {
              setValue(
                "startWorkTime",
                formatCustomDateTime(date, ""),
              );
            }}
          />
        </div>
        <div>
          <Label>{BerthingLabels._StartBollard}</Label>
          {(!VesselBerthingSchema.shape.startBollard.isOptional()) && <MandatoryIcon />}
          <Input {...register("startBollard")}
            error={!!errors.startBollard}
          />
        </div>
        <div>
          <Label>{BerthingLabels._EndBollard}</Label>
          {(!VesselBerthingSchema.shape.endBollard.isOptional()) && <MandatoryIcon />}
          <Input {...register("endBollard")}
            error={!!errors.endBollard}
          />
        </div>

      </div>
      <FormActions
        isEdit={VesselBerthing?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
