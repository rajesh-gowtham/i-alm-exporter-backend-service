

import { ApiNode, TreeNode } from '@/lib/models';
import {
  addTemplate,
  addTemplateValue,
  editTemplate,
  EditTemplateValue,
  fetchTemplateChildren,
  fetchTemplateDetails,
} from '@/lib/services/levelTemplate-services';
import { ChevronDown, ChevronRight, Pencil, Plus, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';

const TreeNodeItem = ({ node, onAdd, onRename, onCreateNew, onExpand, onToggleExpand, editingNodes, setEditing, isParentFlag, setisParentFlag, level = 0 }: {
  node: TreeNode;
  onAdd: (node: TreeNode) => void;
  onRename: (node: TreeNode, name: string, description: string) => void;
  onCreateNew: (id: string, name: string, description: string, parentId: number, userId: string | null, node: TreeNode) => void;
  onExpand: (node: TreeNode) => void;
  onToggleExpand: (id: string, expand: boolean) => void;
  editingNodes: Set<string>;
  setEditing: (id: string) => void;
  isParentFlag?: boolean;
  setisParentFlag: React.Dispatch<React.SetStateAction<boolean>>;
  level: number;

}) => {
  const [newName, setNewName] = useState(node.name);
  const [newDescription, setnewDescription] = useState<string>(node.description ?? "")
  const isEditing = editingNodes.has(node.id);

  const handleSubmit = () => {
    console.log(node, newDescription)
    if (!newName.trim()) {
      toast.error("Value should not be empty")
      return
    };
    node.isNew
      ? onCreateNew(node.id, newName.trim(), newDescription?.trim(), node.raw.ltParentID ?? node.raw.ltid, node.raw.userId, node)
      : onRename(node, newName.trim(), newDescription);
  };
  console.log(node)
  return (
    <div className="ml-6 mt-3 border-l-4 border-orange-300 pl-4">
      <div className="flex items-center gap-2 p-3 bg-gradient-to-r from-orange-100 to-blue-100 hover:from-orange-200 hover:to-blue-200 rounded-lg shadow-md">
        {node.type === 'folder' && (
          <button onClick={() => node.isExpanded ? onToggleExpand(node.id, false) : node.hasFetched ? onToggleExpand(node.id, true) : onExpand(node)} className="text-orange-600 hover:text-orange-800">
            {node.isExpanded ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          </button>
        )}
        {isEditing ? (
          <div className="w-full bg-gradient-to-br from-white via-blue-50 to-blue-100 rounded-xl p-4 shadow-lg border border-blue-200 flex flex-col gap-2 transition-all duration-300">
            <div className={`flex ${isParentFlag ? "w-[280px]" : "w-full"} items-start relative gap-4`}>
              <input
                autoFocus
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Enter name"
                className={`bg-white shadow-sm border border-blue-300 px-4 py-2 text-sm rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${isParentFlag ? 'w-full pr-10' : 'w-2/5 min-w-[140px]'
                  }`}
                onKeyDown={(e) => {
                  if (isParentFlag && e.key === "Enter") {
                    handleSubmit();
                  }
                }}
              />
              {isParentFlag && (
                <button
                  onClick={() => {
                    setNewName(node.name || '');
                    onRename(node, '__cancel__', '');
                  }}
                  title="Cancel"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500 hover:text-red-700 transition"
                >
                  <X size={18} />
                </button>
              )}
              {(Object.prototype.hasOwnProperty.call(node?.raw, 'ltVID') && !isParentFlag) && (
                <input
                  value={newDescription}
                  onChange={(e) => setnewDescription(e.target.value)}
                  placeholder="Enter description"
                  className="w-3/5 bg-white border border-blue-300 px-4 py-2 text-sm rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all"
                />
              )}
            </div>
            {!isParentFlag && (
              <div className="flex justify-end gap-2 mt-1">
                <button
                  onClick={handleSubmit}

                  title="Save"
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-1.5 text-sm rounded-md shadow-md hover:from-blue-600 hover:to-blue-700 transition"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setNewName(node.name || '');
                    setnewDescription(node.description || '');
                    onRename(node, '__cancel__', '');
                  }}
                  title="Cancel"
                  className="bg-red-100 text-red-600 px-4 py-1.5 text-sm rounded-md hover:bg-red-200 transition"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col">
            <span className="text-[#2c417f] font-semibold text-sm tracking-wide">
              {node.name || '(unnamed)'}
            </span>
            {Object.prototype.hasOwnProperty.call(node?.raw, 'ltVDescription') &&
              node?.raw?.ltVDescription?.trim() !== '' && (
                <span className="text-gray-500 text-xs italic mt-0.5">
                  {node.raw.ltVDescription}
                </span>
              )}
          </div>
        )}

        <div className="flex gap-2 ml-auto">
          <button onClick={() => {
            console.log(node);
            setEditing(node.id);
            const description = node?.raw?.ltVDescription ?? '';
            setnewDescription(description);
            if (Object.prototype.hasOwnProperty.call(node?.raw, 'ltVDescription')) {
              setisParentFlag(false);
            } else {
              setisParentFlag(true);
            }
          }}
            title="Edit" className="text-[#2c417f] hover:text-[#2c417f]">
            <Pencil className="w-4 h-4" />
          </button>
          {(node.level ?? level) < 3 && (
            <button onClick={() => onAdd(node)} title="Add Child" className="text-orange-600 hover:text-orange-800">
              <Plus className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {node.isExpanded && node.children && (
        <div className="ml-4 border-l-2 border-dashed border-blue-300">
          {node.children.map((child) => (
            <TreeNodeItem key={child.id} node={child} level={level + 1}
              {...{
                onAdd, onRename, onCreateNew, onExpand, onToggleExpand, editingNodes, setEditing,
                setisParentFlag
              }} />

          ))}
        </div>
      )}
    </div>
  );
};

export default function TreeView() {
  const [tree, setTree] = useState<TreeNode[]>([]);
  const [editingNodes, setEditingNodes] = useState<Set<string>>(new Set());
  const [isParentFlag, setisParentFlag] = useState(false)

  useEffect(() => { fetchInitialParents(); }, []);

  const fetchInitialParents = async () => {
    const data = await fetchTemplateDetails();
    setTree(data.map((item) => ({
      id: item.ltid.toString(),
      name: item.ltName || '(unnamed)',
      type: 'folder',
      raw: item,
      isExpanded: false,
      hasFetched: false,
      level: 0,
    })));
  };

  const updateNode = (nodes: TreeNode[], id: string, updater: (n: TreeNode) => TreeNode): TreeNode[] =>
    nodes.map((n) => n.id === id ? updater(n) : n.children ? { ...n, children: updateNode(n.children, id, updater) } : n);

  const onToggleExpand = (id: string, expand: boolean) =>
    setTree(updateNode(tree, id, (n) => ({ ...n, isExpanded: expand })));

  const handleExpand = async (node: TreeNode) => {
    console.log(node)
    try {
      const childrenData = await fetchTemplateChildren();
      const parentVID = node.raw.ltVID ?? node.raw.ltid;
      console.log(parentVID)
      const children = (childrenData as unknown as ApiNode[]).filter((c) => {
        const targetParentVID = parentVID === 1 ? 0 : parentVID;
        return c.ltVParentID === targetParentVID && node.raw.ltid === c.ltid;
      })
        .map((c) => ({
          id: (c.ltVID ?? c.ltid).toString(),
          name: c.ltValue || '(unnamed)',
          type: 'folder',
          raw: c,
          isExpanded: false,
          hasFetched: false,
          children: [],
          level: (node.level ?? 0) + 1,

        }));
      setTree(updateNode(tree, node.id, (n) => ({ ...n, children, isExpanded: true, hasFetched: true })));
    } catch (err) {
      console.error('Child load error:', err);
    }
  };

  const handleAdd = (parent: TreeNode) => {
    console.log(parent)
    const tempId = `temp-${Date.now()}`;
    const newNode: TreeNode = {
      id: tempId,
      name: '',
      type: 'child',
      raw: {
        ltid: parent.raw.ltid,
        ltName: '',
        ltParentID: parent.raw.ltVID ?? parent.raw.ltid,
        userId: parent.raw.userId,
        childCount: "0",
        ltVID: 0,
      },
      isNew: true,
    };
    setTree(updateNode(tree, parent.id, (n) => ({ ...n, children: [...(n.children || []), newNode], isExpanded: true })));
    setEditingNodes(new Set([tempId]));
  };

  const handleCreateNew = async (id: string, name: string, description: string, parentId: number, userId: string | null, node: TreeNode) => {
    try {
      const payload = node.type === 'parent'
        ? { ltid: 0, ltName: name.trim(), ltParentID: 0, userId: null, childCount: "0" }
        : {
          ltVID: 0, ltid: node.raw.ltid, ltValue: name.trim(),
          ltVParentID: parentId, ltVDescription: description, userId, childCount: "0",
        };
      if (node.type === 'parent') {
        await addTemplate(payload);
      } else {
        await addTemplateValue(payload);
      }

      const latestParents = await fetchInitialParents();
      const created = latestParents.find((p: any) => p.ltName === name.trim());
      const newLtid = created?.ltid ?? node.raw.ltid;

      setTree(updateNode(tree, node.id, (n) => ({
        ...n,
        name: name.trim(),
        description: description || '',
        raw: {
          ...n.raw,
          ltid: newLtid,
          ltVDescription: description || '',
        },
        isExpanded: true
      })));

      setEditingNodes((prev) => {
        const set = new Set(prev);
        set.delete(node.id);
        return set;
      });

      toast.success("Creation Completed", {
        description: `Value created successfully`,
      });

      setisParentFlag(true);
    } catch (err) {
      console.error('Create error:', err);
    }
  };


  const handleRename = async (node: TreeNode, name: string, description: string) => {
    console.log(node)
    if (name === '__cancel__') {
      if (node.isNew) {
        const removeNode = (nodes: TreeNode[]): TreeNode[] =>
          nodes
            .map((n) =>
              n.id === node.id
                ? null
                : n.children
                  ? { ...n, children: removeNode(n.children).filter(Boolean) as TreeNode[] }
                  : n
            )
            .filter(Boolean) as TreeNode[];

        setTree((prev) => removeNode(prev));
      }
      setEditingNodes((prev) => {
        const set = new Set(prev);
        set.delete(node.id);
        return set;
      });

      return;
    }
    console.log(node)
    if (!name.trim()) {
      toast.error("Value should not be empty");
      return;
    }
    try {
      const isParentNode = !('ltVID' in node.raw)
      if (isParentNode) {
        await editTemplate({
          ltid: node.raw.ltid, ltName: name.trim(), ltParentID: 0, userId: null, childCount: "0",
        });
      } else {
        await EditTemplateValue({
          ltVID: node.raw.ltVID!, ltid: node.raw.ltid, ltValue: name.trim(), ltVParentID: node.raw.ltParentID ?? node.raw.ltid, ltVDescription: description, userId: null, childCount: "0",
        });
      }
      setTree(updateNode(tree, node.id, (n) => ({
        ...n,
        name: name.trim(),
        description: description || '',
        raw: {
          ...n.raw,
          ltVDescription: description || '',
        },
      })));
      setEditingNodes((prev) => {
        const set = new Set(prev);
        set.delete(node.id);
        return set;
      });
      await fetchTemplateChildren();
      toast.success("Updation Completed", {
        description: `Value updated successfully`,
      });
      setisParentFlag(true)

    } catch (err) {
      console.error("Rename error:", err);

    }
  };

  const setEditing = (id: string) => setEditingNodes(new Set([id]));

  const handleAddParent = () => {
    const tempId = `temp-parent-${Date.now()}`;
    const newParent: TreeNode = {
      id: tempId,
      name: '',
      type: 'parent',
      raw: {
        ltid: 0,
        ltName: '',
        ltParentID: 0,
        ltVID: 0,
        userId: null,
        childCount: "0",
      },
      isNew: true,
      children: [],
    };
    setTree((prev) => [...prev, newParent]);
    setEditingNodes(new Set([tempId]));
    setisParentFlag(true)
  };

  return (
    <div className="relative p-8 bg-gradient-to-br from-orange-50 via-blue-50 to-white rounded-2xl shadow-2xl w-full max-w-4xl mx-auto border border-blue-200">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-[#2c417f] flex items-center gap-3">
          📁 Level Template
        </h2>

        <button
          onClick={() => handleAddParent()}
          className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg shadow hover:bg-orange-600 transition duration-200 text-sm font-medium"
        >
          <Plus className="w-4 h-4" />
          Add Parent
        </button>
      </div>

      {tree.map((node) => (
        <TreeNodeItem
          key={node.id}
          node={node}
          level={0}
          {...{ onAdd: handleAdd, onRename: handleRename, onCreateNew: handleCreateNew, onExpand: handleExpand, onToggleExpand, editingNodes, setEditing, isParentFlag, setisParentFlag }}
        />
      ))}
    </div>

  );
}
