import SubHeader from "@/components/SubHeader";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { ConfigData, RfidDevice } from "@/lib/models";
import { RfidRegisterFormLabels, rfidTabs } from "@/lib/models/form-constants/formLabels";
import { addRTLSDevice, deleteRTLSDevice, editRTLSDevice, fetchRTLSDevice, fetchRTLSDeviceMasterData } from "@/lib/services/rfid-service";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import React, { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useRfidDeviceStore from "../store/RfidDeviceStore";
import TreeBuilder from "./level-template";
import RfidDeviceForm from "./rfid-form";

export default function RfidMaster() {
  const [RfidDevice, setRfidDevice] = useState<RfidDevice[]>([]);
  const [configData, setConfigData] = useState<ConfigData>({
  readerType: [],
  readerModel: [],
  levelTemplate: [],
  levelTemplateZone: [],
  // levelTemplateSubZone:[]
});
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [RfidDeviceToEdit, setRfidDeviceToEdit] = useState<RfidDevice | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [RfidAssetToDelete, setRfidAssetToDelete] = useState<RfidDevice | undefined>(undefined);
  const DeviceAssetStore = useRfidDeviceStore();
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);
  const [activeTab, setActiveTab] = useState("leveltemplate");

  const columnsConfig = [
    { key: "readerIP", title: RfidRegisterFormLabels._ReaderIP, hidden: false },
    { key: "rpName", title: RfidRegisterFormLabels._ReadPointNames, hidden: false },
    { key: "antennaID", title: RfidRegisterFormLabels._AntennaID, hidden: false },
    { key: "locationName", title: RfidRegisterFormLabels._Location, hidden: false },
    { key: "readerTypeValue", title: RfidRegisterFormLabels._ReaderType, hidden: false },
    { key: "readerModelValue", title: RfidRegisterFormLabels._ReaderModal, hidden: false },
    { key: "ltValue", title: RfidRegisterFormLabels._ltValue, hidden: false },
    { key: "lat", title: RfidRegisterFormLabels._Lat, hidden: false },
    { key: "long", title: RfidRegisterFormLabels._Lang, hidden: false },
  ];

  const columns: ColumnDef<RfidDevice>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: false,
      // enableSorting: false,
      meta: { hidden }
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: RfidDevice } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];
  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  };

  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    if (activeTab !== 'leveltemplate')
      try {

        const [rfidDeviceData, masterData] = await Promise.all([
          fetchRTLSDevice(skip, take, search),
          fetchRTLSDeviceMasterData(skip, take, search)
        ]);
        console.log('Devices:', rfidDeviceData);
        console.log('Master Data:', masterData);
        setConfigData({
          readerModel: masterData.readerModel,
          readerType: masterData.readerType,
          levelTemplate: masterData.levelTemplate,
          levelTemplateZone: masterData.levelTemplate.filter((el: { ltVParentID: number; }) => el.ltVParentID === 0 || el.ltVParentID === el.ltid),
        });
        setRfidDevice(rfidDeviceData?.items as RfidDevice[]);
        DeviceAssetStore.setRfidDevice(rfidDeviceData?.items as RfidDevice[]);
        const totalCount = rfidDeviceData?.totalCount ?? 0;
        setTotalRecord(totalCount);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setOpen(false);
      }
  };

  useEffect(() => {
    fetchData();
  }, [paged, activeTab]);


  const handleEdit = (RfidDevice: RfidDevice) => {
    console.log(RfidDevice);
    
    // const getmatchedRfidData = configData.levelTemplate.filter((el:any) => el.ltVID === RfidDevice.ltVID)
    // console.log(getmatchedRfidData)
    setConfigData({
      ...configData,
      levelTemplate: configData.levelTemplate,
      levelTemplateZone: configData.levelTemplate.filter(el => el.ltVParentID === 0 || el.ltVParentID === el.ltid),
      // levelTemplateSubZone: [...configData.levelTemplate.filter((el:any) => el.ltVParentID === 0), getmatchedRfidData],
    });

    const rfidltVID = RfidDevice.ltVID
    console.log(rfidltVID)
    const constructZoneConfigData = configData.levelTemplate.filter(el => el.ltVID === parseInt(rfidltVID)).map(el => el.ltVParentID)
    console.log(constructZoneConfigData) //26
    const subChild = configData.levelTemplate.filter(el => el.ltVID === parseInt(constructZoneConfigData)).map(el => el.ltVParentID).join('')
    console.log(subChild) //16
    const mappingRfidDevice = { ...RfidDevice, locationID: String(RfidDevice.locationID), ltVID: String(RfidDevice.ltVID), isEditFlag: true,zoneltVID:subChild }
    console.log(mappingRfidDevice)
    setRfidDeviceToEdit(mappingRfidDevice);
    setOpen(true)

  };

  const handleDeleteClick = (RfidDevice: RfidDevice) => {
    setRfidAssetToDelete(RfidDevice);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (RfidAssetToDelete?.rpid) {
        await deleteRTLSDevice(RfidAssetToDelete.rpid);
        await fetchData();
        SuccessToaster("", "RFID Device deleted successfully");
        mutate("RfidDevice");
        setLoading(false);
      }
      setConfirmDeleteOpen(false);
    }
    catch (error) {
      console.error(error);
      ErrorToaster("RFID Device Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally {
      setConfirmDeleteOpen(false);
    }

  };

  const handleSubmit = async (data: Omit<RfidDevice, "id" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt">
  ) => {
    console.log(data)
    try {
      if (RfidDeviceToEdit?.rpid) {
        await editRTLSDevice(RfidDeviceToEdit.rpid, data);
        SuccessToaster("", "RFID Device updated successfully");
      } else {
        // await (data);
        console.log("Creating new device asset:", data);
        await addRTLSDevice(data);
        SuccessToaster("", "RFID Device created successfully");
      }
      setOpen(false);
      setRfidDeviceToEdit(undefined);
      await fetchData();
      mutate("RfidDevice");
    } catch (error) {
      ErrorToaster(error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }
  }

  const onSearchChange = (searchText: string) => {
    console.log(searchText)
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      <div className="mb-6 ml-4 border-gray-200">
        <div className="inline-flex overflow-hidden bg-white border border-gray-300 rounded-md shadow-sm">
          {rfidTabs.map((tab, index) => (
            <React.Fragment key={tab.id}>
              <button
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-2 text-sm font-semibold focus:outline-none transition-colors rounded-md duration-200 ${activeTab === tab.id
                  ? "bg-[#2c417f] text-white"
                  : "text-gray-700 hover:bg-gray-100"
                  }`}
              >
                {tab.label}
              </button>
              {/* {index < rfidTabs.length - 1 && (
                <div className="w-px my-2 bg-gray-300" />
              )} */}
            </React.Fragment>
          ))}
        </div>
      </div>
      {/* //tab  */}
      {activeTab === "onboarding" && (
        <div>
          <SubHeader
            placeholder="RFID Name..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            onAddClickOpen={setOpen}
            setComponentToEdit={setRfidDeviceToEdit}
            errorList={errorList}
            isImportBtnDisabled={true}
          />
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <div className="mt-4">
              <DataTable
                columns={columns}
                data={RfidDevice || []}
                totalRecords={totalRecord}
                pagination={paged}
                onPaginationChange={handlePaginationChange}
              />
            </div>
          )}
          {/* Delete Modal */}
          {confirmDeleteOpen && (
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={RfidAssetToDelete?.readPointName || ""}
            />
          )}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setRfidDeviceToEdit(undefined);
            }}
          >
            <DialogContent className="max-h-screen overflow-y-scroll">
              <DialogTitle>
                {RfidDeviceToEdit
                  ? "Edit RFID Device"
                  : "Add RFID Device"}
              </DialogTitle>
              <RfidDeviceForm
                RfidDevice={RfidDeviceToEdit}
                onClose={() => {
                  setOpen(false);
                  setRfidDeviceToEdit(undefined);
                }}
                onSubmit={handleSubmit}
                configData={configData}
              />
            </DialogContent>
          </Dialog>
        </div>
      )}
      {activeTab === "leveltemplate" && (
        <div className="p-4 m-4 text-gray-800 border rounded-lg bg-blue-50">
          <TreeBuilder />
        </div>
      )}
    </div>
  )
}
