import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownWhite, ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { locationOptionList } from "@/lib/constants";
import { ConfigData, ReaderDetail, RfidDevice } from "@/lib/models";
import { RfidRegisterFormLabels } from "@/lib/models/form-constants/formLabels";
import { RfidRegisterSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
// Import your Calendar component from the correct UI library
import { useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";


interface RfidDeviceFormProps {
  RfidDevice?: RfidDevice;
  onClose: () => void;
  onSubmit: (data: RfidDevice) => void;
  configData: ConfigData;
}

export default function RfidDeviceForm({
  RfidDevice,
  onClose,
  onSubmit,
  configData
}: RfidDeviceFormProps) {
  const [antennaDetails, setAntennaDetails] = useState<ReaderDetail[]>([{
    uniqueId: '',
    name: '',
    // type: 'Fixed',
    // fixedMob: 'Fixed',
    readerName: '',
  }])

  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const [subChildData, setSubChildData] = useState('')
  const {
    register,
    reset,
    handleSubmit,
    setValue,
    clearErrors,
    control,
    getValues,
    formState: { errors },
    watch,
  } = useForm<z.infer<typeof RfidRegisterSchema>>({
    resolver: zodResolver(RfidRegisterSchema),
    defaultValues: {
      ltVID: '',
    }
  });

  const RfidDeviceMemo = useMemo(() => RfidDevice, [RfidDevice]);
const [constructSubZonesData, setConstructSubZonesData] = useState([]);
  console.log(RfidDevice)
  useEffect(() => {
    if (RfidDeviceMemo) {
      reset({
        ...RfidDeviceMemo
      });
    }
  }, [RfidDeviceMemo, reset]);
  const submitHandler = async (formData: z.infer<typeof RfidRegisterSchema>) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      // const finalPayload = {
      //   ...formData,
      //   antennaDetails,
      // };
      console.log("Final submission", formData);
      const payload = { ...formData, userId: null, rPID: 0, locationID: parseInt(formData.locationID) }
      await onSubmit(payload);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };

  console.log(configData, RfidDevice)
  // const rfidltVID =!RfidDevice?.isEditFlag ? getValues("zoneltVID") :getValues("ltVID")
  const rfidltVID = RfidDevice?.isEditFlag ? getValues("ltVID") : getValues("zoneltVID")
  console.log(rfidltVID, getValues("zoneltVID")) //16
  const handleEditOptionSubZone = () => {
    console.log(getValues("zoneltVID"))
    const value = configData.levelTemplate.filter(el => el.ltVID === parseInt(rfidltVID)).map(el => el.ltVParentID) //0
    console.log(value)
    const subChildId = configData.levelTemplate.filter(el => el.ltVParentID === parseInt(value))
    console.log(subChildId) //16 ltVParentID
    return subChildId
  }

  //for sub zone filter
  const constructSubZoneConfigData = configData.levelTemplate.filter(el => el.ltVParentID === parseInt(rfidltVID)).map(el => el.ltVID)
  console.log(constructSubZoneConfigData)
  const constructSubZoneData = RfidDevice?.isEditFlag === true ? handleEditOptionSubZone()
    : configData.levelTemplate.filter(el => constructSubZoneConfigData.includes(el.ltVParentID))
  console.log(constructSubZoneData)
  const zoneValue = watch("zoneltVID");
  const isFirstRun = useRef(true);

useEffect(() => {
  if (RfidDevice?.isEditFlag) {
    if (isFirstRun.current) {
      isFirstRun.current = false;
      return;
    }
    handleZoneChangeInEdit(zoneValue);
  }
}, [zoneValue, RfidDevice?.isEditFlag]);

const handleZoneChangeInEdit = (newValue) => {
  console.log("newValue", newValue);
  if (newValue !== undefined) {
    const constructSubZoneConfigDatas = configData.levelTemplate
      .filter(el => el.ltVParentID === parseInt(newValue))
      .map(el => el.ltVID);
    console.log(constructSubZoneConfigDatas);
    const subZoneId = configData.levelTemplate
      .filter(el => constructSubZoneConfigDatas.includes(el.ltVParentID));
    console.log(subZoneId);
    setConstructSubZonesData(subZoneId); 
  }
};



  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>{RfidRegisterFormLabels._ReaderIP}</Label>
          {(!RfidRegisterSchema.shape.readerIP.isOptional()) && <MandatoryIcon />}
          <Input  {...register("readerIP")}
            error={!!errors.readerIP}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._ReadPointNames}</Label>
          {(!RfidRegisterSchema.shape.rpName.isOptional()) && <MandatoryIcon />}
          <Input  {...register("rpName")}
            error={!!errors.rpName}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._AntennaID}</Label>
          {(!RfidRegisterSchema.shape.antennaID.isOptional()) && <MandatoryIcon />}
          <Input {...register("antennaID", { valueAsNumber: true })}
            error={!!errors.antennaID}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._Location}</Label>
          {(!RfidRegisterSchema.shape.locationID.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={RfidRegisterFormLabels._Location}
            fieldName="locationID"
            fieldValue={RfidDevice?.locationID + ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={locationOptionList}
            error={!!errors.locationID}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._ReaderType}</Label>
          {(!RfidRegisterSchema.shape.readerType.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={RfidRegisterFormLabels._ReaderType}
            fieldName="readerType"
            fieldValue={RfidDevice?.readerType + ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={configData?.readerType?.map(item => ({ label: item.gpValue, value: (item.gpid) + "" }))}
            error={!!errors.readerType}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._ReaderModal}</Label>
          {(!RfidRegisterSchema.shape.readerModel.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={RfidRegisterFormLabels._ReaderModal}
            fieldName="readerModel"
            fieldValue={RfidDevice?.readerModel + ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={configData?.readerModel?.map(item => ({ label: item.gpValue, value: (item.gpid) + "" }))}
            error={!!errors.readerModel}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._Zone}</Label>
          {(!RfidRegisterSchema.shape.zoneltVID.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={RfidRegisterFormLabels._Zone}
            fieldName="zoneltVID"
            fieldValue={RfidDevice?.zoneltVID + ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={configData?.levelTemplateZone?.map(item => ({ label: item.ltValue, value: item.ltVID.toString() }))}
            // optionsList={RfidDevice?.isEditFlag  ? configData?.levelTemplate?.map(item => ({label: item.ltValue,value: item.ltVID.toString()})):constructZoneConfigData?.map(item => ({ label: item.ltValue, value: item.ltVID.toString() }))}
            error={!!errors.zoneltVID}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._SubZone}</Label>
          {(!RfidRegisterSchema.shape.ltVID.isOptional()) && <MandatoryIcon />}
          <DropdownWhite
            Label_Placeholder={RfidRegisterFormLabels._SubZone}
            fieldName="ltVID"
            fieldValue={RfidDevice?.ltVID + ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={constructSubZonesData.length>0 ? constructSubZonesData?.map(item => ({
              label: item.ltValue,
              value: item?.ltVID?.toString()
            })) :constructSubZoneData?.map(item => ({
              label: item.ltValue,
              value: item?.ltVID?.toString()
            }))}
            error={!!errors.ltVID}
          />

        </div>
        <div>
          <Label>{RfidRegisterFormLabels._Lat}</Label>
          {(!RfidRegisterSchema.shape.lat.isOptional()) && <MandatoryIcon />}
          <Input {...register("lat")}
            error={!!errors.lat}
          />
        </div>
        <div>
          <Label>{RfidRegisterFormLabels._Lang}</Label>
          {(!RfidRegisterSchema.shape.long.isOptional()) && <MandatoryIcon />}
          <Input {...register("long")}
            error={!!errors.long}
          />
        </div>
        {/* < div className="col-span-2">
          <ReaderDetailsCardLayout
            value={antennaDetails}
            onChange={setAntennaDetails}
          />
        </div> */}
      </div>
      <FormActions
        isEdit={RfidDevice?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
