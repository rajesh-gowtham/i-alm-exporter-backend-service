import { ReaderDetail } from '@/lib/models';
import { MinusCircleIcon, PlusIcon } from 'lucide-react';
import React from 'react';

interface ReaderDetailsCardLayoutProps {
  value: ReaderDetail[];
  onChange: (updated: ReaderDetail[]) => void;
}

const initialRow = (): ReaderDetail => ({
  uniqueId: '',
  name: '',
//   type: 'Fixed',
//   fixedMob: 'Fixed',
  readerName: '',
});

const ReaderDetailsCardLayout: React.FC<ReaderDetailsCardLayoutProps> = ({ value, onChange }) => {
  const handleChange = (index: number, field: keyof ReaderDetail, valueStr: string) => {
    const updated = [...value];
    updated[index] = { ...updated[index], [field]: valueStr };
    onChange(updated);
  };

  const addRow = () => {
    if (value.length < 4) {
      onChange([...value, initialRow()]);
    }
  };

  const removeRow = (index: number) => {
    if (value.length <= 1) return;
    const updatedRows = [...value];
    updatedRows.splice(index, 1);
    onChange(updatedRows);
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-l font-semibold text-gray-800">Antenna Count</h2>
        <button
          type="button"
          onClick={addRow}
          className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition"
          disabled={value.length >= 4}
        >
          <PlusIcon className="w-4 h-4" />
        </button>
      </div>

      <div className="overflow-auto max-h-[350px]">
        <table className="min-w-full text-sm border border-gray-200">
          <thead className="bg-gray-100 text-gray-700 sticky top-0 z-10">
            <tr>
              <th className="px-4 py-2 text-left border">Unique ID</th>
              <th className="px-4 py-2 text-left border">Name</th>
              <th className="px-4 py-2 text-left border">Reader Name</th>
              <th className="px-4 py-2 text-left border">Action</th>
            </tr>
          </thead>
          <tbody>
            {value.map((row, index) => (
              <tr key={index} className="even:bg-gray-50">
                <td className="border px-3 py-2">
                  <input
                    type="text"
                    value={row.uniqueId}
                    onChange={(e) => handleChange(index, 'uniqueId', e.target.value)}
                    className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter Unique ID"
                  />
                </td>
                <td className="border px-3 py-2">
                  <input
                    type="text"
                    value={row.name}
                    onChange={(e) => handleChange(index, 'name', e.target.value)}
                    className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter Name"
                  />
                </td>
                {/* <td className="border px-3 py-2">
                  <select
                    value={row.type}
                    onChange={(e) => handleChange(index, 'type', e.target.value)}
                    className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option>Fixed</option>
                    <option>Mobile</option>
                  </select>
                </td> */}
                {/* <td className="border px-3 py-2">
                  <select
                    value={row.fixedMob}
                    onChange={(e) => handleChange(index, 'fixedMob', e.target.value)}
                    className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option>Fixed</option>
                    <option>Mobile</option>
                  </select>
                </td> */}
                <td className="border px-3 py-2">
                  <input
                    type="text"
                    value={row.readerName}
                    onChange={(e) => handleChange(index, 'readerName', e.target.value)}
                    className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter Reader Name"
                  />
                </td>
                <td className="border px-3 py-2 text-center">
                  <button
                    type="button"
                    onClick={() => removeRow(index)}
                    className="text-red-600 hover:text-red-800 transition"
                    disabled={value.length === 1}
                    title="Remove Row"
                  >
                    <MinusCircleIcon className="w-5 h-5 inline-block" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ReaderDetailsCardLayout;
