import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle
} from '@/components/ui/dialog';
import { ErrorToaster, SuccessToaster } from '@/components/UtilComp';
import { EquipmentPool } from '@/lib/models';
import { equipmentPoolAssignments } from '@/lib/services/equipmentpool-services';
import { Search } from 'lucide-react';
import React, { useState } from 'react';
import { HiOutlineArrowLeft, HiOutlineArrowRight } from 'react-icons/hi';

const isValidValue = (value: string) => {
    return value !== '' && value !== undefined && value !== null;
};
interface Equipment {
    id: number;
    equipmentName: string;
    assignedPool: string;
}

interface EquipmentPoolFormProps {
    openEditEquipPoolManage: () => void;
    EquipmentPoolToEdit: EquipmentPool | undefined;
    unAssignedEquipments: Equipment[];
    assignedEquipments: Equipment[];
    setAssignedEquipments: (value: Equipment[]) => void;
    setUnAssignedEquipments: (value: Equipment[]) => void;
    isEquipPoolManageOpen: boolean;
    setFormOpen: (arg: boolean) => void;
    setIsEquipPoolManageOpen: (arg: boolean) => void;
}

export default function EquipmentPoolManagement({
    EquipmentPoolToEdit,
    unAssignedEquipments,
    assignedEquipments,
    setUnAssignedEquipments,
    isEquipPoolManageOpen,
    openEditEquipPoolManage,
    setAssignedEquipments,
    setFormOpen,
    setIsEquipPoolManageOpen
}: EquipmentPoolFormProps) {
    console.log(unAssignedEquipments, assignedEquipments);

    // const [open, setOpen] = useState<boolean>(true);
    const [selectedAssigned, setSelectedAssigned] = useState<string[]>([]);
    const [selectedUnassigned, setSelectedUnassigned] = useState<string[]>([]);
    const [searchAssigned, setSearchAssigned] = useState<string>('');
    const [searchUnassigned, setSearchUnassigned] = useState<string>('');

    const filteredAssigned = assignedEquipments?.filter(item =>
        item.equipmentName.toLowerCase().includes(searchAssigned.toLowerCase())
    );

    const filteredUnassigned = unAssignedEquipments?.filter(item =>
        item.equipmentName.toLowerCase().includes(searchUnassigned.toLowerCase())
    );

    const filterUnassignAvailCount = unAssignedEquipments?.filter(item => isValidValue(item.assignedPool));
    console.log("filterUnassignAvailCount", filterUnassignAvailCount);

    const handleSelectAll = (type: 'assignedEquipments' | 'unAssignedEquipments', isChecked: boolean) => {
        console.log(" unAssignedEquipments ", unAssignedEquipments, filteredUnassigned);
        const tempFilterUnAssigned = filteredUnassigned.filter(item => !isValidValue(item.assignedPool));
        console.log(" tempFilterUnAssigned ", tempFilterUnAssigned);
        const list = type === 'assignedEquipments' ? filteredAssigned : tempFilterUnAssigned;
        const ids = isChecked ? list.map(item => item.equipmentName) : [];
        if (type === 'assignedEquipments')
            setSelectedAssigned(ids)
        else
            setSelectedUnassigned(ids);
    };

    const moveToAssigned = () => {
        const toMove = unAssignedEquipments.filter(item => selectedUnassigned.includes(item.equipmentName));
        setAssignedEquipments([...assignedEquipments, ...toMove]);
        setUnAssignedEquipments(unAssignedEquipments.filter(item => !selectedUnassigned.includes(item.equipmentName)));
        setSelectedUnassigned([]);
    };

    const moveToUnassigned = () => {
        const toMove = assignedEquipments.filter(item => selectedAssigned.includes(item.equipmentName));
        setUnAssignedEquipments([...unAssignedEquipments, ...toMove]);
        setAssignedEquipments(assignedEquipments.filter(item => !selectedAssigned.includes(item.equipmentName)));
        setSelectedAssigned([]);
    };


    const handleUpdate = async () => {
        try {
            console.log(assignedEquipments);
            const assignData = assignedEquipments?.map(el => ({
                equipmentId: Object.keys(el).includes("equipment") ? el.equipmentId : el.id
            }));
            console.log(assignData);

            const data = await equipmentPoolAssignments(assignData, EquipmentPoolToEdit?.id);
            console.log(data)
            if (data) {
                SuccessToaster('', 'Equipment assigned successfully')
            }
            setFormOpen(false);
            setIsEquipPoolManageOpen(false);
        } catch (error) {
            console.error("Error updating equipment pool assignments:", error);
        }
    };

    console.log("filteredUnassigned", filteredUnassigned, "selectedUnassigned", selectedUnassigned, "filterUnassignAvailCount", filterUnassignAvailCount);

    return (
        <Dialog open={isEquipPoolManageOpen} onOpenChange={openEditEquipPoolManage}>
            <DialogContent className="!max-w-[50vw] !h-[90vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle>Assign Equipment To Pool</DialogTitle>
                </DialogHeader>
                <div className="flex flex-1 space-x-4 overflow-hidden">
                    {/* Assigned Card */}
                    <Card className="flex flex-col flex-1">
                        <CardContent className="flex-1 p-4 overflow-hidden">
                            <h2 className="mb-2 font-semibold">Assigned</h2>
                            <div className="relative mb-3">
                                <Search className="absolute top-[8px] left-2 w-4 h-4 text-gray-400" />
                                <input
                                    type="search"
                                    placeholder="Search ITV..."
                                    value={searchAssigned}
                                    onChange={(e) => setSearchAssigned(e.target.value)}
                                    className="w-full focus:outline-none px-1 py-1 pl-8 text-gray-700 border border-gray-300 rounded-md"
                                />
                            </div>
                            <div className="flex items-center gap-2 mb-2">
                                <Checkbox
                                    className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                                    checked={filteredAssigned.length > 0 &&
                                        selectedAssigned.length === filteredAssigned.length}
                                    onCheckedChange={(checked: boolean) =>
                                        handleSelectAll('assignedEquipments', checked)
                                    }
                                />
                                <span className={`text-sm ${selectedAssigned.length === filteredAssigned.length ? 'text-blue-600 font-semibold' : 'text-gray-400'}`}>
                                    Select All
                                </span>
                            </div>
                            <ul className="space-y-2 overflow-y-auto max-h-[calc(100%-120px)] pr-2">
                                {filteredAssigned.map(item => (
                                    <li key={item.id} className="flex items-center gap-2">
                                        <Checkbox
                                            checked={selectedAssigned.includes(item.equipmentName)}
                                            onCheckedChange={(checked) =>
                                                checked
                                                    ? setSelectedAssigned([...selectedAssigned, item.equipmentName])
                                                    : setSelectedAssigned(
                                                        selectedAssigned.filter(id => id !== item.equipmentName)
                                                    )
                                            }
                                            className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                                        />
                                        <span className={`${selectedAssigned.includes(item.equipmentName) ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
                                            {item.equipmentName}
                                        </span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>


                    <div className="flex flex-col items-center justify-center space-y-4">
                        <Button
                            onClick={moveToUnassigned}
                            disabled={selectedAssigned.length === 0}
                            variant="outline"
                            className="bg-[#0c8ce9] hover:bg-[#0c8ce9] text-white"
                        >
                            <HiOutlineArrowRight />
                        </Button>
                        <Button
                            onClick={moveToAssigned}
                            disabled={selectedUnassigned.length === 0}
                            variant="outline"
                            className="bg-[#0c8ce9] hover:bg-[#0c8ce9] text-white"
                        >
                            <HiOutlineArrowLeft />
                        </Button>
                    </div>

                    <Card className="flex flex-col flex-1">
                        <CardContent className="flex-1 p-4 overflow-hidden">
                            <h2 className="mb-2 font-semibold">Unassigned</h2>
                            <div className="relative mb-3">
                                <Search className="absolute top-[8px] left-2 w-4 h-4 text-gray-400" />
                                <input
                                    type="search"
                                    placeholder="Search ITV..."
                                    value={searchUnassigned}
                                    onChange={(e) => setSearchUnassigned(e.target.value)}
                                    className="w-full focus:outline-none px-1 py-1 pl-8 text-gray-700 border border-gray-300 rounded-md"
                                />
                            </div>
                            <div className="flex items-center gap-2 mb-2">
                                <Checkbox
                                    checked={filteredUnassigned.length > 0 &&
                                        filteredUnassigned.length !== filterUnassignAvailCount.length &&
                                        selectedUnassigned.length === (filteredUnassigned.length - filterUnassignAvailCount.length)}
                                    onCheckedChange={(checked: boolean) =>
                                        handleSelectAll('unAssignedEquipments', checked)
                                    }
                                    className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                                />
                                <span className={`text-sm ${selectedUnassigned.length === filteredUnassigned.length ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
                                    Select All
                                </span>
                            </div>
                            <ul className="space-y-2 overflow-y-auto max-h-[calc(100%-120px)] pr-2">
                                {filteredUnassigned.map(item => (
                                    <li key={item.id} className="flex items-center gap-2">
                                        <Checkbox
                                            checked={selectedUnassigned.includes(item.equipmentName)}
                                            onCheckedChange={(checked) =>
                                                checked
                                                    ? setSelectedUnassigned([...selectedUnassigned, item.equipmentName])
                                                    : setSelectedUnassigned(
                                                        selectedUnassigned.filter(id => id !== item.equipmentName)
                                                    )
                                            }
                                            disabled={isValidValue(item.assignedPool)}
                                            className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                                        />
                                        {isValidValue(item.assignedPool) ? (
                                            <span className="flex items-center text-gray-400">
                                                {item.equipmentName}
                                                <span className="px-2 ml-2 text-sm font-light text-red-600 bg-red-200/50 rounded-md">
                                                    {item.assignedPool}
                                                </span>
                                            </span>
                                        ) : (
                                            <span className={`${selectedUnassigned.includes(item.equipmentName) ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
                                                {item.equipmentName}
                                            </span>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                </div>
                <div className="flex justify-end mb-2">
                    <Button
                        onClick={handleUpdate}
                        className="h-[30px] text-white text-sm"
                    >
                        Update
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}
