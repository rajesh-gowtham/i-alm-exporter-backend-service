import { EditableCell } from "@/components/EditableCell";
import FileImportManipulate from "@/components/FileImportManipulate";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ErrorToaster, FileImport, SuccessToaster } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { EquipmentPoolLabels } from "@/lib/models/form-constants/formLabels";
import { EquipmentPoolSchema, FileImportSchema } from "@/lib/schemas";
import { addEquipmentPoolInBatch } from "@/lib/services/equipmentpool-services";
import { zodResolver } from "@hookform/resolvers/zod";
import { ReloadIcon } from "@radix-ui/react-icons";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router";
import * as XLSX from "xlsx";
import { z } from "zod";
// Enhanced schema with coercion and validation

type EquipmentPoolRecord = z.infer<typeof EquipmentPoolSchema>;
type FormData = z.infer<typeof FileImportSchema>;
const requiredBackendFields = ["poolName"];
const headerMap: Record<typeof EquipmentPoolLabels[keyof typeof EquipmentPoolLabels], string> = {
  [EquipmentPoolLabels._PoolName]: "poolName",
};
interface EquipmentPoolImportProps {
  handleImportError: (arg: any[]) => void;
  errorList: any[];
  setColumns: (arg: any) => void;
  setTableData: (arg: any) => void;
  columns: any[];
  tableData: any[];
  openCloseImport: (arg: string) => void;
  setIsImportError: (arg: boolean) => void;
}
export default function EquipmentPoolImport({ handleImportError, errorList, setColumns, setTableData, columns, tableData, openCloseImport, setIsImportError }: EquipmentPoolImportProps) {

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<EquipmentPoolRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(errorList.length > 0);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);
  // const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  // const [columns, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);
  const navigate = useNavigate();


  const batchInsert = async (records: EquipmentPoolRecord[]) => {
    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;
      for (let i = 0; i < records.length; i += batchSize) {
        const batch = records.slice(i, i + batchSize);
        await addEquipmentPoolInBatch(batch);
        const progress = Math.min(100, ((i + batch.length) / totalRecords) * 100);
        setImportProgress(progress);
        await new Promise((r) => setTimeout(r, 100));
      }

      SuccessToaster("Import Completed", `${totalRecords} EquipmentPool imported successfully`);
      // navigate(privateRoute._Configuration + privateRoute._Equipmentpool);
      openCloseImport("CLEAR-SUCCESS");
      setIsImportError(false);
    } catch (error) {
      ErrorToaster("Import Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
      setShowConfirmModal(true);
    } finally {
      setBatchProcessing(false);
      setImportProgress(0);
      // setShowConfirmModal(false);
      reset();
    }
  };

  const updateData = (rowIndex: number, columnId: string, value: any) => {
    setTableData(prev =>
      prev.map((row, index) => {
        if (index === rowIndex) {
          return {
            ...row,
            [columnId]: value,
          };
        }
        return row;
      })
    );
  };

  useEffect(() => {
    if (tableData.length === 0) return;

    const validationResults = tableData.map((row, index) => {
      const result = EquipmentPoolSchema.safeParse(row);
      return {
        row: index + 2,
        valid: result.success,
        errors: result.success ? [] : result.error.errors,
        data: result.success ? result.data : null
      };
    });

    const valid = validationResults.filter(r => r.valid).map(r => r.data) as EquipmentPoolRecord[];
    const errors = validationResults.filter(r => !r.valid).map(r => ({
      row: r.row,
      issues: r.errors,
      original: tableData[r.row - 2]
    }));

    setValidRecords(valid);
    setValidationErrors(errors);
  }, [tableData]);


  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const [headerRow, ...rows] = jsonData;
        const headers = headerRow as string[];

        const errors: string[] = [];

        for (const readableHeader in headerMap) {
          const backendKey = headerMap[readableHeader];
          if (!headers.includes(readableHeader)) {
            if (requiredBackendFields.includes(backendKey)) {
              errors.push(`Missing required column: ${readableHeader}`);
            }
          }
        }

        const unknownHeaders = headers.filter(h => !headerMap[h]);
        if (unknownHeaders.length > 0) {
          unknownHeaders.forEach(h => errors.push(`Unknown column found: ${h}`));
        }

        if (errors.length > 0) {
          ErrorToaster("File validation failed:\n" + errors.join("\n"));
          // Don't return — continue to extract raw data
        }

        // 1. Extract raw data even if invalid
        const extractedData = rows.map((row) =>
          headers.reduce((obj, readableHeader, idx) => {
            const backendKey = headerMap[readableHeader];
            if (backendKey) {
              obj[backendKey] = row[idx] ?? '';
            }
            return obj;
          }, {} as Record<string, any>)
        );

        let errorCount = 0;
        const validRowsToInsert = [];
        const validatedRows = extractedData.map((row, index) => {
          console.log(" row ", row);
          const result = EquipmentPoolSchema.safeParse(row);
          console.log(" result ", result);
          if (result.success) {
            validRowsToInsert.push(result.data);
            return { ...result.data, __rowValid: true };
          } else {
            errorCount += 1;
            return {
              ...row,
              __rowValid: false,
              __rowErrors: result.error.flatten().fieldErrors,
              __rowIndex: index + 2, // Excel row index
            };
          }
        });

        // 3. Set for editable table
        const newColumns = Object.keys(headerMap).map((readableHeader) => ({
          Header: readableHeader,
          accessor: headerMap[readableHeader],
        }));

        setColumns(newColumns);
        setTableData(validatedRows);
        // setShowConfirmModal(true);
        console.log("validatedRows", errorCount, validatedRows);
        if (errorCount === 0) {
          // const dataInset = validatedRows as VesselRecord[]
          batchInsert(validRowsToInsert as EquipmentPoolRecord[])
        } else {
          handleImportError(validatedRows);
        }
      } catch (error) {
        console.error(error);
        ErrorToaster("Failed to process file: " + (error as any).message);
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  // const processExcelFile = (file: File) => {
  //   const reader = new FileReader();
  //   reader.onload = (e) => {
  //     const binary = e.target?.result;
  //     const workbook = XLSX.read(binary, { type: "binary" });
  //     const sheet = workbook.Sheets[workbook.SheetNames[0]];

  //     const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
  //     const [headerRow, ...rows] = jsonData;
  //     const headers = headerRow as string[];

  //     const newColumns = headers.map((header) => ({
  //       Header: header,
  //       accessor: header,
  //     }));
  //     setColumns(newColumns);

  //     const newData = rows.map((row) =>
  //       headers.reduce((obj, header, idx) => ({
  //         ...obj,
  //         [header]: row[idx] ?? '',
  //       }), {})
  //     );
  //     setTableData(newData);
  //     setShowConfirmModal(true);
  //     setUploading(false);
  //   };
  //   reader.readAsBinaryString(file);
  // };

  const renderTable = () => (
    <div className="overflow-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {columns.map((column) => (
              <th
                key={column.accessor}
                className="sticky top-0 p-2 text-left border border-gray-200 bg-muted"
              >
                {column.Header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, rowIndex) => {
            const isInvalid = validationErrors.some(e => e.row === rowIndex + 2);
            return (
              <tr
                key={rowIndex}
                className={isInvalid ? 'bg-muted hover:bg-red-100' : ''}
              >
                {columns.map((column) => {
                  // const isNumeric = numericFields.includes(column.accessor);
                  return (
                    <td key={column.accessor} className="border border-gray-200">
                      <EditableCell
                        value={row[column.accessor]}
                        row={{ index: rowIndex }}
                        column={{ id: column.accessor }}
                        isNumeric={false}
                        updateData={updateData}
                      />
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  return (

    < div >
      <FileImport
        errors={errors}
        handleSubmit={handleSubmit}
        processExcelFile={processExcelFile}
        register={register}
        setUploading={setUploading}
        uploading={uploading}
        backToParent={openCloseImport}
        filename="equipmentpoolmaster.xlsx"
      />

      <Dialog
        open={showConfirmModal}
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
         <DialogContent className="max-w-[95vw] h-[85vh] overflow-auto flex flex-col p-0">
          <FileImportManipulate
            columns={columns}
            tableData={tableData}
            updateData={updateData}
            validationErrors={validationErrors}
            validRecords={validRecords}
            batchProcessing={batchProcessing}
            setShowConfirmModal={setShowConfirmModal}
            importProgress={importProgress}
            batchInsert={batchInsert}
          />
        </DialogContent>
      </Dialog>
    </div >
  );
}