"use client";

import FileImportManipulate from "@/components/FileImportManipulate";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ErrorToaster, FileImport, SuccessToaster } from "@/components/UtilComp";
import { DeviceAssetLabels } from "@/lib/models/form-constants/formLabels";
import { FileImportSchema, createDeviceAssetSchema } from "@/lib/schemas";
import { addDeviceAssetsInBatch } from "@/lib/services/device-asset-service";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as XLSX from "xlsx";
import { z } from "zod";

const requiredBackendFields = [
  "Device ID",
  "Manufacturer",
  "Model",
  "Firmware Version",
  "Communication Protocol",
  "Device Type",
  "Power Source",
  "Warranty Start Date",
  "Warranty Expiry Date",
];

const headerMap: Record<typeof DeviceAssetLabels[keyof typeof DeviceAssetLabels], string> = {
  [DeviceAssetLabels._DeviceId]: "Device ID",
  [DeviceAssetLabels._Manufacturer]: "Manufacturer",
  [DeviceAssetLabels._Model]: "Model",
  [DeviceAssetLabels._FirmwareVersion]: "Firmware Version",
  [DeviceAssetLabels._Device_Type]: "Device Type",
  [DeviceAssetLabels._Communication_Protocol]: "Communication Protocol",
  [DeviceAssetLabels._Power_Source]: "Power Source",
  [DeviceAssetLabels._warrantyStartDate]: "Warranty Start Date",
  [DeviceAssetLabels._warrantyExpiryDate]: "Warranty Expiry Date",
};

const BulkDeviceAssetSchema = createDeviceAssetSchema(true);

const uiToBackendMap: Record<string, string> = {
  "Device ID": "deviceId",
  "Manufacturer": "manufacturer",
  "Model": "model",
  "Firmware Version": "firmwareVersion",
  "Device Type": "deviceType",
  "Communication Protocol": "communicationProtocol",
  "Power Source": "powerSource",
  "Warranty Start Date": "warrantyStartDate",
  "Warranty Expiry Date": "warrantyExpiryDate",
};

// Excel serial date -> JS Date
const excelDateToJSDate = (serial: number) =>
  new Date((serial - 25569) * 86400 * 1000);

const transformRow = (row: Record<string, any>) => {
  const result: Record<string, any> = {};
  for (const key in row) {
    if (key.startsWith("__")) continue;
    const backendKey = uiToBackendMap[key];
    if (!backendKey) continue;

    let value = row[key];
    if (backendKey === "firmwareVersion") value = String(value);
    if (backendKey === "warrantyStartDate" || backendKey === "warrantyExpiryDate") {
      value = typeof value === "number" ? excelDateToJSDate(value) : new Date(value);
    }
    result[backendKey] = value;
  }
  return result;
};

type DeviceAssetRecord = z.infer<typeof BulkDeviceAssetSchema>;
type FormData = z.infer<typeof FileImportSchema>;

interface DeviceAssetsImportProps {
  handleImportError: (arg: any[]) => void;
  errorList: any[];
  setColumns: (arg: any) => void;
  setTableData: (arg: any) => void;
  columns: any[];
  tableData: any[];
  openCloseImport: (arg: string) => void;
  setIsImportError: (arg: boolean) => void;
}

export default function DeviceAssetsImport({
  handleImportError,
  errorList,
  setColumns,
  setTableData,
  columns,
  tableData,
  openCloseImport,
  setIsImportError,
}: DeviceAssetsImportProps) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<DeviceAssetRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(errorList.length > 0);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);

  /** ------------ Batch Insert ------------ */
  const batchInsert = async (records: DeviceAssetRecord[]) => {
    if (!records.length) {
      ErrorToaster("Import Failed", "No valid records to import");
      return;
    }

    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;

      for (let i = 0; i < totalRecords; i += batchSize) {
        const batch = records.slice(i, i + batchSize).map((record) => ({
          ...record,
          warrantyStartDate: record.warrantyStartDate instanceof Date
            ? record.warrantyStartDate.toISOString()
            : record.warrantyStartDate,
          warrantyExpiryDate: record.warrantyExpiryDate instanceof Date
            ? record.warrantyExpiryDate.toISOString()
            : record.warrantyExpiryDate,
        }));

        await addDeviceAssetsInBatch(batch);

        setImportProgress(Math.min(100, ((i + batch.length) / totalRecords) * 100));
        await new Promise((r) => setTimeout(r, 100));
      }

      SuccessToaster("Import Completed", `${records.length} Telematics Devices imported successfully`);
      openCloseImport("CLEAR-SUCCESS");
      setIsImportError(false);
    } catch (error: any) {
      ErrorToaster("Import Failed", error?.response?.data || "Unknown error occurred");
      setShowConfirmModal(true);
    } finally {
      setBatchProcessing(false);
      setImportProgress(0);
      reset();
    }
  };

  /** ------------ Table Cell Update ------------ */
  const updateData = async (rowIndex: number, columnId: string, value: any) => {
    const updatedRows = [...tableData];
    const updatedRow = { ...updatedRows[rowIndex], [columnId]: value };

    const transformed = transformRow(updatedRow);
    const result = await BulkDeviceAssetSchema.safeParseAsync(transformed);

    if (result.success) {
      updatedRows[rowIndex] = {
        ...updatedRow,
        __rowValid: true,
        __rowErrors: {},
        __backendData: result.data,
      };
    } else {
      updatedRows[rowIndex] = {
        ...updatedRow,
        __rowValid: false,
        __rowErrors: result.error.flatten().fieldErrors,
        __backendData: undefined,
      };
    }

    setTableData(updatedRows);
  };

  /** ------------ Validate Table Data (Initial) ------------ */
  useEffect(() => {
    if (!tableData.length) return;
    (async () => {
      const validationResults = await Promise.all(
        tableData.map(async (row, index) => {
          const transformed = transformRow(row);
          const result = await BulkDeviceAssetSchema.safeParseAsync(transformed);
          return {
            row: index + 2,
            valid: result.success,
            errors: result.success ? [] : result.error.errors,
            data: result.success ? result.data : null,
          };
        })
      );

      const validRows = validationResults.filter((r) => r.valid).map((r) => r.data) as DeviceAssetRecord[];
      const invalidRows = validationResults.filter((r) => !r.valid);

      setValidRecords(validRows);
      setValidationErrors(
        invalidRows.map((r) => ({
          row: r.row,
          issues: r.errors,
          original: tableData[r.row - 2],
        }))
      );

      if (invalidRows.length === 0 && validRows.length > 0) {
        setShowConfirmModal(true);
      }
    })();
  }, [tableData]);

  /** ------------ Validate Excel Headers ------------ */
  const validateHeaders = (headers: string[]) => {
    const errors: string[] = [];
    for (const readableHeader in headerMap) {
      const backendKey = headerMap[readableHeader as keyof typeof headerMap];
      if (!headers.includes(readableHeader) && requiredBackendFields.includes(backendKey)) {
        errors.push(`Missing required column: ${readableHeader}`);
      }
    }
    headers
      .filter((h) => !(h in headerMap))
      .forEach((h) => errors.push(`Unknown column found: ${h}`));

    if (errors.length) ErrorToaster("File validation failed:\n" + errors.join("\n"));
    return errors.length === 0;
  };

  /** ------------ Process Excel ------------ */
  const processExcelFile = (file: File) => {
    setUploading(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const workbook = XLSX.read(e.target?.result as string, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        const [headerRow, ...rows] = jsonData;
        const headers = headerRow as string[];

        if (!validateHeaders(headers)) return setUploading(false);

        // FIX: Convert Excel serial dates to ISO string immediately
        const extractedData = rows.map((row) =>
          headers.reduce((obj, readableHeader, idx) => {
            let cellValue = row[idx] ?? "";
            if (
              (readableHeader === "Warranty Start Date" || readableHeader === "Warranty Expiry Date") &&
              typeof cellValue === "number"
            ) {
              cellValue = excelDateToJSDate(cellValue).toISOString().split("T")[0];
            }
            obj[readableHeader] = cellValue;
            return obj;
          }, {} as Record<string, any>)
        );

        let errorCount = 0;
        const validatedRows = await Promise.all(
          extractedData.map(async (row, index) => {
            const transformed = transformRow(row);
            const result = await BulkDeviceAssetSchema.safeParseAsync(transformed);

            if (result.success) {
              return {
                ...row,
                __rowValid: true,
                __backendData: result.data,
              };
            }

            errorCount++;
            return {
              ...row,
              __rowValid: false,
              __rowErrors: result.error.flatten().fieldErrors,
              __rowIndex: index + 2,
            };
          })
        );

        setColumns(
          Object.keys(headerMap).map((readableHeader) => ({
            Header: readableHeader,
            accessor: readableHeader,
          }))
        );
        setTableData(validatedRows);

        if (errorCount === 0) {
          batchInsert(validatedRows.map(r => r.__backendData));
        } else {
          handleImportError(validatedRows);
          setShowConfirmModal(true);
        }
      } catch (error: any) {
        ErrorToaster("Failed to process file: " + error.message);
      } finally {
        setUploading(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div>
      <FileImport
        errors={errors}
        handleSubmit={handleSubmit}
        processExcelFile={processExcelFile}
        register={register}
        setUploading={setUploading}
        uploading={uploading}
        backToParent={openCloseImport}
        filename="TelematicsDeviceAssetmaster.xlsx"
      />

      <Dialog
        open={showConfirmModal}
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
        <DialogContent className="max-w-[95vw] h-[85vh] overflow-auto flex flex-col p-0">
          <FileImportManipulate
            columns={columns}
            tableData={tableData}
            updateData={updateData}
            validationErrors={validationErrors}
            validRecords={validRecords}
            batchProcessing={batchProcessing}
            setShowConfirmModal={setShowConfirmModal}
            importProgress={importProgress}
            batchInsert={() =>
              batchInsert(tableData.filter(r => r.__rowValid).map(r => r.__backendData))
            }
            numericFields={[]}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
