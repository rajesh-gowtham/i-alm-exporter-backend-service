import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { CommunicationProtocol, CommunicationProtocolDisplay, DeviceAsset, DeviceType, DeviceTypeDisplay, PowerSource, PowerSourceDisplay } from "@/lib/models";
import { DeviceAssetLabels } from "@/lib/models/form-constants/formLabels";
import { createDeviceAssetSchema /* , DeviceAssetSchema  */} from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import * as z from "zod";

const normalizeDate = (date: string | Date) => {
  const d = new Date(date);
  d.setUTCHours(0, 0, 0, 0);  // set time to 00:00:00 UTC
  return d.toISOString();
};

interface DeviceAssetFormProps {
  DeviceAsset?: DeviceAsset;
  onClose: () => void;
  onSubmit: (data: DeviceAsset) => void;
}

export default function DeviceAssetForm({
  DeviceAsset,
  onClose,
  onSubmit,
}: DeviceAssetFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const DeviceAssetSchema = createDeviceAssetSchema(false);
  const {
    register,
    reset,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<z.infer<typeof DeviceAssetSchema>>({
    resolver: zodResolver(DeviceAssetSchema),
    defaultValues: DeviceAsset
      ? {
        ...DeviceAsset,
        id: DeviceAsset.id != null ? String(DeviceAsset.id) : undefined,
        firmwareVersion:
          DeviceAsset.firmwareVersion !== undefined
            ? String(DeviceAsset.firmwareVersion)
            : undefined,
        warrantyStartDate:
          DeviceAsset.warrantyStartDate
            ? typeof DeviceAsset.warrantyStartDate === "string"
              ? new Date(DeviceAsset.warrantyStartDate)
              : DeviceAsset.warrantyStartDate
            : undefined,
        warrantyExpiryDate:
          DeviceAsset.warrantyExpiryDate
            ? typeof DeviceAsset.warrantyExpiryDate === "string"
              ? new Date(DeviceAsset.warrantyExpiryDate)
              : DeviceAsset.warrantyExpiryDate
            : undefined,
      }
      : {},
  });

  const DeviceAssetMemo = useMemo(() => DeviceAsset, [DeviceAsset]);

  useEffect(() => {
    if (DeviceAssetMemo) {
      reset({
        ...DeviceAssetMemo,
        id: DeviceAssetMemo.id ? DeviceAssetMemo.id.toString() : undefined,
        firmwareVersion: DeviceAssetMemo.firmwareVersion !== undefined ? String(DeviceAssetMemo.firmwareVersion) : undefined,
        warrantyStartDate: DeviceAssetMemo.warrantyStartDate ? new Date(DeviceAssetMemo.warrantyStartDate) : undefined,
        warrantyExpiryDate: DeviceAssetMemo.warrantyExpiryDate ? new Date(DeviceAssetMemo.warrantyExpiryDate) : undefined,
      });
    }
  }, [DeviceAssetMemo, reset]);

  const submitHandler = async (formData: z.infer<typeof DeviceAssetSchema>) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      // Ensure warrantyExpiryDate is present in the submitted data
      const completeFormData: DeviceAsset = {
        ...formData,
        id: DeviceAsset?.id ? DeviceAsset.id : undefined,
        deviceType: formData.deviceType !== undefined ? String(formData.deviceType) : "",
        communicationProtocol: formData.communicationProtocol !== undefined ? String(formData.communicationProtocol) : "",
        powerSource: formData.powerSource !== undefined ? String(formData.powerSource) : "",
        firmwareVersion: formData.firmwareVersion !== undefined ? String(formData.firmwareVersion) : "",
        warrantyStartDate: formData.warrantyStartDate ? normalizeDate(formData.warrantyStartDate) : "",
        warrantyExpiryDate: formData.warrantyExpiryDate ? normalizeDate(formData.warrantyExpiryDate) : "",
      };
      await onSubmit(completeFormData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">

        <div>
          <Label>{DeviceAssetLabels._DeviceId}</Label>
          <MandatoryIcon />
          <Input {...register("deviceId")}
            error={!!errors.deviceId}
            // disabled={DeviceAsset !== undefined}
          />
          {errors.deviceId && (
            <span className="text-sm text-red-500">{errors.deviceId.message?.toString()}</span>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._Manufacturer}</Label>
          <MandatoryIcon />
          <Input  {...register("manufacturer")}
            error={!!errors.manufacturer}
          />
          {errors.manufacturer && (
            <span className="text-sm text-red-500">{errors.manufacturer.message?.toString()}</span>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._Model}</Label>
          <MandatoryIcon />
          <Input {...register("model")}
            error={!!errors.model}
          />
          {errors.model && (
            <span className="text-sm text-red-500">{errors.model.message?.toString()}</span>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._FirmwareVersion}</Label>
          <MandatoryIcon />
          <Input {...register("firmwareVersion")}
            error={!!errors.firmwareVersion}
          />
          {errors.firmwareVersion && (
            <span className="text-sm text-red-500">{errors.firmwareVersion.message?.toString()}</span>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._Device_Type}</Label>
          <MandatoryIcon />
          <Controller
            name="deviceType"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value}>
                <SelectTrigger
                  id="deviceType"
                  className={errors.deviceType ? "border-red-500" : ""}
                >
                  <SelectValue placeholder="Select device type" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(DeviceType).map(([key]) => (
                    <SelectItem key={key} value={key}>
                      {DeviceTypeDisplay[key as DeviceType]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />

          {errors.deviceType && (
            <span className="text-sm text-red-500">{errors.deviceType.message?.toString()}</span>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._Communication_Protocol}</Label>
          <MandatoryIcon />
          <Controller
            name="communicationProtocol"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value}>
                <SelectTrigger
                  id="communicationProtocol"
                  className={errors.communicationProtocol ? "border-red-500" : ""}
                >
                  <SelectValue placeholder="Select communication protocol" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CommunicationProtocol).map(([key]) => (
                    <SelectItem key={key} value={key}>
                      {CommunicationProtocolDisplay[key as CommunicationProtocol]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
          {errors.communicationProtocol && (
            <p className="text-sm text-red-500">{errors.communicationProtocol.message?.toString()}</p>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._Power_Source}</Label>
          <MandatoryIcon />
          <Controller
            name="powerSource"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value}>
                <SelectTrigger
                  id="powerSource"
                  className={errors.powerSource ? "border-red-500" : ""}
                >
                  <SelectValue placeholder="Select power source" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PowerSource).map(([key]) => (
                    <SelectItem key={key} value={key}>
                      {PowerSourceDisplay[key as PowerSource]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />

          {errors.powerSource && (
            <p className="text-sm text-red-500">{errors.powerSource.message?.toString()}</p>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._warrantyStartDate}</Label>
          <MandatoryIcon />

          <Controller
            name="warrantyStartDate"
            control={control}
            render={({ field }) => (
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={`w-full justify-start text-left font-normal ${!field.value ? "text-muted-foreground" : ""
                      } ${errors.warrantyStartDate ? "border-red-500" : ""}`}
                  >
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {field.value ? format(field.value, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value ? new Date(field.value) : undefined}
                    onSelect={field.onChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            )}
          />

          {errors.warrantyStartDate && (
            <p className="text-sm text-red-500">
              {errors.warrantyStartDate.message?.toString()}
            </p>
          )}
        </div>
        <div>
          <Label>{DeviceAssetLabels._warrantyExpiryDate}</Label>
          <MandatoryIcon />
          <Controller
            name="warrantyExpiryDate"
            control={control}
            render={({ field }) => (
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={`w-full justify-start text-left font-normal ${!field.value ? "text-muted-foreground" : ""
                      } ${errors.warrantyExpiryDate ? "border-red-500" : ""}`}
                  >
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {field.value ? format(field.value, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            )}
          />

          {errors.warrantyExpiryDate && (
            <p className="text-sm text-red-500">
              {errors.warrantyExpiryDate.message?.toString()}
            </p>
          )}
        </div>
      </div>
      <FormActions
        isEdit={DeviceAsset?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
