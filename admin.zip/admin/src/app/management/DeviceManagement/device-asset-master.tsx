import SubHeader from "@/components/SubHeader";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { DeviceAsset } from "@/lib/models";
import { DeviceAssetLabels } from "@/lib/models/form-constants/formLabels";
import {
  addDeviceAsset,
  addDeviceAssetsInBatch,
  deleteDeviceAsset,
  editDeviceAsset,
  fetchDeviceAssets
} from "@/lib/services/device-asset-service";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useDeviceAssetStore from "../store/DeviceAssetsStore";
import DeviceAssetsImport from "./device-assest-import";
import DeviceAssetForm from "./device-asset-form";

export default function DeviceAssetMaster() {
  const [DeviceAsset, setDeviceAsset] = useState<DeviceAsset[]>([]);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  const [totalRecord, setTotalRecord] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [DeviceAssetToEdit, setDeviceAssetToEdit] = useState<DeviceAsset | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [DeviceAssetToDelete, setDeviceAssetToDelete] = useState<DeviceAsset | undefined>(undefined);
  const DeviceAssetStore = useDeviceAssetStore();
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const columnsConfig = [
    { key: "deviceId", title: DeviceAssetLabels._DeviceId, hidden: false },
    { key: "manufacturer", title: DeviceAssetLabels._Manufacturer, hidden: false },
    { key: "model", title: DeviceAssetLabels._Model, hidden: false },
    { key: "firmwareVersion", title: DeviceAssetLabels._FirmwareVersion, hidden: false },
    { key: "deviceType", title: DeviceAssetLabels._Device_Type, hidden: false },
    { key: "communicationProtocol", title: DeviceAssetLabels._Communication_Protocol, hidden: false },
    { key: "powerSource", title: DeviceAssetLabels._Power_Source, hidden: true },
    { key: "warrantyStartDate", title: DeviceAssetLabels._warrantyStartDate, hidden: true },
    // { key: "readPointName", title: DeviceAssetLabels._ReadPoint_ID, hidden: true },
    { key: "warrantyExpiryDate", title: DeviceAssetLabels._warrantyExpiryDate, hidden: true },

  ];

  const columns: ColumnDef<DeviceAsset>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: false,
      // enableSorting: false,
      meta: { hidden }
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: DeviceAsset } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];
  const handlePaginationChange = (newPagination: PaginationState) => {
    console.log("newPagination", newPagination);
    setPaged(newPagination);
  };

  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchDeviceAssets(skip, take, search);

      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      // const totalCount = data?.totalItems ?? 0;
      setTotalRecord(totalCount as number);
      setDeviceAsset(items as DeviceAsset[]);
      // console.log("Fetched Device Assets:", data);
      DeviceAssetStore.setDeviceAsset(items as DeviceAsset[]);
    }
    finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [paged]);

  const handleEdit = (DeviceAsset: DeviceAsset) => {
    setDeviceAssetToEdit(DeviceAsset);
    setOpen(true);
  };

  const handleDeleteClick = (DeviceAsset: DeviceAsset) => {
    setDeviceAssetToDelete(DeviceAsset);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (DeviceAssetToDelete?.id) {
        // setLoading(true);
        await deleteDeviceAsset(DeviceAssetToDelete.id.toString());
      }
      setLoading(false);
      await fetchData();
      SuccessToaster("", "Telematics Device deleted successfully");
      mutate("DeviceAsset");
    }
    catch (error) {
      console.error(error);
      ErrorToaster("Telematics Device Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally {
      setConfirmDeleteOpen(false);
    }

  };

  const handleSubmit = async (data: Omit<DeviceAsset, "id" | "createdBy" | "updatedBy" | "createdAt" | "updatedAt">
  ) => {
    try {
      if (DeviceAssetToEdit?.id) {
        setLoading(true);
        console.log("Editing device asset:", data);
        console.log("DeviceAssetToEdit:", DeviceAssetToEdit);
        await editDeviceAsset(DeviceAssetToEdit.id.toString(), data);
        SuccessToaster("", "Telematics Device updated successfully");
      } else {
        // await (data);
        console.log("Creating new device asset:", data);
        await addDeviceAsset(data);
        SuccessToaster("", "Telematics Device created successfully");
      }
      setOpen(false);
      setDeviceAssetToEdit(undefined);
      await fetchData();
      mutate("DeviceAsset");
    } catch (error) {
      ErrorToaster(
        (typeof error === "object" && error !== null && "response" in error && (error as any).response?.data)
          ? (error as any).response.data
          : "Unknown error occurred"
      )
    } finally {
      setLoading(false);
    }
  }

  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      fetchData();
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?

        <div>
          <SubHeader
            placeholder="Device Name..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            onAddClickOpen={setOpen}
            setComponentToEdit={setDeviceAssetToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            isImportBtnDisabled={ false }
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={DeviceAsset || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          {confirmDeleteOpen &&
            <DeleteConfirmModelUI
              isModelOpen={confirmDeleteOpen}
              loading={loading}
              onConfirmDeleteClick={confirmDelete}
              setIsModelOpen={setConfirmDeleteOpen}
              selectedName={` Telemetry Device ${DeviceAssetToDelete?.deviceId} `}
            />
          }
          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setDeviceAssetToEdit(undefined);
            }}
          >
            <DialogContent>
              <DialogTitle>
                {DeviceAssetToEdit ? "Edit Telematics Device" : "Add Telematics Device"}
              </DialogTitle>
              <DeviceAssetForm
                DeviceAsset={DeviceAssetToEdit}
                onClose={() => {
                  setOpen(false);
                  setDeviceAssetToEdit(undefined);
                }}
                onSubmit={handleSubmit}
              />
            </DialogContent>
          </Dialog>
        </div>
        :
        <DeviceAssetsImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }
    </div>
  );
}
