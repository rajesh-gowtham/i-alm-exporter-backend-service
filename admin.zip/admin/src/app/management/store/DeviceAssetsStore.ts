import { create } from "zustand";
import { DeviceAsset } from "@/lib/models";

type State = {
    DeviceAsset: DeviceAsset[];
    selectedDeviceAsset: DeviceAsset | null;
};

type Actions = {
    setDeviceAsset: (DeviceAsset: DeviceAsset[]) => void;
    addDeviceAsset: (DeviceAsset: DeviceAsset) => void;
    updateDeviceAsset: (id: string, updatedDeviceAsset: DeviceAsset) => void;
    deleteDeviceAsset: (id: string) => void;
    setSelectedDeviceAsset: (DeviceAsset: DeviceAsset | null) => void;
};

const initialState: State = {
    DeviceAsset: [],
    selectedDeviceAsset: null,
};

const useDeviceAssettore = create<State & Actions>()((set) => ({
    ...initialState,

    setDeviceAsset: (DeviceAsset) => set({ DeviceAsset }),

    addDeviceAsset: (DeviceAsset) =>
        set((state) => ({ DeviceAsset: [...state.DeviceAsset, DeviceAsset] })),

    updateDeviceAsset: (id, updatedDeviceAsset) =>
        set((state) => ({
            DeviceAsset: state.DeviceAsset.map((v) => (v.id === id ? updatedDeviceAsset : v)),
        })),

    deleteDeviceAsset: (id) =>
        set((state) => ({
            DeviceAsset: state.DeviceAsset.filter((v) => v.id !== id),
        })),

    setSelectedDeviceAsset: (DeviceAsset) => set({ selectedDeviceAsset: DeviceAsset }),
}));

export default useDeviceAssettore;
