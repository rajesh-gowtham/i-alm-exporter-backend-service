import { create } from "zustand";
import { EquipmentPool } from "@/lib/models";

type State = {
  equipmentPools: EquipmentPool[];
  selectedEquipmentPool: EquipmentPool | null;
};

type Actions = {
  setEquipmentPools: (equipmentPools: EquipmentPool[]) => void;
  addEquipmentPool: (equipmentPool: EquipmentPool) => void;
  updateEquipmentPool: (id: string, updatedEquipmentPool: EquipmentPool) => void;
  deleteEquipmentPool: (id: string) => void;
  setSelectedEquipmentPool: (equipmentPool: EquipmentPool | null) => void;
};

const initialState: State = {
  equipmentPools: [],
  selectedEquipmentPool: null,
};

const useEquipmentPoolStore = create<State & Actions>()((set) => ({
  ...initialState,

  setEquipmentPools: (equipmentPools) => set({ equipmentPools }),

  addEquipmentPool: (equipmentPool) =>
    set((state) => ({ equipmentPools: [...state.equipmentPools, equipmentPool] })),

  updateEquipmentPool: (id, updatedEquipmentPool) =>
    set((state) => ({
      equipmentPools: state.equipmentPools.map((v: EquipmentPool) => (v.id === id ? updatedEquipmentPool : v)),
    })),

  deleteEquipmentPool: (id) =>
    set((state) => ({
      equipmentPools: state.equipmentPools.filter((v: EquipmentPool) => v.id !== id),
    })),

  setSelectedEquipmentPool: (equipmentPool) => set({ selectedEquipmentPool: equipmentPool }),
}));

export default useEquipmentPoolStore;
