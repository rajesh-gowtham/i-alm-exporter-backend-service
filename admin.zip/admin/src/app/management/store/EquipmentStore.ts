import { create } from "zustand";
import { Equipment } from "@/lib/models";

type State = {
  equipments: Equipment[];
  selectedEquipment: Equipment | null;
};

type Actions = {
  setEquipments: (equipments: Equipment[]) => void;
  addEquipment: (equipment: Equipment) => void;
  updateEquipment: (id: string, updatedEquipment: Equipment) => void;
  deleteEquipment: (id: string) => void;
  setSelectedEquipment: (equipment: Equipment | null) => void;
};

const initialState: State = {
  equipments: [],
  selectedEquipment: null,
};

const useEquipmentStore = create<State & Actions>()((set) => ({
  ...initialState,

  setEquipments: (equipments) => set({ equipments }),

  addEquipment: (equipment) =>
    set((state) => ({ equipments: [...state.equipments, equipment] })),

  updateEquipment: (id, updatedEquipment) =>
    set((state) => ({
      equipments: state.equipments.map((v) => (v.id === id ? updatedEquipment : v)),
    })),

  deleteEquipment: (id) =>
    set((state) => ({
      equipments: state.equipments.filter((v) => v.id !== id),
    })),

  setSelectedEquipment: (equipment) => set({ selectedEquipment: equipment }),
}));

export default useEquipmentStore;
