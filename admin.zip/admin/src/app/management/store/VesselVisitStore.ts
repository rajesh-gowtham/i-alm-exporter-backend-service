import { create } from "zustand";
import { VesselVisit } from "@/lib/models";

type State = {
  vesselVisits: VesselVisit[];
  selectedVesselVisit: VesselVisit | null;
};

type Actions = {
  setVesselVisits: (vesselVisits: VesselVisit[]) => void;
  addVesselVisit: (vesselVisit: VesselVisit) => void;
  updateVesselVisit: (id: string, updatedVesselVisit: VesselVisit) => void;
  deleteVesselVisit: (id: string) => void;
  setSelectedVesselVisit: (vesselVisit: VesselVisit | null) => void;
};

const initialState: State = {
  vesselVisits: [],
  selectedVesselVisit: null,
};

const useVesselVisitStore = create<State & Actions>()((set) => ({
  ...initialState,

  setVesselVisits: (vesselVisits) => set({ vesselVisits: vesselVisits }),

  addVesselVisit: (vesselVisit) =>
    set((state) => ({ vesselVisits: [...state.vesselVisits, vesselVisit] })),

  updateVesselVisit: (id, updatedVesselVisit) =>
    set((state) => ({
      vesselVisits: state.vesselVisits.map((v) => (v.id === id ? updatedVesselVisit : v)),
    })),

  deleteVesselVisit: (id) =>
    set((state) => ({
      vesselVisits: state.vesselVisits.filter((v) => v.id !== id),
    })),

  setSelectedVesselVisit: (vesselVisit) => set({ selectedVesselVisit: vesselVisit }),
}));

export default useVesselVisitStore;
