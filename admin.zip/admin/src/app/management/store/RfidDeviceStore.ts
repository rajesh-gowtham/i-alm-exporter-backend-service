import { create } from "zustand";
import { RfidDevice } from "@/lib/models";

type State = {
    RfidDevice: RfidDevice[];
    selectedDeviceAsset: RfidDevice | null;
};

type Actions = {
    setRfidDevice: (RfidDevice: RfidDevice[]) => void;
    addRfidDevice: (RfidDevice: RfidDevice) => void;
    updateRfidDevice: (id: string, updatedDeviceAsset: RfidDevice) => void;
    deleteRfidDevice: (id: string) => void;
    setSelectedRfidDevice: (RfidDevice: RfidDevice | null) => void;
};

const initialState: State = {
    RfidDevice: [],
    selectedDeviceAsset: null,
};
const useRfidDeviceStore = create<State & Actions>()((set) => ({
  ...initialState,

  setRfidDevice: (RfidDevice) => set({ RfidDevice }),

  addRfidDevice: (RfidDevice) =>
    set((state) => ({ RfidDevice: [...state.RfidDevice, RfidDevice] })),

  updateRfidDevice: (id, updatedDeviceAsset) =>
    set((state) => ({
      RfidDevice: state.RfidDevice.map((v) => (v.id === id ? updatedDeviceAsset : v)),
    })),

  deleteRfidDevice: (id) =>
    set((state) => ({
      RfidDevice: state.RfidDevice.filter((v) => v.id !== id),
    })),

  setSelectedRfidDevice: (RfidDevice) => set({ selectedDeviceAsset: RfidDevice }),
}));


export default useRfidDeviceStore;
