import { create } from "zustand";
import { VesselBerthing } from "@/lib/models";

type State = {
  vesselBerthings: VesselBerthing[];
  selectedvesselBerthing: VesselBerthing | null;
};

type Actions = {
  setVesselBerthings: (vesselBerthings: VesselBerthing[]) => void;
  addVesselBerthing: (vesselBerthing: VesselBerthing) => void;
  updateVesselBerthing: (id: string, updatedvesselBerthing: VesselBerthing) => void;
  deleteVesselBerthing: (id: string) => void;
  setSelectedVesselBerthing: (vesselBerthing: VesselBerthing | null) => void;
};

const initialState: State = {
  vesselBerthings: [],
  selectedvesselBerthing: null,
};

const useVesselBerthingStore = create<State & Actions>()((set) => ({
  ...initialState,

  setVesselBerthings: (vesselBerthings) => set({ vesselBerthings }),

  addVesselBerthing: (vesselBerthing) =>
    set((state) => ({ vesselBerthings: [...state.vesselBerthings, vesselBerthing] })),

  updateVesselBerthing: (id, updatedvesselBerthing) =>
    set((state) => ({
      vesselBerthings: state.vesselBerthings.map((v) => (v.id === id ? updatedvesselBerthing : v)),
    })),

  deleteVesselBerthing: (id) =>
    set((state) => ({
      vesselBerthings: state.vesselBerthings.filter((v) => v.id !== id),
    })),

  setSelectedVesselBerthing: (vesselBerthing) => set({ selectedvesselBerthing: vesselBerthing }),
}));

export default useVesselBerthingStore;
