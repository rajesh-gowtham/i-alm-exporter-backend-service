import { create } from "zustand";

type ImportRecord = {
    id: number;
    timestamp: string;
    type: string;
    status: "Success" | "Failure";
    remark: string;
};

type State = {
    history: ImportRecord[];
    selectedRecord: ImportRecord | null;
};

type Actions = {
    setHistory: (history: ImportRecord[]) => void;
    addRecord: (record: ImportRecord) => void;
    updateRecord: (id: number, updatedRecord: ImportRecord) => void;
    deleteRecord: (id: number) => void;
    setSelectedRecord: (record: ImportRecord | null) => void;
    clearHistory: () => void;
};

const initialState: State = {
    history: [],
    selectedRecord: null,
};

export const useMasterDataStore = create<State & Actions>()((set) => ({
    ...initialState,

    setHistory: (history) => set({ history }),

    addRecord: (record) =>
        set((state) => ({ history: [...state.history, record] })),

    updateRecord: (id, updatedRecord) =>
        set((state) => ({
            history: state.history.map((r) => (r.id === id ? updatedRecord : r)),
        })),

    deleteRecord: (id) =>
        set((state) => ({
            history: state.history.filter((r) => r.id !== id),
        })),

    setSelectedRecord: (record) => set({ selectedRecord: record }),

    clearHistory: () => set({ history: [] }),
}));
