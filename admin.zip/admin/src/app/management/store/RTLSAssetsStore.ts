import { create } from "zustand";
import { RTLSAsset } from "@/lib/models";

type State = {
    RTLSAsset: RTLSAsset[];
    selectedRTLSAsset: RTLSAsset | null;
};

type Actions = {
    setRTLSAsset: (RTLSAsset: RTLSAsset[]) => void;
    addRTLSAsset: (RTLSAsset: RTLSAsset) => void;
    updateRTLSAsset: (id: string, updatedRTLSAsset: RTLSAsset) => void;
    deleteRTLSAsset: (id: string) => void;
    setSelectedRTLSAsset: (RTLSAsset: RTLSAsset | null) => void;
};

const initialState: State = {
    RTLSAsset: [],
    selectedRTLSAsset: null,
};

const useRTLSAssettore = create<State & Actions>()((set) => ({
    ...initialState,

    setRTLSAsset: (RTLSAsset) => set({ RTLSAsset }),

    addRTLSAsset: (RTLSAsset) =>
        set((state) => ({ RTLSAsset: [...state.RTLSAsset, RTLSAsset] })),

    updateRTLSAsset: (id, updatedRTLSAsset) =>
        set((state) => ({
            RTLSAsset: state.RTLSAsset.map((v) => (v.id === id ? updatedRTLSAsset : v)),
        })),

    deleteRTLSAsset: (id) =>
        set((state) => ({
            RTLSAsset: state.RTLSAsset.filter((v) => v.id !== id),
        })),

    setSelectedRTLSAsset: (RTLSAsset) => set({ selectedRTLSAsset: RTLSAsset }),
}));

export default useRTLSAssettore;
