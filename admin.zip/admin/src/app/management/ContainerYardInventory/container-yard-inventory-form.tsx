import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ContainerYardInventory } from "@/lib/models";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";
import { DateTimePicker } from "@/components/datetimepicker";
import { ContainerYardInventorySchema } from "@/lib/schemas";

interface ContainerYardInventoryFormProps {
  ContainerYardInventory?: ContainerYardInventory;
  onClose: () => void;
  onSubmit: (data: ContainerYardInventory) => void;
}

export default function ContainerYardInventoryForm({
  ContainerYardInventory,
  onClose,
  onSubmit,
}: ContainerYardInventoryFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  // console.log("vessel", vessel);
  const {
    register,
    setValue,
    watch,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<z.infer<typeof ContainerYardInventorySchema>>({
    resolver: zodResolver(ContainerYardInventorySchema),
    defaultValues: ContainerYardInventory || {},
  });
  const lastMove = watch("lastMove");

  const ContainerYardInventoryMemo = useMemo(
    () => ContainerYardInventory,
    [ContainerYardInventory]
  );

  useEffect(() => {
    if (ContainerYardInventoryMemo) {
      reset({
        ...ContainerYardInventoryMemo,
        lastMove: format(
          ContainerYardInventoryMemo.lastMove,
          "yyyy-MM-dd HH:mm:ss"
        ),
      });
    }
  }, [ContainerYardInventoryMemo, reset]);

  // const formatToPocketBaseDatetime = (date: string | File | null) => {
  //   if (!date || typeof date !== "string") return "";

  //   let parsedDate = new Date(date);

  //   // ✅ Fix: Handle cases where date is in an incorrect format
  //   if (isNaN(parsedDate.getTime())) {
  //     try {
  //       parsedDate = parseISO(date);
  //     } catch (error) {
  //       console.error("Invalid date format:", date);
  //       return "";
  //     }
  //   }

  //   return format(parsedDate, "yyyy-MM-dd HH:mm:ss.SSS'Z'");
  // };

  const submitHandler = async (
    formData: z.infer<typeof ContainerYardInventorySchema>
  ) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      await onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  /* 
  const submitHandler = async (event: any) => {
    event.preventDefault();
    setIsLoading(true); // Set loading to true
    console.log("event.currentTarget", event.currentTarget);
    try {
      const formData = new FormData(event.currentTarget);
      if (lastMove) {
        formData.append(
          "lastMove",
          formatToPocketBaseDatetime(lastMove as string)
        );
      }

      const data = Object.fromEntries(
        formData.entries()
      ) as unknown as ContainerYardInventory;

      console.log("data", data);
      await onSubmit(data);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
*/
  return (
    <form onSubmit={handleSubmit(submitHandler)} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* ... (input fields) ... */}
        <div>
          <Label>Container ID</Label>
          <Input {...register("containerId")} />
          {errors.containerId && (
            <p className="text-red-500">{errors.containerId.message}</p>
          )}
        </div>
        <div>
          <Label>Equipment Type</Label>
          <Input {...register("equipmentType")} />
          {errors.equipmentType && (
            <p className="text-red-500">{errors.equipmentType.message}</p>
          )}
        </div>
        <div>
          <Label>Equipment Type</Label>
          <Input {...register("equipmentType")} />
          {errors.equipmentType && (
            <p className="text-red-500">{errors.equipmentType.message}</p>
          )}
        </div>
        <div>
          <Label>Category</Label>
          <Input {...register("category")} />
          {errors.category && (
            <p className="text-red-500">{errors.category.message}</p>
          )}
        </div>
        <div>
          <Label>Transit State</Label>
          <Input
            type="number"
            {...register("transitState", { valueAsNumber: true })}
          />
          {errors.transitState && (
            <p className="text-red-500">{errors.transitState.message}</p>
          )}
        </div>
        <div>
          <Label>Position</Label>
          <Input
            type="number"
            {...register("position", { valueAsNumber: true })}
          />
          {errors.position && (
            <p className="text-red-500">{errors.position.message}</p>
          )}
        </div>

        <div>
          <Label>Line Operator</Label>
          <Input {...register("lineOperator")} />
          {errors.lineOperator && (
            <p className="text-red-500">{errors.lineOperator.message}</p>
          )}
        </div>
        <div>
          <Label>Inbound Actual Visit</Label>
          <Input {...register("inboundActualVisit")} />
          {errors.inboundActualVisit && (
            <p className="text-red-500">{errors.inboundActualVisit.message}</p>
          )}
        </div>
        <div>
          <Label>Outbound Actual Visit</Label>
          <Input {...register("outboundActualVisit")} />
          {errors.outboundActualVisit && (
            <p className="text-red-500">{errors.outboundActualVisit.message}</p>
          )}
        </div>
        <div>
          <Label>Port of Discharge</Label>
          <Input {...register("portOfDischarge")} />
          {errors.portOfDischarge && (
            <p className="text-red-500">{errors.portOfDischarge.message}</p>
          )}
        </div>
        <div>
          <Label>Freight Kind</Label>
          <Input {...register("freightKind")} />
          {errors.freightKind && (
            <p className="text-red-500">{errors.freightKind.message}</p>
          )}
        </div>
        <div>
          <Label>Estimated time & date of Arrival/Departure</Label>
          <DateTimePicker
            date={lastMove ? new Date(lastMove) : null}
            onDateChange={(date: Date) => {
              setValue("lastMove", date);
            }}
          />

          {errors.lastMove && (
            <p className="text-red-500">{errors.lastMove.message}</p>
          )}
        </div>
      </div>
      <div className="flex justify-end mt-4 space-x-2">
        <Button
          type="button"
          variant="secondary"
          onClick={onClose}
          disabled={isLoading}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            "Save"
          )}
        </Button>
      </div>
    </form>
  );
}
