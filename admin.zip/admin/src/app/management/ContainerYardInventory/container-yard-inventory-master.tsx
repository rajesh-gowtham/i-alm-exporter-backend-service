import SubHeader from "@/components/SubHeader";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ContainerYardInventory } from "@/lib/models";
import {
  addContainerYardInventory,
  deleteContainerYardInventory,
  editContainerYardInventory,
  fetchContainerYardInventorys,
} from "@/lib/services/container-yard-inventory-services";
import { convertTime } from "@/lib/utils";
import { PenSquare, Trash } from "lucide-react";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable, SortableHeader } from "../data-table";
import ContainerYardInventoryForm from "./container-yard-inventory-form";

export default function ContainerYardInventoryMaster() {
  const [ContainerYardInventorys, setContainerYardInventorys] = useState<
    ContainerYardInventory[]
  >([]);
  const [filteredContainerYardInventorys, setFilteredContainerYardInventorys] =
    useState<ContainerYardInventory[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [ContainerYardInventoryToEdit, setContainerYardInventoryToEdit] =
    useState<ContainerYardInventory | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [ContainerYardInventoryToDelete, setContainerYardInventoryToDelete] =
    useState<ContainerYardInventory | undefined>(undefined);

  const columns = [
    {
      accessorKey: "containerId",
      header: ({ column }) => SortableHeader({ column: column, title: "ID" }),
      enableSorting: true,
      enableHiding: false,
      meta: {
        hidden: false,
      },
    },
    {
      accessorKey: "equipmentType",
      enbleHiding: true,
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Equipment Type" }),
      enableSorting: true,
    },
    {
      accessorKey: "category",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Category" }),
      enableSorting: true,
      enableHiding: true,
    },
    {
      accessorKey: "transitState",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Transit State" }),
      enableSorting: true,
    },
    {
      accessorKey: "position",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Position" }),
      enableSorting: true,
      enableHiding: true,
    },
    {
      accessorKey: "lineOperator",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Line operator" }),
      enableSorting: true,
      enableHiding: true,
    },
    {
      accessorKey: "inboundActualVisit",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Inbound Actual Visit" }),
      enableSorting: true,
      enableHiding: true,
      meta: {
        hidden: true,
      },
    },
    {
      accessorKey: "outboundActualVisit",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Outbound Actual Visit" }),
      enableSorting: true,
      enableHiding: true,
      meta: {
        hidden: true,
      },
    },
    {
      accessorKey: "portOfDischarge",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Port Of Discharge" }),
      enableSorting: true,
      enableHiding: true,
      meta: { hidden: true },
    },
    {
      accessorKey: "freightKind",
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Freight Kind" }),
      enableSorting: true,
      enableHiding: true,
      meta: { hidden: true },
    },
    {
      accessorKey: "lastMove",
      cell: ({ row }: { row: { original: ContainerYardInventory } }) =>
        convertTime(row.original.lastMove),
      header: ({ column }) =>
        SortableHeader({ column: column, title: "Last Move" }),
      enableSorting: true,
      enableHiding: true,
      meta: {
        hidden: true,
      },
    },

    {
      accessorKey: "actions",
      header: "Action",
      enableHiding: false,
      cell: ({ row }: { row: { original: ContainerYardInventory } }) => (
        <div className="flex space-x-2">
          <Button
            size="icon"
            variant="outline"
            className="w-4 h-4"
            disabled={loading}
            onClick={() => handleEdit(row.original)}
          >
            <PenSquare className="w-4 h-4" />
          </Button>

          <Button
            size="icon"
            variant="outline"
            className="w-4 h-4"
            disabled={loading}
            onClick={() => handleDeleteClick(row.original)}
          >
            <Trash className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await fetchContainerYardInventorys();
      setContainerYardInventorys(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleEdit = (ContainerYardInventory: ContainerYardInventory) => {
    setContainerYardInventoryToEdit(ContainerYardInventory);
    setOpen(true);
  };

  const handleDeleteClick = (
    ContainerYardInventory: ContainerYardInventory
  ) => {
    setContainerYardInventoryToDelete(ContainerYardInventory);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    if (ContainerYardInventoryToDelete?.id) {
      setLoading(true);
      await deleteContainerYardInventory(
        ContainerYardInventoryToDelete.id.toString()
      );
      await fetchData();
      mutate("containerYardInventorys");
      setLoading(false);
    }
    setConfirmDeleteOpen(false);
  };

  const handleSubmit = async (
    data: Omit<ContainerYardInventory, "id" | "created" | "updated">
  ) => {
    setLoading(true);

    if (ContainerYardInventoryToEdit?.id) {
      await editContainerYardInventory(ContainerYardInventoryToEdit.id, data);
    } else {
      await addContainerYardInventory(data);
    }

    setOpen(false);
    setContainerYardInventoryToEdit(undefined);
    await fetchData();
    mutate("containerYardInventorys");
    setLoading(false);
  };
  useEffect(() => {
    if (!searchQuery) {
      setFilteredContainerYardInventorys(ContainerYardInventorys);
    } else {
      const lowerCasedQuery = searchQuery.toLowerCase();
      const filtered = ContainerYardInventorys.filter(
        (ContainerYardInventory) =>
          ContainerYardInventory.containerId
            .toLowerCase()
            .includes(lowerCasedQuery) ||
          ContainerYardInventory.equipmentType
            .toLowerCase()
            .includes(lowerCasedQuery) ||
          ContainerYardInventory.category
            .toLowerCase()
            .includes(lowerCasedQuery) ||
          ContainerYardInventory.transitState
            .toString()
            .includes(lowerCasedQuery)
      );
      setFilteredContainerYardInventorys(filtered);
    }
  }, [searchQuery, ContainerYardInventorys]);

  return (
    <div>
      {/* <div className="flex justify-between mb-4 space-x-2">
        <Input
          type="text"
          placeholder="Search Container Yard..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-1/3"
        />
        <div>
          <Button size="sm" variant="outline" disabled={loading}>
            Import
          </Button>
          <Button
            size="sm"
            disabled={loading}
            onClick={() => {
              setOpen(true);
              setContainerYardInventoryToEdit(undefined);
            }}
          >
            + Add Inventory
          </Button>
        </div>
      </div> */}
      <SubHeader
        placeholder="Container Yard..."
        searchValue={searchQuery}
        onSearchChange={setSearchQuery}
        addButtonLabel="+ Add Inventory"
        isButtonDisabled={loading}
        importNavigationUrl=""
        onAddClickOpen={setOpen}
        setComponentToEdit={setContainerYardInventoryToEdit}
      />
      {loading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="w-full h-8" />
          ))}
        </div>
      ) : (
        <DataTable columns={columns} data={filteredContainerYardInventorys} />
      )}

      {/* Confirm Delete Modal */}
      <Dialog open={confirmDeleteOpen} onOpenChange={setConfirmDeleteOpen}>
        <DialogContent>
          <DialogTitle>Confirm Deletion</DialogTitle>
          <p>
            Are you sure you want to delete the Inventory{" "}
            <b>{ContainerYardInventoryToDelete?.containerId}</b>? This action
            cannot be undone.
          </p>
          <div className="flex justify-end mt-4 space-x-2">
            <Button
              variant="outline"
              disabled={loading}
              onClick={() => setConfirmDeleteOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={loading}
              onClick={confirmDelete}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Vessel Form Modal */}
      <Dialog
        open={open}
        onOpenChange={(isOpen) => {
          setOpen(isOpen);
          if (!isOpen) setContainerYardInventoryToEdit(undefined);
        }}
      >
        <DialogContent>
          <DialogTitle>
            {ContainerYardInventoryToEdit
              ? "Edit Container Yard Inventrory"
              : "Add Container Yard Inventrory"}
          </DialogTitle>
          <ContainerYardInventoryForm
            ContainerYardInventory={ContainerYardInventoryToEdit}
            onClose={() => {
              setOpen(false);
              setContainerYardInventoryToEdit(undefined);
            }}
            onSubmit={handleSubmit}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
