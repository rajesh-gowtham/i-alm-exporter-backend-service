import { EditableCell } from "@/components/EditableCell";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { FileImportSchema, WorkInstructionImportSchema } from "@/lib/schemas";
import { addWorkInstructionInBatch } from "@/lib/services/work-instruction-services";
import { zodResolver } from "@hookform/resolvers/zod";
import { ReloadIcon } from "@radix-ui/react-icons";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router";
import * as XLSX from "xlsx";
import { z } from "zod";
import usePointofWorkStore from "../store/PointofWorkStore";
import useVesselVisitStore from "../store/VesselVisitStore";
import { ErrorToaster, FileImport, SuccessToaster } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { WorkInstructionLabels } from "@/lib/models/form-constants/formLabels";
import FileImportManipulate from "@/components/FileImportManipulate";

const requiredBackendFields = ["quay", "berthingSide", "weight", "berthAta", "startBollard", "endBollard", "vesselVisitId", "deck",'assignedLane'];
const headerMap: Record<typeof WorkInstructionLabels[keyof typeof WorkInstructionLabels], string> = {
  [WorkInstructionLabels._ContainerID]: "containerId",
  [WorkInstructionLabels._ISO]: "isoCode",
  [WorkInstructionLabels._MoveType]: "moveType",
  [WorkInstructionLabels._Mode]: "mode",
  [WorkInstructionLabels._InboundLocationType]: "inboundLocationType",
  [WorkInstructionLabels._VisitRef]: "vesselVisitId",
  [WorkInstructionLabels._OutboundLocationType]: "outboundLocationType",
  [WorkInstructionLabels._OutboundCarrier]: "outboundCarrier",
  [WorkInstructionLabels._From]: "fromLocation",
  [WorkInstructionLabels._To]: "targetLocation",
  [WorkInstructionLabels._POW]: "pointOfWorkId",
  [WorkInstructionLabels._CHEPut]: "assignedChe",
  [WorkInstructionLabels._CHECarry]: "cheCarry",
  [WorkInstructionLabels._PosOnChassis]: "positionOnCarriage",
  [WorkInstructionLabels._Status]: "workInstructionStatus",
  [WorkInstructionLabels._JobSteppingStatus]: "jobSteppingStatus",
  [WorkInstructionLabels._Deck]: "deck",
  [WorkInstructionLabels._Weight]: "weight",
  [WorkInstructionLabels._AssignedLane]: "assignedLane",
};

type WorkInstructionRecord = z.infer<typeof WorkInstructionImportSchema>;
type FormData = z.infer<typeof FileImportSchema>;
interface WorkInstructionImportProps {
  handleImportError: (arg: any[]) => void;
  errorList: any[];
  setColumns: (arg: any) => void;
  setTableData: (arg: any) => void;
  columns: any[];
  tableData: any[];
  openCloseImport: (arg: string) => void;
  setIsImportError: (arg: boolean) => void;
  // openCloseImport: () => void;
}
export default function WorkInstructionImport({ handleImportError, errorList, setColumns, setTableData, columns, tableData, openCloseImport, setIsImportError }: WorkInstructionImportProps) {


  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<WorkInstructionRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(errorList.length > 0);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);
  // const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  // const [columns, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);
  const vesselVisitStore = useVesselVisitStore();
  const pointofWorkStore = usePointofWorkStore();

  const navigate = useNavigate();

  const batchInsert = async (records: WorkInstructionRecord[]) => {
    console.log(records)
    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;
      for (let i = 0; i < records.length; i += batchSize) {
        let batch = records.slice(i, i + batchSize);
        batch = batch.map((item) => {
          const vesselNameFromExcel = item.vesselVisitId?.toLowerCase();
          const matchedVessel = vesselVisitStore.vesselVisits.find(
            (vessel) => vessel.visitRef?.toLowerCase() === vesselNameFromExcel
          );
          const powName = item.pointOfWorkId?.toLowerCase();
          const matchedPow = pointofWorkStore.pointofWorks.find(
            (vessel) => vessel.name?.toLowerCase() === powName
          );
          if (!matchedVessel) {
            isValidRecod = false;
          }
          return {
            ...item,
            vesselVisitId: matchedVessel?.id,
            pointOfWorkId: matchedPow?.id,

          };
        });
        // const batch = records.slice(i, i + batchSize);
        await addWorkInstructionInBatch(batch);
        const progress = Math.min(100, ((i + batch.length) / totalRecords) * 100);
        setImportProgress(progress);
        await new Promise((r) => setTimeout(r, 100));
      }
      SuccessToaster("Import Completed", `${totalRecords} Work Instructions imported successfully`);
      // navigate(privateRoute._Configuration + privateRoute._Workinstruction);
      openCloseImport("CLEAR-SUCCESS")
      setIsImportError(false)

    } catch (error) {
      console.error(error);
      ErrorToaster("Import Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
      setShowConfirmModal(true)
    } finally {
      setBatchProcessing(false);
      setImportProgress(0);
      // setShowConfirmModal(false);
      reset();
    }
  };

  const updateData = (rowIndex: number, columnId: string, value: any) => {
    setTableData(prev =>
      prev.map((row, index) => {
        if (index === rowIndex) {
          return {
            ...row,
            [columnId]: value,
          };
        }
        return row;
      })
    );
  };

  useEffect(() => {
    if (tableData.length === 0) return;

    const validationResults = tableData.map((originalRow, index) => {
      const row = { ...originalRow };
      const rowErrors: z.ZodIssue[] = [];

      // Resolve vesselVisitId
      if (typeof row["vesselVisitId"] === "string") {
        const visitRef = row["vesselVisitId"].toLowerCase().trim();
        const match = vesselVisitStore.vesselVisits.find(
          (item) => item.visitRef?.toLowerCase() === visitRef
        );
        if (match?.id) {
          // row["vesselVisitId"] = match.id;
        } else {
          rowErrors.push({
            code: "custom",
            path: ["vesselVisitId"],
            message: `IB Carrier "${row["vesselVisitId"]}" not found.`,
          });
        }
      }

      // Resolve pointOfWorkId
      if (typeof row["pointOfWorkId"] === "string") {
        const powName = row["pointOfWorkId"].toLowerCase().trim();
        const match = pointofWorkStore.pointofWorks.find(
          (item) => item.name?.toLowerCase() === powName
        );
        if (match?.id) {
          // row["pointOfWorkId"] = match.id;
        } else {
          rowErrors.push({
            code: "custom",
            path: ["pointOfWorkId"],
            message: `Point of Work "${row["pointOfWorkId"]}" not found.`,
          });
        }
      }

      // Normalize values
      if ("fromLocation" in row) {
        row["fromLocation"] = String(row["fromLocation"] ?? "");
      }
      if ("positionOnCarriage" in row) {
        row["positionOnCarriage"] = String(row["positionOnCarriage"] ?? "");
      }

      // Zod validation
      const result = WorkInstructionImportSchema.safeParse(row);
      const allErrors = result.success
        ? rowErrors
        : [...rowErrors, ...result.error.issues];

      return {
        row: index + 2,
        valid: allErrors.length === 0,
        errors: allErrors,
        data: allErrors.length === 0 ? result.data : null,
      };
    });

    const valid = validationResults
      .filter((r) => r.valid)
      .map((r) => r.data) as WorkInstructionRecord[];

    const errors = validationResults
      .filter((r) => !r.valid)
      .map((r) => ({
        row: r.row,
        issues: r.errors,
        original: tableData[r.row - 2],
      }));

    setValidRecords(valid);
    setValidationErrors(errors);
  }, [tableData, vesselVisitStore.vesselVisits, pointofWorkStore.pointofWorks]);


  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: "binary" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const [headerRow, ...rows] = jsonData;
        const headers = headerRow as string[];

        const errors: string[] = [];

        for (const readableHeader in headerMap) {
          const backendKey = headerMap[readableHeader];
          if (!headers.includes(readableHeader)) {
            if (requiredBackendFields.includes(backendKey)) {
              errors.push(`Missing required column: ${readableHeader}`);
            }
          }
        }

        const unknownHeaders = headers.filter(h => !headerMap[h]);
        if (unknownHeaders.length > 0) {
          unknownHeaders.forEach(h => errors.push(`Unknown column found: ${h}`));
        }

        if (errors.length > 0) {
          ErrorToaster("File validation failed:\n" + errors.join("\n"));
          // Don't return — continue to extract raw data
        }

        // 1. Extract raw data even if invalid
        const extractedData = rows.map((row) =>
          headers.reduce((obj, readableHeader, idx) => {
            const backendKey = headerMap[readableHeader];
            if (backendKey) {
              obj[backendKey] = row[idx] ?? '';
            }
            return obj;
          }, {} as Record<string, any>)
        );

        let errorCount = 0;
        const validRowsToInsert = [];
        const validatedRows = extractedData.map((itemRow, index) => {
          const row = { ...itemRow };
          const rowErrors: z.ZodIssue[] = [];

          // Resolve vesselVisitId
          if (typeof row["vesselVisitId"] === "string") {
            const visitRef = row["vesselVisitId"].toLowerCase().trim();
            const findItem = vesselVisitStore.vesselVisits.find(
              (item) => item.visitRef?.toLowerCase() === visitRef
            );

            if (findItem?.id) {
              // row["vesselVisitId"] = findItem.id;
            } else {
              // errorCount += 1;
              rowErrors.push({
                code: "custom",
                path: ["vesselVisitId"],
                message: `IB Carrier "${row["vesselVisitId"]}" not found.`,
              });
            }
          }

          // Resolve pointOfWorkId
          if (typeof row["pointOfWorkId"] === "string") {
            const powName = row["pointOfWorkId"].toLowerCase().trim();
            const findData = pointofWorkStore.pointofWorks.find(
              (item) => item.name?.toLowerCase() === powName
            );
            if (findData?.id) {
              // row["pointOfWorkId"] = findData.id;
            } else {
              // errorCount += 1;
              rowErrors.push({
                code: "custom",
                path: ["pointOfWorkId"],
                message: `Point of Work "${row["pointOfWorkId"]}" not found.`,
              });
            }
          }

          // Normalize types for optional fields
          if ("fromLocation" in row) {
            row["fromLocation"] = String(row["fromLocation"] ?? "");
          }
          if ("assignedLane" in row) {
            row["assignedLane"] = String(row["assignedLane"] ?? "");
          }
          if ("positionOnCarriage" in row) {
            row["positionOnCarriage"] = String(row["positionOnCarriage"] ?? "");
          }

          // Schema validation
          const result = WorkInstructionImportSchema.safeParse(row);
          const allErrors = !result.success
            ? [...rowErrors, ...result.error.issues]
            : rowErrors;

          if (allErrors.length === 0) {
            validRowsToInsert.push(result.data)
            return { ...result.data, __rowValid: true };
          } else {
            errorCount += 1;
            return {
              ...row,
              __rowValid: false,
              __rowErrors: allErrors.reduce<Record<string, string[]>>((acc, issue) => {
                const key = issue.path?.[0] as string;
                acc[key] = acc[key] || [];
                acc[key].push(issue.message);
                return acc;
              }, {}),
              __rowIndex: index + 2, // Excel row number
            };
          }
        });


        // 3. Set for editable table
        const newColumns = Object.keys(headerMap).map((readableHeader) => ({
          Header: readableHeader,
          accessor: headerMap[readableHeader],
        }));

        setColumns(newColumns);
        setTableData(validatedRows);
        // setShowConfirmModal(true);
        console.log("validatedRows", errorCount, validatedRows);
        if (errorCount === 0) {
          // const dataInset = validatedRows as VesselRecord[]
          batchInsert(validRowsToInsert as WorkInstructionRecord[])
        } else {
          handleImportError(validatedRows);
        }
      } catch (error) {
        console.error(error);
        ErrorToaster("Failed to process file: " + (error as any).message);
      } finally {
        setUploading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  // const processExcelFile = (file: File) => {
  //   const reader = new FileReader();
  //   reader.onload = (e) => {
  //     const binary = e.target?.result;
  //     const workbook = XLSX.read(binary, { type: "binary" });
  //     const sheet = workbook.Sheets[workbook.SheetNames[0]];

  //     const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
  //     const [headerRow, ...rows] = jsonData;
  //     const headers = headerRow as string[];

  //     const newColumns = headers.map((header) => ({
  //       Header: header,
  //       accessor: header,
  //     }));
  //     setColumns(newColumns);

  //     const rowsItems = rows as string[];
  //     console.log(" rowsItems ", rowsItems);
  //     const newData = rowsItems.map((row) =>
  //       headers.reduce((obj, header, idx) => {
  //         if (header === "vesselVisitId") {
  //           const findData = vesselVisitStore.vesselVisits.find((item) => item.visitRef?.toLowerCase() === String(row[idx] ?? '').toLowerCase().trim());
  //           console.log(findData);
  //           obj[header] = findData ? findData.id : '';
  //         }
  //         else if (header === "pointOfWorkId") {
  //           console.log("pointofWorkStore.pointofWorks", pointofWorkStore.pointofWorks);
  //           const findData = pointofWorkStore.pointofWorks.find((item) => item.name?.toLowerCase() === String(row[idx] ?? '').toLowerCase().trim());
  //           console.log(findData);
  //           obj[header] = findData ? findData.id : '';
  //         } else {
  //           obj[header] = (row[idx] ?? '') + "";
  //         }
  //         return obj;
  //       }, {} as Record<string, any>)
  //     );

  //     // const newData = rows.map((row) =>
  //     //   headers.reduce((obj, header, idx) => ({
  //     //     ...obj,
  //     //     [header]   : row[idx] ?? '',
  //     //   }), {})
  //     // );
  //     console.log(" newData", newData);
  //     setTableData(newData);
  //     setShowConfirmModal(true);
  //     setUploading(false);
  //   };
  //   reader.readAsBinaryString(file);
  // };

  // const renderTable = () => (
  //   <div className="overflow-auto">
  //     <table className="w-full border-collapse">
  //       <thead>
  //         <tr>
  //           {columns.map((column) => (
  //             <th
  //               key={column.accessor}
  //               className="sticky top-0 p-2 text-left border border-gray-200 bg-muted"
  //             >
  //               {column.Header}
  //               {/* {numericFields.includes(column.accessor) && (
  //                 <span className="ml-1 text-xs text-gray-500">(number)</span>
  //               )} */}
  //             </th>
  //           ))}
  //         </tr>
  //       </thead>
  //       <tbody>
  //         {tableData.map((row, rowIndex) => {
  //           const isInvalid = validationErrors.some(e => e.row === rowIndex + 2);
  //           return (
  //             <tr
  //               key={rowIndex}
  //               className={isInvalid ? 'bg-muted hover:bg-red-100' : ''}
  //             >
  //               {columns.map((column) => {
  //                 // const isNumeric = numericFields.includes(column.accessor);
  //                 return (
  //                   <td key={column.accessor} className="border border-gray-200">
  //                     <EditableCell
  //                       value={row[column.accessor]}
  //                       row={{ index: rowIndex }}
  //                       column={{ id: column.accessor }}
  //                       isNumeric={false}
  //                       updateData={updateData}
  //                     />
  //                   </td>
  //                 );
  //               })}
  //             </tr>
  //           );
  //         })}
  //       </tbody>
  //     </table>
  //   </div>
  // );


  return (

    <div>
      <FileImport
        errors={errors}
        handleSubmit={handleSubmit}
        processExcelFile={processExcelFile}
        register={register}
        setUploading={setUploading}
        uploading={uploading}
        backToParent={openCloseImport}
        filename="workinstructionmaster.xlsx"
      />

      <Dialog
        open={showConfirmModal}
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
         <DialogContent className="max-w-[95vw] h-[85vh] overflow-auto overflow-auto flex flex-col p-0">
          <FileImportManipulate
            columns={columns}
            tableData={tableData}
            updateData={updateData}
            validationErrors={validationErrors}
            validRecords={validRecords}
            batchProcessing={batchProcessing}
            setShowConfirmModal={setShowConfirmModal}
            importProgress={importProgress}
            batchInsert={batchInsert}
          />
        </DialogContent>
      </Dialog>
    </div >

  );
}