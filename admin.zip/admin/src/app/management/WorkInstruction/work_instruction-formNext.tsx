import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownWhite, FormActions, MandatoryIcon, optionsListProps } from "@/components/UtilComp";
import { deckOptionLists, ibOblocationTypeOptionList } from "@/lib/constants";
import { WorkInstruction } from "@/lib/models";
import { WorkInstructionLabels } from "@/lib/models/form-constants/formLabels";
import { WorkInstructionSchema } from "@/lib/schemas";
import { fetchAssignedEquipmentByPoolName } from "@/lib/services/equipmentpool-services";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";
import useEquipmentStore from "../store/EquipmentStore";
import usePointofWorkStore from "../store/PointofWorkStore";
import useVesselVisitStore from "../store/VesselVisitStore";
interface WorkInstructionFormProps {
    WorkInstruction?: WorkInstruction;
    onClose: () => void;
    onSubmit: (data: WorkInstruction) => void;
    isSecondStepActive: boolean;
    onBack: () => void;
}

const moveTypeOptionList = [
    { value: "Load", label: "Load" },
    { value: "Discharge", label: "Discharge" },

]

export default function WorkInstructionFormNext({
    WorkInstruction,
    onClose,
    onSubmit,
    isSecondStepActive,
    onBack
}: WorkInstructionFormProps) {
    const [isLoading, setIsLoading] = useState(false); // Add loading state
    const EquipmentStore = useEquipmentStore();
    const vesselVisitStore = useVesselVisitStore();
    const powStore = usePointofWorkStore();
    // console.log("vessel", vessel);
    const {
        register,
        reset,
        handleSubmit,
        setValue,
        watch,
        clearErrors,
        control,
        getFieldState,
        getValues,
        formState: { errors },
    } = useForm<z.infer<typeof WorkInstructionSchema>>({
        resolver: zodResolver(WorkInstructionSchema),
        defaultValues: { mode: "Twin" }
    });

    const [cheCarryOptionsList, setCheCarryOptionsList] = useState<optionsListProps[]>([])
    const WorkInstructionMemo = useMemo(() => WorkInstruction, [WorkInstruction]);


    const selectedPOWId = watch("pointOfWorkId"); // Watch for vessel ID change

    useEffect(() => {
        console.log(" selectedPOWId ", selectedPOWId);
        const selectedPow = powStore.pointofWorks.find((item) => item.id === Number(selectedPOWId));
        console.log(" selectedPow ", selectedPow);
        if (selectedPow) {
            async function fetchOptions() {
                const data = await getAssignedEquipments(selectedPow.pool);
                setCheCarryOptionsList(data)
            }
            fetchOptions()
            // setValue("cheCarry", selectedPow || "");
        } else {
            setValue("cheCarry", "");
        }
    }, [selectedPOWId, setValue, powStore.pointofWorks]);
    useEffect(() => {
        const selectedPOWId = WorkInstruction?.pointOfWorkId;
        const selectedPow = powStore.pointofWorks.find((item) => item.id === Number(selectedPOWId));
        console.log(" selectedPow ", selectedPow);
        if (selectedPow?.pool) {
            async function fetchOptions() {
                const data = await getAssignedEquipments(selectedPow?.pool);
                setCheCarryOptionsList(data)
            }
            fetchOptions()
            // setValue("cheCarry", selectedPow || "");
        } else {
            setValue("cheCarry", "");

        }
        setValue("mode", "Twin", {
            shouldValidate: true
        })
    }, []);
    const getAssignedEquipments = async (poolName: string) => {
        try {
            const assignedEquipments = await fetchAssignedEquipmentByPoolName(poolName);
            console.log(" assignedEquipments", assignedEquipments);
            return await assignedEquipments?.map(opt => ({
                label: opt,
                value: opt
            }))
        } catch (error) {
            console.error(error);
            return []
        }

    }
    useEffect(() => {
        if (WorkInstructionMemo) {
            reset({
                ...WorkInstructionMemo,
                id:
                    typeof WorkInstructionMemo.id === "string"
                        ? parseInt(WorkInstructionMemo.id)
                        : WorkInstructionMemo.id,
                // containerId:
                //   typeof WorkInstructionMemo.containerId === "string"
                //     ? parseInt(WorkInstructionMemo.containerId)
                //     : WorkInstructionMemo.containerId,
            });
        }
    }, [WorkInstructionMemo, reset]);
    const submitHandler = async (
        formData: z.infer<typeof WorkInstructionSchema>
    ) => {
        setIsLoading(true); // Set loading to true
        try {
            console.log("Submit handler called", formData);
            const payload = {
                ...formData,
                outboundLocationType: formData.outboundLocationType ? formData.outboundLocationType : '',
                inboundLocationType: formData.inboundLocationType ? formData.inboundLocationType : '',
                outboundCarrier: formData.outboundCarrier ? formData.outboundCarrier : '',
            };
            console.log(payload)
            await onSubmit(payload as WorkInstruction);
        } catch (error) {
            console.error("Error submitting form:", error);
        } finally {
            setIsLoading(false); // Set loading to false
        }
    };
    console.log(errors, getValues("mode"),)
    return (
        <form onSubmit={handleSubmit(submitHandler)} className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
                <div>
                    <Label>{WorkInstructionLabels._ContainerID}</Label>
                    {(!WorkInstructionSchema.shape.containerId.isOptional()) && <MandatoryIcon />}
                    <Input
                        {...register("containerId")}
                        onChange={(e) => {
                            const upper = e.target.value.toUpperCase();
                            setValue("containerId", upper, { shouldValidate: true });
                        }}
                        disabled={WorkInstruction !== undefined} readOnly={WorkInstruction !== undefined}
                        error={!!errors.containerId}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._ISO}</Label>
                    {(!WorkInstructionSchema.shape.isoCode.isOptional()) && <MandatoryIcon />}
                    <Input {...register("isoCode")}
                        onChange={(e) => {
                            const upper = e.target.value.toUpperCase();
                            setValue("isoCode", upper, { shouldValidate: true });
                        }}
                        error={!!errors.isoCode}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._MoveType}</Label>
                    {(!WorkInstructionSchema.shape.moveType.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={"Move Type"}
                        fieldName="moveType"
                        fieldValue={WorkInstruction?.moveType || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={moveTypeOptionList}
                        error={!!errors.moveType}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._Mode}</Label>
                    {/* {(!WorkInstructionSchema.shape.mode.isOptional()) && <MandatoryIcon />} */}
                    {/* <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._Mode}
                        fieldName="mode"
                        fieldValue={"Twin"}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={TransModeOptionList}
                        disabled={true}
                    /> */}
                    <Input
                        readOnly
                        disabled
                        {...register("mode")}
                    // value={"Twin"}
                    />
                    {/* {errors.mode && (
            <p className="text-red-500">{errors.mode.message}</p>
          )} */}
                </div>
                <div>
                    <Label>{WorkInstructionLabels._Weight}</Label>
                    {(!WorkInstructionSchema.shape.weight.isOptional()) && <MandatoryIcon />}
                    <Input
                        {...register("weight", { valueAsNumber: true })}
                        error={!!errors.weight}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._InboundLocationType}</Label>
                    {(!WorkInstructionSchema.shape.inboundLocationType.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._InboundLocationType}
                        fieldName="inboundLocationType"
                        fieldValue={WorkInstruction?.inboundLocationType || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={ibOblocationTypeOptionList}
                        error={!!errors.inboundLocationType}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._VisitRef}</Label>
                    {(!WorkInstructionSchema.shape.vesselVisitId.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._VisitRef}
                        fieldName="vesselVisitId"
                        fieldValue={WorkInstruction?.vesselVisitId + '' || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={vesselVisitStore?.vesselVisits?.map((vesselVisit) => ({
                            label: vesselVisit.visitRef,
                            value: vesselVisit.id + ""
                        }))}
                        error={!!errors.vesselVisitId}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._OutboundLocationType}</Label>
                    {(!WorkInstructionSchema.shape.outboundLocationType.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._OutboundLocationType}
                        fieldName="outboundLocationType"
                        fieldValue={WorkInstruction?.outboundLocationType || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={ibOblocationTypeOptionList}
                        error={!!errors.outboundLocationType}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._OutboundCarrier}</Label>
                    {(!WorkInstructionSchema.shape.outboundCarrier.isOptional()) && <MandatoryIcon />}
                    <Input {...register("outboundCarrier")}
                        error={!!errors.outboundCarrier}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._Deck}</Label>
                    {(!WorkInstructionSchema.shape.deck.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._Deck}
                        fieldName="deck"
                        fieldValue={WorkInstruction?.deck || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={deckOptionLists}
                        error={!!errors.deck}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._From}</Label>
                    {(!WorkInstructionSchema.shape.fromLocation.isOptional()) && <MandatoryIcon />}
                    <Input {...register("fromLocation")}
                        error={!!errors.fromLocation}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._To}</Label>
                    {(!WorkInstructionSchema.shape.targetLocation.isOptional()) && <MandatoryIcon />}
                    <Input {...register("targetLocation")}
                        error={!!errors.targetLocation}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._AssignedLane}</Label>
                    {(!WorkInstructionSchema.shape.assignedLane.isOptional()) && <MandatoryIcon />}
                    <Input {...register("assignedLane")}
                        error={!!errors.assignedLane}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._POW}</Label>
                    {(!WorkInstructionSchema.shape.pointOfWorkId.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._POW}
                        fieldName="pointOfWorkId"
                        fieldValue={WorkInstruction?.pointOfWorkId + ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={powStore?.pointofWorks?.map(item => ({ label: item.name, value: (item.id) + "" }))}
                        error={!!errors.pointOfWorkId}
                    />
                </div>


                <div>
                    <Label>{WorkInstructionLabels._CHECarry}</Label>
                    {(!WorkInstructionSchema.shape.cheCarry.isOptional()) && <MandatoryIcon />}
                    <DropdownWhite
                        Label_Placeholder={WorkInstructionLabels._CHECarry}
                        fieldName="cheCarry"
                        fieldValue={WorkInstruction?.cheCarry || ""}
                        setValue={setValue}
                        clearErrors={clearErrors}
                        optionsList={cheCarryOptionsList}
                        error={!!errors.cheCarry}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._PosOnChassis}</Label>
                    {(!WorkInstructionSchema.shape.positionOnCarriage.isOptional()) && <MandatoryIcon />}
                    <Input {...register("positionOnCarriage")}
                        error={!!errors.positionOnCarriage}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._CHEPut}</Label>
                    {(!WorkInstructionSchema.shape.assignedChe.isOptional()) && <MandatoryIcon />}
                    <Input {...register("assignedChe")}
                        error={!!errors.assignedChe}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._Status}</Label>
                    {(!WorkInstructionSchema.shape.workInstructionStatus.isOptional()) && <MandatoryIcon />}
                    <Input value={"Planned"} disabled  {...register("workInstructionStatus")}
                        error={!!errors.workInstructionStatus}
                    />
                </div>
                <div>
                    <Label>{WorkInstructionLabels._JobSteppingStatus}</Label>
                    {(!WorkInstructionSchema.shape.jobSteppingStatus.isOptional()) && <MandatoryIcon />}
                    <Input disabled value={"Yet to Start"}
                        {...register("jobSteppingStatus")}
                        error={!!errors.jobSteppingStatus}
                    />
                </div>
            </div>
            <FormActions
                isEdit={WorkInstruction?.id ? true : false}
                isLoading={isLoading}
                onClose={onClose}
                isSecondStepActive={isSecondStepActive}
                onBack={onBack}
            />
        </form>
    );
}
