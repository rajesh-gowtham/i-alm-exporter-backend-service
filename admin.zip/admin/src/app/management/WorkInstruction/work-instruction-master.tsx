import SubHeader from "@/components/SubHeader";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { privateRoute } from "@/lib/constants";
import { WorkInstruction } from "@/lib/models";
import { WorkInstructionLabels } from "@/lib/models/form-constants/formLabels";
import { fetchEquipments } from "@/lib/services/equipment-services";
import { fetchPointofWorks } from "@/lib/services/pointofwork-services";
import { fetchVesselVisits } from "@/lib/services/vessels-services";
import {
  addWorkInstruction,
  addWorkInstructionInBatch,
  deleteWorkInstruction,
  editWorkInstruction,
  fetchWorkInstructions,
} from "@/lib/services/work-instruction-services";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import useEquipmentStore from "../store/EquipmentStore";
import usePointofWorkStore from "../store/PointofWorkStore";
import useVesselVisitStore from "../store/VesselVisitStore";
import useWorkInstructionStore from "../store/WorkInstructionStore";
import WorkInstructionForm from "./work-instruction-form";
import WorkInstructionImport from "./work-instruction-import";
import WorkInstructionFormNext from "./work_instruction-formNext";

export default function WorkInstructionMaster() {
  const [WorkInstructions, setWorkInstructions] = useState<WorkInstruction[]>(
    []
  );
  const [totalRecord, setTotalRecord] = useState(0);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  // const [filteredWorkInstructions, setFilteredWorkInstructions] = useState<WorkInstruction[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [isSecondStepActive, setIsSecondStepActive] = useState(false);
  const [SecondStepActiveData, setSecondStepActiveData] = useState([])
  const [loading, setLoading] = useState(false);
  const [WorkInstructionToEdit, setWorkInstructionToEdit] = useState<
    WorkInstruction | undefined
  >(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [WorkInstructionToDelete, setWorkInstructionToDelete] = useState<
    WorkInstruction | undefined
  >(undefined);
  const workInstructionStore = useWorkInstructionStore();
  const PointofWorkStore = usePointofWorkStore();
  const VesselVisitsStore = useVesselVisitStore();
  const EquimentsStore = useEquipmentStore();
  // Import rework
  const [isImportEnable, setIsImportEnable] = useState(false);
  const [isImportError, setIsImportError] = useState(false);
  const [errorList, setErrorList] = useState([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columnsImport, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const handlePaginationChange = (newPagination: PaginationState) => {
    // console.log("newPagination", newPagination);
    setPaged(newPagination);
  }
  const columnsConfig = [
    // { key: "sequence", title: WorkInstructionLabels._Sequence, hidden: true },
    { key: "containerId", title: WorkInstructionLabels._ContainerID, hidden: false },
    { key: "isoCode", title: WorkInstructionLabels._ISO, hidden: false },
    { key: "moveType", title: WorkInstructionLabels._MoveType, hidden: false },
    { key: "mode", title: WorkInstructionLabels._Mode, hidden: false },
    { key: "inboundLocationType", title: WorkInstructionLabels._InboundLocationType, hidden: true },
    { key: "vesselVisitId", title: WorkInstructionLabels._VisitRef, hidden: false },
    { key: "outboundLocationType", title: WorkInstructionLabels._OutboundLocationType, hidden: true },
    { key: "outboundCarrier", title: WorkInstructionLabels._OutboundCarrier, hidden: true },
    { key: "deck", title: WorkInstructionLabels._Deck, hidden: false },
    { key: "fromLocation", title: WorkInstructionLabels._From, hidden: false },
    { key: "targetLocation", title: WorkInstructionLabels._To, hidden: false },
    { key: "assignedLane", title: WorkInstructionLabels._AssignedLane, hidden: false },
    { key: "pointOfWorkId", title: WorkInstructionLabels._POW, hidden: false },
    { key: "assignedChe", title: WorkInstructionLabels._CHEPut, hidden: true },
    { key: "cheCarry", title: WorkInstructionLabels._CHECarry, hidden: true },
    { key: "positionOnCarriage", title: WorkInstructionLabels._PosOnChassis, hidden: true },
    { key: "weight", title: WorkInstructionLabels._Weight, hidden: true },
    { key: "workInstructionStatus", title: WorkInstructionLabels._Status, hidden: false },
    { key: "jobSteppingStatus", title: WorkInstructionLabels._JobSteppingStatus, hidden: false },
  ];

  const columns: ColumnDef<WorkInstruction>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => {
      const column: ColumnDef<WorkInstruction> = {
        accessorKey: key,
        header: title,
        // header: ({ column }) => SortableHeader({ column, title }),
        // enableHiding: true,
        // enableSorting: false,
        meta: { hidden },
        size: 150,

      };
      if (key === "vesselVisitId") {
        column.cell = ({ row }) =>
          VesselVisitsStore.vesselVisits.length > 0
            ? VesselVisitsStore.vesselVisits.find(
              (vesselVisit) => vesselVisit.id === row.original.vesselVisitId
            )?.visitRef ?? "N/A" : "N/A";

      }
      if (key === "pointOfWorkId") {
        column.cell = ({ row }) =>
          PointofWorkStore.pointofWorks.length > 0
            ? PointofWorkStore.pointofWorks.find(
              (pointofWork) => pointofWork.id === row.original.pointOfWorkId
            )?.name ?? "N/A" : "N/A";
      }
      return column;
    }),

    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: { hidden: false },
      cell: ({ row }: { row: { original: WorkInstruction } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];

  const fetchPointofWorksData = async () => {
    try {
      const data = await fetchPointofWorks();
      PointofWorkStore.setPointofWorks(data["items"]);
    } finally {
      //
    }
  };
  const fetchVesselVisitsData = async () => {
    try {
      const data = await fetchVesselVisits();
      VesselVisitsStore.setVesselVisits(data["items"]);
    } finally {
      //
    }
  };
  const fetchEquipmentData = async () => {
    try {
      const data = await fetchEquipments();
      EquimentsStore.setEquipments(data["items"]);
    } finally {
      //
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const skip = paged.pageIndex * paged.pageSize;
      const take = paged.pageSize;
      const search = paged.search;
      const data = await fetchWorkInstructions(skip, take, search);
      if (data?.items) {
        setOpen(false)
        setTotalRecord(data["totalCount"]);
        setWorkInstructions(data["items"]);
        workInstructionStore.setSelectedWorkInstruction(data["items"]);
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [paged]);
  useEffect(() => {
    fetchPointofWorksData();
    fetchEquipmentData();
    fetchVesselVisitsData();
  }, []);

  const handleEdit = (WorkInstruction: WorkInstruction) => {
    console.log(WorkInstruction);
    if (WorkInstruction.workInstructionStatus === "Inprogress") {
      ErrorToaster("Active workinstruction can not be deleted");
      return;
    }
    setWorkInstructionToEdit(WorkInstruction);
    setOpen(true);
  };

  const handleDeleteClick = (WorkInstruction: WorkInstruction) => {
    setWorkInstructionToDelete(WorkInstruction);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    if (WorkInstructionToDelete?.id) {
      setLoading(true);
      await deleteWorkInstruction(WorkInstructionToDelete.id.toString());
      await fetchData();
      mutate("workInstruction");
      SuccessToaster("", "Work Instruction deleted successfully");
      setLoading(false);
    }
    setConfirmDeleteOpen(false);
  };
  const handleSecondStepForm = async (data: Omit<WorkInstruction, "id" | "created" | "updated" | "mode">) => {
    // setLoading(true);
    console.log(data)
    const payload = [data, SecondStepActiveData]
    console.log(payload)
    try {
      await addWorkInstructionInBatch(payload);
      SuccessToaster("", "Work Instruction created successfully");
      setOpen(false);
      setWorkInstructionToEdit(undefined);
      await fetchData();
      mutate("workInstruction");
      setIsSecondStepActive(false);
      setLoading(false);
    }
    catch (error) {
      ErrorToaster(`Work Instruction ${WorkInstructionToEdit ? 'Updation' : 'Creation'} Failed`, error instanceof Error ? error?.response?.data : "Unknown error occurred")
    } finally {
      setLoading(false);
    }

  }
  const handleSubmit = async (
    data: Omit<WorkInstruction, "id" | "created" | "updated">
  ) => {
    try {

      if (WorkInstructionToEdit?.id) {
        await editWorkInstruction(WorkInstructionToEdit.id.toString(), data);
        SuccessToaster("", "Work Instruction updated successfully");
      } else {
        if (data.mode === 'Twin') {
          console.log("Switching to step 2");
          setSecondStepActiveData(data);
          setIsSecondStepActive(true);
          return;
        }
        await addWorkInstruction(data);
        SuccessToaster("", "Work Instruction created successfully");
      }
      setOpen(false);
      setWorkInstructionToEdit(undefined);
      await fetchData();
      mutate("workInstruction");
      setLoading(false);
    } catch (error) {
      ErrorToaster(
        `Work Instruction ${WorkInstructionToEdit ? 'Updation' : 'Creation'} Failed`,
        error instanceof Error ? error?.response?.data : "Unknown error occurred"
      );
    } finally {
      setLoading(false);
    }
  };
  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredWorkInstructions(WorkInstructions);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     const filtered = WorkInstructions.filter(
  //       (WorkInstruction) =>
  //         WorkInstruction.containerId
  //           .toLowerCase()
  //           .includes(lowerCasedQuery) ||
  //         VesselVisitsStore.vesselVisits.find((vesselVisit) => vesselVisit.visitRef
  //           .toLowerCase().includes(lowerCasedQuery)) ||
  //         WorkInstruction.isoCode
  //           .toLowerCase()
  //           .includes(lowerCasedQuery) ||
  //         WorkInstruction.moveType.toLowerCase().includes(lowerCasedQuery));
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     setFilteredWorkInstructions(filtered.slice(start, end));
  //   }
  // }, [searchQuery, WorkInstructions]);

  // Import rework
  const openCloseImport = (type: string) => {
    setIsImportEnable(prev => !prev);
    if (type === "CLEAR") {
      setErrorList([]);
      setTableData([]);
      setColumns([]);
      setIsImportError(false)
    }
    if (type === "CLEAR-SUCCESS") {
      setErrorList([]);
      setTableData([]);
      fetchData()
      setColumns([]);
      setIsImportError(false)
    }
  }
  const handleImportError = (data: any[]) => {
    console.log("data ", data);
    const errors = data.filter(r => !r.__rowValid)
    setErrorList(errors);
    setIsImportError(true);
    openCloseImport("");
    ErrorToaster("Import failed!");
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      {!isImportEnable ?

        <div>
          <SubHeader
            placeholder="IB Carrier/Move Type/Container ID..."
            searchValue={searchQuery}
            onSearchChange={onSearchChange}
            addButtonLabel="+"
            isButtonDisabled={loading}
            importNavigationUrl={privateRoute._Operation + privateRoute._Workinstruction_Import}
            onAddClickOpen={setOpen}
            setComponentToEdit={setWorkInstructionToEdit}
            openCloseImport={openCloseImport}
            isImportError={isImportError}
            errorList={errorList}
          />

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-8" />
              ))}
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={WorkInstructions || []}
              totalRecords={totalRecord}
              pagination={paged}
              onPaginationChange={handlePaginationChange}
            />
          )}

          {/* Confirm Delete Modal */}
          <Dialog open={confirmDeleteOpen} onOpenChange={setConfirmDeleteOpen}>
            <DialogContent>
              <DialogTitle>Confirm Deletion</DialogTitle>
              <p>
                Are you sure you want to delete the Work Instruction Order{" "}
                <b>{WorkInstructionToDelete?.containerId}</b>? This action cannot be
                undone.
              </p>
              <div className="flex justify-end mt-4 space-x-2">
                <Button
                  variant="outline"
                  disabled={loading}
                  onClick={() => setConfirmDeleteOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  disabled={loading}
                  onClick={confirmDelete}
                >
                  Delete
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Vessel Form Modal */}
          <Dialog
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) {
                setWorkInstructionToEdit(undefined);
                setIsSecondStepActive(false);
                setSecondStepActiveData([]);
              }
            }}
          >
            <DialogContent className="lg:max-w-screen-lg overflow-y-scroll max-h-screen">
              <DialogTitle>
                {WorkInstructionToEdit ? "Edit Work Instruction" : "Add Work Instruction"}
              </DialogTitle>

              {!isSecondStepActive ? (
                <WorkInstructionForm
                  WorkInstruction={WorkInstructionToEdit}
                  onClose={() => {
                    setOpen(false);
                  }}
                  onSubmit={handleSubmit}
                />
              ) : (
                <WorkInstructionFormNext
                  // initialData={SecondStepActiveData}
                  onClose={() => {
                    setOpen(!open);
                    setWorkInstructionToEdit(undefined);
                    setIsSecondStepActive(false);
                    setSecondStepActiveData([]);
                  }}
                  onBack={() => {
                    setOpen(true);
                    setWorkInstructionToEdit(undefined);
                    setIsSecondStepActive(false);
                  }
                  }
                  onSubmit={handleSecondStepForm}
                  isSecondStepActive={isSecondStepActive}
                />
              )}
            </DialogContent>
          </Dialog>
        </div>
        :
        <WorkInstructionImport
          errorList={errorList}
          handleImportError={handleImportError}
          setColumns={setColumns}
          setTableData={setTableData}
          columns={columnsImport}
          tableData={tableData}
          openCloseImport={openCloseImport}
          setIsImportError={setIsImportError}
        />
      }

    </div>
  );
}
