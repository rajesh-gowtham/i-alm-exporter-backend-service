import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input, SearchInput } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DeleteConfirmModelUI, ErrorToaster, SuccessToaster, TableActionIcons } from "@/components/UtilComp";
import { PointofWork, PoolOptionList, PowOptionList } from "@/lib/models";
import { fetchEquipments } from "@/lib/services/equipment-services";
import { fetchEquipmentPools } from "@/lib/services/equipmentpool-services";
import {
  addPointofWork,
  deletePointofWork,
  editPointofWork,
  fetchPointofWorks,
} from "@/lib/services/pointofwork-services";
import { ColumnDef, PaginationState } from '@tanstack/react-table';
import { useEffect, useState } from "react";
import { mutate } from "swr";
import { DataTable } from "../data-table";
import usePointofWorkStore from "../store/PointofWorkStore";
import PointofWorkForm from "./pointofwork-form";

export default function PointofWorkMaster() {
  const [PointofWorks, setPointofWorks] = useState<PointofWork[]>([]);
  const [powOptionList, setPowOptionList] = useState<PowOptionList[]>([]);
  const [poolOptionList, setPoolOptionList] = useState<PoolOptionList[]>([]);
  const [totalRecord, setTotalRecord] = useState(0);
  const [paged, setPaged] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
    search: ""
  });
  // const [filteredPointofWorks, setFilteredPointofWorks] = useState<PointofWork[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [PointofWorkToEdit, setPointofWorkToEdit] = useState<PointofWork | undefined>(undefined);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [PointofWorkToDelete, setPointofWorkToDelete] = useState<PointofWork | undefined>(undefined);
  const PointofWorkStore = usePointofWorkStore();
  const handlePaginationChange = (newPagination: PaginationState) => {
    setPaged(newPagination);
  }

  const columnsConfig = [
    { key: "name", title: "POW Name", hidden: false },
    { key: "pool", title: "Pool Name", hidden: false },
  ];

  const columns: ColumnDef<PointofWork>[] = [
    ...columnsConfig.map(({ key, title, hidden }) => ({
      accessorKey: key,
      header: title,
      // header: ({ column }: { column: Column<Vessel> }) => SortableHeader({ column, title }),
      // enableHiding: true,
      enableSorting: false,
      meta: { hidden },
    })),
    {
      accessorKey: "actions",
      header: "Action",
      enableSorting: false,
      enableHiding: false,
      meta: {
        hidden: false,
      },
      cell: ({ row }: { row: { original: PointofWork } }) => (
        <TableActionIcons
          handleDeleteClick={handleDeleteClick}
          handleEditClick={handleEdit}
          loading={loading}
          rowOriginal={row.original}
        />
      ),
    },
  ];
  const fetchData = async () => {
    const skip = paged.pageIndex * paged.pageSize;
    const take = paged.pageSize;
    const search = paged.search;
    try {
      const data = await fetchPointofWorks(skip, take, search);
      const items = data?.items ?? [];
      const totalCount = data?.totalCount ?? 0;
      setTotalRecord(totalCount as number);
      setPointofWorks(items as PointofWork[]);
      PointofWorkStore.setPointofWorks(items as PointofWork[]);
    } finally {
      setOpen(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [paged]);

  const handleEdit = async (PointofWork: PointofWork) => {
    try {
      // setLoading(true)
      console.log("pow", PointofWork);
      setPointofWorkToEdit(PointofWork);
      await fetchPowAndPoolOptions();
      setOpen(true);
      setLoading(false)
    } catch (error) {
      console.error(error);
      setLoading(false)
    }
  };

  const handleDeleteClick = (PointofWork: PointofWork) => {
    setPointofWorkToDelete(PointofWork);
    setConfirmDeleteOpen(true);
  };

  const confirmDelete = async () => {
    try {
      if (PointofWorkToDelete?.id) {
        // setLoading(true);
        await deletePointofWork(PointofWorkToDelete.id.toString());
        await fetchData();
        SuccessToaster("", "POW deleted successfully");
        mutate("pointofworks");
        setLoading(false);
      }
      setConfirmDeleteOpen(false);
    }    catch (error) {
      console.error(error);
      ErrorToaster("POW Deletion Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally{
      setConfirmDeleteOpen(false);
    }
  };

  const handleSubmit = async (
    data: Omit<PointofWork, "id" | "created" | "updated">
  ) => {
    try {
      // setLoading(true);
      if (PointofWorkToEdit?.id) {
        await editPointofWork(PointofWorkToEdit.id + "", data);
        SuccessToaster("", "POW Updated successfully");
      } else {
        // const isPOWExists = PointofWorks?.some(item => (item.name.toLowerCase().trim() === data.name.toLowerCase().trim()));
        // if (isPOWExists) {
        //   ErrorToaster('', "POW already exists")
        //   setLoading(false);
        //   return;
        // }
        await addPointofWork(data);
        SuccessToaster("", "POW created successfully");
      }
      setOpen(false);
      setPointofWorkToEdit(undefined);
      await fetchData();
      mutate("pointofworks");
      setLoading(false);
    } catch (error) {
      ErrorToaster("POW Creation Failed", error instanceof Error ? error?.response?.data : "Unknown error occurred")
    }
    finally{
      setLoading(false);
    }
  };
  // useEffect(() => {
  //   if (!searchQuery) {
  //     setFilteredPointofWorks(PointofWorks);
  //   } else {
  //     const lowerCasedQuery = searchQuery.toLowerCase();
  //     console.log(" PointofWorks ", PointofWorks);
  //     const filtered = PointofWorks.filter(
  //       (PointofWork) =>
  //         PointofWork?.name?.toLowerCase().includes(lowerCasedQuery) ||
  //         PointofWork.pool.toLowerCase().includes(lowerCasedQuery)
  //     );
  //     const start = paged.pageIndex * paged.pageSize;
  //     const end = start + paged.pageSize;
  //     setFilteredPointofWorks(filtered.slice(start, end));
  //   }
  // }, [searchQuery, PointofWorks]);

  const fetchPowAndPoolOptions = async () => {
    try {
      const equipmentList = await fetchEquipments();
      console.log(" equipmentList ", equipmentList);
      const tempPowOptins = (equipmentList.items.filter(item => item.equipmentType === "STS")).map(item => ({
        powId: item.id || "",
        powName: item.equipmentName || ""
      }));
      const equipmentPoolList = await fetchEquipmentPools();
      const tempEquipmentPoolList = equipmentPoolList.items.map(item => ({
        poolId: item.id || "",
        pool: item.poolName || ""
      }));
      setPowOptionList(tempPowOptins);
      setPoolOptionList(tempEquipmentPoolList);
      console.log(tempPowOptins, tempEquipmentPoolList);
    } catch (error) {
      console.error(error)
    }
  }
  const handleAddButtonClick = () => {
    setOpen(true);
    setPointofWorkToEdit(undefined);
    fetchPowAndPoolOptions();
  }
  const onSearchChange = (searchText: string) => {
    setSearchQuery(searchText);
    if (searchText.length === 0 || searchText.length >= 3) {
      setPaged(prev => ({
        ...prev,
        search: searchText
      }))
    }
  }
  return (
    <div>
      <div className="flex justify-between mt-2 px-4 mb-4 space-x-2">
        <SearchInput
          type="search"
          placeholder="POW Name/Pool Name..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-1/3 placeholder:text-black/40"
        />
        <div className="flex space-x-2">
          {/* <Button size="sm" variant="outline" disabled={loading} onClick={() => navigate("/management/pointofwork/import")}>
            Import
          </Button>  */}
          <Button
            size="sm"
            disabled={loading}
            className="bg-[#34658A] text-white hover:bg-[#E98028] text-lg pb-1  flex justify-center items-center"
            onClick={() => {
              setOpen(true);
              setPointofWorkToEdit(undefined);
              fetchPowAndPoolOptions();
            }}
          >
            +
          </Button>
        </div>
      </div>
      {loading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="w-full h-8" />
          ))}
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={PointofWorks || []}
          totalRecords={totalRecord}
          pagination={paged}
          onPaginationChange={handlePaginationChange}
        />
      )}

      {/* Confirm Delete Modal */}
      {confirmDeleteOpen &&
        <DeleteConfirmModelUI
          isModelOpen={confirmDeleteOpen}
          loading={loading}
          onConfirmDeleteClick={confirmDelete}
          setIsModelOpen={setConfirmDeleteOpen}
          selectedName={PointofWorkToEdit?.name || ""}
        />
      }
      {/* Vessel Form Modal */}
      <Dialog
        open={open}
        onOpenChange={(isOpen) => {
          setOpen(isOpen);
          if (!isOpen) setPointofWorkToEdit(undefined);
        }}
      >
        <DialogContent>
          <DialogTitle>
            {PointofWorkToEdit ? "Edit POW" : "Add POW"}
          </DialogTitle>
          <PointofWorkForm
            PointofWork={PointofWorkToEdit}
            onClose={() => {
              setOpen(false);
              setPointofWorkToEdit(undefined);
            }}
            onSubmit={handleSubmit}
            powOptionList={powOptionList}
            poolOptionList={poolOptionList}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
