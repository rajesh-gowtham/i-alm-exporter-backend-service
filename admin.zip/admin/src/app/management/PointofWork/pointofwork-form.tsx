import { Label } from "@/components/ui/label";
import { DropdownWhite, ErrorToaster, FormActions, MandatoryIcon } from "@/components/UtilComp";
import { PointofWork, PoolOptionList, PowOptionList } from "@/lib/models";
import { PointofWorkSchema } from "@/lib/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useState
} from "react";
import { useForm } from "react-hook-form";
import * as z from "zod";
interface PointofWorkFormProps {
  PointofWork?: PointofWork;
  onClose: () => void;
  poolOptionList: PoolOptionList[];
  powOptionList: PowOptionList[];
  onSubmit: (data: PointofWork) => void;
}

export default function PointofWorkForm({ PointofWork, onClose, onSubmit, poolOptionList, powOptionList }: PointofWorkFormProps) {
  const [isLoading, setIsLoading] = useState(false); // Add loading state
  console.log("PointofWork", PointofWork, poolOptionList, powOptionList);
  const {
    // register,
    // reset,
    handleSubmit,
    setValue,
    clearErrors,
    formState: { errors },
  } = useForm<z.infer<typeof PointofWorkSchema>>({
    resolver: zodResolver(PointofWorkSchema),
    defaultValues: PointofWork || {},
  });

  // const PointofWorkMemo = useMemo(() => PointofWork, [PointofWork]);

  const submitHandler = async (formData: z.infer<typeof PointofWorkSchema>) => {
    setIsLoading(true); // Set loading to true
    try {
      console.log("Submit handler called", formData);
      onSubmit(formData);
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false); // Set loading to false
    }
  };
  const handleError = (formErrors: typeof errors) => {
    console.error("Validation errors", formErrors);
    ErrorToaster("Please fill all required fields.");
  };
  return (
    <form
      // onSubmit={handleSubmit(submitHandler)}
      onSubmit={handleSubmit(submitHandler, handleError)}
      className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* ... (input fields) ... */}
        <div>
          <Label>Pow Name</Label>
          <MandatoryIcon />
          <DropdownWhite
            Label_Placeholder={"Pow Name"}
            fieldName="name"
            fieldValue={PointofWork?.name || ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={powOptionList?.map(item => ({ label: item.powName, value: (item.powName) + "" }))}
            error={!!errors.name}
          />
        </div>
        <div>
          <Label>Pool</Label>
          <MandatoryIcon />
          <DropdownWhite
            Label_Placeholder={"Pool"}
            fieldName="pool"
            fieldValue={PointofWork?.pool || ""}
            setValue={setValue}
            clearErrors={clearErrors}
            optionsList={poolOptionList?.map(item => ({ label: item.pool, value: (item.pool) + "" }))}
            error={!!errors.pool}
          />
        </div>
      </div>
      <FormActions
        isEdit={PointofWork?.id ? true : false}
        isLoading={isLoading}
        onClose={onClose}
      />
    </form>
  );
}
