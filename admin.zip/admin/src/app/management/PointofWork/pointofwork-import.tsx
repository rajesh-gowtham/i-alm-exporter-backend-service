import { useEffect, useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import * as XLSX from "xlsx";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useMasterDataStore } from "../store/MasterDataImportStore";
import { PointofWorkSchema, FileImportSchema } from "@/lib/schemas";
import { addPointofWorkInBatch } from "@/lib/services/pointofwork-services";
import { toast } from "sonner";
import { ReloadIcon } from "@radix-ui/react-icons";
import { EditableCell } from "@/components/EditableCell";


// Enhanced schema with coercion and validation
const numericFields = ['overallLength'];

type PointofWorkRecord = z.infer<typeof PointofWorkSchema>;



type FormData = z.infer<typeof FileImportSchema>;


export default function PointofWorkImport() {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FileImportSchema),
  });

  const [uploading, setUploading] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [validRecords, setValidRecords] = useState<PointofWorkRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [validationErrors, setValidationErrors] = useState<any[]>([]);
  const [tableData, setTableData] = useState<Array<Record<string, any>>>([]);
  const [columns, setColumns] = useState<Array<{ Header: string; accessor: string }>>([]);

  const { addRecord } = useMasterDataStore();

  const batchInsert = async (records: PointofWorkRecord[]) => {
    setBatchProcessing(true);
    const totalRecords = records.length;
    try {
      const batchSize = 200;
      for (let i = 0; i < records.length; i += batchSize) {
        const batch = records.slice(i, i + batchSize);
        await addPointofWorkInBatch(batch);
        const progress = Math.min(100, ((i + batch.length) / totalRecords) * 100);
        setImportProgress(progress);
        await new Promise((r) => setTimeout(r, 100));
      }

      toast.success("Import Completed", {
        description: `${totalRecords} PointofWorks imported successfully`,
      });
    } catch (error) {
      toast.error("Import Failed", {
        description: error instanceof Error ? error.message : "Unknown error occurred",
      });
    } finally {
      setBatchProcessing(false);
      setImportProgress(0);
      setShowConfirmModal(false);
      reset();
    }
  };

  const updateData = (rowIndex: number, columnId: string, value: any) => {
    setTableData(prev =>
      prev.map((row, index) => {
        if (index === rowIndex) {
          return {
            ...row,
            [columnId]: value,
          };
        }
        return row;
      })
    );
  };

  useEffect(() => {
    if (tableData.length === 0) return;
    
    const validationResults = tableData.map((row, index) => {
      const result = PointofWorkSchema.safeParse(row);
      return {
        row: index + 2,
        valid: result.success,
        errors: result.success ? [] : result.error.errors,
        data: result.success ? result.data : null
      };
    });

    const valid = validationResults.filter(r => r.valid).map(r => r.data) as PointofWorkRecord[];
    const errors = validationResults.filter(r => !r.valid).map(r => ({
      row: r.row,
      issues: r.errors,
      original: tableData[r.row - 2]
    }));

    setValidRecords(valid);
    setValidationErrors(errors);
  }, [tableData]);

  const processExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const binary = e.target?.result;
      const workbook = XLSX.read(binary, { type: "binary" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      
      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      const [headerRow, ...rows] = jsonData;
      const headers = headerRow as string[];

      const newColumns = headers.map((header) => ({
        Header: header,
        accessor: header,
      }));
      setColumns(newColumns);

      const newData = rows.map((row) =>
        headers.reduce((obj, header, idx) => ({
          ...obj,
          [header]: row[idx] ?? '',
        }), {})
      );
      setTableData(newData);
      setShowConfirmModal(true);
      setUploading(false);
    };
    reader.readAsBinaryString(file);
  };

  const renderTable = () => (
    <div className="overflow-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {columns.map((column) => (
              <th
                key={column.accessor}
                className="sticky top-0 p-2 text-left border border-gray-200 bg-muted"
              >
                {column.Header}
                {numericFields.includes(column.accessor) && (
                  <span className="ml-1 text-xs text-gray-500">(number)</span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, rowIndex) => {
            const isInvalid = validationErrors.some(e => e.row === rowIndex + 2);
            return (
              <tr
                key={rowIndex}
                className={isInvalid ? 'bg-muted hover:bg-red-100' : ''}
              >
                {columns.map((column) => {
                  const isNumeric = numericFields.includes(column.accessor);
                  return (
                    <td key={column.accessor} className="border border-gray-200">
                      <EditableCell
                        value={row[column.accessor]}
                        row={{ index: rowIndex }}
                        column={{ id: column.accessor }}
                        isNumeric={isNumeric}
                        updateData={updateData}
                      />
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="max-w-4xl p-6 mx-auto rounded-lg shadow-md bg-muted">
      <form onSubmit={handleSubmit((data) => {
        setUploading(true);
        processExcelFile(data.file[0]);
      })} className="space-y-4">
        <p className="text-sm text-gray-600">
          Download template:{" "}
          <a href="/files/dataimport/pointofworkmaster.xlsx" className="text-blue-600 hover:underline">
          pointofworkmaster.xlsx
          </a>
        </p>

        <div className="space-y-2">
          <Input
            type="file"
            accept=".xlsx"
            {...register("file")}
            className="w-full p-2 border rounded-md"
          />
          {errors.file && (
            <p className="mt-1 text-sm text-red-500">{errors.file.message}</p>
          )}
         
        </div>

        <Button
          type="submit"
          disabled={uploading}
          className="w-full text-white bg-blue-600 hover:bg-blue-700 disabled:bg-muted disabled:cursor-not-allowed"
        >
          {uploading ? "Processing..." : "Upload & Validate"}
        </Button>
      </form>

      <Dialog 
        open={showConfirmModal} 
        onOpenChange={(open) => !batchProcessing && setShowConfirmModal(open)}
      >
         <DialogContent className="max-w-[95vw] h-[85vh] overflow-auto flex flex-col p-0">
          <div className="p-6 border-b">
            <DialogTitle className="text-lg font-semibold">
              Data Validation & Correction
            </DialogTitle>
            <DialogDescription>
              Edit cells directly and review errors before import
            </DialogDescription>
          </div>
          
          <div className="grid flex-1 grid-cols-1 gap-6 p-6 overflow-hidden lg:grid-cols-2">
            <div className="flex flex-col space-y-4 overflow-hidden">
              <div className="p-4 border border-gray-200 rounded-lg bg-muted">
                <h3 className="mb-3 font-medium text-gray-700">Validation Summary</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Valid Records:</span>
                    <span className="font-medium text-green-600">{validRecords.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Errors Found:</span>
                    <span className="font-medium text-red-600">{validationErrors.length}</span>
                  </div>
                </div>
              </div>

              {validationErrors.length > 0 && (
                <div className="p-4 overflow-auto border border-red-200 rounded-lg bg-muted">
                  <h4 className="mb-3 font-medium text-red-700">Validation Errors</h4>
                  <div className="space-y-3">
                    {validationErrors.map((error, index) => (
                      <div key={index} className="p-3 border border-red-100 rounded bg-muted">
                        <div className="flex items-start mb-2">
                          <span className="mr-2 font-mono text-red-600">Row {error.row}:</span>
                          <div className="flex flex-wrap gap-1">
                            {error.issues.map((issue: any) => (
                              <span
                                key={issue.path.join(".")}
                                className="px-2 py-1 text-xs text-red-800 bg-red-100 rounded"
                              >
                                {issue.code === 'invalid_type' ? 
                                  `Invalid type for ${issue.path.join('.')}` : 
                                  issue.message}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-1 text-sm text-gray-600">
                          {Object.entries(error.original).map(([key, value]) => (
                            <div key={key} className="flex items-baseline">
                              <span className="w-24 font-medium text-gray-500 truncate">{key}:</span>
                              <span className="flex-1 ml-2 font-mono text-gray-700">{String(value)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col h-full border-l lg:border-l-0 lg:border-t">
              <div className="p-4 border-b border-gray-200 bg-muted">
                <h3 className="font-medium text-gray-700">
                  Excel Preview
                  <span className="ml-2 text-sm font-normal text-gray-500">(Editable cells)</span>
                </h3>
              </div>
              {renderTable()}
            </div>
          </div>

          <div className="flex flex-col gap-3 p-4 border-t bg-muted">
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 text-gray-700 border-gray-300 hover:bg-muted"
                disabled={batchProcessing}
              >
                Cancel
              </Button>
              <Button
                onClick={() => batchInsert(validRecords)}
                className="px-6 text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                disabled={validRecords.length === 0 || batchProcessing}
              >
                {batchProcessing ? (
                  <div className="flex items-center gap-2">
                    <ReloadIcon className="w-4 h-4 animate-spin" />
                    Importing ({Math.round(importProgress)}%)
                  </div>
                ) : (
                  `Import Valid Data (${validRecords.length})`
                )}
              </Button>
            </div>
            {batchProcessing && (
              <div className="w-full mt-2">
                <Progress value={importProgress} className="h-2" />
                <p className="mt-1 text-xs text-center text-gray-500">
                  {Math.round(importProgress)}% completed
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}