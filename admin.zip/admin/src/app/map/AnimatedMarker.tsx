/* import React, { useEffect, useRef, useState } from "react";
import { RMarker } from "maplibre-react-components";
import * as turf from "@turf/turf";

export const AnimatedMarker = React.memo(function AnimatedMarker({
  equipmentId,
  image,
  rotation,
  targetLat,
  targetLng,
  size,
  duration = 400,
}: {
  equipmentId: number;
  image: string;
  rotation: number;
  targetLat: number;
  targetLng: number;
  size: number;
  duration?: number;
}) {
  const [position, setPosition] = useState({ lat: targetLat, lng: targetLng });

  const startRef = useRef({ lat: targetLat, lng: targetLng });
  const startTimeRef = useRef<number | null>(null);
  const animationRef = useRef<number | null>(null);

  const isMovementSignificant = (
    a: number,
    b: number,
    threshold = 0.0000001
  ) => Math.abs(a - b) > threshold;

  const easeInOutQuad = (t: number) =>
    t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

  useEffect(() => {
    const from = turf.point([position.lng, position.lat]);
    const to = turf.point([targetLng, targetLat]);
    const distance = turf.distance(from, to, { units: "meters" });

    if (
      !isMovementSignificant(targetLat, position.lat) &&
      !isMovementSignificant(targetLng, position.lng)
    ) {
      // Prevent unnecessary animation
      return;
    }

    const bearing = turf.bearing(from, to);

    if (isNaN(bearing) || distance === 0) {
      console.warn("Invalid bearing or distance — skipping animation");
      return;
    }

    const animate = (timestamp: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = timestamp;
        startRef.current = { ...position };
      }

      const elapsed = timestamp - startTimeRef.current;
      const t = Math.min(1, elapsed / duration);
      const easedT = easeInOutQuad(t);
      const currentDistance = distance * easedT;

      const interpolated = turf.destination(from, currentDistance, bearing, {
        units: "meters",
      });

      const [lng, lat] = interpolated.geometry.coordinates;
      setPosition({ lat, lng });

      if (t < 1) {
        animationRef.current = requestAnimationFrame(animate);
      } else {
        startTimeRef.current = null;
        animationRef.current = null;
      }
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [targetLat, targetLng]);

  return (
    <RMarker
      key={equipmentId}
      longitude={position.lng}
      latitude={position.lat}
      rotation={rotation}
    >
      <div
        style={{
          width: `${size}px`,
          height: `${size}px`,
          backgroundImage: `url(${image})`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          pointerEvents: "none",
        }}
      />
    </RMarker>
  );
} );

*/


import React, { useEffect, useRef, useState } from "react";
import { RMarker } from "maplibre-react-components";
import { useUltraSmooth } from "./Markers/hooks";

export function AnimatedMarker({
  equipmentId,
  image,
  rotation,
  targetLat,
  targetLng,
  size,
}: {
  equipmentId: number;
  image: string;
  rotation: number;
  targetLat: number;
  targetLng: number;
  size: number;
}) {
  const {lat, lng} = useUltraSmooth([targetLng, targetLat], )



  return (
    <RMarker
      key={equipmentId}
      longitude={lng}
      latitude={lat}
      rotation={rotation}
    >
      <div
        style={{
          width: `${size}px`,
          height: `${size}px`,
          backgroundImage: `url(${image})`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          pointerEvents: "none",
        }}
      />
    </RMarker>
  );
}