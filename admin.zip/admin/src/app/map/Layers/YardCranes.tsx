/* import { useEffect, useRef, useState } from "react";
import * as turf from "@turf/turf";
import ContainerCenereLine from "@/data/geojsonnew/centerline_yard.json";
import GeoJsonLayer from "../GeoJsonLayer";
import {
  INITIAL_MAX_ZOOM,
  INITIAL_MIN_ZOOM,
  INITIAL_ZOOM,
} from "../MapConstants";

// Crane Type
type Crane = {
  id: string;
  yard: string;
  longitude: number;
  latitude: number;
};

type SnappedCrane = Crane & {
  snappedLng: number;
  snappedLat: number;
};

const CRANE_CONFIGURATIONS = {
  DOUBLE_SIDED_YARDS: ['1D', '2D', '3D', '1E', '2E', '3E'],
  ROTATED_YARDS: {
    '1A': 179.5, '1C': 179.5, '2A': 179.5,
    '2C': 179.5, '3A': 179.5, '3C': 179.5
  },
  OFFSET_YARDS: {
    GROUP1: ['1A', '1C', '2A', '2C', '3A', '3C'],
    GROUP2: ['1B', '2B', '3B']
  }
};

const ZOOM_SCALE = [
  { zoom: 16, size: 0.20 },
  { zoom: 17, size: 0.33 },
  { zoom: 18, size: 0.75 },
  { zoom: 19, size: 1.55 },
  { zoom: 20, size: 3.03 },
  { zoom: 21, size: 6.3 },
  { zoom: 22, size: 12.5 }
];

function animateCraneMovement(
  start: [number, number],
  end: [number, number],
  duration: number,
  onUpdate: (coords: [number, number]) => void,
  onComplete?: () => void
) {
  const startTime = performance.now();
  const routeLine = turf.lineString([start, end]);
  const totalDistance = turf.length(routeLine, { units: "meters" });

  function step(now: number) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const distanceAlong = progress * totalDistance;
    const currentPoint = turf.along(routeLine, distanceAlong, { units: "meters" });
    onUpdate(currentPoint.geometry.coordinates as [number, number]);

    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      onComplete?.();
    }
  }

  requestAnimationFrame(step);
}

function snapCraneToLine(crane: Crane): [number, number] {
  const point = turf.point([crane.longitude, crane.latitude]);
  const snapped = turf.nearestPointOnLine(ContainerCenereLine, point, { units: "meters" });
  return snapped.geometry.coordinates as [number, number];
}

export default function YardCranesLayer({ YardCranes }: { YardCranes: Crane[] }) {
  const [cranes, setCranes] = useState<SnappedCrane[]>(() =>
    YardCranes.map((crane) => {
      const [snappedLng, snappedLat] = snapCraneToLine(crane);
      return { ...crane, snappedLng, snappedLat };
    })
  );

  const previousCranesRef = useRef<Crane[]>(YardCranes);
  const animatingRef = useRef<Record<string, boolean>>({});

  useEffect(() => {
    if (!YardCranes || YardCranes.length === 0) return;

    YardCranes.forEach((newCrane) => {
      const oldCrane = previousCranesRef.current.find(c => c.id === newCrane.id);
      const isMoving =
        !oldCrane ||
        oldCrane.latitude !== newCrane.latitude ||
        oldCrane.longitude !== newCrane.longitude;
console.log('isMoving', isMoving);
      if (isMoving && !animatingRef.current[newCrane.id]) {
        const start: [number, number] = oldCrane
          ? snapCraneToLine(oldCrane)
          : snapCraneToLine(newCrane);
        const end: [number, number] = snapCraneToLine(newCrane);

        const route = turf.lineString([start, end]);
        const distance = turf.length(route, { units: "meters" });
        const duration = (distance / 1.3) * 1000;

        animatingRef.current[newCrane.id] = true;

        animateCraneMovement(start, end, duration, (coords) => {
          setCranes((prev) =>
            prev.map((c) =>
              c.id === newCrane.id
                ? {
                    ...c,
                    longitude: newCrane.longitude,
                    latitude: newCrane.latitude,
                    snappedLng: coords[0],
                    snappedLat: coords[1],
                  }
                : c
            )
          );
        }, () => {
          animatingRef.current[newCrane.id] = false;
        });
      }
    });

    previousCranesRef.current = YardCranes;
  }, [YardCranes]);

  return (
    <>
      <GeoJsonLayer
        id="craneCenterLine"
        data={ContainerCenereLine}
        minzoom={INITIAL_MIN_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="line"
        paint={{ "line-color": "#c0d1f7", "line-width": 3 }}
        layout={{ visibility: "none" }}
        beforeId="yard-cranes-layer-layer"
      />
      <GeoJsonLayer
        id="yard-cranes-layer"
        data={{
          type: "FeatureCollection",
          features: cranes.map((crane) => ({
            type: "Feature",
            geometry: {
              type: "Point",
              coordinates: [crane.snappedLng, crane.snappedLat],
            },
            properties: {
              id: crane.id,
              yardNo: crane.yard,
            },
          })),
        }}
        minzoom={INITIAL_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="symbol"
        layout={{
          "icon-image": [
            "match", ["get", "yardNo"],
            ...CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.flatMap(y => [y, "double-side-yard-crane"]),
            "single-side-yard-crane"
          ],
          "icon-rotate": [
            "match", ["get", "yardNo"],
            ...Object.entries(CRANE_CONFIGURATIONS.ROTATED_YARDS).flat(),
            -0.5
          ],
          "icon-size": [
            "interpolate", ["linear"], ["zoom"],
            ...ZOOM_SCALE.flatMap(({ zoom, size }) => [zoom, size])
          ],
          "icon-offset": [
            "match", ["get", "yardNo"],
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.map(y => [y, ["literal", [0, 10]]]).flat(),
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.map(y => [y, ["literal", [0, 7]]]).flat(),
            ["literal", [0, 0]]
          ],
          "icon-allow-overlap": true,
          "icon-ignore-placement": true,
          "icon-anchor": "center",
        }}
        paint={{}}
        beforeId="Quay-cranes-layer"
      />
    </>
  );
} */

  import { useEffect, useRef, useState } from "react";
import * as turf from "@turf/turf";
import ContainerCenereLine from "@/data/geojsonnew/centerline_yard.json";
import YardCranesRoute from "@/data/geojsonnew/Ycrane_point_route.json";
import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, INITIAL_ZOOM } from "../MapConstants";

// Crane Type
type Crane = {
  id: string;
  yard: string;
  longitude: number;
  latitude: number;
};

type SnappedFeatureProperties = {
  id: string;
  yardNo: string;
  originalLongitude: number;
  originalLatitude: number;
};

// Crane Config
const CRANE_CONFIGURATIONS = {
  DOUBLE_SIDED_YARDS: ["1D", "2D", "3D", "1E", "2E", "3E"],
  ROTATED_YARDS: {
    "1A": 179.5, "1C": 179.5, "2A": 179.5,
    "2C": 179.5, "3A": 179.5, "3C": 179.5
  },
  OFFSET_YARDS: {
    GROUP1: ["1A", "1C", "2A", "2C", "3A", "3C"],
    GROUP2: ["1B", "2B", "3B"]
  }
};

const ZOOM_SCALE = [
  { zoom: 16, size: 0.20 },
  { zoom: 17, size: 0.33 },
  { zoom: 18, size: 0.75 },
  { zoom: 19, size: 1.55 },
  { zoom: 20, size: 3.03 },
  { zoom: 21, size: 6.3 },
  { zoom: 22, size: 12.5 }
];

function animateCraneMovement(
  start: [number, number],
  end: [number, number],
  duration: number,
  onUpdate: (coords: [number, number]) => void,
  onComplete?: () => void
) {
  const startTime = performance.now();
  const routeLine = turf.lineString([start, end]);
  const totalDistance = turf.length(routeLine, { units: "meters" });

  function step(now: number) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const distanceAlong = progress * totalDistance;
    const currentPoint = turf.along(routeLine, distanceAlong, { units: "meters" });
    onUpdate(currentPoint.geometry.coordinates as [number, number]);

    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      onComplete?.();
    }
  }

  requestAnimationFrame(step);
}

function snapPointsToLine(
  points: Crane[],
  line: turf.Feature<turf.LineString> | turf.LineString,
  options: turf.NearestPointOnLineOptions = { units: "meters" }
): turf.Feature<turf.Point, SnappedFeatureProperties>[] {
  return points.map((point) => {
    const targetPoint = turf.point([point.longitude, point.latitude]);
    const snapped = turf.nearestPointOnLine(line, targetPoint, options);

    return {
      type: "Feature",
      geometry: snapped.geometry,
      properties: {
        id: point.id,
        originalLongitude: point.longitude,
        originalLatitude: point.latitude,
        yardNo: point.yard,
      },
    };
  });
}

export default function YardCranesLayer({ yardCranes }: { yardCranes: Crane[] }) {
  const [cranes, setCranes] = useState<Crane[]>(yardCranes);
  const prevCranesRef = useRef<Crane[]>(yardCranes);
  const activeAnimations = useRef<Record<string, boolean>>({});

  useEffect(() => {
    if (!Array.isArray(yardCranes)) return;

    yardCranes.forEach((newCrane) => {
      const prevCrane = prevCranesRef.current.find(c => c.id === newCrane.id);
      const alreadyAnimating = activeAnimations.current[newCrane.id];

      if (
        prevCrane &&
        (prevCrane.latitude !== newCrane.latitude || prevCrane.longitude !== newCrane.longitude) &&
        !alreadyAnimating
      ) {
        const start: [number, number] = [prevCrane.longitude, prevCrane.latitude];
        const end: [number, number] = [newCrane.longitude, newCrane.latitude];
        const route = turf.lineString([start, end]);
        const distance = turf.length(route, { units: "meters" });
        // const duration = (distance / 1.3) * 500;
        // Tune animation duration based on small movements
          const speedMetersPerSec = 1.3; // your crane speed
          const minDuration = 300; // never faster than this, even for tiny moves
          const maxDuration = 8000; // upper limit for long moves

         


          // Match real speed: duration = distance / speed
          let duration = (distance / speedMetersPerSec) * 1000;

          // Smooth even for very small moves
          if (distance < 2) duration = 6000;
          else if (distance < 5) duration = 7000;
          else if (distance < 7) duration = 8000;
          // Clamp to min/max
          duration = Math.min(Math.max(duration, minDuration), maxDuration);

        activeAnimations.current[newCrane.id] = true;

        animateCraneMovement(start, end, duration,
          (coords) => {
            setCranes(prev =>
              prev.map(c =>
                c.id === newCrane.id ? { ...c, longitude: coords[0], latitude: coords[1] } : c
              )
            );
          },
          () => {
            activeAnimations.current[newCrane.id] = false;
          }
        );
      }

      if (!prevCrane) {
        setCranes((prev) =>
          prev.map((c) =>
            c.id === newCrane.id
              ? { ...c, longitude: newCrane.longitude, latitude: newCrane.latitude }
              : c
          )
        );
      }
    });

    prevCranesRef.current = yardCranes;
  }, [yardCranes]);

  const snappedCranes = snapPointsToLine(cranes, ContainerCenereLine);

  return (
    <>
      <GeoJsonLayer
        id="craneCenterLine"
        data={ContainerCenereLine}
        minzoom={INITIAL_MIN_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="line"
        paint={{ "line-color": "#c0d1f7", "line-width": 3 }}
        layout={{ visibility: "none" }}
        beforeId="yard-cranes-layer-layer"
      />
      <GeoJsonLayer
        id="yard-cranes-layer"
        data={{
          type: "FeatureCollection",
          features: snappedCranes,
        }}
        minzoom={INITIAL_ZOOM}
        maxzoom={INITIAL_MAX_ZOOM}
        type="symbol"
        layout={{
          "icon-image": ["match", ["get", "yardNo"],
            ...CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.flatMap(yard => [yard, "double-side-yard-crane"]),
            "single-side-yard-crane"
          ],
          "icon-rotate": ["match", ["get", "yardNo"],
            ...Object.entries(CRANE_CONFIGURATIONS.ROTATED_YARDS).flat(),
            -0.5
          ],
          "icon-size": [
            "interpolate", ["linear"], ["zoom"],
            ...ZOOM_SCALE.flatMap(({ zoom, size }) => [zoom, size])
          ],
          "icon-offset": ["match", ["get", "yardNo"],
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP1.map(yard => [yard, ["literal", [0, 10]]]).flat(),
            ...CRANE_CONFIGURATIONS.OFFSET_YARDS.GROUP2.map(yard => [yard, ["literal", [0, 7]]]).flat(),
            ["literal", [0, 0]]
          ],
          "icon-allow-overlap": true,
          "icon-ignore-placement": true,
          "icon-anchor": "center",
        }}
        paint={{}}
        beforeId="Quay-cranes-layer"
      />
    </>
  );
}
