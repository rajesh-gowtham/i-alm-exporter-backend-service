import GeoJsonLayer from "../GeoJsonLayer";
import Road from "@/data/geojsonnew/road_v1.json";
import ServiceLane from "@/data/geojsonnew/service_lane.json";
import CenterLine from '@/data/geojsonnew/centre_line_truck_traffic_point.json';
import { INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, MODIFIED_MIN_ZOOM } from "../MapConstants";

export default function RoadLane() {
    return (
        <>
            <GeoJsonLayer
                id="Road"
                data={Road}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={{
                    "line-color": [
                        "match",
                        ["get", "LAYER"],
                        "Centerline", "transparent",
                        "Service Lane", "transparent",
                        "centre line truck traffic", "transparent",
                        "#c2d1fa"
                    ],
                    "line-width": 1,
                }}
                filter={["!=", ["get", "LAYER"], "MA_CRMG TRACK"]}
                beforeId="ContainersType-cross-line-layer"
            />
            <GeoJsonLayer
                id="RoadRail"
                data={Road}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                paint={{
                    "line-color": "#5e2120",
                    "line-dasharray": [2, 2],
                    "line-width": 1
                }}
                filter={["==", ["get", "LAYER"], "MA_CRMG TRACK"]}
                beforeId="Road-layer"
            />
            <GeoJsonLayer
                id="ServiceLane"
                data={ServiceLane}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{ "fill-color": "#155bbd", "fill-pattern": "boxed-stripe", "fill-opacity": 0.4 }}
                beforeId="RoadRail-layer"
            />
            <GeoJsonLayer
                id="centerLineJson"
                data={CenterLine}
                type="symbol"
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                layout={{
                    "text-field": ["get", "Label"],
                    "symbol-placement": "point",
                    "text-size": 10,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-overlap": "always",
                    "text-ignore-placement":true
                
                }}
                paint={{
                    "text-color": "#464646",
                }}
                beforeId="ServiceLane-layer"
            
            />
        </>
    );
}
