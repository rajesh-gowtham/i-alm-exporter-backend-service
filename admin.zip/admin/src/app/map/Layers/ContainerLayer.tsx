import GeoJsonLayer from "../GeoJsonLayer";
import ContainerYard from "@/data/geojsonnew/container_yards.json";
import ContainersType from "@/data/geojsonnew/container_type.json";
import ContainerYardCentroids from "@/data/geojsonnew/container_yards_point.json";
import ContainerTypeLabel from "@/data/geojsonnew/container_type_point.json";
import ContainerPositionLabel from "@/data/geojsonnew/container_position_v1.json";
import { containerColorMap, INITIAL_MAX_ZOOM, INITIAL_MIN_ZOOM, MODIFIED_MIN_ZOOM , INITIAL_ZOOM} from "../MapConstants";
import { useEffect, useMemo, useState } from "react";
import { RPopup } from "maplibre-react-components";
import rawContainers  from "@/data/geojsonnew/container.json";
import {fetchAllContainerInventory} from "@/lib/services/inventory-service";
import useSWR from "swr";
import PlatformLayer from "./PlatformLayer";

interface ContainerPopup {
    lat: number;
    lng:number;
    yard: string;
    bay: string;
    row: string;
    containers: string[];
    location: string[];
}

export default function ContainerLayer() {
    // console.log('containerData', containerData);
      const [containerJson, setContainerJson] = useState(rawContainers);
    const [containerPopup, setContainerPopup] = useState<ContainerPopup | null>(null);
     const { data: containersPosition } = useSWR("/inventory/container", fetchAllContainerInventory, {
        refreshInterval: 1000,
         revalidateOnFocus: true,
        revalidateOnReconnect: true,
      });

    function processContainers(data) {
      // Helper to parse location
      // location format example: "1E65A.1"
      // Here: yard = "1E", bay = "65", row = "A", position = "1"
      function parseLocation(location) {
        const [mainPart, tire] = location.split(".");
        const yard = mainPart.slice(0, 2);       // "1E"
        const bay = mainPart.slice(2, 4);        // "65"
        const row = mainPart.slice(4, 5);        // "A"
        return { yard, bay, row, tire};
      }
    
      // Grouping container data
      const grouped = {};
    
      for (const item of data.items) {
        const location = item.location;
        const { yard, bay, row, tire } = parseLocation(location);
        const key = `${yard}-${bay}-${row}-${tire}`;
        const containerLocation = location;
        if (!grouped[key]) {
          grouped[key] = {
            yard,
            bay,
            row,
            tire,
            location:[],
            count: 0,
            containers: [],
          };
        }
    
        // containerId concatenated with position with '-'
        // const containerWithPosition = `${item.containerId}-${position}`;
        const containerWithPosition = `${item.containerId}`;
        grouped[key].containers.push(containerWithPosition);
        grouped[key].location.push(containerLocation);
        grouped[key].count += 1;
      }
    
      // Convert grouped object to array for easier use
      return Object.values(grouped);
    }
    
    /* function updateGeoJson(containerjson, groupedData) {
      containerjson.features = containerjson.features.map(feature => {
        const props = feature.properties;
        const match = groupedData.find(
          group =>
            group.yard === props.yard &&
            group.bay === props.bay &&
            group.row === props.row
        );
    
        if (match) {
          return {
            ...feature,
            properties: {
              ...props,
              stack_valu: match.count, // updated stack_valu
              containerList: match.containers, // new field

            }
          };
        }
    
        return feature; // no match: return as is
      });
    
      return containerjson;
    } */

    function updateGeoJson(containerjson, groupedData) {
  containerjson.features = containerjson.features.map(feature => {
    const props = feature.properties;
    const bayNumber = parseInt(props.bay, 10);
    // Matching grouped items based on yard and row
    const matchingGroups = groupedData.filter(group => {
        
      
      const groupBay = parseInt(group.bay, 10);
      const isEvenBay = groupBay % 2 === 0;
       // console.log('isEvenBay', isEvenBay);
      const bayMatch = isEvenBay
        ? (bayNumber === groupBay - 1 || bayNumber === groupBay + 1)
        : bayNumber === groupBay;
         
      return (
        group.yard === props.yard &&
        group.row === props.row &&
        bayMatch
      );
    });
    // console.log('matchingGroups', matchingGroups);

    if (matchingGroups.length > 0) {
      // Aggregate total count and container list
      const totalCount = matchingGroups.reduce((sum, g) => sum + g.count, 0);
      const containerList = matchingGroups.flatMap(g => g.containers);
      const location  = matchingGroups.flatMap(group => group.location);
      console.log("test", location);
      return {
        ...feature,
        properties: {
          ...props,
          stack_valu: totalCount,
          location,
          containerList
        }
      };
    }

    return feature;
  });

  return containerjson;
}


    useEffect(() => {
  if (!containersPosition || containersPosition.items.length === 0) {
    // console.warn("No container data available");
     setContainerJson(structuredClone(rawContainers));
    return;
  }
  const result = processContainers(containersPosition);
  // console.log('result', result);
  const updatedGeoJson = updateGeoJson(structuredClone(rawContainers), result);
  setContainerJson(structuredClone(updatedGeoJson));
}, [containersPosition]);
    
   /*  useEffect(() => {

        console.log("Processing containers position data...", containersPosition);
      if (!containersPosition || containersPosition.items.length === 0) {
        console.warn("No container data available");
        return;
      }
      const result = processContainers(containersPosition);
    
      console.log("Containers Position:", result);
    
      const updatedGeoJson = updateGeoJson(structuredClone(rawContainers), result);
      // console.log("Updated GeoJSON:", updatedGeoJson);
      setContainerJson(updatedGeoJson)
    
    }, [containersPosition]); */
    
    function buildContainerFillColorExpression() {
        const expressions: any[] = ["case"];

        for (const [type, colors] of Object.entries(containerColorMap)) {
            if (type === "Damaged containers") {
                expressions.push(["==", ["get", "type"], type], colors[0]);
            } else if (type === "ODC Cargo") {
                expressions.push(["==", ["get", "type"], type], colors[0]);
            } else if (type === "default") {
                continue;
            } else {
                colors.forEach((color, index) => {
                    // console.log(`Adding color for type: ${type}, index: ${index}`, color);
                    expressions.push(
                        ["all", ["==", ["get", "type"], type], ["==", ["get", "stack_valu"], index]],
                        color
                    );
                });
            }
        }

        // Fallback
        expressions.push(containerColorMap.default);
        return expressions;
    }

    const containerTypeFillColor = useMemo(() => buildContainerFillColorExpression(), []);
    // console.log("containerPopup:", containerPopup);
    return (
        <>
            <GeoJsonLayer
                id="ContainerYard"
                data={ContainerYard}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                 paint={{
                          "fill-outline-color": "#5f5f5f",
                          "fill-color": "#5f5f5f",
                          "fill-opacity": 0.1
                      }}
                
            />
            <GeoJsonLayer
                id="Containers"
                data={containerJson}
                minzoom={16}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                layout={{
                   
                }}
                paint={{
                    "fill-color": [
                        "step",
                        ["get", "stack_valu"],
                        "#fff2ff",
                        0, "#fff2ff",
                        1, "#709959",
                        2, "#f2eea2",
                        3, "#f2ce85",
                        4, "#c28c7c"
                    ],
                    "fill-outline-color": "#FFFFFF",
                    
                }}
                filter={[
                        "all",
                        ["all",
                            ["!=", ["get", "bay"], null],
                            ["!=", ["get", "bay"], ""],
                            ["<=", ["get", "bay"], "35"]
                        ],
                        ["all",
                            ["!=", ["get", "row"], null],
                            ["!=", ["get", "row"], ""]
                        ]
                    ]}
                    onHover={(e) => {
                        // console.log('hoverevent', e)
                        const feature = e.features?.[0];
                        // console.log('onhver', feature);
                        if (feature?.properties?.containerList) {
                           //  console.log("ABCD");
                            const rawList = feature.properties.containerList;
                            const locationList = feature.properties.location;
                            // Step 1: Join string fragments if it's an array of partial strings
                            const jsonString = Array.isArray(rawList) ? rawList.join("") : rawList;
                            const locationjsonString = Array.isArray(locationList)? locationList.join(""): locationList;
                            // Step 2: Parse JSON safely
                            let containers: string[] = [];
                            let location: string[] =[];
                            try {
                                containers = JSON.parse(jsonString);
                                location = JSON.parse(locationjsonString);

                            } catch (err) {
                                console.warn("Failed to parse containerList:", jsonString);
                            }

                            setContainerPopup({
                                lat: e.lngLat.lat,
                                lng: e.lngLat.lng,
                                yard: feature.properties.yard,
                                bay: feature.properties.bay,
                                row: feature.properties.row,
                                containers,
                                location,
                            });
                        } else {
                            setContainerPopup(null);
                        }
                    }}
            />
            <GeoJsonLayer
                id="ContainersType"
                data={structuredClone(ContainersType)}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="fill"
                paint={{
                    "fill-color": containerTypeFillColor,
                    "fill-outline-color": "transparent",
                }}
            />
            <GeoJsonLayer
                id="ContainersType-border"
                data={structuredClone(ContainersType)}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="line"
                filter={['all', ['==', ['get', 'stack_valu'], 7], ['==', ['get', 'type'], 'Future Reefer']]} 
                paint={{
                    'line-color': '#df6d72',
                    'line-width': [
                        "interpolate",
                        ["linear"],
                        ["zoom"],
                        16,.25,18,.5,20,1,22,1.25,24,1.5
                    ]
                }}
            />
            <GeoJsonLayer
                id="ContainersType-cross-line"
                data={structuredClone(ContainersType)}
                minzoom={INITIAL_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                filter={['all', ['==', ['get', 'stack_valu'], 7], ['==', ['get', 'type'], 'Future Reefer']]}
                type="line"
                paint={{
                   'line-color': '#df6d72',
                    'line-width': [
                        "interpolate",
                        ["linear"],
                        ["zoom"],
                        16,.25,18,.5,20,1,22,1.25,24,1.5
                    ],
                    'line-dasharray': [2, 2]
                }}
            />
            <GeoJsonLayer
                id="ContainerYardLabel"
                data={ContainerYardCentroids}
                minzoom={INITIAL_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "ID"], ["get", "ID"], ""],
                    "text-size":[
                      "interpolate",
                      ["linear"],
                      ["zoom"],
                      14,10,
                      16,12,   // Medium size at zoom 18
                      18,14,
                      20,16,
                      21,18,
                      22, 20      // Large size at zoom 22+
                    ],
                    "text-anchor": "center",
                    "text-overlap": "always",
                    "text-ignore-placement":false,
                    
                }}
                paint={{
                    "text-color": "#000000",
                   
                }}
            />
            <GeoJsonLayer
                id="ContainerTypeLabel"
                data={structuredClone(ContainerTypeLabel)}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["get", "Label"],
                    "text-size": 10,
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "Label"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap": "always",
                    "text-ignore-placement": true
                }}
                paint={{
                    "text-color": "#000000",
                    "text-halo-color": "#ffffff",
                    "text-halo-width": 2,
                    "text-halo-blur": 0.5,
                }}
            />
            <GeoJsonLayer
                id="ContainerPositionLabel"
                data={ContainerPositionLabel}
                minzoom={MODIFIED_MIN_ZOOM}
                maxzoom={INITIAL_MAX_ZOOM}
                type="symbol"
                layout={{
                    "text-field": ["case", ["has", "Label"], ["get", "Label"], ""],
                     "text-size":[
                      "interpolate",
                      ["linear"],
                      ["zoom"],
                      18,10,
                      20,12,
                      21,14,
                      22, 16      // Large size at zoom 22+
                    ],
                    "text-anchor": "center",
                    "text-justify": "center",
                    "text-offset": [0, 0],
                    "symbol-placement": "point",
                    "symbol-avoid-edges": true,
                    "symbol-sort-key": ["get", "Label"],
                    "symbol-spacing": 1000,
                    "symbol-z-order": "source",
                    "text-overlap":"always"                  
                    
                }}
                paint={{
                    "text-color": "#71797E",
                    
                }}
                filter={[
  'all',
  ['has', 'Yard'],                   // Ensure the 'Yard' property exists
  ['!=', ['get', 'Yard'], ''],       // Exclude empty string
  ['!=', ['get', 'Yard'], null]      // Exclude null value
]}
beforeId="ContainerYardLabel-layer"
            />

             {containerPopup && (
        <RPopup
          longitude={containerPopup.lng}
          latitude={containerPopup.lat}
        >
            <button
                        className="maplibregl-popup-close-button text-lg font-bold w-5 !right-5"
                        onClick={() => {
                                    setContainerPopup(null);
                                }}
                    >
                        ×
                    </button>
          <div className="p-2">
            
            <ul className="pl-4 text-sm list-desc">
             {containerPopup.containers.map((container, index) => (
              <li key={index} className="text-gray-700">
                {container} - {containerPopup.location[index]}
              </li>
            ))}
            </ul>
          </div>
        </RPopup>
      )}
    </>
  );
}
