import GeoJsonLayer from "../GeoJsonLayer";
import dividers from "@/data/geojsonnew/divider.json";
import { INITIAL_MAX_ZOOM, INITIAL_ZOOM } from "../MapConstants";

export default function DividerLayer() {
  return (
    <GeoJsonLayer
      id="dividers"
      type="fill"
      data={dividers}
      minzoom={INITIAL_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      paint={{ "fill-color": "#1b7d05", "fill-opacity":0.1}}
      beforeId="ContainerYard-layer"
    />
  );
}
