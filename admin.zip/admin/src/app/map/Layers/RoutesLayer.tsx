// EquipmentLayer.tsx
import React, { useMemo } from "react";
import GeoJsonLayer from "../GeoJsonLayer";
import { INITIAL_ZOOM, INITIAL_MAX_ZOOM } from "../MapConstants";

function RoutesLayer({ data }) {
  const memoizedData = useMemo(() => structuredClone(data), [data]);
  if (!memoizedData || !memoizedData.features || memoizedData.features.length === 0) return null;

  return (
    <GeoJsonLayer
      id="Route-Parking-STG01"
      data={memoizedData}
      minzoom={INITIAL_ZOOM}
      maxzoom={INITIAL_MAX_ZOOM}
      type="line"
      // type="circle"
      // paint={{ "circle-color": "#1e3a8a", "circle-opacity": 0.7, "circle-radius": 3 }}
      paint={{ "line-color": "#22c55e", "line-width": 0.5 }}
      layout={{
  visibility:
    data && typeof data === "object" && Object.keys(data).length > 0
      ? "visible"
      : "none",
}}
    />
  );
}

export default React.memo(RoutesLayer);
