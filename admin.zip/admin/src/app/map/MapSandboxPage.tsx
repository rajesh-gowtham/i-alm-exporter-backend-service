import { useEffect, useState, useRef, useCallback } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { RMap, RMapContextProvider } from "maplibre-react-components";

// Import your existing constants and utilities
import {
  INITIAL_CENTER,
  INITIAL_ZOOM,
  INITIAL_BEARING,
  YardCranes,
  BASE64_PATTERN,
} from "./MapConstants";

// Import your existing components and utilities
import MapControls from "./MapControls";
import { loadSpriteImgs } from "./MapUtils";

// Import layer components
import ContainerLayer from "./Layers/ContainerLayer";
import DividerLayer from "./Layers/DividerLayer";
import GeoFencesLayer from "./Layers/GeoFencesLayer";
import HatchedAreaLayer from "./Layers/HatchedArea";
import ParkingLayer from "./Layers/ParkingLayer";
import PlatformLayer from "./Layers/PlatformLayer";
import RFIDLayer from "./Layers/RFIDLayer";
import RoadLane from "./Layers/RoadLane";
import QuayCrane from "./Layers/QuayCranes";
import YardCranesLayer from "./Layers/YardCranes";

import ITV from "@/data/geojsonnew/toptruckwithoutcontainermodified.png";

// Import images
import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";
import RFIDICON from "@/data/geojsonnew/wifi.png";
import WIFIICON from "@/data/geojsonnew/network.png";
import ServiceLaneIcon from "@/data/geojsonnew/blueboxServiceLanes.svg";
import PlatformLanePattern from "@/data/geojsonnew/platformdiagonal.svg";
// import { googleProtocol } from "maplibre-google-maps";
// maplibregl.addProtocol("google", googleProtocol);

import MovingMarker from "./Markers/MovingMarker";

// Import route data
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import { FeatureCollection, Point, Feature } from "geojson";

const combinedRoute: FeatureCollection<Point> = {
  type: "FeatureCollection",
  features: [
    ...RouteParkingToLane1.features,
    ...RouteLane1ToBlock1EW.features,
    ...RouteBlock1EWToParking.features,
  ] as Feature<Point>[],
};

// Main Equipment Tracking Component
export default function MapSandboxPage({ height = "500px" }) {
  const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);
  const mapRef = useRef<maplibregl.Map | null>(null);

  const [position, setPosition] = useState<[number, number]>(
    combinedRoute.features.length > 0
      ? (combinedRoute.features[0].geometry.coordinates as [number, number])
      : [0, 0]
  );

  useEffect(() => {
    if (combinedRoute.features.length === 0) return;

    let idx = 0;
    const interval = setInterval(() => {
      idx++;
      if (idx < combinedRoute.features.length) {
        setPosition(
          combinedRoute.features[idx].geometry.coordinates as [number, number]
        );
      } else {
        clearInterval(interval); // Stop at end, or loop if you want
        // To loop: idx = 0; setPosition(features[0].geometry.coordinates);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [combinedRoute]);

  useEffect(() => {
    console.log("--- MapSandboxPage mounted ---");
    console.log(RouteParkingToLane1);
  }, []);

  // Load map images
  useEffect(() => {
    if (!mapRef.current) return;

    const handleLoad = () => {
      const map = mapRef.current;
      if (!map) return;

      loadSpriteImgs("quay-crane", QuayCraneImg, 150, 380, map);
      loadSpriteImgs(
        "single-side-yard-crane",
        SingleSideYardCarneImg,
        40,
        205,
        map
      );
      loadSpriteImgs(
        "double-side-yard-crane",
        DoubleSideYardCraneImg,
        40,
        225,
        map
      );
      loadSpriteImgs("diagonal-stripe", BASE64_PATTERN, 8, 8, map);
      loadSpriteImgs("boxed-stripe", ServiceLaneIcon, 32, 32, map);
      loadSpriteImgs("platform-stripe", PlatformLanePattern, 6, 6, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
    };

    if (mapRef.current.loaded()) {
      handleLoad();
    } else {
      mapRef.current.on("load", handleLoad);
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.off("load", handleLoad);
      }
    };
  }, []);

  // Handle zoom changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleZoom = () => {
      setMapZoom(map.getZoom());
    };

    map.on("zoom", handleZoom);
    // return () => map.off("zoom", handleZoom);
  }, []);

  // Reset view handler
  const handleResetView = useCallback(() => {
    mapRef.current?.flyTo({
      center: INITIAL_CENTER,
      zoom: INITIAL_ZOOM,
      bearing: INITIAL_BEARING,
      duration: 1000,
    });
  }, []);

  const mapStyle: maplibregl.StyleSpecification = {
    version: 8,
    sources: {},
    layers: [],
    glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
  };

  return (
    <div className="relative w-full h-full">
      <RMapContextProvider>
        <div className="relative">
          <RMap
            ref={mapRef}
            style={{
              width: "100%",
              minHeight: height === "waterside" ? "300px" : "500px",
              height: "100%",
              backgroundColor: "transparent",
            }}
            mapStyle={mapStyle}
            initialCenter={INITIAL_CENTER}
            initialZoom={INITIAL_ZOOM}
            initialBearing={INITIAL_BEARING}
            initialPitch={0}
            dragRotate={false}
            touchZoomRotate={false}
            initialCanvasContextAttributes={{
              antialias: true,
            }}
          >
            <MapControls onResetView={handleResetView} />

            {/* Base Layers */}
            <PlatformLayer />
            <ContainerLayer />
            <RoadLane />
            <HatchedAreaLayer />
            <DividerLayer />
            <ParkingLayer />
            <RFIDLayer />
            <GeoFencesLayer />
            <QuayCrane />
            <YardCranesLayer YardCranes={YardCranes} />

            <MovingMarker nextLocation={position} duration={550} />
            {/* Equipment Markers */}
          </RMap>
        </div>
      </RMapContextProvider>

      {/* Debug info */}
      {process.env.NODE_ENV === "development" && (
        <div className="absolute p-2 text-xs text-white bg-black bg-opacity-50 rounded top-16 left-4">
          <div>
            {/* Current Position: {position}, {position[0]}{" "} */}
            Current Position: {position[0].toFixed(6)}, {position[1].toFixed(6)}
          </div>
          <div>Zoom: {mapZoom.toFixed(1)}</div>
          <div>Markers Visible: {mapZoom >= 14 ? "Yes" : "No"}</div>
        </div>
      )}
    </div>
  );
}
