// ImageMarker.tsx
import React from "react";
import { RMarker } from "maplibre-react-components";

interface ImageMarkerProps {
  equipmentId: string;
  longitude: number;
  latitude: number;
  imageSrc: string;
  altText: string;
  className?: string;
  rotation?: number;
  size: number;
  onClick?: () => void;
}

const ImageMarker: React.FC<ImageMarkerProps> = ({ equipmentId, longitude, latitude, imageSrc, altText, className, rotation, size, onClick }) => {
  const { width, height } = size;
  return (
    <div key={equipmentId}>
      <RMarker longitude={longitude} latitude={latitude} draggable={false}  rotation={rotation} onClick={onClick}>
        <img key={equipmentId} src={imageSrc} alt={altText} className={className}  style={{
          width: `${width}px`,
          height: `${height}px`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          pointerEvents: "none",
        }} />
      </RMarker>
    </div>
  );
};

export default ImageMarker;