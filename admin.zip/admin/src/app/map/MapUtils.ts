import * as turf from '@turf/turf';
 // Adjust the import path as necessary
import {EquipmentState, RouteSegmentType } from "@/lib/models";
// Simulated mapping of RouteSegmentType to imported GeoJSONs
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";
/* import ITV from "@/data/geojsonnew/flat-bed-truck Left.png";
import ITV2 from "@/data/geojsonnew/flat-bed-truck Right.png";
import IVTL2R from "@/data/geojsonnew/itvL2R.png";
import ITVR2L from "@/data/geojsonnew/itvR2L.png";
import SITV from "@/data/geojsonnew/delivery-truck Active1.png";
import SITV2 from "@/data/geojsonnew/delivery-truck_Active.png";
*/
import ITV from "@/data/geojsonnew/toptruckwithoutcontainermodified.png";
import IVTL2R from "@/data/geojsonnew/toptruckwithcontainermodified.png";
import SITV from "@/data/geojsonnew/toptruckwithcontainermodifiedactive.png";

import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";

interface Properties {
    [key: string]: any;
}

interface Feature {
    type: "Feature";
    geometry: any;
    properties: Properties;
}

interface FeatureCollection {
    type: string;
    features: Feature[];
}

export function getCentroidsFeatureCollection(featureCollection: FeatureCollection): FeatureCollection {
    return turf.featureCollection(
        featureCollection.features.map(feature =>
            turf.centroid(feature, { properties: feature.properties })
        )
    );
}


interface Crane {
  id: string | number;
  longitude: number;
  latitude: number;
  yard: string;
}

interface SnappedFeatureProperties {
  id: string | number;
  originalLongitude: number;
  originalLatitude: number;
  yardNo: string;
}

export function snapPointsToLine(
  points: Crane[],
  line: turf.Feature<turf.LineString> | turf.LineString,
  options: turf.NearestPointOnLineOptions = { units: 'meters' }
): turf.Feature<turf.Point, SnappedFeatureProperties>[] {
  return points.map((point) => {
    const targetPoint = turf.point([point.longitude, point.latitude]);
    const snapped = turf.nearestPointOnLine(line, targetPoint, options);

    return {
      type: 'Feature',
      geometry: snapped.geometry,
      properties: {
        id: point.id,
        originalLongitude: point.longitude,
        originalLatitude: point.latitude,
        yardNo: point.yard,
      },
    };
  });
}



export function loadSpriteImgs(
  name: string,
  imageSrc: string,
  imgWidth: number,
  imgHeight: number,
  map: maplibregl.Map | null
): void {
  if (!map || map.hasImage(name)) return;

  const image = new Image(imgWidth, imgHeight);
  image.onload = (): void => {
    map.addImage(name, image, { pixelRatio: 1, sdf: false });
  };
  image.onerror = (err) => {
    console.error(`Failed to load sprite image: ${imageSrc}`, err);
  };
  image.src = imageSrc;
}

export const routeSegmentGeoJsonMap: Record<RouteSegmentType, any> = {
  [RouteSegmentType.ParkingToSTS01]: RouteParkingToLane1,
  [RouteSegmentType.ParkingToSTS02]: RouteParkingToLane2,
  [RouteSegmentType.STS01ToYard]: RouteLane1ToBlock1EW,
  [RouteSegmentType.STS02ToYard]: RouteLate2ToBlock1EW,
  [RouteSegmentType.YardToParkingLane1]: RouteBlock1EWToParking,
  [RouteSegmentType.YardToParkingLane2]: RouteBlock1EWToParking2,
  [RouteSegmentType.YardToSTS01]: Route1EBlockToLane1,
  [RouteSegmentType.YardToSTS02]: Route1EBlockToLane2
};

export function convertToGeoJSON(equipmentList: EquipmentState[]) {
 
  return {
    type: "FeatureCollection",
    features: equipmentList.map((item) => {
      let matchedLayer = item.parameters?.LAYER ?? "L to R";
      // item.routeSegment = RouteSegmentType.ParkingToLane1;
      if (item.routeSegment && routeSegmentGeoJsonMap[item.routeSegment]) {
        const geojson = routeSegmentGeoJsonMap[item.routeSegment];
        // console.log(item.routeSegment,item.routeSegment);
        // console.log('routesegment',item);
        const point = turf.point([item.longitude, item.latitude]);
        // const point = turf.point([76.994199763873112, 8.372674922999661]);
        for (const feature of geojson.features) {
          const featureGeom = turf.getGeom(feature);
          const isMatch = turf.booleanEqual(featureGeom, point) || turf.distance(point, featureGeom, { units: "meters" }) < 1;
          
          if (isMatch && feature.properties?.Direction) {
            matchedLayer = feature.properties.Direction;
            break;
          }
        }
      }
// console.log("matchedLayer", matchedLayer);
      return {
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: [item.longitude, item.latitude],
        },
        properties: {
          equipmentId: item.equipmentId,
          equipmentName: item.equipmentName,
          equipmentType: item.equipmentType,
          status: item.status,
          message: item.message,
          gpsTime: item.gpsTime,
          altitude: item.altitude,
          heading: item.heading,
          parameters: item.parameters,
          LAYER: matchedLayer,
        },
      };
    }),
  };
}

export const EmptyRouteSegments = new Set<RouteSegmentType>([
  RouteSegmentType.ParkingToSTS01,
  RouteSegmentType.ParkingToSTS02,
  RouteSegmentType.YardToParkingLane1,
  RouteSegmentType.YardToParkingLane2,
  RouteSegmentType.YardToSTS01,
  RouteSegmentType.YardToSTS02
]);

export const ActiveRouteDirectionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: SITV, rotation: 90 },
  "U to D": { image: SITV, rotation: -90 },
  "L to R": { image: SITV, rotation: 180 },
  "R to L": { image: SITV, rotation: 0 },
};

export const EmptyRouteDirectionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: ITV, rotation: 90 },
  "U to D": { image: ITV, rotation: -90 },
  "L to R": { image: ITV, rotation: 180 },
  "R to L": { image: ITV, rotation: 0 },
};

export const directionConfigMap: Record<string, { image: string; rotation: number }> = {
  "D to U": { image: IVTL2R, rotation: 90 },
  "U to D": { image: IVTL2R, rotation: -90 },
  "L to R": { image: IVTL2R, rotation: 180 },
  "R to L": { image: IVTL2R, rotation: 0 },
};

export function getEquipmentMarkerImageByDirection(equipment: {
  latitude: number;
  longitude: number;
  routeSegment: RouteSegmentType;
  equipmentName: string;
  jobStatus: string;
}, selectedEquipmentId: string): { image: string; rotation: number } {
  const routeGeoJson = routeSegmentGeoJsonMap[equipment.routeSegment];
  if (!routeGeoJson || !equipment.latitude || !equipment.longitude) {
    return { image: ITV, rotation: 0 };
  }

  const currentPoint = turf.point([equipment.longitude, equipment.latitude]);

  let nearestIdx = 0;
  let minDistance = Infinity;

  routeGeoJson.features.forEach((feature, index) => {
    if (feature.geometry.type !== "Point") return;

    const point = turf.point(feature.geometry.coordinates);
    const distance = turf.distance(currentPoint, point, { units: "meters" });

    if (distance < minDistance) {
      minDistance = distance;
      nearestIdx = index;
    }
  });

  const nearestFeature = routeGeoJson.features[nearestIdx];
  const direction = nearestFeature?.properties?.direction;
  
  // console.log(selectedEquipmentId, equipment.equipmentName,  selectedEquipmentId === equipment.equipmentId);
  const configMap = equipment.jobStatus =='Completed' || equipment.jobStatus =='Arrive to Origin'
    ? EmptyRouteDirectionConfigMap  
    : selectedEquipmentId === equipment.equipmentName && !EmptyRouteSegments.has(equipment.routeSegment)
      ? ActiveRouteDirectionConfigMap
      : EmptyRouteSegments.has(equipment.routeSegment)
        ? EmptyRouteDirectionConfigMap 
        : directionConfigMap;

  return  configMap[direction] ?? { image: ITV, rotation: 0 };
}

const CRANE_CONFIGURATIONS = {
    DOUBLE_SIDED_YARDS: ['1D', '2D', '3D', '1E', '2E', '3E'],
    ROTATED_YARDS: {
        '1A': 179.5, '1C': 179.5, '2A': 179.5,
        '2C': 179.5, '3A': 179.5, '3C': 179.5
    },
    OFFSET_YARDS: {
        GROUP1: ['1A', '1C', '2A', '2C', '3A', '3C'],
        GROUP2: ['1B', '2B', '3B']
    }
};

const ZOOM_SCALE = [
    { zoom: 16, size: 0.20 },
    { zoom: 17, size: 0.33 },
    { zoom: 18, size: 0.75 },
    { zoom: 19, size: 1.55 },
    { zoom: 20, size: 3.03 },
    { zoom: 21, size: 6.3 },
    { zoom: 22, size: 12.5 }
];
export function getYardCraneMarkerImageByDirection(equipment: {
  id: string;
  yard: string;
  longitude: number;
  latitude: number;
}): { image: string; rotation: number } {
  const { yard } = equipment;

  // Match icon image based on yard
  const image = CRANE_CONFIGURATIONS.DOUBLE_SIDED_YARDS.includes(yard)
    ? DoubleSideYardCraneImg
    : SingleSideYardCarneImg;

  // Match rotation based on yard
  const rotation = yard in CRANE_CONFIGURATIONS.ROTATED_YARDS
    ? CRANE_CONFIGURATIONS.ROTATED_YARDS[yard]
    : 0;

  return { image, rotation };
}


interface GeoJSONFeatureCollection {
  type: "FeatureCollection";
  features: GeoJSON.Feature[];
}

function sortGeoJsonByProperty(
  geojson: GeoJSONFeatureCollection,
  propertyName: string,
  ascending: boolean = true
): GeoJSONFeatureCollection {
  const sortedFeatures = [...geojson.features].sort((a, b) => {
    const valA = a.properties?.[propertyName];
    const valB = b.properties?.[propertyName];

    // Handle undefined/null
    if (valA == null) return 1;
    if (valB == null) return -1;

    if (valA < valB) return ascending ? -1 : 1;
    if (valA > valB) return ascending ? 1 : -1;
    return 0;
  });

  return {
    ...geojson,
    features: sortedFeatures,
  };
}



export function sortGeoJsonByTime(geojson: GeoJSON.FeatureCollection | undefined): GeoJSON.FeatureCollection {
  if (!geojson || !geojson.features || !Array.isArray(geojson.features)) {
    console.warn("Invalid GeoJSON FeatureCollection passed to sortGeoJsonByTime");
    return { type: "FeatureCollection", features: [] };
  }

  const sortedFeatures = [...geojson.features].sort((a, b) => {
    const timeA = a.properties?.time_sec ?? 0;
    const timeB = b.properties?.time_sec ?? 0;
    return timeA - timeB;
  });

  return {
    ...geojson,
    features: sortedFeatures,
  };
}


export function createLineGeoJsonByDirectionChange(geojson: GeoJSON.FeatureCollection): GeoJSON.FeatureCollection {
  if (!geojson || !geojson.features || geojson.features.length === 0) {
    return turf.featureCollection([]);
  }

  const lineFeatures: GeoJSON.Feature[] = [];
  let currentGroup: any[] = [];
  let currentDirection = geojson.features[0].properties?.direction;

  for (let i = 0; i < geojson.features.length; i++) {
    const feature = geojson.features[i];
    const direction = feature.properties?.direction;

    if (direction !== currentDirection && currentGroup.length > 1) {
      // Finalize current group as a LineString
      lineFeatures.push(
        turf.lineString(currentGroup, { direction: currentDirection })
      );
      
      // Start new group with last coordinate of previous group
      currentGroup = [currentGroup[currentGroup.length - 1]];
    }

    if (feature.geometry.type === 'Point') {
      currentGroup.push((feature.geometry as GeoJSON.Point).coordinates);
    }
    currentDirection = direction;
  }

  // Push the final group
  if (currentGroup.length > 1) {
    lineFeatures.push(
      turf.lineString(currentGroup, { direction: currentDirection })
    );
  }

  return turf.featureCollection(lineFeatures);
}