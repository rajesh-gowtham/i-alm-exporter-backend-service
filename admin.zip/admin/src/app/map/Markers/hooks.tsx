import { useEffect, useRef, useState } from "react";

// Robert Penner’s easeInOutQuad
export function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
}

function easeLinear(t: number): number {
  return t;
}

export function useUltraSmooth(
  incoming: [number, number],
  chaseDur = 500
): [number, number] {
  // 1) state for the marker’s current on-screen position
  const [pos, setPos] = useState<[number, number]>(incoming);

  // 2) REFS for our time-anchored interpolation
  const lastRef = useRef<{ pos: [number, number]; t: number }>({
    pos,
    t: performance.now(),
  });
  const nextRef = useRef<{ pos: [number, number]; t: number }>({
    pos: incoming,
    t: performance.now(),
  });

  // ←— **HERE** is where you apply the low-pass to smooth the raw incoming fixes
  const smoothRef = useRef<[number, number]>(incoming);
  useEffect(() => {
    const α = 0.1; // 0.05–0.2 is a good sweet-spot
    smoothRef.current = [
      smoothRef.current[0] * (1 - α) + incoming[0] * α,
      smoothRef.current[1] * (1 - α) + incoming[1] * α,
    ];
    // now schedule our chase to target *that* smoothed point
    const now = performance.now();
    lastRef.current = { pos, t: now };
    nextRef.current = { pos: smoothRef.current, t: now + chaseDur };
  }, [incoming, chaseDur, pos]);

  // 3) the single RAF loop that actually lerps every frame
  useEffect(() => {
    let frame: number;
    function step() {
      const now = performance.now();
      const { pos: p0, t: t0 } = lastRef.current;
      const { pos: p1, t: t1 } = nextRef.current;
      const raw = (now - t0) / (t1 - t0);
      const t = Math.max(0, Math.min(1, raw));
      const e = easeLinear(t);

      const lng = p0[0] + (p1[0] - p0[0]) * e;
      const lat = p0[1] + (p1[1] - p0[1]) * e;
      setPos([lng, lat]);

      frame = requestAnimationFrame(step);
    }
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, []);

  return pos;
}

// Default easing function
const defaultEasing = (t: number): number => {
  return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
};

interface UseSmoothRotationOptions {
  duration?: number; // Animation duration in milliseconds
  threshold?: number; // Skip animation if rotation change is below this threshold
  easing?: (t: number) => number; // Custom easing function
}

export const useSmoothRotation = (
  targetRotation: number,
  {
    duration = 500,
    threshold = 0.5,
    easing = defaultEasing,
  }: UseSmoothRotationOptions = {}
): number => {
  const [currentRotation, setCurrentRotation] = useState(targetRotation);
  const animationRef = useRef<number>();
  const startRotationRef = useRef<number>(targetRotation);
  const startTimeRef = useRef<number>(0);

  // Normalize 0–360
  const normalize = (a: number) => ((a % 360) + 360) % 360;

  // Shortest delta
  const deltaBetween = (from: number, to: number) => {
    let d = normalize(to) - normalize(from);
    if (d > 180) d -= 360;
    if (d < -180) d += 360;
    return d;
  };

  useEffect(() => {
    // tear down any previous
    if (animationRef.current) cancelAnimationFrame(animationRef.current);

    const from = currentRotation;
    const delta = deltaBetween(from, targetRotation);

    if (Math.abs(delta) < threshold) {
      setCurrentRotation(targetRotation);
      return;
    }

    startRotationRef.current = from;
    startTimeRef.current = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTimeRef.current;
      const t = Math.min(elapsed / duration, 1);
      const eased = easing(t);

      const next = startRotationRef.current + delta * eased;
      setCurrentRotation(normalize(next));

      if (t < 1) {
        animationRef.current = requestAnimationFrame(step);
      } else {
        // snap exactly
        setCurrentRotation(normalize(targetRotation));
      }
    };

    animationRef.current = requestAnimationFrame(step);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [targetRotation, duration, threshold, easing]);

  // clean up on unmount
  useEffect(
    () => () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    },
    []
  );

  return currentRotation;
};

// function easeInOutCubic(t: number, b: number, c: number, d: number) {
//   t /= d / 2;
//   if (t < 1) return (c / 2) * t * t * t + b;
//   t -= 2;
//   return (c / 2) * (t * t * t + 2) + b;
// }

// export function useSmoothRotationNew(
//   targetRotation: number,
//   speedDegPerSecond = 90,
//   interpolationMethod = "bezier"
// ) {
//   const [currentRotation, setCurrentRotation] = useState(targetRotation);
//   const animationFrameId = useRef<number | null>(null);
//   const startTimeRef = useRef<number | null>(null);
//   const startRotationRef = useRef<number>(targetRotation);
//   const animationDurationRef = useRef<number>(500); // default duration

//   useEffect(() => {
//     if (animationFrameId.current) {
//       cancelAnimationFrame(animationFrameId.current);
//     }

//     // 1. Initialize starting point
//     startRotationRef.current = currentRotation;

//     // 2. Calculate shortest angle difference
//     let diff = targetRotation - startRotationRef.current;
//     if (diff > 180) diff -= 360;
//     if (diff < -180) diff += 360;

//     // 3. Duration = angle difference / speed
//     const absDiff = Math.abs(diff);
//     animationDurationRef.current = Math.max(
//       100,
//       (absDiff / speedDegPerSecond) * 1000
//     );
//     startTimeRef.current = null;

//     const animate = (timestamp: number) => {
//       if (!startTimeRef.current) {
//         startTimeRef.current = timestamp;
//       }
//       const elapsed = timestamp - startTimeRef.current;
//       const progress = Math.min(elapsed / animationDurationRef.current, 1);

//       const easedProgress =
//         interpolationMethod === "bezier"
//           ? easeInOutCubic(elapsed, 0, 1, animationDurationRef.current)
//           : progress;

//       const newRotation = startRotationRef.current + diff * easedProgress;
//       setCurrentRotation(newRotation);

//       if (progress < 1) {
//         animationFrameId.current = requestAnimationFrame(animate);
//       } else {
//         setCurrentRotation(targetRotation); // Snap to exact target
//         animationFrameId.current = null;
//       }
//     };

//     animationFrameId.current = requestAnimationFrame(animate);

//     return () => {
//       if (animationFrameId.current) {
//         cancelAnimationFrame(animationFrameId.current);
//       }
//     };
//   }, [targetRotation, speedDegPerSecond, interpolationMethod]);

//   return currentRotation;
// }
