import { useMemo } from "react";
import { EquipmentState } from "@/lib/models";
import { convertToGeoJSON } from "./MapUtils";

export function useEquipmentStatesGeoJSON(data: EquipmentState[] | undefined) {
  const ITVGEOJSON = useMemo(() => {
    if (!data) return null;
    return convertToGeoJSON(data);
  }, [data]);

  return {
    ITVGEOJSON,
  };
}