import React from "react";

interface BaseMapToggleProps {
  showBaseMap: boolean;
  onToggle: () => void;
}

const BaseMapToggle: React.FC<BaseMapToggleProps> = ({ showBaseMap, onToggle }) => {
  return (
    <div className="absolute z-10 px-4 py-2 bg-white rounded-md shadow-md top-2 left-2 bg-opacity-80">
      <label className="flex items-center gap-2 text-sm text-black">
        <input type="checkbox" checked={showBaseMap} onChange={onToggle} />
        {showBaseMap ? "Hide Base Map" : "Show Base Map"}
      </label>
    </div>
  );
};

export default BaseMapToggle;