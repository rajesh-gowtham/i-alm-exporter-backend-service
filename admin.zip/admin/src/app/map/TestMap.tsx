import { useEffect, useState, useRef, useMemo, useCallback } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  RMap,
  RMapContextProvider,
  RSource,
  RLayer,
  RMarker,
} from "maplibre-react-components";
import useSWR from "swr";

// Import your existing constants and utilities
import {
  INITIAL_CENTER,
  INITIAL_ZOOM,
  INITIAL_BEARING,
  YardCranes,
  BASE64_PATTERN,
} from "./MapConstants";

// Import route data
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";

// Import your existing components and utilities
import BaseMapToggle from "./BaseMapToggle";
import MapControls from "./MapControls";
import {
  createLineGeoJsonByDirectionChange,
  getEquipmentMarkerImageByDirection,
  loadSpriteImgs,
  sortGeoJsonByTime,
} from "./MapUtils";
import { RouteSegmentType } from "@/lib/models";
import { fetchEquipmentStates } from "@/lib/services/map-services";

// Import layer components
import ContainerLayer from "./Layers/ContainerLayer";
import DividerLayer from "./Layers/DividerLayer";
import GeoFencesLayer from "./Layers/GeoFencesLayer";
import HatchedAreaLayer from "./Layers/HatchedArea";
import ParkingLayer from "./Layers/ParkingLayer";
import PlatformLayer from "./Layers/PlatformLayer";
import RFIDLayer from "./Layers/RFIDLayer";
import RoadLane from "./Layers/RoadLane";
import QuayCrane from "./Layers/QuayCranes";
import YardCranesLayer from "./Layers/YardCranes";

// Import images
import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";
import RFIDICON from "@/data/geojsonnew/wifi.png";
import WIFIICON from "@/data/geojsonnew/network.png";
import ServiceLaneIcon from "@/data/geojsonnew/blueboxServiceLanes.svg";
import PlatformLanePattern from "@/data/geojsonnew/platformdiagonal.svg";
import { useTweenedPosition, useSmoothLngLat } from "./useTweenedPosition";
import { Marker, LngLatLike } from "maplibre-gl";
import { googleProtocol, createGoogleStyle } from "maplibre-google-maps";
maplibregl.addProtocol("google", googleProtocol);

// Equipment marker component with proper route following
// import { Marker } from "maplibre-gl";
// import { useEffect, useRef } from "react";
// import { useTweenedPosition } from "./useTweenedPosition";
// import * as turf from "@turf/turf"; // only for bearing()

interface Props {
  map: maplibregl.Map;
  id: string;
  /** latest backend fix */
  pos: [number, number];
  image: string;
  size: { width: number; height: number };
  duration?: number; // ms between fixes
}

interface MarkerProps {
  map: maplibregl.Map;
  id: string;
  fix: [number, number]; // latest backend coord
  icon: string;
  size: { width: number; height: number };
  tweenMs?: number; // default 500
}

function EquipmentMarker({
  map,
  id,
  fix,
  icon,
  size,
  rotation = 0,
  tweenMs = 500,
}: Props) {
  const markerRef = useRef<Marker | null>(null);
  const tweenRef = useSmoothLngLat(fix, tweenMs);

  /* drive the marker every animation frame */
  useEffect(() => {
    const move = () => {
      markerRef.current?.setLngLat(tweenRef.current);
      requestAnimationFrame(move);
    };
    const id = requestAnimationFrame(move);
    return () => cancelAnimationFrame(id);
  }, []);

  /* render once — the ref gives us Marker object for imperative moves */
  return (
    <RMarker
      longitude={fix[0]}
      latitude={fix[1]}
      rotation={rotation}
      draggable={false}
      ref={markerRef as any} // MapLibre Marker instance
    >
      <div
        style={{
          width: size.width,
          height: size.height,
          background: `url(${icon}) no-repeat center/contain`,
          willChange: "transform",
          pointerEvents: "none",
        }}
      />
    </RMarker>
  );
}

// Main Equipment Tracking Component
export default function TestMapComponent({ height = "500px" }) {
  const [showBaseMap, setShowBaseMap] = useState(false);
  const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);
  const [equipmentPositions, setEquipmentPositions] = useState(new Map());
  const mapRef = useRef<maplibregl.Map | null>(null);

  // Fetch equipment data every 500ms
  const { data: liveEquipments } = useSWR(
    "/equipment/states",
    fetchEquipmentStates,
    {
      refreshInterval: 500,
      dedupingInterval: 0, // turn off dedupe throttling
      revalidateOnFocus: false, // disable focus-triggered revalidations
      refreshWhenHidden: false, // pause polling when tab is hidden
    }
  );

  // Get route coordinates for equipment
  const getEquipmentRoute = useCallback((equipment) => {
    let FollowRoute = null;

    switch (equipment.routeSegment) {
      case RouteSegmentType.ParkingToSTS01:
        FollowRoute = RouteParkingToLane1;
        break;
      case RouteSegmentType.ParkingToSTS02:
        FollowRoute = RouteParkingToLane2;
        break;
      case RouteSegmentType.STS01ToYard:
        FollowRoute = RouteLane1ToBlock1EW;
        break;
      case RouteSegmentType.STS02ToYard:
        FollowRoute = RouteLate2ToBlock1EW;
        break;
      case RouteSegmentType.YardToParkingLane1:
        FollowRoute = RouteBlock1EWToParking;
        break;
      case RouteSegmentType.YardToParkingLane2:
        FollowRoute = RouteBlock1EWToParking2;
        break;
      case RouteSegmentType.YardToSTS01:
        FollowRoute = Route1EBlockToLane1;
        break;
      case RouteSegmentType.YardToSTS02:
        FollowRoute = Route1EBlockToLane2;
        break;
      default:
        return [];
    }

    if (!FollowRoute?.features?.length) return [];

    try {
      const sorted = sortGeoJsonByTime(FollowRoute);
      const line = createLineGeoJsonByDirectionChange(sorted);
      const coords: number[][] = [];
      line.features.forEach((f) => {
        if (f.geometry.type === "LineString")
          coords.push(
            ...f.geometry.coordinates.filter(
              (c) => Array.isArray(c) && !isNaN(c[0]) && !isNaN(c[1])
            )
          );
      });
      return coords;
    } catch (err) {
      console.error("route error for", equipment.equipmentId, err);
      return [];
    }
  }, []);

  /* update positions map every push --------------------------------- */
  useEffect(() => {
    if (!liveEquipments?.length) return;
    const m = new Map();
    liveEquipments.forEach((eq) => {
      m.set(eq.equipmentId, {
        current: [eq.longitude, eq.latitude] as [number, number],
        route: getEquipmentRoute(eq),
        equipment: eq,
      });
    });
    setEquipmentPositions(m);
  }, [liveEquipments, getEquipmentRoute]);

  /* marker auto-scaling based on zoom ------------------------------- */
  const getMarkerSize = useCallback((zoom: number) => {
    const base = 24;
    const s = zoom <= 17 ? 1 + (zoom - 16) * 0.3 : 1.2 + (zoom - 17) * 0.6;
    const scale = Math.min(Math.max(s, 0.5), 4);
    return { width: base * scale, height: base * scale };
  }, []);

  // Base map style
  const baseMapStyle = useMemo(() => {
    return showBaseMap
      ? {
          ...createGoogleStyle(
            "google",
            "satellite",
            import.meta.env.VITE_GOOGLE_MAPS_KEY
          ),
          glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
        }
      : {
          version: 8,
          sources: {},
          layers: [],
          glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
        };
  }, [showBaseMap]);

  // Load map images
  useEffect(() => {
    if (!mapRef.current) return;

    const handleLoad = () => {
      const map = mapRef.current;
      if (!map) return;

      loadSpriteImgs("quay-crane", QuayCraneImg, 150, 380, map);
      loadSpriteImgs(
        "single-side-yard-crane",
        SingleSideYardCarneImg,
        40,
        205,
        map
      );
      loadSpriteImgs(
        "double-side-yard-crane",
        DoubleSideYardCraneImg,
        40,
        225,
        map
      );
      loadSpriteImgs("diagonal-stripe", BASE64_PATTERN, 8, 8, map);
      loadSpriteImgs("boxed-stripe", ServiceLaneIcon, 32, 32, map);
      loadSpriteImgs("platform-stripe", PlatformLanePattern, 6, 6, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
    };

    if (mapRef.current.loaded()) {
      handleLoad();
    } else {
      mapRef.current.on("load", handleLoad);
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.off("load", handleLoad);
      }
    };
  }, []);

  // Handle zoom changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleZoom = () => {
      setMapZoom(map.getZoom());
    };

    map.on("zoom", handleZoom);
    return () => map.off("zoom", handleZoom);
  }, []);

  // Reset view handler
  const handleResetView = useCallback(() => {
    mapRef.current?.flyTo({
      center: INITIAL_CENTER,
      zoom: INITIAL_ZOOM,
      bearing: INITIAL_BEARING,
      duration: 1000,
    });
  }, []);

  return (
    <div className="relative w-full h-full">
      <RMapContextProvider>
        <div className="relative">
          <BaseMapToggle
            showBaseMap={showBaseMap}
            onToggle={() => setShowBaseMap(!showBaseMap)}
          />

          <RMap
            ref={mapRef}
            style={{
              width: "100%",
              minHeight: height === "waterside" ? "300px" : "500px",
              height: "100%",
              backgroundColor: "transparent",
            }}
            mapStyle={baseMapStyle}
            initialCenter={INITIAL_CENTER}
            initialZoom={INITIAL_ZOOM}
            initialBearing={INITIAL_BEARING}
            initialPitch={0}
            dragRotate={false}
            touchZoomRotate={false}
            initialCanvasContextAttributes={{
              antialias: true,
            }}
          >
            {/* Base Layers */}
            <PlatformLayer />
            <ContainerLayer />
            <RoadLane />
            <HatchedAreaLayer />
            <DividerLayer />
            <ParkingLayer />
            <RFIDLayer />
            <GeoFencesLayer />
            <QuayCrane />
            <YardCranesLayer YardCranes={YardCranes} />

            {/* Equipment Markers - Only show at zoom 14+ for better visibility */}
            {/* {mapZoom >= 14 && mapRef.current && Array.from(equipmentPositions.entries()).map(([equipmentId, positionData]) => {
              const { current, route, equipment } = positionData;
              const size = getMarkerSize(mapZoom);
              const { image, rotation } = getEquipmentMarkerImageByDirection(equipment, equipmentId);

              // Only render if we have a valid route
              if (!route || route.length === 0) return null;

              return (
                <EquipmentMarker
                  key={`${equipmentId}-${equipment.routeSegment}-route`}
                  map={mapRef.current}
                  equipmentId={equipmentId}
                  currentPosition={current}
                  route={route}
                  image={image}
                  size={size}
                  rotation={rotation}
                  smoothingFactor={0.3}
                />
              );
            })} */}

            {/* dynamic equipment */}
            {mapZoom >= 14 &&
              Array.from(equipmentPositions.entries()).map(
                ([id, { current, route, equipment }]) => {
                  const { image, rotation } =
                    getEquipmentMarkerImageByDirection(equipment, id);
                  return (
                    <EquipmentMarker
                      key={id}
                      map={mapRef.current!}
                      id={id}
                      fix={current}
                      icon={image}
                      rotation={rotation}
                      size={getMarkerSize(mapZoom)}
                      tweenMs={500} // same as refreshInterval
                    />
                  );
                }
              )}

            <MapControls onResetView={handleResetView} />
          </RMap>
        </div>
      </RMapContextProvider>

      {/* Debug info */}
      {process.env.NODE_ENV === "development" && (
        <div className="absolute p-2 text-xs text-white bg-black bg-opacity-50 rounded top-16 left-4">
          <div>Zoom: {mapZoom.toFixed(1)}</div>
          <div>Equipment Count: {equipmentPositions.size}</div>
          <div>Markers Visible: {mapZoom >= 14 ? "Yes" : "No"}</div>
        </div>
      )}
    </div>
  );
}
