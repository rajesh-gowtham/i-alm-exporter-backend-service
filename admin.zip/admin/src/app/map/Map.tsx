import { useEffect, useState, useRef, useMemo } from "react";
import useSWR from "swr";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { RMap, RMapContextProvider } from "maplibre-react-components";
import { googleProtocol, createGoogleStyle } from "maplibre-google-maps";
import * as turf from "@turf/turf";

import {
  INITIAL_CENTER,
  INITIAL_ZOOM,
  INITIAL_BEARING,
  BASE64_PATTERN,
  VITE_GOOGLE_MAPS_KEY,
  YardCranes,
} from "./MapConstants";

import QuayCraneImg from "@/data/geojsonnew/quay crane red yellow.png";
import SingleSideYardCarneImg from "@/data/geojsonnew/SingleSideYardCrane_red.png";
import DoubleSideYardCraneImg from "@/data/geojsonnew/DoubleSideYardCrane-red.png";
import RFIDICON from "@/data/geojsonnew/wifi.png";
import WIFIICON from "@/data/geojsonnew/network.png";
import ServiceLaneIcon from "@/data/geojsonnew/blueboxServiceLanes.svg";
import PlatformLanePattern from "@/data/geojsonnew/platformdiagonal.svg";

// Routes
import RouteParkingToLane1 from "@/data/geojsonnew/Routes/ParkingtoSTS01.json";
import RouteParkingToLane2 from "@/data/geojsonnew/Routes/ParkingtoSTS02.json";
import RouteLane1ToBlock1EW from "@/data/geojsonnew/Routes/STS01to1E35A.json";
import RouteLate2ToBlock1EW from "@/data/geojsonnew/Routes/STS02to1E35A.json";
import RouteBlock1EWToParking from "@/data/geojsonnew/Routes/1E35AtoParking.json";
import RouteBlock1EWToParking2 from "@/data/geojsonnew/Routes/1E35AParking2.json";
import Route1EBlockToLane1 from "@/data/geojsonnew/Routes/1E35AtoSTS01.json";
import Route1EBlockToLane2 from "@/data/geojsonnew/Routes/1E35AtoSTS02.json";

// Components
import BaseMapToggle from "./BaseMapToggle";
import MapControls from "./MapControls";
import ContainerLayer from "./Layers/ContainerLayer";
import RoadLane from "./Layers/RoadLane";
import YardCranesLayer from "./Layers/YardCranes";
import QuayCrane from "./Layers/QuayCranes";
import HatchedAreaLayer from "./Layers/HatchedArea";
import DividerLayer from "./Layers/DividerLayer";
import ParkingLayer from "./Layers/ParkingLayer";
import RFIDLayer from "./Layers/RFIDLayer";
import PlatformLayer from "./Layers/PlatformLayer";
import GeoFencesLayer from "./Layers/GeoFencesLayer";

// Services & Hooks
import {
  fetchEquipmentStates,
  fetchEquipmentStateByName,
} from "@/lib/services/map-services";
import { RouteSegmentType } from "@/lib/models";
import { loadSpriteImgs, getEquipmentMarkerImageByDirection, createLineGeoJsonByDirectionChange, sortGeoJsonByTime } from "./MapUtils";
import RoutesLayer from "./Layers/RoutesLayer";
import EnhancedAnimatedMarker from "./EnhancedRouteFollowingMarker";
import { useEquipmentStatesGeoJSON } from "./useEquipmentGeoJSON";
import { BsTruckFlatbed } from "react-icons/bs";

maplibregl.addProtocol("google", googleProtocol);

export function updateCraneCoordinatesById(
  id: string,
  newLatitude: number,
  newLongitude: number
) {
  const index = YardCranes.findIndex((crane) => crane.id === id);
  if (index !== -1) {
    YardCranes[index] = {
      ...YardCranes[index],
      latitude: newLatitude,
      longitude: newLongitude,
    };
    return true; // Successfully updated
  }
  return false; // ID not found
}

export default function MapComponent({ height }) {
  const [showBaseMap, setShowBaseMap] = useState(false);
  const [selectedEquipmentId, setSelectedEquipmentId] = useState<string | null>(
    null
  );
  const [followEquipment, setFollowEquipment] = useState(false);
  const [RouteingJson, setRouteingJson] = useState({});
  const [containerDispatchPoint, SetContainerDispatchPoint] = useState("");
  const [mapZoom, setMapZoom] = useState(INITIAL_ZOOM);

  const mapRef = useRef<any>(null);

  const { data: equipmentData } = useSWR(
    "/equipment/states",
    fetchEquipmentStates,
    {
      refreshInterval: 500,
      dedupingInterval: 0, // turn off dedupe throttling
      revalidateOnFocus: false, // disable focus-triggered revalidations
      refreshWhenHidden: false, // pause polling when tab is hidden
    }
  );

  useEffect(() => {
    if (!equipmentData || !Array.isArray(equipmentData)) return;

    const arrivedEquipment = equipmentData.find(
      (equipment) => equipment.jobStatus === "Arrived at Destination"
    );

    if (arrivedEquipment) {
      console.log('arrivedEquipment', arrivedEquipment.latitude, arrivedEquipment.longitude);
      updateCraneCoordinatesById(
        "CRMG-E01",
        arrivedEquipment.latitude,
        arrivedEquipment.longitude
      );
    }
  }, [equipmentData]);

  const { ITVGEOJSON: EquipmentLists } = useEquipmentStatesGeoJSON(equipmentData);

  const { data: equipmentState } = useSWR(
    selectedEquipmentId ? `${selectedEquipmentId}` : null,
    fetchEquipmentStateByName,
    {
      refreshInterval: 500,
      dedupingInterval: 0, // turn off dedupe throttling
      revalidateOnFocus: false, //disable focus-triggered revalidations
      refreshWhenHidden: false, // pause polling when tab is hidden
    }
  );

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const handleZoom = () => {
      setMapZoom(map.getZoom());
    };

    map.on("zoom", handleZoom);

    return () => {
      map.off("zoom", handleZoom);
    };
  }, []);

  const getMarkerSize = (zoom: number) => {
    const baseWidth = 11; // width at zoom 16
    const baseHeight = 4; // maintains original image aspect ratio
    const scale =
      zoom <= 17
        ? 1 + (zoom - 16) * 0.3 // zoom 16 → 1.0, zoom 17 → 1.3
        : 1.3 + (zoom - 17) * 0.6; // zoom 18 → 1.9, zoom 19 → 2.5, zoom 20 → 3.1
    const clampedScale = Math.min(scale, 3); // prevent excessive size at high zoom
    return {
      width: baseWidth * clampedScale,
      height: baseHeight * clampedScale,
    }; // scales between 12px and 48px
  };
  useEffect(() => {
    if (!mapRef.current) return;
    mapRef.current.on("load", () => {
      const map = mapRef.current;
      loadSpriteImgs("quay-crane", QuayCraneImg, 150, 380, map);
      loadSpriteImgs(
        "single-side-yard-crane",
        SingleSideYardCarneImg,
        40,
        205,
        map
      );
      loadSpriteImgs(
        "double-side-yard-crane",
        DoubleSideYardCraneImg,
        40,
        225,
        map
      );
      loadSpriteImgs("diagonal-stripe", BASE64_PATTERN, 8, 8, map);
      loadSpriteImgs("boxed-stripe", ServiceLaneIcon, 32, 32, map);
      loadSpriteImgs("platform-stripe", PlatformLanePattern, 6, 6, map);
      loadSpriteImgs("RFIDICON", RFIDICON, 40, 40, map);
      loadSpriteImgs("WIFIICON", WIFIICON, 40, 40, map);
    });
  }, []);

  useEffect(() => {
    if (!equipmentState || !mapRef.current || !followEquipment) {
      setRouteingJson({});

      return;
    }



    let FollowRoute = null;
    switch (equipmentState.routeSegment) {
      case RouteSegmentType.ParkingToSTS01:
        FollowRoute = RouteParkingToLane1;
        break;
      case RouteSegmentType.ParkingToSTS02:
        FollowRoute = RouteParkingToLane2;
        break;
      case RouteSegmentType.STS01ToYard:
        FollowRoute = RouteLane1ToBlock1EW;
        break;
      case RouteSegmentType.STS02ToYard:
        FollowRoute = RouteLate2ToBlock1EW;
        break;
      case RouteSegmentType.YardToParkingLane1:
        FollowRoute = RouteBlock1EWToParking;
        break;
      case RouteSegmentType.YardToParkingLane2:
        FollowRoute = RouteBlock1EWToParking2;
        break;
      case RouteSegmentType.YardToSTS01:
        FollowRoute = Route1EBlockToLane1;
        break;
      case RouteSegmentType.YardToSTS02:
        FollowRoute = Route1EBlockToLane2;
    }

    if (!FollowRoute) {
      setRouteingJson({});
      return;
    }

    /*  
    const equipmentPoint = turf.point([
       equipmentState.longitude,
       equipmentState.latitude,
     ]);
     let nearestIdx = 0;
     let minDistance = Infinity;
 
     FollowRoute.features.forEach((feature, index) => {
       if (feature.geometry.type !== "Point") return;
 
       const point = turf.point(feature.geometry.coordinates);
       const distance = turf.distance(equipmentPoint, point, {
         units: "meters",
       });
 
       if (distance < minDistance) {
         minDistance = distance;
         nearestIdx = index;
       }
     });
 
     const trimmedFeatures = FollowRoute.features.slice(nearestIdx);
     const updatedRoute = { ...FollowRoute, features: trimmedFeatures };
     console.log("updatedRoute", updatedRoute);
     setRouteingJson(structuredClone(updatedRoute));
 */


    FollowRoute = createLineGeoJsonByDirectionChange(sortGeoJsonByTime(FollowRoute as GeoJSON.FeatureCollection));
    const equipmentPoint = turf.point([equipmentState.longitude, equipmentState.latitude]);
    let nearestCoordIdx = 0;
    let minDistance = Infinity;

    // Flatten all coordinates from all LineStrings
    const allCoords: number[][] = [];

    FollowRoute.features.forEach((feature) => {
      if (feature.geometry.type === "LineString") {
        allCoords.push(...feature.geometry.coordinates);
      }
    });

    // Find the nearest coordinate
    allCoords.forEach((coord, index) => {
      const point = turf.point(coord);
      const distance = turf.distance(equipmentPoint, point, { units: "meters" });

      if (distance < minDistance) {
        minDistance = distance;
        nearestCoordIdx = index;
      }
    });

    // Trim coordinates from nearest index
    const trimmedCoords = allCoords.slice(nearestCoordIdx);
    // const trimmedCoords = allCoords;
    // Safely create LineString if enough points
    if (trimmedCoords.length >= 2) {
      const updatedRoute = turf.featureCollection([
        turf.lineString(trimmedCoords)
      ]);
      setRouteingJson(updatedRoute);
    } else {
      console.warn("Not enough points to form a LineString");
      setRouteingJson(null); // or handle appropriately
    }
    mapRef.current.easeTo({
      center: [equipmentState.longitude, equipmentState.latitude],
      zoom: 18,
      duration: 500,
    });
  }, [equipmentState, followEquipment]);



  const handleResetView = () => {
    mapRef.current?.flyTo({
      center: INITIAL_CENTER,
      zoom: INITIAL_ZOOM,
      bearing: INITIAL_BEARING,
      duration: 1000,
    });
  };

  const baseMapStyle = useMemo(() => {
    return showBaseMap
      ? {
        ...createGoogleStyle("google", "satellite", VITE_GOOGLE_MAPS_KEY),
        glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
      }
      : {
        version: 8,
        sources: {},
        layers: [],
        glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
      };
  }, [showBaseMap]);

  return (
    <div className="relative w-full h-full">
      {EquipmentLists && (
        <>
          {/* code changes for ITV aand job info */}
          <div className="absolute z-10 gap-3 px-3 py-2 bg-white border rounded shadow top-2 right-12">
            <div className="flex items-center space-x-0.5">
              <label className="block text-sm font-semibold">Follow ITV:</label>
              <select
                className="border rounded z-[999] p-0.5"
                onChange={(e) => {
                  const selected = e.target.value;
                  if (selected === "") {
                    setFollowEquipment(false);
                    setSelectedEquipmentId(null);
                    handleResetView();
                  } else {
                    setSelectedEquipmentId(selected);
                    setFollowEquipment(true);
                  }
                }}
                value={selectedEquipmentId || ""}
              >
                <option value="">-- Select --</option>
                {EquipmentLists.features.map((feature) => (
                  <option
                    key={feature.properties.equipmentId}
                    value={feature.properties.equipmentName}
                  >
                    {feature.properties.equipmentName}
                  </option>
                ))}
              </select>
            </div>
            {selectedEquipmentId && equipmentState && (
              <div className="absolute bg-[#DFF5F6] -top-[122px] -right-12 p-2  z-10 w-[250px] h-[120px] overflow-y-auto bg-white border border-gray-300 shadow-md rounded-md p-3 text-sm space-y-2 transition-all duration-300 ease-in-out opacity-100">
                <div className="flex items-center justify-center space-x-2">
                  <BsTruckFlatbed size={20} color="black" />
                  
                  <span className="font-bold text-[#E77200]">{`${equipmentState.equipmentName} (${equipmentState.equipmentType})`}</span>
                </div>
                <div>
                  <span className="font-bold text-gray-700 text-sm">State:</span>
                  <span>{equipmentState?.status === "Available" ? " Active" : " Inactive"}</span>
                </div>
                <div >
                  <span className="font-extrabold text-[#2C427E] text-sm">Move Details</span>
                </div>
                <div >
                  <span className="font-semibold text-gray-700 text-sm">Move Kind:</span>
                  <span className="ml-1">{equipmentState?.jobDetails?.[0]?.type}</span>
                </div>
                <div >
                  <span className="font-semibold text-gray-700 text-sm">Job Stepping Status:</span>
                  <span className="ml-1">{equipmentState?.jobSteppingStatus}</span>
                </div>
                {equipmentState?.jobDetails?.length > 0 && (
                  <div>
                    <div className="font-extrabold text-[#2C427E] pb-1">Jobs</div>
                    <div className="space-y-2">
                      {equipmentState?.jobDetails.map((container, index) => (
                        <div
                          key={index}
                          className="text-gray-900 border-b pb-2"
                        >
                          <div className="flex gap-4 text-sm font-medium">
                            <span className="truncate" title={container.containerId}>
                              {`${container.containerId} / ${container.iso}`}
                            </span>
                          </div>
                          <div className="text-sm font-semibold text-gray-700 mt-1">
                            Pos on Chassis: <span className="font-medium">{container.posOnChassis}</span>
                          </div>
                          <div className="text-sm font-semibold text-gray-700">
                            Drop Location: <span className="font-medium">{container.TargetPos}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}

      <RMapContextProvider>
        <div className="relative">
          <BaseMapToggle
            showBaseMap={showBaseMap}
            onToggle={() => setShowBaseMap(!showBaseMap)}
          />
          <RMap
            ref={mapRef}
            style={{
              width: "100%",
              minHeight: height === "waterside" ? "300px" : "500px",
              height: "100%",
              backgroundColor: showBaseMap ? "transparent" : "white",
            }}
            mapStyle={baseMapStyle}
            initialCenter={INITIAL_CENTER}
            initialZoom={INITIAL_ZOOM}
            initialBearing={INITIAL_BEARING}
            initialPitch={0}
            dragRotate={false}
            touchZoomRotate={false}
            initialCanvasContextAttributes={{
              antialias: true,
            }}
          >
            <PlatformLayer />
            <ContainerLayer />
            <RoadLane />
            <HatchedAreaLayer />
            <DividerLayer />
            <ParkingLayer />
            <RFIDLayer />
            <GeoFencesLayer />
            <RoutesLayer data={RouteingJson} />
            {/* <EquipmentLayer data={EquipmentLists} /> */}

            {equipmentData?.map((equipment) => {
              const markerSize = getMarkerSize(mapZoom);
              const { image, rotation } = getEquipmentMarkerImageByDirection(
                equipment,
                selectedEquipmentId
              );

              return (
                <EnhancedAnimatedMarker
                  key={equipment.equipmentId}
                  equipmentId={equipment.equipmentId}
                  image={image}
                  rotation={rotation}
                  size={markerSize}
                  targetLat={equipment.latitude}
                  targetLng={equipment.longitude}
                />
              );
            })}

            {/*  {mapZoom >= 16 &&
  YardCranes?.map((YardCrane) => {
    const markerSize = getYardCraneMarkerSize(mapZoom);
    const { image, rotation } = getYardCraneMarkerImageByDirection(YardCrane);

    return (
      <ImageMarker
        key={YardCrane.id}
        equipmentId={YardCrane.id}
        imageSrc={image}
        rotation={rotation}
        size={markerSize}
        latitude={YardCrane.latitude}
        longitude={YardCrane.longitude}
        altText={YardCrane.id}
      />
    );
  })}
 */}

            <QuayCrane />
            <YardCranesLayer yardCranes={YardCranes} />
            <MapControls onResetView={handleResetView} />
          </RMap>
        </div>
      </RMapContextProvider>
    </div>
  );
}
