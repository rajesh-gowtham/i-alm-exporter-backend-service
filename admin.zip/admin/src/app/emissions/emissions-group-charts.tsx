import React, { useState, useMemo, useEffect } from "react";
import { useEmissionsChartsStore } from "./emissions-charts-store";
import { emissionGroups } from "./emission-groups";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
  Label,
} from "recharts";
import type { TooltipProps } from "recharts";
import { ChartFilterDropdown } from "./chart-filter";

const groupLabels = {
  carbonOxides: "Carbon Oxides",
  nitrogenGases: "Nitrogen Gases",
  particulates: "Particulates",
};

const COLORS = {
  duration: "hsl(var(--chart-1))",
  load: "hsl(var(--chart-2))",
  main: "hsl(var(--chart-4))",
};

function CustomTooltip({
  active,
  payload,
  label,
}: TooltipProps<string, string>) {
  if (!active || !payload || !payload.length) return null;

  const getColor = (dataKey: string = ""): string => {
    if (/engineLoad/i.test(dataKey)) return COLORS.load;
    if (/duration|hours/i.test(dataKey)) return COLORS.duration;
    if (/gal|fuel/i.test(dataKey)) return "#0ea5e9"; // Per-gal lines (if you use them)
    return COLORS.main;
  };

  return (
    <div className="min-w-[150px] p-4 text-sm rounded-md shadow bg-popover text-popover-foreground">
      <div className="mb-2 font-semibold">{label}</div>
      <div className="flex flex-col gap-1">
        {payload.map((p) => (
          <div key={p.dataKey} className="flex items-center gap-2 text-sm">
            <span
              className="inline-block w-3 h-3 mr-1 rounded-sm"
              style={{ background: getColor(p.dataKey as string) }}
            />
            <span>
              {p.name}: {p.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

const EmissionsGroupCharts: React.FC = () => {
  const {
    selectedGroup: group,
    setSelectedGroup: setGroup,
    viewMode,
    setViewMode,
    selectedAssetId,
    emissionsData,
  } = useEmissionsChartsStore();

  const assetData = emissionsData[selectedAssetId];
  const metrics = emissionGroups[group];

  // Track visible charts in local state (reset when group changes)
  const [visibleKeys, setVisibleKeys] = useState<string[]>(
    metrics.map((m) => m.key)
  );

  // Reset visibility on group change
  useEffect(() => {
    setVisibleKeys(emissionGroups[group].map((m) => m.key));
  }, [group]);

  const data = useMemo(() => {
    const records = assetData?.emissions?.[viewMode] || [];
    return records.map((rec) => ({
      date: rec.date,
      duration:
        viewMode === "active" ? rec.totalActiveHours : rec.totalIdleHours,
      engineLoadPercent: rec.engineLoadPercent,
      ...rec,
    }));
  }, [assetData, viewMode]);

  return (
    <div className="space-y-7">
      {/* Group selector + View toggle */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {Object.keys(emissionGroups).map((g) => (
          <button
            key={g}
            className={`px-4 py-2 rounded-lg font-semibold border transition
            ${
              group === g
                ? "bg-blue-600 text-white border-blue-700 shadow"
                : "bg-white dark:bg-neutral-900 text-gray-700 dark:text-gray-100 border-gray-300 dark:border-neutral-700 hover:bg-blue-50 dark:hover:bg-neutral-800"
            }`}
            onClick={() => setGroup(g as keyof typeof emissionGroups)}
          >
            {groupLabels[g as keyof typeof emissionGroups]}
          </button>
        ))}
        {/* Active/Idle toggle */}
        <div className="flex items-center gap-1 ml-4">
          <label className="font-semibold text-gray-600 dark:text-gray-300">
            View:
          </label>
          <button
            onClick={() => setViewMode("active")}
            className={`px-3 py-1 rounded-l ${
              viewMode === "active"
                ? "bg-blue-500 text-white"
                : "bg-gray-100 dark:bg-neutral-800 text-gray-700 dark:text-gray-100"
            }`}
          >
            Active
          </button>
          <button
            onClick={() => setViewMode("idle")}
            className={`px-3 py-1 rounded-r ${
              viewMode === "idle"
                ? "bg-blue-500 text-white"
                : "bg-gray-100 dark:bg-neutral-800 text-gray-700 dark:text-gray-100"
            }`}
          >
            Idle
          </button>
        </div>

        {/* Show/Hide Charts Filter */}
        <ChartFilterDropdown
          metrics={metrics}
          visibleKeys={visibleKeys}
          setVisibleKeys={setVisibleKeys}
        />
      </div>

      {/* Chart grid */}
      <div className="grid grid-cols-1 gap-7 sm:grid-cols-2 xl:grid-cols-3">
        {metrics
          .filter((metric) => visibleKeys.includes(metric.key))
          .map((metric) => (
            <div
              key={metric.key}
              className="p-5 transition bg-white border shadow-sm border-muted dark:bg-neutral-900 dark:border-neutral-700 rounded-2xl hover:shadow-lg"
            >
              <h3 className="mb-1 text-base font-semibold tracking-tight text-gray-800 dark:text-gray-200">
                {metric.label}
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <ComposedChart
                  data={data}
                  margin={{ top: 12, right: 18, left: 14, bottom: 10 }}
                  barCategoryGap={0}
                  barGap={0}
                >
                  <CartesianGrid
                    strokeDasharray="2 3"
                    stroke="#e5e7eb"
                    className="dark:stroke-[#2d323c]"
                  />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#64748b", fontSize: 13 }}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickLine={false}
                    interval={0}
                    padding={{ left: 0, right: 0 }}
                    className="dark:text-gray-400"
                    height={32}
                  />
                  {/* Left Y axis (duration, per-gal-fuel) */}
                  <YAxis
                    yAxisId="left"
                    width={40}
                    domain={[0, "dataMax + 0.5"]}
                    stroke="#a1a1aa"
                    tick={{ fill: "#6b7280", fontSize: 13 }}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickLine={false}
                    className="dark:text-gray-400"
                  >
                    <Label
                      value="Hours"
                      angle={-90}
                      position="insideLeft"
                      fontSize={13}
                      fill="#64748b"
                      offset={8}
                      style={{ textAnchor: "middle" }}
                      className="dark:fill-gray-400"
                    />
                  </YAxis>
                  {/* Engine Load axis (right) */}
                  <YAxis
                    yAxisId="middle"
                    orientation="right"
                    width={40}
                    domain={[0, 100]}
                    stroke="#a1a1aa"
                    tick={{ fill: "#6b7280", fontSize: 13 }}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickLine={false}
                    className="dark:text-gray-400"
                  >
                    <Label
                      value="Load %"
                      angle={90}
                      position="insideRight"
                      fontSize={13}
                      fill="#64748b"
                      offset={8}
                      style={{ textAnchor: "middle" }}
                      className="dark:fill-gray-400"
                    />
                  </YAxis>
                  {/* Main emission axis (hidden) */}
                  <YAxis yAxisId="right" orientation="right" hide />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend
                    wrapperStyle={{
                      paddingTop: 2,
                      fontSize: 13,
                      color: "#64748b",
                    }}
                    iconType="circle"
                    height={30}
                  />
                  {/* Main Bars */}
                  <Bar
                    yAxisId="left"
                    dataKey="duration"
                    name={viewMode === "active" ? "Active Hours" : "Idle Hours"}
                    fill={COLORS.duration}
                    barSize={26}
                    minPointSize={12}
                    radius={0}
                    opacity={0.93}
                    maxBarSize={32}
                  />
                  <Bar
                    yAxisId="middle"
                    dataKey="engineLoadPercent"
                    name="Engine Load (%)"
                    fill={COLORS.load}
                    barSize={26}
                    minPointSize={12}
                    radius={0}
                    opacity={0.93}
                    maxBarSize={32}
                  />
                  {/* Main emission line */}
                  <Line
                    yAxisId="right"
                    type="linear"
                    dataKey={metric.key}
                    name={metric.label}
                    stroke={COLORS.main}
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          ))}
      </div>
    </div>
  );
};

export default EmissionsGroupCharts;
