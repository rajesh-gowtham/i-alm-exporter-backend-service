
# Emissions Analytics Feature – Documentation

## Overview

This module implements an interactive analytics dashboard for port vehicle emissions, providing **summary KPIs**, **interactive charts**, and **tabular data**. It enables users to select an asset (vehicle), emissions group (e.g. Carbon Oxides), and operating mode (Active/Idle), and instantly view breakdowns and trends for all key emission metrics.

---

## File Structure & Feature Description

### **1. Asset Data Files**
- **Files:** `/data/asset-154.json`, `/data/asset-165.json`, `/data/asset-190.json`, `/data/asset-223.json`
- **Purpose:** Store all per-asset emissions telemetry, ready for front-end use. Loaded dynamically on page load.
- **Structure:**  
  ```json
  {
    "assetId": 154,
    "emissions": {
      "active": [ { /* EmissionRecord fields per day */ }, ... ],
      "idle": [ { /* EmissionRecord fields per day */ }, ... ]
    }
  }
  ```
  - Each entry contains all emission and operational fields needed for summaries, charts, and tables.

---

### **2. Store & State Management**
- **File:** `emissions-charts-store.ts`
- **Purpose:** Central Zustand store for:
  - Current group (carbonOxides, nitrogenGases, particulates)
  - Selected asset ID
  - View mode (active/idle)
  - Emissions data (all loaded assets)
- **Pattern:** Global React state; used by all other components for instant UI sync.

---

### **3. Filtering UI**
- **Files:** `filters.tsx`, `asset-select.tsx`
- **Description:**  
  - `filters.tsx`: Contains main filter bar, including (optionally) date range, utilization, and the **AssetSelector**.
  - `asset-select.tsx`: ShadCN-based dropdown for asset selection, updating global store on change.

---

### **4. KPI Cards**
- **File:** `cards.tsx`
- **Component:** `EmissionSummaryCards`
- **Functionality:**  
  - Renders cards for:
    - Total CO₂ (kg)
    - Idle Hours
    - Active Hours
    - Idle %
    - Active %
  - Each card is draggable/reorderable, shows an icon and color (consistent with metric meaning).
  - All values are computed from the currently selected asset and emissions view.

---

### **5. Emission Metric Groups**
- **File:** `emission-groups.ts`
- **Purpose:**  
  - Defines the **available metrics** for each emissions group.
  - Each group (carbonOxides, nitrogenGases, particulates) contains an array of metrics, each with:
    - `key`: field in the data
    - `label`: display label
    - `fuelKey`/`fuelLabel`: (optional) corresponding fuel-normalized metric for dual-line/axis charts.
- **This config drives both chart and table column mapping.**

---

### **6. Emissions Group Charts**
- **File:** `emissions-group-charts.tsx`
- **Component:** `EmissionsGroupCharts`
- **Features:**
  - Grid of cards: one for each metric in the selected group (from `emission-groups.ts`).
  - Each card contains a **Recharts ComposedChart**:
    - Bar: Time (active/idle hours) — colored by CSS variable (`--chart-1`)
    - Bar: Engine Load (%) — colored by CSS variable (`--chart-2`)
    - Line: Main emission value (from metric key)
    - Optional Line: Fuel-normalized value (if metric has `fuelKey`)
    - Axes: Adaptive, with clear labeling and theme-aware styling
    - **Custom Tooltip:** Dark/light aware using Tailwind classes, shows all values for hovered point.
  - Users can select group and view (Active/Idle) via toggles at the top.
  - Responsive and compact layout, with full dark theme support.

---

### **7. Emissions Data Table**
- **Files:** `table.tsx`, `columns.ts`
- **Component:** `EmissionsTable`
- **Features:**
  - TanStack Table, shows all data for current asset/view/group.
  - Only columns relevant to the current group are shown (mapping via `emissionGroupColumnKeys`).
  - All columns and formatting are defined in `columns.ts`.
  - Supports column show/hide, sorting, and pagination.

---

## **How Data Flows**

1. **On Page Load:**
   - `emissions-page.tsx` loads all asset data files and stores them in Zustand.

2. **User Interaction:**
   - User selects an asset/group/view in filters.
   - All KPI cards, charts, and the table update in sync using the central store and config-driven mappings.

3. **Charts & Table:**
   - Each chart and table cell pulls its data from the selected asset’s dataset, using the keys and labels defined in `emission-groups.ts` and `columns.ts`.

---

## **Summary Table of Key Files**

| File                       | Purpose                                                                                  |
|----------------------------|------------------------------------------------------------------------------------------|
| `asset-xxx.json`           | Data source for each vehicle asset, loaded by emissions-page                             |
| `emissions-charts-store.ts`| Zustand store: global state (asset/group/view/data)                                      |
| `filters.tsx`              | Top bar for all dashboard filters                                                        |
| `asset-select.tsx`         | Asset dropdown using ShadCN UI                                                           |
| `cards.tsx`                | Draggable summary KPI cards (Total CO2, Hours, %, etc)                                  |
| `emission-groups.ts`       | Declarative config for all available metrics (group, label, fuelKey, fuelLabel)          |
| `emissions-group-charts.tsx`| Grid of all charts for current group (bars, lines, custom tooltips, theme support)     |
| `table.tsx` + `columns.ts` | Tabular view of all emissions data, responsive to asset/group/view                      |
| `emissions-page.tsx`       | Main orchestrator: loads data, renders all other components                             |

---

## **Data Files (asset-154.json, etc.)**

- **Stored in `/data/asset-XXX.json`**
- **Structure Example:**
  ```json
  {
    "assetId": 154,
    "emissions": {
      "active": [
        {
          "date": "2025-03-10",
          "CO2_percent": 6.37,
          "CO_percent": 0.00305,
          "HC_ppm": 0.39,
          "NO_ppm": 104.2,
          "NO2_ppm": 3.6,
          "NOx_ppm": 108,
          ...
        },
        ...
      ],
      "idle": [
        // ...same structure as "active"
      ]
    }
  }
  ```
- **Each entry contains all metric fields required for summary cards, charts, and tables.**
- **Metric keys** match those in `emission-groups.ts` and `columns.ts`.

---

## **Extensibility & Customization**

- To add new metrics, simply update `emission-groups.ts` and add data fields to your asset JSON.
- Theme and chart colors are controlled via CSS variables, fully supporting dark mode.
- All KPIs, charts, and table columns update dynamically in response to user selections, with no code duplication.

