import useEmissionsStore from "@/lib/stores/emissions-store";
import { DatePickerWithRange } from "@/components/range-date-picker";
import { DateRange } from "react-day-picker";
import AssetSelector from "./asset-select";

export type Vehicle = {
  name?: string;
  asset?: string;
  id?: string;
};

export type EmissionsFilters = {
  asset: string;
  state: "Active" | "Idle" | "Both";
  utilizationRange: [number, number];
  fuelRange: [number, number];
  dateRange: DateRange | undefined;
  assetOptions: string[];
};

const FiltersBar: React.FC = () => {
  const { filters, setFilters } = useEmissionsStore();

  const handleInput = (
    field: keyof EmissionsFilters,
    value:
      | string
      | [number, number]
      | DateRange
      | undefined
      | "Active"
      | "Idle"
      | "Both"
      | string[]
  ) => {
    setFilters({ ...filters, [field]: value });
  };

  // Predefined options for utilization and fuel ranges
  const utilizationOptions = [
    { label: "Any", value: [0, 12] },
    { label: "0-2 hrs", value: [0, 2] },
    { label: "2-4 hrs", value: [2, 4] },
    { label: "4-6 hrs", value: [4, 6] },
    { label: "6-8 hrs", value: [6, 8] },
    { label: "8+ hrs", value: [8, 12] },
  ];

  // Find the current label for selected ranges
  const selectedUtilizationLabel =
    utilizationOptions.find(
      (option) =>
        option.value[0] === filters.utilizationRange[0] &&
        option.value[1] === filters.utilizationRange[1]
    )?.label || "Custom";

  return (
    <div className="flex flex-wrap items-center w-full gap-x-3 gap-y-2">
      {/* Asset Selector */}
      <div className="flex items-center w-64 gap-2 px-2 py-1">
        <AssetSelector />
      </div>

      {/* State Selector */}
      {/* <div className="flex items-center gap-2 px-2 py-1 border border-green-100 rounded-full bg-green-50/50 dark:bg-gray-700/50 dark:border-gray-600">
        <span className="text-green-700 dark:text-green-300" aria-hidden="true">
          <SettingsIcon className="w-4 h-4" />
        </span>
        <div className="flex gap-1" role="group" aria-label="State">
          {["Active", "Idle", "Both"].map((state) => (
            <Button
              key={state}
              type="button"
              size="sm"
              variant="ghost"
              className={`px-1.5 py-0 h-6 text-xs font-medium rounded-md ${
                filters.state === state
                  ? "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300"
                  : "text-green-700 hover:bg-green-50 dark:text-green-300 dark:hover:bg-gray-700/50"
              }`}
              aria-pressed={filters.state === state}
              aria-label={state}
              tabIndex={0}
              onClick={() => handleInput("state", state)}
            >
              {state}
            </Button>
          ))}
        </div>
      </div> */}

      {/* Utilization Range Select */}
      {/* <div className="flex items-center gap-2 px-2 py-1 border border-purple-100 rounded-full bg-purple-50/50 dark:bg-gray-700/50 dark:border-gray-600">
        <span
          className="text-purple-500 dark:text-purple-300"
          aria-hidden="true"
        >
          <Timer className="w-4 h-4" />
        </span>
        <Select
          value={JSON.stringify(filters.utilizationRange)}
          onValueChange={(value) =>
            handleInput("utilizationRange", JSON.parse(value))
          }
        >
          <SelectTrigger
            id="utilizationRange"
            name="utilizationRange"
            className="w-24 text-xs bg-transparent border-0 shadow-none h-7 focus:ring-0 focus:ring-offset-0 dark:text-gray-200"
            aria-label="Utilisation"
          >
            <SelectValue placeholder={selectedUtilizationLabel} />
          </SelectTrigger>
          <SelectContent>
            {utilizationOptions.map((option) => (
              <SelectItem
                key={option.label}
                value={JSON.stringify(option.value)}
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div> */}

      {/* Date Range Picker */}
      <div className="flex items-center gap-2 px-2 py-1">
        <DatePickerWithRange
          className=""
          dateRange={filters.dateRange}
          onDateRangeChange={(range) => handleInput("dateRange", range)}
          aria-label="Date Range"
          disabled={true}
        />
      </div>
    </div>
  );
};

export default FiltersBar;
