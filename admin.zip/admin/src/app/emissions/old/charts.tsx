import React, { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ComposedChart,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Bar,
  Line,
  ResponsiveContainer,
  CartesianGrid,
  TooltipProps,
} from "recharts";
import useEmissionsStore from "@/lib/stores/emissions-store";
import useSWR from "swr";
import { format, parseISO } from "date-fns";
import { getEmissionsChartData } from "@/lib/api/emissions-endpoints";
import { ChartContainer } from "@/components/ui/chart";
import { EmissionsChartPoint } from "@/lib/models/emissions";
import type {
  NameType,
  ValueType,
} from "recharts/types/component/DefaultTooltipContent";

interface ShapedChartRow {
  date: string;
  active: number;
  idle: number;
  avgEngineLoad: number;
  activeRow?: EmissionsChartPoint;
  idleRow?: EmissionsChartPoint;
}

interface PollutantConfig {
  key: keyof EmissionsChartPoint;
  rateKey: keyof EmissionsChartPoint;
  label: string;
  barUnit: string;
  lineUnit: string;
  colorActive: string;
  colorIdle: string;
}

// --------- Config ---------
const POLLUTANTS: PollutantConfig[] = [
  {
    key: "co2KgTotal",
    rateKey: "co2KgH",
    label: "CO₂ Emitted",
    barUnit: "kg",
    lineUnit: "%",
    colorActive: "hsl(var(--chart-1))",
    colorIdle: "hsl(var(--chart-3))",
  },
  {
    key: "noxGTotal",
    rateKey: "noxGH",
    label: "NOx Emitted",
    barUnit: "g",
    lineUnit: "%",
    colorActive: "hsl(var(--chart-1))",
    colorIdle: "hsl(var(--chart-3))",
  },
  {
    key: "coGTotal",
    rateKey: "coGH",
    label: "CO Emitted",
    barUnit: "g",
    lineUnit: "%",
    colorActive: "hsl(var(--chart-1))",
    colorIdle: "hsl(var(--chart-3))",
  },
  {
    key: "pmGTotal",
    rateKey: "pmGH",
    label: "PM Emitted",
    barUnit: "g",
    lineUnit: "%",
    colorActive: "hsl(var(--chart-1))",
    colorIdle: "hsl(var(--chart-3))",
  },
];

// --------- Helpers ---------
function shapeEmissionsChart(
  data: EmissionsChartPoint[] | undefined,
  totalKey: keyof EmissionsChartPoint
): ShapedChartRow[] {
  if (!data) return [];
  const byDate: Record<
    string,
    { active?: EmissionsChartPoint; idle?: EmissionsChartPoint }
  > = {};
  data.forEach((row) => {
    if (!byDate[row.date]) byDate[row.date] = {};
    byDate[row.date][row.state.toLowerCase() as "active" | "idle"] = row;
  });
  return Object.entries(byDate).map(([date, rows]) => ({
    date: date.slice(0, 10),
    active: rows.active ? (rows.active[totalKey] as number) : 0,
    idle: rows.idle ? (rows.idle[totalKey] as number) : 0,
    avgEngineLoad:
      ((rows.active?.avgEngineLoad ?? 0) + (rows.idle?.avgEngineLoad ?? 0)) /
      ([rows.active, rows.idle].filter(Boolean).length || 1),
    activeRow: rows.active,
    idleRow: rows.idle,
  }));
}

// Exclusive Tooltip per chart
const PollutantTooltip: React.FC<
  TooltipProps<ValueType, NameType> & { config: PollutantConfig }
> = ({ active, payload, label, config }) => {
  if (!active || !payload || !payload[0]) return null;
  const d = payload[0].payload as ShapedChartRow;
  if (!d) return null;

  // Get active/idle rows and colors
  const { activeRow, idleRow } = d;
  const barUnit = config.barUnit;
  const rateUnit = config.barUnit === "kg" ? "kg/h" : "g/h";
  const pollutantKey = config.key;
  const rateKey = config.rateKey;

  return (
    <div className="p-3 text-xs bg-white rounded-lg shadow dark:bg-gray-900 min-w-40">
      <div className="mb-1 font-bold">{label}</div>
      <table className="w-full">
        <thead>
          <tr>
            <th />
            <th>Active</th>
            <th>Idle</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              {config.label} ({barUnit})
            </td>
            <td>{activeRow ? activeRow[pollutantKey] : "–"}</td>
            <td>{idleRow ? idleRow[pollutantKey] : "–"}</td>
          </tr>
          <tr>
            <td>
              {config.label} ({rateUnit})
            </td>
            <td>{activeRow ? activeRow[rateKey] : "–"}</td>
            <td>{idleRow ? idleRow[rateKey] : "–"}</td>
          </tr>
          <tr>
            <td>Avg Engine Load (%)</td>
            <td>{activeRow?.avgEngineLoad ?? "–"}</td>
            <td>{idleRow?.avgEngineLoad ?? "–"}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

// --------- Chart ---------
interface EmissionsBarLineChartProps {
  data: ShapedChartRow[];
  config: PollutantConfig;
  isLoading: boolean;
}
const EmissionsBarLineChart: React.FC<EmissionsBarLineChartProps> = ({
  data,
  config,
}) => (
  <Card className="shadow-none cursor-pointer dark:shadow-none">
    <CardHeader>
      <CardTitle>
        {config.label}{" "}
        <span className="text-xs text-gray-500">({config.barUnit})</span>
      </CardTitle>
    </CardHeader>
    <CardContent className="px-2 pb-4">
      <ChartContainer config={{}}>
        <ResponsiveContainer width="100%" height={220}>
          <ComposedChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="date"
              tickFormatter={(val: string) => format(parseISO(val), "MMM dd")}
            />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" width={40} />
            <Tooltip content={<PollutantTooltip config={config} />} />
            <Legend />
            <Bar
              yAxisId="left"
              dataKey="active"
              name="Active"
              stackId="a"
              fill={config.colorActive}
              maxBarSize={22}
            />
            <Bar
              yAxisId="left"
              dataKey="idle"
              name="Idle"
              stackId="b"
              fill={config.colorIdle}
              maxBarSize={22}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="avgEngineLoad"
              name="Avg Engine Load"
              stroke="#22d3ee"
              dot={false}
              strokeWidth={2}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </ChartContainer>
    </CardContent>
  </Card>
);

// --------- Main Component ---------
const EmissionsCharts: React.FC = () => {
  const { filters } = useEmissionsStore();

  const { data, isLoading } = useSWR(
    filters.asset
      ? [
          `/emissions/${filters.asset}/chart`,
          filters.asset,
          filters.dateRange!.from,
          filters.dateRange!.to,
        ]
      : null,
    async ([, vid, from, to]) => {
      // Convert from/to to Date objects for the API
      const fromDate = from ? new Date(from) : undefined;
      const toDate = to ? new Date(to) : undefined;
      if (!fromDate || !toDate) return [];
      const response = await getEmissionsChartData(vid, fromDate, toDate);
      return response;
    },
    {
      refreshInterval: 300_000,
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    }
  );

  useEffect(() => {
    if (data) {
      // console.log("Fetched emissions data:", data);
    }
  }, [data]);

  return (
    <div className="pb-2 overflow-x-auto">
      <div className="relative grid grid-flow-row lg:grid-flow-col lg:gap-4 lg:min-w-[800px] sm:min-w-0 grid-cols-1 lg:grid-cols-4">
        {POLLUTANTS.map((config) => (
          <EmissionsBarLineChart
            key={config.key}
            data={shapeEmissionsChart(data, config.key)}
            config={config}
            isLoading={isLoading}
          />
        ))}
      </div>
    </div>
  );
};

export default EmissionsCharts;
