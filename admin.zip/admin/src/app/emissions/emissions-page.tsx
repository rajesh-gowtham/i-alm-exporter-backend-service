import React, { useEffect } from "react";
import FiltersBar from "./filters";
import EmissionSummaryCards from "./cards";
import EmissionsTable from "./table";
import EmissionsGroupCharts from "./emissions-group-charts";
import { useEmissionsChartsStore } from "./emissions-charts-store";

const assetIds = [154, 165, 190, 223];

const EmissionsPage: React.FC = () => {
  // const { loading, error } = useEmissionsStore();
  const setEmissionsData = useEmissionsChartsStore((s) => s.setEmissionsData);

  useEffect(() => {
    Promise.all(
      assetIds.map((id) =>
        fetch(`/data/emissions/asset-${id}.json`).then((r) => r.json())
      )
    ).then(([d154, d165, d190, d223]) => {
      setEmissionsData({
        154: d154,
        165: d165,
        190: d190,
        223: d223,
      });
    });
  }, [setEmissionsData]);

  return (
    <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-2">
      {/* Filters Bar spans full width */}
      <div className="col-span-1 md:col-span-2">
        <FiltersBar />
      </div>

      {/* Summary Cards */}
      <div className="col-span-1 md:col-span-2">
        <EmissionSummaryCards />
      </div>

      {/* Tabbed Charts */}
      <div className="col-span-1 md:col-span-2">
        {/* <EmissionsCharts /> */}
        <EmissionsGroupCharts />
      </div>

      {/* Data Table */}
      <div className="col-span-1 md:col-span-2">
        <EmissionsTable />
      </div>
    </div>
  );
};

export default EmissionsPage;
