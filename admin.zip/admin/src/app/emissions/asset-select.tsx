import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useEmissionsChartsStore } from "./emissions-charts-store";

const ASSETS = [
  { id: 154, label: "Reach Stacker (154)" },
  { id: 165, label: "Fork Lift (165)" },
  { id: 190, label: "Reach Stacker (190)" },
  { id: 223, label: "Reach Stacker (223)" },
];

export default function AssetSelector() {
  const selectedAssetId = useEmissionsChartsStore((s) => s.selectedAssetId);
  const setSelectedAssetId = useEmissionsChartsStore(
    (s) => s.setSelectedAssetId
  );

  return (
    <Select
      value={selectedAssetId?.toString()}
      onValueChange={(val) => setSelectedAssetId(Number(val))}
    >
      {/* <SelectTrigger className="w-56 bg-white border rounded shadow-sm focus:ring-2 focus:ring-blue-500"> */}
      <SelectTrigger className="flex-1">
        <SelectValue placeholder="Select Asset" />
      </SelectTrigger>
      <SelectContent>
        {ASSETS.map((a) => (
          <SelectItem key={a.id} value={a.id.toString()}>
            {a.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
