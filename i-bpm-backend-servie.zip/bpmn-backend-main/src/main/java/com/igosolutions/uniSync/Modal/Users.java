package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private String username;
	private String password;
	private String email;
	private String mekey;
	private String almkey;
	private String usercreateon;
	private String userupdateon;
	
	
	public Users() {
		
	}
	
	@Override
	public String toString() {
		return "Users [username=" + username + ", password=" + password + ",mekey=" + mekey +"]";
	}
	
	
	
	
	public String getupdatetime() {
		return userupdateon;
	} 
	public void setupdatetime(String userupdateon) {
		this.userupdateon = userupdateon;
	}
	
	
	public String getcreatetime() {
		return usercreateon;
	} 
	
	public void setcreatetime(String usercreateon) {
		this.usercreateon = usercreateon;
	}
	
	public String getMe_Key() {
		return mekey;
	} 
	public void setMe_Key(String mekey) {
		this.mekey = mekey;
	}
	public String getALM_Key() {
		return almkey;
	} 
	public void setALM_Key(String ALM_Key) {
		this.almkey = ALM_Key;
	}
	

	public String getUsername() {
		return username;
	} 
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void ReactLogins(String username ,String password) {
		this.password = password;
		this.username = username;
	}
	
	public String ReactLogins() {
		return password;
	}
	
	public String getEmail() {
		return email;
	} 
	public void setEmail(String email) {
		this.email = username;
	}
	
	
}
