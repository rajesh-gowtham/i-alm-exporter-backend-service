package com.igosolutions.uniSync.controller;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Service.DataSourceService;
import net.minidev.json.parser.ParseException;


@RestController
//@CrossOrigin(origins = "http://localhost:7676/")
public class DataSourceController {
	@Autowired
	public DataSourceService datasourceservice;

	private DataSource source;

	public String almURL;
	public static String lwssoCookie = "";
	public static String cookies;
	public List domaindata = new LinkedList();
	public static String xsrfHeaderValue = "";
	public List projectData = new LinkedList();
	public Map map = new HashMap();
	
	

	public static String baseMEURl;
	public static String getFieldURL;
	public static String getSubfield_KeyValue_ME = "{\"requesttype\": \"name\", \"status\": \"statusname\" , \"mode\": \"modename\" ,\"level\": \"levelname\", \"priority\": \"priorityname\" , \"impact\": \"name\",\"urgency\": \"name\",\"replytemplate\": \"templatename\" ,\"resolutiontemplate\": \"templatename\" }";;
	public static String techniciankey = "";
	public static String Client_ALM_URL=null;
	public static String Client_ALM_USERNAME=null;
	public static String Client_ALM_PASSWORD=null;
	public static String Client_ALM_dataSourceName=null;
	public static String Client_ALM_orgName=null;
	public static String Client_ALM_Modulename=null;
	public static String Client_ALM_Domainname=null;
	public static String Client_ALM_Projectname=null;
	
	
	public static Map<Object, Object> mappingUserdefinedfields_ALM = new HashMap<Object, Object>();
	
	

	
	public static void ALMRe_authConnection() {
		String responseBody = "";

			try {
				if (!lwssoCookie.isEmpty()) {
					lwssoCookie = "";
					cookies = "";
					xsrfHeaderValue = "";
				}
				

	         	String		almURL_ = Client_ALM_URL + "/qcbin";
				String authEndPoint = almURL_ + "/authentication-point/alm-authenticate";
				URL authUrl = new URL(authEndPoint);
				HttpURLConnection authConnection_ = (HttpURLConnection) authUrl.openConnection();
				
				try {
					
					authConnection_.setRequestMethod("POST");
					authConnection_.setRequestProperty("Content-Type", "application/xml");
					authConnection_.setDoOutput(true);
					OutputStream os = authConnection_.getOutputStream();
					try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
						osw.write("<alm-authentication><user>" + Client_ALM_USERNAME + "</user><password>"
								+ Client_ALM_PASSWORD + "</password></alm-authentication>");
					}
					authConnection_.connect();
				
					
				}catch(Exception ex) {
					LogFile.LogWrite("Data Source Controller - Error ALMRe_authConnection isValidUser func:"+ex);
					authConnection_.disconnect();
					
				}	
				
	
				
				String qcSessionEndPoint = almURL_ + "/rest/site-session";
				lwssoCookie = authConnection_.getHeaderField("Set-Cookie").split(";")[0];
				LogFile.LogWrite("Data Source Controller - the lwss cokkies ALMRe_authConnection " + lwssoCookie);
				/* create session begin */
				HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
				createSession.setRequestProperty("Cookie", lwssoCookie);
				createSession.setRequestProperty("Content-Type", "application/json");
				createSession.setRequestMethod("POST");
				createSession.connect();
				Map<String, List<String>> values = createSession.getHeaderFields();
				xsrfHeaderValue = "";

				for (String cookie : values.get("Set-Cookie")) {
					String content = cookie.split(";")[0];
					cookies = cookies + content + ";";
					String[] nameValue = content.split("=");
					String name = nameValue[0];
					String value = nameValue[1];
					if (name.equalsIgnoreCase("XSRF-TOKEN")) {
						xsrfHeaderValue = value;
					}
				}
				LogFile.LogWrite("Data Source Controller - the header ALMRe_authConnection  value is" + xsrfHeaderValue);
				createSession.disconnect();;

				HttpURLConnection authConnection = authConnection_;
				responseBody = authConnection.getResponseMessage();
				if (authConnection.getResponseCode() == 200) {
					String token = xsrfHeaderValue;
					// getAllDomain(token);
					responseBody = authConnection.getResponseMessage();
				} else if (authConnection.getResponseCode() == 400) {
					InputStream in = new BufferedInputStream(authConnection.getInputStream());
					BufferedReader reader = new BufferedReader(new InputStreamReader(in));
					StringBuilder result = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
				}
				LogFile.LogWrite("Data Source Controller - the ALMRe_authConnection respone body data is"+responseBody);
//				return responseBody;
			} catch (MalformedURLException e) {

			} catch (ProtocolException e) {

//				return e.getMessage();
			} catch (IOException e) {

//				return e.getLocalizedMessage();
			}
		
	}
	
    public String GetDesignSteps(String url,String domainname, String projectname ) throws MalformedURLException, IOException {
    	
    	
    	HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new URL(
				url + "/qcbin/" + "rest/domains/" + domainname
						+ "/projects/" + projectname + "/design-steps").openConnection();
    	LogFile.LogWrite("BPMN GetDesignSteps URL:" + url + "/qcbin/" + "rest/domains/" + domainname
				+ "/projects/" + projectname + "/design-steps");
    	 LogFile.LogWrite("BPMN DESIGN STEPS Cookie<><> :" + cookies + lwssoCookie);
    	 LogFile.LogWrite("BPMN DESIGN STEPS X-XSRF-TOKEN<><> :" +xsrfHeaderValue);
    	 LogFile.LogWrite("");
		requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		requiredFieldsConnection.setRequestProperty("Content-Type", "application/JSON");
		requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
		requiredFieldsConnection.setRequestMethod("GET");
		requiredFieldsConnection.connect();

		InputStream inputStream = new BufferedInputStream(requiredFieldsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
		String result1 = new String();
		String line1;
		// LogFile.LogWrite("BPMN GetDesignSteps reader1<><> :" + reader1);
		try {
			while ((line1 = reader1.readLine()) != null) {
				result1+=line1;
			}
			requiredFieldsConnection.disconnect();
			 LogFile.LogWrite("BPMN DESIGN STEPS result1<><> :" + result1);
			 LogFile.LogWrite("");
			 LogFile.LogWrite("");
			 
			 return result1;
		}catch(Exception ex) {
			LogFile.LogWrite("BPMN GetDesignSteps Exception :" + ex.getMessage());
			requiredFieldsConnection.disconnect();
			return null;
			
		}
    	
	}
	
	
	//  ADDED AND COMMANDED BY MUBARAK
	// BPMN-ALM
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getMappingField", method = RequestMethod.POST)
	 public List<String> getMappingField(@RequestBody DataSource dataSource) {
	//	List<DataSource> dataSourceData = datasourceservice.getAllDataSource();
		 List<String> TestCases= new  ArrayList<String>();
		 String result1 = new String();
	   try {

		   // Get DATSOURCE DETAILS
		   DataSource DataSourcedata=datasourceservice.getDataSource(dataSource.getDatasourcename());
		   String username=DataSourcedata.getUsername();
		   String password=DataSourcedata.getPassword();
		   String url=DataSourcedata.getUrl();
		   String defecttool=DataSourcedata.getDefectTool();
		   String modulename=DataSourcedata.getModulename();
		   String projectname=DataSourcedata.getProjectname();
		   String domainname=DataSourcedata.getDomainname();
		
		   
			Client_ALM_USERNAME=username;
			Client_ALM_URL=url;
			Client_ALM_PASSWORD=password;
		   
			ALMRe_authConnection(); // RE AUTHENTICATION
		   //ALM TOOL
		   if(defecttool.equals("ALM")||defecttool=="ALM") {
			///qcbin/rest/domains/{domain}/projects/{project}/tests
			   String TestFolders=url + "/qcbin/" + "rest/domains/" + domainname
						+ "/projects/" + projectname + "/tests"; //test-folders
			   //MODULE TESTING
			   if(modulename.equals("Testing")||modulename=="Testing") {
				   
				   //GET DESIGN STEPS: tests
				   TestCases.add(GetDesignSteps(url,domainname,projectname));
				   
					HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new URL(
							TestFolders).openConnection();
					requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
					requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
					requiredFieldsConnection.setRequestProperty("Content-Type", "application/JSON");
					requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
					requiredFieldsConnection.setRequestMethod("GET");
					requiredFieldsConnection.connect();

					InputStream inputStream = new BufferedInputStream(requiredFieldsConnection.getInputStream());
					BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
					 LogFile.LogWrite("BPMN TESTCASES reader1<><> :" + reader1);
					String line1;

					try {
						while ((line1 = reader1.readLine()) != null) {
							result1+=line1;
						}
						requiredFieldsConnection.disconnect();
						 LogFile.LogWrite("BPMN TESTCASES result1<><> :" + result1);
					     //Add TestCase Details
						 TestCases.add(result1);

						 
					}catch(Exception ex) {
						 LogFile.LogWrite("BPMN TESTCASES Exception<><> :" + ex.getMessage());
						requiredFieldsConnection.disconnect();
						return null;
						
					}
					
			   }
		   }
		   
		} catch (Exception e) {
		
			result1+=("{STATUS:ERROR,Exception "+e.getMessage()+"}");
		}
	   return TestCases;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/authentication", method = RequestMethod.POST)
	public String defectToolAuthentication(@RequestBody DataSource authmodal) throws IOException {
		
		LogFile.LogWrite("Data Source Controller - the respone body data is"+authmodal.getUrl());
		String responseBody = "";

		if (authmodal.getDefectTool().equals("ALM")) {
			try {
				if (!lwssoCookie.isEmpty()) {
					lwssoCookie = "";
					cookies = "";
					xsrfHeaderValue = "";
				}
				HttpURLConnection authConnection = isValidUser(authmodal);
				responseBody = authConnection.getResponseMessage();
				if (authConnection.getResponseCode() == 200) {
					String token = generateXSRFTOKEN(authConnection);
					// getAllDomain(token);
					responseBody = authConnection.getResponseMessage();
				} else if (authConnection.getResponseCode() == 400) {
					InputStream in = new BufferedInputStream(authConnection.getInputStream());
					BufferedReader reader = new BufferedReader(new InputStreamReader(in));
					StringBuilder result = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
				}
				LogFile.LogWrite("Data Source Controller - the respone body data is"+responseBody);
				return responseBody;
			} catch (MalformedURLException e) {

			} catch (ProtocolException e) {

				return e.getMessage();
			} catch (IOException e) {

				return e.getLocalizedMessage();
			}
		} else if (authmodal.getDefectTool().equals("ME")) {
			try {
				
				baseMEURl = authmodal.getUrl() + "/sdpapi/auth?username=" + authmodal.getUsername() + "&password="
						+ authmodal.getPassword() + "&format=json";
				LogFile.LogWrite("Data Source Controller - the base me url is"+baseMEURl);
				HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
				authConnection.setRequestProperty("Accept", "application/json");
				authConnection.setRequestMethod("GET");
				authConnection.setDoOutput(true);
				authConnection.connect();

				InputStream in = new BufferedInputStream(authConnection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				try {
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
				}catch(Exception ex) {
					LogFile.LogWrite("Data Source Controller -ERROR 56985 the respone body data is");
					authConnection.disconnect();
					throw ex;
				}
				
				authConnection.disconnect();
				String response = result.toString();
				JSONObject obj = new JSONObject(response);
				JSONObject operationObj = obj.getJSONObject("operation");
				JSONObject resultObj = (JSONObject) operationObj.get("result");
				JSONObject detailsObj = (JSONObject) operationObj.get("details");

				responseBody = resultObj.getString("status");
				techniciankey = detailsObj.getString("techniciankey");
				LogFile.LogWrite("Data Source Controller - the respone body data is"+responseBody);
				return responseBody;
			} catch (MalformedURLException e) {
				return e.getMessage();
			} catch (ProtocolException e) {
				return e.getMessage();
			} catch (IOException e) {
				return e.getMessage();
			}

		}
		return responseBody;
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getDomainData", method = RequestMethod.GET)
	public List getDomainData() throws MalformedURLException, IOException {
		getAllDomain(xsrfHeaderValue);
		LogFile.LogWrite("getDomainData xsrfHeaderValue is" + xsrfHeaderValue);
		return domaindata;

		// ObjectMapper mapper = new ObjectMapper();
		// JsonNode node = mapper.readTree(connection.getInputStream());
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/createNewDataSource", method = RequestMethod.POST)
	public ResponseEntity saveDataSource(@RequestBody DataSource datasource) {

		try {

			DataSource source = new DataSource();
			// source.setDatasourcename(datasource.getDatasourcename());
			// source.setDefectTool(datasource.getDefectTool());
			// source.setUrl(datasource.getUrl());
			// source.setUsername(datasource.getUsername());
			// source.setPassword(datasource.getPassword());
			// source.setDomainname(datasource.getDomainname());
			// source.setProjectname(datasource.getProjectname());
			// source.set(datasource);
			datasource.setTechniciankey(techniciankey);
			datasourceservice.saveDataSource(datasource);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value="/updateDataSource",method = RequestMethod.PUT)
	public ResponseEntity updateDataSource(@RequestBody DataSource datasource) {

		try {

			DataSource source = new DataSource();
			
			datasourceservice.updateDataSource(datasource);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value="/deleteDataSource",method = RequestMethod.DELETE)
	public ResponseEntity deleteDataSource(@RequestParam(name = "datasourcename", required = false) String datasourcename) {

		
		try {
			LogFile.LogWrite("Data Source Controller - Delete datasourcename is #101" + datasourcename);
			datasourceservice.deleteDataSource(datasourcename);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	//	LogFile.LogWrite("Data Source Controller - Delete datasourcename is #101" + datasourcename);	
		//datasourceservice.deleteDataSource(datasourcename);
		//LogFile.LogWrite("Data Source Controller - Delete datasourcename is #102" + datasourcename);
		
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getAccountsME", method = RequestMethod.GET)
	public List get_ME_Account(@RequestParam(name = "datasourcename", required = false) String datasourcename)
			throws MalformedURLException, IOException {

		List me_accountList = new LinkedList();
		DataSource source = datasourceservice.getDataSource(datasourcename);
		String newtechkey = manageEngineLogin(source);

		String accountURL = source.getUrl() + "/sdpapi/admin/account?&AUTHTOKEN=" + newtechkey + "&format=json";
		HttpURLConnection connection = (HttpURLConnection) new URL(accountURL).openConnection();
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		String jsonstring = result.toString();
		JSONObject mainObject = new JSONObject(jsonstring);

		JSONObject resultObject = mainObject.getJSONObject("operation");
		LogFile.LogWrite("Data Source Controller - the operation json object is" + resultObject);
		JSONArray detailsObject = resultObject.getJSONArray("details");
		LogFile.LogWrite("Data Source Controller - the detailsObject json object is" + detailsObject);

		for (int i = 0; i < detailsObject.length(); i++) {
			JSONObject object = detailsObject.getJSONObject(i);
			me_accountList.add(object.get("AccountName"));
		}
		
		// LIST to String:
		if(me_accountList.size()>0) {
			 String delim = "-";	 
		        StringBuilder sb = new StringBuilder();
		        int i = 0;
		        while (i < me_accountList.size() - 1)
		        {
		            sb.append(me_accountList.get(i));
		            sb.append(delim);
		            i++;
		        }
		        sb.append(me_accountList.get(i));
		 
		        String res = sb.toString();
			//END
			LogFile.LogWrite("me_accountList is "+res);
		}else {
			LogFile.LogWrite("me_accountList IS NULL");
		}
		   
		return me_accountList;

	}
	
	

	public String manageEngineLogin(DataSource authmodal) {

		try {
			baseMEURl = authmodal.getUrl() + "/sdpapi/auth?username=" + authmodal.getUsername() + "&password="
					+ authmodal.getPassword() + "&format=json";
			HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
			authConnection.setRequestProperty("Accept", "application/json");
			authConnection.setRequestMethod("GET");
			authConnection.setDoOutput(true);
			authConnection.connect();

			InputStream in = new BufferedInputStream(authConnection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}

			String response = result.toString();
			JSONObject obj = new JSONObject(response);
			JSONObject operationObj = obj.getJSONObject("operation");
			JSONObject resultObj = (JSONObject) operationObj.get("result");
			JSONObject detailsObj = (JSONObject) operationObj.get("details");

			String newtechniciankey = detailsObj.getString("techniciankey");

			LogFile.LogWrite("Data Source Controller - the technician key value is" + newtechniciankey);
			return newtechniciankey;
		} catch (MalformedURLException e) {
			return e.getMessage();
		} catch (ProtocolException e) {
			return e.getMessage();
		} catch (IOException e) {
			return e.getMessage();
		}

		// return almURL;

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getFields/", method = RequestMethod.GET)
		public List<String> getFieldsForDataSource(
				@RequestParam(name = "datasourcename", required = false) String datasourcename,
				@RequestParam(name = "orgName", required = false) String orgName) throws IOException, ParseException {
		
		List<String> fieldsList = new ArrayList<String>();
		
		LogFile.LogWrite("Data Source Controller - Server Side Parameter # 1020   "+"datasourcename    :"+datasourcename+"    orgName  :"+orgName);
		
		
		try {
		
			DataSource source = datasourceservice.getDataSource(datasourcename);
			if (source.getDefectTool().equals("ME")) {

			String uri = "http://localhost:7373/getRequestIDByOrgName?orgName=" + orgName + "";
			RestTemplate restTemplate = new RestTemplate();
			List returnids = restTemplate.getForObject(uri, List.class);
			Object object = returnids.get(0);
			Gson gson = new Gson();
			String json = gson.toJson(object);
			JSONObject obj1 = new JSONObject(json);

			int requestID = obj1.getInt("WORKORDERID");

			String newtechkey = manageEngineLogin(source);
			getFieldURL = source.getUrl() + "/sdpapi/request/" + requestID + "?&AUTHTOKEN=" + newtechkey
					+ "&format=json";
			// getFieldURL = "
			// http://172.22.6.21:7171/sdpapi/request/?&TECHNICIAN_KEY=B3F0CAC7-167C-4A26-AE4C-EFF5368A71DA&format=json";
			// source.getUrl()+"/sdpapi/request/account?&AUTHTOKEN="+source.getTechniciankey()+"&format=json";
			HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestMethod("GET");
			connection.connect();
			InputStream in = new BufferedInputStream(connection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}

			String jsonstring = result.toString();
			JSONObject mainObject = new JSONObject(jsonstring);

			JSONObject resultObject = mainObject.getJSONObject("operation");
			JSONObject detailsObject = resultObject.getJSONObject("details");

			Iterator<String> keys = detailsObject.keys();
			while (keys.hasNext()) {
				fieldsList.add(keys.next());
			}

			// LIST to String:
			if(fieldsList.size()>0) {
				 StringBuilder sb = new StringBuilder();		 
			        int i = 0;
			        String delim = "-";
			        while (i < fieldsList.size() - 1)
			        {
			            sb.append(fieldsList.get(i));
			            sb.append(delim);
			            i++;
			        }
			        sb.append(fieldsList.get(i));
			        String res = sb.toString();
				LogFile.LogWrite("Data Source Controller - INFO 2021 fieldsList IS" +res);
			}else {
				LogFile.LogWrite("Data Source Controller - INFO 2021 fieldsList IS NULL" );
			}
		
			//END

		} else if (source.getDefectTool().equals("ALM")) {
			if (source.getModulename().equals("Defect")) {
				source.setModulename("defects");
			} else {
				source.setModulename("requirements");
			}
			// getFieldURL =source.getUrl() + "/qcbin/api/domains/"+ source.getDomainname()
			// +"/projects/"+ source.getProjectname()
			// +"/"+source.getModulename()+"/$metadata/fields";
			// getFieldURL = source.getUrl() + "/qcbin/rest/domains/" +
			// source.getDomainname() + "/projects/"
			// + source.getProjectname() + "/"+source.getModulename();
			
			String getsubfieldURL = source.getUrl() + "/qcbin/api/domains/" + source.getDomainname() + "/projects/"
					+ source.getProjectname() + "/" + source.getModulename() + "/$metadata/fields";			
			Client_ALM_Modulename=source.getModulename();
			Client_ALM_Domainname=source.getDomainname();
			Client_ALM_Projectname=source.getProjectname();
	
			
			LogFile.LogWrite("Data Source Controller - Get Fields URL #1010 " + "Client_ALM_Modulename :"+Client_ALM_Modulename+"Client_ALM_Domainname :"+Client_ALM_Domainname+"Client_ALM_Projectname :"+Client_ALM_Projectname);											
			LogFile.LogWrite("Data Source Controller - Get Fields URL #1012 " + getsubfieldURL);						
			LogFile.LogWrite("Data Source Controller - the get subfields url isss"+getsubfieldURL);
		    HttpURLConnection connection1 = isValidUser(source);
		    
			String token = generateXSRFTOKEN(connection1);
			
			
			LogFile.LogWrite("Data Source Controller - 34565 the token"+token);
			
			HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();
			try {
				connection.setRequestProperty("Cookie", cookies + lwssoCookie);
				connection.setRequestProperty("X-XSRF-TOKEN", token);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Accept", "application/json");
				connection.setRequestMethod("GET");
				connection.connect();

			}catch(Exception ex) {	
				connection.disconnect();
				LogFile.LogWrite("Data Source Controller - ERROR 25258 the connection"+ex.getMessage());	
				throw ex;
			}
		
			InputStream in = new BufferedInputStream(connection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			fieldsList = new ArrayList<String>();
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}
			
			connection.disconnect();
			if (!lwssoCookie.isEmpty()) {
				lwssoCookie = "";
				cookies = "";
				xsrfHeaderValue = "";
			}
			
			String jsonstring = result.toString();

			String repaceString = jsonstring.replaceAll("\"type\":\"field\",", " ");

			JSONObject mainObject = new JSONObject(repaceString);

			JSONArray dataArrayObject = mainObject.getJSONArray("data");
			 mappingUserdefinedfields_ALM = new HashMap<Object, Object>();
			JSONObject singleObject = new JSONObject();

			for (int i = 0; i < dataArrayObject.length(); i++) {
				JSONObject objects1 = dataArrayObject.getJSONObject(i);
				Set<String> key = objects1.keySet();
				for (String element : key) {

					if (element.equals("name")) {
						singleObject.put("name", objects1.get(element));
					} else if ((element.equals("label"))) {

						fieldsList.add((String) objects1.get(element));
						singleObject.put("label", objects1.get(element));
					}

				}
				Object labelkey = objects1.get("label");
				Object nameValue = objects1.get("name");
				mappingUserdefinedfields_ALM.put(labelkey, nameValue);
			}
			LogFile.LogWrite("Data Source Controller - the mapping fields is " + mappingUserdefinedfields_ALM);
			
		}

		}catch(Exception ex) {
			LogFile.LogWrite("Data Source Controller - Error 2001 " + ex);	
		}
		
		return fieldsList;	

	}

	public JSONObject getJSONObject(String key) throws JSONException, IOException {

		LogFile.LogWrite("Data Source Controller - the key value is" + key);
		Object object = this.get(key);
		LogFile.LogWrite("Data Source Controller - the object value is" + object);
		if (object instanceof JSONObject) {
			return (JSONObject) object;
		} else {
			return null;
		}
	}

	public Object get(String key) throws JSONException, IOException {
		if (key == null) {
			throw new JSONException("Null key.");
		}
		if (key.equals("type")) {
			LogFile.LogWrite("Data Source Controller - duplicate key");
		} else {
			Object object = this.opt(key);
			return object;
		}
		return key;
	}

	public Object opt(String key) throws IOException {
		LogFile.LogWrite("Data Source Controller - the opt key value issss" + key);
		return key == null ? null : this.map.get(key);
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSubFields", method = RequestMethod.GET)
	public List getSubFieldsForME(@RequestParam(name = "fieldName", required = false) String fieldName)
			throws MalformedURLException, IOException, JSONException {

		
		
		String subFieldURL = "http://172.22.6.21:7171/sdpapi/admin/" + fieldName
				+ "/?&AUTHTOKEN=5VJolQMMWirDxvIxHdRTLQ==&format=json";
		HttpURLConnection connection = (HttpURLConnection) new URL(subFieldURL).openConnection();
		
		try {
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestMethod("GET");
			connection.connect();
		}catch(Exception ex) {
			connection.disconnect();
			throw ex;
		}
		
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		
		try {
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}
			connection.disconnect();
		}catch(Exception ex) {
			connection.disconnect();
			throw ex;
		}
		
		
		LogFile.LogWrite("Data Source Controller - the response is <><><" + connection.getResponseMessage());
		String jsonstring = result.toString();
		JSONObject keyObject = new JSONObject(getSubfield_KeyValue_ME);
		String keyvalue = keyObject.getString(fieldName);

		JSONObject mainObject = new JSONObject(jsonstring);
		JSONObject operationObject = mainObject.getJSONObject("operation");
		JSONArray details_array = operationObject.getJSONArray("details");
		List subField = new LinkedList();
		try {

			for (int i = 0; i < details_array.length(); i++) {
				JSONObject objects = details_array.getJSONObject(i);
				subField.add(objects.get(keyvalue));
				//LogFile.LogWrite(objects.get(keyvalue));
			}
		}catch(Exception ex) {
			throw ex;
		}
		
		
		LogFile.LogWrite("Data Source Controller - the subField value is" + subField);
		return subField;

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/isExist_Datasource/", method = RequestMethod.GET)
	public boolean isExistNewDatasource(
			@RequestParam(name = "datasourcename", required = false) String datasourcename) {
		boolean return1 = datasourceservice.findDataSouceName(datasourcename);
		return return1;
	}
	
	public DataSource selectDomanin(String targetdatasource) {
		System.out.println("INFO 3344 targetdatasource"+targetdatasource);
		DataSource source=	datasourceservice.selectDomanin(targetdatasource);		
	//	String DomainIS=source.getDomainname();
		return source;	
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getDataSourcedata", method = RequestMethod.GET)
	public List<DataSource> getAllDataSource() {
		List<DataSource> dataSourceData = datasourceservice.getAllDataSource();
		return dataSourceData;
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/domain/getProject/", method = RequestMethod.GET)
	public List getAllProject(@RequestParam(name = "domainname", required = false) String domainname)
			throws MalformedURLException, IOException {
		String listAllProjectsInDomain =almURL + "/api/domains/" + domainname + "/projects";
		LogFile.LogWrite("/domain/getProject/ - almURL" + almURL);
		HttpURLConnection getProjectsConnection = (HttpURLConnection) new URL(listAllProjectsInDomain).openConnection();
		LogFile.LogWrite("getProject lwssoCookie is" + lwssoCookie);
		LogFile.LogWrite("getProject xsrfHeaderValue is" + xsrfHeaderValue);
		getProjectsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		getProjectsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		// getProjectsConnection.setRequestProperty("Content-Type", "application/json");
		getProjectsConnection.setRequestProperty("Accept", "application/json");
		getProjectsConnection.setRequestMethod("GET");
		getProjectsConnection.connect();
		LogFile.LogWrite("/domain/getProject/ - getProjectsConnection CONNECTED");
		LogFile.LogWrite("/domain/getProject/ - getProjectsConnection.getInputStream()" +getProjectsConnection.getInputStream().toString());
		InputStream in1 = new BufferedInputStream(getProjectsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
		StringBuilder result1 = new StringBuilder();
		String line1;

		try {
			while ((line1 = reader1.readLine()) != null) {
				result1.append(line1);
			}
			
		}catch(Exception ex) {
			LogFile.LogWrite("/domain/getProject/ - getProjectsConnection Exception" +ex.getMessage());
			getProjectsConnection.disconnect();
			throw ex;
		}
		
		getProjectsConnection.disconnect();
		String jsonstring = result1.toString();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		projectData = new LinkedList();
		if (!lwssoCookie.isEmpty()) {
				lwssoCookie = "";
	     			cookies = "";
				xsrfHeaderValue = "";
			}
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			projectData.add(objects.get("name"));
			//LogFile.LogWrite(objects.get("name"));
		}
		// String listAllProjectsInDomain1 = almURL +
		// "/api/domains/"+domainname+"/projects/Jira_Test/customization/entities";
		// HttpURLConnection getProjectsConnection1 = (HttpURLConnection) new
		// URL(listAllProjectsInDomain ).openConnection();
		// getProjectsConnection1.setRequestProperty("Cookie", cookies + lwssoCookie);
		// getProjectsConnection1.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		// //getProjectsConnection.setRequestProperty("Content-Type",
		// "application/json");
		// getProjectsConnection1.setRequestProperty("Accept", "application/json");
		// getProjectsConnection1.setRequestMethod("GET");
		// getProjectsConnection1.connect();
		// InputStream in2 = new
		// BufferedInputStream(getProjectsConnection.getInputStream());
		// BufferedReader reader2 = new BufferedReader(new InputStreamReader(in2));
		// StringBuilder result2 = new StringBuilder();
		// String line2;
		//
		// while ((line2 = reader2.readLine()) != null) {
		// result2.append(line2);
		// }
		// String jsonstring1 = result2.toString();
		// JSONObject jsonobject1 = new JSONObject(jsonstring1);
		// JSONArray jsarray1 = jsonobject1.getJSONArray("results");
		// // JSONObject data=(object)result;
		// List entityData = new LinkedList();
		// for (int i = 0; i < jsarray1.length(); i++) {
		// JSONObject objects = jsarray1.getJSONObject(i);
		// entityData.add(objects.get("name"));
		// LogFile.LogWrite(objects.get("name"));
		// }
		return projectData;
	}

	public HttpURLConnection isValidUser(DataSource authmodal) throws IOException {
	
		almURL = authmodal.getUrl() + "/qcbin";
		String authEndPoint = almURL + "/authentication-point/alm-authenticate";
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		
		try {
			
			authConnection.setRequestMethod("POST");
			authConnection.setRequestProperty("Content-Type", "application/xml");
			authConnection.setDoOutput(true);
			OutputStream os = authConnection.getOutputStream();
			try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
				osw.write("<alm-authentication><user>" + authmodal.getUsername() + "</user><password>"
						+ authmodal.getPassword() + "</password></alm-authentication>");
			}
			authConnection.connect();
			Client_ALM_URL=authmodal.getUrl();
			Client_ALM_USERNAME=authmodal.getUsername();
			Client_ALM_PASSWORD=authmodal.getPassword();
			
		}catch(Exception ex) {
			LogFile.LogWrite("Data Source Controller - Error isValidUser func:"+ex);
			authConnection.disconnect();
			
		}	
		
		return authConnection;
	}

	public String generateXSRFTOKEN(HttpURLConnection authConnection) throws MalformedURLException, IOException {
		String qcSessionEndPoint = almURL + "/rest/site-session";
		lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Data Source Controller - the lwss cokkies" + lwssoCookie);
		/* create session begin */
		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		xsrfHeaderValue = "";

		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}
		LogFile.LogWrite("Data Source Controller - the header value is" + xsrfHeaderValue);
		createSession.disconnect();;
		return xsrfHeaderValue;
	}

	public void getAllDomain(String token) throws MalformedURLException, IOException {
		String listAllDomainURL = almURL + "/api/domains";
		HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllDomainURL).openConnection();
		createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession1.setRequestProperty("X-XSRF-TOKEN", token);
		createSession1.setRequestProperty("Content-Type", "application/json");
		createSession1.setRequestProperty("Accept", "application/json");
		createSession1.setRequestMethod("GET");
		createSession1.connect();
		InputStream in = new BufferedInputStream(createSession1.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		createSession1.disconnect();
		// Updated By Mubarak Ali M
		if (!lwssoCookie.isEmpty()) {
		//	lwssoCookie = "";
     	//		cookies = "";
		//	xsrfHeaderValue = "";
		}
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String jsonstring = result.toString();
		domaindata = new LinkedList();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			domaindata.add(objects.get("name"));
		}
	}
	public List<String> getAllProjects(String token,String domainname) throws MalformedURLException, IOException {
		String listAllProjectsInDomain =almURL + "/api/domains/" + domainname + "/projects";
		HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllProjectsInDomain).openConnection();
		createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession1.setRequestProperty("X-XSRF-TOKEN", token);
		createSession1.setRequestProperty("Content-Type", "application/json");
		createSession1.setRequestProperty("Accept", "application/json");
		createSession1.setRequestMethod("GET");
		createSession1.connect();
		InputStream in = new BufferedInputStream(createSession1.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		createSession1.disconnect();
		if (!lwssoCookie.isEmpty()) {
			lwssoCookie = "";
			cookies = "";
			xsrfHeaderValue = "";
		}
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String jsonstring = result.toString();
		projectData = new LinkedList();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			domaindata.add(objects.get("name"));
		}
		return projectData;
	}
	
	

	public Map<Object, Object> getALMFields(DataSource source) throws IOException, InterruptedException {
		
		
		try 
		{

			LogFile.LogWrite("Data Source Controller - the data source name is"+source);
			
			try {

				//source.getModulename()
				//LogFile.LogWrite("Data Source Controller - source.getModulename() #1011   :" + source.getModulename());
				if (source.getModulename().equalsIgnoreCase("Defects")|| source.getModulename().equalsIgnoreCase("Defect")) { // Changed 
					source.setModulename("defects");
				} else {
					source.setModulename("requirements");
				}
				
			}catch(Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1212 getALMFields  "+ex.getMessage());
			}
			
			
			
			
			// getFieldURL =source.getUrl() + "/qcbin/api/domains/"+ source.getDomainname()
			// +"/projects/"+ source.getProjectname()
			// +"/"+source.getModulename()+"/$metadata/fields";
			// getFieldURL = source.getUrl() + "/qcbin/rest/domains/" +
			// source.getDomainname() + "/projects/"
			// + source.getProjectname() + "/"+source.getModulename();
			List<String> fieldsList = new ArrayList<String>();
			String getsubfieldURL = source.getUrl() + "/qcbin/api/domains/" + source.getDomainname() + "/projects/"
					+ source.getProjectname() + "/" + source.getModulename() + "/$metadata/fields";
			
			// http://172.22.6.7:8080/qcbin/api/domains/AVLINO/projects/Jira_Test/requirements/$metadata/fields
			Client_ALM_Modulename=source.getModulename();
			Client_ALM_Domainname=source.getDomainname();
			Client_ALM_Projectname=source.getProjectname();
			
			LogFile.LogWrite("Data Source Controller - Get Fields URL #1013 " + "Client_ALM_Modulename :  "+Client_ALM_Modulename+"Client_ALM_Domainname    :"+Client_ALM_Domainname+"Client_ALM_Projectname     :"+Client_ALM_Projectname);
			LogFile.LogWrite("Data Source Controller - getsubfieldURL #1011   :" + getsubfieldURL);
			
		    HttpURLConnection connection1 = isValidUser(source);
		    LogFile.LogWrite("Data Source Controller - getsubfieldURL #7878   connection1 :" + connection1);
		    
			String token = generateXSRFTOKEN(connection1);
			LogFile.LogWrite("Data Source Controller - getsubfieldURL #7878  token :" + token);
			HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();
			
			
           try {
        	connection.setRequestProperty("Cookie", cookies + lwssoCookie);
   			connection.setRequestProperty("X-XSRF-TOKEN", token);
   			connection.setRequestProperty("Content-Type", "application/json");
   			connection.setRequestProperty("Accept", "application/json");
   			connection.setRequestMethod("GET");
   			connection.connect();
   		
 
			}catch(Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1213 getALMFields CONNECT "+ex.getMessage());
				connection.disconnect();
		   		
				throw ex;
			}
			
			
			InputStream in = new BufferedInputStream(connection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			fieldsList = new ArrayList<String>();
			try {
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}
				connection.disconnect();
				
				
				
			}catch(Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1215 getALMFields CONNECT "+ex.getMessage());
				connection.disconnect();
				ALMRe_authConnection();// RE AUTHENTICATION
				throw ex;
			}
			
			
			String jsonstring = result.toString();

			String repaceString = jsonstring.replaceAll("\"type\":\"field\",", " ");

			JSONObject mainObject = new JSONObject(repaceString);

			JSONArray dataArrayObject = mainObject.getJSONArray("data");
			 mappingUserdefinedfields_ALM = new HashMap<Object, Object>();
			JSONObject singleObject = new JSONObject();

			for (int i = 0; i < dataArrayObject.length(); i++) {
				
				try {

					JSONObject objects1 = dataArrayObject.getJSONObject(i);
					Set<String> key = objects1.keySet();
					for (String element : key) {

						if (element.equals("name")) {
							singleObject.put("name", objects1.get(element));
						} else if ((element.equals("label"))) {

							fieldsList.add((String) objects1.get(element));
							singleObject.put("label", objects1.get(element));
						}

					}
					Object labelkey = objects1.get("label");
					Object nameValue = objects1.get("name");
					
					try {
						mappingUserdefinedfields_ALM.put(labelkey, nameValue);
						
					}catch(Exception ex) {
						LogFile.LogWrite("Data Source Controller - ERROR #1215 mappingUserdefinedfields_ALM PUT:  "+ex.getMessage());
						ALMRe_authConnection();// RE AUTHENTICATION
						throw ex;
					}	
				}catch(Exception ex) {
					LogFile.LogWrite("Data Source Controller - ERROR #1214 dataArrayObject FORLOOP:  "+ex.getMessage());
					ALMRe_authConnection();// RE AUTHENTICATION
					throw ex;
				}
		
			}
			LogFile.LogWrite("Data Source Controller - the mapping fields is " + mappingUserdefinedfields_ALM);
			
		}catch(Exception ex) {
			
			LogFile.LogWrite("Data Source Controller - ERROR #1215 mapping fields is " + mappingUserdefinedfields_ALM);
			
			LogFile.LogWrite("Data Source Controller - ERROR #1216 " + ex.getMessage());
			ALMRe_authConnection();// RE AUTHENTICATION
			throw ex;
		}

	return mappingUserdefinedfields_ALM;
}
		
		//
		// String almURL = "http://172.22.6.7:8080/qcbin/";
		// String authEndPoint = almURL + "authentication-point/alm-authenticate";
		// String qcSessionEndPoint = almURL + "rest/site-session";
		// /* authenticate begin */
		// URL authUrl = new URL(authEndPoint);
		// HttpURLConnection authConnection = (HttpURLConnection)
		// authUrl.openConnection();
		// authConnection.setRequestMethod("POST");
		// authConnection.setRequestProperty("Content-Type", "application/xml");
		// authConnection.setDoOutput(true);
		// OutputStream os = authConnection.getOutputStream();
		// try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
		// osw.write(
		// "<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");
		// }
		// authConnection.connect();
		//
		// LogFile.LogWrite(authConnection.getResponseMessage());
		// String lwssoCookie =
		// authConnection.getHeaderField("Set-Cookie").split(";")[0];
		// LogFile.LogWrite("Data Source Controller - the lwssscookiess " + lwssoCookie);
		// /* authenticate end */
		// /* create session begin */
		//
		// HttpURLConnection createSession = (HttpURLConnection) new
		// URL(qcSessionEndPoint).openConnection();
		// createSession.setRequestProperty("Cookie", lwssoCookie);
		// // createSession.setRequestProperty("Content-Type", "application/json");
		// createSession.setRequestMethod("POST");
		// createSession.connect();
		// Map<String, List<String>> values = createSession.getHeaderFields();
		// String xsrfHeaderValue = "";
		// String cookies = "";
		// for (String cookie : values.get("Set-Cookie")) {
		// String content = cookie.split(";")[0];
		// cookies = cookies + content + ";";
		// LogFile.LogWrite("Data Source Controller - the coookies value isss" + cookies);
		// String[] nameValue = content.split("=");
		// String name = nameValue[0];
		// String value = nameValue[1];
		// if (name.equalsIgnoreCase("XSRF-TOKEN")) {
		// xsrfHeaderValue = value;
		// }
		// }
		//
		// String getsubfieldURL=
		// "http://172.22.6.7:8080/qcbin/api/domains/AVLINO/projects/Jira_Test/defects/$metadata/fields";
		// LogFile.LogWrite("Data Source Controller - the system id is"+getsubfieldURL);
		//
		// HttpURLConnection connection = (HttpURLConnection) new
		// URL(getsubfieldURL).openConnection();
		// connection.setRequestProperty("Cookie", cookies + lwssoCookie);
		// connection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		// connection.setRequestProperty("Content-Type", "application/json");
		// connection.setRequestProperty("Accept", "application/json");
		// connection.setRequestMethod("GET");
		// connection.connect();
		//
		// InputStream in = new BufferedInputStream(connection.getInputStream());
		// BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		// StringBuilder result = new StringBuilder();
		// String line;
		// //fieldsList = new ArrayList<String>();
		// while ((line = reader.readLine()) != null) {
		// result.append(line);
		// }
		//
		// String jsonstring = result.toString();
		// LogFile.LogWrite("Data Source Controller - the json string

		// baseMEURl =
		// "http://172.22.6.21:7171/sdpapi/auth?username=suresh.a&password=Welcome@123&format=json";
		// HttpURLConnection authConnection = (HttpURLConnection) new
		// URL(baseMEURl).openConnection();
		// authConnection.setRequestProperty("Accept", "application/json");
		// authConnection.setRequestMethod("GET");
		// authConnection.setDoOutput(true);
		// authConnection.connect();
		//
		// LogFile.LogWrite("Data Source Controller - the auth conenection response request
		// headerrrr"+authConnection.getHeaderFields());
		//
		// Map<String, List<String>> values = authConnection.getHeaderFields();
		// String sdpcsrfcookie = "";
		// String SDPSESSIONID="";
		// String cookies = "";
		// for (String cookie : values.get("Set-Cookie")) {
		// String content = cookie.split(";")[0];
		// cookies = cookies + content + ";";
		// LogFile.LogWrite("Data Source Controller - the coookies value isss" + cookies);
		// String[] nameValue = content.split("=");
		// String name = nameValue[0];
		// String value = nameValue[1];
		// LogFile.LogWrite("Data Source Controller - the auth conenection name "+name);
		// LogFile.LogWrite("Data Source Controller - the auth conenection value"+value);
		// if(name.equalsIgnoreCase("sdpcsrfcookie")) {
		// sdpcsrfcookie=value;
		//
		// }
		// else if(name.equalsIgnoreCase("SDPSESSIONID")) {
		// SDPSESSIONID=value;
		// }
		// }

//		String baseMEURl = "http://172.22.6.21:7171/api/v3/attachment/26702?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417";
//		LogFile.LogWrite("Data Source Controller - the url is<><><" + baseMEURl);
//		HttpURLConnection httpUrlConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
//		// authConnection.setRequestProperty("Accept", "application/force-download");
//		// authConnection.setRequestProperty("TECHNICIAN_KEY",
//		// "3E77F07C-97F9-4188-B730-AEFD343A6927");
//		// authConnection.setRequestProperty("format", "json");
//
//		// authConnection.setRequestProperty("Accept", "*/*");
//		// authConnection.setRequestProperty("Accept-Encoding", "gzip, deflate");
//		// authConnection.setRequestProperty("Accept-Language",
//		// "en-GB,en-US;q=0.9,en;q=0.8");
//		// authConnection.setRequestProperty("Connection", "keep-alive");
//		//
//		// authConnection.setRequestProperty("tm", "1651149399172");
//		// authConnection.setRequestMethod("GET");
//
//		httpUrlConnection.setRequestProperty("Accept", "*/*");
//		// httpUrlConnection.setRequestProperty("Accept-Encoding", "gzip,deflate");
//		// httpUrlConnection.setRequestProperty("Accept-Language",
//		// "en-GB,en-US;q=0.9,en;q=0.8");
//		// httpUrlConnection.setRequestProperty("Connection", "keep-alive");
//		// httpUrlConnection.setRequestProperty("Cookie",
//		// cookies);
//		// httpUrlConnection.setRequestProperty("Host", "172.22.6.21:7171");
//		// // httpUrlConnection.setRequestProperty("Referer",
//		// "http://172.22.6.21:7171/html/APICall.html");
//
//		LogFile.LogWrite("Data Source Controller - the cookies valueeee" + cookies);
//		// httpUrlConnection.setRequestProperty("User-Agent",
//		// "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like
//		// Gecko) Chrome/100.0.4896.127 Safari/537.36");
//
//		httpUrlConnection.connect();
//		LogFile.LogWrite("Data Source Controller - the response data is" + httpUrlConnection.getRequestMethod());
//
//		LogFile.LogWrite("Data Source Controller - the response data is" + httpUrlConnection.getResponseCode());
//		LogFile.LogWrite("Data Source Controller - the response data is" + httpUrlConnection.getHeaderFields());
//		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpUrlConnection.getInputStream()));
//
//		String line = null;
//		String XMLFile = new String();
//		while (bufferedReader.readLine() != null) {
//			line = bufferedReader.readLine();
//
//			XMLFile += line;
//		}
//
//		LogFile.LogWrite("Data Source Controller - the response data is <>< xml file data is" + XMLFile);
//
//		String fileName = "108012.csv";
//		// Path file = Paths.(XMLFile);
//		byte[] bFile = XMLFile.getBytes();
//
//		String almURL = "http://172.22.6.7:8080/qcbin/";
//		String authEndPoint = almURL + "authentication-point/alm-authenticate";
//		String qcSessionEndPoint = almURL + "rest/site-session";
//		/* authenticate begin */
//		URL authUrl = new URL(authEndPoint);
//		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
//		authConnection.setRequestMethod("POST");
//		authConnection.setRequestProperty("Content-Type", "application/xml");
//		authConnection.setDoOutput(true);
//		OutputStream os = authConnection.getOutputStream();
//		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
//			osw.write(
//					"<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");
//		}
//		authConnection.connect();
//
//		LogFile.LogWrite(authConnection.getResponseMessage());
//		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
//		LogFile.LogWrite("Data Source Controller - the lwssscookiess " + lwssoCookie);
//		/* authenticate end */
//		/* create session begin */
//
//		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
//		createSession.setRequestProperty("Cookie", lwssoCookie);
//		// createSession.setRequestProperty("Content-Type", "application/json");
//		createSession.setRequestMethod("POST");
//		createSession.connect();
//		Map<String, List<String>> values = createSession.getHeaderFields();
//		String xsrfHeaderValue = "";
//		String cookies = "";
//		for (String cookie : values.get("Set-Cookie")) {
//			String content = cookie.split(";")[0];
//			cookies = cookies + content + ";";
//			LogFile.LogWrite("Data Source Controller - the coookies value isss" + cookies);
//			String[] nameValue = content.split("=");
//			String name = nameValue[0];
//			String value = nameValue[1];
//			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
//				xsrfHeaderValue = value;
//			}
//		}
//
//		// LogFile.LogWrite("Data Source Controller - file name: "+file);
//		String updateurl = "http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/60";
//		HttpURLConnection createDefectAttach = (HttpURLConnection) new URL(updateurl).openConnection();
//				//"http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/60/attachments")
//						//.openConnection(updateurl);
//
//		createDefectAttach.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
//		createDefectAttach.setRequestProperty("Cookie", cookies + lwssoCookie);
//		createDefectAttach.setRequestProperty("Content-Type", "application/octet-stream");
//		createDefectAttach.setRequestProperty("slug", fileName);
//		createDefectAttach.setRequestProperty("Content-Disposition", "attachment;filename=" + fileName);
//
//		// createDefect.setRequestMethod("POST");
//		createDefectAttach.setDoOutput(true);
//		createDefectAttach.setDoInput(true);
//
//		createDefectAttach.connect();
//
//		OutputStream out = createDefectAttach.getOutputStream();
//		out.write(bFile);
//		out.flush();
//		out.close();
//		LogFile.LogWrite(createDefectAttach.getResponseMessage());

	
	@CrossOrigin(origins = "*", allowedHeaders = "*")                          
	@RequestMapping(value = "/getDefectstatusINALM/", method = RequestMethod.GET)
	public List<String> getstatusvalue(
			@RequestParam(name = "dataSourcename", required = false) String datasourcename,
	        @RequestParam(name = "fieldName", required = false) String fieldName) throws IOException {
		String FieldNametemp="";
		fieldName=fieldName.trim();
		if(fieldName.equals("Status")) {
			FieldNametemp="Bug Status";
		}else if(fieldName.equals("Severity")) {
			FieldNametemp="Severity";
		}else {
		}
		
		LogFile.LogWrite("Data Source Controller - fieldName ** is" +fieldName);
		
		
		List defectStatusValue=new LinkedList();
		LogFile.LogWrite("Data Source Controller - the target data source is"+datasourcename);
		DataSource source = datasourceservice.getDataSource(datasourcename);
		String getsubfieldURL = "http://172.22.6.7:8080/qcbin/rest/domains/"+source.getDomainname()+"/projects/"+source.getProjectname()+"/customization/entities/defect/lists";
		// String getsubfieldURL=
		// "http://172.22.6.7:8080/qcbin/rest/domains/INTERTEK/projects/Evo2_Prod_Support/customization/entities/defect/lists";
		//
		// String getsubfieldURL=
		// "http://172.22.6.7:8080/qcbin/api/domains/AVLINO/projects/Jira_Test/defects/$metadata/fields";

		HttpURLConnection connection1 = isValidUser(source);
		String token = generateXSRFTOKEN(connection1);
		HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();
		connection.setRequestProperty("Cookie", cookies + lwssoCookie);
		connection.setRequestProperty("X-XSRF-TOKEN", token);
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		
		
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}
			
		}catch(Exception ex) {
			LogFile.LogWrite("Data Source Controller - ERROR 25856 the  string builder is" + result.toString());
			connection.disconnect();
			throw ex;
		}
		
		connection.disconnect();
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String retrunstring = result.toString();
		JSONObject listobject = new JSONObject(retrunstring);
		JSONArray listarrayObject = listobject.getJSONArray("lists");
		LogFile.LogWrite("Data Source Controller - listarrayObject ******  "+listarrayObject.toString());
		for(int i=0;i<listarrayObject.length();i++) {
			
			JSONObject nameObject = listarrayObject.getJSONObject(i);
			
			
			
			
			if(nameObject.getString("Name").equals(FieldNametemp)) {
				
				JSONArray itemsarrayobject = nameObject.getJSONArray("Items");
				
				for(int j=0;j<itemsarrayobject.length();j++) {
					
					JSONObject valueobject = itemsarrayobject.getJSONObject(j);
					
					defectStatusValue.add(valueobject.get("value"));
					
				}
			}
		}
		LogFile.LogWrite("Data Source Controller - the list value is"+defectStatusValue);
		return defectStatusValue;
	}

	
	
	

}
