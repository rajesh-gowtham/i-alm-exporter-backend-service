package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.Users;

public interface UserServices {
	public Users logins(String username,String password);
	
	public Users GetMeKey(String username);
	
	public void deleteUser (String username);
	
	public void savenewUser(String username,String password,String email,String Me_Key);
	
	public void updateuserdetails(String username,String password,String email);
	
	public List<Users> getAllUsers();

//	public Users getMeKey(String key);
}
