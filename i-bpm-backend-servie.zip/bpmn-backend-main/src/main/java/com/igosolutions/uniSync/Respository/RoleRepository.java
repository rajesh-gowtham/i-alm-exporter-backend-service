package com.igosolutions.uniSync.Respository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.igosolutions.uniSync.Modal.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
   @Transactional
   @Query("select s from Role s where s.roleName = :roleName")
   Role findByRole(String roleName);

}
