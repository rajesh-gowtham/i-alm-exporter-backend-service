package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "ibpmn_user")
public class BpmnUser {

 
	public BpmnUser() {
		super();
	}
	
	 public BpmnUser(Long userid, String organization, String firstname, String lastname, String email, String mobileno, String role, String password, String imgname, String imgcontent) {
	        this.userid = userid;
	        this.organization = organization;
	        this.firstname = firstname;
	        this.lastname = lastname;
	        this.email = email;
	        this.mobileno = mobileno;
	        this.role = role;
	        this.password = password;
	        this.imgname = imgname;
	        this.imgcontent = imgcontent;
	    }
	 
	public BpmnUser(Long userid, String firstname, String lastname, String email, String role, String mobileno, String imgname, String imgcontent, String organization) {
	    this.userid = userid;
	    this.firstname = firstname;
	    this.lastname = lastname;
	    this.email = email;
	    this.role = role;
	    this.mobileno = mobileno;
	    this.imgname = imgname;
	    this.imgcontent = imgcontent;
	    this.organization = organization;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long userid;
    private String firstname;
    private String lastname;
    private String email;
    private String role;
    private String mobileno;
    private String password;
    private String organization;
    @Column(name = "reset_token")
    private String resettoken;
    private String imgname;
    private String imgcontent;
    private String accesstoken;
    private String timestamp;
    public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getAccesstoken() {
		return accesstoken;
	}

	public void setAccesstoken(String accesstoken) {
		this.accesstoken = accesstoken;
	}

	public String getImgname() {
		return imgname;
	}
	public void setImgname(String imgname) {
		this.imgname = imgname;
	}
	public String getImgcontent() {
		return imgcontent;
	}
	public void setImgcontent(String imgcontent) {
		this.imgcontent = imgcontent;
	}

	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
   
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getResettoken() {
		return resettoken;
	}

	public void setResettoken(String resettoken) {
		this.resettoken = resettoken;
	}

	@Override
	public String toString() {
		return "BpmnUser [userid=" + userid + ", firstname=" + firstname + ", lastname=" + lastname + ", email=" + email
				+ ", role=" + role + ", mobileno=" + mobileno + ", password=" + password + ", organization="
				+ organization + ", resettoken=" + resettoken + ", imgname=" + imgname + ", imgcontent=" + imgcontent
				+ ", accesstoken=" + accesstoken + ", timestamp=" + timestamp + "]";
	}

}
