package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Connection;


public interface ConnectionRepository extends JpaRepository<Connection, Long> {
	///Added By Mubarak
	@Transactional
	@Modifying
	@Query("UPDATE Connection SET onoff=:status ,switchfalg = :switchfalge, switchontime = :time  WHERE connectionName =:connectionName")
    void connectionONstatus(String connectionName, String status,String switchfalge,String time);
	
	@Transactional
	@Modifying
	@Query("UPDATE Connection SET  connectionCreationDate = :time  WHERE connectionName =:connectionName")
    void updateConnectionCreateTime(String connectionName,String time);
	
	
	@Transactional
	@Modifying
	@Query("UPDATE Connection SET  switchfalg = :flag  WHERE connectionName =:connectionName")
    void updateConnectionswitchflag(String connectionName,String flag);
	
	
	@Transactional
	@Modifying
	@Query("UPDATE Connection SET mappingField=:MappingField,masterCondition=:MasterCondition,userDefinevalues=:UserDefinevalues,connectionUpdateDate=:Updatetime  WHERE connectionName =:connectionName")
    void updateConnection(String connectionName, String MappingField,String MasterCondition,String UserDefinevalues,String Updatetime);
	
	
	@Transactional
	@Modifying
	@Query("UPDATE Connection SET onoff=:status ,switchfalg = :switchfalge, switchofftime = :time  WHERE connectionName =:connectionName")
    void connectionOFFstatus(String connectionName, String status,String switchfalge,String time);
	//END

	@Transactional
	@Modifying
	@Query("UPDATE Connection SET connectionstatus=:status  WHERE connectionName =:connectionName")
    void updateConnectionStatus(String connectionName, String status);
	
	@Transactional
	@Modifying
	@Query("delete from Connection  WHERE connectionName= :connectionName")
	void deleteByConnection(String connectionName);

	
	
	
	
	@Transactional
	//@Query("Select sm from  sm where sm.ONOFF=:ISON")
	@Query("SELECT connectionName FROM Connection")
	List<Connection> getConnectionName(); 
	
	@Transactional
	//@Query("Select sm from  sm where sm.ONOFF=:ISON")
	@Query("SELECT u FROM Connection u WHERE u.onoff= :ISON")
	List<Connection> getAllConnectionDataoff(String ISON); 

}
