package com.igosolutions.uniSync.Service;

import java.sql.SQLException;
import java.util.List;

public interface ALMDataBaseService {

	public void getUpdatetimeRecords();
	
	public List getAMLRecordsByALMIDs(List<Object> almIDs,String databasename,String domainname, String targetProjectname) throws ClassNotFoundException, SQLException;
}
