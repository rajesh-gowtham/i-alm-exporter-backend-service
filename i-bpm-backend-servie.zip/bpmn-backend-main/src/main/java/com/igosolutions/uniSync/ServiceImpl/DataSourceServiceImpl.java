package com.igosolutions.uniSync.ServiceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Respository.DataSourceRepository;
import com.igosolutions.uniSync.Service.DataSourceService;

@Service
public class DataSourceServiceImpl implements DataSourceService {

	@Autowired
	public DataSourceRepository repo;

	

	@Override
	public void saveDataSource(DataSource datasource) {
		repo.save(datasource);
	}

	@Override
	public List<DataSource> getAllDataSource() {

		List<DataSource> dataSourceData = (List<DataSource>) repo.findAll();
		System.out.println("the data source data items isssss" + dataSourceData);
		return dataSourceData;
	}

	@Override
	public boolean findDataSouceName(String datasourcename) {
		DataSource source = repo.existsByDatasourcename(datasourcename);
		if (source == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public DataSource getDataSource(String datasourcename) {
		DataSource source = repo.existsByDatasourcename(datasourcename);
		System.out.println("the source name is" + source);
		return source;
	}

	@Override
	public void updateDataSource(DataSource datasource) {
		
		DataSource source =repo.findByDatasourcename(datasource.getDatasourcename());
		repo.save(source);
	}
	
	@Override
	public DataSource selectDomanin(String targetdatasource) {
		System.out.println("INFO 3344 targetdatasource"+targetdatasource);
		DataSource source=	repo.selectDomanin(targetdatasource);
		return source;
	}
	
	
	@Override
	@Transactional
	public void deleteDataSource(String datasourcename) {
		
		repo.deleteByDataSource(datasourcename);
	}

}
