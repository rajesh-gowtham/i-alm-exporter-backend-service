package com.igosolutions.uniSync.controller;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.openqa.selenium.By;  //commanded By Mubarak 15-11-2022
//import org.openqa.selenium.WebDriver; //commanded By Mubarak 15-11-2022
//import org.openqa.selenium.chrome.ChromeDriver; //commanded By Mubarak 15-11-2022
// Added By Mubarak 15-11-2022
import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.WebDriver; //commanded By Mubarak 15-11-2022
//import org.openqa.selenium.chrome.ChromeDriver;  //commanded By Mubarak 15-11-2022
import org.openqa.selenium.support.ui.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.Gson;
import com.igosolutions.uniSync.Modal.Connection;
import com.igosolutions.uniSync.Modal.ConnectionAudits;
import com.igosolutions.uniSync.Modal.Connectionsyncdata;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Service.ConnectionService;
import com.igosolutions.uniSync.Service.DataSourceService;
import com.igosolutions.uniSync.ServiceImpl.ALMDataBaseServiceImpl;
import com.igosolutions.uniSync.ServiceImpl.ConnectionAuditServiceImpl;
import com.igosolutions.uniSync.ServiceImpl.ConnectionsyncdataServiceImpl;;

@RestController
// @CrossOrigin(origins = "http://172:22.6.21:7575/")
// @CrossOrigin(origins = "http://localhost:7676/")
public class ConnectionController extends Thread{

	public String almURL;
	public static String almUserName;
	public static String almPassword;
	public String lwssoCookie = "";
	public String cookies;
	public String xsrfHeaderValue = "";
	public String qcSession = "";
	public String almUser = "";
	public boolean Error_Sync = false;
	@Autowired
	private DataSourceService service;
	@Autowired
	private ConnectionService connservice;
	@Autowired
	private DataSourceController dscontrooler;
	@Autowired
	private ALMDataBaseServiceImpl almdatabaseImpl;
	@Autowired
	private ConnectionAuditServiceImpl connauditsImpl;
	@Autowired
	private ConnectionsyncdataServiceImpl connectionsyncdataServiceImpl;
	@Autowired
	private ConnectionsyncdataServiceImpl userrepo;

	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/updateConnection", method = RequestMethod.POST)
	public ResponseEntity<Object> UpdateConnection(@RequestBody Connection connModal) throws IOException {
		try {

			LogFile.LogWrite("Connection Controller - the UpdateConnection modal data is" + connModal);
			DataSource masterDatasource = service.getDataSource(connModal.getMasterdatasource());

			DataSource targetDatasource = service.getDataSource(connModal.getTargetdatasource());

			LogFile.LogWrite("Connection Controller - targetDatasource  = " + targetDatasource);

			connservice.UpdateConnection(connModal);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			LogFile.LogWrite("Connection Controller - ERROR #30332 UpdateConnection internal Server Error");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/saveConnection", method = RequestMethod.POST)
	public ResponseEntity<Object> saveConnection(@RequestBody Connection connModal) throws IOException {
		try {

			LogFile.LogWrite("Connection Controller - the connection modal data is" + connModal);
			DataSource masterDatasource = service.getDataSource(connModal.getMasterdatasource());

			DataSource targetDatasource = service.getDataSource(connModal.getTargetdatasource());

			LogFile.LogWrite("Connection Controller - targetDatasource  = " + targetDatasource);

			connservice.saveConnection(connModal);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			LogFile.LogWrite("Connection Controller - ERROR #30332 internal Server Error");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/connectionONstatus", method = RequestMethod.PUT)
	public ResponseEntity<Object> connectionONstatus(
			@RequestParam(name = "connectionName", required = false) String connectionName,
			@RequestParam(name = "connectionStatus", required = false) String status) throws IOException {
		try {

			String switchfalg = null;
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			// dtf.format(now);
			String Time = dtf.format(now).toString();

			if (status.toUpperCase().equals("ON")) {
				switchfalg = "YES";
				// Current Time
				connservice.connectionONstatus(connectionName, status.toUpperCase(), switchfalg, Time);
				LogFile.LogWrite("INFO #3020 update connectionONstatus : " + connectionName + "status :"
						+ status.toUpperCase() + " " + switchfalg + " " + Time);
			} else if (status.toUpperCase().equals("OFF")) {
				switchfalg = "NO";
				// Current Time

				connservice.connectionOFFstatus(connectionName, status.toUpperCase(), switchfalg, Time);
				LogFile.LogWrite("INFO #3020 update connectionONstatus : " + connectionName + "status :"
						+ status.toUpperCase() + " " + switchfalg + " " + Time);
			}

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			LogFile.LogWrite("Connection Controller - Error # 3020 connectionName : " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/deleteSelectedConnection", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteConnection(
			@RequestParam(name = "connectionName", required = false) String connectionName) throws IOException {
		try {
			connservice.deleteConnection(connectionName);
			LogFile.LogWrite("Connection Controller - Delete connectionName : " + connectionName);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			LogFile.LogWrite("Connection Controller - ERROR  internal Server Error");
			LogFile.LogWrite("Connection Controller - Error # 2020 connectionName : " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getConnectionName", method = RequestMethod.GET)
	public List<Connection> getConnectionName() throws IOException {
		List<Connection> connectiondata = connservice.getConnectionName();
	return connectiondata;
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getConnectionData", method = RequestMethod.GET)
	public List<Connection> getConnectionData() throws IOException {

		List<Connection> connectiondata = connservice.getAllConnectionData();
		String delim = "-";
		if (connectiondata.size() > 0) {
			StringBuilder sb = new StringBuilder();

			int i = 0;
			while (i < connectiondata.size() - 1) {
				sb.append(connectiondata.get(i));
				sb.append(delim);
				i++;
			}
			sb.append(connectiondata.get(i));

			String res = sb.toString();
			LogFile.LogWrite("Connection Controller - INFO #5252  ALL Connection IS :" + res);
		} else {

			LogFile.LogWrite("Connection Controller - INFO #5252  ALL Connection IS :" + " Null");
		}

		return connectiondata;
	}


	
	//ALM TO ME
	// @Scheduled(fixedRate = 60000)
//	@Scheduled(fixedRate = 30000)
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBackWardSync", method = RequestMethod.GET)
	public String doBackWardSync() throws MalformedURLException, IOException, ClassNotFoundException, SQLException,
			TransformerException, ParserConfigurationException, ParseException, InterruptedException {
				
		System.out.println("********************************  getBackWardSync");
//		 UserProfileSettingController objmekey = new UserProfileSettingController();
//		 String Admin_MEKEY= objmekey.GetMeKey();
//		 LogFile.LogWrite("Connection Controller - INFO #4242  Admin_MEKEY  :" + Admin_MEKEY);

		List<Connection> listConnectionData = connservice.getAllConnectionDataoff("ON");
		// List<Connection> listConnectionData = connservice.getAllConnectionData();
		// connectionsyncdataServiceImpl.deleteAllConnectionsyncdata();
		LogFile.LogWrite("Connection Controller - INFO #4242  ON Connection DATA  :" + listConnectionData);
		for (int connectiondataIntiallization = 0; connectiondataIntiallization < listConnectionData
				.size(); connectiondataIntiallization++) {

			Connection conndata = listConnectionData.get(connectiondataIntiallization);
			
			
			
			updateConnectionStatus(conndata, "ACTIVE");
			DataSource masterDatasource = service.getDataSource(conndata.getMasterdatasource());
			DataSource targetDatasource = service.getDataSource(conndata.getTargetdatasource());

			String masterProjectName = conndata.getMasterprojectname();

			//
			
			String connectioncondition = conndata.getMasterCondition();
			LogFile.LogWrite("Connection Controller - connectioncondition 25256 :" + connectioncondition);
			LogFile.LogWrite("Connection Controller - the connectioncondition iss<><>" + connectioncondition);
			JSONObject obj = new JSONObject(connectioncondition);
			LogFile.LogWrite("Connection Controller - the 15156 obj iss<><>" + obj);
			JSONArray conditonarray = obj.getJSONArray("masterCondition");
			String querycondition = "";

			for (int conditionarrayIni = 0; conditionarrayIni < conditonarray.length(); conditionarrayIni++) {

				JSONObject conditionobject = conditonarray.getJSONObject(conditionarrayIni);

				String label = (String) conditionobject.get("MasterField");
				String conditonvalue = (String) conditionobject.get("MasterValue");

				String columnName = getFieldName(label);
				String fieldname = "";
				if (!columnName.isEmpty()) {

					fieldname = columnName;
					fieldname = "wf." + fieldname;
				} else {
					fieldname = label;
					fieldname = "wo." + fieldname;
				}
				querycondition = querycondition + fieldname + "='" + conditonvalue + "' and ";

			}

			String condition = querycondition + "acc.ORG_NAME ='" + conndata.getMasterprojectname()
					+ "' and wf.UDF_CHAR2 is not null";

			LogFile.LogWrite("Connection Controller 25256 - condition " + condition);
			List<?> getMErecords = getMEUpdatedRecords(masterProjectName, condition);
			//
			LogFile.LogWrite("Connection Controller - masterProjectName 25256 :" + masterProjectName);
			LogFile.LogWrite("Connection Controller - getMErecords 25256 :" + getMErecords);
			 
			
			// List getMErecords = getMEUpdatedRecords(masterProjectName);
			String domainname = targetDatasource.getDomainname();
			String targetProjectname = targetDatasource.getProjectname();
			String databasename = "";
			
			
			if (domainname.equals("Intertek")) {

				databasename = domainname + "_" + targetProjectname + "_" + "db0";
				databasename.toLowerCase();
			} else {
				databasename = domainname + "_" + targetProjectname + "_" + "db";
				databasename.toLowerCase();
			}

			List<Object> listAlmIDs = new ArrayList<Object>();

		

			for (int i = 0; i < getMErecords.size(); i++) {
				Gson gson = new Gson();
				String json = gson.toJson(getMErecords.get(i));
				JSONObject objects = new JSONObject(json);

				listAlmIDs.add(objects.get("ALM_ID"));
			}
			LogFile.LogWrite("Connection Controller - 2210 listAlmIDs : " + listAlmIDs);
			List<Connectionsyncdata> listconnectionsyncdatas = almdatabaseImpl.getAMLRecordsByALMIDs(listAlmIDs,
					databasename,domainname,targetProjectname);
			
	
			if (listconnectionsyncdatas.size() > 0) {

				
				
				for (int i = 0; i < listconnectionsyncdatas.size(); i++) {
					Gson gson = new Gson();
					String json = gson.toJson(getMErecords.get(i));
					JSONObject objects = new JSONObject(json);

					Connectionsyncdata connectionsyncdata = listconnectionsyncdatas.get(i);

					connectionsyncdata.setMeId(objects.get("WORKORDERID").toString());
					String dateandtime = objects.get("updatetime").toString();
					String times = dateandtime.substring(0, 10);

					long timestamp = Long.parseLong(times);
					String defectCreationDate = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
							.format(new java.util.Date(timestamp * 1000));

					connectionsyncdata.setMeupdateTime(defectCreationDate);
					LogFile.LogWrite("Connection Controller - 2050 setMeupdateTime IS  :" + defectCreationDate);
					
					LogFile.LogWrite("Connection Controller - 202020 connectionsyncdata IS  :" + connectionsyncdata);
				}

				List<Connectionsyncdata> listallConnectionsyndata = connectionsyncdataServiceImpl
						.getAllConnectionsyncdata();

				LogFile.LogWrite("Connection Controller - listallConnectionsyndata IS  :" + listallConnectionsyndata);

				if (listallConnectionsyndata.size() > 0) {
					LogFile.LogWrite("Connection Controller - 303030 connectionsyncdata IS  :" + listconnectionsyncdatas);
					connectionsyncdataServiceImpl.updateAllMEupdatetimeALMupdatetime(listconnectionsyncdatas);
				} else {
					connectionsyncdataServiceImpl.saveConnectionsyncdata(listconnectionsyncdatas);
				}
				
				
				// Get Current Domain Name:
				DataSource CurrentDSDetails=dscontrooler.selectDomanin(conndata.getTargetdatasource());
				String DomainnameIS =CurrentDSDetails.getProjectname(); //Project Name
			
				LogFile.LogWrite("Connection Controller - 2525 Sync match  DomainnameIS   :"+ DomainnameIS);
				
				int Iteration=0;

				ERRORHANDLING:	
			
					for (int i = Iteration; i < listallConnectionsyndata.size(); i++) {
						 LogFile.LogWrite("Connection Controller -SYNC ITERATION  *********************  :"+i);	
					LogFile.LogWrite("Connection Controller - 2525 Sync match  listallConnectionsyndata :"+ listallConnectionsyndata.get(i).getalmDefaultProject());	
            try {
        	if(DomainnameIS.equals(listallConnectionsyndata.get(i).getalmDefaultProject())) {
		LogFile.LogWrite("Connection Controller - 2525 Sync match  YESSSSSS getalmDefaultProject :: " +listallConnectionsyndata.get(i).getalmDefaultProject());	
		LogFile.LogWrite("Connection Controller - 2525 Sync match  YESSSSSS getAlmId :: " +listallConnectionsyndata.get(i).getAlmId());	
		LogFile.LogWrite("Connection Controller - 2525 Sync match  YESSSSSS getMeId :: " +listallConnectionsyndata.get(i).getMeId());	
		
		
		

		Date MEUPDATETIMEFIND = null;
		 String MeupdateTimeString=null;
		
//		// Added By Mubarak For Resolved			
		
		
		 
		 try {
				String uri = "http://localhost:7373/getModifiedTimeByMEIdResolved?meID=" + listallConnectionsyndata.get(i).getMeId() ;
				LogFile.LogWrite("Connection Controller - 5758 uri:"+ uri);	
				RestTemplate restTemplate_ = new RestTemplate();
				String result_ = restTemplate_.getForObject(uri, String.class);
				LogFile.LogWrite("Connection Controller - 5757 RESOLVED /CLOSED NULL TOP 2525 :"+result_);
				if(result_.equalsIgnoreCase("ERROR")||result_==null||result_=="ERROR") {
					MeupdateTimeString=listallConnectionsyndata.get(i).getMeupdateTime();
					LogFile.LogWrite("Connection Controller - 5757 RESOLVED /CLOSED NULL TOP: MeupdateTimeString="+MeupdateTimeString);	
				}else {
					

					 String dateandtime_ = result_;
					 long seconddatetime_ = Long.parseLong(dateandtime_);
					 Timestamp stamp_ = new Timestamp(seconddatetime_);
				     Date date_ = new Date(stamp_.getTime());
					 DateFormat f_ = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					 MeupdateTimeString= f_.format(date_);
					 Date medateResolved = null;
					 Date medateUpdateOld = null;
					 SimpleDateFormat sdfResolved = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					 medateResolved = sdfResolved.parse(MeupdateTimeString);
					 MEUPDATETIMEFIND =sdfResolved.parse(MeupdateTimeString);
					 medateUpdateOld= sdfResolved.parse(listallConnectionsyndata.get(i).getMeupdateTime());
					 LogFile.LogWrite("Connection Controller - 5758   MEUPDATETIMEFIND RESOLVED /CLOSED  MEUPDATETIME  ID:"+ listallConnectionsyndata.get(i).getMeId()+" MEUPDATETIMEFIND:"+MEUPDATETIMEFIND);
						LogFile.LogWrite("Connection Controller - 5758   RESOLVED /CLOSED  MEUPDATETIME  ID:"+ listallConnectionsyndata.get(i).getMeId()+" medateResolved:"+medateResolved);	
						LogFile.LogWrite("Connection Controller - 5758  RESOLVED /CLOSED   MEUPDATETIME  ID:"+ listallConnectionsyndata.get(i).getMeId()+" medateUpdateOld:"+medateUpdateOld);	
					 if(medateResolved.after(medateUpdateOld)) {
						 
							LogFile.LogWrite("Connection Controller - 5757  RESOLVED /CLOSED TRUE  MEUPDATETIME  ID:"+ listallConnectionsyndata.get(i).getMeId()+" UPDATE TIME:"+MEUPDATETIMEFIND);	
							connectionsyncdataServiceImpl.updateMEUpdateTimeAlon(listallConnectionsyndata.get(i).getMeId(), MeupdateTimeString);
	 
					 }
				}
				
		 }catch(Exception ex) {
			
			 LogFile.LogWrite("Connection Controller -ERROR  78789:"+ex.getMessage());			 
//			 Iteration=Iteration+1;
			 continue ERRORHANDLING;			 
		 }
		 
		 
		

		//Resolved End
//		
		
		
		
		
		
		
		try {
								
	String connectionOfftime = null;

	String meupdatetime = listallConnectionsyndata.get(i).getMeupdateTime();
	String almupdatetime = listallConnectionsyndata.get(i).getAlmupdateTime();
	String mecopyupdatetime = listallConnectionsyndata.get(i).getMecopyupdatetime();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	String mappingFields = listConnectionData.get(connectiondataIntiallization).getMappingField();
	Date medate = null;
	Date connectionswitchofftime = null;
	LogFile.LogWrite("Connection Controller - ME ID " + listallConnectionsyndata.get(i).getMeId());
	LogFile.LogWrite("Connection Controller - meupdatetime :" + meupdatetime + "  " + "almupdatetime :"
			+ almupdatetime + "");

	if (almupdatetime != null) {
		String almcopyupdatetime = listallConnectionsyndata.get(i).getAlmcopyupdatetime();
		LogFile.LogWrite("Connection Controller - ME ID " + listallConnectionsyndata.get(i).getMeId());
		LogFile.LogWrite("Connection Controller - meupdatetime :" + meupdatetime + "  "
				+ "almupdatetime :" + almupdatetime + "");
		try {
			medate = sdf.parse(meupdatetime);

		} catch (ParseException e) {

			e.printStackTrace();
		}
		Date almdate = null;
		try {
			almdate = sdf.parse(almupdatetime);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (mecopyupdatetime == null || almcopyupdatetime == null) {
			if (medate.after(almdate)) {

				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				//
				LogFile.LogWrite("Connection Controller - #2121" + "meupdatetime :" + meupdatetime
						+ "almupdatetime :" + almupdatetime);

				Date d1 = sdf1.parse(meupdatetime);
				Date d2 = sdf1.parse(almupdatetime);

				SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
				String meupdatetime_dateString = sdf3.format(d1);
				String almupdatetime_dateString = sdf3.format(d2);

				LogFile.LogWrite(
						"Connection Controller - Date in the format of dd-MM-yyyy hh:mm:ss : 1 "
								+ meupdatetime_dateString);

				Date d3 = sdf3.parse(meupdatetime_dateString);
				Date d4 = sdf3.parse(almupdatetime_dateString);
				long difference_In_Time = d3.getTime() - d4.getTime();
				difference_In_Time = difference_In_Time / 1000;
				LogFile.LogWrite(
						"Connection Controller - the difference time  is 01 :" + difference_In_Time);

				if (difference_In_Time < 180000) {
					// if (difference_In_Time > 90000 ) {

					String meID = listallConnectionsyndata.get(i).getMeId();
					Object objectmeID = meID;
					String almID = listallConnectionsyndata.get(i).getAlmId();
					JSONObject meObjects = getMERecordsById(meID, masterDatasource);
					String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID, almID,
							conndata.getConnectionName(), targetDatasource);

					// isAttachmentINME(objectmeID,almID);
					findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
					updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
							MeupdateTimeString);
					LogFile.LogWrite("Connection Controller - difference_In_Time< 3 Minit updatedALMRecords 1 :" + updatedALMRecords
							+ " " + "ME ID :" + meID);
				}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
					String meID = listallConnectionsyndata.get(i).getMeId();
					Object objectmeID = meID;
					String almID = listallConnectionsyndata.get(i).getAlmId();
					JSONObject meObjects = getMERecordsById(meID, masterDatasource);
					String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID, almID,
							conndata.getConnectionName(), targetDatasource);
					LogFile.LogWrite("Connection Controller - 7676 DIFF >1 Minit findAttachmentMEandAttachTOALM BEFORE 1 2092 :" + updatedALMRecords
							+ " " + "ME ID :" + meID);
					// isAttachmentINME(objectmeID,almID);
					findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
					updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
							MeupdateTimeString);
					LogFile.LogWrite("Connection Controller - updatedALMRecords 1 2092 :" + updatedALMRecords
							+ " " + "ME ID :" + meID);
				}

			} else if (almdate.after(medate)) {

				//
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				//
				Date d1 = sdf1.parse(meupdatetime);
				Date d2 = sdf1.parse(almupdatetime);
				sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
				String meupdatetime_dateString = sdf.format(d1);
				String almupdatetime_dateString = sdf.format(d2);

				LogFile.LogWrite("Connection Controller - Date in the format of dd-MM-yyyy hh:mm:ss : "
						+ meupdatetime_dateString);

				Date d3 = sdf.parse(meupdatetime_dateString);
				Date d4 = sdf.parse(almupdatetime_dateString);
				long difference_In_Time = d4.getTime() - d3.getTime();
				difference_In_Time = difference_In_Time / 1000;
				LogFile.LogWrite(
						"Connection Controller - the difference time  is 02 " + difference_In_Time);

				
				 
				if (difference_In_Time < 180000) {
					LogFile.LogWrite(
							"Connection Controller - 4545 difference_In_Time< 3 Minit   is 02 " + difference_In_Time);

					String almID = listallConnectionsyndata.get(i).getAlmId();
					String meID = listallConnectionsyndata.get(i).getMeId();
					mappingTOManageEngine(almID, mappingFields, meID, conndata.getConnectionName(),
							targetDatasource);
					updateALMModifiedtimeAfterMEUpdate(meID, almID, almupdatetime);

				}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
					
					LogFile.LogWrite("Connection Controller - 30332 DIFF >1 Minit   difference_In_Time TRUE 1010 IS  :" + difference_In_Time);
					String almID = listallConnectionsyndata.get(i).getAlmId();
					String meID = listallConnectionsyndata.get(i).getMeId();
					mappingTOManageEngine(almID, mappingFields, meID, conndata.getConnectionName(),
							targetDatasource);
					updateALMModifiedtimeAfterMEUpdate(meID, almID, almupdatetime);
				}

			}
		} else {
			Date mecopyupdatetimeDateF = sdf.parse(mecopyupdatetime);
			Date almcopyupdatetimeDateF = sdf.parse(almcopyupdatetime);

			if (medate.after(mecopyupdatetimeDateF)) {

				if (medate.after(almdate)) {

					//
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					//
					Date d1 = sdf1.parse(meupdatetime);
					Date d2 = sdf1.parse(almupdatetime);

					sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
					String meupdatetime_dateString = sdf.format(d1);
					String almupdatetime_dateString = sdf.format(d2);

					LogFile.LogWrite(
							"Connection Controller - Date in the format of dd-MM-yyyy hh:mm:ss : "
									+ meupdatetime_dateString);

					Date d3 = sdf.parse(meupdatetime_dateString);
					Date d4 = sdf.parse(almupdatetime_dateString);
					long difference_In_Time = d3.getTime() - d4.getTime();
					difference_In_Time = difference_In_Time / 1000;
					LogFile.LogWrite("Connection Controller - the difference time  is 03 : "
							+ difference_In_Time);

					if (conndata.getswitchfalg().equals("YES")) {
						connectionOfftime = conndata.getOFFTime();
						connectionswitchofftime = sdf.parse(connectionOfftime);

						if (medate.after(connectionswitchofftime)) {
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - updatedALMRecords 3: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}

					} else {

						if (difference_In_Time < 180000) {
							// if (difference_In_Time > 90000 ) {

							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - difference_In_Time 2033 < 3 minit updatedALMRecords 3: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
							LogFile.LogWrite("Connection Controller - difference_In_Time TRUE 1011 IS  :" + difference_In_Time);
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - 20500 DIFF >1 Minit  updatedALMRecords 3 ID 2939: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}
					}
				} else if (almdate.after(medate)) {

					//
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					//
					Date d1 = sdf1.parse(meupdatetime);
					Date d2 = sdf1.parse(almupdatetime);

					sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
					String meupdatetime_dateString = sdf.format(d1);
					String almupdatetime_dateString = sdf.format(d2);

					LogFile.LogWrite("Date in the format of dd-MM-yyyy hh:mm:ss 04 : "
							+ meupdatetime_dateString);

					Date d3 = sdf.parse(meupdatetime_dateString);
					Date d4 = sdf.parse(almupdatetime_dateString);
					long difference_In_Time = d4.getTime() - d3.getTime();
					difference_In_Time = difference_In_Time / 1000;

					LogFile.LogWrite("Connection Controller - the difference time  is 04  :"
							+ difference_In_Time);

					if (conndata.getswitchfalg().equals("YES")) {
						connectionOfftime = conndata.getOFFTime();
						connectionswitchofftime = sdf.parse(connectionOfftime);

						if (almdate.after(connectionswitchofftime)) {
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - updatedALMRecords 3: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}

					} else {

						if (difference_In_Time < 180000) {
							LogFile.LogWrite("Connection Controller - difference_In_Time < 3 Minit  difference_In_Time TRUE 1012 IS  :" + difference_In_Time);
							// if (difference_In_Time > 90000 ) {
							String almID = listallConnectionsyndata.get(i).getAlmId();
							String meID = listallConnectionsyndata.get(i).getMeId();
							mappingTOManageEngine(almID, mappingFields, meID,
									conndata.getConnectionName(), targetDatasource);
							updateALMModifiedtimeAfterMEUpdate(meID, almID, almupdatetime);
						}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
							LogFile.LogWrite("Connection Controller -30302  DIFF >1 Minit  difference_In_Time TRUE 1012 IS  :" + difference_In_Time);
							String almID = listallConnectionsyndata.get(i).getAlmId();
							String meID = listallConnectionsyndata.get(i).getMeId();
							mappingTOManageEngine(almID, mappingFields, meID,
									conndata.getConnectionName(), targetDatasource);
						}
					}
				}

			} else if (almdate.after(almcopyupdatetimeDateF)) {

				if (medate.after(almdate)) {

					//
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					//
					Date d1 = sdf1.parse(meupdatetime);
					Date d2 = sdf1.parse(almupdatetime);

					// Calucalte time difference
					// in milliseconds

					sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
					String meupdatetime_dateString = sdf.format(d1);
					String almupdatetime_dateString = sdf.format(d2);
					LogFile.LogWrite(
							"Date in the format of dd-MM-yyyy hh:mm:ss : " + meupdatetime_dateString);

					Date d3 = sdf.parse(meupdatetime_dateString);
					Date d4 = sdf.parse(almupdatetime_dateString);
					long difference_In_Time = d3.getTime() - d4.getTime();
					difference_In_Time = difference_In_Time / 1000;
					LogFile.LogWrite("Connection Controller - the difference time  is 05  :"
							+ difference_In_Time);

					if (conndata.getswitchfalg().equals("YES")) {
						connectionOfftime = conndata.getOFFTime();
						connectionswitchofftime = sdf.parse(connectionOfftime);

						if (medate.after(connectionswitchofftime)) {
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - updatedALMRecords 3: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}

					} else {

						if (difference_In_Time < 180000) {
							// if (difference_In_Time > 90000 ) {
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite(
									"Connection Controller - difference_In_Time 3> Minit  2:" + updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
							LogFile.LogWrite("Connection Controller - 20202 DIFF >1 Minit  difference_In_Time TRUE 1013 IS  :" + difference_In_Time);
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite(
									"Connection Controller - updatedALMRecords 2:" + updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}
					}

				} else if (almdate.after(medate)) {

					//
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					//
					Date d1 = sdf1.parse(meupdatetime);
					Date d2 = sdf1.parse(almupdatetime);

					sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
					String meupdatetime_dateString = sdf.format(d1);
					String almupdatetime_dateString = sdf.format(d2);

					LogFile.LogWrite(
							"Connection Controller - Date in the format of dd-MM-yyyy hh:mm:ss 06 : "
									+ meupdatetime_dateString);

					Date d3 = sdf.parse(meupdatetime_dateString);
					Date d4 = sdf.parse(almupdatetime_dateString);
					long difference_In_Time = d4.getTime() - d3.getTime();
					difference_In_Time = difference_In_Time / 1000;
					LogFile.LogWrite("Connection Controller - the difference time  is 05 :"
							+ difference_In_Time);

					if (conndata.getswitchfalg().equals("YES")) {
						connectionOfftime = conndata.getOFFTime();
						connectionswitchofftime = sdf.parse(connectionOfftime);

						if (almdate.after(connectionswitchofftime)) {
							String meID = listallConnectionsyndata.get(i).getMeId();
							Object objectmeID = meID;
							String almID = listallConnectionsyndata.get(i).getAlmId();
							JSONObject meObjects = getMERecordsById(meID, masterDatasource);
							String updatedALMRecords = mappingToALM(mappingFields, meObjects, meID,
									almID, conndata.getConnectionName(), targetDatasource);
							findAttachmentMEandAttachTOALM(objectmeID, almID, targetDatasource);
							LogFile.LogWrite("Connection Controller - updatedALMRecords 3: "
									+ updatedALMRecords);
							updateMEModifiedtimeAfterALMUpdate(updatedALMRecords, meID, mappingFields,
									MeupdateTimeString);
						}

					} else {

						if (difference_In_Time < 180000) {
							// if (difference_In_Time > 90000 ) {
							String almID = listallConnectionsyndata.get(i).getAlmId();
							String meID = listallConnectionsyndata.get(i).getMeId();
							mappingTOManageEngine(almID, mappingFields, meID,
									conndata.getConnectionName(), targetDatasource);
							updateALMModifiedtimeAfterMEUpdate(meID, almID, almupdatetime);
						}else if(difference_In_Time>60000) {// Added By Mubarak  Else IF for SYNc diff more than one minits
							LogFile.LogWrite("Connection Controller -DIFF >1 Minit   difference_In_Time TRUE 1014 IS  :" + difference_In_Time);
							String almID = listallConnectionsyndata.get(i).getAlmId();
							String meID = listallConnectionsyndata.get(i).getMeId();
							mappingTOManageEngine(almID, mappingFields, meID,
									conndata.getConnectionName(), targetDatasource);
						}
					}
				}

			} else {
				String almID = listallConnectionsyndata.get(i).getAlmId();
			}

		}

		// }
	}
		}catch(Exception ex) {
			LogFile.LogWrite("Connection Controller - ERROR 6565  Sync match :"+ ex.getMessage());	
			throw ex;
		}
}else {
	LogFile.LogWrite("Connection Controller - 6565  Sync match Project Miss match :");	
}
	
}catch(Exception ex) {
	throw ex;
}
	
				// To Update con switch flag as NO After Completed Sync
				connservice.updateConnectionswitchflag(conndata.getConnectionName());
//				LogFile.LogWrite("Connection Controller -Update Conn Falg As YES ");
				// NO 
//				   Iteration=Iteration+1;
				   continue ERRORHANDLING;
						
				}
			}
			updateConnectionStatus(conndata, "INACTIVE");
		}
		LogFile.LogWrite("Connection Controller - ********** getBackWardSync END **********");
		return "success";
	}

	public JSONObject getMERecordsById(String meID, DataSource masterDataSource)
			throws MalformedURLException, IOException {

		String url = masterDataSource.getUrl();

		String getFieldURL = url + "/sdpapi/request/" + meID
				+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json";

		LogFile.LogWrite("Connection Controller - ME TECH KEY getFieldURL : " + getFieldURL);

		// 04BAF692-6023-4065-A7A7-D421093A13AD OLD KEY
		HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		String jsonstring = result.toString();
		JSONObject mainObject = new JSONObject(jsonstring);

		JSONObject resultObject = mainObject.getJSONObject("operation");
		JSONObject detailsObject = resultObject.getJSONObject("details");

		return detailsObject;
	}

	public List<?> getMEUpdatedRecords(String orgName, String condition) throws IOException {
		String uri = "http://localhost:7373/getModifiedTimeByOrgName?orgName=" + orgName;
		RestTemplate restTemplate = new RestTemplate();
		List<?> result = restTemplate.getForObject(uri, List.class);
		LogFile.LogWrite("Connection Controller - the return data items" + result);
		String dateandtime = "1623468929960";
		long seconddatetime = Long.parseLong(dateandtime);
		Timestamp stamp = new Timestamp(seconddatetime);
		Date date = new Date(stamp.getTime());
		DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
		DateFormat f1 = new SimpleDateFormat("yyyy/MM/dd");
		String d = f.format(date);
		String d1 = f1.format(date);
		LogFile.LogWrite("Connection Controller - thee ddd value is" + d);
		return result;
	}

	public String mappingToALM(String mappingfields, JSONObject detailsObject, String meID, String almID,
			String connectionName, DataSource targetDataSource)
			throws TransformerException, ParserConfigurationException, IOException, InterruptedException {
		String conndata = mappingfields;
		JSONObject conndataJOSN = new JSONObject(conndata);
		JSONArray fieldObject = conndataJOSN.getJSONArray("Fields");
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Map<Object, Object> almFields;
		
		try {
			almFields = dscontrooler.getALMFields(targetDataSource);
		}catch(Exception ex) {
			LogFile.LogWrite("Connection Controller -ERROR 2425 thee ddd value is   " + ex.getMessage());
			throw ex;
		}
		
		
		// root elements
		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("Entity");
		doc.appendChild(rootElement);
		rootElement.setAttribute("Type", "defect");
		Element fieldsElement = doc.createElement("Fields");
		// add staff to root
		rootElement.appendChild(fieldsElement);

		for (int i = 0; i < fieldObject.length(); i++) {
			JSONObject objects1 = fieldObject.getJSONObject(i);
			if ((objects1.get("direction").equals(1)) || (objects1.get("direction").equals(3))) {
				String masterDataField = (String) objects1.get("masterdatafield");
				String targetDataFieldValue = (String) detailsObject.get(masterDataField);
				String targetDataField = (String) objects1.get("targetdatafield");

				for (Object key : almFields.keySet()) {

					if (key.equals(targetDataField)) {

						targetDataField = (String) almFields.get(key);
					}
				}

				if (targetDataField.equals("detected-by")) {

					//
					// Element fieldElementi = doc.createElement("Field");
					//
					// fieldsElement.appendChild(fieldElementi);
					//
					// fieldElementi.setAttribute("Name", "" + targetDataField + "");
					// Element valueElementi = doc.createElement("Value");
					// valueElementi.setTextContent("Navin.kanna");
					// fieldElementi.appendChild(valueElementi);
				} else if (targetDataField.equals("creation-time")) {

					//
					// Element fieldElementi = doc.createElement("Field");
					//
					// fieldsElement.appendChild(fieldElementi);
					//
					// fieldElementi.setAttribute("Name", "" + targetDataField + "");
					// Element valueElementi = doc.createElement("Value");
					// valueElementi.setTextContent("Navin.kanna");
					// fieldElementi.appendChild(valueElementi);
				} else if (targetDataField.equals("owner")) {
					// Element fieldElementi = doc.createElement("Field");
					//
					// fieldsElement.appendChild(fieldElementi);
					//
					// fieldElementi.setAttribute("Name", "" + targetDataField + "");
					// Element valueElementi = doc.createElement("Value");
					// valueElementi.setTextContent("Navin.kanna");
					// fieldElementi.appendChild(valueElementi);
				} else if (targetDataField.equals("description")) {

					String removehtmltags_string = targetDataFieldValue.replaceAll("<[^>]*>", "");
					String targetDataFieldValue1 = removehtmltags_string;
					Element fieldElementi = doc.createElement("Field");

					fieldsElement.appendChild(fieldElementi);

					fieldElementi.setAttribute("Name", "" + targetDataField + "");
					Element valueElementi = doc.createElement("Value");
					valueElementi.setTextContent("" + targetDataFieldValue1 + "");
					fieldElementi.appendChild(valueElementi);
				}

				else if (targetDataField.equals("status")) {

					JSONArray fieldmappingArray = objects1.getJSONArray("subFieldMapping");
					String subfiledtargetValue = "";
					for (int k = 0; k < fieldmappingArray.length(); k++) {

						JSONObject subfieldMappingObject = fieldmappingArray.getJSONObject(k);
						if (subfieldMappingObject.get("masterSubFieldMapping").equals(targetDataFieldValue)) {
							subfiledtargetValue = (String) subfieldMappingObject.get("targetSubFieldMapping");
						}

					}
					Element fieldElementi = doc.createElement("Field");

					fieldsElement.appendChild(fieldElementi);

					fieldElementi.setAttribute("Name", "" + targetDataField + "");
					Element valueElementi = doc.createElement("Value");
					valueElementi.setTextContent("" + subfiledtargetValue + "");
					fieldElementi.appendChild(valueElementi);
				} else {

					Element fieldElementi = doc.createElement("Field");

					fieldsElement.appendChild(fieldElementi);

					fieldElementi.setAttribute("Name", "" + targetDataField + "");
					Element valueElementi = doc.createElement("Value");
					valueElementi.setTextContent("" + targetDataFieldValue + "");
					fieldElementi.appendChild(valueElementi);
				}
			}
		}

		String outputXMLData = writeXml(doc, System.out);

		JSONObject xmlJSONObj = XML.toJSONObject(outputXMLData);
		String auditData = xmlJSONObj.toString();

		byte[] b = outputXMLData.getBytes();

		String almURL = targetDataSource.getUrl() + "/qcbin/";

		almUserName = targetDataSource.getUsername();
		almPassword = targetDataSource.getPassword();

		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		/* authenticate begin */
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {

			LogFile.LogWrite("Connection Controller - targetDataSource.getUsername()" + targetDataSource.getUsername());
			LogFile.LogWrite("Connection Controller - targetDataSource.getPassword()" + targetDataSource.getPassword());

			osw.write("<alm-authentication><user>" + targetDataSource.getUsername() + "</user><password>"
					+ targetDataSource.getPassword() + "</password></alm-authentication>");
		}
		authConnection.connect();

		LogFile.LogWrite(authConnection.getResponseMessage());
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Connection Controller - INFO the lwssscookiess " + lwssoCookie);
		/* authenticate end */
		/* create session begin */
		try {
			HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
			createSession.setRequestProperty("Cookie", lwssoCookie);
			// createSession.setRequestProperty("Content-Type", "application/json");
			createSession.setRequestMethod("POST");
			createSession.connect();
			Map<String, List<String>> values = createSession.getHeaderFields();
			String xsrfHeaderValue = "";
			String cookies = "";
			for (String cookie : values.get("Set-Cookie")) {
				String content = cookie.split(";")[0];
				cookies = cookies + content + ";";
				LogFile.LogWrite("Connection Controller - the coookies value isss" + cookies);
				String[] nameValue = content.split("=");
				String name = nameValue[0];
				String value = nameValue[1];
				if (name.equalsIgnoreCase("XSRF-TOKEN")) {
					xsrfHeaderValue = value;
				}
			}

			/* create session end */
			/* create defect begin */
			HttpURLConnection updateDefect = (HttpURLConnection) new URL(
					targetDataSource.getUrl() + "/qcbin/rest/domains/" + targetDataSource.getDomainname() + "/projects/"
							+ targetDataSource.getProjectname() + "/defects/" + almID).openConnection();
			LogFile.LogWrite("Connection Controller - INFO #2010 updateDefect  : " + targetDataSource.getUrl()
					+ "/qcbin/rest/domains/" + targetDataSource.getDomainname() + "/projects/"
					+ targetDataSource.getProjectname() + "/defects/" + almID);

			try {
				updateDefect.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
				updateDefect.setRequestProperty("Cookie", cookies + lwssoCookie);
				updateDefect.setRequestProperty("Content-Type", "application/xml");
				updateDefect.setRequestProperty("Accept", "application/json");
				updateDefect.setRequestMethod("PUT");
				updateDefect.setDoOutput(true);
				updateDefect.setDoInput(true);
				updateDefect.connect();
				LogFile.LogWrite("Connection Controller - INFO #1217 updateDefect Connected ");
			} catch (Exception ex) {
				LogFile.LogWrite("Connection Controller - ERROR #1217 updateDefect  " + ex.getMessage());
				throw ex;
			}

			OutputStream os1 = updateDefect.getOutputStream();

			os1.write(b);

			os1.flush();

			LogFile.LogWrite("Connection Controller - INFO #1010 updateDefect");

			InputStream inputStream = new BufferedInputStream(updateDefect.getInputStream());
			LogFile.LogWrite("Connection Controller - INFO #1111 updateDefect");
			BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
			StringBuilder result1 = new StringBuilder();
			String line1;
			String jsonString1 = "";

			LogFile.LogWrite("Connection Controller - INFO #1515 updateDefect");

			try {
				while ((line1 = reader1.readLine()) != null) {
					result1.append(line1);
				}
				updateDefect.disconnect();
			}catch(Exception ex) {
				LogFile.LogWrite("Connection Controller - ERROR #1919 updateDefect");
				updateDefect.disconnect();
				throw ex;
				
			}
			
			LogFile.LogWrite("Connection Controller - INFO #1818 updateDefect");
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
	        LocalDateTime now = LocalDateTime.now();
			String eventhandledatetime = dtf.format(now);

			LogFile.LogWrite("Connection Controller - INFO #2020 updateDefect");

			if (updateDefect.getResponseCode() == 200) {

				try {
					ConnectionAudits connaudit = new ConnectionAudits();
					
				
					connaudit.setAuditdatetime(eventhandledatetime);
					connaudit.setMEID(meID);
					connaudit.setALMID(almID);
					connaudit.setSyncDate(auditData);
					connaudit.setDirection("ALM <= ME");
					// DO Not Change the Content its For Substring in React audit Table // By Mubarak 23-07-2022
					connaudit.setConnectionauditdescription("Fields are Sync from ME to ALM. ME id is " + meID
							+ ".ALM id is" + almID + ".Those fields are" + auditData);
					connaudit.setConnectionname(connectionName);
					connauditsImpl.saveconnectionAudit(connaudit);

				} catch (Exception ex) {
					LogFile.LogWrite("Connection Controller - ERROR #1215 updateDefect  " + ex.getMessage());
					throw ex;
				}

			}

			return jsonString1 = result1.toString();
		} catch (Exception e) {
			LogFile.LogWrite("Connection Controller - ERROR 1218 updateDefect " + e.getMessage());
		}

		return "";

	}

	public void mappingTOManageEngine(String almID, String mappingFields, String meID, String connectionName,
			DataSource targetDatasource) throws MalformedURLException, IOException, InterruptedException {

		String conndata = mappingFields;

		String almURL = targetDatasource.getUrl() + "/qcbin/";
		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		/* authenticate begin */
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
			osw.write("<alm-authentication><user>" + targetDatasource.getUsername() + "</user><password>"
					+ targetDatasource.getPassword() + "</password></alm-authentication>");
		}
		authConnection.connect();

		LogFile.LogWrite("Connection Controller - INFO #3030" + authConnection.getResponseMessage());
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Connection Controller - INFO the lwssscookiess " + lwssoCookie);
		/* authenticate end */
		/* create session begin */

		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		// createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		String xsrfHeaderValue = "";
		String cookies = "";
		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			LogFile.LogWrite("Connection Controller - the coookies value isss" + cookies);
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}

		JSONObject conndataJOSN = new JSONObject(conndata);
		LogFile.LogWrite("Connection Controller - INFO the conndataJOSN conndataJOSN conndataJOSN is" + conndataJOSN);
		JSONArray fieldObject = conndataJOSN.getJSONArray("Fields");

		HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new URL(
				targetDatasource.getUrl() + "/qcbin/" + "rest/domains/" + targetDatasource.getDomainname()
						+ "/projects/" + targetDatasource.getProjectname() + "/defects/" + almID).openConnection();

		/*
		 * ADDED AND COMMANDED BY MUBARAK
		 * 
		 * "http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/"
		 * + almID) .openConnection();
		 */

		requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		requiredFieldsConnection.setRequestProperty("Content-Type", "application/JSON");
		requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
		requiredFieldsConnection.setRequestMethod("GET");
		requiredFieldsConnection.connect();

		InputStream inputStream = new BufferedInputStream(requiredFieldsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
		StringBuilder result1 = new StringBuilder();
		String line1;

		try {
			while ((line1 = reader1.readLine()) != null) {
				result1.append(line1);
			}
			requiredFieldsConnection.disconnect();
		
		}catch(Exception ex) {
			requiredFieldsConnection.disconnect();
			throw ex;
			
		}
		
		String jsonstring1 = result1.toString();
		LogFile.LogWrite("Connection Controller - INFO the json string object is" + jsonstring1);

		JSONObject createALMId_returnJSON = new JSONObject(jsonstring1);
		JSONArray fieldArrayObject = createALMId_returnJSON.getJSONArray("Fields");
		JSONObject masterSyncDetailsObject = new JSONObject();
		JSONObject masterSyncOperationObject = new JSONObject();
		JSONObject mastersyncObject = new JSONObject();
		String updatetime = "";
		Map<Object, Object> almFields = dscontrooler.getALMFields(targetDatasource);
		for (int i = 0; i < fieldObject.length(); i++) {

			JSONObject objects1 = fieldObject.getJSONObject(i);
			String masterDataField = (String) objects1.get("masterdatafield");

			String targetDataField = (String) objects1.get("targetdatafield");
			String targetDataFieldValue = "";

			if ((objects1.get("direction").equals(2)) || (objects1.get("direction").equals(3))) {
			//	NullHANDLING:
				for (int j = 0; j < fieldArrayObject.length(); j++)

				{
					// mastersyncObject = new JSONObject();
					JSONObject item = fieldArrayObject.getJSONObject(j);
					String nameObject1 = item.getString("Name");

					for (Object key : almFields.keySet()) {

						if (key.equals(targetDataField)) {

							targetDataField = (String) almFields.get(key);
						}
					}

					if (nameObject1.equals(targetDataField)) {

						try {

							JSONArray valuesarrayObject = item.getJSONArray("values");

							JSONObject valuejsonobject = valuesarrayObject.getJSONObject(0);
							ArrayList<String> list = new ArrayList<String>(valuejsonobject.keySet());
							if (nameObject1.equals("id")) {

								try {
									almID = (String) valuejsonobject.get("value");
								} catch (Exception ex) {
									LogFile.LogWrite("Connection Controller - ERROR #7273 getALMFields :almID "
											+ ex.getMessage());
									throw ex;
								}

							}

							if (nameObject1.equals("last-modified")) {

								try {
									Object modifiedTime = (Object) valuejsonobject.get("value");
									updatetime = (String) modifiedTime;
								} catch (Exception ex) {
									LogFile.LogWrite(
											"Connection Controller - ERROR #7274 getALMFields  " + ex.getMessage());
									throw ex;
								}

							}

							if (list.contains("value")) {

								try {

									if (nameObject1.equals("dev-comments")) {

										try {
											String devcomments = (String) valuejsonobject.get("value");
											String removehtmltags_string = devcomments.replaceAll("<[^>]*>", "");
											targetDataFieldValue = removehtmltags_string;
										} catch (Exception ex) {
											LogFile.LogWrite(
													"ERROR #7277 getALMFieldsdev-comments :  " + ex.getMessage());
											throw ex;
										}

									} else if (nameObject1.equals("defect status")) {
										try {

											String status = (String) valuejsonobject.get("value");

											JSONArray fieldmappingArray = objects1.getJSONArray("subFieldMapping");
											String subfiledMasterValue = "";
											for (int k = 0; k < fieldmappingArray.length(); k++) {

												JSONObject subfieldMappingObject = fieldmappingArray.getJSONObject(k);
												if (subfieldMappingObject.get("targetSubFieldMapping").equals(status)) {
													subfiledMasterValue = (String) subfieldMappingObject
															.get("masterSubFieldMapping");
													// Added By Mubarak 15-09-2022  Avoid Null 
//													if(subfiledMasterValue==null ||subfiledMasterValue=="") {
//														 continue NullHANDLING;
//													}
													targetDataFieldValue = subfiledMasterValue;
												}

											}
										} catch (Exception ex) {
											LogFile.LogWrite("Connection Controller - ERROR #7278 getALMFields  "
													+ ex.getMessage());
											throw ex;
										}

									} else {

										try {
											// Added By Mubarak 15-09-2022  Avoid Null 
//											if((String) valuejsonobject.get("value")==null ||(String) valuejsonobject.get("value")=="") {
//												 continue NullHANDLING;
//											}
											targetDataFieldValue = (String) valuejsonobject.get("value");
										} catch (Exception ex) {
											LogFile.LogWrite("Connection Controller - ERROR #7279 getALMFields  "
													+ ex.getMessage());
											throw ex;
										}

									}
								} catch (Exception ex) {
									LogFile.LogWrite("Connection Controller - ERROR #7276 getALMFields value  "
											+ ex.getMessage());
								}

							}

						} catch (Exception ex) {
							LogFile.LogWrite("Connection Controller - ERROR #7272 targetDataField  " + ex.getMessage());
						}
					}

				}
			if(targetDataFieldValue==null||targetDataFieldValue=="") {
				// Avoid Null Values  19/09/2022
			}else {
				mastersyncObject.put(masterDataField, targetDataFieldValue);	
			}
				
			}

		}
		// mastersyncObject.put("last_updated_time",updatetime);
		masterSyncDetailsObject.put("details", mastersyncObject);

		masterSyncOperationObject.put("operation", masterSyncDetailsObject);
		String stringmasterSyncOperationObject = masterSyncOperationObject.toString();
		String auditData = stringmasterSyncOperationObject;

		byte[] mastersyncbytesdata = stringmasterSyncOperationObject.getBytes();
		try {
			updateMEusingDriver(stringmasterSyncOperationObject, meID);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			String eventhandledatetime = now.toString();

			ConnectionAudits connaudit = new ConnectionAudits();
			connaudit.setAuditdatetime(eventhandledatetime);
			connaudit.setMEID(meID);
			connaudit.setALMID(almID);
			connaudit.setSyncDate(auditData);
			connaudit.setDirection("ALM => ME");
			
			// connaudit.setConnectionauditdescription("Fields are Mapping from ALM to
			// ME.Those fields are"+auditData);
			connaudit.setConnectionauditdescription("Fields are Sync from ALM to ME. ME id is " + meID + ".ALM id is"
					+ almID + ".Those fields are" + auditData);
			connaudit.setConnectionname(connectionName);
			connauditsImpl.saveconnectionAudit(connaudit);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updateMEModifiedtimeAfterALMUpdate(String updatedALMRecords, String meID, String mappingFields,
			String meupdatetime) throws IOException {

		// Added By Mubarak :if cond

		LogFile.LogWrite("Connection Controller - INFO 2325 updatedALMRecords: " + updatedALMRecords);
		String almID = "";
		String conndata = mappingFields;

		if (updatedALMRecords.length() > 0) {
			JSONObject conndataJOSN = new JSONObject(conndata);
			JSONArray fieldObject = conndataJOSN.getJSONArray("Fields");

			JSONObject createALMId_returnJSON = new JSONObject(updatedALMRecords);

			JSONArray fieldArrayObject = createALMId_returnJSON.getJSONArray("Fields");
			JSONObject masterSyncDetailsObject = new JSONObject();
			JSONObject masterSyncOperationObject = new JSONObject();
			JSONObject mastersyncObject = new JSONObject();
			String almupdatetime = "";
			for (int i = 0; i < fieldObject.length(); i++) {

				JSONObject objects1 = fieldObject.getJSONObject(i);
				String masterDataField = (String) objects1.get("masterdatafield");

				String targetDataField = (String) objects1.get("targetdatafield");
				String targetDataFieldValue = "";

				for (int j = 0; j < fieldArrayObject.length(); j++)

				{
					// mastersyncObject = new JSONObject();
					JSONObject item = fieldArrayObject.getJSONObject(j);
					String nameObject1 = item.getString("Name");

					if (nameObject1.equals("last-modified")) {
						JSONArray valuesarrayObject = item.getJSONArray("values");

						JSONObject valuejsonobject = valuesarrayObject.getJSONObject(0);
						ArrayList<String> list = new ArrayList<String>(valuejsonobject.keySet());
						Object modifiedTime = (Object) valuejsonobject.get("value");
						almupdatetime = modifiedTime.toString();
					}

					// mastersyncObject.put(masterDataField, targetDataFieldValue);
				}

			}
			// mastersyncObject.put("last_updated_time", almupdatetime);

			connectionsyncdataServiceImpl.updateALMUpdateTimeandALMCopyUpdateTime(meID, almupdatetime, meupdatetime);

			masterSyncDetailsObject.put("details", mastersyncObject);

			masterSyncOperationObject.put("operation", masterSyncDetailsObject);
			String stringmasterSyncOperationObject = masterSyncOperationObject.toString();

			LogFile.LogWrite("Connection Controller - INFO the object is()" + stringmasterSyncOperationObject);
		}

	}

	public void updateALMModifiedtimeAfterMEUpdate(String meID, String ALMID, String almupdatetime)
			throws TransformerException, ParserConfigurationException, IOException, ParseException {

		try {

			String uri = "http://localhost:7373/getModifiedTimeByMEId?meID=" + meID + "";
			RestTemplate restTemplate = new RestTemplate();
			String result = restTemplate.getForObject(uri, String.class);

			String dateandtime = result;
			long seconddatetime = Long.parseLong(dateandtime);
			Timestamp stamp = new Timestamp(seconddatetime);
			Date date = new Date(stamp.getTime());
			DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DateFormat f1 = new SimpleDateFormat("yyyy/MM/dd");
			String meupdateTime = f.format(date);

			connectionsyncdataServiceImpl.updateMEUpdateTimeAndMECopyUpdateTime(meID, meupdateTime, almupdatetime);

			LogFile.LogWrite("Connection Controller - INFO off updateALMModifiedtimeAfterMEUpdate IS COMPLETED ");

		} catch (Exception ex) {

			LogFile.LogWrite(
					"Connection Controller - ERROR 1212 off updateALMModifiedtimeAfterMEUpdate " + ex.getMessage());

		}

	}

	// Date date6=f.parse(meupdateTime);

	// root elements

	// DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	// DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	// Document doc = docBuilder.newDocument();
	// Element rootElement = doc.createElement("Entity");
	// doc.appendChild(rootElement);
	// rootElement.setAttribute("Type", "defect");
	// Element fieldsElement = doc.createElement("Fields");
	// // add staff to root
	// rootElement.appendChild(fieldsElement);
	//
	// Element fieldElementi = doc.createElement("Field");
	//
	// fieldsElement.appendChild(fieldElementi);
	//
	// fieldElementi.setAttribute("Name", "last-modified");
	// Element valueElementi = doc.createElement("Value");
	// valueElementi.setTextContent("" + date6 + "");
	// fieldElementi.appendChild(valueElementi);
	//
	//
	// String xmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"
	// standalone=\"no\"?>"
	// + "<Entity Type=\"defect\">\r\n" +
	//
	// " <Fields>" +
	//
	// " <Field Name=\"detected-by\">" +
	//
	// " <Value>suresh.a</Value>" +
	//
	// " </Field>\r\n" +
	//
	// " <Field Name=\"last-modified\">" +
	//
	// " <Value>2022-05-08 19:11:40</Value>\r\n" +
	//
	// " </Field>\r\n" +
	//
	// " </Fields>\r\n" +
	//
	// "</Entity>";
	//
	//
	//
	// String outputXMLData = writeXml(doc, System.out);
	//
	// LogFile.LogWrite("Connection Controller - the xml data
	// itemsss"+outputXMLData);
	// byte[] b = xmldata.getBytes();
	//
	//
	// String almURL = "http://172.22.6.7:8080/qcbin/";
	// String authEndPoint = almURL + "authentication-point/alm-authenticate";
	// String qcSessionEndPoint = almURL + "rest/site-session";
	// /* authenticate begin */
	// URL authUrl = new URL(authEndPoint);
	// HttpURLConnection authConnection = (HttpURLConnection)
	// authUrl.openConnection();
	// authConnection.setRequestMethod("POST");
	// authConnection.setRequestProperty("Content-Type", "application/xml");
	// authConnection.setDoOutput(true);
	// OutputStream os = authConnection.getOutputStream();
	// try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
	// osw.write(
	// "<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");
	// }
	// authConnection.connect();
	//
	// LogFile.LogWrite(authConnection.getResponseMessage());
	// String lwssoCookie =
	// authConnection.getHeaderField("Set-Cookie").split(";")[0];
	// LogFile.LogWrite("Connection Controller - the lwssscookiess " + lwssoCookie);
	// /* authenticate end */
	// /* create session begin */
	// try {
	// HttpURLConnection createSession = (HttpURLConnection) new
	// URL(qcSessionEndPoint).openConnection();
	// createSession.setRequestProperty("Cookie", lwssoCookie);
	// // createSession.setRequestProperty("Content-Type", "application/json");
	// createSession.setRequestMethod("POST");
	// createSession.connect();
	// Map<String, List<String>> values = createSession.getHeaderFields();
	// String xsrfHeaderValue = "";
	// String cookies = "";
	// for (String cookie : values.get("Set-Cookie")) {
	// String content = cookie.split(";")[0];
	// cookies = cookies + content + ";";
	// LogFile.LogWrite("Connection Controller - the coookies value isss" +
	// cookies);
	// String[] nameValue = content.split("=");
	// String name = nameValue[0];
	// String value = nameValue[1];
	// if (name.equalsIgnoreCase("XSRF-TOKEN")) {
	// xsrfHeaderValue = value;
	// }
	// }
	//
	// /* create session end */
	// /* create defect begin */
	// HttpURLConnection createDefect = (HttpURLConnection) new URL(
	// "http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/"+ALMID)
	// .openConnection();
	// createDefect.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
	// createDefect.setRequestProperty("Cookie", cookies + lwssoCookie);
	// createDefect.setRequestProperty("Content-Type", "application/xml");
	// createDefect.setRequestProperty("Accept", "application/json");
	// createDefect.setRequestMethod("PUT");
	// createDefect.setDoOutput(true);
	// createDefect.setDoInput(true);
	// // createDefect.getOutputStream().write(b);
	//
	// LogFile.LogWrite("Connection Controller - the request header is" +
	// createDefect.getRequestProperties());
	// createDefect.connect();
	//
	// OutputStream os1 = createDefect.getOutputStream();
	//
	// os1.write(b);
	//
	// os1.flush();
	//
	//// os1.close();
	// InputStream inputStream = new
	// BufferedInputStream(createDefect.getInputStream());
	// BufferedReader reader1 = new BufferedReader(new
	// InputStreamReader(inputStream));
	// StringBuilder result1 = new StringBuilder();
	// String line1;
	// String jsonString1="";
	//
	// while ((line1 = reader1.readLine()) != null) {
	// result1.append(line1);
	// }
	//
	//
	// }catch(Exception e) {
	// LogFile.LogWrite(e);
	// }
	//

	// public void doBackWardSyncByEachID(Object object) throws
	// MalformedURLException, IOException {
	// Gson gson = new Gson();
	// String json = gson.toJson(object);
	// JSONObject obj1 = new JSONObject(json);
	// LogFile.LogWrite("Connection Controller - the object isss" + obj1);
	//
	// String getFieldURL = "http://172.22.6.21:7171/sdpapi/request/" +
	// obj1.get("WORKORDERID")
	// + "?&TECHNICIAN_KEY=04BAF692-6023-4065-A7A7-D421093A13AD&format=json";
	// HttpURLConnection connection = (HttpURLConnection) new
	// URL(getFieldURL).openConnection();
	// connection.setRequestProperty("Content-Type", "application/json");
	// connection.setRequestProperty("Accept", "application/json");
	// connection.setRequestMethod("GET");
	// connection.connect();
	// InputStream in = new BufferedInputStream(connection.getInputStream());
	// BufferedReader reader = new BufferedReader(new InputStreamReader(in));
	// StringBuilder result = new StringBuilder();
	// String line;
	// while ((line = reader.readLine()) != null) {
	// result.append(line);
	// }
	//
	// String jsonstring = result.toString();
	// JSONObject mainObject = new JSONObject(jsonstring);
	//
	// JSONObject resultObject = mainObject.getJSONObject("operation");
	// JSONObject detailsObject = resultObject.getJSONObject("details");
	// LogFile.LogWrite("Connection Controller - the request id data fectched here
	// <><<>" +
	// detailsObject);
	//
	// String almURL = "http://172.22.6.7:8080/qcbin/";
	// String authEndPoint = almURL + "authentication-point/alm-authenticate";
	// String qcSessionEndPoint = almURL + "rest/site-session";
	// /* authenticate begin */
	// URL authUrl = new URL(authEndPoint);
	// HttpURLConnection authConnection = (HttpURLConnection)
	// authUrl.openConnection();
	// authConnection.setRequestMethod("POST");
	// authConnection.setRequestProperty("Content-Type", "application/xml");
	// authConnection.setDoOutput(true);
	// OutputStream os = authConnection.getOutputStream();
	// try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
	// osw.write(
	// "<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");
	// }
	// authConnection.connect();
	//
	// LogFile.LogWrite(authConnection.getResponseMessage());
	// String lwssoCookie =
	// authConnection.getHeaderField("Set-Cookie").split(";")[0];
	// LogFile.LogWrite("Connection Controller - the lwssscookiess " + lwssoCookie);
	// /* authenticate end */
	// /* create session begin */
	// try {
	// HttpURLConnection createSession = (HttpURLConnection) new
	// URL(qcSessionEndPoint).openConnection();
	// createSession.setRequestProperty("Cookie", lwssoCookie);
	// // createSession.setRequestProperty("Content-Type", "application/json");
	// createSession.setRequestMethod("POST");
	// createSession.connect();
	// Map<String, List<String>> values = createSession.getHeaderFields();
	// String xsrfHeaderValue = "";
	// String cookies = "";
	// for (String cookie : values.get("Set-Cookie")) {
	// String content = cookie.split(";")[0];
	// cookies = cookies + content + ";";
	// LogFile.LogWrite("Connection Controller - the coookies value isss" +
	// cookies);
	// String[] nameValue = content.split("=");
	// String name = nameValue[0];
	// String value = nameValue[1];
	// if (name.equalsIgnoreCase("XSRF-TOKEN")) {
	// xsrfHeaderValue = value;
	// }
	// }
	//
	//
	// }
	// catch(Exception e) {
	// LogFile.LogWrite("Connection Controller - the exception "+e);
	// }
	//
	// }
	//
	
	
	
	
//	@Scheduled(fixedRate = 20000)
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/metoalmSync", method = RequestMethod.GET)
	public String defectToolAuthenticationa() throws MalformedURLException, IOException, ParserConfigurationException,
			TransformerException, ParseException, InterruptedException {
		System.out.println("******************************** getBackWardSync");
//		 UserProfileSettingController objmekey = new UserProfileSettingController();
//		 String Admin_MEKEY= objmekey.GetMeKey();
//		 LogFile.LogWrite("Connection Controller - INFO #5252  Admin_MEKEY  :" + Admin_MEKEY);
		
		try {
			LogFile.LogWrite("Connection Controller - ********** INFO MOVE MEtoALM IS START **********");

			Thread t1 = new Thread(new Runnable() {
			    @Override
			    public void run() {
			        // code goes here.
			    	try {
						moveMEtoALM();
						LogFile.LogWrite("Connection Controller - ********** moveMEtoALM Thread START **********");
					} catch (IOException | ParserConfigurationException | TransformerException | ParseException
							| InterruptedException ex) {
						// TODO Auto-generated catch block
						try {
							LogFile.LogWrite("Connection Controller - ERROR 1212  moveMEtoALM Thread  :" + ex.getMessage());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						ex.printStackTrace();
					}
			    }
			});  
			t1.start();
			
			
		//	moveMEtoALM();

			LogFile.LogWrite("Connection Controller - ********** INFO  MOVE MEtoALM IS COMPLETED **********");
		} catch (Exception ex) {
			LogFile.LogWrite("Connection Controller - ERROR 1212 MOVE MEtoALM IS COMPLETED  :" + ex.getMessage());
		}

		return "success";
	}

	public String getFieldName(String condition) throws IOException {
		String getFieldColumnName = "";
		try {

			String uri = "http://localhost:7373/getUserdefinedfieldName?condition=" + condition;
			LogFile.LogWrite("Connection Controller - INFO  getFieldName uri :" + uri);
			RestTemplate restTemplate = new RestTemplate();
			getFieldColumnName = restTemplate.getForObject(uri, String.class);
			LogFile.LogWrite("Connection Controller - INFO  COMPLETED the Field Name :" + getFieldColumnName);
			// Added by Mubarak 25-08-2022
			if(getFieldColumnName.equalsIgnoreCase(null) ||getFieldColumnName.isEmpty()) {
				getFieldColumnName=condition;
				LogFile.LogWrite("Connection Controller - Condition True getFieldColumnName.equalsIgnoreCase(null)  condition:" + condition);
			}
			// End 25-08-2022
			
		} catch (Exception ex) {
			LogFile.LogWrite("Connection Controller - ERROR 1312 getFieldName IS COMPLETED " + ex.getMessage());
		}

		return getFieldColumnName;

	}

	public void updateConnectionStatus(Connection conndata, String status) {

		connservice.updateConnectionStatus(conndata, status);

	}

	public void moveMEtoALM() throws MalformedURLException, IOException, ParserConfigurationException,
			TransformerException, ParseException, InterruptedException {
		LogFile.LogWrite("Connection Controller - ********** MEtoALM START HERE **********");
		Map<Object, Object> userdefineMap = new HashMap<Object, Object>();

		JSONObject nameObject = new JSONObject();
		JSONArray valueArrayObject = new JSONArray();
		JSONObject valueObject = new JSONObject();
		JSONObject valuesjsonObject = new JSONObject();
		JSONObject finalarrayObject = new JSONObject();
		JSONArray fieldarrayobject = new JSONArray();
		JSONObject finalObject = new JSONObject();
		String connectionName = "";

		// List<Connection> listConnectionData = connservice.getAllConnectionData();

		List<Connection> listConnectionData = connservice.getAllConnectionDataoff("ON");

		String delim = "-";
		if (listConnectionData.size() > 0) {
			StringBuilder sb = new StringBuilder();
			int ite = 0;
			while (ite < listConnectionData.size() - 1) {
				sb.append(listConnectionData.get(ite));
				sb.append(delim);
				ite++;
			}
			sb.append(listConnectionData.get(ite));
			String res = sb.toString();

			LogFile.LogWrite("Connection Controller - #3232 off Connection IS :" + res);
		} else {
			LogFile.LogWrite("Connection Controller - #3232 off Connection IS :" + "NULL");
		}

		for (int connectiondataIntiallization = 0; connectiondataIntiallization < listConnectionData
				.size(); connectiondataIntiallization++) {

			Connection conndata = listConnectionData.get(connectiondataIntiallization);

			DataSource masterDatasource = service.getDataSource(conndata.getMasterdatasource());
			DataSource targetDatasource = service.getDataSource(conndata.getTargetdatasource());

			String masterProjectName = conndata.getMasterprojectname();
			connectionName = conndata.getConnectionName();

			String connectioncondition = conndata.getMasterCondition();
			LogFile.LogWrite("Connection Controller - the connectioncondition iss<><> " + connectioncondition);

			JSONObject obj = new JSONObject(connectioncondition);

			JSONArray conditonarray = obj.getJSONArray("masterCondition");
			String querycondition = "";

			for (int conditionarrayIni = 0; conditionarrayIni < conditonarray.length(); conditionarrayIni++) {

				JSONObject conditionobject = conditonarray.getJSONObject(conditionarrayIni);

				String label = (String) conditionobject.get("MasterField");
				String conditonvalue = (String) conditionobject.get("MasterValue");

				String columnName = getFieldName(label);
				String fieldname = "";
				if (!columnName.isEmpty()) {

					fieldname = columnName;
					fieldname = "wf." + fieldname;
				} else {
					fieldname = label;
					fieldname = "wo." + fieldname;
				}
				querycondition = querycondition + fieldname + "='" + conditonvalue + "' and ";

			}

			updateConnectionStatus(conndata, "ACTIVE");

			String condition = querycondition + "acc.ORG_NAME ='" + conndata.getMasterprojectname()
					+ "' and wf.UDF_CHAR2 is not null and wf.UDF_Long1 is null";

			String uri = "http://localhost:7373/getServiceDeskIDS?condition=" + condition;
			RestTemplate restTemplate = new RestTemplate();
			List<?> getWorkorderIDS = restTemplate.getForObject(uri, List.class);

			JSONObject userdefineObject = new JSONObject(conndata.getUserDefinevalues());

			JSONArray userdefineArray = userdefineObject.getJSONArray("userdefinevalue");

			for (int userdefine = 0; userdefine < userdefineArray.length(); userdefine++) {

				JSONObject usersObject = userdefineArray.getJSONObject(userdefine);

				userdefineMap.put(usersObject.get("field"), usersObject.get("fieldValue"));

			}

			for (int workorderIDS = 0; workorderIDS < getWorkorderIDS.size(); workorderIDS++) {
				Date date_ = null;
				String workorder_Date = "";
				String d1_ = "";
				/*
				 * try {
				 * 
				 * String iduri = "http://localhost:7373/getModifiedTimeByMEId?meID="
				 * +getWorkorderIDS.get(workorderIDS); RestTemplate idrestTemplate = new
				 * RestTemplate(); String result = restTemplate.getForObject(iduri,
				 * String.class); String dateandtime = result; long seconddatetime =
				 * Long.parseLong(dateandtime); Timestamp stamp = new Timestamp(seconddatetime);
				 * date_ = new Date(stamp.getTime()); DateFormat f = new
				 * SimpleDateFormat("yyyy-MM-dd HH:MM:ss"); DateFormat f1 = new
				 * SimpleDateFormat("yyyy/MM/dd"); workorder_Date = f.format(date_); d1_ =
				 * f1.format(date_);
				 * LogFile.LogWrite("Connection Controller - INFO the ddd value is" +
				 * workorder_Date); } catch (Exception EX) {
				 * LogFile.LogWrite("Connection Controller - ERROR workorder_Date" +
				 * EX.getMessage());
				 * 
				 * }
				 */
				LogFile.LogWrite("Connection Controller - Try End 2020");

				Gson gson = new Gson();
				String json = gson.toJson(getWorkorderIDS.get(workorderIDS));
				JSONObject obj1 = new JSONObject(json);

				String getFieldURL = masterDatasource.getUrl() + "/sdpapi/request/" + obj1.get("WORKORDERID")
						+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json";
				// 04BAF692-6023-4065-A7A7-D421093A13AD OLD KEY
				LogFile.LogWrite(
						"Connection Controller - INFO 2121  masterDatasource.getUrl() IS " + masterDatasource.getUrl());
				LogFile.LogWrite(
						"Connection Controller - INFO 2121  obj1.get(\"WORKORDERID\") IS " + obj1.get("WORKORDERID"));
				// 04BAF692-6023-4065-A7A7-D421093A13AD
				HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Accept", "application/json");
				connection.setRequestMethod("GET");
				connection.connect();
				InputStream in = new BufferedInputStream(connection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}

				String jsonstring = result.toString();
				JSONObject mainObject = new JSONObject(jsonstring);

				JSONObject resultObject = mainObject.getJSONObject("operation");

				LogFile.LogWrite("Connection Controller - INFO 2121 resultObject IS " + resultObject);

				JSONObject detailsObject = resultObject.getJSONObject("details");

				LogFile.LogWrite("Connection Controller - INFO 2121 detailsObject IS " + detailsObject);

				String conndata1 = listConnectionData.get(connectiondataIntiallization).getMappingField();

				JSONObject conndataJOSN = new JSONObject(conndata1);

				JSONArray fieldObject = conndataJOSN.getJSONArray("Fields");
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

				// root elements
				Document doc = docBuilder.newDocument();
				Element rootElement = doc.createElement("Entity");
				doc.appendChild(rootElement);
				rootElement.setAttribute("Type", "defect");
				Element fieldsElement = doc.createElement("Fields");
				// add staff to root
				rootElement.appendChild(fieldsElement);
				Map<Object, Object> almFields = dscontrooler.getALMFields(targetDatasource);

				for (int i = 0; i < fieldObject.length(); i++) {
					JSONObject objects1 = fieldObject.getJSONObject(i);

					LogFile.LogWrite("Connection Controller - the  objects1 objects are" + objects1);
					valuesjsonObject = new JSONObject();
					valueObject = new JSONObject();
					LogFile.LogWrite("Connection Controller - the direction value is" + objects1.get("direction"));
					LogFile.LogWrite(
							"Connection Controller - the masterdatafield value is" + objects1.get("masterdatafield"));

					if ((objects1.get("direction").equals(1)) || (objects1.get("direction").equals(3))) {
						String masterDataField = (String) objects1.get("masterdatafield");
						String targetDataFieldValue = (String) detailsObject.get(masterDataField);

						LogFile.LogWrite(
								"the targetDataFieldValue targetDataFieldValue Field Value is" + targetDataFieldValue);
						LogFile.LogWrite(
								"the objects1.get(\"masterdatafield\")  objects1.get(\"masterdatafield\") Field Value is"
										+ objects1.get("masterdatafield"));

						LogFile.LogWrite(
								"the objects1.get(\"masterdatafield\")  objects1.get(\"masterdatafield\") Field Value is"
										+ objects1.get("masterdatafield"));
						String targetDataField = (String) objects1.get("targetdatafield");

						// finalObject.put(targetDataField, targetDataFieldValue);
						// Existing code working-------------------------
						for (Object key : userdefineMap.keySet()) {

							if (key.equals(masterDataField)) {
								targetDataFieldValue = (String) userdefineMap.get(key);
							}
						}

						LogFile.LogWrite("Connection Controller - the alm fields value is" + almFields);

						for (Object key : almFields.keySet()) {

							if (key.equals(targetDataField)) {
								LogFile.LogWrite("Connection Controller - the key value iss" + almFields.get(key));

								targetDataField = (String) almFields.get(key);
								LogFile.LogWrite("Connection Controller - targetDataField targetDataField iss"
										+ targetDataField);
							}
						}

						if ((targetDataField.equals("detected-by")) || (targetDataField.equals("owner"))) {

							try {

								valuesjsonObject.put("Name", targetDataField);
								valueObject.put("value", "Navin.kanna");
								Element fieldElementi = doc.createElement("Field");

								fieldsElement.appendChild(fieldElementi);

								fieldElementi.setAttribute("Name", "" + targetDataField + "");
								Element valueElementi = doc.createElement("Value");
								valueElementi.setTextContent("Navin.kanna");
								fieldElementi.appendChild(valueElementi);
							} catch (Exception ex) {
								LogFile.LogWrite("Connection Controller - ERROR CODE 1010" + ex.getMessage());
								throw ex;
							}

						} else if (targetDataField.equals("creation-time")) {

							try {
								String times = targetDataFieldValue;
								times = times.substring(0, 10);
								long timestamp = Long.parseLong(times);
								LocalDate date = Instant.ofEpochMilli(timestamp * 1000).atZone(ZoneId.systemDefault())
										.toLocalDate();
								String defectCreationDate = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								// defectCreationDate="2023-11-17 10:05:25.120";

								Element fieldElementi = doc.createElement("Field");

								fieldsElement.appendChild(fieldElementi);

								fieldElementi.setAttribute("Name", "" + targetDataField + "");
								Element valueElementi = doc.createElement("Value");
								valueElementi.setTextContent(defectCreationDate);
								fieldElementi.appendChild(valueElementi);
							} catch (Exception ex) {
								LogFile.LogWrite("Connection Controller - ERROR CODE 2020" + ex.getMessage());
								throw ex;
							}

						} else if (targetDataField.equals("defect status")) {

							try {
								JSONArray fieldmappingArray = objects1.getJSONArray("subFieldMapping");
								String subfiledtargetValue = "";
								for (int k = 0; k < fieldmappingArray.length(); k++) {

									JSONObject subfieldMappingObject = fieldmappingArray.getJSONObject(k);
									if (subfieldMappingObject.get("masterSubFieldMapping")
											.equals(targetDataFieldValue)) {
										subfiledtargetValue = (String) subfieldMappingObject
												.get("targetSubFieldMapping");
									}

								}
								Element fieldElementi = doc.createElement("Field");

								fieldsElement.appendChild(fieldElementi);

								fieldElementi.setAttribute("Name", "" + targetDataField + "");
								Element valueElementi = doc.createElement("Value");
								valueElementi.setTextContent("" + subfiledtargetValue + "");
								fieldElementi.appendChild(valueElementi);

							} catch (Exception ex) {
								LogFile.LogWrite("Connection Controller - ERROR CODE 4040" + ex.getMessage());
								throw ex;
							}

						} else {

							JSONArray fieldmappingArray = objects1.getJSONArray("subFieldMapping");
							if (fieldmappingArray.length() > 0) {

								String subfiledtargetValue = "";

								try {

									for (int k = 0; k < fieldmappingArray.length(); k++) {

										JSONObject subfieldMappingObject = fieldmappingArray.getJSONObject(k);

										if (subfieldMappingObject.get("masterSubFieldMapping")
												.equals(targetDataFieldValue)) {
											subfiledtargetValue = (String) subfieldMappingObject
													.get("targetSubFieldMapping");

										}

									}

								} catch (Exception ex) {
									LogFile.LogWrite("Connection Controller - ERROR #6265 masterSubFieldMapping LOOP  "
											+ ex.getMessage());
									throw ex;
								}

								valuesjsonObject.put("Name", targetDataField);
								valueObject.put("value", targetDataFieldValue);

								Element fieldElementi = doc.createElement("Field");

								fieldsElement.appendChild(fieldElementi);

								fieldElementi.setAttribute("Name", "" + targetDataField + "");
								Element valueElementi = doc.createElement("Value");
								valueElementi.setTextContent("" + subfiledtargetValue + "");
								fieldElementi.appendChild(valueElementi);
							}

							else {

								try {
									valuesjsonObject.put("Name", targetDataField);
									valueObject.put("value", targetDataFieldValue);

									Element fieldElementi = doc.createElement("Field");

									fieldsElement.appendChild(fieldElementi);

									fieldElementi.setAttribute("Name", "" + targetDataField + "");
									Element valueElementi = doc.createElement("Value");
									valueElementi.setTextContent("" + targetDataFieldValue + "");
									fieldElementi.appendChild(valueElementi);

								} catch (Exception ex) {
									LogFile.LogWrite("Connection Controller - ERROR #6263 targetDataField Name  "
											+ ex.getMessage());
									throw ex;
								}

							}

						}

						valuesjsonObject.put("values", valueObject);
						fieldarrayobject.put(valuesjsonObject);
					}

				}
				// Element fieldElement_servicedesk = doc.createElement("Field");
				//
				// fieldsElement.appendChild(fieldElement_servicedesk);
				//
				// fieldElement_servicedesk.setAttribute("Name", "user-01");
				// Element valueElement_servicedesk = doc.createElement("Value");
				// valueElement_servicedesk.setTextContent("" + obj1.get("WORKORDERID") + "");
				// fieldElement_servicedesk.appendChild(valueElement_servicedesk);

				String outputXMLData = writeXml(doc, System.out);

				LogFile.LogWrite("Connection Controller - the output xml data string is" + outputXMLData);
				// finalObject.put("servicedeskid", obj1.get("WORKORDERID"));
				// Existing code working-------------------------

				// valuesjsonObject.put("Name", "servicedeskid");
				// valueObject.put("value",obj1.get("WORKORDERID") );
				// valueArrayObject.put(valueObject);
				valuesjsonObject.put("values", valueObject);
				fieldarrayobject.put(valuesjsonObject);
				valuesjsonObject.put("values", valueObject);

				finalObject.put("Fields", fieldarrayobject);
				finalObject.put("Type", "defect");
				finalObject.put("children-count", 0);

				String finalString = finalObject.toString();
				LogFile.LogWrite("Connection Controller - the final object data issss<><>" + finalObject);

				DataSource targetDatasource1 = service
						.getDataSource(listConnectionData.get(connectiondataIntiallization).getTargetdatasource());
				LogFile.LogWrite("Connection Controller - the authorization issss" + targetDatasource1);
				// HttpURLConnection authConnection = isValidUser(targetDatasource);
				//
				//
				// if (authConnection.getResponseCode() == 200) {
				// String token = generateXSRFTOKEN(authConnection);
				// // getAllDomain(token);
				// LogFile.LogWrite("Connection Controller - the token value
				// issss<><><><"+token);getSubFields
				//
				// String movedataURL = targetDatasource.getUrl() + "/qcbin/rest/domains/" +
				// targetDatasource.getDomainname() + "/projects/"
				// + targetDatasource.getProjectname() + "/defects";
				// //String getsubfieldURL=
				// "http://172.22.6.7:8080/qcbin/rest/domains/INTERTEK/projects/Evo2_Prod_Support/customization/entities/defect/lists";
				// LogFile.LogWrite("Connection Controller - the move data url
				// iss"+movedataURL);
				//
				// HttpURLConnection postconection = (HttpURLConnection) new
				// URL(movedataURL).openConnection();
				// // String concatenatedHeaderCookieString = "SiteSession="+qcSession+";
				// LWSSO_COOKIE_KEY="+lwssoCookie;
				// String concatenatedHeaderCookieString = "QCSession=" + qcSession + ";" +
				// "ALM_USER=" + ";" + almUser + ";" + "XSRF-TOKEN=" + xsrfHeaderValue + ";"+
				// "LWSSO_COOKIE_KEY=" + lwssoCookie;
				// postconection.setRequestProperty("X-XSRF-TOKEN", token);
				// postconection.setRequestProperty("Cookie", cookies + lwssoCookie);
				//
				// postconection.setRequestProperty("Content-Type", "application/json");
				// postconection.setRequestProperty("Accept", "application/json");
				// postconection.setRequestMethod("POST");
				// postconection.setDoOutput(true);
				// postconection.setDoInput(true);
				//
				//
				// OutputStream outputStream = postconection.getOutputStream();
				// BufferedWriter writer = new BufferedWriter(new
				// OutputStreamWriter(outputStream, "UTF-8"));
				// writer.write(finalString);
				// // writer.flush();
				// postconection.connect();
				// LogFile.LogWrite("Connection Controller - the response code
				// isss"+postconection.getResponseCode());
				//
				//
				// LogFile.LogWrite("Connection Controller - the response Message
				// isss"+postconection.getResponseMessage());

				// JSONObject datas = new JSONObject();
				// datas.put("type", "defect");
				// datas.put("name", "Testing from Dev Team");
				// datas.put("severity", "1-Low");
				// datas.put("detected-by", "Navin Kanna");
				// datas.put("creation-time", "2022-04-22");
				// String createDefectRequest = datas.toString();
				//
				// String xmldata = "<?xml version=\"1.0\" encoding=\"UTF-8\"
				// standalone=\"no\"?>"
				// + "<Entity Type=\"defect\">\r\n" +
				//
				// " <Fields>" +
				//
				// " <Field Name=\"detected-by\">" +
				//
				// " <Value>suresh.a</Value>" +
				//
				// " </Field>\r\n" +
				//
				// " <Field Name=\"creation-time\">" +
				//
				// " <Value>2022-04-25</Value>\r\n" +
				//
				// " </Field>\r\n" +
				//
				// " <Field Name=\"severity\">\r\n" +
				//
				// " <Value>Medium</Value>\r\n" +
				//
				// " </Field>\r\n" +
				//
				// " <Field Name=\"name\">\r\n" +
				//
				// " <Value>Mani Navin.</Value>\r\n" +
				//
				// " </Field>\r\n" +
				//
				// " </Fields>\r\n" +
				//
				// "</Entity>";
				// JSONObject xmltoJSON = XML.toJSONObject(xmldata);
				//
				// LogFile.LogWrite("Connection Controller - the xml conversion ..json data" +
				// xmltoJSON);
				// String jsonString = xmldata.toString();
				// LogFile.LogWrite(jsonString);

				byte[] b = outputXMLData.getBytes();

				String almURL = targetDatasource.getUrl() + "/qcbin/";
				// String almURL = "http://172.22.6.7:8080/qcbin/";
				String authEndPoint = almURL + "authentication-point/alm-authenticate";
				String qcSessionEndPoint = almURL + "rest/site-session";
				/* authenticate begin */
				URL authUrl = new URL(authEndPoint);
				HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
				authConnection.setRequestMethod("POST");
				authConnection.setRequestProperty("Content-Type", "application/xml");
				authConnection.setDoOutput(true);
				OutputStream os = authConnection.getOutputStream();
				try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
					osw.write("<alm-authentication><user>" + targetDatasource.getUsername() + "</user><password>"
							+ targetDatasource.getPassword() + "</password></alm-authentication>");
				}
				authConnection.connect();

				LogFile.LogWrite(authConnection.getResponseMessage());
				String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
				LogFile.LogWrite("Connection Controller - the lwssscookiess " + lwssoCookie);
				/* authenticate end */
				/* create session begin */
				try {
					HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
					createSession.setRequestProperty("Cookie", lwssoCookie);
					// createSession.setRequestProperty("Content-Type", "application/json");
					createSession.setRequestMethod("POST");
					createSession.connect();
					Map<String, List<String>> values = createSession.getHeaderFields();
					String xsrfHeaderValue = "";
					String cookies = "";
					for (String cookie : values.get("Set-Cookie")) {
						String content = cookie.split(";")[0];
						cookies = cookies + content + ";";
						LogFile.LogWrite("Connection Controller - the coookies value isss" + cookies);
						String[] nameValue = content.split("=");
						String name = nameValue[0];
						String value = nameValue[1];
						if (name.equalsIgnoreCase("XSRF-TOKEN")) {
							xsrfHeaderValue = value;
						}
					}

					/* create session end */
					/* create defect begin */
					HttpURLConnection createDefect = (HttpURLConnection) new URL(
							targetDatasource.getUrl() + "/qcbin/" + "rest/domains/" + targetDatasource.getDomainname()
									+ "/projects/" + targetDatasource.getProjectname() + "/defects/").openConnection();

					/*
					 * ADED AND COMMANDED BY MUBARAK
					 * "http://172.22.6.7:8080/qcbin/rest/domains/"+targetDatasource.getDomainname()
					 * +"/projects/"+targetDatasource.getProjectname()+"/defects/")
					 * .openConnection();
					 */

					createDefect.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
					createDefect.setRequestProperty("Cookie", cookies + lwssoCookie);
					createDefect.setRequestProperty("Content-Type", "application/xml");
					createDefect.setRequestProperty("Accept", "application/json");
					createDefect.setRequestMethod("POST");
					createDefect.setDoOutput(true);
					createDefect.setDoInput(true);
					// createDefect.getOutputStream().write(b);

					LogFile.LogWrite(
							"Connection Controller - the request header is" + createDefect.getRequestProperties());
					createDefect.connect();

					OutputStream os1 = createDefect.getOutputStream();

					os1.write(b);

					os1.flush();

					// os1.close();
					InputStream inputStream = new BufferedInputStream(createDefect.getInputStream());
					BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
					StringBuilder result1 = new StringBuilder();
					String line1;

					while ((line1 = reader1.readLine()) != null) {
						result1.append(line1);
					}
					String almID = "";
					String jsonstring1 = result1.toString();
					LogFile.LogWrite("Connection Controller - the json string object is" + jsonstring1);

					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
					LocalDateTime now = LocalDateTime.now();
					String eventhandledatetime = now.toString();
					LogFile.LogWrite("Connection Controller - the xml data itemsss" + outputXMLData);
					JSONObject xmlJSONObj = XML.toJSONObject(outputXMLData);
					String auditData = xmlJSONObj.toString();

					ConnectionAudits connaudit = new ConnectionAudits();
					connaudit.setAuditdatetime(eventhandledatetime);
					connaudit.setMEID(obj1.get("WORKORDERID").toString());
					connaudit.setALMID(almID);
					connaudit.setSyncDate(auditData);
					connaudit.setDirection("ALM <= ME");
					// DO Not Change the Content its For Substring in React audit Table // By Mubarak 23-07-2022
					connaudit.setConnectionauditdescription("Fields are Sync from ME to ALM. ME id    "
							+ obj1.get("WORKORDERID") + ".Those fields are" + auditData);
					connaudit.setConnectionname(connectionName);
					connauditsImpl.saveconnectionAudit(connaudit);

					JSONObject createALMId_returnJSON = new JSONObject(jsonstring1);
					JSONArray fieldArrayObject = createALMId_returnJSON.getJSONArray("Fields");
					JSONObject masterSyncDetailsObject = new JSONObject();
					JSONObject masterSyncOperationObject = new JSONObject();
					JSONObject mastersyncObject = new JSONObject();
					for (int i = 0; i < fieldObject.length(); i++) {

						JSONObject objects1 = fieldObject.getJSONObject(i);
						String masterDataField = (String) objects1.get("masterdatafield");

						String targetDataField = (String) objects1.get("targetdatafield");
						String targetDataFieldValue = "";
						LogFile.LogWrite(
								"Connection Controller - INFO the target data field value is" + targetDataField);
						String updatetime = "";

						if ((objects1.get("direction").equals(2)) || (objects1.get("direction").equals(3))) {
							for (int j = 0; j < fieldArrayObject.length(); j++)

							{
								// mastersyncObject = new JSONObject();
								JSONObject item = fieldArrayObject.getJSONObject(j);
								String nameObject1 = item.getString("Name");

								LogFile.LogWrite("Connection Controller - INFO the alm fields value is" + almFields);

								for (Object key : almFields.keySet()) {

									if (key.equals(targetDataField)) {
										LogFile.LogWrite(
												"Connection Controller - the key value iss" + almFields.get(key));

										targetDataField = (String) almFields.get(key);
										LogFile.LogWrite(
												"Connection Controller - INFO targetDataField targetDataField iss"
														+ targetDataField);
									}
								}

								if (nameObject1.equals(targetDataField)) {
									LogFile.LogWrite("Connection Controller - INFO the nameObject1 field value is"
											+ nameObject1);
									JSONArray valuesarrayObject = item.getJSONArray("values");

									JSONObject valuejsonobject = valuesarrayObject.getJSONObject(0);
									ArrayList<String> list = new ArrayList<String>(valuejsonobject.keySet());
									if (nameObject1.equals("id")) {
										almID = (String) valuejsonobject.get("value");
									}
									if (nameObject1.equals("defect status")) {

										JSONArray fieldmappingArray = objects1.getJSONArray("subFieldMapping");
										String subfiledtargetValue = "";
										for (int k = 0; k < fieldmappingArray.length(); k++) {

											JSONObject subfieldMappingObject = fieldmappingArray.getJSONObject(k);
											if (subfieldMappingObject.get("targetSubFieldMapping")
													.equals(targetDataFieldValue)) {
												subfiledtargetValue = (String) subfieldMappingObject
														.get("masterSubFieldMapping");
											}

										}
										targetDataFieldValue = subfiledtargetValue;
									}

									if (list.contains("value")) {
										targetDataFieldValue = (String) valuejsonobject.get("value");

									}

								}

							}
							if(targetDataFieldValue==null||targetDataFieldValue=="") {
								// Do Nothing Mubarak 19-09-2022
							}else {
								mastersyncObject.put(masterDataField, targetDataFieldValue);
							}
							
						}
					}
					masterSyncDetailsObject.put("details", mastersyncObject);

					masterSyncOperationObject.put("operation", masterSyncDetailsObject);
					String stringmasterSyncOperationObject = masterSyncOperationObject.toString();

					LogFile.LogWrite("Connection Controller - the object is()" + stringmasterSyncOperationObject);
					byte[] mastersyncbytesdata = stringmasterSyncOperationObject.getBytes();
					try {
						updateMEusingDriver(stringmasterSyncOperationObject, obj1.get("WORKORDERID"));

						dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
						now = LocalDateTime.now();
						eventhandledatetime = now.toString();
						LogFile.LogWrite("Connection Controller - the xml data itemsss" + outputXMLData);

						auditData = stringmasterSyncOperationObject;

						connaudit = new ConnectionAudits();
						connaudit.setAuditdatetime(eventhandledatetime);
						connaudit.setMEID(obj1.get("WORKORDERID").toString());
						connaudit.setALMID(almID);
						connaudit.setSyncDate(auditData);
						connaudit.setDirection("ALM <= ME");
						// DO Not Change the Content its For Substring in React audit Table // By Mubarak 23-07-2022
						connaudit.setConnectionauditdescription("Fields are Sync from ME to ALM. ME id    "
								+ obj1.get("WORKORDERID") + "The ALM id is" + almID + ".Those fields are" + auditData);
						// connaudit.setConnectionauditdescription("Fields are Mapping from ME to
						// ALM.Those fields are"+auditData);
						connaudit.setConnectionname(connectionName);
						connauditsImpl.saveconnectionAudit(connaudit);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					Boolean status = isAttachmentINME(obj1.get("WORKORDERID"), almID, targetDatasource);
					if (status) {
						LogFile.LogWrite("Connection Controller - INFO the status is" + status + " -isAttachmentINME ");
					}

					// String getFieldURL1 = "http://172.22.6.21:7171/sdpapi/request/"+
					// obj1.get("WORKORDERID")
					// + "?&TECHNICIAN_KEY=94ABBD34-6409-464E-AA23-8E0C6CE83A34&format=json";
					// HttpURLConnection updateDefect = (HttpURLConnection) new
					// URL(getFieldURL1).openConnection();
					//
					// updateDefect.setRequestProperty("Content-Type", "application/json");
					// updateDefect.setRequestProperty("Accept", "application/json");
					// updateDefect.setRequestMethod("PUT");
					// updateDefect.setDoOutput(true);
					// updateDefect.setDoInput(true);
					// // createDefect.getOutputStream().write(b);
					//
					// LogFile.LogWrite("Connection Controller - the request header is" +
					// updateDefect.getRequestProperties());
					// updateDefect.connect();
					// OutputStream osCreateDefect = updateDefect.getOutputStream();
					// try(OutputStreamWriter osCreateDefectWriter = new
					// OutputStreamWriter(osCreateDefect, "UTF-8")){
					// osCreateDefectWriter.write(stringmasterSyncOperationObject);
					// }
					//
					//
					// LogFile.LogWrite("Connection Controller - the response code isss
					// "+updateDefect.getResponseCode());
					//
					//
					// InputStream inputStream1 = new
					// BufferedInputStream(updateDefect.getInputStream());
					// BufferedReader reader11 = new BufferedReader(new
					// InputStreamReader(inputStream1));
					// StringBuilder result11 = new StringBuilder();
					// String line11;
					//
					// while ((line11 = reader11.readLine()) != null) {
					// result11.append(line11);
					// }
					//
					// String jsonstring11 = result11.toString();
					// LogFile.LogWrite("Connection Controller - the json string object
					// is"+jsonstring11);

					// HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new
					// URL("http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/33").openConnection();
					// requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
					// requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
					// //requiredFieldsConnection.setRequestProperty("Content-Type",
					// "application/JSON");
					// requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
					// requiredFieldsConnection.setRequestMethod("GET");
					// requiredFieldsConnection.connect();
					//
					// LogFile.LogWrite("Connection Controller - the connection executing here
					// ********");
					// InputStream inputStream = new
					// BufferedInputStream(requiredFieldsConnection.getInputStream());
					// BufferedReader reader1 = new BufferedReader(new
					// InputStreamReader(inputStream));
					// StringBuilder result1 = new StringBuilder();
					// String line1;
					//
					// while ((line1 = reader1.readLine()) != null) {
					// result1.append(line1);
					// }
					//
					// String jsonstring1 = result1.toString();
					// LogFile.LogWrite("Connection Controller - the json string object
					// is"+jsonstring1);

					// createDefect.connect();

				} catch (RuntimeException e) {
					LogFile.LogWrite("Connection Controller - ERROR #2122 the exception is" + e);
					throw e;
				} catch (IOException e) {
					LogFile.LogWrite("Connection Controller - ERROR #3133 the exception is" + e);
					throw e;

				}
			}
			updateConnectionStatus(conndata, "INACTIVE");

		}
		LogFile.LogWrite("Connection Controller - ********** INFO #2020 MOVE MEtoALM END **********");
	}

	
	public static  String ReplaceStringData(String updateddata) throws IOException {
		
		try {
            String updateddataReplace=updateddata;
			
//            StringBuilder sb = new StringBuilder(updateddataReplace);
//            Pattern.compile("$").matcher(sb).replaceAll("%24");
//            Pattern.compile("<").matcher(sb).replaceAll("%3C");
//        	Pattern.compile("!").matcher(sb).replaceAll("%21");
//			Pattern.compile("%").matcher(sb).replaceAll("%25");
//			Pattern.compile("&amp;").matcher(sb).replaceAll("&");
//			Pattern.compile("'").matcher(sb).replaceAll("%27");
//			Pattern.compile("*").matcher(sb).replaceAll("%2a");
//			Pattern.compile("+").matcher(sb).replaceAll("%2b");
//			Pattern.compile(",").matcher(sb).replaceAll("%2c");
//			Pattern.compile("-").matcher(sb).replaceAll("%2d");
//			Pattern.compile(".").matcher(sb).replaceAll("%2e");
//			Pattern.compile("/").matcher(sb).replaceAll("%2f");
//			Pattern.compile(":").matcher(sb).replaceAll("%3a");
//			Pattern.compile(";").matcher(sb).replaceAll("%3b");
//			Pattern.compile("<").matcher(sb).replaceAll("%3c");
//			Pattern.compile("=").matcher(sb).replaceAll("%3D");
//			Pattern.compile(">").matcher(sb).replaceAll("%3E");
//			Pattern.compile("?").matcher(sb).replaceAll("%3F");
//			Pattern.compile("@").matcher(sb).replaceAll("%40");
//			Pattern.compile("[").matcher(sb).replaceAll("%5b");
//			Pattern.compile("]").matcher(sb).replaceAll("%5d");
			
			
			
			updateddataReplace.replace("$", "%24");
			updateddataReplace.replace("<", "%3C");
			updateddataReplace.replace(" ", "%20");
			updateddataReplace.replace("!", "%21");
//			updateddataReplace.replace("\"\"", "%22");
			updateddataReplace.replace("%", "%25");
			updateddataReplace.replace("&", "%26");		
			updateddataReplace.replace("'", "%27");
			updateddataReplace.replace("*", "%2A");
			updateddataReplace.replace("+", "%2B");
			updateddataReplace.replace(",", "%2C");		
			updateddataReplace.replace("-", "%2D");
			updateddataReplace.replace(".", "%2E");
			updateddataReplace.replace("/", "%2F");
			updateddataReplace.replace(":","%3A");	
			updateddataReplace.replace(";","%3B");	
			updateddataReplace.replace("<","%3C");	
			updateddataReplace.replace("=","%3D");	
			updateddataReplace.replace(">","%3E");	
			updateddataReplace.replace("?","%3F");	
			updateddataReplace.replace("@","%40");
			updateddataReplace.replace("[","%5b");
			updateddataReplace.replace("]","%5d");
            
            
            
			return updateddataReplace.toString();
            
            
            
            
            
            
		}catch(Exception ex) {
			
			LogFile.LogWrite("Connection Controller - ERROR Original Data : ReplaceStringData"+ex.getMessage());
			return updateddata;
		}
		
		
	}
	
	public void updateMEusingDriver(String updateddata, Object id)
			throws InterruptedException, MalformedURLException, IOException {

		try {
			LogFile.LogWrite("Connection Controller - RAW  Data : "+updateddata);
			//updateddata=ReplaceStringData(updateddata);
			
		updateddata.replace("&lt;", "<");
		updateddata.replace("&gt;", ">");
			
			String ModifiedData = updateddata.replaceAll("\\[", "(").replaceAll("\\]",")");
			
			if(ModifiedData.contains("&lt;")){
				ModifiedData= ModifiedData.replaceAll("&lt;", "<");	
			}
			if(ModifiedData.contains("&gt;")){
				ModifiedData= ModifiedData.replaceAll("&gt;", ">");
			}
							
			if(ModifiedData.contains("&amp;")) {
				ModifiedData= ModifiedData.replaceAll("&amp;", "&");
			}
			
			
			
			
			LogFile.LogWrite("Connection Controller - Original Data : "+ModifiedData);

		//	Added By Mubarak 15-11-2022		
			
// *********************************************** Update Web Driver Code ***********************************************
			LogFile.LogWrite("Connection Controller - INFO the updateMEusingDriver START HERE ");
			//System.setProperty("webdriver.chrome.driver", "E:/chromedriver.exe");
			
			
			    WebDriverManager.chromedriver().setup();
		        WebDriver driver=new ChromeDriver();
		       // driver.get("https://www.google.com/");		       
			
			
			LogFile.LogWrite("Connection Controller - INFO the updatedata is :" + ModifiedData);

			driver.get("http://172.22.6.21:7171/html/APICall.html");
			driver.manage().window().maximize();

			Thread.sleep(1000);
			driver.findElement(By.name("url")).sendKeys("http://172.22.6.21:7171/sdpapi/request/" + id);
			LogFile.LogWrite("Connection Controller - INFO the request ID IS  :" + id);
			Select methodSelect = new Select(driver.findElement(By.name("method")));
			methodSelect.selectByVisibleText("PUT");

			Select authmethodSelect = new Select(driver.findElement(By.name("authmethod")));
			authmethodSelect.selectByVisibleText("TECHNICIAN_KEY");

			driver.findElement(By.name("techniciankey")).sendKeys("A0AC8B5E-1055-4432-A472-7AFC556DC417");

			Select formatSelect = new Select(driver.findElement(By.name("format")));
			formatSelect.selectByVisibleText("JSON");

			driver.findElement(By.name("parameters")).sendKeys("data=" + ModifiedData);

			driver.findElement(By.xpath("//input[@value='Submit']")).click();
			Thread.sleep(3000);
			// LogFile.LogWrite(driver.findElement(By.name("response")).getText());
			driver.close();
			
			
			
			
	//		commanded By Mubarak 15-11-2022			
			
//			******************  OLD DRIVER CODE ---- COMMANDED BY Mubarak For web driver  *********************************
			
			
//			LogFile.LogWrite("Connection Controller - INFO the updateMEusingDriver START HERE ");
//			System.setProperty("webdriver.chrome.driver", "E:/chromedriver.exe");
//			WebDriver driver = new ChromeDriver();
//			LogFile.LogWrite("Connection Controller - INFO the updatedata is :" + ModifiedData);
//
//			driver.get("http://172.22.6.21:7171/html/APICall.html");
//			driver.manage().window().maximize();
//
//			Thread.sleep(1000);
//			driver.findElement(By.name("url")).sendKeys("http://172.22.6.21:7171/sdpapi/request/" + id);
//			LogFile.LogWrite("Connection Controller - INFO the request ID IS  :" + id);
//			Select methodSelect = new Select(driver.findElement(By.name("method")));
//			methodSelect.selectByVisibleText("PUT");
//
//			Select authmethodSelect = new Select(driver.findElement(By.name("authmethod")));
//			authmethodSelect.selectByVisibleText("TECHNICIAN_KEY");
//
//			driver.findElement(By.name("techniciankey")).sendKeys("A0AC8B5E-1055-4432-A472-7AFC556DC417");
//
//			Select formatSelect = new Select(driver.findElement(By.name("format")));
//			formatSelect.selectByVisibleText("JSON");
//
//			driver.findElement(By.name("parameters")).sendKeys("data=" + ModifiedData);
//
//			driver.findElement(By.xpath("//input[@value='Submit']")).click();
//			Thread.sleep(3000);
//			// LogFile.LogWrite(driver.findElement(By.name("response")).getText());
//			driver.close();
			
			
			
			
			LogFile.LogWrite("Connection Controller - updateddata updateddata updateddata" + ModifiedData);
			LogFile.LogWrite("Connection Controller - ********** the me updated data starts from here **********");
		} catch (Exception ex) {

			LogFile.LogWrite("Connection Controller - ERROR  updateMEusingDriver START HERE :" + ex.getMessage());
		}

		/*
		 * 
		 * //String getFieldURL = "http://172.22.6.21:7171/sdpapi/request/" + id // +
		 * "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json";
		 * 
		 * String getFieldURL = "http://172.22.6.21:7171/api/v3/requests/ "+ id;
		 * 
		 * 
		 * 
		 * HttpURLConnection updateDefect = (HttpURLConnection) new
		 * URL(getFieldURL).openConnection();
		 * updateDefect.setRequestProperty("Content-Type", "application/json"); // Added
		 * 
		 * 
		 * 
		 * 
		 * 
		 * updateDefect.setRequestProperty("OPERATION_NAME", "EDIT_REQUEST");
		 * updateDefect.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		 * updateDefect.setRequestProperty("INPUT_DATA",
		 * "{\"operation\":{\"details\":{\"defect status\":\"new\",\"alm id\":\"10\",\"priority\":\"Critical\",\"alm / jira comments\":\"good12345\"}}}"
		 * ); updateDefect.setRequestProperty("Accept",
		 * "application/vnd.manageengine.sdp.v3+json");
		 * updateDefect.setRequestProperty("TECHNICIAN_KEY",
		 * "A0AC8B5E-1055-4432-A472-7AFC556DC417");
		 * updateDefect.setRequestMethod("POST"); // ENDED
		 * 
		 * 
		 * 
		 * 
		 * //updateDefect.setRequestProperty("Accept", "application/json");
		 * //updateDefect.setRequestMethod("PUT"); updateDefect.setDoOutput(true);
		 * 
		 * 
		 * updateDefect.setDoInput(true);
		 * 
		 * 
		 * try {
		 * 
		 * updateDefect.connect();
		 * 
		 * 
		 * 
		 * byte[] b = updateddata.getBytes();
		 * 
		 * OutputStream os1 = updateDefect.getOutputStream();
		 * 
		 * os1.write(b);
		 * 
		 * os1.flush();
		 * 
		 * 
		 * 
		 * 
		 * LogFile.LogWrite("Connection Controller - *************try **************");
		 * }catch(Exception ex) { LogFile.
		 * LogWrite("Connection Controller - **************catch Block **************");
		 * }
		 * 
		 * 
		 * 
		 * 
		 * 
		 * System.out.
		 * println("************** the me updated data starts from here **************"
		 * );
		 * 
		 * InputStream in = new BufferedInputStream(updateDefect.getInputStream());
		 * BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		 * StringBuilder result = new StringBuilder(); String line; while ((line =
		 * reader.readLine()) != null) { result.append(line); }
		 * 
		 * Map<String, String> fileNameFileContentME = new HashMap<String, String>();
		 * String jsonstring = result.toString(); JSONObject mainObject = new
		 * JSONObject(jsonstring);
		 * 
		 * JSONObject resultObject = mainObject.getJSONObject("operation");
		 * 
		 * LogFile.LogWrite("Connection Controller - the return object data" +
		 * jsonstring); System.out.
		 * println("************** the me updated data starts from here **************"
		 * );
		 */
	}

	public boolean findAttachmentMEandAttachTOALM(Object id, String almID, DataSource targetDataSource)
			throws MalformedURLException, IOException {

		List<String> attachmentfilenameME = new LinkedList<String>();

		// String KEY_ROLL="administrator";
		// String
		// Me_TECHNICIAN_KEY=UserProfileSettingController.getMeKey(KEY_ROLL.trim());
		//
		// LogFile.LogWrite("Connection Controller -Me_TECHNICIAN_KEY:
		// "+Me_TECHNICIAN_KEY);
		String getFieldURL = "http://172.22.6.21:7171/sdpapi/request/" + id + "/attachments"
				+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json";
		
		
		LogFile.LogWrite("Connection Controller - getFieldURL Attachment :" + getFieldURL);
		
		HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		Map<String, String> fileNameFileContentME = new HashMap<String, String>();
		String jsonstring = result.toString();
		JSONObject mainObject = new JSONObject(jsonstring);

		JSONObject resultObject = mainObject.getJSONObject("operation");

		LogFile.LogWrite("Connection Controller - the return object data" + jsonstring);
		List<String> list = new ArrayList<String>(resultObject.keySet());

		LogFile.LogWrite("Connection Controller - the list operation is" + list);
		if (list.contains("details")) {

			try {

				JSONArray detailsJsonArrayObject = resultObject.getJSONArray("details");

				for (int i = 0; i < detailsJsonArrayObject.length(); i++) {

					JSONObject attachmentobject = detailsJsonArrayObject.getJSONObject(i);

					String filename = attachmentobject.getString("filename");
					attachmentfilenameME.add(filename);

					String baseMEURl = "http://172.22.6.21:7171/api/v3/attachment/"
							+ attachmentobject.getString("attachmentid")
							+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json&tm=1651149399172";
					LogFile.LogWrite("Connection Controller - the url is<><><" + baseMEURl);
					HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
					authConnection.setRequestMethod("GET");

					try {
						authConnection.connect();
					} catch (Exception ex) {
						LogFile.LogWrite(
								"Connection Controller - ERROR #1213 detailsJsonArrayObject  " + ex.getMessage());
						throw ex;
					}

					InputStream in1 = new BufferedInputStream(authConnection.getInputStream());
					BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
					StringBuilder result1 = new StringBuilder();
					String line1;
					// fieldsList = new ArrayList<String>();
					while ((line1 = reader1.readLine()) != null) {
						result1.append(line1);
					}

					String jsonstring1 = result1.toString();

					fileNameFileContentME.put(filename, jsonstring1);

				}
				
		
				
				List<String> getAttachmentFileNameINALM = findAttachmentINALM(almID, targetDataSource);
				LogFile.LogWrite(
						"Connection Controller - CODE 2121 getAttachmentFileNameINALM  " + getAttachmentFileNameINALM);
				if (getAttachmentFileNameINALM.size() > 0) {

					try {

						for (String filenameME : getAttachmentFileNameINALM) {
							if (attachmentfilenameME.contains(filenameME)) {

								attachmentfilenameME.remove(filenameME);
							}
						}
						LogFile.LogWrite(
								"Connection Controller - CODE 2122 getAttachmentFileNameINALM  " );

						for (int k = 0; k < attachmentfilenameME.size(); k++) {

							String filename = attachmentfilenameME.get(k);

							String filecontent = fileNameFileContentME.get(filename);
							fileAttachmentME_ALM(filename, filecontent, almID, targetDataSource);
						}

						LogFile.LogWrite(
								"Connection Controller - CODE 2121 getAttachmentFileNameINALM  2023" );
						
					} catch (Exception ex) {
						LogFile.LogWrite(
								"Connection Controller - ERROR #1215 getAttachmentFileNameINALM  " + ex.getMessage());
						throw ex;
					}

				} else {

					try {

						for (int k = 0; k < attachmentfilenameME.size(); k++) {
							LogFile.LogWrite("Connection Controller - attachmentfilenameME   " +attachmentfilenameME);
							LogFile.LogWrite("Connection Controller - attachmentfilenameME LENGTH  " +attachmentfilenameME.size());
							String filename = attachmentfilenameME.get(k);
							String filecontent = fileNameFileContentME.get(filename);
							LogFile.LogWrite("Connection Controller - attachmentfilenameME filename:" +filename+"filecontent :"+ filecontent+"almID :"+ almID+"targetDataSource :"+targetDataSource);
							fileAttachmentME_ALM(filename, filecontent, almID, targetDataSource);
						}

					} catch (Exception ex) {
						LogFile.LogWrite("Connection Controller - ERROR #1216 getALMFields  " + ex.getMessage());
						throw ex;
					}

				}

				return true;

			} catch (Exception ex) {

				LogFile.LogWrite("Connection Controller - ERROR #4141 details  " + ex.getMessage());
				throw ex;
			}

		} else {
			return false;
		}

	}

	public boolean isAttachmentINME(Object id, String almID, DataSource targetDataSource)
			throws MalformedURLException, IOException {

		String getFieldURL = "http://172.22.6.21:7171/sdpapi/request/" + id + "/attachments"
				+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json";
		HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		String jsonstring = result.toString();
		JSONObject mainObject = new JSONObject(jsonstring);

		JSONObject resultObject = mainObject.getJSONObject("operation");

		LogFile.LogWrite("Connection Controller - the return object data" + jsonstring);
		List<String> list = new ArrayList<String>(resultObject.keySet());

		LogFile.LogWrite("Connection Controller - the list operation is" + list);
		if (list.contains("details")) {
			JSONArray detailsJsonArrayObject = resultObject.getJSONArray("details");

			for (int i = 0; i < detailsJsonArrayObject.length(); i++) {

				JSONObject attachmentobject = detailsJsonArrayObject.getJSONObject(i);

				LogFile.LogWrite("Connection Controller - the details operation is"
						+ attachmentobject.getString("attachmentid"));

				String filename = attachmentobject.getString("filename");

				String baseMEURl = "http://172.22.6.21:7171/api/v3/attachment/"
						+ attachmentobject.getString("attachmentid")
						+ "?&TECHNICIAN_KEY=A0AC8B5E-1055-4432-A472-7AFC556DC417&format=json&tm=1651149399172";
				LogFile.LogWrite("Connection Controller - the url is<><><" + baseMEURl);
				HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
				authConnection.setRequestMethod("GET");

				authConnection.connect();

				InputStream in1 = new BufferedInputStream(authConnection.getInputStream());
				BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
				StringBuilder result1 = new StringBuilder();
				String line1;
				// fieldsList = new ArrayList<String>();
				while ((line1 = reader1.readLine()) != null) {
					result1.append(line1);
				}

				String jsonstring1 = result1.toString();
				LogFile.LogWrite("Connection Controller - INFO the json string object is" + jsonstring1);

				fileAttachmentME_ALM(filename, jsonstring1, almID, targetDataSource);
			}

			return true;
		} else {
			return false;
		}
	}

	public List<String> findAttachmentINALM(String almID, DataSource targetDataSource)
			throws MalformedURLException, IOException {
		List<String> filenamesALM = new LinkedList<String>();

		LogFile.LogWrite("Connection Controller - INFO #1001 findAttachmentINALM");
		String almURL = targetDataSource.getUrl() + "/qcbin/";

		// String almURL = "http://172.22.6.7:8080/qcbin/";

		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		/* authenticate begin */
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {

			osw.write("<alm-authentication><user>" + targetDataSource.getUsername() + "</user><password>"
					+ targetDataSource.getPassword() + "</password></alm-authentication>");

			// osw.write("<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");

		}
		authConnection.connect();

		LogFile.LogWrite(authConnection.getResponseMessage());
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Connection Controller - the lwssscookiess " + lwssoCookie);
		/* authenticate end */
		/* create session begin */

		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		// createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		String xsrfHeaderValue = "";
		String cookies = "";
		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			LogFile.LogWrite("Connection Controller - the coookies value isss" + cookies);
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}

		HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new URL(
				targetDataSource.getUrl() + "/qcbin/" + "rest/domains/" + targetDataSource.getDomainname()
						+ "/projects/" + targetDataSource.getProjectname() + "/defects/" + almID + "/attachments")
								.openConnection();

		// Modified By Mubarak
		// "http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/"
		// + almID + "/attachments")
		// .openConnection();

		LogFile.LogWrite("Connection Controller - INFO #1213 requiredFieldsConnection START ");
		StringBuilder result1 = new StringBuilder();
		BufferedReader reader1;
		String line1;
		try {

			requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
			requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
			requiredFieldsConnection.setRequestProperty("Content-Type", "application/JSON");
			requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
			requiredFieldsConnection.setRequestMethod("GET");
			requiredFieldsConnection.connect();

			LogFile.LogWrite("Connection Controller - INFO #1212 requiredFieldsConnection:  ");
		

		  InputStream inputStream = new BufferedInputStream(requiredFieldsConnection.getInputStream());
		 reader1 = new BufferedReader(new InputStreamReader(inputStream));
		
		
		} 
		catch (Exception ex) {
			LogFile.LogWrite("Connection Controller - ERROR #1212 requiredFieldsConnection  " + ex.getMessage());
			throw ex;
		}
		while ((line1 = reader1.readLine()) != null) {
			result1.append(line1);
		}

		String jsonstring2 = result1.toString();

		JSONObject mainObject1 = new JSONObject(jsonstring2);

		JSONArray resultObject1 = mainObject1.getJSONArray("entities");
		Map<String, String> fileattachment = new HashMap<String, String>();

		String attachmentfilename = null;
		String attachmentId = "";

		for (int i = 0; i < resultObject1.length(); i++) {

			try {

				JSONObject object = resultObject1.getJSONObject(i);
				JSONArray fieldArrayObject = object.getJSONArray("Fields");

				for (int j = 0; j < fieldArrayObject.length(); j++) {

					JSONObject fieldobject = fieldArrayObject.getJSONObject(j);

					JSONArray valuesarrayObject = fieldobject.getJSONArray("values");

					if (fieldobject.get("Name").equals("name")) {

						JSONObject valuejsonobject = valuesarrayObject.getJSONObject(0);
						attachmentfilename = valuejsonobject.getString("value");

						filenamesALM.add(attachmentfilename);
					}
				}

			} catch (Exception ex) {
				LogFile.LogWrite("Connection Controller - ERROR #1213 resultObject1  " + ex.getMessage());
				throw ex;
			}

			LogFile.LogWrite("Connection Controller - INFO #1213 requiredFieldsConnection END ");

		}

		return filenamesALM;

	}

	public void fileAttachmentME_ALM(String filename, String filecontent, String almID, DataSource targetDataSource)
			throws MalformedURLException, IOException {

		byte[] bFile = filecontent.getBytes();

		LogFile.LogWrite("Connection Controller - the target data source is #1000 " + targetDataSource);
		String almURL = targetDataSource.getUrl() + "/qcbin/";
		// String almURL = "http://172.22.6.7:8080/qcbin/";

		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		/* authenticate begin */
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {

			// osw.write("<alm-authentication><user> + almUserName +
			// </user><password>+almPassword+</password></alm-authentication>");
			// osw.write("<alm-authentication><user>Navin.kanna</user><password>Welkom@123</password></alm-authentication>");
			osw.write("<alm-authentication><user>" + targetDataSource.getUsername() + "</user><password>"
					+ targetDataSource.getPassword() + "</password></alm-authentication>");
		}
		authConnection.connect();

		LogFile.LogWrite(authConnection.getResponseMessage());
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Connection Controller - the lwssscookiess " + lwssoCookie);
		/* authenticate end */
		/* create session begin */

		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		// createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		String xsrfHeaderValue = "";
		String cookies = "";
		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			LogFile.LogWrite("Connection Controller - the coookies value isss" + cookies);
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}

		HttpURLConnection requiredFieldsConnection = (HttpURLConnection) new URL(
				targetDataSource.getUrl() + "/qcbin/" + "rest/domains/" + targetDataSource.getDomainname()
						+ "/projects/" + targetDataSource.getProjectname() + "/defects/" + almID + "/attachments")
								.openConnection();

		// Added By Mubarak And Commaned
		// "http://172.22.6.7:8080/qcbin/rest/domains/"+targetDataSource.getDomainname()+"/projects/"+targetDataSource.getProjectname()+"/defects/"
		// + almID + "/attachments")
		// .openConnection();

		requiredFieldsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		requiredFieldsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		requiredFieldsConnection.setRequestProperty("Content-Type", "application/JSON");
		requiredFieldsConnection.setRequestProperty("Accept", "application/JSON");
		requiredFieldsConnection.setRequestMethod("GET");
		requiredFieldsConnection.connect();

		InputStream inputStream = new BufferedInputStream(requiredFieldsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
		StringBuilder result1 = new StringBuilder();
		String line1;

		while ((line1 = reader1.readLine()) != null) {
			result1.append(line1);
		}

		String jsonstring1 = result1.toString();
		LogFile.LogWrite("Connection Controller - the json string object is" + jsonstring1);

		//
		// JSONObject mainObject = new JSONObject(jsonstring1);
		//
		// JSONArray resultObject = mainObject.getJSONArray("entities");
		// Map<String,String> fileattachment=new HashMap<String,String>();
		//
		// List filenames = new LinkedList();
		// for(int i=0;i<resultObject.length();i++) {
		//
		// JSONObject object = resultObject.getJSONObject(i);
		// JSONArray fieldArrayObject = object.getJSONArray("Fields");
		//
		// for(int j=0;j<fieldArrayObject.length();j++) {
		//
		// JSONObject fieldobject = fieldArrayObject.getJSONObject(i);
		//
		// JSONArray valuesarrayObject = fieldobject.getJSONArray("values");
		// JSONObject valuejsonobject = valuesarrayObject.getJSONObject(0);
		//
		//
		// String attachmentfilename = null;
		// String attachmentId="";
		// if(fieldobject.get("Name").equals("name")) {
		// //attachmentfilename=(String) fieldobject.get("Name");
		//
		// attachmentfilename=valuejsonobject.getString("value");
		// filenames.add(attachmentfilename);
		// }
		//
		// }
		// }
		//
		// LogFile.LogWrite("Connection Controller - the attachment set up is
		// here"+fileattachment);
		//
		// Attachment delete code heree
		// HttpURLConnection deleteattachmentconnection = (HttpURLConnection) new
		// URL("http://172.22.6.7:8080/qcbin/rest/domains/AVLINO/projects/Jira_Test/defects/"+almID+"/attachments/58?by-id=true").openConnection();
		// deleteattachmentconnection.setRequestProperty("Cookie", cookies +
		// lwssoCookie);
		// deleteattachmentconnection.setRequestProperty("X-XSRF-TOKEN",
		// xsrfHeaderValue);
		//
		// deleteattachmentconnection.setRequestMethod("DELETE");
		// deleteattachmentconnection.connect();
		//
		//
		// InputStream inputStream1 = new
		// BufferedInputStream(deleteattachmentconnection.getInputStream());
		// BufferedReader reader11 = new BufferedReader(new
		// InputStreamReader(inputStream1));
		// StringBuilder result11 = new StringBuilder();
		// String line11;
		//
		// while ((line11 = reader11.readLine()) != null) {
		// result11.append(line11);
		// }
		//
		// String jsonstring11 = result11.toString();
		// LogFile.LogWrite("Connection Controller - the json string object
		// is"+jsonstring11);

		// POST Attachment here

		// LogFile.LogWrite("Connection Controller - file name: "+file);
		HttpURLConnection createDefectAttach = (HttpURLConnection) new URL(
				targetDataSource.getUrl() + "/qcbin/" + "rest/domains/" + targetDataSource.getDomainname()
						+ "/projects/" + targetDataSource.getProjectname() + "/defects/" + almID + "/attachments")
								.openConnection();

		/*
		 * 
		 * ADDED AND COMMANED BY MUBARAK
		 * "http://172.22.6.7:8080/qcbin/rest/domains/"+targetDataSource.getDomainname()
		 * +"/projects/"+targetDataSource.getProjectname()+"/defects/" + almID +
		 * "/attachments") .openConnection();
		 * 
		 */

		createDefectAttach.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		createDefectAttach.setRequestProperty("Cookie", cookies + lwssoCookie);
		createDefectAttach.setRequestProperty("Content-Type", "application/octet-stream");
		createDefectAttach.setRequestProperty("slug", filename);
		createDefectAttach.setRequestProperty("Content-Disposition", "attachment;filename=" + filename);

		createDefectAttach.setRequestMethod("POST");
		createDefectAttach.setDoOutput(true);
		createDefectAttach.setDoInput(true);

		createDefectAttach.connect();

		OutputStream out = createDefectAttach.getOutputStream();
		out.write(bFile);
		out.flush();
		out.close();
		LogFile.LogWrite(createDefectAttach.getResponseMessage());
	}

	private static String writeXml(Document doc, OutputStream output) throws TransformerException, IOException {

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();

		// pretty print
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		StringWriter writer = new StringWriter();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(output);

		transformer.transform(source, new StreamResult(writer));
		String xmlString = writer.getBuffer().toString();
		LogFile.LogWrite(xmlString);
		return xmlString;
	}

	public HttpURLConnection isValidUser(DataSource authmodal) throws IOException {

		almURL = authmodal.getUrl() + "/qcbin";
		String authEndPoint = almURL + "/authentication-point/alm-authenticate";
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
			osw.write("<alm-authentication><user>" + authmodal.getUsername() + "</user><password>"
					+ authmodal.getPassword() + "</password></alm-authentication>");
		}
		authConnection.connect();
		LogFile.LogWrite(authConnection.toString());

		return authConnection;
	}

	public String generateXSRFTOKEN(HttpURLConnection authConnection) throws MalformedURLException, IOException {
		String qcSessionEndPoint = almURL + "/rest/site-session";
		lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Connection Controller - the set cookie site session is<><><"
				+ authConnection.getHeaderField("Set-Cookie"));
		LogFile.LogWrite("Connection Controller - the lwss cokkies" + lwssoCookie);
		/* create session begin */
		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		xsrfHeaderValue = "";
		LogFile.LogWrite("Connection Controller - the cookies value isssss" + values);

		for (String cookie : values.get("Set-Cookie")) {
			LogFile.LogWrite("Connection Controller - the cookieeee dataaa" + cookie);
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("QCSession")) {
				// xsrfHeaderValue = value;
				qcSession = value;
			} else if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			} else if (name.equalsIgnoreCase("ALM_USER")) {
				almUser = value;
			}
		}
		LogFile.LogWrite("Connection Controller - INFO the header value is" + xsrfHeaderValue);
		createSession.disconnect();
		return xsrfHeaderValue;
	}
}