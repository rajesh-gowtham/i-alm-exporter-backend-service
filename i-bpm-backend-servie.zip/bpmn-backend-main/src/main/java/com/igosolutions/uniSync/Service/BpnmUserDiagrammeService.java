package com.igosolutions.uniSync.Service;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;


public interface BpnmUserDiagrammeService {

	public BpnmUserDiagramme saveOrUpdateXmlData(BpnmUserDiagramme bpnmUserDiagramme);
    public BpnmUserDiagramme getDiagrammeByUserId(Long UserId);
							
}
