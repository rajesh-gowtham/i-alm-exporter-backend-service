package com.igosolutions.uniSync.ServiceImpl;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;

@Component
public class CustomUserDetailsService implements UserDetailsService {
	@Autowired
	private BpmnUserRepository bpmnUserRepository;
	
	private static final String AES_KEY = "ThisIsASecretKey";

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        BpmnUser user = bpmnUserRepository.findByEmail(username);
        String password = null;
        try {
			 password = decryptPassword(user.getPassword());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        if (user == null) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        return new org.springframework.security.core.userdetails.User(
        		user.getEmail(), password, Collections.emptyList());
    }
    
    public static String decryptPassword(String encryptedPassword) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}
}
