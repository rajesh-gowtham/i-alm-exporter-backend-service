package com.igosolutions.uniSync.Service;

import org.springframework.http.ResponseEntity;

import com.igosolutions.uniSync.Modal.RequestBodyData;

public interface TranslationService {

	ResponseEntity<Object> processRequestData(String fromLanguage, String toLanguage, RequestBodyData requestBodyData);
	
}
