package com.igosolutions.uniSync.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Modal.PublishBpmn;
import com.igosolutions.uniSync.Service.BPMNService;
import com.igosolutions.uniSync.Modal.Bpmn;


@RestController
//@CrossOrigin(origins = "http://localhost:7676/")
public class BpmnController {
	@Autowired
	public BPMNService  bpmnService;

	Logger log = LoggerFactory.getLogger(BpmnController.class);
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public", method = RequestMethod.GET)
	public String getApplicationStart() {
		//log.debug("i-BPMN Running SuccesFully");
		try {
			return "i-BPMN Running SuccesFully";
		} catch (Exception e) {
			return "Error "+e.toString();
		}
	}
	@RequestMapping(value = "/public/healthCheck", method = RequestMethod.GET)
	public String getApplicationStart1() {
		try {
			return "i-BPMN Running SuccesFully with v - 0.1.18.1.2305-SNAPSHOT";
		} catch (Exception e) {
			return "Error "+e.toString();
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/createBPMN", method = RequestMethod.POST)
	public ResponseEntity<Object> saveBpmn(@RequestBody Bpmn bpmn) {
		log.debug("Request {}", bpmn);
		try {

			LogFile.LogWrite("BPMN Controller - bpmn<><> :" + bpmn);
			LogFile.LogWrite("BPMN Controller - bpmn<><  :>" + bpmn.getBpmnXml());
			LogFile.LogWrite("BPMN Controller - bpmn<><> :" + bpmn.getTaskJSON());
			bpmnService.saveTaskConnectionBulk(bpmn);
			log.debug("Response {}", HttpStatus.CREATED);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/publishBPMN", method = RequestMethod.POST)
	public ResponseEntity<Object> publishBPMN(@RequestParam(name = "diagramname", required = false) String diagramname,@RequestParam(name = "publishurl", required = false) String publishurl) throws Exception {
		log.debug("Request {}", diagramname, publishurl);
		try {

			LogFile.LogWrite("BPMN Controller - drname<><> :" + diagramname);
			LogFile.LogWrite("BPMN Controller - publishurl<><> :" + publishurl);
			System.out.println("1 diagramname "+diagramname);
			System.out.println("2 publishurl "+publishurl);
			PublishBpmn publishBpmn=new PublishBpmn();
			publishBpmn.setdiagramname(diagramname);
			System.out.println(" setdiagramname Setted----");
			publishBpmn.seturl(publishurl);
			System.out.println(" seturl Setted----");
			LogFile.LogWrite("BPMN Controller - publishBpmn<><> 2 :" + publishBpmn);
			bpmnService.savePublishBpmn(publishBpmn);
			log.debug("Response {}",HttpStatus.CREATED);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			if(e.getMessage().equals("Diagram name already exist")) {
				return new ResponseEntity<>("Diagram name already exist", HttpStatus.CONFLICT);
			}
			else {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
	}



	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getpublishBPMN", method = RequestMethod.GET)
	public List<Bpmn> getpublishBPMN(@RequestParam(name = "diagramname", required = false) String diagramname) throws IOException {
		log.debug("Request {}", diagramname);
		LogFile.LogWrite("BPMN Controller - diagramname<><> :" + diagramname);
		List<Bpmn> bpmndata	=bpmnService.BpmnByDiagramname(diagramname);
		log.debug("Response {}", bpmndata);
		return bpmndata;
	}


	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value="/updateBPMN",method = RequestMethod.PUT)
	public ResponseEntity<Object> updateDataSource(@RequestBody DataSource datasource) {
		log.debug("Request {}", datasource);
		try {
			log.debug("Response {}", HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value="/deleteBPMN",method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteDataSource(@RequestParam(name = "datasourcename", required = false) String datasourcename) {
		log.debug("Request {}", datasourcename);
		try {
			log.debug("Response {}", HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}


		//	LogFile.LogWrite("Data Source Controller - Delete datasourcename is #101" + datasourcename);	
		//datasourceservice.deleteDataSource(datasourcename);
		//LogFile.LogWrite("Data Source Controller - Delete datasourcename is #102" + datasourcename);

	}




	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBPMN", method = RequestMethod.GET)
	public List<Bpmn> getAllDataSource() {
		//	List<DataSource> dataSourceData = datasourceservice.getAllDataSource();
		log.debug("Request {}");
		List<Bpmn> bpmndata	=bpmnService.getAllDataSource();
		log.debug("Response {}", bpmndata);
		return bpmndata;
	}








}
