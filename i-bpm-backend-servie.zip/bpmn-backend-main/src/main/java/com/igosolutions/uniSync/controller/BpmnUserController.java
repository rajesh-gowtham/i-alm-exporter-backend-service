package com.igosolutions.uniSync.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.Role;
import com.igosolutions.uniSync.Service.BpmnUserService;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;

@RestController
//@RequestMapping("/users")
public class BpmnUserController {
	

	@Autowired
	BpmnUserService bpmnUserService;
	
	@Autowired
    BpnmUserDiagrammeService bpnmUserDiagrammeService;

	Logger log = LoggerFactory.getLogger(BpmnUserController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/createUser",method = RequestMethod.POST) 
	public ResponseEntity<Object> createUser(@RequestBody BpmnUserRequest bpmnUserRequest) {
		log.debug("Request {}");
		String create_User = "CREATE";
		try {
			Map<String,Object> addBpmnUser = bpmnUserService.addEditUsers(bpmnUserRequest,create_User);
			log.debug("Response {}",addBpmnUser);
			return new ResponseEntity<>(addBpmnUser, HttpStatus.CREATED);

		} catch (Exception e) {

			if(e.getMessage() == ("Email already exist")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}
			else {
//				e.printStackTrace();
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}

    @CrossOrigin(origins = "*", allowedHeaders = "*")	
	@RequestMapping(value = "/public/users/loginAuthentication", method = RequestMethod.POST)
	public ResponseEntity<Object> loginAuthentication(@RequestBody BpmnUser bpmnUser) {
    	log.debug("Request {}");
		try {
			Map<String,Object> loginAuthentication  = bpmnUserService.checkEmailPassword(bpmnUser);

			log.debug("Response {}",loginAuthentication);
			return new ResponseEntity<>(loginAuthentication, HttpStatus.OK);

		} catch (Exception e) {
			if(e.getMessage().equals("Incorrect email") || 
					e.getMessage().equals("Incorrect password") ||
					e.getMessage().equals("Email ID does not exist") ) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/viewUserDetails", method = RequestMethod.GET)
	public ResponseEntity<List<Object>> getAllUsers() {
		log.debug("Request {}");
		try {
			List<Object> allUsers = bpmnUserService.getAllUsersWithoutPassword();
			log.debug("Response {}",allUsers);
			return new ResponseEntity<>(allUsers,HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/editUser",method = RequestMethod.POST) 
	public ResponseEntity<Object> updateUser(@RequestBody BpmnUserRequest bpmnUserRequest) {
		log.debug("Request {}", bpmnUserRequest);
		String update_User = "UPDATE";
		try {
			Map<String,Object> updatedBpmnUser = bpmnUserService.addEditUsers(bpmnUserRequest,update_User);
			log.debug("Response {}",updatedBpmnUser);
			return new ResponseEntity<>(updatedBpmnUser,HttpStatus.OK);

		} catch (Exception e) {
			if(e.getMessage().equals("Email not exist") || e.getMessage().equals("User not exist")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/deleteUser/{userid}",method = RequestMethod.DELETE) 
	public ResponseEntity<Object> deleteUser(@PathVariable Long userid) {
		log.debug("Request {}", userid);
		try {
			BpmnUser deletedUser= null;
			//For viewer Role the diagramXMLID is null so the below implementation
			BpnmUserDiagramme diagrammeByUserId = bpnmUserDiagrammeService.getDiagrammeByUserId(userid);
			if(diagrammeByUserId != null){
				 deletedUser = bpmnUserService.deleteUser(userid, diagrammeByUserId.getDiagramXmlId());
			}
			else{
				deletedUser = bpmnUserService.deleteUser(userid);
			}
			
			if (deletedUser == null) {
				log.debug("Response {}","User deleted successfully");
				return new ResponseEntity<>("User deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","User not found");
				return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>("An error occurred during delete the user: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/generateResetPassword/request/{email}",method = RequestMethod.GET) 
	public ResponseEntity<String> requestReset(@PathVariable String email ,HttpServletRequest request) {
		log.debug("Request {}", email);
		try {
			bpmnUserService.generateResetToken(email , request);
			log.debug("Response {}","Reset link sent successfully");
			return ResponseEntity.ok("Reset link sent successfully");
		}
		catch(Exception e) {
			if(e.getMessage().equals("Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}
			else if(e.getMessage().equals("Error sending link")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Error sending code", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/verifyResetPassword", method = RequestMethod.GET) 
	public ResponseEntity<Object> verifyResetToken(@RequestParam String userEmail,@RequestParam String resetToken,HttpServletRequest request) {
		log.debug("Request {}", userEmail, resetToken);
		try {

			String response = bpmnUserService.verifyResetToken(userEmail, resetToken);
			log.debug("Response {}", response);
			return new ResponseEntity<>(response,HttpStatus.OK);

		} catch(Exception e) {
			if(e.getMessage().equals("An error occurred while verifying reset token:  Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}  else {
				log.error(e.getMessage());
				return new ResponseEntity<>("Reset code mismatched", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/confirmPassword", method = RequestMethod.POST) 
	public ResponseEntity<Object> confirmResetPassword(@RequestBody Map<String, String> requestPayload) {
		log.debug("Request {}", requestPayload);
		try {
			String email = requestPayload.get("userEmail");
			String newPassword = requestPayload.get("newPassword");
			String resetToken = requestPayload.get("resetToken");

			bpmnUserService.resetPassword(email, newPassword ,resetToken);
			log.debug("Response {}", "Password reset successful");
			return ResponseEntity.ok("Password reset successful");
		}
		catch(Exception e) {
			if(e.getMessage().equals("Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>("Reset link expired while reset password", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/addRole",method = RequestMethod.POST) 
	public ResponseEntity<Object> addRole(@RequestBody Role role) {
		log.debug("BpmnUserController::addRole::Request {}", role);
		try {
			Role createdRole = bpmnUserService.createRole(role);
			log.debug("BpmnUserController::addRole::Response {}", createdRole);
			return new ResponseEntity<>(createdRole, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("BpmnUserController::addRole::Exception {}", e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/getRole", method = RequestMethod.GET)
	public ResponseEntity<List<Role>> getAllRoles() {
		try {
			log.debug("BpmnUserController::getAllRoles::Request {}");
			List<Role> roles = bpmnUserService.getAllRoles();
			return new ResponseEntity<>(roles, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/deleteRole/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteRole(@PathVariable Long id) {
		log.debug("Request {}", id);
		try {
			Role deletedRole = bpmnUserService.deleteRole(id);
			if (deletedRole == null) {
				log.debug("Response {}","Role deleted successfully");
				return new ResponseEntity<>("Role deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","User not found");
				return new ResponseEntity<>("Role not found with Role Id", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>("An error occurred during delete the Role: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/editRole", method = RequestMethod.POST)
	public ResponseEntity<Object> editRole(@RequestBody Role role) {
		
		log.debug("BpmnUserController::editRole::Request {}", role);
		
		try {
		
		Map<String,Object> UpdatedRole = bpmnUserService.UpdateRole(role);
			log.debug("BpmnUserController::editRole::Response {}", UpdatedRole);
			return new ResponseEntity<>(UpdatedRole, HttpStatus.OK);
		} 
		catch (Exception e) {
			log.error("BpmnUserController::editRole::Exception {}", e.getMessage());
			return new ResponseEntity<>("Role Id not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


}





