package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.ConnectionAudits;

public interface ConnectionAuditService {
	public void saveconnectionAudit(ConnectionAudits connaudit);
	
	public List<ConnectionAudits> getAllConnectionAudits();
	
	public void saveConnectionAuditData(ConnectionAudits connaudit);
	
	public  List<ConnectionAudits> getSelectedConnectionaudits(String auditname);
	
	public  List<ConnectionAudits> getFilterConnectionaudits(String auditname, String startdate,String enddate);

//	List<ConnectionAudits> getFilterConnectionaudits(String auditname, Date startdate, Date enddate);

	
	
}
