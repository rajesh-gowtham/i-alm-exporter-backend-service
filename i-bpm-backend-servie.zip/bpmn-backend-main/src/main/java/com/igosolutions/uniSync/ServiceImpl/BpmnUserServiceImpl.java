package com.igosolutions.uniSync.ServiceImpl;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityNotFoundException;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.Role;
import com.igosolutions.uniSync.Modal.SharePointDetails;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.RoleRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.BpmnUserService;
import com.igosolutions.uniSync.controller.EncryptDecrypt;

@Service
public class BpmnUserServiceImpl implements BpmnUserService {

	@Autowired
	private BpmnUserRepository bpmnUserRepository;

	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;

	@Autowired
	SharePointRepository sharePointRepository;

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private AuthenticationManager authenticationManager;

	private static final String AES_KEY = "ThisIsASecretKey";
	Logger log = LoggerFactory.getLogger(BpmnUserServiceImpl.class);

	@Value("${sharepoint.clientId}")
	private String clientId; // Your client ID

	@Value("${sharepoint.clientSecret}")
	private String clientSecret; // Your client secret

	 

	@Override
	public Map<String, Object> addEditUsers(BpmnUserRequest bpmnUserRequest, String createUpdate) throws Exception {
		BpmnUser response = new BpmnUser();
		Map<String, Object> UserResponse = new HashMap<>();
		try {
			BpmnUser bpmnUser = new BpmnUser(bpmnUserRequest.getUserid(),
					bpmnUserRequest.getOrganization(),
					bpmnUserRequest.getFirstname(),
					bpmnUserRequest.getLastname(),
					bpmnUserRequest.getEmail(),
					bpmnUserRequest.getMobileno(),
					bpmnUserRequest.getRole(),
					bpmnUserRequest.getPassword(),
					bpmnUserRequest.getUserimage().getImgname(),
					bpmnUserRequest.getUserimage().getImgcontent());

			BpmnUser userEmail = bpmnUserRepository.findByEmail(bpmnUser.getEmail());
			BpmnUser userId = bpmnUserRepository.findByUserId(bpmnUser.getUserid());

			if (userEmail != null && createUpdate.equals("CREATE")) {
				throw new Exception("Email already exist");
			}

			if (userId == null && createUpdate.equals("UPDATE")) {
				throw new Exception("User not exist");
			}

			if (userId != null && createUpdate.equals("UPDATE")) {
				if (userId.getEmail().equals(bpmnUser.getEmail())) {

				bpmnUserRepository.updateUser(bpmnUser.getUserid(),
							bpmnUser.getFirstname(),
							bpmnUser.getLastname(),
							bpmnUser.getEmail(),
							bpmnUser.getRole(),
							bpmnUser.getMobileno(),
							bpmnUser.getImgname(),
							bpmnUser.getImgcontent(),
							bpmnUser.getOrganization());
					response = bpmnUserRepository.findByUserId(bpmnUser.getUserid());

				} else {
					throw new Exception("Email not exist");
				}
			}

			if (createUpdate.equals("CREATE")) {

				bpmnUser.setPassword(encryptPassword(bpmnUser.getPassword()));
				BpmnUser user = bpmnUserRepository.save(bpmnUser);
				response = bpmnUserRepository.findByUserId(user.getUserid());

				if (!(bpmnUser.getRole().equalsIgnoreCase("viewer"))) {

					BpnmUserDiagramme userDiagram = new BpnmUserDiagramme();
					userDiagram.setUserid(user.getUserid());
					bpnmUserDiagrammeRepository.save(userDiagram);

				}
				if (response != null) {

					UserResponse.put("userid", String.valueOf(response.getUserid()));
					//Commenting mail to increase performance.
					// SimpleMailMessage message = new SimpleMailMessage();
					// message.setTo(bpmnUser.getEmail());
					// message.setSubject(" New user registered ");

					// String emailBody = "Hi " + bpmnUser.getFirstname() + ",\n\n";
					// emailBody += "New user " + bpmnUser.getEmail()
					// 		+ " registered successfully with IGO Organization.\n\n";
					// emailBody += "Thanks & Regards,\nadminIBPMN.";
					// message.setText(emailBody);

					// javaMailSender.send(message);
				}

			}
			if (createUpdate.equals("UPDATE"))
				UserResponse.put("userid", String.valueOf(response.getUserid()));

			UserResponse.put("firstname", response.getFirstname());
			UserResponse.put("lastname", response.getLastname());
			UserResponse.put("email", response.getEmail());
			UserResponse.put("role", response.getRole());
			UserResponse.put("mobileno", response.getMobileno());
			UserResponse.put("organization", response.getOrganization());
			Map<String, String> userImageMap = new HashMap<>();
			userImageMap.put("imgname", response.getImgname());
			userImageMap.put("imgcontent", response.getImgcontent());
			UserResponse.put("userimage", userImageMap);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("The exception came into catch");
			throw new Exception(e.getMessage());

		}

		return UserResponse;

	}

	@Override
	public List<Object> getAllUsersWithoutPassword() throws Exception {
		List<BpmnUser> bpmnUser = bpmnUserRepository.getAllUsersWithoutPassword();
		List<Object> allUsers = bpmnUser.stream().map(user -> {
			Map<String, Object> userResponse = new HashMap<>();
			userResponse.put("userid", String.valueOf(user.getUserid()));
			userResponse.put("firstname", user.getFirstname());
			userResponse.put("lastname", user.getLastname());
			userResponse.put("email", user.getEmail());
			userResponse.put("role", user.getRole());
			userResponse.put("mobileno", user.getMobileno());
			userResponse.put("organization", user.getOrganization());
			Map<String, String> userImageMap = new HashMap<>();
			userImageMap.put("imgname", user.getImgname());
			userImageMap.put("imgcontent", user.getImgcontent());
			userResponse.put("userimage", userImageMap);
			return userResponse;
		}).collect(Collectors.toList());

		return allUsers;
	}

	@Override
	public Map<String, Object> checkEmailPassword(BpmnUser bpmnUser) throws Exception {

		Map<String, Object> responsePayload = new HashMap<>();

		BpmnUser user = bpmnUserRepository.findByEmail(bpmnUser.getEmail());

		if (user != null) {

			if (bpmnUser.getPassword().equals(decryptPassword(user.getPassword()))) {

				String userName = bpmnUser.getEmail();
				// String password = encryptPassword(bpmnUser.getPassword());

				/*
				 * authenticationManager.authenticate( new
				 * UsernamePasswordAuthenticationToken(userName, password));
				 */
				String token = jwtTokenUtil.generateToken(userName);
				System.out.println("Token     " + token);
				String encryptedtoken = EncryptDecrypt.encrypt(token);
				System.out.println("Encrypted      " + encryptedtoken);

				responsePayload.put("firstname", user.getFirstname());
				responsePayload.put("lastname", user.getLastname());
				responsePayload.put("userid", String.valueOf(user.getUserid()));
				responsePayload.put("role", user.getRole());
				responsePayload.put("organization", user.getOrganization());
				Map<String, String> userImageMap = new HashMap<>();
				userImageMap.put("imgname", user.getImgname());
				userImageMap.put("imgcontent", user.getImgcontent());
				responsePayload.put("userimage", userImageMap);
				responsePayload.put("accestoken", encryptedtoken);

			} else {
				throw new Exception("Incorrect password");
			}
		} else {
			throw new Exception("Email ID does not exist");
		}
		return responsePayload;
	}

	@Override
	public BpmnUser getUserByEmail(String email) throws Exception {
		return bpmnUserRepository.findByEmail(email);
	}

	@Transactional
	@Override
	public BpmnUser deleteUser(Long userid, int diagramXmlId) throws Exception {

		try {
			if (bpmnUserRepository.findByUserId(userid) != null) {
				if (sharePointRepository.existsByDiagramXmlId(Integer.toString(diagramXmlId))) {
					SharePointClient sharePointClient = new SharePointClient(clientId, clientSecret);
					sharePointClient.deleteFolderByName(Integer.toString(diagramXmlId));
					sharePointRepository.deleteByDiagramId(Integer.toString(diagramXmlId));
				}
				bpnmUserDiagrammeRepository.deleteByUserId(userid);
				bpmnUserRepository.deleteByUserId(userid);

			} else
				throw new Exception("User not exist");
		} catch (Exception e) {
			if (e.getMessage().equals("User not exist"))
				throw new Exception("User not exist");
			else
			e.printStackTrace();
				throw new Exception("An error occured during delete the user");
		}
		BpmnUser responseUserId = bpmnUserRepository.findByUserId(userid);

		return responseUserId;
	}
	@Transactional
	@Override
	public BpmnUser deleteUser(Long userid) throws Exception {
		try {
			if (bpmnUserRepository.findByUserId(userid) != null) {
				
				bpmnUserRepository.deleteByUserId(userid);
			} else
				throw new Exception("User not exist");
		} catch (Exception e) {
			if (e.getMessage().equals("User not exist"))
				throw new Exception("User not exist");
			else
			e.printStackTrace();
				throw new Exception("An error occured during delete the user");
		}
		BpmnUser responseUserId = bpmnUserRepository.findByUserId(userid);

		return responseUserId;
	}

	public void generateResetToken(String email, HttpServletRequest request) throws Exception {
		BpmnUser user = bpmnUserRepository.findByEmail(email);
		if (user != null) {
			String resetToken = generateRandomToken();
			user.setResettoken(resetToken);
			bpmnUserRepository.save(user);
			try {
				sendResetTokenEmail(user.getFirstname(), user.getEmail(), resetToken, request);
			} catch (Exception e) {
				throw new Exception("Error sending link");
			}
		} else {
			throw new Exception("Invalid user");
		}
	}

	public void resetPassword(String email, String newPassword, String resetToken) throws Exception {

		BpmnUser user = bpmnUserRepository.findByEmail(email);

		String decryptedResetToken = decryptOTPToken(resetToken);

		if (user != null) {
			if (user.getResettoken() != null && user.getResettoken().equals(decryptedResetToken)) {
				user.setPassword(encryptPassword(newPassword));
				user.setResettoken(null);
				bpmnUserRepository.save(user);
			} else {
				throw new Exception("Reset token mismatched");
			}
		} else {
			throw new Exception("Invalid user");
		}
	}

	public boolean verifyCode(String resetToken) throws Exception {
		BpmnUser user = bpmnUserRepository.findByResettoken(resetToken);
		if (user != null) {
			user.setResettoken("verified");
			bpmnUserRepository.save(user);
			return true;
		} else {
			return false;
		}
	}

	public void sendResetTokenEmail(String userName, String userEmail, String resetToken, HttpServletRequest request)
			throws Exception {
		String resetUrl = request.getRequestURL().toString().replace(request.getRequestURI(), "") + "/";
		String encryptedResetToken = encryptOtp(resetToken);

		// Construct the reset URL
		String originHeader = request.getHeader("Origin");
		if (originHeader != null && !originHeader.isEmpty()) {
			resetUrl = originHeader;
		} else {
			// If Origin header is not present, construct the URL using scheme, server name,
			// and port
			String scheme = request.getScheme();
			String serverName = request.getServerName();
			int port = request.getServerPort();

			// Construct the reset URL
			resetUrl = scheme + "://" + serverName + (port != 80 && port != 443 ? ":" + port : "");
		}

		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(userEmail);
		message.setSubject("Password Reset Link");
		resetUrl += "/resetPassword" + "/" + userEmail + "/" + encryptedResetToken;
		message.setText("Hi " + userName + ",\n\nTo reset your password, please click on the link below:\n" + resetUrl);

		javaMailSender.send(message);

	}

	private String generateRandomToken() {
		int min = 100000;
		int max = 999999;
		Random random = new Random();

		return String.valueOf(random.nextInt(max - min + 1) + min);
	}

	public static String decryptPassword(String encryptedPassword) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public static String decryptOTPToken(String resetToken) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getUrlDecoder().decode(resetToken));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public static String encryptPassword(String token) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);

	}

	public static String encryptOtp(String token) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getUrlEncoder().encodeToString(encryptedBytes);
	}

	@Override
	public String verifyResetToken(String email, String resetToken) throws Exception {
		try {
			BpmnUser user = bpmnUserRepository.findByEmail(email);
			if (user != null) {
				String decryptedResetToken = decryptOTPToken(resetToken);

				if (decryptedResetToken.equals(user.getResettoken())) {

					return "Reset code verified";

				} else {
					throw new Exception("Reset Token mismatched");
				}
			} else {
				throw new Exception("Invalid user");
			}
		} catch (Exception e) {
			throw new Exception("Reset  link expired while reset password");
		}

	}

	@Transactional
	public void updateUserInfo(Long userId, String firstname, String lastname, String role, String mobileno,
			String imgname, String imgcontent, String organization) {
		BpmnUser bpmnUser = bpmnUserRepository.findById(userId)
				.orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

		bpmnUser.setFirstname(firstname);
		bpmnUser.setLastname(lastname);
		bpmnUser.setRole(role);
		bpmnUser.setMobileno(mobileno);
		bpmnUser.setImgname(imgname);
		bpmnUser.setImgcontent(imgcontent);
		bpmnUser.setOrganization(organization);

		bpmnUserRepository.save(bpmnUser);
	}

	@Override
	public Role createRole(Role role) throws Exception {
		log.debug("BpmnUserServiceImpl::createRole::Request {}", role);
		Role existrole = roleRepository.findByRole(role.getRoleName());
		Role responseRole = null;
		try {
			if (existrole == null)
				responseRole = roleRepository.save(role);
			else
				throw new Exception("Role already exist");
		} catch (Exception e) {
			throw new RuntimeException("Failed to create role: " + e.getMessage());
		}
		return responseRole;
	}

	@Override
	public List<Role> getAllRoles() {

		try {
			return roleRepository.findAll();
		} catch (Exception e) {
			throw new RuntimeException("Failed to retrieve roles from the database", e);
		}
	}

	@Transactional
	@Override
	public Role deleteRole(Long id) throws Exception {
		// TODO Auto-generated method stub
		try {
			Optional<Role> roleOptional = roleRepository.findById(id);
			if (roleOptional.isPresent()) {
				Role role = roleOptional.get();
				roleRepository.delete(role);

				if (roleRepository.existsById(id)) {
					throw new Exception("Role with ID " + id + " still exists in the database after deletion");
				}

				return null;
			} else {
				throw new Exception("Role with ID " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> UpdateRole(Role role) throws Exception {

		Map<String, Object> UpdatedResponse = new HashMap<>();

		Role roles = roleRepository.getById(role.getId());
		try {
			if (roles != null) {

				Role saveUpdate = roleRepository.save(role);
				UpdatedResponse.put("id", saveUpdate.getId());
				UpdatedResponse.put("rolename", saveUpdate.getRoleName());
				UpdatedResponse.put("description", saveUpdate.getRoleDescription());
			} else
				throw new Exception("Role Id not found");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return UpdatedResponse;
	}
}
