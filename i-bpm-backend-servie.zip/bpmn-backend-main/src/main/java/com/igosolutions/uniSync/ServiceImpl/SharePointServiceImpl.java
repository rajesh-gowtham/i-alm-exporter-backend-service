package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.SharePointDetails;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.SharePointService;

@Service
public class SharePointServiceImpl implements SharePointService{
	

    @Value("${sharepoint.clientId}")
    private String clientId; // Your client ID

    @Value("${sharepoint.clientSecret}")
    private String clientSecret; // Your client secret
    
    @Autowired
    private SharePointRepository sharePointRepository;
    @Autowired
    BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
    
    private String document_Id = null;
    private String diagramXml_Id = null; 
    private String current_Xml_Id = null;
    private String activity_Id = null;
    private String file_Name = null;
    
    Logger log = LoggerFactory.getLogger(SharePointServiceImpl.class);

	@Override
	public String uploadDocument(MultipartFile file) throws Exception{
		
		try {
		        log.info("Upload document Request{}",file);

		        byte[] fileBytes = file.getBytes();
		        String fileName = file.getOriginalFilename();
		        System.out.println("This is the requested  file name   :  "+ fileName);
				//filename="777/1/Activity_0ek6ut5/APMT Progress Report 04 Jan 2024 .pdf
		        String[] parts = fileName.split("/");

		        if (parts.length == 4) {
		        	 diagramXml_Id = parts[0];
		             current_Xml_Id = parts[1];
		             activity_Id = parts[2];
		             file_Name = parts[3];
		        }
		        String uploaded_File_Name = activity_Id+"_"+file_Name;

		        SharePointClient sharePointClient = new SharePointClient(clientId, clientSecret);
		        
		        System.out.println("This is the uploaded file name  :"+uploaded_File_Name);
		       int diagramId = Integer.parseInt(diagramXml_Id);
		       BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramId); 
              
               
               SharePointDetails sharePointDetailsUpload = new SharePointDetails();
               if(bpnmUserDiagramme != null) {
            	   SharePointDetails SharePointDetails = sharePointRepository.findByDiagramCurrentActivity(diagramXml_Id,current_Xml_Id,activity_Id,file_Name);
               if(SharePointDetails == null) {
            	   document_Id = sharePointClient.uploadFile(fileBytes,diagramXml_Id,current_Xml_Id, uploaded_File_Name);
            	   
                  if(document_Id != null) {
					sharePointDetailsUpload.setDiagramXmlId(diagramXml_Id);
					sharePointDetailsUpload.setCurrentXmlId(current_Xml_Id);
					sharePointDetailsUpload.setActivityId(activity_Id);
					sharePointDetailsUpload.setDocumentId(document_Id);
					sharePointDetailsUpload.setFileName(file_Name);
					sharePointRepository.save(sharePointDetailsUpload);
            	   }
            	   else {
            		   throw new Exception("Failed to upload document");
            		   }
               }
               else {
            	   sharePointClient.deleteDocument(sharePointRepository,SharePointDetails.getDocumentId(),SharePointDetails.getId());
            	   document_Id = sharePointClient.uploadFile(fileBytes,diagramXml_Id,current_Xml_Id, uploaded_File_Name);
            	   if(document_Id != null) {
            	   sharePointDetailsUpload.setDiagramXmlId(diagramXml_Id);
            	   sharePointDetailsUpload.setCurrentXmlId(current_Xml_Id);
            	   sharePointDetailsUpload.setActivityId(activity_Id);
            	   sharePointDetailsUpload.setDocumentId(document_Id);
            	   sharePointDetailsUpload.setFileName(file_Name);
            	   sharePointRepository.save(sharePointDetailsUpload);
            	   }
            	   else {
            		   throw new Exception("Failed to update document");
            	   }
               }
               }
               else {
            	   throw new Exception("The diagram level id not matched");
               }
                
                log.info("Document uploaded here {}",document_Id);
		    } catch (Exception e) {
		        e.printStackTrace();
		        throw new Exception(e.getMessage());
		    }
		return document_Id;
		
	}
	
	@Override
	public byte[] getFile(String diagram_xml_id, String current_xml_id, String activity_id, String file_name)
			throws Exception {
		try {

			SharePointClient sharePointClient = new SharePointClient(clientId,clientSecret); 
			//System.out.println("This is the uploaded file name: " +file_name);
			log.info("Document retrieved from   SharePointServiceImpl : ",file_name);
			

			SharePointDetails SharePointDetails = sharePointRepository.findByDiagramCurrentActivity(diagram_xml_id,
					current_xml_id, activity_id,file_name); 
			if(SharePointDetails != null) {
				log.info("Document retrieved suessfully from SharePointServiceImpl : ",file_name);
				return sharePointClient.getFile(diagram_xml_id,current_xml_id,activity_id,file_name); 
			}
			else
			{
				throw new Exception("Failed to get file: Document not exist");
			}
			
		} catch(Exception e) { 
			e.printStackTrace(); 
			throw new IOException("Failed to get file: " + e.getMessage()); }
	}

	
	  @Override 
	  public Object deleteDocument(String diagram_xml_id, String current_xml_id, String activity_id, String file_name) {
		  
		  SharePointClient sharePointClient = new SharePointClient(clientId, clientSecret);
		  
		  SharePointDetails sharePointDetails = sharePointRepository.findByDiagramCurrentActivity(diagram_xml_id,
					current_xml_id, activity_id,file_name); 
		  System.out.println("This is id     :  "+ sharePointDetails.getId());
		  return sharePointClient.deleteDocument(sharePointRepository,sharePointDetails.getDocumentId(),sharePointDetails.getId());

	  
	  }
	 

	

}
