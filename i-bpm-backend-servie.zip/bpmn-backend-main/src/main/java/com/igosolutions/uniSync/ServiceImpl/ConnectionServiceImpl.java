package com.igosolutions.uniSync.ServiceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Connection;
import com.igosolutions.uniSync.Respository.ConnectionRepository;
import com.igosolutions.uniSync.Service.ConnectionService;

@Service
public class ConnectionServiceImpl implements ConnectionService {

	
	@Autowired
	private ConnectionRepository connRepository;
	
	@Override
	public void UpdateConnection(Connection connectiondata) {		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now).toString();
	        
		connRepository.updateConnection(connectiondata.getConnectionName(),connectiondata.getMappingField(),connectiondata.getMasterCondition(),connectiondata.getUserDefinevalues(),Time);
		//connRepository.save(connectiondata);
	System.out.println("updateConnection" +connectiondata.getConnectionName()+" "+connectiondata.getMappingField()+" "+connectiondata.getMasterCondition()+" "+connectiondata.getUserDefinevalues()+" "+Time);
	}
	
	@Override
	public void saveConnection(Connection connectiondata) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now).toString();
		connRepository.save(connectiondata);
		connRepository.updateConnectionCreateTime(connectiondata.getConnectionName(),Time);
		
		
	}
	

	@Override
	public List<Connection> getAllConnectionData() {
	List<Connection>	listconnectiondata = connRepository.findAll();
		return listconnectiondata;
	}
	
	@Override
	public List<Connection> getConnectionName() {
	List<Connection>	listconnectiondata = connRepository.getConnectionName();
		return listconnectiondata;
	}
	
	
	
	@Override
	public List<Connection> getAllConnectionDataoff(String ISON) {
	List<Connection>	listconnectiondata = connRepository.getAllConnectionDataoff(ISON);
		return listconnectiondata;
	}
	
	

	@Override
	public void updateConnectionStatus(Connection connection,String status) {
		StringBuffer ConnectionName=new StringBuffer();
		ConnectionName.append(connection.getConnectionName());
	
		connRepository.updateConnectionStatus(ConnectionName.toString(),status);
	}

	@Override
	public void deleteConnection(String connectionName) {
	
		try {
			System.out.println("connectionName DELETE IS: "+connectionName);
			connRepository.deleteByConnection(connectionName);
		}catch(Exception ex) {
			System.out.println("Error # 1010 connectionName : "+ex.getMessage());
		}
		
	}

	
	@Override
	public void updateconnection(String connectionName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void connectionONstatus(String connectionName, String status,String switchfalge,String time) {
		// TODO Auto-generated method stub
		try {
			System.out.println("303030 connectionName "+connectionName +" status"+status +"switchfalge "+switchfalge);
			connRepository.connectionONstatus(connectionName,status,switchfalge,time);
		}catch(Exception ex) {
			System.out.println("Error # 1010 connectionName : "+ex.getMessage());
		}
	}
	
	
	
	
	@Override
	public void updateConnectionswitchflag(String connectionName) {
		// TODO Auto-generated method stub
		try {
			
			connRepository.updateConnectionswitchflag(connectionName,"NO");
		}catch(Exception ex) {
			System.out.println("Error # 1010 updateConnectionswitchflag : "+ex.getMessage());
		}
	}
	
	
	@Override
	public void connectionOFFstatus(String connectionName, String status,String switchfalge,String time) {
		// TODO Auto-generated method stub
		try {
			System.out.println("303030 connectionName "+connectionName +" status"+status +"switchfalge "+switchfalge);
			connRepository.connectionOFFstatus(connectionName,status,switchfalge,time);
		}catch(Exception ex) {
			System.out.println("Error # 1010 connectionName : "+ex.getMessage());
		}
	}

}
