package com.igosolutions.uniSync.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Connectionsyncdata;
import com.igosolutions.uniSync.Respository.ConnectionsyncdataRepository;
import com.igosolutions.uniSync.Service.ConnectionsyncdataService;

@Service
public class ConnectionsyncdataServiceImpl implements ConnectionsyncdataService{
	
	@Autowired
	private ConnectionsyncdataRepository connectionsyncdatarepo;
	private Connectionsyncdata connsyncdata;

	@Override
	public void saveConnectionsyncdata(List<Connectionsyncdata> listsyndata) {
		System.out.println("#123 INFO saveConnectionsyncdata : "+listsyndata);
		
		connectionsyncdatarepo.saveAll(listsyndata);
	}

	@Override
	public List<Connectionsyncdata> getAllConnectionsyncdata() {
		List<Connectionsyncdata> listconnectionsyndata =	connectionsyncdatarepo.findAll();
	
		return listconnectionsyndata;
	}
	
	public void updateAllMEupdatetimeALMupdatetime(List<Connectionsyncdata> listconnsyncdata) {
		System.out.println("INFO 3342 updateAllMEupdatetimeALMupdatetime");
		
		for(int i=0;i<listconnsyncdata.size();i++) {
			String meID=listconnsyncdata.get(i).getMeId();
			System.out.println("The backward sync operation <><> :"+listconnsyncdata.get(i));
			
			
			try {
				connsyncdata = connectionsyncdatarepo.findByMeid(meID);
				System.out.println("INFO 3334 The connsyncdata :"+connsyncdata);
			}catch(Exception ex) {
				System.out.print("ERROR #5252 connsyncdata :"+ ex.getMessage());
				throw ex;
			}	
			if(connsyncdata == null) {			
				try {
					Connectionsyncdata connectionsyncdata = new Connectionsyncdata();
					connectionsyncdata.setMeId(listconnsyncdata.get(i).getMeId());
					connectionsyncdata.setAlmId(listconnsyncdata.get(i).getAlmId());
					connectionsyncdata.setAlmupdateTime(listconnsyncdata.get(i).getAlmupdateTime());
					connectionsyncdata.setMeupdateTime(listconnsyncdata.get(i).getMeupdateTime());
					// Added By Mubarak s			
					connectionsyncdata.setalmDomain(listconnsyncdata.get(i).getalmDomain());
					connectionsyncdata.setalmDBName(listconnsyncdata.get(i).getalmDBName());
					connectionsyncdata.setalmDefaultProject(listconnsyncdata.get(i).getalmDefaultProject());
					
					
					System.out.println("ConnectionsyncdataServiceImpl #1223 SAVE updateAllMEupdatetimeALMupdatetime : "+listconnsyncdata);
					connectionsyncdatarepo.save(connectionsyncdata);
				}catch(Exception ex) {
					System.out.print("ConnectionsyncdataServiceImpl ERROR #6262 connectionsyncdata :"+ ex.getMessage());
					throw ex;
				}		
			
			} else {
			
				
				try {
					String almupdatetime=listconnsyncdata.get(i).getAlmupdateTime();
					String meupdatetime =listconnsyncdata.get(i).getMeupdateTime();
					// added By Mubarak
					String almDomain=listconnsyncdata.get(i).getalmDomain();
					String almDbName=listconnsyncdata.get(i).getalmDBName();
					String almtargetProject=listconnsyncdata.get(i).getalmDefaultProject();
					
					
					if(almtargetProject==null) {
						connectionsyncdatarepo.updateMEupdatetimeALMupdatetimeifprojectnull(meupdatetime, almupdatetime, meID);
					}else {
						System.out.println("ConnectionsyncdataServiceImpl Info UPADTE #7676 meupdatetime, almupdatetime, meID :" +" "+ meupdatetime+" "+almupdatetime+" "+ meID);
						connectionsyncdatarepo.updateMEupdatetimeALMupdatetime(meupdatetime, almupdatetime, meID,almDomain,almDbName,almtargetProject);
					}
					
					
				}catch(Exception ex) {
					 System.out.println("ConnectionsyncdataServiceImpl ERROR #7272 targetDatasource :"+ ex.getMessage());
 					throw ex;
				}
		
			}
		}
		
	}
	
	

	@Override
	public void deleteAllConnectionsyncdata() {
		connectionsyncdatarepo.deleteAll();
	}

	public void updateALMUpdateTimeandALMCopyUpdateTime(String meID,String updatetime, String meupdatetime) {
		System.out.println("INFO 3344 updateALMUpdateTimeandALMCopyUpdateTime");
		connectionsyncdatarepo.updateALMUpdateTimeAndALMCopyUpdateTime(meID,updatetime,meupdatetime);
	}
	
	public void updateMEUpdateTimeAndMECopyUpdateTime(String meID,String updatetime,String almupdtetime) {
		System.out.println("INFO 3345 updateMEUpdateTimeAndMECopyUpdateTime");
		connectionsyncdatarepo.updateMEUpdateTimeAndMECopyUpdateTime(meID, updatetime,almupdtetime);
	}
	
	public void updateMEUpdateTimeAlon(String meID,String updatetime) {
		System.out.println("INFO 3345 updateMEUpdateTimeAndMECopyUpdateTime");
		connectionsyncdatarepo.updateMEUpdateTimeAlon(meID, updatetime);
	}
}
