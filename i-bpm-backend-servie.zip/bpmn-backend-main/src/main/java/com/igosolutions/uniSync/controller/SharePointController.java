package com.igosolutions.uniSync.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.SharePointDetails;
import com.igosolutions.uniSync.Service.SharePointService;
import com.igosolutions.uniSync.ServiceImpl.SharePointClient;

@RestController
public class SharePointController {

	    Logger log = LoggerFactory.getLogger(SharePointController.class);

		@Value("${sharepoint.clientId}")
		private String clientId; // Your client ID

		@Value("${sharepoint.clientSecret}")
		private String clientSecret; // Your client secret
	   
	    @Autowired
	    private SharePointService sharePointService;

	    @CrossOrigin(origins = "*", allowedHeaders = "*")
	    @RequestMapping(value = "/doc/upload", method = RequestMethod.POST)
	    public ResponseEntity<String> uploadDocuments(@RequestParam("files") MultipartFile[] files) {
	        log.info("UploadDocuments Request {}");
	        if (files == null || files.length == 0) {
	            return ResponseEntity.badRequest().body("No files provided");
	        }
	     

	        try {         
	        	synchronized (this) {             
	        		for (MultipartFile file : files) {                
	        			if (!file.isEmpty()) {                     
	        				sharePointService.uploadDocument(file);                 
	        			}             
	        		}         
	        	}         
	        	return ResponseEntity.ok("Documents uploaded successfully to SharePoint.");    
	        } catch (Exception e) {
	            e.printStackTrace();
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .body("Failed to upload documents to SharePoint: " + e.getMessage());
	        }
	    }
	    
	    @CrossOrigin(origins = "*", allowedHeaders = "*")
        @RequestMapping(value = "/doc/getDoc/{diagram_xml_id}/{current_xml_id}/{activity_id}/{file_name}", method = RequestMethod.GET)
        public ResponseEntity<byte[]> downloadDocument(@PathVariable("diagram_xml_id") String diagram_xml_id,
                                                       @PathVariable("current_xml_id") String current_xml_id,
                                                       @PathVariable("activity_id") String activity_id,
                                                       @PathVariable("file_name") String file_name) {
            log.info("The doc retreiving starting from controller {}", file_name);
             try {
                 byte[] fileContent = sharePointService.getFile(diagram_xml_id,current_xml_id,
                                                                activity_id,file_name);
                
                 HttpHeaders headers = new HttpHeaders();
                 headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                 headers.setContentDispositionFormData("attachment", file_name);
                 log.info("The doc retreiving completed in controller {}", file_name);
                 return ResponseEntity.ok().headers(headers).body(fileContent);
             } catch (Exception e) {
                 
                 e.printStackTrace();
                 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                         .body(("Failed to download document from SharePoint: " + e.getMessage()).getBytes());
        
             }
        }
	    
//	    @CrossOrigin(origins = "*" , allowedHeaders = "*")
//	    @RequestMapping(value = "/doc/deleteDoc/{diagram_xml_id}/{current_xml_id}/{activity_id}/{file_name}" , method = RequestMethod.DELETE)
//	    public ResponseEntity<String>deleteDocument(@PathVariable("diagram_xml_id") String diagram_xml_id,
//                                                    @PathVariable("current_xml_id") String current_xml_id,
//                                                    @PathVariable("activity_id") String activity_id,
//                                                    @PathVariable("file_name") String file_name){
//	    	System.out.println(diagram_xml_id);
//	    	
//	    	try {
//	    		sharePointService.deleteDocument(diagram_xml_id,current_xml_id,activity_id,file_name);
//	    		return ResponseEntity.ok().body("Document deleted Successfully");
//	    		
//	    	}catch(Exception e) {
//	    		e.printStackTrace();
//	    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(("Failed to delete the document :  "+ e.getMessage()));
//	    	}
//	    	
//	    }
	    
	    @CrossOrigin(origins = "*" , allowedHeaders = "*")
	    @RequestMapping(value = "/doc/deleteDoc/{diagram_xml_id}" , method = RequestMethod.DELETE)
	    public ResponseEntity<String>deleteDocument(@PathVariable("diagram_xml_id") String diagram_xml_id, @RequestBody List<SharePointDetails> sharePointDetails){
	    	
	    	boolean allDeletedSuccessfully = true;
	    	
	    	for(SharePointDetails sharePointDetail: sharePointDetails) {
	    		try {
		    		sharePointService.deleteDocument(diagram_xml_id,sharePointDetail.getCurrentXmlId(),sharePointDetail.getActivityId(),sharePointDetail.getFileName());
		    	}catch(Exception e) {
		    		e.printStackTrace();
		    		allDeletedSuccessfully = false;
		    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(("Failed to delete the document :  "+ e.getMessage()));
		    	}
	    	}
	    	
	    	if (allDeletedSuccessfully) {
	    		 return ResponseEntity.ok().body("Document deleted Successfully");
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                                 .body("Failed to delete one or more documents");
	        }
	    	
	    }

		//UnUsed Controller for deleting the folder in the sharepoint folder
		@CrossOrigin(origins = "*" , allowedHeaders = "*")
	    @RequestMapping(value = "/doc/deleteFolder/{diagram_xml_id}" , method = RequestMethod.DELETE)
	    public ResponseEntity<String>sharePointFolderDelete(@PathVariable("diagram_xml_id") String diagram_xml_id){
	    	System.out.println(diagram_xml_id);
	    	
	    	try {
	    		SharePointClient sharePointClient = new SharePointClient(clientId,clientSecret); 
				sharePointClient.deleteFolderByName(diagram_xml_id);
	    		return ResponseEntity.ok().body("Sharepoint Folder deleted Successfully");
	    		
	    	}catch(Exception e) {
	    		e.printStackTrace();
	    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(("Failed to delete the document :  "+ e.getMessage()));
	    	}
	    	
	    }
	    
	    
}
