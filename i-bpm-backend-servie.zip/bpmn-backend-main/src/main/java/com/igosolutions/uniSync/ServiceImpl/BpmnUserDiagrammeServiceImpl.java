package com.igosolutions.uniSync.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;

@Service
public class BpmnUserDiagrammeServiceImpl implements BpnmUserDiagrammeService {
	
	@Autowired
    BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;

	@Override
	public BpnmUserDiagramme saveOrUpdateXmlData(BpnmUserDiagramme bpnmUserDiagramme) {
		// TODO Auto-generated method stub
		
		BpnmUserDiagramme existingData = bpnmUserDiagrammeRepository.getByuserid(bpnmUserDiagramme.getUserid());
		
		if(existingData == null) {

			BpnmUserDiagramme saveData = new BpnmUserDiagramme();
			saveData.setUserid(bpnmUserDiagramme.getUserid());
			saveData.setDiagramXmlId(bpnmUserDiagramme.getDiagramXmlId());
			saveData.setXmlData(bpnmUserDiagramme.getXmlData());
			saveData.setLanguageCode(bpnmUserDiagramme.getLanguageCode());
			saveData.setLanguageName(bpnmUserDiagramme.getLanguageName());
			return bpnmUserDiagrammeRepository.save(saveData) ;
		}

		else {

			existingData.setXmlData(bpnmUserDiagramme.getXmlData());
			existingData.setLanguageCode(bpnmUserDiagramme.getLanguageCode());
			existingData.setLanguageName(bpnmUserDiagramme.getLanguageName());
			bpnmUserDiagrammeRepository.update(existingData.getUserid(),existingData.getXmlData(),existingData.getLanguageCode(),existingData.getLanguageName());
		}
		return existingData;
	}
		
		 
	

	@Override
	public BpnmUserDiagramme getDiagrammeByUserId(Long userId) {
		
		return bpnmUserDiagrammeRepository.getByuserid(userId);

	}

}


