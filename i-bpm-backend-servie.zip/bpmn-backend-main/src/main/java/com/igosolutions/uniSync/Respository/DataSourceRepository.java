package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.igosolutions.uniSync.Modal.DataSource;

public interface DataSourceRepository extends JpaRepository<DataSource, Long> {
    
	@Query("select s from DataSource s where s.datasourcename = :datasourcename")
	DataSource existsByDatasourcename(String datasourcename);
	
	@Query("select s from DataSource s where s.datasourcename = :datasourcename")
	DataSource findByDatasourcename(String datasourcename);

	@Modifying
	@Query("delete from DataSource s where s.datasourcename = :datasourcename")
	void deleteByDataSource(String datasourcename);
	
	
//  select domainname from data_source where datasourcename='Dummy Project'
	@Query("select s from DataSource s where s.datasourcename = :targetdatasource")
	DataSource selectDomanin(String targetdatasource);
	

}
