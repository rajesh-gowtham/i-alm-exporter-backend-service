package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.SharePointDetails;

public interface SharePointRepository extends JpaRepository<SharePointDetails, Long> {

	@Transactional
	@Query("SELECT s FROM SharePointDetails s WHERE s.diagramXmlId = :diagramXml_Id AND s.currentXmlId = :current_Xml_Id AND s.activityId = :activity_Id AND s.fileName = :file_Name")
	SharePointDetails findByDiagramCurrentActivity(@Param("diagramXml_Id") String diagramXml_Id,
			@Param("current_Xml_Id") String current_Xml_Id, @Param("activity_Id") String activity_Id,
			@Param("file_Name") String file_Name);

	@Transactional
	@Modifying
	@Query("update SharePointDetails s set s.documentId =:document_Id, s.fileName = :file_Name where s.id = :id")
	void update(@Param("id") Long id, @Param("document_Id") String document_Id, @Param("file_Name") String file_Name);

	@Transactional
	@Modifying
	@Query("DELETE FROM SharePointDetails d WHERE d.documentId=:documentId")
	void deleteBydocumentId(@Param("documentId") String documentId);

	@Transactional
	@Query("SELECT s FROM SharePointDetails s WHERE s.diagramXmlId = :diagramXml_Id AND s.currentXmlId = :current_Xml_Id AND s.activityId = :activity_Id ")
	List<SharePointDetails> findByDiagramCurrentActivityFolder(@Param("diagramXml_Id") String diagramXml_Id,
			@Param("current_Xml_Id") String current_Xml_Id, @Param("activity_Id") String activity_Id);

	@Transactional
	@Modifying
	@Query("DELETE FROM SharePointDetails d WHERE d.diagramXmlId = :diagramXmlId AND d.currentXmlId = :currentXmlId AND d.activityId = :activityId")
	void deleteByDiagramCurrentActivity(@Param("diagramXmlId") String diagramXmlId,
			@Param("currentXmlId") String currentXmlId,
			@Param("activityId") String activityId);

	@Transactional
	@Modifying
	@Query("DELETE FROM SharePointDetails b WHERE b.diagramXmlId = :diagram_xml_id")
	void deleteByDiagramId(String diagram_xml_id);

	@Transactional
	@Query("SELECT CASE WHEN COUNT(s) > 0 THEN true ELSE false END FROM SharePointDetails s WHERE s.diagramXmlId = :diagramXml_Id")
	boolean existsByDiagramXmlId(@Param("diagramXml_Id") String diagramXmlId);

}
