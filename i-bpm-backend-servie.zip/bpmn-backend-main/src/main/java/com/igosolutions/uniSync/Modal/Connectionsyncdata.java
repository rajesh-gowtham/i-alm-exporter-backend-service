package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Connectionsyncdata")
public class Connectionsyncdata {
	
	
	public Connectionsyncdata() {
		
	}
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	private String meId;
	private String meupdateTime;
	private String mealmId;
	private String mecopyupdatetime;
	private String almId;
	private String almupdateTime;
	private String almcopyupdatetime;
	private String almDomain;
	private String almDefaultProject;
	private String almModuleName;
	private String almDBName;
	
	@Override
	public String toString() {
		return "Connectionsyncdata [id=" + id + ", meId=" + meId + ", meupdateTime=" + meupdateTime + ", mealmId="
				+ mealmId + ", mecopyupdatetime=" + mecopyupdatetime + ", almId=" + almId + ", almupdateTime="
				+ almupdateTime + ", almcopyupdatetime=" + almcopyupdatetime  
				+ ", almDomain=" + almDomain + ", almDBName=" + almDBName 
				+", getalmDefaultProject=" + almDefaultProject + ", getId()=" + getId()
				+ ", getMeId()="+ getMeId() + ", getMeupdateTime()=" + getMeupdateTime() + ", getMealmId()=" + getMealmId()
				+ ", getAlmId()=" + getAlmId() + ", getAlmupdateTime()=" + getAlmupdateTime()
				+ ", getMecopyupdatetime()=" + getMecopyupdatetime() + ", getAlmcopyupdatetime()="+ getAlmcopyupdatetime() 
                + ", getalmDomain()="+ getalmDomain()  + ", getalmDBName()="+ getalmDBName() + ", getalmDefaultProject()="+ getalmDefaultProject() 
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
	
	public String getalmDomain() {
		return almDomain;
	}
	public void setalmDomain(String almDomain) {
		this.almDomain = almDomain;
	}
	public String getalmDBName() {
		return almDBName;
	}
	public void setalmDBName(String almDBName) {
		this.almDBName = almDBName;
	}
	
	
	
	public String getalmDefaultProject() {
		return almDefaultProject;
	}
	public void setalmDefaultProject(String almDefaultProject) {
		this.almDefaultProject = almDefaultProject;
	}
	
	public String getalmModuleName() {
		return almModuleName;
	}
	public void setalmModuleName(String almModuleName) {
		this.almModuleName = almModuleName;
	}
	
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getMeId() {
		return meId;
	}
	public void setMeId(String meId) {
		this.meId = meId;
	}
	public String getMeupdateTime() {
		return meupdateTime;
	}
	public void setMeupdateTime(String meupdateTime) {
		this.meupdateTime = meupdateTime;
	}
	public String getMealmId() {
		return mealmId;
	}
	public void setMealmId(String mealmId) {
		this.mealmId = mealmId;
	}
	public String getAlmId() {
		return almId;
	}
	public void setAlmId(String almId) {
		this.almId = almId;
	}
	public String getAlmupdateTime() {
		return almupdateTime;
	}
	public void setAlmupdateTime(String almupdateTime) {
		this.almupdateTime = almupdateTime;
	}
	public String getMecopyupdatetime() {
		return mecopyupdatetime;
	}
	public void setMecopyupdatetime(String mecopyupdatetime) {
		this.mecopyupdatetime = mecopyupdatetime;
	}
	public String getAlmcopyupdatetime() {
		return almcopyupdatetime;
	}
	public void setAlmcopyupdatetime(String almcopyupdatetime) {
		this.almcopyupdatetime = almcopyupdatetime;
	}
	
	
}
