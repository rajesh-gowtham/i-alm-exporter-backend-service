package com.igosolutions.uniSync.ServiceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.igosolutions.uniSync.Modal.ActivityText;
import com.igosolutions.uniSync.Modal.CommentText;
import com.igosolutions.uniSync.Modal.RemainingText;
import com.igosolutions.uniSync.Modal.RequestBodyData;
import com.igosolutions.uniSync.Service.TranslationService;

@Service
public class TranslationServiceImpl implements TranslationService{

//	int count = 0;
	
	RestTemplate restTemplate = new RestTemplate();
	
	 
	
	private static final String TRANSLATION_API_URL = "https://translate.googleapis.com/translate_a/single?client=gtx";
	
	@Override
	public ResponseEntity<Object> processRequestData(String fromLanguage, String toLanguage, RequestBodyData requestBodyData) {
		
        String apiUrl = TRANSLATION_API_URL+"&sl="+ fromLanguage + "&tl="+toLanguage+"&dt=t&q=";
        
        
        List<ActivityText> activityTexts = new ArrayList<>();
        List<CommentText> commentTexts = new ArrayList<>();
        List<RemainingText> remainingTexts = new ArrayList<>();
        ExecutorService executor = Executors.newFixedThreadPool(10);
        
        
        Integer activitySize = requestBodyData.getActivityTexts().size();
        Integer activitySixthSize = activitySize / 6;
        Integer activitiesCheck = activitySize % 6;

        if (activitySize >= 6) {
            List<List<ActivityText>> sixths = new ArrayList<>();

            int startIndex = 0;
            for (int i = 0; i < 6; i++) {
                int currentSixthSize = activitySixthSize + (i < activitiesCheck ? 1 : 0);
                List<ActivityText> sixth = requestBodyData.getActivityTexts().subList(startIndex, startIndex + currentSixthSize);
                sixths.add(sixth);
                startIndex += currentSixthSize;
            }

            for (int i = 0; i < 6; i++) {
                int finalI = i;
                executor.execute(() -> {
                    if (requestBodyData.getActivityTexts() != null) {
                        for (ActivityText activityText : sixths.get(finalI)) {
                            activityTexts.add(mapActivityText(apiUrl, activityText));
                        }
                    }
                });
            }
        } else {
            executor.execute(() -> {
                if (requestBodyData.getActivityTexts() != null) {
                    for (ActivityText activityText : requestBodyData.getActivityTexts()) {
                        activityTexts.add(mapActivityText(apiUrl, activityText));
                    }
                }
            });
        }
        
        Integer commentSize = requestBodyData.getCommentTexts().size();
        Integer commentSixthSize = commentSize / 6;
        Integer commentCheck = commentSize % 6;

        if (commentSize >= 6) {
            List<List<CommentText>> sixths = new ArrayList<>();

            // Divide into six parts
            int startIndex = 0;
            for (int i = 0; i < 6; i++) {
                int currentSixthSize = commentSixthSize + (i < commentCheck ? 1 : 0);
                List<CommentText> sixth = requestBodyData.getCommentTexts().subList(startIndex, startIndex + currentSixthSize);
                sixths.add(sixth);
                startIndex += currentSixthSize;
            }

            // Execute tasks for each sixth
            for (int i = 0; i < 6; i++) {
                int finalI = i;
                executor.execute(() -> {
                    if (requestBodyData.getCommentTexts() != null) {
                        for (CommentText commentText : sixths.get(finalI)) {
                            commentTexts.add(mapCommentText(apiUrl, commentText));
                        }
                    }
                });
            }
        } else {
            // If there are less than 6 comments, execute as before
            executor.execute(() -> {
                if (requestBodyData.getCommentTexts() != null) {
                    for (CommentText commentText : requestBodyData.getCommentTexts()) {
                        commentTexts.add(mapCommentText(apiUrl, commentText));
                    }
                }
            });
        }
        

        Integer remainingTextsSize = requestBodyData.getRemainingTexts().size();
        Integer remainingSixthSize = remainingTextsSize / 6; 
        Integer remainingCheck = remainingTextsSize % 6; 

        if (remainingTextsSize >= 6) {

            List<List<RemainingText>> sixths = new ArrayList<>(); 

            int startIndex = 0;
            for (int i = 0; i < 6; i++) {
                int currentSixthSize = remainingSixthSize + (i < remainingCheck ? 1 : 0); 
                List<RemainingText> sixth = requestBodyData.getRemainingTexts().subList(startIndex, startIndex + currentSixthSize); // Changed from fifth to sixth
                sixths.add(sixth); 
                startIndex += currentSixthSize;
            }

      
            for (int i = 0; i < 6; i++) { 
                int finalI = i;
                executor.execute(() -> {
                    if (requestBodyData.getRemainingTexts() != null) {
                        for (RemainingText remainingText : sixths.get(finalI)) { 
                            System.out.println("Processing sixth " + (finalI + 1) + "\n\nProcessing\n"); 
                            remainingTexts.add(mapRemainingText(apiUrl, remainingText)); 
                        }
                    }
                });
            }
        } else {
           
            executor.execute(() -> {
                if (requestBodyData.getRemainingTexts() != null) {
                    for (RemainingText remainingText : requestBodyData.getRemainingTexts()) {
                        remainingTexts.add(mapRemainingText(apiUrl, remainingText));
                    }
                }
            });
        }


        
        executor.shutdown();             
        
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        RequestBodyData responseBody = new RequestBodyData();
        responseBody.setActivityTexts(activityTexts);
        responseBody.setCommentTexts(commentTexts);
        responseBody.setRemainingTexts(remainingTexts);
//        System.out.println("Total API call - "+count);
//        count = 0;
        return new ResponseEntity<>(responseBody, HttpStatus.OK);
	}

	
    @SuppressWarnings("unchecked")
	String translateWord(String apiUrl, String value) {
    	ResponseEntity<Object[]> responseEntity = restTemplate.getForEntity(apiUrl + value, Object[].class);
        Object[] responseBody = responseEntity.getBody();
//        LocalDateTime now = LocalDateTime.now();
//
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
//
//        String formattedDateTime = now.format(formatter);
//        count++;
//        System.out.println(count+" Time: "+formattedDateTime);
       
        try {
            List<List<Object>> nestedArrays = (List<List<Object>>) responseBody[0];
            String translatedText = (String) nestedArrays.get(0).get(0); 
            return translatedText;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    ActivityText mapActivityText(String apiUrl, ActivityText activityText) {

    	String translatedFullName = translateWord(apiUrl, activityText.getFullNameTxt());

    	String truncatedName = translatedFullName.length() <= 25 ? translatedFullName : translatedFullName.substring(0, 25) + "...";

    	ActivityText translatedActivity = new ActivityText();
    	translatedActivity.setId(activityText.getId());
    	translatedActivity.setName(truncatedName);
    	translatedActivity.setFullNameTxt(translatedFullName);

    	return translatedActivity;

    }
	
	CommentText mapCommentText(String apiUrl, CommentText commentText) {

		String translatedFullName = translateWord(apiUrl, commentText.getNameText());

		CommentText translatedComment = new CommentText();
		translatedComment.setId(commentText.getId());
		translatedComment.setNameText(translatedFullName);

		return translatedComment;

	}
	
	RemainingText mapRemainingText(String apiUrl, RemainingText remainingText) {

		 String translatedName = translateWord(apiUrl, remainingText.getName());
		 
		RemainingText translatedRemaining = new RemainingText();
        translatedRemaining.setId(remainingText.getId());
        translatedRemaining.setName(translatedName);

		return translatedRemaining;

	}

}




