package com.igosolutions.uniSync.controller;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;


@RestController
public class BpmnUserDiagrammeController {
	
	@Autowired
    BpnmUserDiagrammeService bpnmUserDiagrammeService;
 
	Logger log = LoggerFactory.getLogger(BpmnUserDiagrammeController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/bpmnXml/getLastSavedXml/{userid}", method = RequestMethod.GET)
	public ResponseEntity<BpnmUserDiagramme> getDiagrammeByUserId(@PathVariable("userid") Long userId) {

		log.debug("Request {}", userId);
		BpnmUserDiagramme diagrammeByUserId = bpnmUserDiagrammeService.getDiagrammeByUserId(userId);
		if(diagrammeByUserId !=null) {
			log.debug("Response {}",diagrammeByUserId);
			return new ResponseEntity<>(diagrammeByUserId,HttpStatus.OK);
		}
		else {
			log.debug("Response {}",diagrammeByUserId);
			return new ResponseEntity<>(diagrammeByUserId,HttpStatus.NO_CONTENT);
		}

	}



	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnXml/saveLatestXml/{userid}",method = RequestMethod.POST) 
	public ResponseEntity<Object> saveLatestXml(@PathVariable(name = "userid") Long userid,@RequestBody BpnmUserDiagramme bpnmUserDiagramme){

		log.debug("Request {}", userid);
		try {
			bpnmUserDiagramme.setUserid(userid);
			BpnmUserDiagramme savedOrUpdateDiagramme = bpnmUserDiagrammeService.saveOrUpdateXmlData(bpnmUserDiagramme);
			if(savedOrUpdateDiagramme != null) {

				Map<String,String> response = new HashMap<>();
				response.put("diagramXmlId",  String.valueOf(savedOrUpdateDiagramme.getDiagramXmlId()));
				response.put("xmlData", savedOrUpdateDiagramme.getXmlData());
				response.put("languageName", savedOrUpdateDiagramme.getLanguageName());
				response.put("languageCode", savedOrUpdateDiagramme.getLanguageCode());
				log.debug("Response {}",response);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		log.debug("Response {}",HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);


	} 
}
