package com.igosolutions.uniSync.ServiceImpl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.Resource;
import com.igosolutions.uniSync.Respository.ResourceRepository;
import com.igosolutions.uniSync.Service.ResourceService;

@Service
public class ResourceServiceImpl implements ResourceService {

	@Autowired
    private ResourceRepository resourceRepository;

	@Override
	public Map<String, String> addResource(Resource resource) throws Exception {
		Resource findByName = resourceRepository.findByName(resource.getResourceName());
		
		Map<String, String> response = new LinkedHashMap<>();
			if(!(findByName!=null)) {
				Resource newResource = resourceRepository.save(resource);
				
				response.put("id", String.valueOf(newResource.getId()));
				response.put("resourceName", newResource.getResourceName());
				response.put("displayName", newResource.getDisplayName());
				response.put("infoField1", newResource.getInfoField1());
				response.put("infoField2", newResource.getInfoField2());
				response.put("type", newResource.getType());
				return response;
			}
			else {
				throw new Exception("Resource name already exist");
			}
		
	}

	@Override
	public List<Object> getAllResource() throws Exception {
		
		List<Resource> bpmnResource = resourceRepository.getAllResource();
		List<Object> allUsers = bpmnResource.stream().map(user -> {
		    Map<String, String> userResponse = new HashMap<>();
		    userResponse.put("id", String.valueOf(user.getId()));
		    userResponse.put("resourceName", user.getResourceName());
		    userResponse.put("displayName", user.getDisplayName());
		    userResponse.put("infoField1", user.getInfoField1());
		    userResponse.put("infoField2", user.getInfoField2());
		    userResponse.put("type", user.getType());
		    return userResponse;
		}).collect(Collectors.toList());
		
		return allUsers;
	}
	
	@Transactional
	@Override
	public Resource deleteUser(Long id) throws Exception {
		try {
			if(resourceRepository.findByResourceId(id) != null) {
				resourceRepository.deleteByResourceId(id);
			}
			else 
				throw new Exception("User not exist");
		}
		catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().equals("User not exist"))
				throw new Exception("User not exist");
			else
				throw new Exception("An error occured during delete the user");
		}
		Resource response = resourceRepository.findByResourceId(id);

		return response;
	}

	@Override
	public Map<String, String> addEditUsers(Resource resource) throws Exception {
		Resource findByName = resourceRepository.findByName(resource.getResourceName());
		
		if(findByName!=null) {
			Map<String, String> response = new LinkedHashMap<>();
				Resource newResource = resourceRepository.save(resource);
				
				response.put("id", String.valueOf(newResource.getId()));
				response.put("resourceName", newResource.getResourceName());
				response.put("displayName", newResource.getDisplayName());
				response.put("infoField1", newResource.getInfoField1());
				response.put("infoField2", newResource.getInfoField2());
				response.put("type", newResource.getType());
				return response;
		}else {
			throw new Exception("Resource not exist");
		}
		
	}
	
}
