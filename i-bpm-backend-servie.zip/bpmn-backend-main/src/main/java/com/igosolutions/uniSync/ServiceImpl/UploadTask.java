package com.igosolutions.uniSync.ServiceImpl;

import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Service.SharePointService;

public class UploadTask implements Runnable {
    private MultipartFile file;
    private SharePointService sharePointService;
 
    public UploadTask(MultipartFile file, SharePointService sharePointService) {
        this.file = file;
        this.sharePointService = sharePointService;
    }
 
    @Override
    public void run() {
        try {
            // Process the file upload
            if (sharePointService != null) {
                sharePointService.uploadDocument(file);
            } else {
                throw new RuntimeException("SharePointService is null");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}