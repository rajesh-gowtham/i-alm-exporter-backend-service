package com.igosolutions.uniSync.Service;

import org.springframework.web.multipart.MultipartFile;

public interface SharePointService {

	String uploadDocument(MultipartFile file) throws Exception;

	byte[] getFile(String diagram_xml_id, String current_xml_id, String activity_id, String file_name) throws Exception;

	Object deleteDocument(String diagram_xml_id, String current_xml_id, String activity_id, String file_name);
	

}
