package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Bpmn;

public interface BPMNRepository extends JpaRepository<Bpmn, Long> {

	@Transactional
	@Query("select s from Bpmn s where s.diagramname = :diagramname")
	List<Bpmn> BpmnByDiagramname(String diagramname);

	



}
