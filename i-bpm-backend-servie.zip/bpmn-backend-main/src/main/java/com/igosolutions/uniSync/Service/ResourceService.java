package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.Resource;

public interface ResourceService {

	public Map<String, String> addResource(Resource resource) throws Exception;
	
	public List<Object> getAllResource() throws Exception;
	
	public Map<String, String> addEditUsers(Resource resource) throws Exception;

	public Resource deleteUser(Long id) throws Exception;
}
