package com.igosolutions.uniSync.controller;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.igosolutions.uniSync.Service.ConnectionService;
import com.igosolutions.uniSync.Service.DataSourceService;
import com.igosolutions.uniSync.ServiceImpl.ALMDataBaseServiceImpl;
import com.igosolutions.uniSync.ServiceImpl.ConnectionsyncdataServiceImpl;

@RestController
//@CrossOrigin(origins = "http://172.22.6.21:7575/")
public class LoginController {

	@Autowired
	private DataSourceService service;

	@Autowired
	private ConnectionService connservice;
	@Autowired
	private DataSourceController dscontrooler;
	@Autowired
	
	private ALMDataBaseServiceImpl almdatabaseImpl;

	@Autowired
	private ConnectionsyncdataServiceImpl connectionsyncdataServiceImpl;
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/loginsubmit", method = RequestMethod.GET)
	public String login(@RequestParam(name = "userName", required = false) String userName,
			@RequestParam(name = "password", required = false) String password) {
		String userName1 = "Universal Sync is used to map and sync data from one apps to another apps";
		try {
			String message = "";
			JSONObject returndata = new JSONObject();
			String statuscode = "";
			loginME();
			if (userName.equals("admin@igosolutions.eu") && (password.equals("admin1234"))) {

				returndata.put(message, "User logged in successfully");
				returndata.put(statuscode, 200);
				return "User logged in successfully";
			} else {
				returndata.put(message, "UserName and Password are in Coreect.");
				returndata.put(statuscode, 401);
				return "UserName and Password are in Coreect.";
			}
		} catch (Exception e) {

			e.printStackTrace();
			return "UserName and Password are in Coreect.";
		}

	}

	public void secondMethod() throws IOException {
		String almURL = "http://172.22.6.7:8080/qcbin/";
		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		String listAllDomainURL = almURL + "api/domains";

		String listAllProjectsInDomain = almURL + "api/domains/AVLINO/projects";
		/* authenticate begin */
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/xml");
		authConnection.setDoOutput(true);
		OutputStream os = authConnection.getOutputStream();
		try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
			osw.write("<alm-authentication><user>suresh.a</user><password>Welkom@123</password></alm-authentication>");
		}
		authConnection.connect();
		//LogFile.LogWrite(authConnection.getResponseCode());
		String lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Info #8989the lwss cokkies" + lwssoCookie);
		/* create session begin */
		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		String xsrfHeaderValue = "";
		String cookies = "";
		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}
		LogFile.LogWrite("the header value is" + xsrfHeaderValue);
		HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllDomainURL).openConnection();
		createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession1.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		createSession1.setRequestProperty("Content-Type", "application/json");
		createSession1.setRequestProperty("Accept", "application/json");
		createSession1.setRequestMethod("GET");
		createSession1.connect();
		LogFile.LogWrite(createSession1.getResponseMessage());
		InputStream in = new BufferedInputStream(createSession1.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		LogFile.LogWrite("the  string builder is #2001" + result);

		HttpURLConnection getProjectsConnection = (HttpURLConnection) new URL(listAllProjectsInDomain).openConnection();
		getProjectsConnection.setRequestProperty("Cookie", cookies + lwssoCookie);
		getProjectsConnection.setRequestProperty("X-XSRF-TOKEN", xsrfHeaderValue);
		// getProjectsConnection.setRequestProperty("Content-Type", "application/json");
		getProjectsConnection.setRequestProperty("Accept", "application/json");
		getProjectsConnection.setRequestMethod("GET");
		getProjectsConnection.connect();
		InputStream in1 = new BufferedInputStream(getProjectsConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
		StringBuilder result1 = new StringBuilder();
		String line1;
		while ((line1 = reader1.readLine()) != null) {
			result1.append(line1);
		}
		LogFile.LogWrite(getProjectsConnection.getResponseMessage());
	//	LogFile.LogWrite(getProjectsConnection.getResponseCode());
		LogFile.LogWrite("the  string builder is #2002" + result1);

	}

	public void loginME() throws IOException {
		String almURL = "http://172.22.6.21:7171/sdpapi/auth/";
		String authEndPoint = almURL + "authentication-point/alm-authenticate";
		String qcSessionEndPoint = almURL + "rest/site-session";
		String listAllDomainURL = almURL + "api/domains";

		String listAllProjectsInDomain = almURL + "api/domains/AVLINO/projects";
		/* authenticate begin */
		URL authUrl = new URL(almURL);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();
		authConnection.setRequestMethod("POST");
		authConnection.setRequestProperty("Content-Type", "application/json");
		authConnection.setDoOutput(true);
		authConnection.addRequestProperty("username", "buvanesh.v");
		authConnection.addRequestProperty("password", "Welkom@123");
		// OutputStream os = authConnection.getOutputStream();
		// try(OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")){
		// osw.write("<alm-authentication><user>suresh.a</user><password>Welkom@123</password></alm-authentication>");
		// }
		authConnection.connect();
		InputStream in1 = new BufferedInputStream(authConnection.getInputStream());
		BufferedReader reader1 = new BufferedReader(new InputStreamReader(in1));
		StringBuilder result1 = new StringBuilder();
		String line1;
		while ((line1 = reader1.readLine()) != null) {
			result1.append(line1);
		}

		// SQL Query --- Do not remove
		//
		// select cast(max(woh.OPERATIONTIME) as varchar(100))as updatetime
		// ,wf.WORKORDERID, wf.UDF_Long1 as ALM_ID, wf.UDF_CHAR2 as Severity,
		// acc.ORG_NAME as AccountType from Workorder_Fields as wf
		// inner join WorkOrder as wo on wo.WORKORDERID = wf.WORKORDERID inner join
		// AccountDefinition as acc on wo.SITEID = acc.DEFAULTSITEID
		// inner join WorkOrderHistory as woh on woh.WORKORDERID = wo.WORKORDERID
		// where wf.UDF_CHAR7 = 'Resolved' and wf.UDF_CHAR2 is not null and wf.UDF_Long1
		// is not null and woh.OPERATION = 'Update'
		// group by wf.WORKORDERID,wf.UDF_Long1, wf.UDF_CHAR2,acc.ORG_NAME
		//
		//
		// Select * , CAST (OPERATIONTIME AS BIGINT) as update_time from
		// WorkOrderHistory where WORKORDERID = '729' and OPERATION = 'Update' order by
		// OPERATIONTIME desc

	}
	
	
	

//	@RequestMapping(value = "/api/synz/mealm", method = RequestMethod.GET)
//	public String doBackWardSync() throws MalformedURLException, IOException, ClassNotFoundException, SQLException,
//			TransformerException, ParserConfigurationException, ParseException {
//
//		List<Connection> listConnectionData = connservice.getAllConnectionData();
//
//
//		for (int connectiondataIntiallization = 0; connectiondataIntiallization < listConnectionData.size(); connectiondataIntiallization++) {
//
//			Connection conndata = listConnectionData.get(connectiondataIntiallization);
//
//			DataSource masterDatasource = service.getDataSource(conndata.getMasterdatasource());
//			DataSource targetDatasource = service.getDataSource(conndata.getTargetdatasource());
//
//			String masterProjectName = conndata.getMasterprojectname();
//
//			List getMErecords = getMEUpdatedRecords(masterProjectName);
//
//			List<Object> listAlmIDs = new ArrayList<Object>();
//
//			for (int i = 0; i < getMErecords.size(); i++) {
//				Gson gson = new Gson();
//				String json = gson.toJson(getMErecords.get(i));
//				JSONObject objects = new JSONObject(json);
//				LogFile.LogWrite("the objects and date ena dtie" + getMErecords.get(i));
//				listAlmIDs.add(objects.get("ALM_ID"));
//			}
//			List<Connectionsyncdata> listconnectionsyncdatas = almdatabaseImpl.getAMLRecordsByALMIDs(listAlmIDs);
//
//			for (int i = 0; i < listconnectionsyncdatas.size(); i++) {
//				Gson gson = new Gson();
//				String json = gson.toJson(getMErecords.get(i));
//				JSONObject objects = new JSONObject(json);
//
//				Connectionsyncdata connectionsyncdata = listconnectionsyncdatas.get(i);
//				connectionsyncdata.setMeId(objects.get("WORKORDERID").toString());
//				String dateandtime = objects.get("updatetime").toString();
//				long seconddatetime = Long.parseLong(dateandtime);
//				Timestamp stamp = new Timestamp(seconddatetime);
//				Date date = new Date(stamp.getTime());
//				DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
//				DateFormat f1 = new SimpleDateFormat("yyyy/MM/dd");
//				String d = f.format(date);
//
//				LogFile.LogWrite("the date and time of the " + objects.get("WORKORDERID") + "the date time is " + d);
//
//				connectionsyncdata.setMeupdateTime(d);
//				
//				LogFile.LogWrite("the connection data items isss"+connectionsyncdata);
//
//			}
//			
//			connectionsyncdataServiceImpl.updateAllMEupdatetimeALMupdatetime(listconnectionsyncdatas);
//            LogFile.LogWrite("the data items issss<><" + listconnectionsyncdatas);
//		}
//		return null;
//
//	}

	public List getMEUpdatedRecords(String orgName) throws IOException {
		String uri = "http://localhost:7373/getModifiedTimeByOrgName?orgName=" + orgName + "";
		RestTemplate restTemplate = new RestTemplate();
		List result = restTemplate.getForObject(uri, List.class);

		LogFile.LogWrite("the return data items" + result);
		String dateandtime = "1623468929960";
		long seconddatetime = Long.parseLong(dateandtime);
		Timestamp stamp = new Timestamp(seconddatetime);
		Date date = new Date(stamp.getTime());
		DateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
		DateFormat f1 = new SimpleDateFormat("yyyy/MM/dd");
		String d = f.format(date);
		String d1 = f1.format(date);
		LogFile.LogWrite("thee ddd value is" + d);
		LogFile.LogWrite(d1);
		return result;

	}

}
