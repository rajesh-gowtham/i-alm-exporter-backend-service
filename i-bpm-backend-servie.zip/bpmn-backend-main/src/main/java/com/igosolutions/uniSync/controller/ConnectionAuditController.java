package com.igosolutions.uniSync.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.ConnectionAudits;
import com.igosolutions.uniSync.ServiceImpl.ConnectionAuditServiceImpl;

@RestController
public class ConnectionAuditController {

@Autowired
private ConnectionAuditServiceImpl connauditsImpl;



    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getConnectionAuditsdata", method = RequestMethod.GET)
	public List<ConnectionAudits> getConnectionaudits() throws IOException {

// Current Months		
		List<ConnectionAudits> listconnaudits = connauditsImpl.getAllConnectionAudits();
		LogFile.LogWrite("Connection Controller - getConnectionAuditsdata :"+listconnaudits);
		return listconnaudits;
	}
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getfilteraudit", method = RequestMethod.GET)
	public List<ConnectionAudits> getfilteraudit(@RequestParam(name = "auditname", required = false) String auditname,@RequestParam(name = "startdate", required = false) String startdate,@RequestParam(name = "enddate", required = false) String enddate) throws IOException, ParseException {

		LogFile.LogWrite("Connection Controller - auditname    :"+auditname +"  startdate   :"+startdate+"  enddate   :"+enddate);	
		List<ConnectionAudits> listconnaudits = connauditsImpl.getFilterConnectionaudits(auditname,startdate,enddate);		
		LogFile.LogWrite("Connection Controller - loadFilterudit :"+listconnaudits);
		return listconnaudits;
	}
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/loadselectedaudit", method = RequestMethod.GET)
	public List<ConnectionAudits> getSelectedConnectionaudits(@RequestParam(name = "auditname", required = false) String auditname) throws IOException {

		LogFile.LogWrite("Connection Controller - auditname :"+auditname);
		List<ConnectionAudits> listconnaudits = connauditsImpl.getSelectedConnectionaudits(auditname);
		LogFile.LogWrite("Connection Controller - loadselectedaudit :"+listconnaudits);
		return listconnaudits;
	}
}
