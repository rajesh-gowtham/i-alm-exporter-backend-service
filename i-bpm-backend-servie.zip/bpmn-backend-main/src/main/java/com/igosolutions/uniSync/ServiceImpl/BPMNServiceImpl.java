package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.PublishBpmn;
import com.igosolutions.uniSync.Respository.BPMNRepository;
import com.igosolutions.uniSync.Respository.PublishBpmnRepository;
import com.igosolutions.uniSync.Service.BPMNService;
import com.igosolutions.uniSync.controller.LogFile;

@Service
public class BPMNServiceImpl implements BPMNService {

	
	@Autowired
	private BPMNRepository bpmnRepository;
	@Autowired
	private PublishBpmnRepository publishBpmnRepository;

	
	@Override
	public void saveTaskConnectionBulk(Bpmn bpmn) {
	   bpmnRepository.save(bpmn);
	}
	
	@Override
	public void savePublishBpmn(PublishBpmn publishBpmn) throws Exception {
		System.out.println("publishBpmn ------>"+publishBpmn);
		String currDiagram = publishBpmn.getdiagramname();
		List<PublishBpmn> data = publishBpmnRepository.findAll();
		if(!data.isEmpty()) {
			for(PublishBpmn obj:data) {
				if(obj.getdiagramname().equals(currDiagram)) {
					throw new  Exception("Diagram name already exist");
				}
			}
			
		}
		
		publishBpmnRepository.savedetails(publishBpmn.geturl(), publishBpmn.getdiagramname());
	}
	@Override
	public List<Bpmn> BpmnByDiagramname(String Diagramname) {
		try {
			LogFile.LogWrite("BPMN Controller - BpmnByDiagramname<><> :" + Diagramname);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     List<Bpmn> bpmndata = bpmnRepository.BpmnByDiagramname(Diagramname);
	return bpmndata;
	}

	@Override
	public List<Bpmn> getAllDataSource() {
	List<Bpmn> bpmndata = (List<Bpmn>) bpmnRepository.findAll();
    return bpmndata;
	}
	
	
}
