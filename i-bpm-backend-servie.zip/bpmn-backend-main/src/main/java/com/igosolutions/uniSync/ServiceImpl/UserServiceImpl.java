package com.igosolutions.uniSync.ServiceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.igosolutions.uniSync.Respository.UserRepository;
import com.igosolutions.uniSync.Service.UserServices;
import com.igosolutions.uniSync.Modal.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserServices {
	
	@Autowired
	private UserRepository userrepo;
	
	
	@Override
	public void deleteUser(String username) {		
		userrepo.deleteUser(username);
		System.out.println("deleteUser 332 :"+username+" ");
	}
	
	
	@Override
	public Users GetMeKey(String username){
		try {
			System.out.println("GetMeKey 332 :"+username);
			Users	listlogconnections = userrepo.GetMeKey(username);
			System.out.println("listlogconnections 332 :"+listlogconnections);
			return listlogconnections;
		}catch(Exception ex) {
			System.out.println("listlogconnections 332 ERROR :"+ex.getMessage());
			return null;
		}
		
	}
	
	
	
	@Override
	public Users logins(String username,String password){
		Users	listlogconnections = userrepo.logins(username,password);
		return listlogconnections;
	}

	@Override
	public void updateuserdetails(String username,String password,String email) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now).toString();
		userrepo.updateuserdetails(username,password,email,Time);
		System.out.println("savenewUser 332 :"+username+" "+password+" "+email+"Me_Key" );
	}
	
	
	@Override
	public void savenewUser(String username,String password,String email,String Me_Key) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String Time = dtf.format(now).toString();
		userrepo.savedetails(username,password,email,Me_Key,Time);
		System.out.println("savenewUser 332 :"+username+" "+password+" "+email+"Me_Key" );
	}
	
	@Override
	public List<Users> getAllUsers() {

		List<Users> users = (List<Users>) userrepo.findAll();
		System.out.println("the getAllUsers data items isssss" + users);
		return users;
	}
	
	
}
