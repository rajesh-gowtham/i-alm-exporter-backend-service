package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.PublishBpmn;


public interface BPMNService {

	public void saveTaskConnectionBulk(Bpmn bpmndata);
	
	public List<Bpmn> BpmnByDiagramname(String Diagramname);
	
	public List<Bpmn> getAllDataSource();
		
	public void savePublishBpmn(PublishBpmn publishBpmn) throws Exception;
}
