package com.igosolutions.uniSync.Modal;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestBodyData {
    @JsonProperty("ActivityTexts")
    private List<ActivityText> activityTexts;

    @JsonProperty("remainingTexts")
    private List<RemainingText> remainingTexts;

    @JsonProperty("CommentTexts")
    private List<CommentText> commentTexts;

    // Getters and setters

    public List<ActivityText> getActivityTexts() {
        return activityTexts;
    }

    public void setActivityTexts(List<ActivityText> activityTexts) {
        this.activityTexts = activityTexts;
    }

    public List<RemainingText> getRemainingTexts() {
        return remainingTexts;
    }

    public void setRemainingTexts(List<RemainingText> remainingTexts) {
        this.remainingTexts = remainingTexts;
    }

    public List<CommentText> getCommentTexts() {
        return commentTexts;
    }

    public void setCommentTexts(List<CommentText> commentTexts) {
        this.commentTexts = commentTexts;
    }
}