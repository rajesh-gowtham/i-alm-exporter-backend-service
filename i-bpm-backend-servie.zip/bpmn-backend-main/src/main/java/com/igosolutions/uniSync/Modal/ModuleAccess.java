
package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "privilege")
public class ModuleAccess {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private String modles;
	private String access;
	
	
	
	
}
