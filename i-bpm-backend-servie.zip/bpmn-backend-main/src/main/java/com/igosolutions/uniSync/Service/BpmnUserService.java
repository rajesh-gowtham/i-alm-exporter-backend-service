package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.Role;


public interface BpmnUserService {
	
	public Map<String, Object> addEditUsers(BpmnUserRequest bpmnUserRequest, String user) throws Exception;
	
    public List<Object> getAllUsersWithoutPassword() throws Exception;

	BpmnUser getUserByEmail(String email) throws Exception;

	public Map<String, Object> checkEmailPassword(BpmnUser bpmnUser)throws Exception;

	public BpmnUser deleteUser(Long userid, int diagramXmlId) throws Exception;
	
	public BpmnUser deleteUser(Long userid) throws Exception;
	
	public void sendResetTokenEmail(String userName, String userEmail, String resetToken , HttpServletRequest request) throws Exception;
	
	public void resetPassword(String email, String newPassword, String resetToken) throws Exception;
	
	public boolean verifyCode(String resetToken) throws Exception;
	
	public void generateResetToken(String email, HttpServletRequest request) throws Exception;

	public String verifyResetToken(String email, String resetToken) throws Exception;

	public Role createRole(Role role) throws Exception;

	public List<Role> getAllRoles();

	public Role deleteRole(Long id) throws Exception;

	public Map<String, Object> UpdateRole(Role role) throws Exception;
	
}