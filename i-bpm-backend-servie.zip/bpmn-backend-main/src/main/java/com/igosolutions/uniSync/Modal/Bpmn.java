package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bpmn")
public class Bpmn {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long   taskConnectionId;
	private String taskJSON;
	private String bpmnXml;
	private String diagramname;
	@Column(name = "diagram_xml_id")
	private String diagramXmlId;
	@Column(name = "language_code")
	private String languageCode;
	@Column(name = "language_name")
	private String languageName;
	@Column(name = "published_by")
	private String publishedBy;
	
	public String getDiagramname() {
		return diagramname;
	}



	public void setDiagramname(String diagramname) {
		this.diagramname = diagramname;
	}


	@Override
	public String toString() {
		
		return "Bpmn [taskConnectionId=" + taskConnectionId + ", bpmnXml=" + bpmnXml
				+", taskJSON=" +taskJSON
				+", diagramname=" +diagramname
				+"]";
		
	}
	
	
	public String getDiagramXmlId() {
		return diagramXmlId;
	}



	public void setDiagramXmlId(String diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}



	public String getLanguageCode() {
		return languageCode;
	}



	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}



	public String getLanguageName() {
		return languageName;
	}



	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}



	public String getPublishedBy() {
		return publishedBy;
	}



	public void setPublishedBy(String publishedBy) {
		this.publishedBy = publishedBy;
	}



	public Long getTaskConnectionId() {
		return taskConnectionId;
	} 
	
	public void setTaskConnectionId(Long TaskConnectionId_) {
		this.taskConnectionId = TaskConnectionId_;
	}
	
	
	public String getBpmnXml() {
		return bpmnXml;
	} 
	
	public void setBpmnXml(String BpmnXml_) {
		this.bpmnXml = BpmnXml_;
	}
	
	public String getTaskJSON() {
		return taskJSON;
	} 
	
	public void setTaskJSON(String TaskJSON) {
		this.taskJSON = TaskJSON;
	}
	
	
}
