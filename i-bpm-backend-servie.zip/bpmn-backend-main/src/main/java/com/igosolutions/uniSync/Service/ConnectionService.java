package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.Connection;

public interface ConnectionService {
	
	public void saveConnection(Connection connection);
	
	public void updateConnectionswitchflag(String connectionname);
	
	public void UpdateConnection(Connection connection);
	
	public List<Connection> getAllConnectionData();
	
	public List<Connection> getConnectionName();
	
	
	public List<Connection> getAllConnectionDataoff(String ISON);
	
	public void updateConnectionStatus(Connection connection,String status);
	
	public void deleteConnection(String connectionName);
	
	public void updateconnection(String connectionName);
	
	public void connectionONstatus(String connectionName, String status,String switchfalge,String ontime);
	
	public void connectionOFFstatus(String connectionName, String status,String switchfalge,String ontime);
	
	
	
}
