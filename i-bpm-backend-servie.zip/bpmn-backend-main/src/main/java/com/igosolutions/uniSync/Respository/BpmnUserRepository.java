package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.BpmnUser;


public interface BpmnUserRepository extends JpaRepository<BpmnUser, Long>{

	@Query("select s from BpmnUser s where s.email = :email")
	BpmnUser findByEmail(String email);
	
	BpmnUser findByResettoken(String resettoken);
	
	@Transactional
	@Query(value="SELECT b FROM BpmnUser b WHERE b.userid = :userid")
	public BpmnUser findByUserId(@Param("userid")Long userid);
	
	/*
	 * @Transactional
	 * 
	 * @Modifying
	 * 
	 * @Query("UPDATE BpmnUser u SET u.firstname = :firstname, u.lastname = :lastname, u.role = :role, u.mobileno = :mobileno, u.imgname = :imgname, u.imgcontent = :imgcontent, u.organization = :organization WHERE u.userid = :userid"
	 * ) BpmnUser save(
	 * 
	 * @Param("userid") Long userid,
	 * 
	 * @Param("firstname") String firstname,
	 * 
	 * @Param("lastname") String lastname,
	 * 
	 * @Param("role") String role,
	 * 
	 * @Param("mobileno") String mobileno,
	 * 
	 * @Param("imgname") String imgname,
	 * 
	 * @Param("imgcontent") String imgcontent,
	 * 
	 * @Param("organization") String organization );
	 */

	@Transactional
	@Modifying
	@Query("UPDATE BpmnUser b SET b.firstname = :firstname, b.lastname = :lastname, b.email = :email, b.role = :role, b.mobileno = :mobileno, b.imgname = :imgname, b.imgcontent = :imgcontent, b.organization = :organization WHERE b.userid = :userid")
	public void updateUser(@Param("userid") long userid, @Param("firstname") String firstname, @Param("lastname") String lastname, @Param("email") String email, @Param("role") String role, @Param("mobileno") String mobileno, @Param("imgname") String imgname, @Param("imgcontent") String imgcontent, @Param("organization") String organization);
	
	@Query(value = "SELECT new com.igosolutions.uniSync.Modal.BpmnUser(user.userid, user.firstname, user.lastname, user.email, user.role, user.mobileno, user.imgname, user.imgcontent, user.organization) FROM BpmnUser user ORDER BY user.firstname")
	List<BpmnUser> getAllUsersWithoutPassword();
    
	/*
	 * @Modifying
	 * 
	 * @Transactional
	 * 
	 * @Query("DELETE FROM BpmnUser u WHERE u.userid = :userid") void
	 * deleteBpmnUsersByUserId(Long userid);
	 */
	
    @Transactional
    @Modifying
    @Query("DELETE FROM BpmnUser u WHERE u.userid = :userid")
	void deleteByUserId(Long userid);



	
}
