package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.DataSource;


public interface DataSourceService {

	public void saveDataSource(DataSource datasource);
	
	public List<DataSource> getAllDataSource();
	
	public boolean findDataSouceName(String datasourcename);

	public DataSource getDataSource(String datasourcename);
	
	public void updateDataSource(DataSource datasource);
	
	public void deleteDataSource(String datasourcename);
	
	public DataSource selectDomanin(String targetdatasource);
}
