package com.igosolutions.uniSync.Respository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;

public interface BpnmUserDiagrammeRepository extends JpaRepository<BpnmUserDiagramme, Long> {
	
   
	@Transactional
    @Modifying
    @Query("update BpnmUserDiagramme s set s.xmlData = :xmlData, s.languageCode =:languageCode, s.languageName = :languageName where s.userid = :userid")
    void update(@Param("userid") Long userid, @Param("xmlData") String xmlData,@Param("languageCode") String languageCode,@Param("languageName") String languageName);
   
	@Transactional
	@Query(value="SELECT b FROM BpnmUserDiagramme b WHERE b.userid = :userId")
	public BpnmUserDiagramme getByuserid(@Param("userId")Long userId);
	
	
    
	@Transactional
    @Modifying
    @Query("DELETE FROM BpnmUserDiagramme b WHERE b.userid = :userid")
    void deleteByUserId(Long userid);

	@Transactional
	@Query(value="SELECT d FROM BpnmUserDiagramme d WHERE d.diagramXmlId =:diagramXml_Id")
	BpnmUserDiagramme findbyDiagramXmlId(@Param("diagramXml_Id")int diagramId);
}

