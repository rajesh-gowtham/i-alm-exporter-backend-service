package com.igosolutions.uniSync.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Resource;
import com.igosolutions.uniSync.Service.ResourceService;
@RestController
public class ResourceController {

	@Autowired
	public ResourceService  resourceService;
	
    Logger log = LoggerFactory.getLogger(ResourceController.class);
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/createResource",method = RequestMethod.POST) 
	public ResponseEntity<Object> createUser(@RequestBody Resource resource) {
		log.debug("Request {}", resource);
		try {
			Map<String, String> addResource = resourceService.addResource(resource);
            log.debug("Response {}",addResource);
			return new ResponseEntity<>(addResource, HttpStatus.CREATED);

		} catch (Exception e) {

			if(e.getMessage() == ("Resource name already exist")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/resources/viewResourceDetails", method = RequestMethod.GET)
	public ResponseEntity<List<Object>> getAllUsers() {
        log.debug("Request {}");
		try {
			List<Object> allResource = resourceService.getAllResource();
			log.debug("Response {}",allResource);
			return new ResponseEntity<>(allResource,HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/deleteResource/{id}",method = RequestMethod.DELETE) 
	public ResponseEntity<Object> deleteUser(@PathVariable Long id) {
		log.debug("Request {}", id);
		try {
			Resource deletedUser = resourceService.deleteUser(id);
			if (deletedUser == null) {
				log.debug("Response {}","User deleted successfully");
				return new ResponseEntity<>("User deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","User not found");
				return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			if(e.getMessage().equals("User not exist")){
				return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
			}
			else {
				e.printStackTrace();
				return new ResponseEntity<>("An error occurred during delete the user: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/editResource",method = RequestMethod.POST) 
	public ResponseEntity<Object> updateUser(@RequestBody Resource resource) {
		log.debug("Request {}", resource);
		try {
			Map<String,String> editResource = resourceService.addEditUsers(resource);
			log.debug("Response {}",editResource);
			return new ResponseEntity<>(editResource,HttpStatus.OK);

		} catch (Exception e) {
			if(e.getMessage().equals("Resource not exist")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
	
}
