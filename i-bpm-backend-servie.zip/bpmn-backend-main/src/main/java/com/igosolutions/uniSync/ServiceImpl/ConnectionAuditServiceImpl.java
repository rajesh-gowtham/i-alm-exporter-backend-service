package com.igosolutions.uniSync.ServiceImpl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.ConnectionAudits;
import com.igosolutions.uniSync.Respository.ConnectionAuditRepository;
import com.igosolutions.uniSync.Service.ConnectionAuditService;

@Service
public class ConnectionAuditServiceImpl implements ConnectionAuditService{

	@Autowired
	private ConnectionAuditRepository connauditRepo;
	

	@Override
	public List<ConnectionAudits> getAllConnectionAudits() {
		  LocalDate currentdate = LocalDate.now();
	      //Getting the current month
	      String currentMonth = currentdate.getMonth().toString();
	      int currentYear = currentdate.getYear();
	      System.out.println("Current month: "+currentYear);
		
		List<ConnectionAudits> listconnauidts = connauditRepo.getCurrentMonthConnectionaudits();
		return listconnauidts;
		
	}
	
	@Override
	public List<ConnectionAudits> getSelectedConnectionaudits(String auditname) {
		List<ConnectionAudits> listconnauidts = connauditRepo.getSelectedConnectionaudits(auditname);
		return listconnauidts;
		
	}
	@Override
	public List<ConnectionAudits> getFilterConnectionaudits(String auditname, String startdate,String enddate) {
		StringBuilder enddate_=new StringBuilder(enddate);
		
		
		// Retun Without Filter
		List<ConnectionAudits> listconnauidts = connauditRepo.getAllAudit();
		return listconnauidts;
		
////		String st=startdate +" 00:00:00";
////		sc.append(" 00:00:00");
//		System.out.println("select * from connectionaudit u WHERE u.connectionname= '"+auditname+"' and  auditdatetime BETWEEN '"+startdate+"' AND '"+enddate_+"'");
//		List<ConnectionAudits> listconnauidts = connauditRepo.getFilterConnectionaudits(auditname,startdate,enddate_);
//		return listconnauidts;
//		
	}
	
	

	@Override
	public void saveConnectionAuditData(ConnectionAudits connaudit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveconnectionAudit(ConnectionAudits connaudit) {
		connauditRepo.save(connaudit);
		
	}

}
