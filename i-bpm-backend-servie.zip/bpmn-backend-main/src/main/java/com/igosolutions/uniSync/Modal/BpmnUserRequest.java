package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;

public class BpmnUserRequest {

	
	private Long userid;
    private String firstname;
    private String lastname;
    private String email;
    private String role;
    private String mobileno;
    private String password;
    private String organization;
    private String image;
    private String resettoken;
    private UserImage userimage;
    
    public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getResettoken() {
		return resettoken;
	}

	public void setResettoken(String resettoken) {
		this.resettoken = resettoken;
	}

	public UserImage getUserimage() {
		return userimage;
	}

	public void setUserimage(UserImage userimage) {
		this.userimage = userimage;
	}

	public class UserImage{
    	private String imgname;
        private String imgcontent;
		public String getImgname() {
			return imgname;
		}
		public void setImgname(String imgname) {
			this.imgname = imgname;
		}
		public String getImgcontent() {
			return imgcontent;
		}
		public void setImgcontent(String imgcontent) {
			this.imgcontent = imgcontent;
		}
    }
}
