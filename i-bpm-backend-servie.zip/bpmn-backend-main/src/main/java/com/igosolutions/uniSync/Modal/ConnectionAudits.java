package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Connectionaudit")
public class ConnectionAudits {

	public ConnectionAudits() {
		
	}
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	private String connectionname;
	private String connectionauditdescription;
	private String auditdatetime;
	private String MEID;
	private String ALMID;
	private String SyncDate;
	private String Direction;
	
	public String getDirection() {
		return Direction;
	}
	public void setDirection(String Direction) {
		this.Direction = Direction;
	}
	
	public String getSyncDate() {
		return SyncDate;
	}
	public void setSyncDate(String SyncDate) {
		this.SyncDate = SyncDate;
	}
	
	
	public String getMEID() {
		return MEID;
	}
	public void setMEID(String MEID) {
		this.MEID = MEID;
	}
	
	public String getALMID() {
		return ALMID;
	}
	public void setALMID(String ALMID) {
		this.ALMID = ALMID;
	}
	
	
	public String getConnectionname() {
		return connectionname;
	}
	public void setConnectionname(String connectionname) {
		this.connectionname = connectionname;
	}
	public String getConnectionauditdescription() {
		return connectionauditdescription;
	}
	public void setConnectionauditdescription(String connectionauditdescription) {
		this.connectionauditdescription = connectionauditdescription;
	}
	public String getAuditdatetime() {
		return auditdatetime;
	}
	public void setAuditdatetime(String eventhandledate) {
		this.auditdatetime = eventhandledate;
	}
	
	
	
	
}
