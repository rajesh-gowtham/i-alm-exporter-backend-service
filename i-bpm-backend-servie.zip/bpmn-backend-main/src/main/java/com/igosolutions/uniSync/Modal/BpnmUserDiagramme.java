package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ibpmn_user_diagramme")
public class BpnmUserDiagramme {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "diagram_xml_id")
	private int diagramXmlId;
	@Column(name = "userid")
	private Long userid;
	@Column(name = "xml_data")
	private String xmlData;
    @Column(name = "language_name")
	private String languageName;
	@Column(name = "language_code")
	private String languageCode;


	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getXmlData() {
		return xmlData;
	}
	public void setXmlData(String xmlData) {
		this.xmlData = xmlData;
	}
	@Override
	public String toString() {
		return "BpnmUserDiagramme [diagramXmlId=" + diagramXmlId + ", userid=" + userid + ", xmlData=" + xmlData
				+ ", languageName=" + languageName + ", languageCode=" + languageCode + "]";
	}
}