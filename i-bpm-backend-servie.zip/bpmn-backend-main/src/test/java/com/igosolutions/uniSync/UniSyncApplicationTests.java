package com.igosolutions.uniSync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniSyncApplicationTests {

//	@Test
	void contextLoads() {
	}

}
