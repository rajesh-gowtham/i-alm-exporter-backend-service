import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { Injectable } from '@nestjs/common';
import { Ref_usersService } from '../Services/Ref_usersService';
const prisma = new PrismaClient();
@Injectable()
export class TokenValidate {
    constructor(private readonly Services: Ref_usersService) { }


   async CheckTokenValidate(bizunit_gkey) {
       return this.Services.CheckExistEmail(bizunit_gkey)
     }

}
