import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_settingsServices {
  async GetSettingsDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.ref_settings.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log('GetSettingsDetailsbyOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteSettingsByOrg(gkey) {
    try {
      const deleteSettings = await prisma.ref_settings.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>" + gkey);
      return deleteSettings;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreateSettingsByOrg(gkey, Name, value1, value2, Description) {
    try {
      const SettingsInput: Prisma.Ref_settingsCreateInput = {
        Name: Name,
        Value1: value1,
        Value2: value2,
        Description: Description,
        status: true,
        bizunit: { connect: { gkey: gkey } },
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const createdSettings = await prisma.ref_settings.create({
          data: SettingsInput,
        });
        console.log('CreateSettingsByOrg Created ' + gkey);
        return createdSettings;
      }
      catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async UpdateSettingsByOrg(gkey, Name, value1, value2, Description) {
    try {
      const updateUser = await prisma.ref_settings.update({
        where: {
          gkey: gkey
        },
        data: {
          Name: Name,
          Value1: value1,
          Value2: value2,
          Description: Description,
        },
      })
      console.log('CreateSettingsByOrg Created ' + gkey);
      return updateUser;
    }
    catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}