import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_ReferenceSevices {
  async GetReferenceDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.ref_aut_app.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log('GetReferenceDetailsbyOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async DeleteReferenceByOrg(Gkey) {
    try {
      const deleteReference = await prisma.ref_aut_app.delete({
        where: {
          gkey: Gkey,
        },
      })
      console.log("Deleted ==>" + Gkey);
      return deleteReference;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreateReferenceByOrg(type, Value, description, status, gkey) {
    try {
      console.log('CreateReferenceByOrg ' + type);
      const ReferenceInput: Prisma.Ref_aut_appCreateInput = {
        type: type,
        Value: Value,
        description: description,
        status: status,
        bizunit: { connect: { gkey: gkey } },
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const createdReference = await prisma.ref_aut_app.create({
          data: ReferenceInput,
        });
        console.log('CreateReferenceByOrg Created ' + type);
        return createdReference;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdateReferenceByOrg(type, Value, description, status, gkey) {
    try {
      console.log('CreateReferenceByOrg ' + type);
      const updateUser = await prisma.ref_aut_app.update({
        where: {
          gkey: gkey
        },
        data: {
          type: type,
          Value: Value,
          description: description,
          status: status,
        },
      })
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

}
