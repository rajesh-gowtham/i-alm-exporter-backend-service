import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_rolesServices {
  async GetrolesDetailsbyOrg(MasterBizUitKey) {
    try {
      const findNulls = await prisma.ref_roles.findMany({
        where: {
          bizunit_gkey: MasterBizUitKey,
        },
      })
      //  console.log('GetrolesDetailsbyOrg >>>>>>>>>>>>>> :' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      console.log('GetrolesDetailsbyOrg error>>>>>>>>>>>>>> :' + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleterolesByOrg(Gkey) {
    let Message = '';
    try {
      //Check If Role Assign For User
      const Isexist = await prisma.argo_Users_roles_details.count({
        where: {
          Role_Gkey: Gkey,
        },
      })

      console.log("----- RoleKey Isexist:" + Isexist)
      if (Isexist == 1) {
        Message = "Role Exist with User";
        return Message
      }

      //Argo Role Delete 
      const IsexistArgoRole = await prisma.argo_roles_privileges.deleteMany({
        where: {
          Role_Gkey: Gkey,
        },
      })

      //Delete Role
      const deleteroles = await prisma.ref_roles.delete({
        where: {
          gkey: Gkey,
        },
      })
      console.log("Deleted ==>" + Gkey);
      Message = 'Role Deleted Successfully';
      return Message;
    } catch (error) {
      Message = error;
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreaterolesByOrg(Name, Description, MasterBizUitKey) {
    try {
      const rolesInput: Prisma.Ref_rolesCreateInput = {
        name: Name,
        description: Description,
        bizunit: { connect: { gkey: MasterBizUitKey } },
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const createdroles = await prisma.ref_roles.create({
          data: rolesInput,
        });
        console.log('CreaterolesByOrg Created ' + Name);
        return createdroles;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdateRoleByOrg(gkey, Name, Description) {
    try {
      console.log('UpdateRoleByOrg Name : ' + Name);
      const updateRole = await prisma.ref_roles.update({
        where: {
          gkey: gkey
        },
        data: {
          name: Name,
          description: Description,
        },
      })
      return updateRole;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}
