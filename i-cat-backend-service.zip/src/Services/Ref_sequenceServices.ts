import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_sequenceServices {
  async GetsequenceDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.ref_sequence.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log('GetsequenceDetailsbyOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      console.log(error)
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeletesequenceByOrg(gkey) {
    try {
      const deletesequence = await prisma.ref_sequence.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>" + gkey);
      return deletesequence;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
 // Added by Rajesh (14-07-2023) for single sequence creation (connect bizunit)
  async CreatesequenceByOrg(lable, description, Apply_To, Parameterizable, bizunit) {
    try {
      const createInput: Prisma.Ref_sequenceCreateInput = {
        lable: lable,
        description: description,
        Parameterizable: Parameterizable,
        bizunit: { connect: { gkey: bizunit } },
        Apply_To: { connect: { gkey: Apply_To } },
      }
      const createdsequence = await prisma.ref_sequence.create({
        data: createInput,
      });
      console.log('CreatesequenceByOrg Created  OK');
      return createdsequence;
    } catch (error) {
      console.log(' error ' + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async UpdatesequenceByOrg(lable, description, Apply_To, Parameterizable, gkey) {
    try {

      console.log('CreatesequenceByOrg Created ' + gkey);

      const updateUser = await prisma.ref_sequence.update({
        where: {
          gkey: gkey
        },
        data: {
          lable: lable,
          description: description,
          Parameterizable: Parameterizable,
          Apply_To: { connect: { gkey: Apply_To } },
        }
      })
      console.log('CreatesequenceByOrg Created ' + gkey);
      return updateUser;
    }
    catch (error) {
      console.error(error)
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}