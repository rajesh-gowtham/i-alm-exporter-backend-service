import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { throwError } from 'rxjs';
import { connect } from 'http2';
import admin from 'FireBase/firebase.config';
const prisma = new PrismaClient();
@Injectable()
export class Ref_usersService {
  async AllUsersbyOrg() {
    try {
      console.log('FindAllByOrgRef_users 1111');
      const findNulls = await prisma.ref_users.findMany()
      const bizunit = await prisma.ref_master_bizunit.findMany()
      // {
      //   where: {
      //     bizunit_gkey: bizunit_gkey,
      //   },
      // })
      // 
      console.log('FindAllByOrgRef_users ', (findNulls), bizunit);
      return findNulls;
    } catch (error) {
      console.log('FindAllByOrgRef_users error' ,error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  //Added by Mubarak 16/03 
  async GetOrgDetailsByEmail(email) {
    try {
      prisma.$connect();
      //Validate User Start
      let postCount = {};
      try {
        postCount = await prisma.ref_users.count({
          where: {
            email: email,
          },
        })
        console.log("EXIST ==>" + postCount);
        if (postCount == 0) {
          return "Not Exist";
        }
      } catch (error) {
        await prisma.$disconnect();
        throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
      }
      //Validate User End
      console.log("prisma.$connect() Success *******")
      const users = await prisma.ref_users.findFirst({
        where: {
          email: email,
        },
      })
      console.log("USER:" + JSON.stringify(users))
      const masterdetails = await prisma.ref_master_bizunit.findFirst({
        where: {
          gkey: users["bizunit_gkey"],
        },
      })


      // Added by Mubarak 
      const GetRoleID = await prisma.argo_Users_roles_details.findFirst({
        where: {
          User_Gkey: users["gkey"],
        },
      })
      const Roles = await prisma.ref_roles.findFirst({
        where: {
          gkey: GetRoleID['Role_Gkey'].toString()
        },
      })

      var UserDetails = {
        Isexist: postCount,
        Bizunit_gkey: users["bizunit_gkey"],
        Gkey: users["gkey"],
        UserName: users["firstName"] + " " + users["lastName"],
        Organization: masterdetails["name"],
        RoleGkey: GetRoleID["Role_Gkey"],
        RoleName: Roles["name"],
      }
      console.log("final User details ", UserDetails)
      return UserDetails;
    } catch (error) {
      await prisma.$disconnect();
      console.log("****** error" + error)
      console.log("prisma.$Disconnected() Success ******")
      throwError;
    }
  }

  async FindOrgByEamil(email) {

    try {
      const findNulls = await prisma.ref_users.findMany({
        where: {
          email: email,
        },
      })
      console.log('FindOrgByEamil ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async CreateUserByOrg(gkey, firstname, lastname, email, status, rolegkey, firebaseid) {

    try {
      // Add User Details:
      const userInput: Prisma.Ref_usersCreateInput = {
        firstName: firstname,
        lastName: lastname,
        email: email,
        status: true,
        firebaseid: firebaseid,
        bizunit: { connect: { gkey: gkey } },
        updatedAt: new Date(2023, 1, 23)
      };
      console.log('Ref_usersCreateInput', userInput)
      try {
        const createdUser = await prisma.ref_users.create({
          data: userInput,
        });
        console.log('CreateUserByOrg Created ' + JSON.stringify(createdUser));
        let usergkey = createdUser["gkey"].toString();
        // Add User Role Details :
        const UserRoleDetail: Prisma.Argo_Users_roles_detailsCreateInput = {
          //UserGkey: usergkey,
          UserGkey: { connect: { gkey: usergkey } },
          RoleGkey: { connect: { gkey: rolegkey } },
          updatedAt: new Date(2023, 1, 23)
        };
        const createdUserDetails = await prisma.argo_Users_roles_details.create({
          data: UserRoleDetail,
        });
        console.log('>>>>>>>>> createdUserDetails Created  ' + JSON.stringify(createdUserDetails));
        return createdUser;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async CheckExistEmail(email) {
    try {
      const postCount = await prisma.ref_users.count({
        where: {
          email: email,
        },
      })
      console.log("EXIST ==>" + postCount);
      return postCount;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async UpdateUser(gkey, firstname, lastname, email, Role_Gkey, argo_User_key) {
    try {
      //Update ref_users
      const updateUser = await prisma.ref_users.update({
        where: {
          gkey: gkey
        },
        data: {
          firstName: firstname,
          lastName: lastname,
          email: email,
        },
      })
      //Update argo_Users_roles_details
      const UserRole = await prisma.argo_Users_roles_details.update({
        where: {
          gkey: argo_User_key,
        },
        data: {
          Role_Gkey: Role_Gkey,
        },
      })
      console.log("*********** UpdateUser gkey ==>" + gkey);
      return updateUser;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  // async DeleteUserByOrg(gkey) {
  //   ///Delete User In User_Role Table  
  //   try {
  //     const findNulls = await prisma.argo_Users_roles_details.findMany({
  //       where: {
  //         User_Gkey: gkey,
  //       },
  //     })
  //     const UserDetail = await prisma.ref_users.findFirst({
  //       where: {
  //         gkey: gkey
  //       }
  //     })
  //     console.log("ooooo",gkey);

  //     // const firestore = await admin.auth().deleteUser(UserDetail.firebaseid);
  //     // console.log(firestore);
  //     console.log("findNulls[gkey]" , findNulls)
  //     const deleteUserRoleDetails = await prisma.argo_Users_roles_details.delete({
  //       where: {
  //         gkey: findNulls[0]["gkey"]
  //       },
  //     })

  //     const deleteUser = await prisma.ref_users.delete({
  //       where: {
  //         gkey: gkey,
  //       },
  //     })
  //     console.log("Deleted User -----> " + gkey);
  //     return deleteUser;

  //   } catch (error) {
  //     console.log("error User -----> ", error);
  //     await prisma.$disconnect();
  //     throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
  //   }
  // }



  async DeleteUserByOrg(gkey) {
    ///Delete User In User_Role Table    
    try {
      const findNulls = await prisma.argo_Users_roles_details.findMany({
        where: {
          User_Gkey: gkey,
        },
      })
      console.log(" findNulls[gkey]  -->  " + JSON.stringify(findNulls))

      const deleteUserRoleDetails = await prisma.argo_Users_roles_details.delete({
        where: {
          gkey: findNulls[0]["gkey"]
        },
      })

      // added By Rajesh 21-08-23 for delete relation in the map_group_user Table Before delete the User
      const mapGroupUsers = await prisma.map_group_user.deleteMany({
        where: {
          user_key: gkey
        }
      })
      console.log(" mapGroupUsers ", mapGroupUsers);

      // added By Rajesh 21-08-23 for to get user firebase id
      const UserDetail = await prisma.ref_users.findFirst({
        where: {
          gkey: gkey
        }
      })
      // added By Rajesh 21-08-23 for delete the user from firebase
      const firestore = await admin.auth().deleteUser(UserDetail.firebaseid);
      console.log(firestore);

      const deleteUser = await prisma.ref_users.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted User -----> ", gkey);
      return deleteUser;
    } catch (error) {
      console.log("error User -----> " + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }



}

export function CheckExistEmailApi(email) {
  try {
    const postCount = prisma.ref_users.count({
      where: {
        email: email,
      },
    })
    console.log("EXIST ==>" + postCount);
    return postCount;
  } catch (error) {
    prisma.$disconnect();
    throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
  }
}