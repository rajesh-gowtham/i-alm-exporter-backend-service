import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_scenarioServices {
  async GetscenarioDetailsbyOrg(bizunit_gkey) {
    try {
      const scenarios = await prisma.ref_scenario.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log(scenarios.length)
      const sce_seqs = await prisma.map_scenario_sequence.findMany();
      const sce_auts = await prisma.map_autapp_scenario.findMany();
      return { scenarios, sce_seqs, sce_auts };
    } catch (error) {
      await prisma.$disconnect();
      console.error(" error ", error)
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeletescenarioByOrg(gkey) {
    try {
      const deletescenario = await prisma.ref_scenario.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>" + gkey);
      return deletescenario;
    } catch (error) {
      console.error(" error ", error)
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeletemapScenarioSequence(scenario_key) {
    try {
      console.log("DeletemapScenarioSequence ");
      const deletemap_scenario_sequence = await prisma.map_scenario_sequence.deleteMany({
        where: {
          scenario_key: scenario_key,
        },
      })
      console.log("Deleted ==>OK ");
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteSinglemapScenarioSequence(gkey) {
    try {
      const deletemap_scenario_sequence = await prisma.map_scenario_sequence.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>OK ");
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async Deletemap_autapp_scenario(gkey) {
    try {
      const deletemap_scenario_sequence = await prisma.map_autapp_scenario.deleteMany({
        where: {
          scenario_key: gkey,
        },
      })
      console.log("Deleted ==>OK ");
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteSinglemap_autapp_scenario(gkey) {
    try {
      const deletemap_scenario_sequence = await prisma.map_autapp_scenario.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>OK ");
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async map_scenario_sequence(MapData) {
    try {
      const createdscenario = await prisma.map_scenario_sequence.createMany({
        data: MapData,
      });
      console.log("map_scenario_sequence OK");
      return createdscenario;
    } catch (error) {
      console.log("map_scenario_sequence error" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async map_autapp_scenario(MapData) {
    try {
      const createdscenario = await prisma.map_autapp_scenario.createMany({
        data: MapData,
      });
      console.log("map_autapp_scenario OK");
      return createdscenario;
    } catch (error) {
      console.log("map_autapp_scenario error" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async Updatemap_autapp_scenario(MapData) {
    try {
      const deletemap_scenario_sequence = await prisma.map_scenario_sequence.deleteMany({
        where: {
          scenario_key: MapData[0]["scenario_key"],
        },
      })

      const createdscenario = await prisma.map_autapp_scenario.createMany({
        data: MapData,
      });
      console.log("Updatemap_autapp_scenario OK");
      return createdscenario;
    } catch (error) {
      console.log("Updatemap_autapp_scenario error" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  async Update_map_scenario_sequence(MapData) {
    try {
      const deletemap_scenario_sequence = await prisma.map_scenario_sequence.deleteMany({
        where: {
          scenario_key: MapData[0]["scenario_key"],
        },
      })
      console.log("deletemap_scenario_sequence OK");
      const createdscenario = await prisma.map_scenario_sequence.createMany({
        data: MapData,
      });
      console.log("Update_map_scenario_sequence OK");
      return createdscenario;
    } catch (error) {
      console.log("map_scenario_sequence error" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreatescenarioByOrg(displayName, longName, description, stream_gkey, MasterBizUitKey) {
    console.log('CreatescenarioByOrg bizunit ' + MasterBizUitKey);
    try {
      const scenarioInput: Prisma.Ref_scenarioCreateInput = {
        displayName: displayName,
        longName: longName,
        description: description,
        Stream_key: { connect: { gkey: stream_gkey } },
        bizunit: { connect: { gkey: MasterBizUitKey } },
        updatedAt: new Date(2023, 1, 23)
      };
      // console.log('CreatescenarioByOrg scenarioInput ' + JSON.stringify(scenarioInput));
      try {
        const createdscenario = await prisma.ref_scenario.create({
          data: scenarioInput,
        });
        console.log('CreatescenarioByOrg Created ' + MasterBizUitKey);
        return createdscenario;
      }
      catch (error) {
        console.log(' error ' + error);
        throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
      }
    } catch (error) {
      console.log(' error ' + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async UpdatescenarioByOrg(gkey, displayName, longName, description, stream_gkey) {
    console.log(' UpdatescenarioByOrg service' + gkey);
    try {

      const updateUser = await prisma.ref_scenario.update({
        where: {
          gkey: gkey
        },
        data: {
          displayName: displayName,
          longName: longName,
          description: description,
          Stream_gkey: stream_gkey,
          updatedAt: new Date(2023, 1, 23)
        },
      })
      console.log('UpdatescenarioByOrg Created ' + gkey);
      return updateUser;
    }
    catch (error) {
      console.log('CreatescenarioByOrg error ' + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}