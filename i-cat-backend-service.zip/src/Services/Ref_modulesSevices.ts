import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_modulesServices {

  async GetmodulesDetailsbyOrg(Gkey) {
    try {
      const findNulls = await prisma.ref_modules.findMany({
        where: {
          gkey: Gkey,
        },
      })
      console.log('GetmodulesDetailsbyOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async DeletemodulesByOrg(Gkey) {
    try {
      const deletemodules = await prisma.ref_modules.delete({
        where: {
          gkey: Gkey,
        },
      })
      console.log("Deleted ==>" + Gkey);
      return deletemodules;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreatemodulesByOrg(Name, Description) {
    try {
      console.log('CreatemodulesByOrg ' + Name);
      const modulesInput: Prisma.Ref_modulesCreateInput = {
        name: Name,
        Description: Description,
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const createdmodules = await prisma.ref_modules.create({
          data: modulesInput,
        });
        console.log('CreatemodulesByOrg Created ' + Name);
        return createdmodules;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}
