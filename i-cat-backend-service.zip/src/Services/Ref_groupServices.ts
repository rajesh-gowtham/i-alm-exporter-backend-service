import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { Injectable, HttpException, HttpStatus, } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_groupServices {

  async GetgroupDetailsbyOrg(MasterBizUitKey) {
    try {
      const GetGroup = await prisma.ref_group.findMany({
        where: {
          bizunit_gkey: MasterBizUitKey,
        },
      })
      const UsersGkeyMap = await prisma.map_group_user.findMany({
      })
      let GroupMap = [];

      for (var i = 0; i < GetGroup.length; i++) {
        const UsersGkey = await prisma.map_group_user.findMany({
          where: {
            group_gkey: GetGroup[i].gkey,
          },
        })

        let Group = {
          gkey: GetGroup[i].gkey,
          lable: GetGroup[i].lable,
          description: GetGroup[i].description
        }
        GroupMap.push({
          Group: Group,
          Users: UsersGkeyMap.filter((list) => list.group_gkey === GetGroup[i].gkey)
        });
      }

      const group_scenario = await prisma.map_group_scenario.findMany();
      console.log('group_scenario>>>>>>>>>>>>>>>>>>>>>>>>', group_scenario)
      return { GroupMap, group_scenario };
    } catch (error) {
      console.error('GetgroupDetailsbyOrg error>>>>>>>>>>>>>> :' + error);
      await prisma.$disconnect();
    }
  }
  async DeletegroupByGkey(Gkey) {
    try {

      //Delete map_group_user
      const deletegroup = await prisma.map_group_user.deleteMany({
        where: {
          group_gkey: Gkey
        },
      })
      //Delete ref_group
      const deleteGroupUserMap = await prisma.ref_group.delete({
        where: {
          gkey: Gkey
        },
      })

      return deletegroup;
    } catch (error) {
      console.log(error)
      await prisma.$disconnect();
    }
  }

  async CreategroupByOrg(lable, Description, MasterBizUitKey, Map_User_Key) {
    try {
      // Create Group 
      const groupInput: Prisma.Ref_groupCreateInput = {
        lable: lable,
        description: Description,
        bizunit: { connect: { gkey: MasterBizUitKey } },
        updatedAt: new Date(2023, 1, 23)
      };
      const CreategroupInput = await prisma.ref_group.create({
        data: groupInput,
      });
      console.log("CREATED OK >>>> ", CreategroupInput)
      // Map User Group 
      if (Map_User_Key.length > 0) {
        let Map_User_Group = [];
        let usersgkey = Map_User_Key.map(function (gkey) {
          Map_User_Group.push({
            group_gkey: CreategroupInput.gkey,
            user_key: gkey
          });
        });
        const Create_Map_groupUserInput = await prisma.map_group_user.createMany({
          data: Map_User_Group,
        });
        console.log("CREATED Create_Map_groupUserInput OK >>>> ")
      }
      return CreategroupInput
    } catch (error) {
      console.log("error >>>> " + error)

      await prisma.$disconnect();
    }
  }

  async UpdateGroupByGkey(lable, description, Map_GroupUser, Groupgkey) {
    try {
      const updateGroup = await prisma.ref_group.update({
        where: {
          gkey: Groupgkey
        },
        data: {
          lable: lable,
          description: description,
        },
      })
      // Map User Group 
      if (Map_GroupUser.length > 0) {
        let Map_User_Group = [];
        let usersGkey = Map_GroupUser.map(function (AssignUsergkey) {
          Map_User_Group.push({
            group_gkey: Groupgkey,
            user_key: AssignUsergkey
          });
        });

        //Delete Mapkey.group_gkey,
        const map_group_userdata = await prisma.map_group_user.deleteMany({
          where: {
            group_gkey: Groupgkey
          },
        })

        const Create_Map_groupUserInput = await prisma.map_group_user.createMany({
          data: Map_User_Group,
        });
        console.log("CREATED Create_Map_groupUserInput OK >>>> ")
        return Create_Map_groupUserInput
      } else {
        const map_group_userdata = await prisma.map_group_user.deleteMany({
          where: {
            group_gkey: Groupgkey
          },
        })
        console.log(" else ", Map_GroupUser);
      }


    } catch (error) {
      await prisma.$disconnect();
    }
  }

  async CreateMapUserByGroup(MapDetails) {
    try {


      if (MapDetails.length > 0) {
        let Map_User_Group = [];
        let tempkey = MapDetails.map(function (Mapkey) {
          Map_User_Group.push({
            group_gkey: Mapkey.group_gkey,
            user_key: Mapkey.user_gkey
          });
        });
        const Create_Map_groupUserInput = await prisma.map_group_user.createMany({
          data: Map_User_Group,
        });
        console.log("CREATED CreateMapUserByGroup OK >>>> ")
        return Create_Map_groupUserInput;
      }

    } catch (error) {
      console.log('CreateMapUserByGroup error>>>>>>>>>>>>>> :' + error);
      await prisma.$disconnect();
    }
  }

  //
  async MapScenarioByGroup(GroupGkey) {
    try {

      //Delete map_group_user
      const Createmap_group_scenario = await prisma.map_group_scenario.createMany({
        data: GroupGkey
      })
      console.log("CREATED MapScenarioByGroup OK >>>> ")
      return Createmap_group_scenario;
    } catch (error) {
      await prisma.$disconnect();
    }
  }


  async UpdateMapScenarioByGroup(MapData) {
    console.log('UpdateMapScenarioByGroup', MapData[0]["group_gkey"], MapData)
    try {
      //Delete map_group_user
      const deletegroup = await prisma.map_group_scenario.deleteMany({
        where: {
          group_gkey: MapData[0]["group_gkey"]
        },
      })
      //Re Add Scenarios
      const Createmap_group_scenario = await prisma.map_group_scenario.createMany({
        data: MapData
      })
      console.log("CREATED Createmap_group_scenario OK >>>> ")
      return Createmap_group_scenario;
    } catch (error) {
      console.log("UpdateMapScenarioByGroup error" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdateMapUserByGroup(MapDetails) {
    try {


      if (MapDetails.length > 0) {
        let Map_User_Group = [];
        let GroupKey = '';
        let tempkey = MapDetails.map(function (Mapkey) {
          Map_User_Group.push({
            group_gkey: Mapkey.group_gkey,
            user_key: Mapkey.user_gkey
          });
          GroupKey = Mapkey.group_gkey
        });

        //Delete Mapkey.group_gkey,
        const map_group_userdata = await prisma.map_group_user.deleteMany({
          where: {
            group_gkey: GroupKey
          },
        })
        if (GroupKey != '') {
          //CREATE Mapkey.group_gkey,
          const Create_Map_groupUserInput = await prisma.map_group_user.createMany({
            data: Map_User_Group,
          });
          console.log("CREATED UpdateMapUserByGroup OK >>>> ")
          return Create_Map_groupUserInput;
        }
        return map_group_userdata;
      }

    } catch (error) {
      console.log('CreateMapUserByGroup error>>>>>>>>>>>>>> :' + error);
      await prisma.$disconnect();
    }
  }


  async DelteMapScenarioByGroup(GroupGkey) {
    try {

      //Delete map_group_user
      const deletegroup = await prisma.map_group_scenario.deleteMany({
        where: {
          group_gkey: GroupGkey
        },
      })
      console.log("CREATED DelteMapScenarioByGroup OK >>>> ")
      return deletegroup;
    } catch (error) {
      await prisma.$disconnect();
    }
  }

  async DeleteMapAllUserByGroup(GroupGkey) {
    try {

      //Delete map_group_user
      const deletegroup = await prisma.map_group_user.deleteMany({
        where: {
          group_gkey: GroupGkey
        },
      })
      console.log("CREATED DeleteMapAllUserByGroup OK >>>> ")
      return deletegroup;
    } catch (error) {

      await prisma.$disconnect();
    }
  }

  async DeleteMapUserByGroup(user_key) {
    try {

      //Delete map_group_user
      const deletegroup = await prisma.map_group_user.deleteMany({
        where: {
          user_key: user_key
        },
      })
      console.log("CREATED DeleteMapUserByGroup OK >>>> ")
      return deletegroup;
    } catch (error) {

      await prisma.$disconnect();
    }
  }



}
