import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { CheckExistEmailApi } from './Ref_usersService';
const prisma = new PrismaClient();
@Injectable()
export class Argo_dataset_attrib_descServices {
  async GetColumnDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.argo_dataset_attrib_desc.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log("bizunit_gkey==>" + JSON.stringify(findNulls))
      return findNulls;
    } catch (error) {
      console.log("error 900" + error);
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async GetBrowseColumnDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.argo_dataset_attrib_desc.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
          mode: 'Browse',
        },
      })
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async DeleteColumnByOrg(gkey) {
    try {
      const DeleteColumn = await prisma.argo_dataset_attrib_desc.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==> OK");
      return DeleteColumn;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async CreateColumnByOrg(MasterBizUitKey, shortName, displayName, control, Applie_To, value, Mode) {
    try {
      const ColumnInput: Prisma.Argo_dataset_attrib_descCreateInput = {
        shortName: shortName,
        displayName: displayName,
        control: control,
        value: value,
        bizunit: { connect: { gkey: MasterBizUitKey } },
        Applie_To_key: { connect: { gkey: Applie_To } },
        mode: Mode,
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const CreateCoilmn = await prisma.argo_dataset_attrib_desc.create({
          data: ColumnInput,
        });
        console.log('CreateColumnByOrg Created OK==>');
        return CreateCoilmn;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async CreateColumnManyByOrg(bulkdata) {
    try {
      try {
        const createManyColumn = await prisma.argo_dataset_attrib_desc.createMany({
          data: bulkdata,
        })
        return createManyColumn;
      } catch (error) {
        console.log(' error CreateColumnManyByOrg : ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async UpdateColumnByOrg(gkey, shortName, displayName, control, Applie_To, value) {
    try {
      const updateColumn = await prisma.argo_dataset_attrib_desc.update({
        where: {
          gkey: gkey
        },
        data: {
          shortName: shortName,
          displayName: displayName,
          control: control,
          value: value,
        },
      })
      console.log('UpdateColumnByOrg Created ' + gkey);
      return updateColumn;
    }
    catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}
