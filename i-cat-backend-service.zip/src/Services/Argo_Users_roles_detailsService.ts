import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Argo_Users_roles_detailsService {
  async GetRoleNameByGkey(gkey) {
    let Roledetails = {
      RoleGkey: '',
      RoleName: '',
      argo_Users_rolesgkey: ''
    };
    try {
      const RoleKey = await prisma.argo_Users_roles_details.findFirst({
        where: {
          User_Gkey: gkey,
        },
      })
      const RoleName = await prisma.ref_roles.findFirst({
        where: {
          gkey: RoleKey.Role_Gkey,
        },
      })
      Roledetails.RoleGkey = RoleKey.Role_Gkey;
      Roledetails.RoleName = RoleName.name;
      Roledetails.argo_Users_rolesgkey = RoleKey.gkey;
      // console.log('Roledetails >>> ' + JSON.stringify(Roledetails));
      return Roledetails;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


}