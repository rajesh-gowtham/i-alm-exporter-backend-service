import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_streamServices {
  async GetstreamDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.ref_stream.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log('GetstreamDetailsbyOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async DeletestreamByOrg(gkey) {
    try {
      const deletestream = await prisma.ref_stream.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>" + gkey);
      return deletestream;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async CreatestreamByOrg(gkey, Name, Description) {
    try {
      const streamInput: Prisma.Ref_streamCreateInput = {
        name: Name,
        description: Description,
        bizunit: { connect: { gkey: gkey } },
        updatedAt: new Date(2023, 1, 23)
      };
      try {
        const createdstream = await prisma.ref_stream.create({
          data: streamInput,
        });
        console.log('CreatestreamByOrg Created ' + gkey);
        return createdstream;
      } catch (error) {
        console.log(' error ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdatestreamByOrg(gkey, Name, Description) {

    try {
      const updateStream = await prisma.ref_stream.update({
        where: {
          gkey: gkey
        },
        data: {
          name: Name,
          description: Description,
        },
      })
      console.log('UpdatestreamByOrg Created ' + gkey);
      return updateStream;
    }
    catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

}
