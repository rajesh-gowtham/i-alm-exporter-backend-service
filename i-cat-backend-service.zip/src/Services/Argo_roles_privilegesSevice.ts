import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Argo_roles_privilegesSevice {
  async SetPrivilageToRole(RolePrivilageData) {
    try {
      const DeleteManyPrivilages = await prisma.argo_roles_privileges.deleteMany({
        where: {
          Role_Gkey: {
            in: RolePrivilageData[0]["Role_Gkey"]
          }
        }
      })
      console.log("DeleteManyPrivilages OK==>:")
      const createManyPrivilages = await prisma.argo_roles_privileges.createMany({
        data: RolePrivilageData,
      })
      return createManyPrivilages;

    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  
  // Added By Mubarak Ali  18-04-2023
  async DeleteRolePrivilegeDetails(RoleGkey) {
    try {
      const DeleteManyPrivilages = await prisma.argo_roles_privileges.deleteMany({
        where: {
          Role_Gkey: RoleGkey
        }
      })
      console.log("ALL Privilege Removed FOR ROLE OK");
      return DeleteManyPrivilages;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async GetPrivilageToRole(MasterBizUitKey) {
    try {
      var RolePrivilegeDetails = {}

      //GET Roles
      const Roles = await prisma.ref_roles.findMany({
        where: {
          bizunit_gkey: MasterBizUitKey,
        },
      })
      //     console.log("Roles >>>>" + JSON.stringify(Roles))
      //RoleDetailsKey
      let Argo_roles_Details = {}
      for (var i = 0; i < Roles.length; i++) {
        let Argo_roles = await prisma.argo_roles_privileges.findMany({
          where: {
            Role_Gkey: Roles[i].gkey,
          },
        })

        Argo_roles_Details[Roles[i].name] = Argo_roles
      }
      RolePrivilegeDetails["Roles"] = Roles
      RolePrivilegeDetails["Argo_roles_Details"] = Argo_roles_Details
      //   console.log("RolePrivilegeDetails >>>>" + JSON.stringify(RolePrivilegeDetails))
      return RolePrivilegeDetails;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }




}