import { PrismaClient, Prisma, Ref_master_bizunit } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_master_bizunitService {
  async CreateRef_master_bizunit(orgname) {
    try {
      const userInput: Prisma.Ref_master_bizunitCreateInput = {
        name: orgname,
        status: false,
        updatedAt: new Date(2023, 1, 23)
      };
      const createdOrg = prisma.ref_master_bizunit.create({
        data: userInput,
      });
      console.log("CreateRef_master_bizunit > " + createdOrg);
      return createdOrg;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async CheckExistRef_master_bizunit(orgname) {
    try {
      const postCount = await prisma.ref_master_bizunit.count({
        where: {
          name: orgname,
        },
      })
      console.log("CheckExistRef_master_bizunit ==>" + postCount);
      return postCount;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async GetOrgIDbyName(name) {
    try {
      const findNulls = await prisma.ref_master_bizunit.findMany({
        where: {
          name: name,
        },
      })
      console.log('GetOrgIDbyName ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async GetOrgbyID(ID) {
    try {
      const findNulls = await prisma.ref_master_bizunit.findMany({
        where: {
          gkey: ID,
        },
      })
      console.log('GetOrgbyID ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async GetAllOrg() {
    try {
      const findNulls = await prisma.ref_master_bizunit.findMany({
      })
      // console.log('GetAllOrg ' + JSON.stringify(findNulls));
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteRef_master_bizunit(orgname) {
    try {
      const prisma = new PrismaClient();
      const deleteUser = await prisma.ref_master_bizunit.delete({
        where: {
          gkey: orgname,
        },
      })
      console.log("Deleted ==>" + orgname);
      console.log("Final JSON ==>" + deleteUser);
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
}
