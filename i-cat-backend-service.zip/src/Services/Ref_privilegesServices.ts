import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
const prisma = new PrismaClient();
@Injectable()
export class Ref_privilegesServices {
  async GetprivilegesDetailsbyOrg() {
    try {
      var PrivilageMod = [];
      const privilage = await prisma.ref_privileges.findMany({
        // Where Condition Added By Mubarak 18-04-2023
        // where: {
        //   status:true,
        // },
      })
      const moules = await prisma.ref_modules.findMany({
      })
      PrivilageMod.push(privilage)
      PrivilageMod.push(moules)
      //  console.log('GetprivilegesDetailsbyOrg ' + JSON.stringify(PrivilageMod));
      return PrivilageMod;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  async UpdateBulkPrivilage(BulkData) {
    try {
      const updateUser = await prisma.ref_privileges.updateMany({
        data: BulkData
      })
      console.log(" UpdateUser gkey ==>" + updateUser);
      return updateUser;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async GetEnablePrivilages(BulkData) {
    try {
      const FindEnable = await prisma.ref_privileges.findMany({
        where: {
          CanAdd: true,
          CanView: true,
          CanExcute: true,
          CanDelete: true,
          CanUpdate: true,
        },
      })
      console.log(" UpdateUser gkey ==>" + FindEnable);
      return FindEnable;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdatePrivilage(moduleKey, CanAdd, CanView, CanUpdate, CanExcute, CanDelete) {
    try {
      const updateUser = await prisma.ref_privileges.updateMany({
        where: {
          moduleKey: moduleKey
        },
        data: {
          CanAdd: CanAdd,
          CanView: CanView,
          CanUpdate: CanUpdate,
          CanExcute: CanExcute,
          CanDelete: CanDelete,
        },
      })
      console.log(" UpdateUser gkey ==>" + moduleKey);
      //Return Updated privilages
      return updateUser;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async UpdateprivilegesNamebyGkey(gkey, PName) {
    try {
      const updateUser = await prisma.ref_privileges.update({
        where: {
          gkey: gkey,
        },
        data: {
          Privilege_Name: PName,
        },
      })
      console.log(" UpdateprivilegesNamebyGkey PName ==>" + PName);
      return updateUser;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async UpdateprivilegesStatusByGkey(gkey, status) {
    try {
      const updateUser = await prisma.ref_privileges.update({
        where: {
          gkey: gkey,
        },
        data: {
          status: status,
        },
      })
      console.log(" UpdateprivilegesNamebyGkey status ==>" + gkey);
      return updateUser;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteprivilegesByOrg(Gkey) {
    try {
      const deleteprivileges = await prisma.ref_privileges.delete({
        where: {
          gkey: Gkey,
        },
      })
      console.log("Deleted ==>" + Gkey);
      return deleteprivileges;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }


  async CreateprivilegesByOrg(pName, moduleKey, CanAdd, CanView, CanUpdate, CanDelete, CanExcute) {
    try {
      const privilegesInput: Prisma.Ref_privilegesCreateInput = {
        Privilege_Name: pName,
        moduleKey: { connect: { gkey: moduleKey } },
        lable: pName,
        status: true,
        CanAdd: CanAdd,
        CanView: CanView,
        CanUpdate: CanUpdate,
        CanDelete: CanDelete,
        CanExcute: CanExcute,
      };
      try {
        const createdprivileges = await prisma.ref_privileges.create({
          data: privilegesInput,
        });
        console.log('CreateprivilegesByOrg Created ' + pName);
        return createdprivileges;
      } catch (error) {
        console.log(' error ' + error);
        return error;
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  async CreatePrivilageManyByOrg(bulkdata) {
    try {
      try {
        const createManyPrivilages = await prisma.ref_privileges.createMany({
          data: bulkdata,
        })
        return createManyPrivilages;
      } catch (error) {
        console.log(' error CreateColumnManyByOrg : ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
}
