import { PrismaClient, Prisma, Ref_users } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { CheckExistEmailApi } from './Ref_usersService';
const prisma = new PrismaClient();
@Injectable()
export class Transaction_Argo_dataset_attrib_descService {

  async GetBrowseColumnDetailsbyOrg(bizunit_gkey) {
    try {
      const findNulls = await prisma.transaction_Argo_dataset_attrib_desc.findMany({
        where: {
          bizunit_gkey: bizunit_gkey,
        },
      })
      console.log("GetBrowseColumnDetailsbyOrg :" + JSON.stringify(findNulls))
      return findNulls;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async DeleteColumnByOrg(gkey) {
    try {
      const DeleteColumn = await prisma.transaction_Argo_dataset_attrib_desc.delete({
        where: {
          gkey: gkey,
        },
      })
      console.log("Deleted ==>" + gkey);
      return DeleteColumn;
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  async DeleteAllTransactionByOrg() {
    try {
      // const DeleteTransaction = await prisma.transaction_Argo_dataset_attrib_desc.delete({
      //   where:{
      //     up:hh,
      //   },
      // })
      // console.log(' Success 302  DeleteAllTransactionByOrg : ' + JSON.stringify(DeleteTransaction));
      // return DeleteTransaction;  
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  async CreateColumnManyByOrg(bulkdata) {
    try {
      try {
        const createManyColumn = await prisma.transaction_Argo_dataset_attrib_desc.createMany({
          data: bulkdata,
        })
        console.log(' Success 302  CreateColumnManyByOrg : ' + JSON.stringify(createManyColumn));
        return createManyColumn;
      } catch (error) {
        console.log(' error CreateColumnManyByOrg : ' + error);
      }
    } catch (error) {
      await prisma.$disconnect();
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
}
