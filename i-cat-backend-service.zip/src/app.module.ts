import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { Ref_master_bizunitController } from './Controllers/Ref_master_bizunit';
import {Ref_usersController } from './Controllers/Ref_users';
import {Ref_settingsController } from './Controllers/Ref_settings';
import { Argo_dataset_attrib_descController } from 'Controllers/Argo_dataset_attrib_desc';
import { Ref_streamController } from 'Controllers/Ref_stream';
import { Ref_rolesController } from 'Controllers/Ref_roles';
import { Ref_privilegesController } from 'Controllers/Ref_privileges';
import { Ref_modulesController } from 'Controllers/Ref_modules';
import { Ref_aut_appController } from 'Controllers/Ref_aut_app';
import { Argo_Users_roles_detailsController } from 'Controllers/Argo_Users_roles_details';
import { Argo_roles_privilegesController } from 'Controllers/Argo_roles_privileges';
import { Transaction_Argo_dataset_attrib_descController } from 'Controllers/Transaction_Argo_dataset_attrib_desc';
import { Ref_groupController } from 'Controllers/Ref_group';
import { Ref_sequenceController } from 'Controllers/Ref_sequence';
import { Ref_scenarioController } from 'Controllers/Ref_scenario';
// SERVICES
import { Ref_usersService} from './Services/Ref_usersService';
import { Ref_master_bizunitService } from './Services/Ref_master_bizunit';
import { Ref_settingsServices } from 'Services/Ref_settingsServices';
import { Argo_dataset_attrib_descServices } from 'Services/Argo_dataset_attrib_descServices';
import { Ref_streamServices } from 'Services/Ref_streamServices';
import { Ref_privilegesServices } from 'Services/Ref_privilegesServices';
import { Ref_rolesServices } from 'Services/Ref_rolesServices';
import { Ref_modulesServices } from 'Services/Ref_modulesSevices';
import { AppService } from './app.service';
import { Ref_ReferenceSevices } from 'Services/Ref_ReferenceSevices';
import { Argo_Users_roles_detailsService } from 'Services/Argo_Users_roles_detailsService';
import { Argo_roles_privilegesSevice } from 'Services/argo_roles_privilegesSevice';
import { Transaction_Argo_dataset_attrib_descService } from 'Services/Transaction_Argo_dataset_attrib_descService';
import { Ref_groupServices } from 'Services/Ref_groupServices';
import { Ref_sequenceServices } from 'Services/Ref_sequenceServices';
import { Ref_scenarioServices } from 'Services/Ref_scenarioServices';
@Module({
  imports: [],
  controllers: [ AppController,Ref_master_bizunitController,Ref_usersController,Ref_settingsController,Argo_dataset_attrib_descController,Ref_streamController,Ref_rolesController,Ref_privilegesController,
    Ref_modulesController,Ref_aut_appController,Argo_Users_roles_detailsController,
    Argo_roles_privilegesController,Transaction_Argo_dataset_attrib_descController,Ref_groupController,
    Ref_sequenceController ,Ref_scenarioController ],  
providers:    [
    AppService,Ref_master_bizunitService,Ref_usersService,Ref_settingsServices,
    Argo_dataset_attrib_descServices,Ref_streamServices,Ref_rolesServices,Ref_privilegesServices,
    Ref_modulesServices,Ref_ReferenceSevices,Argo_Users_roles_detailsService,Argo_roles_privilegesSevice,
    Transaction_Argo_dataset_attrib_descService,
    Ref_groupServices,Ref_sequenceServices ,Ref_scenarioServices],
})
export class AppModule {}
