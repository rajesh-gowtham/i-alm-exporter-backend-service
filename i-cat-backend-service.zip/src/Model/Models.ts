export class Column {
    gkey: number;
    shortName: string;
    displayName: string;
    control: string;
    Applie_To:string;
    value: string;
  }
  export class ArgoRole {
    gkey: string;
    rolekey: string;
    privilagekey: string;
  }

  export class RolesModel {
    gkey: number;
    name: string;
    description: string;
  }

  export class Settings {
    gkey: number;
    Name: string;
    Description: string;
    Value1: string;
    Value2:string;
    status: boolean;
    role: string;
  }

  export class Stream {
    gkey: number;
    Name: string;
    Description: string;
  }

  export class User {
    gkey: number;
    firstName: string;
    lastName: string;
    email: string;
    status: boolean;
    role: string;
  }

  export class Modules {
    gkey: number;
    name: string;
    description: string;
  }

  
  export class privileges {
    gkey: number;
    Privilege_Name: string;
    module_Key: string;
    CanAdd: string;
    CanUpdate: string;
    CanDelete: string;
    CanView: string;
    CanExcute: string;
  }
  export class Reference {
    gkey: number;
    type: string;
    Value : string;
    description: string;
    status: string;
  }

  export class GroupModel {
    gkey: number;
    lable: string;
    description: string;
  }
  export class SequenceModel {
    gkey: number;
    lable: string;
    description: string;
     appliedto: string;
  }

  export class ScenarioModel {
    gkey: number;
    displayName: string;
    longName: string;
    appliedto: string;
    Description: string;
    stream_Gkey: string;
    bizunit_Gkey: string;
  }
  