
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_scenarioServices } from '../Services/Ref_scenarioServices';
import { ScenarioModel } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_scenarioController {
    constructor(private readonly scenarioServices: Ref_scenarioServices) { }

    @Get('GetscenarioDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
    GetscenarioDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
        try {
            // var decoded = jwt_decode(token);
            return this.scenarioServices.GetscenarioDetailsbyOrg(MasterBizUitKey);
        } catch (error) {
            console.log(" error ", error)
            throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Post('CreatescenarioByOrg')
    CreatescenarioByOrg(@Body() scenario: ScenarioModel) {
        try {
            //  let Temp={"content":{"displayName":"scenario1","longName":"LName","description":"aaa","stream_gkey":"64786c93eaafa9eb0cb05b81","MasterBizUitKey":"63e4e29c6c3832e34733522c"},"submittedBy":"{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}"}
            //  console.log(Temp)
            const displayName = scenario["content"]["displayName"];
            const longName = scenario["content"]["longName"];
            const description = scenario["content"]["description"];
            const stream_gkey = scenario["content"]["Stream_gkey"];
            const MasterBizUitKey = scenario["content"]["MasterBizUitKey"];
            return this.scenarioServices.CreatescenarioByOrg(displayName, longName, description, stream_gkey, MasterBizUitKey);
        } catch (error) {
            console.log(error)
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }

    }

    @Delete('Deletescenario/gkey/:gkey/token/:token')
    DeletescenarioByOrg(@Param('gkey') gkey, @Param('token') token) {
        try {

            return this.scenarioServices.DeletescenarioByOrg(gkey);
        } catch (error) {
            console.error(" error ", error)
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Put('UpdatescenarioByOrg')
    UpdatescenarioByOrg(@Body() scenario: ScenarioModel) {
        try {
            // let Temp={"content":{"displayName":"scenario13","longName":"LName","description":"aaa","stream_gkey":"6458f3dac608a8e06b3af72d","gkey":"64af9411682c1f4a951f20ff"},"submittedBy":"{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}"}
            //  console.log(Temp)
            const displayName = scenario["content"]["displayName"];
            const longName = scenario["content"]["longName"];
            const description = scenario["content"]["description"];
            const stream_gkey = scenario["content"]["Stream_gkey"];
            const gkey = scenario["content"]["gkey"];
            return this.scenarioServices.UpdatescenarioByOrg(gkey, displayName, longName, description, stream_gkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }


    // @Post('map_scenario_sequence')
    // map_scenario_sequence(@Body() scenario: ScenarioModel) {
    //     try {
    //         //let map_scenario_sequence=[{scenario_key:"64af9411682c1f4a951f20ff",sequence_gkey:"64af9cdfc18661e30792beed"},{scenario_key:"64af9411682c1f4a951f20ff",sequence_gkey:"64af9cbb89a36d06312ab134"},{scenario_key:"64af9411682c1f4a951f20ff",sequence_gkey:"64af9cd62e4d25492649d52c"}]
    //         //  let Temp = { "content": map_scenario_sequence, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
    //         return this.scenarioServices.map_scenario_sequence(scenario["content"]);
    //     } catch (error) {
    //         console.error(" error ", error)
    //         throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    //     }
    // }

    @Put('Update_map_scenario_sequence')
    Update_map_scenario_sequence(@Body() scenario: ScenarioModel) {
        try {
            // let map_scenario_sequence = [{ scenario_key: "64af9411682c1f4a951f20ff", sequence_gkey: "64af9cdfc18661e30792beed" }, { scenario_key: "64af9411682c1f4a951f20ff", sequence_gkey: "64af9cbb89a36d06312ab134" }, { scenario_key: "64af9411682c1f4a951f20ff", sequence_gkey: "64af9cd62e4d25492649d52c" }]
            //   let Temp = { "content": map_scenario_sequence, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            //     console.log(Temp)
            return this.scenarioServices.Update_map_scenario_sequence(scenario["content"]);
        } catch (error) {
            console.error(" error ", error)
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }


    @Delete('DeletemapScenarioSequence/:scenario_key/token/:token')
    DeletemapScenarioSequence(@Param('scenario_key') scenario_key, @Param('token') token) {
        try {
            return this.scenarioServices.DeletemapScenarioSequence(scenario_key);
        } catch (error) {
            console.error('erroer ', error)
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    // @Delete('DeleteSinglemapScenarioSequence/:gkey/token/:token')
    // DeleteSinglemapScenarioSequence(@Param('gkey') gkey, @Param('token') token) {
    //     try {
    //         return this.scenarioServices.DeleteSinglemapScenarioSequence(gkey);
    //     } catch (error) {
    //         throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    //     }
    // }


    // @Post('map_autapp_scenario')
    // map_autapp_scenario(@Body() scenario: ScenarioModel) {
    //     try {
    //         // let map_autapp_scenario = [{ scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3dac608a8e06b3af72d" }, { scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3efc608a8e06b3af72e" }, { scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3f7c608a8e06b3af72f" }]
    //         //   let Temp = { "content": map_autapp_scenario, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
    //         return this.scenarioServices.map_autapp_scenario(scenario["content"]);
    //     } catch (error) {
    //         console.error(" error ", error)
    //         throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    //     }
    // }

    @Put('Updatemap_autapp_scenarios')
    Updatemap_autapp_scenario(@Body() scenario: ScenarioModel) {
        try {
            // let map_autapp_scenario = [{ scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3dac608a8e06b3af72d" }, { scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3efc608a8e06b3af72e" }, { scenario_key: "64af9411682c1f4a951f20ff", aut_app_gkey: "6458f3f7c608a8e06b3af72f" }]
            //   let Temp = { "content": map_autapp_scenario, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            console.log('Updatemap_autapp_scenarios',scenario)
            return this.scenarioServices.Updatemap_autapp_scenario(scenario["content"]);
        } catch (error) {
            console.error(" error ", error)
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Delete('DeleteMapautappScenario/:scenario_key/token/:token')
    Deletemap_autapp_scenario(@Param('scenario_key') scenario_key, @Param('token') token) {
        try {
            return this.scenarioServices.Deletemap_autapp_scenario(scenario_key);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    // @Delete('DeleteSingleMapautappScenario/:gkey/token/:token')
    // DeleteSinglemap_autapp_scenario(@Param('gkey') gkey, @Param('token') token) {
    //     try {
    //         return this.scenarioServices.DeleteSinglemap_autapp_scenario(gkey);
    //     } catch (error) {
    //         throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    //     }
    // }
}