
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_usersService } from '../Services/Ref_usersService';
import { Ref_master_bizunitService } from '../Services/Ref_master_bizunit';
import { User } from 'Model/Models';
@Controller()
export class Ref_usersController {
  constructor(private readonly UserService: Ref_usersService) { }

  @Get('AllUsersbyOrg')///OrgID/:OrgID/token/:token')
  AllUsersbyOrg() {//@Param('OrgID') orgname, @Param('token') token) {
    try {
      //console.log('AllUsersbyOrg KEY ' + token)
      console.log(" inside org ");

      return this.UserService.AllUsersbyOrg();
    } catch (error) {
      console.error(error);
      throw new Error(error)
    }
  }

  @Get('GetOrgByEmail/email/:email/token/:token')
  GetOrgByEmail(@Param('email') email, @Param('token') token) {
    //console.log('GetOrgByEmail  '+email)
    try {
      return this.UserService.FindOrgByEamil(email.trim());
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }
  // Added By Mubarak on 16-03-2023
  @Get('GetOrgDetailsByEmail/email/:email/token/:token')
  GetOrgDetailsByEmail(@Param('email') email, @Param('token') token) {
    try {
      console.log('GetOrgByEmail  ' + email)
      return this.UserService.GetOrgDetailsByEmail(email.trim());
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateUserByOrg')
  CreateUserByOrg(@Body() user: User) {

    try {
      console.log(' **************** ' + JSON.stringify(user));
      // console.log(' ===============> ' + user["content"]["gkey"]);
      const gkey = user["content"]["gkey"];
      const firstname = user["content"]["firstName"].trim();
      const lastname = user["content"]["lastName"].trim();
      const email = user["content"]["email"].trim();
      const status = user["content"]["status"];
      const role = user["content"]["role"];
      const firebaseid = user["content"]["firebaseid"];
      console.log("role ****************** " + role, firebaseid);
      return this.UserService.CreateUserByOrg(gkey, firstname, lastname, email, status, role, firebaseid);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  @Put('UpdateUserByOrg')
  UpdateUserByOrg(@Body() user: User) {
    console.log('USER content ===============> ' + JSON.stringify(user["content"]));
    try {
      const firstname = user["content"]["firstName"];
      const lastname = user["content"]["lastName"];
      const email = user["content"]["email"];
      const status = user["content"]["status"];
      const gkey = user["content"]["gkey"];
      const Role_Gkey = user["content"]["rolegkey"];
      const argo_User_key = user["content"]["argo_User_key"];
      console.log("-----------------------------------------------------------")
      console.log(JSON.stringify(user["content"]))
      console.log("-----------------------------------------------------------")
      return this.UserService.UpdateUser(gkey, firstname, lastname, email, Role_Gkey, argo_User_key);
    } catch (error) {
      console.error("Something bad happened");
      console.error(error);
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  @Get('Existemail/email/:email/token/:token')
  CheckEmailExist(@Param('email') email, @Param('token') token) {
    try {
      return this.UserService.CheckExistEmail(email);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  //Added by Rajesh 07/03/2023 
  @Delete('DeleteUser/gkey/:gkey/token/:token')
  DeleteUserByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log("DeleteUser gKEY====" + gkey)
      return this.UserService.DeleteUserByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}