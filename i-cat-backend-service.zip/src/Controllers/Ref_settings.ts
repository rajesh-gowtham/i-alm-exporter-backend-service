
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_settingsServices } from '../Services/Ref_settingsServices';
import { Settings } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_settingsController {
  constructor(private readonly settingsServices: Ref_settingsServices) { }


  @Get('GetSettingsDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetSettingsDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      var decoded = jwt_decode(token);
      return this.settingsServices.GetSettingsDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateSettingsByOrg')
  CreateSettingsByOrg(@Body() settings: Settings) {
    try {
      console.log(' ===============> ' + JSON.stringify(settings["content"]));
      console.log(' ===============> ' + settings["content"]["MasterBizUitKey"]);
      const gkey = settings["content"]["MasterBizUitKey"];
      const Name = settings["content"]["Name"].trim();
      const value1 = settings["content"]["Value1"].trim();
      const value2 = settings["content"]["Value2"].trim();
      const Description = settings["content"]["Description"];
      return this.settingsServices.CreateSettingsByOrg(gkey, Name, value1, value2, Description);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Delete('DeleteSettings/gkey/:gkey/token/:token')
  DeleteSettingsByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log("DeleteSettings gKEY====" + gkey)
      return this.settingsServices.DeleteSettingsByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Put('UpdateSettingsByOrg')
  UpdateSettingsByOrg(@Body() settings: Settings) {
    try {
      console.log(' ===============> ' + JSON.stringify(settings));
      // console.log(' **************** ' + settings["submittedBy"]);
      console.log(' ===============> ' + settings["content"]["MasterBizUitKey"]);
      const gkey = settings["content"]["gkey"];
      const Name = settings["content"]["Name"].trim();
      const value1 = settings["content"]["Value1"].trim();
      const value2 = settings["content"]["Value2"].trim();
      const Description = settings["content"]["Description"];
      return this.settingsServices.UpdateSettingsByOrg(gkey, Name, value1, value2, Description);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }



}