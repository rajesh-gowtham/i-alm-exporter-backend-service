import { Controller, Get, Post, Body, Param, Delete } from '@nestjs/common';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Argo_Users_roles_detailsService } from 'Services/Argo_Users_roles_detailsService';
@Controller()
export class Argo_Users_roles_detailsController {
  constructor(private readonly ArgoService: Argo_Users_roles_detailsService) { }

  @Get('GetRoleByUser/gkey/:gkey/token/:token')
  GetRoleName(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log("GetRoleByUser gkey :" + gkey)
      return this.ArgoService.GetRoleNameByGkey(gkey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  };

}
