
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Argo_dataset_attrib_descServices } from 'Services/Argo_dataset_attrib_descServices';
import { Column } from 'Model/Models';

@Controller()
export class Argo_dataset_attrib_descController {
  constructor(private readonly ColumnServices: Argo_dataset_attrib_descServices) { }

  @Get('GetColumnDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetColumnDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      console.log('------------------------------------------------')
      //  var decoded = jwt_decode(token);
      console.log("GetColumnDetailsbyOrg " + MasterBizUitKey)
      return this.ColumnServices.GetColumnDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }
  @Get('GetBrowseColumnDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetBrowseColumnDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      console.log('------------------------------------------------')
      var decoded = jwt_decode(token);
      return this.ColumnServices.GetBrowseColumnDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('DeleteColumn/gkey/:gkey/token/:token')
  DeleteColumnByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log('------------------------------------------------')
      console.log("DeleteColumn  gkey >" + gkey)
      return this.ColumnServices.DeleteColumnByOrg(gkey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateColumnByOrg')
  CreateColumnByOrg(@Body() column: Column) {
    try {
      console.log('------------------------------------------------')
      console.log('CreateColumnByOrg >>>>: ' + JSON.stringify(column["content"]));
      const MasterBizUitKey = column["content"]["MasterBizUitKey"];
      const shortName = column["content"]["shortName"].trim();
      const displayName = column["content"]["displayName"].trim();
      const control = column["content"]["control"].trim();
      const Applie_To = column["content"]["Applie_To"];
      const value = column["content"]["value"];
      const Mode = column["content"]["Mode"];
      console.log('CreateColumnByOrg  Mode >>>>: ' + JSON.stringify(column["content"]["Mode"]));
      return this.ColumnServices.CreateColumnByOrg(MasterBizUitKey, shortName, displayName, control, Applie_To, value, Mode);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }


  @Put('ExportCreateColumnByOrg')
  ExportCreateColumnByOrg(@Body() column: Column) {
    try {
      console.log('------------------------------------------------')
      console.log(' ExportCreateColumnByOrg > ' + JSON.stringify(column["content"]));
      const bulkColumn = column["content"];
      return this.ColumnServices.CreateColumnManyByOrg(bulkColumn);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Put('UpdateColumnByOrg')
  UpdateColumnByOrg(@Body() column: Column) {
    try {
      console.log('------------------------------------------------')
      // console.log(' ===============> ' + JSON.stringify(column));
      // console.log(' **************** ' + settings["submittedBy"]);
      console.log('CreateColumnByOrg > ' + JSON.stringify(column["content"]));
      const gkey = column["content"]["gkey"];
      const shortName = column["content"]["shortName"].trim();
      const displayName = column["content"]["displayName"].trim();
      const control = column["content"]["control"].trim();
      const Applie_To = column["content"]["Applie_To"];
      const value = column["content"]["value"];
      //Commanded by mubarak 09-05-2023
      //UpdateColumnByOrg  return this.ColumnServices.CreateColumnByOrg(gkey, shortName, displayName, control, Applie_To,value);
      return this.ColumnServices.UpdateColumnByOrg(gkey, shortName, displayName, control, Applie_To, value);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }

}