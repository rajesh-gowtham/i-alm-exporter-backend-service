
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_streamServices } from '../Services/Ref_streamServices';
import { Stream } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';
@Controller()
export class Ref_streamController {
  constructor(private readonly streamServices: Ref_streamServices) { }
  @Get('GetStreamDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetstreamDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      return this.streamServices.GetstreamDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateStreamByOrg')
  CreatestreamByOrg(@Body() stream: Stream) {
    try {
      const gkey = stream["content"]["MasterBizUitKey"];
      const Name = stream["content"]["name"].trim();
      const Description = stream["content"]["description"];
      return this.streamServices.CreatestreamByOrg(gkey, Name, Description);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('DeleteStream/gkey/:gkey/token/:token')
  DeletestreamByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log("Deletestream gKEY====" + gkey)
      return this.streamServices.DeletestreamByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
  @Put('UpdateStreamByOrg')
  UpdatestreamByOrg(@Body() stream: Stream) {
    try {
      console.log(' ===============> ' + JSON.stringify(stream));
      const gkey = stream["content"]["gkey"];
      const Name = stream["content"]["name"].trim();
      const Description = stream["content"]["description"];
      return this.streamServices.UpdatestreamByOrg(gkey, Name, Description);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

}