
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_modulesServices } from 'Services/Ref_modulesSevices';
import { Modules } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_modulesController {
  constructor(private readonly modulesServices: Ref_modulesServices) { }


  @Get('GetmodulesbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetmodulesDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {

  }

  @Post('CreatemodulesByOrg')
  CreatemodulesByOrg(@Body() modulesModel: Modules) {
    try {
      let modulesName = modulesModel["content"]["name"];
      let modulesDesc = modulesModel["content"]["desc"];
      //console.log("CreatemodulesByOrg"+JSON.stringify(modulesModel))
      return this.modulesServices.CreatemodulesByOrg(modulesName, modulesDesc);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Delete('Deletemodules/gkey/:gkey/token/:token')
  DeletemodulesByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      return this.modulesServices.DeletemodulesByOrg(gkey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }


}