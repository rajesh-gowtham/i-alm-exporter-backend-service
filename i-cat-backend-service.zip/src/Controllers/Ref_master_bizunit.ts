import { Controller, Get, Post, Body, Param, Delete } from '@nestjs/common';
import { Ref_master_bizunitService } from '../Services/Ref_master_bizunit';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
@Controller()
export class Ref_master_bizunitController {
  constructor(private readonly OrgService: Ref_master_bizunitService) { }

  @Post('NewOrg/Orgname/:orgname')
  CreateOrganization(@Param('orgname') orgname) {
    try {
      //  var newstr = orgname.replace(":orgname", "");
      this.OrgService.CreateRef_master_bizunit(orgname);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Get('ExistOrg/Orgname/:orgname/token/:token')
  CheckOrganization(@Param('orgname') orgname, @Param('token') token) {
    try {
      return this.OrgService.CheckExistRef_master_bizunit(orgname);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  };

  @Delete('DeleteOrg/OrgID/:orgname/token/:token')
  DeleteOrganization(@Param('orgname') orgname, @Param('token') token) {
    try {
      //  var newstr = orgname.replace(":orgname", "");
      this.OrgService.DeleteRef_master_bizunit(orgname);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  };
  @Get('GetOrgNamebyID/ID/:ID/token/:token')
  GetOrgbyID(@Param('ID') ID, @Param('token') token) {
    try {
      // console.log('GetOrgNamebyID KEY '+ID);
      return this.OrgService.GetOrgbyID(ID);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  };
  @Get('GetOrgIDbyName/Name/:Name/token/:token')
  GetOrgIDbyName(@Param('Name') ID, @Param('token') token) {
    try {
      // console.log('GetOrgIDbyName KEY '+ID);
      return this.OrgService.GetOrgIDbyName(ID);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  };

  @Get('GetAllOrg/token/:token')
  GetAllOrg(@Param('token') token) {
    try {
      // console.log('AllUsersbyOrg KEY ');
      return this.OrgService.GetAllOrg();
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  };
}
