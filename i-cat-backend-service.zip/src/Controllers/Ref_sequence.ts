
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_sequenceServices } from '../Services/Ref_sequenceServices';
import { SequenceModel } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_sequenceController {
  constructor(private readonly sequenceServices: Ref_sequenceServices) { }


  @Get('GetsequenceDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetsequenceDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      var decoded = jwt_decode(token);
      return this.sequenceServices.GetsequenceDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      console.log(error)
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreatesequenceByOrg')
  CreatesequenceByOrg(@Body() sequence: SequenceModel) {
    try {

      const bizunit = sequence["content"]["MasterBizUitKey"];
      const lable = sequence["content"]["lable"];
      const description = sequence["content"]["description"];
      const Parameterizable = sequence["content"]["Parameterizable"];
      const Apply_To = sequence["content"]["Apply_To"];
      // Added by Rajesh (14-07-2023) for single sequence creation (connect bizunit)
      return this.sequenceServices.CreatesequenceByOrg(lable,description,Apply_To,Parameterizable,bizunit);
    } catch (error) {
      console.log(error)
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Delete('Deletesequence/gkey/:gkey/token/:token')
  DeletesequenceByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      return this.sequenceServices.DeletesequenceByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Put('UpdatesequenceByOrg')
  UpdatesequenceByOrg(@Body() sequence: SequenceModel) {
    try {
      const gkey = sequence["content"]["gkey"];
      const lable = sequence["content"]["lable"].trim();
      const description = sequence["content"]["description"].trim();
      const Parameterizable = sequence["content"]["Parameterizable"].trim();
      const Apply_To = sequence["content"]["Apply_To"];
      return this.sequenceServices.UpdatesequenceByOrg(lable, description, Apply_To, Parameterizable, gkey);
    } catch (error) {
      console.log(error)
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }



}