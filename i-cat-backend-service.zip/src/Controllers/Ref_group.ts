
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_groupServices } from 'Services/Ref_groupServices';
import { GroupModel } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_groupController {
    constructor(private readonly groupServices: Ref_groupServices) { }


    @Get('GetgroupbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
    GetgroupDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
        //GetgroupDetailsbyOrg
        try {
            return this.groupServices.GetgroupDetailsbyOrg(MasterBizUitKey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Post('CreategroupByOrg')
    CreategroupByOrg(@Body() groupModel: GroupModel) {
        try {
            //let Arg={"content":{"lable":"Group8","description":"aaa","MasterBizUitKey":"63e4e27e6c3832e34733522b"},"submittedBy":"{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}"}
            //  let Users=["649ebec9515fb1e086544ce7","649ebf2f515fb1e086544ce9","649ec0581caf8a2f79a6a4b7"]
            // console.log(Map_User_Group)
            let lable = groupModel["content"]["lable"];
            let description = groupModel["content"]["description"];
            let MasterBizUitKey = groupModel["content"]["MasterBizUitKey"];
            let Users = groupModel["content"]["UserMapGroupGKey"];
            return this.groupServices.CreategroupByOrg(lable, description, MasterBizUitKey, Users);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Put('UpdategroupByGkey')
    UpdategroupByGkey(@Body() groupModel: GroupModel) {

        try {
            //          let Arg = { "content": { "gkey": "64a55b77bdc60e689cb552a7", "lable": "Group15", "description": "aaa", "MasterBizUitKey": "63e4e27e6c3832e34733522b" }, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            //            let Map_GroupUser = ["64a249f13f42b51c0daab65c", "649ebf2f515fb1e086544ce9", "649ec0581caf8a2f79a6a4b7"]
            //            console.log(Map_GroupUser)
            let gkey = groupModel["content"]["gkey"];
            let lable = groupModel["content"]["lable"];
            let description = groupModel["content"]["description"];
            let Map_GroupUser = groupModel["content"]["UserMapGroupGKey"];
            return this.groupServices.UpdateGroupByGkey(lable, description, Map_GroupUser, gkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Delete('Deletegroup/gkey/:gkey/token/:token')
    DeletegroupByOrg(@Param('gkey') gkey, @Param('token') token) {
        try {
            return this.groupServices.DeletegroupByGkey(gkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Post('CreateMapUserByGroup')
    CreateMapUserByGroup(@Body() groupModel: GroupModel) {
        try {
            //  let Map_User_GroupGkey=[{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"}]
            // let Arg = { "content": Map_User_GroupGkey, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            let MapDetails = groupModel["content"]
            console.log(MapDetails)
            return this.groupServices.CreateMapUserByGroup(MapDetails);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Put('UpdateMapUserByGroup')
    UpdateMapUserByGroup(@Body() groupModel: GroupModel) {
        try {
            //  let Map_User_GroupGkey=[{user_gkey:"649ebf2f515fb1e086544ce9",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"}]
            // let Arg = { "content": Map_User_GroupGkey, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            let MapDetails = groupModel["content"]
            console.log('MapDetails',MapDetails)
            return this.groupServices.UpdateMapUserByGroup(MapDetails);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    // @Post('MapScenarioByGroup')
    // MapScenarioByGroup(@Body() groupModel: GroupModel) {
    //     try {
    //         //  let Map_User_GroupGkey=[{user_gkey:"649ebf2f515fb1e086544ce9",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"}]
    //         // let Arg = { "content": Map_User_GroupGkey, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
    //         let MapDetails = groupModel["content"]
    //         console.log('MapDetails',MapDetails)
    //         return this.groupServices.MapScenarioByGroup(MapDetails);
    //     } catch (error) {
    //         throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    //     }
    // }

    @Put('UpdateMapScenarioByGroup')
    UpdateMapScenarioByGroup(@Body() groupModel: GroupModel) {
        try {
            //  let Map_User_GroupGkey=[{user_gkey:"649ebf2f515fb1e086544ce9",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"},{user_gkey:"649ebec9515fb1e086544ce7",group_gkey:"64a54ec7c1e9966ca55cc1c3"}]
            // let Arg = { "content": Map_User_GroupGkey, "submittedBy": "{\"uid\":\"ydyhzq4hrEcmlQmyWpeReZhPcVf1\",\"email\":\"nagarasu.v@igosolutions.eu\",\"emailVerified\":true,\"isAnonymous\":false,\"providerData\":[{\"providerId\":\"password\",\"uid\":\"nagarasu.v@igosolutions.eu\",\"displayName\":null,\"email\":\"nagarasu.v@igosolutions.eu\",\"phoneNumber\":null,\"photoURL\":null}],\"stsTokenManager\":{\"refreshToken\":\"APZUo0TekWnb65etxp9kwaRHgEN3NvaqA4r7NgN6DnfxTHAIcZtW1ro-yQ8dk-v_uj1Hb6obya-stcXjo8c-ogBUCNUVVvtrVM5lGHJ9KZ5hecNyyOpm3RctC6q1iM-dmtou7PjgcMKkHmVPMBsea50L04cecwiFzmEYyBPVXXALiZRWJ55zqZwt_EBmWz7BGeSKq1eAFvjg1V3XIWo3PMTZJbnXy85EdQ\",\"accessToken\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImY5N2U3ZWVlY2YwMWM4MDhiZjRhYjkzOTczNDBiZmIyOTgyZTg0NzUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4ODU1MzYzMSwidXNlcl9pZCI6InlkeWh6cTRockVjbWxRbXlXcGVSZVpoUGNWZjEiLCJzdWIiOiJ5ZHloenE0aHJFY21sUW15V3BlUmVaaFBjVmYxIiwiaWF0IjoxNjg4NTUzNjMxLCJleHAiOjE2ODg1NTcyMzEsImVtYWlsIjoibmFnYXJhc3UudkBpZ29zb2x1dGlvbnMuZXUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyJuYWdhcmFzdS52QGlnb3NvbHV0aW9ucy5ldSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.VvYrtlkoEJkookxaVNv9I3C8Fz30Qnn1cffzEwz0Y-8vcS7pLiz196MrXITX4I0vD7ZJVXu7G2BLECRY1dh7ML4NUs_rQ7x8wYIERng3wtHx9QmHinakEQx6EB8OBMm_XpWzg48uI1i7gH7KTVtPujoN1M3Sz8p9Ctql1qt714cxY_hX0wsQvFuOaIlIyuL_g7OmSuJ3hqHY9PJoubeO3t9JwY1m2NGjQqPcLDpB43pOu4bSqWy_mT3h5gwqEWMM4hFVVxDZ-nZAyM9oV_O1k-wxTQ1L7AqZO-L3Pa5_0Kvjp02WNrbpl3cYYj_IoZ0pAFHce7_OEuOyBFANUfJpxA\",\"expirationTime\":1688557231888},\"createdAt\":\"1688125230147\",\"lastLoginAt\":\"1688553631769\",\"apiKey\":\"AIzaSyB3Lw8_bvt5Xn9C3DA5M0zp9PUePLv4-L4\",\"appName\":\"[DEFAULT]\"}" }
            let MapDetails = groupModel["content"]
            console.log('groupModel',groupModel)
            return this.groupServices.UpdateMapScenarioByGroup(MapDetails);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Delete('DelteMapScenarioByGroup/groupkey/:groupkey/token/:token')
    DelteMapScenarioByGroup(@Param('groupkey') groupkey, @Param('token') token) {
        try {
            console.log('DelteMapScenarioByGroup',groupkey)
            return this.groupServices.DelteMapScenarioByGroup(groupkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }


    @Delete('DeleteMapAllUserByGroup/groupkey/:groupkey/token/:token')
    DeleteMapAllUserByGroup(@Param('groupkey') groupkey, @Param('token') token) {
        try {
            return this.groupServices.DeleteMapAllUserByGroup(groupkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

    @Delete('DeleteMapUserByGroup/userkey/:userkey/token/:token')
    DeleteMapUserByGroup(@Param('userkey') userkey, @Param('token') token) {
        try {
            return this.groupServices.DeleteMapUserByGroup(userkey);
        } catch (error) {
            throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
        }
    }

}