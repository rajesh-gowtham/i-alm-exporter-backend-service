
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_privilegesServices } from 'Services/Ref_privilegesServices';
import { privileges } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_privilegesController {
  constructor(private readonly privilegesServices: Ref_privilegesServices) { }


  @Get('GetprivilegesbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetprivilegesDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      return this.privilegesServices.GetprivilegesDetailsbyOrg();
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Put('GetprivilegesbyOrg/')
  UpdateprivilegesDetailsbyOrg(@Body() privilegesModel: privileges) {
    try {
      let gkey = privilegesModel["content"]["module_Key"];
      let CanAdd = privilegesModel["content"]["CanAdd"];
      let CanView = privilegesModel["content"]["CanView"];
      let CanUpdate = privilegesModel["content"]["CanUpdate"];
      let CanExcute = privilegesModel["content"]["CanExcute"];
      let CanDelete = privilegesModel["content"]["CanDelete"];
      //gkey,CanAdd,CanView,CanUpdate,CanExcute,CanDelete
      return this.privilegesServices.UpdatePrivilage(gkey, CanAdd, CanView, CanUpdate, CanExcute, CanDelete);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Put('UpdateBulkprivilegesbyOrg/')
  UpdateBulkDataprivilegesDetailsbyOrg(@Body() privilegesModel: privileges) {
    try {
      let BulkData = privilegesModel["content"]["BulkPrivilageData"];
      //gkey,CanAdd,CanView,CanUpdate,CanExcute,CanDelete
      return this.privilegesServices.UpdateBulkPrivilage(BulkData);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  @Put('UpdateprivilegesNamebyGkey/')
  UpdateprivilegesNamebyGkey(@Body() privilegesModel: privileges) {
    try {
      let gkey = privilegesModel["content"]["gkey"];
      let PrivilegeName = privilegesModel["content"]["Privilege_Name"];
      return this.privilegesServices.UpdateprivilegesNamebyGkey(gkey, PrivilegeName);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


  @Post('CreateprivilegesByOrg')
  CreateprivilegesByOrg(@Body() privilegesModel: privileges) {
    try {
      let privilegesName = "";
      let privilegesDesc = "";
      //return this.privilegesServices.CreateprivilegesByOrg(privilegesName,privilegesDesc);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateBulkprivilegesByOrg')
  CreateBulkprivilegesByOrg(@Body() privilegesModel: privileges) {
    try {
      console.log(' ExportCreateColumnByOrg > ' + JSON.stringify(privilegesModel["content"]));
      console.log('------------------------------------------------------------------------')
      let Allprivileges = privilegesModel["content"];
      let privilegesDesc = "";
      return this.privilegesServices.CreatePrivilageManyByOrg(Allprivileges);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('Deleteprivileges/gkey/:gkey/token/:token')
  DeleteprivilegesByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      return this.privilegesServices.DeleteprivilegesByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Put('UpdateprivilegesStatusByGkey/')
  UpdateprivilegesStatusByGkey(@Body() privilegesModel: privileges) {
    try {
      console.log('------------------------------------------------------------------------')
      let gkey = privilegesModel["content"]["gkey"];
      let status = privilegesModel["content"]["status"];
      console.log('------------------------------------------------------------------------')
      console.log('status' + status)
      return this.privilegesServices.UpdateprivilegesStatusByGkey(gkey, status);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }


}