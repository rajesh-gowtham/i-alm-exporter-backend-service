import { Controller, Get, Post, Body, Param, Delete } from '@nestjs/common';
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { ArgoRole } from 'Model/Models';
import { Argo_roles_privilegesSevice } from 'Services/argo_roles_privilegesSevice';
@Controller()
export class Argo_roles_privilegesController {
    constructor(private readonly Argo_roles: Argo_roles_privilegesSevice) { }

    @Post('SetPrivilageToRole/')
    SetPrivilageToRole(@Body() ArgoRole: ArgoRole) {
        try {
            //console.log('SetPrivilageToRole > ' + JSON.stringify(ArgoRole["content"]));
            let TemRoledata = ArgoRole["content"];
            let Roledata = [];
            for (var i = 0; i < TemRoledata.length; i++) {
                let RoledataRow = {
                    Privileges_Gkey: TemRoledata[i]["Privileges_Gkey"],
                    Role_Gkey: TemRoledata[i]["Role_Gkey"]
                };
                Roledata.push(RoledataRow);
            }
            console.log("=======> " + JSON.stringify(Roledata))
            return this.Argo_roles.SetPrivilageToRole(Roledata);
        } catch (error) {
            throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
        }
    };


    @Get('GetPrivilageToRole/MasterBizUitKey/:MasterBizUitKey/token/:token')
    GetPrivilageToRole(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
        try {
            //         console.log('GetPrivilageToRole > ' + MasterBizUitKey);
            return this.Argo_roles.GetPrivilageToRole(MasterBizUitKey);
        } catch (error) {
            throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
        }
    };

    // GKey Updated By Rajesh 05-07-2023
    @Delete('DeletPrivilageToRoleByGkey/RoleGkey/:RoleGkey/token/:token')
    DeletPrivilageToRoleByName(@Param('RoleGkey') RoleGkey, @Param('token') token) {
        try {
            console.log('GetPrivilageToRole > ' + RoleGkey);
            return this.Argo_roles.DeleteRolePrivilegeDetails(RoleGkey);
        } catch (error) {
            throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
        }
    };
    
}
