
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Transaction_Argo_dataset_attrib_descService } from 'Services/Transaction_Argo_dataset_attrib_descService';
import { Column } from 'Model/Models';

@Controller()
export class Transaction_Argo_dataset_attrib_descController {
  constructor(private readonly ColumnServices: Transaction_Argo_dataset_attrib_descService) { }

  @Get('GetTransactionBrowseColumnDetailsbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetBrowseColumnDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      var decoded = jwt_decode(token);
      return this.ColumnServices.GetBrowseColumnDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('DeleteTransactionColumn/gkey/:gkey/token/:token')
  DeleteColumnByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      console.log("DeleteColumn  gkey >" + gkey)
      return this.ColumnServices.DeleteColumnByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('DeleteAllTransactionByOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  DeleteAllTransactionByOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      console.log("DeleteColumn  MasterBizUitKey >" + MasterBizUitKey)
      return this.ColumnServices.DeleteAllTransactionByOrg();
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Put('ExportTransactionColumnByOrg')
  ExportCreateColumnByOrg(@Body() column: Column) {
    try {
      console.log(' ExportCreateColumnByOrg > ' + JSON.stringify(column["content"]));
      const bulkColumn = column["content"];
      console.log("ExportTransactionColumnByOrg >:" + JSON.stringify(bulkColumn));
      return this.ColumnServices.CreateColumnManyByOrg(bulkColumn);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }
}