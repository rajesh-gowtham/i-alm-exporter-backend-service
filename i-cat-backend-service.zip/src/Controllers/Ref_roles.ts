
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_rolesServices } from 'Services/Ref_rolesServices';
import { RolesModel } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_rolesController {
  constructor(private readonly rolesServices: Ref_rolesServices) { }


  @Get('GetrolesbyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetrolesDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    //GetrolesDetailsbyOrg
    try {
      console.log('-------------------------------------------------------------')
    //  console.log("GetrolesbyOrg >>> " + MasterBizUitKey);
      return this.rolesServices.GetrolesDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreaterolesByOrg')
  CreaterolesByOrg(@Body() rolesModel: RolesModel) {
    try {
      let rolesName = rolesModel["content"]["role"];
      let rolesDesc = rolesModel["content"]["description"];
      let MasterBizUitKey = rolesModel["content"]["MasterBizUitKey"];
      console.log("  >>>> " + JSON.stringify(rolesModel))
      return this.rolesServices.CreaterolesByOrg(rolesName, rolesDesc, MasterBizUitKey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Put('UpdaterolesByOrg')
  UpdaterolesByOrg(@Body() rolesModel: RolesModel) {
    try {
      let gkey = rolesModel["content"]["gkey"];
      let rolesName = rolesModel["content"]["name"];
      let rolesDesc = rolesModel["content"]["description"];
      console.log(" >>>>>>>>>>> >>>> " + JSON.stringify(rolesModel))
      return this.rolesServices.UpdateRoleByOrg(gkey, rolesName, rolesDesc);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Delete('Deleteroles/gkey/:gkey/token/:token')
  DeleterolesByOrg(@Param('gkey') gkey, @Param('token') token) {
    try {
      return this.rolesServices.DeleterolesByOrg(gkey);
    } catch (error) {
      throw new HttpException('Forbidden', HttpStatus.EXPECTATION_FAILED);
    }
  }


}