
import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import jwt_decode from "jwt-decode";
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Ref_ReferenceSevices } from 'Services/Ref_ReferenceSevices';
import { Reference } from 'Model/Models';
import { CheckExistEmailApi } from 'Services/Ref_usersService';


@Controller()
export class Ref_aut_appController {
  constructor(private readonly ReferenceServices: Ref_ReferenceSevices) { }


  @Get('GetReferencebyOrg/MasterBizUitKey/:MasterBizUitKey/token/:token')
  GetReferenceDetailsbyOrg(@Param('MasterBizUitKey') MasterBizUitKey, @Param('token') token) {
    try {
      console.log("GetReferencebyOrg" + MasterBizUitKey)
      return this.ReferenceServices.GetReferenceDetailsbyOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }

  @Post('CreateReferenceByOrg')
  CreateReferenceByOrg(@Body() ReferenceModel: Reference) {
    
    try {
      console.log('ReferenceModel',ReferenceModel)
      let type = ReferenceModel["content"]["type"];
      let Value = ReferenceModel["content"]["Value"];
      let description = ReferenceModel["content"]["description"];
      let status = ReferenceModel["content"]["status"];
      let gkey = ReferenceModel["content"]["MasterBizUitKey"];
      return this.ReferenceServices.CreateReferenceByOrg(type, Value, description, true, gkey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Put('UpdateReferenceByOrg')
  UpdateUserByOrg(@Body() ReferenceModel: Reference) {
    try {
      console.log(' ===============> ' + JSON.stringify(ReferenceModel["content"]));
      let type = ReferenceModel["content"]["type"];
      let Value = ReferenceModel["content"]["Value"];
      let description = ReferenceModel["content"]["description"];
      let status = ReferenceModel["content"]["status"];
      let gkey = ReferenceModel["content"]["gkey"];
      return this.ReferenceServices.UpdateReferenceByOrg(type, Value, description, true, gkey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }

  }

  @Delete('DeleteReference/gkey/:gkey/token/:token')
  DeleteReferenceByOrg(@Param('gkey') MasterBizUitKey, @Param('token') token) {
    try {
      return this.ReferenceServices.DeleteReferenceByOrg(MasterBizUitKey);
    } catch (error) {
      throw new HttpException(error, HttpStatus.EXPECTATION_FAILED);
    }
  }
}