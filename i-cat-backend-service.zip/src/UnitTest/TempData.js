export const TempData = {
    User:{
        AllUsersbyOrg:[
            {
                "gkey": "649969530713b583479cfc8e",
                "firstName": "Mubarak",
                "lastName": "",
                "email": "mubarak.ali@igosolutions.eu",
                "status": true,
                "firebaseid": "bnDgk9pSQsPZcY7Sxk33yDOKFiE2",
                "createdAt": "2023-06-26T10:32:51.786Z",
                "updatedAt": "2023-02-22T18:30:00.000Z",
                "bizunit_gkey": "63e4e27e6c3832e34733522b"
            },
            {
                "gkey": "64996a220713b583479cfc90",
                "firstName": "Rajesh",
                "lastName": "",
                "email": "rajesh.r@igosolutions.eu",
                "status": true,
                "firebaseid": "Jd9Tlf79aXcIIsW6qu5PhasITsH3",
                "createdAt": "2023-06-26T10:36:18.848Z",
                "updatedAt": "2023-06-26T11:38:45.373Z",
                "bizunit_gkey": "63e4e27e6c3832e34733522b"
            }
        ],
    },  
};