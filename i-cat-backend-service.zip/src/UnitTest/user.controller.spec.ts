import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from '../app.controller';
import { AppService } from '../app.service';
import { Ref_usersService } from '../Services/Ref_usersService';
describe('Controller', () => {
let JsonResult= [{
    AllUsersbyOrg:[
        {
            "gkey": "649969530713b583479cfc8e",
            "firstName": "Mubarak",
            "lastName": "",
            "email": "mubarak.ali@igosolutions.eu",
            "status": true,
            "firebaseid": "bnDgk9pSQsPZcY7Sxk33yDOKFiE2",
            "createdAt": "2023-06-26T10:32:51.786Z",
            "updatedAt": "2023-02-22T18:30:00.000Z",
            "bizunit_gkey": "63e4e27e6c3832e34733522b"
        },
        {
            "gkey": "64996a220713b583479cfc90",
            "firstName": "Rajesh",
            "lastName": "",
            "email": "rajesh.r@igosolutions.eu",
            "status": true,
            "firebaseid": "Jd9Tlf79aXcIIsW6qu5PhasITsH3",
            "createdAt": "2023-06-26T10:36:18.848Z",
            "updatedAt": "2023-06-26T11:38:45.373Z",
            "bizunit_gkey": "63e4e27e6c3832e34733522b"
        }
    ],
}];
  let Token='eyJhbGciOiJSUzI1NiIsImtpZCI6IjhkMDNhZTdmNDczZjJjNmIyNTI3NmMwNjM2MGViOTk4ODdlMjNhYTkiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmlyLWF1dGgtN2EzZmQiLCJhdWQiOiJmaXItYXV0aC03YTNmZCIsImF1dGhfdGltZSI6MTY4NzkyMzQwNSwidXNlcl9pZCI6ImJuRGdrOXBTUXNQWmNZN1N4azMzeURPS0ZpRTIiLCJzdWIiOiJibkRnazlwU1FzUFpjWTdTeGszM3lET0tGaUUyIiwiaWF0IjoxNjg3OTIzNDA1LCJleHAiOjE2ODc5MjcwMDUsImVtYWlsIjoibXViYXJhay5hbGlAaWdvc29sdXRpb25zLmV1IiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZW1haWwiOlsibXViYXJhay5hbGlAaWdvc29sdXRpb25zLmV1Il19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.i4tstGnfh7xAFtxYGSSfYPrSaO9JTLUCldMZ6Ext5EqUH8ZcSLAsw2Ve6kwhnpE7JK-pzpMtpODY6z4tBQIXw3aGwgFzRMNUWcenuLCX0AnH3VrStC0U8zWCHOkAUgJwfTJuKII2fb-R9nQqBl08e3-qQXoeIFiH26qOVN6xJrEw-H6Yu92nuEfx9j2L5nEsqAcNYV_5WSimelWM5gTvKdrG3E4ZcLUxsioINI-JIQOBtVkcP9fPesQi_jrV-TDGYXWvyK8V2IacEK2wLzDCTfv1M7NfwAFixQaI-mxppvm_5SK1A8QT-w2knPPaZjzTPqG0SpwiALovHk_7HUn6tw';
  let MasterBizUitKey='63e4e27e6c3832e34733522b';
  let appController: AppController;

  //Service
  let usersService: Ref_usersService;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [AppService,Ref_usersService],
    }).compile();

    appController = app.get<AppController>(AppController);
    usersService= app.get<Ref_usersService>(Ref_usersService);
  });

  describe('root', () => {
    it('should return "iCATS BACK END STARTED!"', () => {
      expect(usersService.FindOrgByEamil(MasterBizUitKey)).toEqual(JsonResult[0].AllUsersbyOrg);
    });
  });
});
