const path = require('path');
const Dotenv = require('dotenv-webpack');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');

// Use process.env.NODE_ENV to determine the mode (development or production)
const mode = process.env.NODE_ENV || 'development';
console.log(process.env.NODE_ENV, 'mode---:', mode);

module.exports = {
  entry: './src/index.js',
  mode: mode,
  devtool: mode === "production" ? 'hidden-nosources-cheap-source-map' : 'eval-source-map',
  output: {
    path: path.resolve(__dirname, 'build'),
    filename: 'bundle.js',
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader', 'postcss-loader'],
      },
      {
        test: /\.(png|jpe?g|gif)$/i,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]',
              outputPath: 'images/',
              publicPath: 'images/',
            },
          },
        ],
      },
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-react'],
          },
        },
      },
      {
        test: /\.bpmn$/,
        use: {
          loader: 'file-loader',
          options: {
            name: '[name].[ext]',
            outputPath: 'assets/',
          },
        },
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.jsx'],
  },
  devServer: {
    static: {
      directory: path.join(__dirname, 'public'),
    },
    watchFiles: {
      paths: ['src/**/*'],
      options: {
        ignored: /node_modules/,
      },
    },
    port: 8286,
    historyApiFallback: true,
    open: true,
    client: {
      overlay: false,
    },
    hot: true, // Enable Hot Module Replacement
    liveReload: true, // Enable Live Reload for non-JavaScript changes
  },
  plugins: [
    new Dotenv({
      path: './.env',
      safe: true,
      systemvars: true,
      silent: true,
    }),
    new webpack.ProvidePlugin({
      React: 'react',
    }),
    new CopyWebpackPlugin({
      patterns: [
        { from: 'public/index.html', to: 'index.html' },
      ],
    }),
    new webpack.HotModuleReplacementPlugin(), // Add HMR Plugin
  ],
};
