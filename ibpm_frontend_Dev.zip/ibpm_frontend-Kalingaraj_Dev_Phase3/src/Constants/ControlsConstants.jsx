//SCREEN ID -3057
export const ControlsConstants = {
    Header: { menubtn: 'block font-bold px-4 py-2 text-sm cursor-default text-white hover:bg-[#FC7504]' },
    Login:{input:'shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5'},
    Buttons: {
        //   BUTTON 
        btnprimary: 'px-4 py-2.5 bg-[#089de3] text-white max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out',
        btnsecoundary: 'px-6 py-2.5 bg-gray-400 text-white max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-gray-700 hover:shadow-lg focus:bg-gray-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-gray-800 active:shadow-lg transition duration-150 ease-in-out',
        btnupdate: 'px-6 py-2.5 bg-[#F6AE2D] text-white  max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-green-500 hover:text-white hover:shadow-lg focus:bg-gray-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-green-500 active:shadow-lg transition duration-150 ease-in-out',
        btnnextstp: 'px-6 py-2.5 bg-gray-200 text-black  max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md hover: bg-gray-100 hover:shadow-lg focus: bg-gray-300 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-green-500 active:shadow-lg transition duration-150 ease-in-out',
        btndanger: 'px-6  py-2.5  bg-[#F6AE2D]  text-white  max-lg:mob-txt-sm font-medium  text-xs  leading-tight  uppercase  rounded shadow-md  hover:bg-red-500 hover:shadow-lg focus:bg-red-500 focus:shadow-lg focus:outline-none focus:ring-0  active:bg-red-500 active:shadow-lg  transition  duration-150  ease-in-out  ml-1',
        btnsuccess: 'px-6  py-2.5  bg-green-600  text-white  max-lg:mob-txt-sm font-medium  text-xs  leading-tight  uppercase  rounded shadow-md  hover:bg-green-400 hover:shadow-lg focus:bg-green-500 focus:shadow-lg focus:outline-none focus:ring-0  active:bg-green-700 active:shadow-lg  transition  duration-150  ease-in-out  ml-1',
        loginbtn: 'px-6 py-2.5  bg-white border border-blue-400  text-blue-500 max-lg:mob-txt-sm font-medium text-xs leading-tight uppercase rounded shadow-md  hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0 transition duration-150 ease-in-out',
    },
    TextBox: {
        //   TEXT BOX
        textBoxDefault: "w-full h-[40px] p-2 border border-slate-400 mt-1 outline-0 text-black text-[14px] focus:border-blue-500 rounded-md",
        textBoxDisabled: "bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500"
    },
    label: {
        labelDefault: 'flex-1 text-[color:#292d34] text-[14px] font-semibold',
    },

    Responsive: {
        // labelResponsive: {
        //     label: 'block text-[color:#292d34  md:text-right mb-1 md:mb-0 pr-4 max-lg:mob-txt-md text-[14px] ',
        // },
        // textboxResponsive: {
        //     text_header: 'max-lg:mob-txt-md max-lg:font-bold   md:text-page-header-2xl text-page-header  pb-1',
        //     textbox_b_red: 'bg-[#eaf1fa] appearance-none   border-[1px] border-[#f74a73] max-lg:w-md w-full  max-lg:py-0 placeholder:text-[11px] max-lg:px-2 py-2 px-4 text-gray-700 leading-tight',
        //     textbox_b_gray: 'bg-[#eaf1fa] appearance-none   border-[1px] border-[#cecef8]  max-lg:w-md w-full  max-lg:py-0  placeholder:text-[11px] max-lg:px-2 py-2 px-4 text-gray-700 leading-tight',
        //     textarea: 'bg-[#eaf1fa] appearance-none   border-[1px] border-[#f74a73] max-lg:rounded-[5px]  max-lg:w-md w-full placeholder:text-[11px]  max-lg:py-0 max-lg:px-2 py-2 px-4 text-gray-700 leading-tight'
        // },
        btnResponsive: {
            btn_from_footer: 'flex items-center  py-2 max-lg:justify-center justify-end border-t border-footer-border rounded-b-md',
            btn_success: 'flex-shrink-0 bg-[#089de3] text-white font-medium text-xs  max-lg:m-2 m-2 max-lg:px-4 px-6 py-2.5 uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out',
            btn_white: 'flex-shrink-0 bg-[#ffffff] text-blue-800 font-medium text-xs max-lg:px-4 py-2 uppercase rounded  hover:bg-gray-100 hover:shadow-md active:bg-white  border border-blue-500 px-6 transition duration-150 ease-in-out ',
            btn_warning: 'flex-shrink-0 bg-[#F6AE2D] text-white font-medium text-xs  max-lg:m-2 m-2  max-lg:px-4 px-6 py-2.5 uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out',
        }
    },
    // checkbox: {
    //     checkbox14: 'flex-1 text-[color:#292d34] text-[14px]',
    //     checkbox17: 'flex-1 flex justify-between text-[color:#292d34] text-[14px] pr-1',
    // },
    // Switch: {
    //     SwitchToggel: 'w-8 h-4 bg-gray-400 rounded-full peer  peer-focus:ring-green-300  peer-checked:after:translate-x-full peer-checked:after:border-white after:content after:absolute after:top-[1px] after:left-[0px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[14px] after:w-[14px] after:transition-all peer-checked:bg-[#F6AE2D]',
    //     // SwitchToggel:'w-11 h-6 bg-gray-400 rounded-full peer  peer-focus:ring-green-300  peer-checked:after:translate-x-full peer-checked:after:border-white after:content after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#F6AE2D]',
    // },
    Model: {
        //  Model POPUP 33658A
        headerbg: '#3266b9',
        headerbgexcel: '#1D6F42',
        modalWidth: '30vw max-lg:10vw',
        modalWidth50: '50vw max-lg:15vw',
        modalWidthProcessscreen: '60vw max-lg:25vw',
        closebtncolorProcessscreen: 'White',
        headerbgProcessscreen: 'White',
        modalWidthUser: '25vw max-lg:10vw',
        bodybg: 'White',
        bodytextcolor: 'Black',
        closebtncolor: '#fc581c',
        headerheight: '40px',
        modelConfirm: 'Confirm',
        resetpassword: 'Change Your Password',
        Manageprivilages: 'Manage Privilages',
        resetTempPassword: 'Reset Your Temporary Password',
    },
    // RegExp: {
    //     emailRegExp: /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i,
    //     digitRegExp: /(?=.*?[0-9])/,
    //     specialCharRegExp: /(?=.*?[#?!@$%^&*-])/,
    // },
    ToolTip: {
        error: 'absolute  right-[-200px] text-center border-[1px] border-red-500 top-[] p-2 rounded-lg w-[200px]  bg-white text-[#5e5c5c] text-[11px]',
        hover: 'opacity-100 bg-[#F6AE2D] hover:bg-[#F6AE2D] focus:ring-[#3266b9] inline-flex items-center rounded-full p-3 text-white shadow-sm transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        hoverflex: 'fixed bottom-6 right-6',
        iconsize: 'h-6 w-6',
        addbutton: 'relative flex flex-col items-center group opacity-100 bg-[#F6AE2D] hover:bg-[#F6AE2D] focus:ring-[#089de3]  rounded-full p-3 text-white shadow-sm transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        arrowbutton: 'relative flex flex-col items-center group opacity-100  bg-transparent  focus:ring-[#089de3]  rounded-full p-2 text-white shadow-sm transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        cancelbutton: 'relative flex flex-col items-center group opacity-100 bg- hover:bg-red-[#F6AE2D] focus:ring-[#089de3]  rounded-full p-3 text-white shadow-sm transition-opacity focus:outline-none focus:ring-2 focus:ring-offset-2',
        tooltiptext: 'rounded-md  relative min-w-[100px] z-10 py-2 text-sm font-bold leading-none text-white  bg-[#089de3]',
        tooltipGroup: 'absolute bottom-7 flex-col items-center hidden mb-6 group-hover:flex',
        tooltipArrow: 'w-3 h-3 -mt-2 rotate-45 bg-[#089de3]'
    },
    Icon: {
        search: {
            size: 20
        }
    },
    Select: {
        dropDownStyles: {
            control: (base, state) => ({
                ...base,
                // background: "#eaf1fa",
                fontSize: '13px',
                borderRadius: "5px",
                border: '1px solid #94a3b8',
                '&:hover': { border: '1px solid #3b82f6' }, // border style on hover
                // default border color
                boxShadow: 'none', // no box-shadow 
                // minHeight: '40px',
                height: '40px',
                color: "black",
            }),
            menuList: styles => ({
                ...styles,
                //    background: 'papayawhip' ,
            }),
            option: (provided, state) => ({
                ...provided,
                //fontWeight: state.isSelected ? "bold" : "normal",
                color: "black",
                //   height: 10,
                //   width: 300,
                padding: 4,
                // backgroundColor: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            singleValue: (provided, state) => ({
                ...provided,
                color: state.data.color,
                fontSize: state.selectProps.myFontSize
            }),
            menu: base => ({
                ...base,
                zIndex: 100
            }),
            placeholder: (defaultStyles) => ({
                ...defaultStyles,
                // color: '#eaf1fa',
                fontSize: '12px',
            })
        },
        // dropDownStylesRed: {
        //     control: (base, state) => ({
        //         ...base,
        //         background: "#eaf1fa",
        //         fontSize: '13px',
        //         // borderRadius: "8px",
        //         border: '1px solid #f74a73',
        //         '&:hover': { borderColor: '#f74a73', border: '1px solid #f74a73' }, // border style on hover
        //         // default border color
        //         boxShadow: 'none', // no box-shadow 
        //         minHeight: '30px',
        //         // height: '35px',
        //     }),
        //     menuList: styles => ({
        //         ...styles,
        //         //    background: 'papayawhip' ,
        //     }),
        //     option: (provided, state) => ({
        //         ...provided,
        //         //fontWeight: state.isSelected ? "bold" : "normal",
        //         color: "black",
        //         //   height: 10,
        //         //   width: 300,
        //         padding: 4,
        //         // backgroundColor: state.data.color,
        //         fontSize: state.selectProps.myFontSize
        //     }),
        //     singleValue: (provided, state) => ({
        //         ...provided,
        //         color: state.data.color,
        //         fontSize: state.selectProps.myFontSize
        //     }),
        //     menu: base => ({
        //         ...base,
        //         zIndex: 100
        //     }),
        //     placeholder: (defaultStyles) => ({
        //         ...defaultStyles,
        //         // color: '#eaf1fa',
        //         fontSize: '13px',

        //     })
        // }
    },
    common: {
        radio: 'w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600',
        input: 'w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500',
        label: "ml-2 text-sm font-medium text-gray-900",
    }
};
// bg-[#1f52a3] BLUE COLOR