//SCREEN ID -3059
export const GridConstants = {
    AGGrid: {
        RowHeight: 35,
        RowHeightExcel: 25,
        paginationPageSize: 10,
        sno: 1,
        gridOptions: {
            // set background colour on every row, this is probably bad, should be using CSS classes 
            rowStyle: { background: 'white' }
        }
    },
};
