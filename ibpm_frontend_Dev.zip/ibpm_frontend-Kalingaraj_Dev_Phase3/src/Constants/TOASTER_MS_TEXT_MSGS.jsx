export const Auth_Common_Toaster = {
    Something_Went_Wrong: 'Something Went Wrong!',
};

export const Login_Toaster = {
    Please_Enter_Email_Address: 'Please enter email address!',
    Please_Enter_Valid_Email_Address: 'Please enter a valid email address!',
    Please_Enter_Password: 'Please enter password!',
    Please_Upload_dot_txt_File: 'Please upload a .txt file',
    Activation_Successful: 'Activation successful!',
    Activation_Failed: 'Activation failed!',
    Password_Updated_Successfully: 'Password updated successfully',
    Password_Is_Mandatory: 'Password is mandatory!',
    Confirm_Password_Is_Mandatory: 'Confirm password is mandatory !',
    Password_And_Confirm_Password_Is_Not_Matched: ' Password and Confirm password is not matched !'
};

export const Forget_Password_Toaster = {
    Email_Is_Mandatory: 'Email is mandatory !',
    Email_Is_Not_Valid: 'Email is not valid !',
    Reset_Link_Successfully_Sent_To_Your_Register_Email: 'Reset link successfully sent to your register email',
};

export const Change_Password_Toaster = {
    Password_Changed_Successfully: 'Password changed successfully',
    Reset_Link_Is_Expired: 'Reset Link is expired',
    Password_Changed: 'Password Changed !',
    Password_Is_Mandatory: 'Password is mandatory !',
    Password_And_Confirm_Password_Is_Not_Matched: 'Password and Confirm password is not matched !',
    Confirm_Password_Is_Mandatory: 'Confirm password is mandatory !',
    Your_Password_Has_Been_Changed_Successfully: 'Your password has been changed successfully .',
    Password_Validation_Error: 'A minimum 8 characters password contains a combination of uppercase, lowercase, special character and number is required. !'
};

export const Users_Toaster = {
    Are_You_Sure_You_Want_To_Delete: 'Are you sure you want to delete ',
    Organization_Is_Mandatory: 'Organization is mandatory !',
    Email_Is_Mandatory: 'Email is mandatory !',
    Email_Is_Not_Valid: 'Email is not valid !',
    Role_Is_Mandatory: 'Role is mandatory !',
    Password_Is_Mandatory: 'Password is mandatory !',
    Old_Password_Is_Mandatory: 'Old Password is mandatory !',
    Project_Is_Mandatory: 'At least one project must be added otherwise customer cannot be processed.',
    Project_Mandatory: 'Project is mandatory!',
    Module_Is_Mandatory: 'Module is mandatory !',
    Customer_Is_Mandatory: 'Project is mandatory !',
    Customers_Is_Mandatory: 'Customer is mandatory !',
    Password_Validation_Error: 'A minimum 8 characters password contains a combination of uppercase, lowercase, special character and number is required. !',
    Confirm_Password_Is_Mandatory: 'Confirm password is mandatory !',
    Password_And_Confirm_Password_Is_Not_Matched: 'Password and Confirm password is not matched !',
    No_File_Chosen: 'No File Chosen',
    Admin_Account_Creation_Successfully: 'Admin account created. Temporary password sent to your email',
    User_Added_Successfully: 'User added successfully!',
    User_Updated_Successfully: 'User updated successfully!',
    User_Deleted_Successfully: 'User deleted successfully!',
    Firstname_Is_Mandatory: 'Firstname is mandatory !',
    Old_Password_Differ: 'The old password must differ from the new password'

};

export const Roles_Toaster = {
    Role_Deleted_Successfully: 'Role deleted successfully',
    Role_Name_Cant_Be_Empty: 'Role name cannot be empty !',
    Role_Created_Successfully: 'Role created successfully!',
    Role_Updated_Successfully: 'Role updated successfully!',
};
export const Project_Toaster = {
    Project_Deleted_Successfully: 'Project deleted successfully',
    Customer_Deleted_Successfully: 'Customer deleted successfully',
    Project_Name_Cant_Be_Empty: 'Customer name cannot be empty !',
    Project_Created_Successfully: 'Project created successfully!',
    Customer_Created_Successfully: 'Customer created successfully!',
    Project_Updated_Successfully: 'Project updated successfully!',
    Customer_Updated_Successfully: 'Customer updated successfully!',
    ClientProject_Name_Cant_Be_Empty: 'Project name cannot be empty !',
};

export const Configuration_Toaster = {
    Please_Fillup_All_Input_Field: 'Please fillup all input field',
    Authentication_Success: 'Authentication success',
    Sharepoint_Validation_Success: 'Sharepoint validated successfully',
    Authentication_Failed: 'Authentication failed',
    Form_Submit_Success: 'Configuration created successfully',
    Form_Update_Success: 'Configuration Updated successfully',
    Configuration_Delete_Succes: 'Configuration deleted successfully',
};

export const BPMNViewer_Toaster = {
    Map_Name_Already_Exist: 'Map Name Already Exist!',
    Url_Published_Successfully: 'Url Published Successfully !',
    Published_Map_Deleted_Sucessfully: 'Published Map Deleted Sucessfully',
    Url_Already_Published_With_The_Map_Name: 'Url already Published with the Map Name!',
    Not_Mapped_Attribute: 'Not mapped attribute',
};

export const BPMN_Editor_Toaster = {
    Changes_Saved_Succesfully: 'Changes saved succesfully !',
    File_Type_Mismatch: 'File Type Mismatch !',
    Invalid_Type_Mismatch: 'Invalid Text File !',
    Please_Enter_The_Map_Name: 'Please enter the map name',
    Please_Enter_Project: 'Please select the project',
    Please_Select_Sharepoint_Configuration: 'Please Select sharepoint Configuration ',
    Please_Select_Specific_Users: 'Please Select specific users ',
    Map_Created_Successfully: 'Map Created Successfully',
    Map_Deleted_Successfully: 'Map deleted successfully',
    Please_Create_A_Diagram_To_Publish: 'Please create a diagram to Publish!',
    No_Changes_Detected: 'No changes detected',
    Map_Saved_Successfully: 'Map saved successfully!',
    Resource_Name_Cant_Be_Empty: 'Resource  Name Cant be Empty !',
    Please_Select_The_Activity: 'Please select the activity!',
    Document_Uploaded: ' Document uploaded',
    Please_Save_The_Changes_For_Rearrange_And_Move_Forward: 'Please save the changes for rearrange and move forward',
    Please_Do_The_Rearrange_And_Move_Forward: 'Please do the rearrange and move forward',
    Please_rearrange_the_elements_and_save_the_changes: 'Please do the rearrange and save the changes.',
    Map_Updated_Successfully: 'Map updated successfully',
    Sequence_Is_Repeated_So_Do_The_Changes_And_Retry: 'Sequence is repeated so do the changes and retry',
    Sequence_Number_Is_Repeated_So_Do_The_Changes_And_Retry: 'The resequenced number is already available, so please try with a different number.',
    Resequence_Completed: 'Resequence completed',
    Auto_Resequence_Completed: 'Automated Resequence completed',
    Please_Select_Reviewer_Name: 'Please Select Reviewer Name',
    Map_Successfully_Sent_To_Reviewer: 'Map successfully sent to reviewer',
    Please_Add_Comments_Before_Revert_To_Editor: 'Please add comments before revert to editor',
    Please_Add_Comments_Before_Approve_The_Map: 'Please add comments before approve the map',
    Map_Successfully_Reverted_To_Editor: 'Map successfully reverted to editor',
    No_Comments_Added: 'No comments added',
    Do_The_Re_Arrange_And_Then_Try_To_Navigate: 'Do the re-Arrange and then try to navigate',
    Map_Published_Successfully: 'Map published successfully !',
    Map_Approved_Successfully: 'Map approved successfully',
    Please_Enter_Greater_Than_0: 'Please enter greater than 0',
    Please_Enter_Only__Number: 'Please enter only number',
    Please_Enter_The_Details: 'Please enter the details',
    The_Entered_Resource_Name_Is_Already_Exists: 'The entered resource name is already exists.',
    Resource_Added_Successfully: 'Resource added successfully!',
    Resource_Updated_Successfully: 'Resource updated successfully!',
    Activity_Is_Already_Added_So_Please_Try_With_Different_Activity_Box: 'Activity is already added so please try with different Activity Box',
    Only_One_Activity_Box_Will_Be_Added_At_A_Time: 'Only one activity box will be added at a time.',
    Please_Select_The_Proper_Activity_Box_For_Flowlink: 'Please select the proper activity box for flowlink',
    Template_Edited_Successfully: 'Template edited successfully',
    Please_Enter_All_Data: 'Please enter all data!',
    Template_Deleted_Successfully: "Template deleted successfully",
    At_least_one_object_needs_to_be_checked: "At least one object needs to be checked",
    Valid_Bpm_file:"Please add a valid BPM Text file",
    Process_Activity:"To connect ALM,the activity type should be process"
};

export const BPMN_Common_Tosters = {
    Error_While_Updating_Diagram: 'Error while updating Diagram!',
    Currently_At_The_Home_Level: 'Currently at the home level !',
    The_Parent_Level_Does_Not_Exist: 'The parent level does not exist.!',
    The_Previous_Diagram_Is_Not_Available: 'The previous diagram is not available.!',
    The_File_Type_Preview_Msg_Start: 'The file type ',
    The_File_Type_Preview_Msg_End: ' preview is not available.',
    This_Flow_Line_Already_Has_A_Link_To_The_Selected_Destination_Flow_Line: 'This flow line already has a link to the selected destination flow line',
    Please_Select_Any_Destination_Flow_Line: 'Please select any destination flow line',
    Please_Select_Any_Flowline_And_Proceed_Further: 'Please select any flowline and proceed further',
};
export const AsisTobe_Toasts = {
    Please_Select_One_Row_From_Each_Map:"Please select one row from each map",
    Please_Select_Different_Map_Names_To_Compare:"Please select different map names to compare",
}