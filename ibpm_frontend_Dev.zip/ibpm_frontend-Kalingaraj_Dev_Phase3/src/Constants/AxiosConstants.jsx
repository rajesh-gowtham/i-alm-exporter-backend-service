//SCREEN ID -3054
export const AxiosConstants = {
    ApiBaseUrl: getBackendServerByEnv(),
    userToken: window.localStorage.getItem("Auth Token"),
    userdetaile: window.localStorage.getItem("user Details"),
    MasterBizUitKey: window.localStorage.getItem("MasterBizUitKey"),
    RoleName: window.localStorage.getItem("userRole"),
    OrganizationName: window.localStorage.getItem("OrganizationName")
};

function getBackendServerByEnv() {
    // return "http://10.1.1.189:7272/"
    const serverEnv = process.env.REACT_APP_ENV;
    // console.log(serverEnv);
    switch (serverEnv) {
        case "DEV":
            return process.env.REACT_APP_BACKEND_SERVER_DEV
        case "PRODUCTION":

            const REACT_BASE_URL = window.location.origin;
            const FE_URL = REACT_BASE_URL?.toLowerCase()?.includes(process.env.REACT_APP_URL_PUBLIC_PROD?.toLowerCase())
            if (FE_URL) {
                console.warn("Public ", process.env.REACT_APP_BACKEND_SERVER_PUBLIC_PROD);
                return process.env.REACT_APP_BACKEND_SERVER_PUBLIC_PROD;
            } else {
                console.warn("Private ", process.env.REACT_APP_BACKEND_SERVER_PRIVATE_PROD);
                return process.env.REACT_APP_BACKEND_SERVER_PRIVATE_PROD
            }

        default:
            console.error(" ENV Not matched ", serverEnv);
            break;
    }
}