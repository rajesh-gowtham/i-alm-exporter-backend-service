import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";
import axiosRaw from "axios";
import { AxiosConstants } from "../Constants/AxiosConstants";

const _APIEndPoint = masterAPIsEndPoints.LOGIN_API
class LoginService {
    LoginAPIcall(loginData) {
        const baseAPIURL = AxiosConstants.ApiBaseUrl;
        const url = `${baseAPIURL}public/users/loginAuthentication`;
        console.log("vurl ", url);

        return axiosRaw.create().post(url,
            loginData,
            {
                headers: {

                }
            }

        )
        // return axios.post(masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + _APIEndPoint._Login_Authentication, loginData)
    }
    ForgotAPIcall(loginData) {
        return axios.get(masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + _APIEndPoint._Generate_ResetPassword + _APIEndPoint._Request + loginData)
    }
    LinkpasswordAPIcall(email, resetToken) {
        console.log(email, resetToken);
        return axios.get(masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + _APIEndPoint._Verify_ResetPassword + email + _APIEndPoint._ResetToken + resetToken)
    }
    confirmResetPasswordAPIcall(resetData) {
        return axios.post(masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + _APIEndPoint._Confirm_Password, resetData)
    }
    LogOutSession(EmailId) {
        return axios.post(_APIEndPoint._Logout, EmailId)
    }
    changeNewPassword(requestData) {
        return axios.post(masterAPIsEndPoints._Users + masterAPIsEndPoints.BPMN_API._changeNewPassword, requestData)
    }
    changeTempPassword(requestData) {
        const baseAPIURL = AxiosConstants.ApiBaseUrl;
        const url = `${baseAPIURL + masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + masterAPIsEndPoints.BPMN_API._changeTempPassword}`;
        console.log("vurl ", url);

        return axiosRaw.create().post(url,
            requestData,
            {
                headers: {

                }
            }

        )
        // return axios.post(masterAPIsEndPoints._Public + masterAPIsEndPoints._Users + masterAPIsEndPoints.BPMN_API._changeTempPassword, requestData)
    }
    onReceiveProjectsData() {
        return axios.get(masterAPIsEndPoints.BPMN_API._GetCustomer)
    }
    uploadActivationFile(formData) {
        return axios.post(masterAPIsEndPoints._Public + _APIEndPoint._License, formData,)
    }
    uploadUpdateActivationFile(formData) {
        return axios.post(_APIEndPoint._License_Update, formData,)
    }
    sendReactErrorToBackenEnd(errorJSON) {
        return axios.post(masterAPIsEndPoints._Public + masterAPIsEndPoints._logContent, errorJSON)
    }
}
export default new LoginService();