import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.USERS_API;

class UserService {
    createNewUserAPIcall(userData) {
        return axios.post(masterAPIsEndPoints._Users + _APIEndPoint._Create_User, userData)
    }
    getAllUsersAPIcall() {
        return axios.get(masterAPIsEndPoints._Users + _APIEndPoint._View_User_Details)
    }
    deleteUsersAPIcall(userId) {
        return axios.delete(masterAPIsEndPoints._Users + _APIEndPoint._Delete_User + userId)
    }
    updateUserAPIcall(updatedData) {
        return axios.post(masterAPIsEndPoints._Users + _APIEndPoint._Edit_User, updatedData)
    }
    createNewAdminAPICall(userData){
        return axios.post("/public/licence/createAdmin", userData)
    }

}
export default new UserService();