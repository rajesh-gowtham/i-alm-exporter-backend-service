import axios from "axios";
import { AxiosConstants } from "../Constants/AxiosConstants";
import { ErrorMessage } from "../CommonUtils/CustomToast";

const baseAPIURL = AxiosConstants.ApiBaseUrl;
axios.defaults.baseURL = baseAPIURL;

axios.interceptors.request.use(
    (config) => {
        const accessToken = window.localStorage.getItem("accessToken");
        if (accessToken) {
            // console.warn('isAuthenticated #45 useraccessToken', window.localStorage.getItem('accessToken'));
            config.headers.Authorization = `Bearer ${accessToken}`;
            config.headers.Organization = `${localStorage.getItem('organization')}`;
            config.headers.UserId = `${localStorage.getItem('userid')}`;
        }
        return config;
    },
    (error) => Promise.reject(error),
);

let hasConfirmed = false;

axios.interceptors.response.use(
    (response) => {
        hasConfirmed = false;
        return response;
    },
    (error) => {
        if (error.response && (error.response.status === 401)) {
            window.localStorage.removeItem("accessToken");
            if (!hasConfirmed) {
                hasConfirmed = true;
                // window.alert(error.response.data.message || "Session expired. Redirect to login?")
                ErrorMessage('Session expired login agian to continue');
                window.location.href = '/';
            }
        }
        return Promise.reject(error);
    }
);


export default axios;
