import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.CUSTOMER_API;

class CustomerService {
    createNewCustomerAPICall(CustomerData) {
        return axios.post(masterAPIsEndPoints._Customer + _APIEndPoint._Add_Customer, CustomerData)
    }
    getAllCustomerAPIcall() {
        return axios.get(masterAPIsEndPoints._Customer + _APIEndPoint._Get_Customer)
    }
    deleteCustomerAPIcall(CustomerId) {
        return axios.delete(masterAPIsEndPoints._Customer + _APIEndPoint._Delete_Customer + CustomerId)
    }
    updateCustomerAPIcall(updatedCustomerData,id) {
        return axios.put(masterAPIsEndPoints._Customer + _APIEndPoint._Edit_Customer+id, updatedCustomerData)
    }
}
export default new CustomerService();