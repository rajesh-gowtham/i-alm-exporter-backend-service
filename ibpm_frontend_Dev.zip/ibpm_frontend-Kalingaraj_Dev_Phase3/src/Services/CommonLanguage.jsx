import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.LanguageConversion;

class CommonLanguageService {
    putLanguageAPIcall(FromLangauage,ToLanguage,payload) {
        return axios.post(_APIEndPoint._Language+FromLangauage+"/"+ToLanguage,payload)
    }
  

}
export default new CommonLanguageService();