import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.PROJECT_API;
class projectreceiverservice{
    getProjectsByUserId(id)
    {
            return axios.get(masterAPIsEndPoints._Projects + _APIEndPoint._Get_Projectbyid+id)
    }
}

export default new projectreceiverservice()