import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.BPMN_API;
class BPMNService {
    getBPMNServicedata() {
        return axios.get(_APIEndPoint._get_BPMN)
    }

    createNewBPMNService(BpmnData) {
        return axios.post(_APIEndPoint._create_BPMN, BpmnData)
    }
    SaveBPMNPublishdata(BpmnData) {

        let url = _APIEndPoint._savePublish_BPMN + BpmnData.diagramname + _APIEndPoint._publish_URL_BPMN + BpmnData.bpmn_xml
        console.log(url);
        return axios.post(url)
    }

    GetBPMNPublishdata(drname) {
        let url = _APIEndPoint._getPublish_BPMN + drname
        console.log(url);
        return axios.get(url)
    }
    saveLatestXmlAPICALL(data, diagramXmlId) {
        console.log(data, diagramXmlId);
        const url = _APIEndPoint._BPMN_XML + _APIEndPoint._saveLatest_XML + diagramXmlId;
        return axios.post(url, data)
    }
    getLastSavedXmlAPICALL(diagramXmlId) {
        return axios.get(_APIEndPoint._BPMN_XML + _APIEndPoint._getLatest_XML + diagramXmlId)
    }
    getSavedXmlAPICALL(taskconnectionId) {
        return axios.get(_APIEndPoint._get_Bpmn_Xml + taskconnectionId)
    }

    GetMappingField(BpmnData) {
        var dataSourceData = {
            datasourcename: BpmnData.datasourcename,
            url: BpmnData.taskid,
            username: '',
            modulename: '',
            password: '',
            defectTool: BpmnData.datasourcenametype,
            domainname: '',
            projectname: ''
        };
        return axios.post(_APIEndPoint._getMapping_Field, dataSourceData)
    }

    uploadActivityDocuments(formData, mapId) {
        const userId = window.localStorage.getItem("userid");
        return axios.post(_APIEndPoint._sharePoint_Doc + _APIEndPoint._sharePoint_Upload + userId + "/" + mapId, formData)
    };
    getActivityUploadedDocuments(fileName, documentId) {
        return axios.get(`${_APIEndPoint._sharePoint_Doc + _APIEndPoint._sharePoint_Download + fileName}/${documentId}`,
            {
                responseType: 'blob'
            })
    };
    deleteActivityUploadedDocuments(deleteReqPayLoad) {
        return axios.delete(`${_APIEndPoint._sharePoint_Doc + _APIEndPoint._sharePoint_Delete}`,
            {
                data: deleteReqPayLoad
            }
        )
    };

    createMapDiagramAPICALL(diagramPayload) {
        return axios.post(_APIEndPoint._bpmnDiagram + _APIEndPoint._createMapDiagram, diagramPayload)
    };

    updateMapDiagramAPICALL(diagramPayload, diagramXmlId) {
        return axios.put(_APIEndPoint._bpmnDiagram + _APIEndPoint._updateMapDiagram + diagramXmlId, diagramPayload)
    };
    deleteMapDiagramAPICALL(deleteReqPayLoad) {
        return axios.delete(`${_APIEndPoint._bpmnDiagram + _APIEndPoint._deleteMapDiagrams}`,
            {
                data: deleteReqPayLoad
            }
        )
    };
    getConfigDataByTypeAPICALL(type) {
        return axios.get(_APIEndPoint._getConfigDataByType + type)
    };

    getALMTestCasesFolderByIdAPICALL(configId) {
        return axios.get(_APIEndPoint._almFetchTestFolders + configId)
    };
    upsertActivityALMConnectIdAPICALL(reqPayload) {
        return axios.post(_APIEndPoint._upsertActivityALMConnect, reqPayload)
    };
    almConnectTestsByIdAPICALL(almConnectId) {
        return axios.get(_APIEndPoint._getActivityALMConnect + almConnectId)
    };
    deleteActivityALMConnectByIdAPICALL(almConnectId) {
        return axios.delete(_APIEndPoint._deleteActivityALMConnect + almConnectId)
    };

    getBPMNDiagramsByUserIdAPICALL() {
        return axios.get(_APIEndPoint._bpmnUserData + _APIEndPoint._getBpmnDiagramByUserId);
    }
    getUsersByRoleNameAPICALL(roleName, projectId) {
        return axios.get(_APIEndPoint._getUsersByRoleName + roleName + projectId)
    }
    ReviewerPostData(payloadData, mapId) {
        console.log(payloadData)
        return axios.post(_APIEndPoint._SEND_REVIEWER + mapId, payloadData)
    }
    revokeToDraftAPICALL(payload, mapId, diagramXmlId) {
        return axios.post(_APIEndPoint._revokeToDraft + mapId + "/" + diagramXmlId, payload);
    }
    deleteRevokedDraftAPICALL(mapId) {
        return axios.delete(_APIEndPoint._deleteUnlockedDraft + mapId);
    }
    publishBpmDiagramAPICALL(payload, mapId) {
        return axios.post(_APIEndPoint._publishBpmDiagram + mapId, payload);
    }
    getAllPublishedDiagramsAPICALL() {
        return axios.get(_APIEndPoint._getAllPublishedDiagrams);
    }

    postComments(requestpayload, diagramXml, currentXml) {
        const url = _APIEndPoint._Comments + diagramXml + "/" + currentXml;
        console.log(url)
        return axios.post(url, requestpayload)
    }
    updatePostComments(commentId, flagToggleActivity) {
        const url = _APIEndPoint._UpdateComments + commentId + "/" + flagToggleActivity;
        console.log(url)
        return axios.post(url)
    }
    getComments(diagramXml) {
        const url = _APIEndPoint._GetComments + diagramXml;
        // console.log(url)
        return axios.get(url)
    }
    getcommentsIsread(diagramXml, userId) {
        const url = _APIEndPoint._GetCommentsIsread + "/" + diagramXml + "/" + userId;
        return axios.get(url)
    }
    postCommentsMarkAsRead(payload, userId) {
        const url = _APIEndPoint._PutCommentsAsRead + "/" + userId;
        console.log(url)
        return axios.put(url, payload)
    }

    deleteExistingComment(requestpayload, diagramXml) {
        const url = _APIEndPoint._resequenceUpdates + diagramXml;
        console.log("url:", url)
        return axios.post(url, requestpayload)
    }
    setDefaultTemplate(templatePayload) {
        return axios.post(_APIEndPoint._BPMN_XML + _APIEndPoint._applyTemplate, templatePayload);
    }
    PublishDelete(deleteId) {
        return axios.delete(_APIEndPoint._publishDiagramDelete + deleteId);
    }
    updateDiagramTimeDiagramXmlIdAPICALL = (diagramXmlId, isCheckType) => {
        return axios.get(_APIEndPoint._bpmnDiagram + _APIEndPoint._updateDiagramTimeByDiagramXmlId + diagramXmlId + "/" + isCheckType)
    }
    createTemplateAPICALL(tempCreate) {
        return axios.post(_APIEndPoint._templateCreation, tempCreate);
    }
    editTemplateAPICALL(reqPayload) {
        return axios.put(_APIEndPoint._editTemplate, reqPayload);
    }
    getAllTemplatesAPICALL() {
        return axios.get(_APIEndPoint._getAllTemplates)
    }
    getTemplateById(templateId) {
        return axios.get(_APIEndPoint._getTemplateById + templateId)
    }
    deleteMultipleTemplates(deleteTemplateByIds) {
        return axios.delete(_APIEndPoint._deleteMultiTemplates,
            {
                data: deleteTemplateByIds
            });
    }

    getUsersByProjectId(projectId) {
        return axios.get(masterAPIsEndPoints._Projects + masterAPIsEndPoints.PROJECT_API._Get_UsersByProjectId + projectId)
    }

    deleteCommentsById(id) {
        return axios.delete(_APIEndPoint._deleteComments + id)
    }
    deleteAllComments(diagramid, userId) {
        return axios.delete(_APIEndPoint._deleteAllComments + diagramid + "/" + userId)
    }
    editCommentsById(id, payload) {
        return axios.put(_APIEndPoint._editComments + id, payload)
    }
    updateAllComments(payload) {
        return axios.post(_APIEndPoint._updateAllComments, payload)
    }
    auditTrail(payload) {
        return axios.post(_APIEndPoint._auditTrail, payload)
    }
    setAuditinsideMap(mapid, payload) {
        return axios.post(_APIEndPoint._auditTrail + _APIEndPoint._setAuditinsideMap + mapid, payload)
    }
    sendCommentsviaMail(payload) {
        return axios.post(_APIEndPoint._sendCommentsviaMail, payload)
    }
    groupCommentsPdf(payload) {
        return axios.post(_APIEndPoint._groupCommentsPdf, payload)
    }

}
export default new BPMNService();