import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.Project_API;

class ProjectClientService {
    createNewCustomerAPICall(CustomerData) {
        return axios.post(masterAPIsEndPoints._Projects + _APIEndPoint._Add_Project, CustomerData)
    }
    getAllCustomerAPIcall() {
        return axios.get(masterAPIsEndPoints._Projects + _APIEndPoint._Get_Project)
    }
    deleteCustomerAPIcall(CustomerId) {
        return axios.delete(masterAPIsEndPoints._Projects + _APIEndPoint._Delete_Project + CustomerId)
    }
    updateCustomerAPIcall(updatedCustomerData,id) {
        return axios.put(masterAPIsEndPoints._Projects + _APIEndPoint._Edit_Project+id, updatedCustomerData)
    }
    getCustomerDetails(org)
    {
        return axios.get(masterAPIsEndPoints._Customer + _APIEndPoint._getCustomerByName+org)
    }
    getCustomerByid(org)
    {
        return axios.get(masterAPIsEndPoints._Customer + _APIEndPoint._customerDetailsId+org)
    }
}
export default new ProjectClientService();