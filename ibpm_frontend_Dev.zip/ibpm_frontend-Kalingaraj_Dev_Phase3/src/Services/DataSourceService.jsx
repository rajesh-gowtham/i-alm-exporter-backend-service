import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.DATASOURCE_API;

class DataSourceService {
    authentication(authconfigdata) {
        return axios.post(_APIEndPoint._Authentication, authconfigdata
        );
    }

    getDomain(almCookies) {
        return axios.post(_APIEndPoint._GetDomainData, almCookies)
    }
    getAllProject(domainname, almCookies) {
        return axios.post(_APIEndPoint._GetProjectByDomain + domainname, almCookies)
    }
    getDataSourcedata() {
        return axios.get(_APIEndPoint._GetDataSourcedata)
    }

    createNewDataSource(dataSourceData) {

        return axios.post(_APIEndPoint._CreateNewDataSource, dataSourceData)
    }
    updateDataSource(dataSourceData) {
        console.log("dataSourceData ", dataSourceData);
        return axios.put(_APIEndPoint._UpdateDataSource + "/" + dataSourceData.id, dataSourceData)
    }
    validateSPCredentials(payload) {
        return axios.post(_APIEndPoint._SharePoint + _APIEndPoint._ValidateAccess, payload)
    }
    deleteDataSourceByIdAPICALL(configId) {
        return axios.delete(_APIEndPoint._DataSource + _APIEndPoint._DeleteDataSource + configId)
    }

}
export default new DataSourceService();