import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.ROLES_API;

class RolesService {
    createNewRoleAPICall(roleData) {
        console.log(roleData);
        return axios.post(masterAPIsEndPoints._Users + _APIEndPoint._Add_Role, roleData)
    }
    getAllRolesAPIcall() {
        return axios.get(masterAPIsEndPoints._Users + _APIEndPoint._Get_Role)
    }
    deleteRoleAPIcall(roleId) {
        return axios.delete(masterAPIsEndPoints._Users + _APIEndPoint._Delete_Role + roleId)
    }
    updateRoleAPIcall(updatedRoleData) {
        return axios.post(masterAPIsEndPoints._Users + _APIEndPoint._Edit_Role, updatedRoleData)
    }

}
export default new RolesService();