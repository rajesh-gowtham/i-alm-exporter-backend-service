import axios from "./AXIOS.config";
import { masterAPIsEndPoints } from "../Constants/UtilJSON";

const _APIEndPoint = masterAPIsEndPoints.RESOURCE_API;

class ResourceService {
    createNewResourceAPIcall(userData) {
        return axios.post(_APIEndPoint._Resources + _APIEndPoint._Create_Resource, userData)
    }
    getAllResourceAPIcall() {
        return axios.get(_APIEndPoint._Resources + _APIEndPoint._View_Resources_Detail)
    }
    deleteResourceAPIcall(userId) {
        return axios.delete(_APIEndPoint._Resources + _APIEndPoint._Delete_Resource + userId)
    }
    updateResourceAPIcall(updatedData) {
        return axios.post(_APIEndPoint._Resources + _APIEndPoint._Edit_Resource, updatedData)
    }

}
export default new ResourceService();