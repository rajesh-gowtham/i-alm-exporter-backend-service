import { legacy_createStore as createStore } from 'redux';

const initailState = {
    isSpinnerLoading: false,
    isUserAuthenticated: false,
    copiedLowerLevels: {},
    getActivityIdValue:""
}

const rootReducer = (state = initailState, action) => {
    switch (action.type) {
        case "SET_SPINNER_LOADING":
            return {
                ...state,
                isSpinnerLoading: action.payload,
            };
        case "SET_IS_USER_AUTHENTICATED":
            return {
                ...state,
                isUserAuthenticated: action.payload,
            };
        case "SET_COPIED_CONTENT":
            return {
                ...state,
                copiedLowerLevels: action.payload,
            };
        case "GET_ACTIVITY_ID":
            return {
                ...state,
                getActivityIdValue: action.payload,
            };
        default:
            return state;
    }
};
export default createStore(rootReducer)