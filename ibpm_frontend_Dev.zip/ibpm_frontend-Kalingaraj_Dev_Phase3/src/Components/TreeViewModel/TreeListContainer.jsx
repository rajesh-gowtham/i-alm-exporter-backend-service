import React, { useState } from "react";
import AutoSizer from "react-virtualized-auto-sizer";
import TreeList from "./TreeList";
import "./styles.css";

const TreeListContainer = ({ treeData, onClickItem, selectedNode, fromALMFolder ,selectedColor }) => {
  const [activeNodes, setActiveNodes] = useState([]);
  const itemHeight = 24
  const parseData = () => {
    const treeNodeList = []
    for (const treeNode of treeData) {
      parseNode({ treeNode, depth: 1, itemsList: treeNodeList })
    }
    return treeNodeList
  }

  const parseNode = ({
    treeNode,
    depth,
    itemsList,
    parentNodes = [],
    isLastChild = false
  }) => {
    const { id, meta, children, diagramXML, name, key, parentId } = treeNode
    const isNodecollapsed = depth === 1 ? activeNodes.includes(id) : !activeNodes.includes(id)

    const nodeHasChildren = children && children.length
    const mergedJSON = Object.assign({}, treeNode, {
      depth,
      hasChildren: nodeHasChildren,
      id,
      isCollapsed: isNodecollapsed,
      isLastChild,
      meta,
      parentNodes,
      name,
      key,
      diagramXML,
      parentId
    });
    // console.log(" mergedJSON ", mergedJSON);
    itemsList.push(mergedJSON)
    if (!isNodecollapsed && children) {
      const lastChild = children.slice(-1).pop()

      for (const child of children) {

        const isThisNodeLastChild = lastChild.id === child.id
        parseNode({
          depth: depth + 1,
          isLastChild: isThisNodeLastChild,
          itemsList,
          parentNodes: [...parentNodes, { ...treeNode, depth, isLastChild }],
          treeNode: child
        })
      }
    }
  }

  const getParsedData = parseData()

  const getContainerStyle = () => {
    const containerHeight = getParsedData.length * itemHeight
    if (containerHeight < 400) {
      return { height: containerHeight }
    }

    return null
  }
  return (

    <div className="tree-list__container" style={getContainerStyle()}>
      <AutoSizer className="tree-list">
        {({ height, width }) => (
          <TreeList
            parsedData={getParsedData}
            setActiveNodes={setActiveNodes}
            style={{ height, width, itemHeight }}
            activeNodes={activeNodes}
            onClickItem={onClickItem}
            selectedNode={selectedNode}
            fromALMFolder={fromALMFolder}
            selectedColor={selectedColor}
          />
        )}
      </AutoSizer>
    </div>
  )
}

export default TreeListContainer
