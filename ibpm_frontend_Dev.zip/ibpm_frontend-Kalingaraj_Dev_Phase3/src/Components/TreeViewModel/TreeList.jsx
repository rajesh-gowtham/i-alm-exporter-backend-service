import React from "react"
import { FixedSizeList as List } from "react-window"
import TreeItem from "./TreeItem"

const TreeList = ({ parsedData, setActiveNodes, style, activeNodes, onClickItem, selectedNode, fromALMFolder, selectedColor }) => {
  const toggleNodes = node => {

    if (node.depth !== 1) {
      node.isCollapsed
        ? setActiveNodes([...activeNodes, node.id])
        : setActiveNodes(activeNodes.filter(id => id !== node.id))
    } else {

      node.isCollapsed
        ? setActiveNodes(activeNodes.filter(id => id !== node.id))
        : setActiveNodes([...activeNodes, node.id])
    }
  }

  const treeItem = ({ index, style: itemStyle }) => {
    const node = parsedData[index]
    const defaultPaddingLeft = 27
    const isNodeFirstLevel = node.depth === 1
    const treeItemPadding = isNodeFirstLevel
      ? defaultPaddingLeft
      : defaultPaddingLeft * node.depth
    const verticalGuideLinesleft = isNodeFirstLevel
      ? defaultPaddingLeft
      : treeItemPadding - defaultPaddingLeft

    return (
      <TreeItem
        key={index}
        style={itemStyle}
        node={node}
        onClick={toggleNodes}
        onClickItem={onClickItem}
        activeNodes={activeNodes}
        defaultPadding={defaultPaddingLeft}
        isNodeFirstLevel={isNodeFirstLevel}
        itemPadding={treeItemPadding}
        verticalGuideLinesleft={verticalGuideLinesleft}
        selectedNode={selectedNode}
        fromALMFolder={fromALMFolder}
        selectedColor={selectedColor}
      />
    )
  }

  return (
    <List
      className="tree-list__list-wrapper List"
      height={style.height}
      itemCount={parsedData.length}
      itemSize={style.itemHeight}
      width={style.width}
    >
      {treeItem}
    </List>
  )
}

export default TreeList
