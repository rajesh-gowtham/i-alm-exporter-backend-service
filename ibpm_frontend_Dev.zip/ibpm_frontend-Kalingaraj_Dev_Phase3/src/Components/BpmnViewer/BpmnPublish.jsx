import "bpmn-font/dist/css/bpmn-embedded.css";
import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule, } from 'bpmn-js-properties-panel';
import "bpmn-js/dist/assets/diagram-js.css";
import BpmnModeler from "bpmn-js/lib/Modeler";
import camundaModdleDescriptors from 'camunda-bpmn-moddle/resources/camunda.json';
import React, { Component } from "react";
import { ReactDialogBox } from 'react-js-dialog-box';
import BPMNService from "../../Services/BPMNService";
import ALMTestCase from "./ALMTestCase";
import { ErrorMessage } from "../../CommonUtils/CustomToast";

//SCREEN ID -3000

class BpmnPublish extends React.Component {
    constructor(props) {
        super();
        this.state = {
            viewDiagram: false,
            isPopupshow: false,
            isPublish: false,
            isPublishOkey: false,
            AlmnTestCase: '',
            bpmn_xml: '',
            diagramname: '',
            taskJSON: '',
            isFlag: false
        }
    }



    CheckElements = () => {
        let elementid = document.getElementById("bio-properties-panel-id").value;
        const isFound = this.state.taskJSON.some(element => {
            return element.taskid === elementid;
        });

        if (isFound) {
            const taskdatasource = this.state.taskJSON.filter((auto) => auto.taskid.includes(elementid));
            console.log("***** ", taskdatasource[0]);
            if (taskdatasource[0].datasourcenametype === "Data Source")
                this.GetAlmTestCase(taskdatasource[0]);
            else if (taskdatasource[0].datasourcenametype === "Navigation")
                // this.GetNavigationPath
                console.log(" Navigation")
            else if (taskdatasource[0].datasourcenametype === "Document")
                this.setState({
                    documentpath: taskdatasource[0].documentpath,
                    isPopupshow: true
                })

            this.setState({
                datasourcetype: taskdatasource[0].datasourcenametype,
                // isPopupshow: taskdatasource[0].datasourcenametype === "Navigation" ? false : true
            })

        } else {
            ErrorMessage('Not mapped attribute')
        }
    }
    closePopup = () => {
        this.setState({
            isPopupshow: false
        })
    }

    GetAlmTestCase = async (datasorce) => {
        console.log("GetAlmTest ", (datasorce))
        try {
            const response = await BPMNService.GetMappingField(datasorce);
            console.log("Response " + JSON.stringify(response.data))
            this.setState({
                AlmnTestCase: response.data,
                AlmDataSource: datasorce,
                isPopupshow: true
            })
        }
        catch (err) {
            console.error(" Error ", err);
        }
    }

    componentDidMount() {
        // document.getElementsByClassName('djs-group').setAttribute('draggable', false);
        BPMNService.GetBPMNPublishdata(this.props.diagramname).then(
            response => {
                this.setState({
                    bpmn_xml: response.data[0].bpmnXml,
                    taskJSON: JSON.parse(response.data[0].taskJSON),
                    isFlag: true
                })
            });
    }

    render() {

        return (
            <>
                {this.state.isFlag === true ?
                    <PublishClientDiragram
                        bpmn_xml={this.state.bpmn_xml}
                        CheckElements={this.CheckElements}
                    /> : null}
                {this.state.isPopupshow && (
                    <>
                        <ReactDialogBox
                            closeBox={this.closePopup}
                            modalWidth='68vw'
                            headerBackgroundColor='#3266b9'
                            headerTextColor='black'
                            headerHeight='40px'
                            closeButtonColor='#fc581c'
                            closeButtonSize='20px'
                            bodyBackgroundColor='#fffdfc'
                            bodyTextColor='black'
                            //   bodyHeight='150px'
                            // headerText='ALM TestCase'
                            headerText={this.state.datasourcetype === 'Data Source' ? 'Test Case' : this.state.datasourcetype}

                        >
                            <div>

                                <div>
                                    {this.state.datasourcetype === 'Data Source' ?
                                        <div>
                                            <ALMTestCase
                                                AlmnTestCase={this.state.AlmnTestCase}
                                                AlmDataSource={this.state.AlmDataSource}
                                            />
                                        </div> : null}
                                    {this.state.datasourcetype === 'Document' ?
                                        <div>
                                            <div>
                                                <div class="p-2 text-center">
                                                    {/* <BsCloudDownload size={32} color="green" /> */}
                                                    <h5 class="mb-1 font-normal text-gray-500 text-lg dark:text-gray-400">Are you sure you want to Download? <br /><span class='text-blue-800'>{this.state.documentpath}</span></h5>
                                                    {/* <h6 class="mb-5 py-2 text-black text-small dark:text-gray-400"><BiCopy size={20}/> : <span class='border-2 p-2 text-blue-700'>{window.location.protocol + '//' + window.location.hostname + ":8286/bpmnPublish/" + this.state.diagramname}</span> <span class='font-semibold text-orange-600'></span></h6> : null} */}
                                                    <div class="flex justify-center pt-2">
                                                        <button
                                                            type="button"
                                                            class="flex bg-blue-600 shadow-lg mx-5 px-4 py-3 rounded-md focus:ring-4 text-white transform transition-transform active:scale-x-75 outline-none"
                                                        >
                                                            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                                            </svg>
                                                            <a class='underline' href={this.state.documentpath}>Download</a>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> : null}
                                </div>

                            </div>
                        </ReactDialogBox>
                    </>
                )}

            </>
        )
    }
}

export default BpmnPublish;


class PublishClientDiragram extends Component {
    modeler = null;
    constructor(props) {
        super(props);
        this.state = {
            propview_Width: "0%",
            TaskDetails: "",
            bpmnview_Width: "100%",
            changeview_Width: false,
            Map_DataSouceFlag: false,
            BpmnXmlData: props.bpmn_xml,
            TimeDelay: 10000,
        };
        this.containerRef = React.createRef();
    }


    Check_UserOnclick = () => {
        // alert("OKEY")
    }

    componentDidMount = () => {
        //alert('props.bpmn_xml'+this.props.bpmn_xml)

        const container = this.containerRef.current;

        this.modeler = new BpmnModeler({
            container: container,
            keyboard: {
                bindTo: window
            },
            propertiesPanel: {
                parent: "#propview"
            },
            additionalModules: [BpmnPropertiesProviderModule, BpmnPropertiesPanelModule,
                {
                    __init__: ["labelEditingProvider"],
                    labelEditingProvider: ['value', null],
                },
                {
                    dragging: ["value", { init: function () { } }]
                }
            ],
            moddleExtensions: {
                camunda: [camundaModdleDescriptors]
            }
        });
        this.newBpmnDiagram();
    };

    newBpmnDiagram = () => {
        this.openBpmnDiagram(this.props.bpmn_xml);
    };


    openBpmnDiagram = xml => {
        this.modeler.importXML(xml, error => {
            if (error) {
                return console.log("fail import xml");
            }
            var canvas = this.modeler.get("canvas");
            canvas.zoom("fit-viewport");
        });
    };

    render = () => {
        return (
            <AuthCommonLayout>
                <div>
                    <div id="view">
                        <div id="bpmncontainer">
                            <div
                                id="propview"
                                style={{
                                    width: this.state.propview_Width,
                                    height: "50vh",
                                    float: "right",
                                    maxHeight: "98vh",
                                    overflowX: "auto"
                                }}
                            ></div>
                            <div
                                onClick={this.props.CheckElements}
                                id="bpmnview"
                                ref={this.containerRef}
                                style={{ width: this.state.bpmnview_Width, height: "98vh", float: "left" }}
                            ></div>
                        </div>
                    </div>
                </div>

            </AuthCommonLayout>


        );
    };
}



function AuthCommonLayout(props) {
    return (
        <div class="flex bg-white w-full h-screen text-gray-200 antialiased overflow-hidden">
            <div class="flex flex-col flex-1">
                <main class='flex flex-row flex-grow min-h-0'>
                    {/* SIDEBAR */}
                    <section class="flex flex-col flex-none transition-all duration-300 ease-in-out">
                        <div class="flex-1 max-h-[100vh] contacts">
                            {/* <Sidebar toggle={true} /> */}
                        </div>
                    </section>
                    <section class="flex flex-col flex-auto">
                        {/* HEADER */}
                        <div class="">
                            <header>
                                <nav class="border-gray-200 bg-[#6EC5E9] dark:bg-gray-800 px-4 lg:px-6 py-1 h-14">
                                    <div class="flex flex-wrap justify-between items-center mx-auto max-w-screen-xl">
                                        <button class="flex items-center">
                                            {/* <h3 class="pl-2 max-lg::pl-0 font-medium text-blue-800 md:text-2xl max-lg:mob-txt-sm"><span class="text-logo-orange"><span class="font-medium">i</span></span>-BPMN</h3> */}
                                        </button>
                                        <div class="flex items-center lg:order-2">

                                            <button class="bg-primary-700 hover:bg-primary-800 dark:hover:bg-primary-700 dark:bg-primary-600 mr-2 px-4 lg:px-5 py-2 lg:py-2.5 rounded-lg focus:ring-4 focus:ring-primary-300 dark:focus:ring-primary-800 font-medium text-sm text-white focus:outline-none">  <img src="https://igosolutions.eu/img/igologo.png" class="mr-3 h-6 sm:h-9" alt="Flowbite Logo" /></button>
                                            <button data-collapse-toggle="mobile-menu-2" type="button" class="inline-flex items-center lg:hidden hover:bg-gray-100 dark:hover:bg-gray-700 ml-1 p-2 rounded-lg focus:ring-2 focus:ring-gray-200 dark:focus:ring-gray-600 text-gray-500 text-sm dark:text-gray-400 focus:outline-none" aria-controls="mobile-menu-2" aria-expanded="false">
                                                <span class="sr-only">Open main menu</span>
                                                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd"></path></svg>
                                                <svg class="hidden w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"></path></svg>
                                            </button>
                                        </div>
                                        <div class="lg:flex justify-between items-center lg:order-1 hidden w-full lg:w-auto" id="mobile-menu-2">
                                        </div>
                                    </div>
                                </nav>
                            </header>

                        </div>
                        {/* MAIN PAGE */}
                        <div class="flex-1 bg-[#ebeef6] px-2 max-sm:px-4 py-4 overlay">
                            <div class='bg-white max-sm:px-2 rounded-md'>
                                {props.children}
                            </div>
                        </div>
                    </section>
                </main>
            </div>
        </div>
    )
}
