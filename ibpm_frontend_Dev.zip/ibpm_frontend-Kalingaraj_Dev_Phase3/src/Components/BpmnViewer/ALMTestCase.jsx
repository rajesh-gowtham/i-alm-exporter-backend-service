import { useEffect, useState } from 'react';
import { AiOutlineUser } from 'react-icons/ai';
import { FaRegFile } from 'react-icons/fa6';
import { MdDeleteOutline, MdOutlineClose } from "react-icons/md";
import { DeleteConfirmPOPUP, isValidValue } from '../../CommonUtils/ComponentUtil';
import { isObject } from 'lodash';

const ALMTestCase = (props) => {
    const [records, setRecords] = useState(props.almMappedTestcases?.length > 0 ? props.almMappedTestcases[0] : {});
    const [actionIndex, setActionIndex] = useState(0);
    const [isDeleteALMEnable, setIsDeleteALMEnable] = useState(false);
    console.log(" props ", props);
    useEffect(() => {
        // setTestCaseById();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    // const setTestCaseById = async () => {
    //     setentities(props.almMappedTestcases)
    //     const tempArr = props.AlmnTestCase?.TestCase;
    //     console.log(" tempArr ", tempArr)
    //     const ids = props.AlmDataSource?.almtestcase;//+ "";
    //     let givenTestIds = props.AlmDataSource.datasorce//.split(',');
    //     console.log(" ids  ", givenTestIds);
    //     let filteredTestCases = [];
    //     tempArr?.forEach((dataArr, ind) => {
    //         const id = sampleArrToValue(dataArr, "id");
    //         if (givenTestIds.includes(id)) {
    //             filteredTestCases.push(dataArr)
    //         }
    //     })
    //     setentities(filteredTestCases)
    //     onTestNameOnClick(filteredTestCases[0], 0)
    // }

    const onTestNameOnClick = async (data) => {
        console.log(" onTestNameOnClick ", data)
        setRecords(data);
        setActionIndex(0);
        return
        // if (!data) { return }
        // const testName = sampleArrToValue(data, "name");
        // const type = sampleArrToValue(data, "subtype-id");
        // const createDate = sampleArrToValue(data, "creation-time");
        // const designer = sampleArrToValue(data, "owner");
        // const status = sampleArrToValue(data, "status");
        // const testId = sampleArrToValue(data, "id");
        // const description = sampleArrToValue(data, "description");
        // const id = sampleArrToValue(data, "id");

        // let designSteps = [];
        // const setDesignSteps = (async () => {
        //     const designData = props.AlmnTestCase?.DesignSteps;
        //     console.log(" designSteps[0] ", designData);
        //     designData.forEach(fields => {
        //         const parentId = sampleArrToValue(fields, "parent-id")
        //         if (id === parentId) {
        //             const stepName = sampleArrToValue(fields, "name");
        //             const designDescription = sampleArrToValue(fields, "description");
        //             const expectedResult = sampleArrToValue(fields, "expected");

        //             const dataArr = {
        //                 stepName: stepName,
        //                 description: designDescription,
        //                 expResult: expectedResult
        //             };
        //             designSteps.push(dataArr)
        //         }
        //     }
        //     )
        //     console.log(" designSteps ", designSteps)
        // })
        // await setDesignSteps();
        // const details = {
        //     testName: testName, type: type, createDate: createDate,
        //     designer: designer, status: status, testId: testId, description: description
        // }
        // const records = { details: details, designSteps: designSteps, index: index }
        // setRecords(records);
        // setActionIndex(0);
    }

    // const sampleArrToValue = (array, fieldValue) => {
    //     try {
    //         const tempArr = array.Fields;
    //         let resuts;
    //         tempArr.forEach(item => {
    //             if (item.Name === fieldValue) {
    //                 resuts = item.values[0].value === undefined ? '' : item.values[0].value
    //             }
    //         })
    //         return resuts;
    //     } catch (error) {
    //         console.error(" Error in sampleArrValue ", error);
    //     }
    // }
    const isFromTestCases = props?.AlmDataSource.type === "test" || props?.AlmDataSource.type === "test-folder";
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[70vw]">
                    <div className="bg-white border-box rounded-md w-full font-sans text-gray-900">
                        <div className="flex justify-center mx-2 w-full">
                            <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                    <span className="font-semibold text-lg">
                                        {isFromTestCases ? 'ALM Test Cases' : 'ALM Requirements'}
                                    </span>
                                    <span className="flex items-center space-x-4 p-[2px]">
                                        {!props.isMapLocked ?
                                            <button onClick={() => { setIsDeleteALMEnable(true) }} class="group inline-flex relative justify-center items-center shadow-md p-4 px-6 py-1 border-2 border-red-500 rounded-lg overflow-hidden font-medium transition duration-300 ease-out">
                                                <span class="absolute inset-0 flex justify-center items-center bg-red-500 w-full text-white -translate-x-full group-hover:translate-x-0 duration-300 ease">
                                                    <MdDeleteOutline className='pr-[6px]' size={24} />
                                                </span>
                                                <span class="absolute flex justify-center items-center w-full text-red-500 transition-all group-hover:translate-x-full duration-300 transform ease">Delete</span>
                                                <span class="invisible relative">Delete</span>
                                            </button>
                                            : null
                                        }
                                        <MdOutlineClose onClick={props.closeDialogPopupBox} className='hover:bg-gray-200 rounded' size={22} />
                                    </span>
                                </div>
                                <div class="flex w-full h-[75vh] text-black">
                                    <div className='flex w-full h-full'>
                                        <div className='flex flex-col w-[30%]'>
                                            <div className='flex justify-center items-center bg-slate-50 drop-shadow-2xl py-[15px] border-[#00000034] border-r border-b w-full'>
                                                <div class="font-semibold text-[16px] text-black">{`${props?.selActivityName} (${props.almMappedTestcases?.length}) `}</div>
                                            </div>
                                            <div className='mb-3 px-1 pt-1 border-[#00000034] border-r w-full h-full overflow-x-auto overflow-y-auto text-base'>
                                                {props.almMappedTestcases?.map(test =>
                                                    <div onClick={() => { onTestNameOnClick(test) }} className={`flex items-center space-x-1.5 border-[#00000034] ${test.id === records.id ? " bg-slate-400 " : " bg-slate-50 bg-opacity-30 "}  hover:bg-gray-300 my-1.5 px-1 py-1 border rounded-md w-full font-medium text-[14px] cursor-pointer`}>
                                                        <span>
                                                            <FaRegFile size={18} color='#0b2e6c' />
                                                        </span>
                                                        <span >
                                                            {test.name}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <div className='flex flex-col w-[70%] h-full'>
                                            <div className='space-x-2 bg-gray-100 shadow-lg py-[9px] pl-2 border-[#00000034] border-b font-sans'>
                                                <div class="flex space-x-4 pl-1 rounded-lg">
                                                    <button onClick={() => { setActionIndex(0) }} class={`flex ${actionIndex === 0 ? " bg-blue-500 text-white " : " bg-white "}  px-4 py-1.5 rounded-md transition-all duration-300 focus:outline-none`}>{isFromTestCases ? 'Test Details' : 'Requirement Details'}</button>
                                                    {isFromTestCases ? <button onClick={() => { setActionIndex(1) }} class={`flex ${actionIndex === 1 ? " bg-blue-500 text-white " : " bg-white "}  px-4 py-1.5 rounded-md transition-all duration-300 focus:outline-none`}>Design Steps</button>
                                                        : null}
                                                </div>
                                            </div>
                                            <div className='h-full overflow-y-auto'>
                                                <div class="flex flex-col mb-3 p-2 w-full h-full text-[6px]">
                                                    {actionIndex === 0 ?
                                                        <FormDetails records={records} isFromTestCases={isFromTestCases} />
                                                        :
                                                        <div className="py-4">
                                                            <DesignSteps rowData={records.designSteps || []} />
                                                        </div>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {isDeleteALMEnable ? (
                        <DeleteConfirmPOPUP
                            titleName={"Delete ALM Connectivity"}
                            deleteDataName={props?.AlmDataSource?.folderName}
                            oKBtnOnClick={() => props.deleteALMOnClick(props?.AlmDataSource?.folderName)}
                            cancelBtnOnClick={() => setIsDeleteALMEnable(false)}
                        />
                    )
                        : null}
                </div>
            </div>
        </div>
    );
};
export default ALMTestCase;

const FormDetails = ({ records, isFromTestCases }) => {
    console.log(" records ", records, "isFromTestCases", isFromTestCases)
    const getTypeValueTypeId = (typeId) => {
        let result;
        switch (typeId) {
            case "0":
                result = "undefined";
                break;
            case "1":
                result = "folder";
                break;
            case "2":
                result = "group";
                break;
            case "3":
                result = "functional";
                break;
            case "4":
                result = "Businness";
                break;
            case "5":
                result = "Testing";
                break;
            case "6":
                result = "Perfomance";
                break;
            default:
                result = "";
                break;
        }
        return result;
    }

    return (
        <form>
            {records === undefined || Object.keys(records).length === 0 ?
                <div className="flex justify-center items-center h-[70vh] text-black text-2xl">
                    <div className=''>
                        No TestCases Found !
                    </div>
                </div>
                :
                <div >
                    <div className="pb-6 border-gray-900/10 border-b">
                        <div className="gap-x-6 gap-y-4 grid grid-cols-1 sm:grid-cols-6">

                            <div className="sm:col-span-3">
                                <label htmlFor="testName" className="block font-medium text-gray-900 text-sm leading-6">
                                    Name
                                </label>
                                <div className="mt-1">
                                    <input
                                        type="text"
                                        name="testName"
                                        id="testName"
                                        disabled
                                        value={records?.name}
                                        autoComplete="given-name"
                                        className="block shadow-sm px-2 py-1.5 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="sm:col-span-3">
                                <label htmlFor="type" className="block font-medium text-gray-900 text-sm leading-6">
                                    Type
                                </label>
                                <div className="mt-1">
                                    <input
                                        type="text"
                                        name="type"
                                        id="type"
                                        disabled
                                        value={isFromTestCases ? records['subtype-id'] : getTypeValueTypeId(records['type-id'])}
                                        autoComplete="family-name"
                                        className="block shadow-sm px-2 py-1.5 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="sm:col-span-3">
                                <label htmlFor="createDate" className="block font-medium text-gray-900 text-sm leading-6">
                                    Creation Date
                                </label>
                                <div className="mt-1">
                                    <input
                                        type="text"
                                        name="createDate"
                                        id="createDate"
                                        disabled
                                        value={records["creation-time"]}
                                        autoComplete="family-name"
                                        className="block shadow-sm px-2 py-1.5 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="sm:col-span-3">
                                <label htmlFor="designer" className="block font-medium text-gray-900 text-sm leading-6">
                                    Author
                                </label>
                                <div className="relative mt-1">
                                    <span class="left-0 absolute inset-y-0 flex items-center pl-2">
                                        <AiOutlineUser size={18} />
                                    </span>
                                    <input
                                        type="text"
                                        name="designer"
                                        id="designer"
                                        disabled
                                        value={records?.owner}
                                        autoComplete="family-name"
                                        className="block shadow-sm px-2 py-1.5 pl-9 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="sm:col-span-3">
                                <label htmlFor="status" className="block font-medium text-gray-900 text-sm leading-6">
                                    {isFromTestCases ? 'Status' : 'Priority'}
                                </label>
                                <div className="mt-1">
                                    <input
                                        type="text"
                                        name="status"
                                        id="status"
                                        disabled
                                        value={isFromTestCases ? records?.status : (((!isObject(records['req-priority'])) && isValidValue(records['req-priority'])) ? records['req-priority'] : "Nil")}
                                        autoComplete="family-name"
                                        className="block shadow-sm px-2 py-1.5 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="sm:col-span-3">
                                <label htmlFor="testId" className="block font-medium text-gray-900 text-sm leading-6">
                                    {isFromTestCases ? 'Excecution Status' : 'Direct Cover Status'}
                                </label>
                                <div className="mt-1">
                                    <input
                                        type="text"
                                        name="testId"
                                        id="testId"
                                        disabled
                                        value={isFromTestCases ? records?.["exec-status"] : records['status']}
                                        autoComplete="family-name"
                                        className="block shadow-sm px-2 py-1.5 border-0 rounded-md ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                                    />
                                </div>
                            </div>
                            <div className="col-span-full mt-2 border-t border-black/30">
                                <label htmlFor="about" className="block font-medium text-gray-900 text-sm leading-6">
                                    description
                                </label>
                                <div className="mt-2">
                                    {(!isObject(records?.description)) && isValidValue(records?.description) ? <div
                                        dangerouslySetInnerHTML={{ __html: records?.description }}
                                    />
                                        : <div className='font-normal text-base'>
                                            No description available
                                        </div>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            }
        </form>
    )
}

const DesignSteps = ({ rowData }) => {
    console.log(rowData);

    return (
        <div className='bg-[#ebeef6] rounded' >
            {
                rowData?.length === 0 ?
                    <div className="flex justify-center items-center h-[70vh] text-black text-2xl">
                        <div className=''>
                            No Design Steps Found !
                        </div>
                    </div>
                    :
                    <div class="relative shadow-md overflow-x-auto">
                        <table class="rounded-md w-full text-gray-500 dark:text-gray-400 text-sm text-left rtl:text-right">
                            <thead class="bg-gray-300 text-gray-700 text-xs uppercase">
                                <tr>
                                    <th scope="col" class="px-6 py-3 border border-black">
                                        Step Name
                                    </th>
                                    <th scope="col" class="px-6 py-3 border border-black">
                                        Description
                                    </th>
                                    <th scope="col" class="px-6 py-3 border border-black">
                                        Expected Result
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {rowData.map(row => <tr class="even:bg-gray-50 even:dark:bg-gray-800 odd:bg-white odd:dark:bg-gray-900 dark:border-gray-700 border-b">
                                    <th scope="row" class="bg-gray-50 px-6 py-4 border border-black font-medium text-gray-900 whitespace-nowrap">
                                        {row.name}
                                    </th>
                                    <td class="bg-gray-50 backdrop-opacity-30 px-6 py-4 border border-black">
                                        <div className='bg-gray-50 text-gray-900' dangerouslySetInnerHTML={{ __html: row.description }} />
                                    </td>
                                    <td class="bg-gray-50 backdrop-opacity-30 px-6 py-4 border border-black">
                                        <div className='bg-gray-50 text-gray-900' dangerouslySetInnerHTML={{ __html: row.expected }} />
                                    </td>
                                </tr>)}

                            </tbody>
                        </table>
                    </div>
            }
        </div>
    );
}