import { cloneDeep ,isArray} from 'lodash';
import React, { Component } from 'react';
import { BsArrow90DegUp } from 'react-icons/bs';
import { FcHome } from 'react-icons/fc';
import { FiZoomIn, FiZoomOut } from 'react-icons/fi';
import { IoIosArrowForward } from 'react-icons/io';
import { IoChevronForward, IoPrintOutline } from "react-icons/io5";
import Select from 'react-select';
import ReactToPrint from 'react-to-print';
import { DropdownIndicator, ReactSelect, compareTwoXmlStringSame, ALMReqTestCaseChoose,getMimeTypeByFileName, isValidValue,getALMConnectedTests } from "../../CommonUtils/ComponentUtil";
import { ErrorMessage } from '../../CommonUtils/CustomToast';
import ShowDiagramPrint from '../../CommonUtils/DiagramPrint';
import { translateXmlNamesByLanguage } from '../../CommonUtils/translateXml';
import { BPMNViewer_Labels, BPMN_Common_Labels } from '../../Constants/COMMON_LABELS';
import { BPMN_Common_Tosters } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import BPMNService from '../../Services/BPMNService';
import diagramXML from '../../assets/diagram.bpmn';
import { getXmlDiagram } from '../BpmnDiagrams/getBpmnDiagrams';
import { ActivityFileDocuments, AddFlowLineTargetPopup, DownloadDiagramPOPUP, OnshowFlowlineActivity } from '../ComundaTool/EditUtilPoupComp';
import ResizeCompIndex from '../ComundaTool/ResizeComponent/TreeViewSideBarResize';
import allLanguages from '../GoogleTranstor/transLanguages.json';
import ShowDiagram from './ShowDiagram';
import ALMTestCase from './ALMTestCase';

class ShowDiagramParent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedLanguage: { label: 'English', value: 'en' },
      isActivityFileDocEnable: false,
      diagramLevel: "CurrentProcessMap",
      isdownload: false,
      editElementObj: "",
      selActivityId: '',
      selActivityName: '',
      mappingDiagrams: [
        {
          id: "1",
          name: "",
          key: "1",
          meta: {
            collapsed: true,
            label: ""
          },
          diagramXML: "",
          parentId: null,
          children: [],
          flowlineMap: []
        },
      ],
      currentMapDet: {
        id: "1",
        meta: {
          collapsed: true,
          label: "1-Map"
        },
        name: "Map",
        key: "",
        diagramXML: "",
        parentId: "",
        children: [],
        flowlineMap: []
      },
      isDiagNavigationClicked: false,
      isTreeView: true,
      showFlowlinoepopup: false,
      showFlowlinoepopupTarget: false, bpmnXMLs: [],
      renderedDiagrams: [],
      isRendering: false,
      PrintLevel: false,
      diagramXml: [],
      printTriggered: false,
      isReqOrTestcaseEnable:false
    };
    this.handleBpmnRef = React.createRef();
    this.containerRef = React.createRef();
    this.diagramListRef = React.createRef();
    this.printRef = React.createRef();
  }

  componentDidMount() {
    const mappingXml = JSON.parse(this.props.bpmn_xml)
    this.setState({
      mappingDiagrams: mappingXml,
      selectedLanguage: this.props.selectedLanguage,
      currentMapDet: mappingXml[0]
    })
    console.log(mappingXml)
    fetch(diagramXML).then(res => res.text()).then(diagramXML => {
      // console.log(" diagramXML test fetch 1", diagramXML);
      this.setState({
        diagramXML: diagramXML,
      });
    });
  };


  zoomInOutBpmn_OnClick = (key) => {
    console.log(key, " key  ", this.handleBpmnRef.current.bpmnModeler.get('zoomScroll'));
    switch (key) {
      case "in":
        this.handleBpmnRef.current.bpmnModeler.get('zoomScroll').stepZoom(1);
        break;
      case "out":
        this.handleBpmnRef.current.bpmnModeler.get('zoomScroll').stepZoom(-1);
        break;
      case "reset":
        console.log("Zoom Reset ");
        break;
      default:
        break;
    }
  };
  handleElementDblClickByTool = async (e, type, selActivityName, tempBussObjAttr) => {
      console.log("HANDLE dblClick ", e, type, selActivityName, tempBussObjAttr);

    if (type === "FILE") {
      // const activityFiles = tempBussObjAttr.allFileNamesWithId === undefined || tempBussObjAttr.allFileNamesWithId === null ? [] : JSON.parse(tempBussObjAttr.allFileNamesWithId);
      // console.log("fileName ", activityFiles);
      // console.log("nameOrActId ", tempBussObjAttr);
      // this.setState({
      //   isActivityFileDocEnable: true,
      //   selActivityId: tempBussObjAttr.parentActivityId,
      //   selActivityDocFiles: activityFiles,
      //   editElementObj: e,
      // })


      let docs = e.businessObject.get('documentation');
      console.log("docs ", docs)
      const allFileNamesWithId = docs.find(d => d.textFormat === 'json/file-document')
      console.log("allFileNamesWithId ", allFileNamesWithId)
      const activityFiles = allFileNamesWithId?.text === undefined || allFileNamesWithId?.text === null || allFileNamesWithId?.text === "" ? [] : JSON.parse(allFileNamesWithId.text);
      console.log("fileName ", activityFiles);
      // console.log("nameOrActId ", tempBussObjAttr);
      this.setState({
        isActivityFileDocEnable: true,
        selActivityId: e.id,
        selActivityDocFiles: activityFiles,
        editElementObj: e,
      })
      // this.downloadDocSharePointAPICALL(nameOrActId, fileName)
    } else if (type === "ALM") {
      try {
        this.props.openSpinnerRedux()
        let docs = e.businessObject.get('documentation');
        const almDataAdded = docs.find(d => d.textFormat === 'json/file-ALMConnect')
        const almData = isValidValue(almDataAdded.text) ? JSON.parse(almDataAdded.text) : []
        console.log(almData)
        if (!isArray(almData) || almData.length === 1) {
          console.log(" almData iff ", almData);
          const selALMData = isArray(almData) ? almData[0] : almData
          console.log("selALMData ", selALMData);
          const finalResultArray = await getALMConnectedTests(selALMData.almConnectId);
        console.log(" selActivityName ", selActivityName);
        this.setState({
          almMappedTestcases: finalResultArray,
          isALMTestCaseViewEnable: true,
          AlmDataSource: selALMData,
          selActivityName: selActivityName
        })
        this.props.closeSpinnerRedux()
      }
      else{
        this.setState({
          isReqOrTestcaseEnable: true,
          almData: almData,
          // isALMTestCaseViewEnable: false,
        })
      }
      } catch (error) {
        this.props.closeSpinnerRedux()
      }

    }
  };
  refreshBpmn_OnClick = async () => {
    try {
      const xml = await getXmlDiagram("default");
      console.log("refreshed xml", xml);
      await this.updateXmlByImportXML(xml);
    } catch (error) {
      console.error("refresh ", error);
    }
    // this.setState({ selectedLanguage: { label: "English", value: "en" }, });
  };
  handleSelectLanguageOnChange = async (selLang) => {
    try {
      this.props.openSpinnerRedux();
      const userSavedData = this.props.selectedLanguage.value;
      const prevLanguage = this.state.selectedLanguage;
      if (prevLanguage.value === selLang.value) {
        console.log("same language selected");
        this.props.closeSpinnerRedux();
        return
      }
      console.log("prev ", prevLanguage, "Sel ", selLang, "user ", userSavedData);
      if (userSavedData === selLang.value) {
        console.log("if ");
        const parsedMappingDiagrams = JSON.parse(this.props.bpmn_xml)
        this.setState({
          mappingDiagrams: parsedMappingDiagrams,
        });
        let importXMLResponse
        const getCurrDiagramXmlById = async (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {

            if (arr[i].id === parentId) {
              importXMLResponse = arr[i].diagramXML;
              return arr;
            }
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children, parentId);
          }
          return arr;
        }
        await getCurrDiagramXmlById(parsedMappingDiagrams, this.state.currentMapDet.id);
        this.updateXmlByImportXML(importXMLResponse);
        this.props.closeSpinnerRedux();
      } else {
        console.log("else");
        // const xmlResult = await this.getCurrentDiagramXML();
        // this.displayLanguageOnChange(xmlResult, prevLanguage, selLang);
        // **************************************************//

        let tempMappDiags = [...this.state.mappingDiagrams];
        const currentXML = await this.getCurrentDiagramXML();
        console.log("currentXML ", currentXML)

        try {

          // **************************************************//
          // this.displayLanguageOnChange(xmlResult, prevLanguage, selLang);
          await this.displayLanguageOnChange(tempMappDiags, prevLanguage, selLang);
        } catch (error) {
          console.error(error);
        }
      }
      this.setState({
        selectedLanguage: selLang,
      });
    } catch (error) {
      console.error(error);
      this.props.closeSpinnerRedux()
    }
  };
  displayLanguageOnChange = async (updatedArray, prevLanguage, selLang) => {
    console.log(prevLanguage, selLang, updatedArray);
    try {
      let tempMappDiags = [...this.state.mappingDiagrams];

      let importXMLResponse;
      const updateCurrDiagramXml = async (arr, parentId) => {
        for (let i = 0; i < arr.length; i++) {
          const currDiagXML = arr[i].diagramXML;
          if (currDiagXML !== "") {
            const response1 = await translateXmlNamesByLanguage(currDiagXML, prevLanguage.value, selLang.value);
            const response = response1.xmlResponse;
            console.log("translate response ", response);

            if (arr[i].id === parentId) {
              console.log("&&& parentId diag IMPORT XML ");
              importXMLResponse = await response;
            }
            arr[i].diagramXML = response;
            if (arr[i].children.length === 0) {
              continue;
            }
          }
          await updateCurrDiagramXml(arr[i].children, parentId);
        }
        return arr;
      }
      this.setMappingDiagramsArray("isDiagNavigationClicked", false)
      const updatedArray = await updateCurrDiagramXml(tempMappDiags, this.state.currentMapDet.id)
      console.log("##### after lang Convert", updatedArray);

      await this.refreshBpmn_OnClick();
      console.log("importXMLResponse ******* ", importXMLResponse);
      await this.updateXmlByImportXML(importXMLResponse);
      this.setState({
        mappingDiagrams: updatedArray
      })
      this.props.closeSpinnerRedux();
    } catch (error) {
      console.error(error);
      this.props.closeSpinnerRedux();
    }
  };


  downloadBPMN_OnClick = async () => {
    try {
      let xmlResult = cloneDeep(this.state.mappingDiagrams);
      const currentXML = await this.getCurrentDiagramXML();
      let exportResult;
      if (this.state.diagramLevel === "CurrentProcessMap") {
        exportResult = xmlResult[0]
      }
      if (this.state.diagramLevel === "CurrentAndLower" || this.state.diagramLevel === "CurrentLevel") {
        const updateCurrDiagramXml = (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              console.log(arr[i].diagramXML, currentXML);
              const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
              console.log("isBothXMLSame ", isBothXMLSame);
              if (!(isBothXMLSame)) {
                arr[i].diagramXML = currentXML;
              }
              if (this.state.diagramLevel === "CurrentLevel") {
                arr[i].children.map((child) => {
                  child.children = []
                  return child.diagramXML = "";
                  // return child
                })
              }
              exportResult = arr[i]
              return arr;
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              updateCurrDiagramXml(arr[i].children, parentId);
            }
          }
          return arr;
        }
        const updatedArray = updateCurrDiagramXml(xmlResult, this.state.currentMapDet.id)
        console.log("##### ", updatedArray);
      }
      console.log(exportResult)
      console.log(this.state.mappingDiagrams);
      const blob = new Blob([JSON.stringify(exportResult)], { type: "application/text" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", exportResult.meta.label + "-(" + this.state.diagramLevel + ") .txt");
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error("Error ,", error);
    }
    this.setState({
      diagramLevel: "CurrentProcessMap",
      isdownload: false
    })
  };

  downloadBpmnSVG_OnClick = async () => {
    try {
      const svgResult = await this.handleBpmnRef.current.bpmnModeler.saveSVG();
      const result = await svgResult.svg;

      const svgBlob = new Blob([result], { type: 'image/svg+xml;charset=utf-8' });
      const svgUrl = URL.createObjectURL(svgBlob);
      const downloadLink = document.createElement('a');
      downloadLink.href = svgUrl;
      downloadLink.download = `${this.props.diagramname}.svg`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      URL.revokeObjectURL(svgUrl);

    } catch (error) {
      console.error(" Error ", error);
    }
  };
  OnprintClick = async () => {
    try {
      const svgResult = await this.handleBpmnRef.current.bpmnModeler.saveSVG();
      const result = await svgResult.svg;

      // Create a hidden iframe
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);

      // Append the SVG content to the iframe document body
      const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

      // Set the page size to be the size of the SVG content
      const svgWrapper = document.createElement('div');
      svgWrapper.style.display = 'flex';
      svgWrapper.style.justifyContent = 'center';
      svgWrapper.style.alignItems = 'center';
      svgWrapper.style.height = '100vh'; // Ensure SVG fills the entire page
      svgWrapper.innerHTML = result;
      iframeDocument.body.appendChild(svgWrapper);

      // Add CSS for page styling
      const style = document.createElement('style');
      style.textContent = `
  @page {
    size: auto; /* Set page size to auto */
    margin: 0; /* Remove default margin */
  }
  body {
    margin: 0; /* Remove body margin */
  }
  `;
      iframeDocument.head.appendChild(style);

      // Print the SVG content
      iframe.contentWindow.print();

      // Remove the iframe after printing
      document.body.removeChild(iframe);

    }
    catch (error) {
      console.error(" Error ", error);
    }
  };
  updateXmlByImportXML = async (xmlString) => {
    try {
      console.log(xmlString);
      await this.handleBpmnRef.current.bpmnModeler.importXML(xmlString);
    } catch (error) {
      console.error(error);
      ErrorMessage(BPMN_Common_Tosters.Error_While_Updating_Diagram)
    }
  }
  getCurrentDiagramXML = async () => {
    const xmlResult = await this.handleBpmnRef.current.bpmnModeler.saveXML();
    const result = await xmlResult.xml;
    return result;
  };
  setMappingDiagramsArray = (stateName, updatedValue) => {
    switch (stateName) {
      case "currentMapDet":
        this.setState(prevState => ({
          prevCurrMapDet: prevState.currentMapDet,
          currentMapDet: updatedValue,
        }))
        break;
      case "isDiagNavigationClicked":
        this.setState({
          isDiagNavigationClicked: updatedValue
        })
        break;

      default:
        break;
    }
    console.log("setMappingDiagramsArray TRIGGEREDDDD", stateName, updatedValue);
  }
  treeViewToggle = () => {
    this.setState({
      isTreeView: !this.state.isTreeView
    })
  }
  onClickTreeViewItem = async (treeItem) => {
    console.log(treeItem)
    //let tempMappDiags = [...this.state.mappingDiagrams];
    const tempCurrMap = { ...this.state.currentMapDet };
    console.log(treeItem, tempCurrMap);
    if (treeItem.id === tempCurrMap.id) {
      console.log("Same Level");
      return
    }
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    //const currentXML = await this.getCurrentDiagramXML();
    const upadtedCurMap = {
      id: treeItem.id,
      name: treeItem.name,
      key: treeItem.key,
      meta: {
        collapsed: true,
        label: treeItem.meta.label
      },
      diagramXML: treeItem.diagramXML,
      parentId: tempCurrMap.id,
      children: [],

    }

    this.setState(prevState => ({
      //mappingDiagrams: updatedArray,
      prevCurrMapDet: prevState.currentMapDet,
      currentMapDet: upadtedCurMap,
    }))

    const xml = await getXmlDiagram("default");
    const diagramXML = treeItem.diagramXML === "" ? xml : treeItem.diagramXML
    console.log(diagramXML);
    this.updateXmlByImportXML(diagramXML)
  }
  onDiagramNavOnclick = async (navType) => {
    console.log("navv ", navType);
    let tempMappDiags = [...this.state.mappingDiagrams];
    const tempCurrMap = { ...this.state.currentMapDet };
    const tempPrevCurrMap = { ...this.state.prevCurrMapDet };
    console.log(tempMappDiags, tempCurrMap);

    const currentXML = await this.getCurrentDiagramXML();

    function updateCurrDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === parentId) {
          arr[i].diagramXML = currentXML;
          return arr;
        } else {
          if (arr[i].children.length === 0) {
            continue;
          }
          updateCurrDiagramXml(arr[i].children, parentId);
        }
      }
      return arr;
    }

    const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
    console.log("##### ", updatedArray);

    let upadtedCurMap = {}
    function getChildDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i].id === parentId, i);
        if (arr[i].id === parentId) {
          return arr[i];
        } else if (arr[i].children.length === 0) {
          continue;
        }
        else {
          const isObjFinded = getChildDiagramXml(arr[i].children, parentId);
          if (isObjFinded) {
            return isObjFinded
          }
        }
      }
      return "";
    }
    switch (navType) {
      case "HOME":
        if (tempCurrMap.id === tempMappDiags[0].id) {
          ErrorMessage(BPMN_Common_Tosters.Currently_At_The_Home_Level);
          return
        }

        upadtedCurMap = tempMappDiags[0]
        break;
      case "UP":
        let splittedId = tempCurrMap.id.split(".");
        splittedId.pop();
        let upParentId = splittedId.join(".");
        console.log("uppp ", upParentId);
        if (upParentId === "" || upParentId === undefined) {
          ErrorMessage(BPMN_Common_Tosters.The_Parent_Level_Does_Not_Exist)
          return
        }
        upadtedCurMap = getChildDiagramXml(tempMappDiags, upParentId)
        console.log("111 ", upadtedCurMap);
        break;
      case "PREV":
        console.log("PREVV ", tempPrevCurrMap);
        if (tempPrevCurrMap === undefined || tempPrevCurrMap.id === undefined) {
          ErrorMessage(BPMN_Common_Tosters.The_Previous_Diagram_Is_Not_Available);
          return
        }
        upadtedCurMap = getChildDiagramXml(tempMappDiags, tempPrevCurrMap.id)
        break;

      default:
        break;
    }
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    // upadtedCurMap.nodes = [];
    console.log(upadtedCurMap, updatedArray, this.state.prevCurrMapDet);

    const xml = await getXmlDiagram("default");
    const diagramXML = upadtedCurMap.diagramXML === "" ? xml : upadtedCurMap.diagramXML
    await this.updateXmlByImportXML(diagramXML)
    this.setState(prevState => ({
      mappingDiagrams: updatedArray,
      prevCurrMapDet: prevState.currentMapDet,
      currentMapDet: upadtedCurMap,
    }))
  }
  closeDialogPopupBox = () => {
    this.setState({
      isActivityFileDocEnable: false,
      showFlowlinoepopup: false,
      OnshowFlowlineActivity: false,
      showFlowlinoepopupTarget: false,
      isdownload: false,
      PrintLevel: false,
      diagramLevel: "CurrentProcessMap",
      isALMTestCaseViewEnable: false
    });

  };
  findElementById = (data, id) => {
    for (let i = 0; i < data.length; i++) {
      const element = data[i];
      if (element.id === id) {
        return element;
      }
      if (element.children && element.children.length > 0) {
        const foundInChildren = this.findElementById(element.children, id);
        if (foundInChildren) {
          return foundInChildren;
        }
      }
    }
    return null;
  }
  flowlinkIdFinder = (resultDiagrams, activityId) => {
    console.log(activityId);
    const importXMLResponse = resultDiagrams;
    if (importXMLResponse !== '') {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(importXMLResponse, 'text/xml');
      console.log(xmlDoc);
      const element = xmlDoc.querySelector(`[id="${activityId}"]`)
      console.log(element);
      if (element === undefined || element === null) {
        return false;
      }
      else {
        return true
      }
    }
  }
  verifyTargetId = (targetId, activityId) => {
    console.log(targetId, this.state.mappingDiagrams);
    const targetMap = this.findElementById(this.state.mappingDiagrams, targetId);
    console.log(targetMap);
    const isActivitypresent = this.flowlinkIdFinder(targetMap?.diagramXML, activityId)
    console.log(isActivitypresent);
    return isActivitypresent
  }

  handleFlowlineClick = async (id, item) => {
    const tempCurrMap = { ...this.state.currentMapDet };
    const currentXML = await this.getCurrentDiagramXML();
    function updateCurrDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === parentId) {
          arr[i].diagramXML = currentXML;
          return arr;
        } else {
          if (arr[i].children.length === 0) {
            continue;
          }
          updateCurrDiagramXml(arr[i].children, parentId);
        }
      }
      return arr;
    }
    let tempMappDiags = [...this.state.mappingDiagrams];
    const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
    console.log("##### ", updatedArray)
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)

    let diagramXMLTemp;
    function getChildDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i].id === parentId, arr[i]);
        if (arr[i].id === parentId) {
          diagramXMLTemp = arr[i]
          return arr[i];
        } else if (arr[i].children.length === 0) {
          continue;
        }
        else {
          getChildDiagramXml(arr[i].children, parentId);

        }
      }
      return "";
    }
    console.log(id);
    getChildDiagramXml([...tempMappDiags], id);

    console.log(diagramXMLTemp);
    console.log(tempMappDiags);
    console.log(diagramXMLTemp);
    await this.updateXmlByImportXML(diagramXMLTemp.diagramXML)

    this.setState(prevState => ({
      showFlowlinoepopup: false,
      currentMapDet: { ...diagramXMLTemp },
      mappingDiagrams: updatedArray,
      prevCurrMapDet: prevState.currentMapDet,
      showFlowlinoepopupTarget: false
    }))
    let selectionService = await this.handleBpmnRef.current.bpmnModeler.get("selection");
    const parentActivityId = this.handleBpmnRef.current.bpmnModeler.get('canvas')._elementRegistry.get(item.targetActivityId)
    const targetActivityId = this.handleBpmnRef.current.bpmnModeler.get('canvas')._elementRegistry.get(item.parentActivityId)
    if (parentActivityId !== undefined) {
      selectionService.select(parentActivityId);
      return;
    }
    else {
      selectionService.select(targetActivityId);
      return;
    }

  }
  popupFlowlineActAvailable = (e) => {
    console.log("im clicked");
    this.setState({
      showFlowlinoepopup: true,
      editElementObj: e
    })
  }
  downloadDocSharePointAPICALL = async (type, file) => {
    try {
      if (type === 'PREVIEW') {
        const extension = file.fileName.split('.').pop().toLowerCase();
        console.log("preview", extension);
        const nonPreviewableFormats = ['zip', 'rar', 'tar', 'gz', 'xls', 'xlsx', 'doc', 'docx', 'ppt', 'pptx'];
        if (nonPreviewableFormats.includes(extension)) {
          ErrorMessage(BPMN_Common_Tosters.The_File_Type_Preview_Msg_Start + extension + BPMN_Common_Tosters.The_File_Type_Preview_Msg_End)
          return
        }
      }
      this.props.openSpinnerRedux()
      const response = await BPMNService.getActivityUploadedDocuments(file.fileName, file.documentId);
      console.log(response);
      if (type === "DOWNLOAD") {

        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', file.fileName);
        document.body.appendChild(link);
        link.click();

        link.parentNode.removeChild(link);
        window.URL.revokeObjectURL(url);

      } else if (type === "PREVIEW") {

        const mimeType = getMimeTypeByFileName(file.fileName);
        console.log("preview", mimeType);
        const blob = new Blob([response.data], { type: mimeType });
        const resURL = URL.createObjectURL(blob);

        if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
          window.open(resURL, '_blank');
        }
        // For Excel (.xlsx) files
        else if (mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
          window.open(resURL, '_blank');
        }
        // For other file types, just open the URL in a new tab
        else {
          const customUrl = `${resURL}#toolbar=0&navpanes=0&scrollbar=0&filename=${encodeURIComponent(file.fileName)}`;
          window.open(customUrl, '_blank');
        }

        this.props.closeSpinnerRedux();
      }
      this.props.closeSpinnerRedux()
    } catch (error) {
      console.error(error);
      this.props.closeSpinnerRedux()
      ErrorMessage(error?.response?.status === 404 ? 'File not found !' : error?.response?.status === 500 ? 'Document not found' :JSON.stringify(error?.response?.data));
    }

  };
  targetFlowline = (e) => {
    this.setState({
      showFlowlinoepopupTarget: true,
      editElementObj: e,
    })
  }
  onClickshowDiagram = async () => {
    if (this.state.treelineFlag) {
      if (this.state.flowLineflag && this.state.selectedIdFlowLine !== null) {
        this.closeDialogPopupBox()
        return
      }
      else {
        const findElementById = (data, id) => {
          for (let i = 0; i < data.length; i++) {
            const element = data[i];
            if (element.id === id) {
              return element;
            }
            if (element.children && element.children.length > 0) {
              const foundInChildren = findElementById(element.children, id);
              if (foundInChildren) {
                return foundInChildren;
              }
            }
          }
          return null;
        };

        const updateElement = (data, updatedElement) => {
          return data.map(item => {
            if (item.id === updatedElement.id) {
              return updatedElement;
            } else if (item.children && item.children.length > 0) {
              return {
                ...item,
                children: updateElement(item.children, updatedElement)
              };
            }
            return item;
          });
        };

        const fetchData = () => {
          console.log("fetchdata is running");
          const currentId = this.state.currentMapDet?.id;
          const mappingDiagrams = [...this.state.mappingDiagrams];
          console.log(mappingDiagrams);
          const foundElement = findElementById(mappingDiagrams, currentId);
          console.log("found element", foundElement);
          if (foundElement.flowlineMap && foundElement.flowlineMap.length > 0) {
            console.log("im inside the flowline length greater than 0");
            const foundElementExists = foundElement.flowlineMap.find(el => el.id === this.state.selectedIdFlowLine);
            if (!foundElementExists) {
              foundElement.flowlineMap.push(this.state.newDataFromConsole);
              const updatedMappingDiagrams = updateElement(this.state.mappingDiagrams, foundElement);
              console.log(updatedMappingDiagrams);
              this.setState({ mappingDiagrams: updatedMappingDiagrams });
              this.closeDialogPopupBox()
              this.addFlowLineActivity()
              this.setState({
                treelineFlag: false
              })
            } else {
              ErrorMessage(BPMN_Common_Tosters.This_Flow_Line_Already_Has_A_Link_To_The_Selected_Destination_Flow_Line);
              return;
            }
          } else {
            console.log("im inside the flowline length lesser than or equal to 0");
            foundElement.flowlineMap = [this.state.newDataFromConsole];
            const updatedMappingDiagrams = updateElement(this.state.mappingDiagrams, foundElement);
            this.setState({ mappingDiagrams: updatedMappingDiagrams });
            this.closeDialogPopupBox()
            this.addFlowLineActivity()
            this.setState({
              treelineFlag: false
            })
          }
        };
        if (!this.state.flowLineflag) {
          fetchData()
          this.setState({
            selectedIdFlowLine: '',
            flowLineflag: false,
            treelineFlag: false

          });
        }
      }
    }
    else {
      ErrorMessage(BPMN_Common_Tosters.Please_Select_Any_Destination_Flow_Line);
      return;
    }
  }
  onShowActivityBox = async () => {
    const elementid = document.getElementById("bio-properties-panel-id")?.value;
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const sourceAutoNum = bpmnCanvas._elementRegistry.get(elementid)

    console.log(sourceAutoNum.businessObject.$attrs.AutoNumCount);
    if (this.state.treelineFlag && this.state.selectedIdFlowLine) {
      this.setState({
        showActivityBoxMapping: true,
        flowLinePopup: false,
        sourceAutoNum: sourceAutoNum.businessObject.$attrs.AutoNumCount
      })
    }
    else {
      ErrorMessage(BPMN_Common_Tosters.Please_Select_Any_Flowline_And_Proceed_Further)
      return
    }
  }
  onBackActivityBox = () => {
    this.setState({
      showActivityBoxMapping: false,
      flowLinePopup: true
    })
  }
  previousforDiagrampop = () => {
    this.setState({
      onshowdiagram: false,
      flowLinePopup: true
    })
  }
  onChangeRadioButton = (e) => {
    this.setState({ diagramLevel: e.target.id });
  }
  onClickBpmnDownload = () => {
    this.setState({
      isdownload: true
    })
  }
  onPrintClick = async () => {
    try {
      let xmlResult = cloneDeep(this.state.mappingDiagrams);
      let exportResult = []
      if (this.state.diagramLevel === "CurrentProcessMap") {
        const getCurrDiagramXmlById = async (arr) => {
          console.log(arr)
          for (let i = 0; i < arr.length; i++) {
            console.log(arr[i])
            const importXMLResponse = arr[i];
            // await this.updateXmlByImportXML(importXMLResponse);
            this.setState({
              diagramXml: importXMLResponse
            })
            exportResult.push(importXMLResponse)
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children);
          }
          return arr;
        }
        await getCurrDiagramXmlById(xmlResult)
        console.log(exportResult)
        return exportResult
      }
      if (this.state.diagramLevel === "CurrentAndLower" || this.state.diagramLevel === "CurrentLevel") {
        const updateCurrDiagramXml = async (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              if (this.state.diagramLevel === "CurrentLevel") {
                return exportResult.push(arr[i])
              }
              const getCurrDiagramXmlById = async (arr) => {
                console.log(arr)
                for (let i = 0; i < arr.length; i++) {
                  console.log(arr[i])
                  const importXMLResponse = arr[i];
                  // await this.updateXmlByImportXML(importXMLResponse);
                  exportResult.push(importXMLResponse)
                  if (arr[i].children.length === 0) {
                    continue;
                  }
                  await getCurrDiagramXmlById(arr[i].children);
                }

              }
              await getCurrDiagramXmlById([arr[i]])
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              await updateCurrDiagramXml(arr[i].children, parentId);
            }
          }
          return arr;
        }
        const updatedArray = await updateCurrDiagramXml(xmlResult, this.state.currentMapDet.id)
        console.log("updatedArray ", updatedArray)
        console.log(exportResult)
        return exportResult
      }
    } catch (error) {
      console.error("Error ,", error);
    }
  };

  handlePrint = async () => {
    this.props.openSpinnerRedux()
    const bpmnXml = await this.onPrintClick(); // Fetch your XMLs here
    this.setState(
      {
        bpmnXMLs: bpmnXml,
        renderedDiagrams: [],
        isRendering: true,
        PrintLevel: false,
        printTriggered: false,
      },
      () => this.renderDiagramsInChunks(bpmnXml, 0)
    );
  };

  renderDiagramsInChunks = (xmlList, startIndex) => {
    const chunkSize = 10; // Adjust chunk size as needed

    if (startIndex >= xmlList.length) {
      this.setState({ isRendering: false }); // Mark rendering as complete
      return;
    }

    const nextChunk = xmlList.slice(startIndex, startIndex + chunkSize).map((xml, index) => (
      <div key={startIndex + index} className="print-page">
        <ShowDiagramPrint
          templateBgColor={this.props.templateBgColor}
          isDefaultTemplateEnable={this.props.isDefaultTemplateEnable}
          currentMapDet={this.state.currentMapDet}
          // CheckElements={this.props.CheckElements}
          diagramXML={xml}
          selectedMapData={this.props.selectedMapData}
          appliedTemplate={this.props.appliedTemplate}
          fromViewer={true}
        />
      </div>
    ));

    this.setState((prevState) => ({
      renderedDiagrams: [...prevState.renderedDiagrams, ...nextChunk],
    }));

    // Schedule the next chunk to render
    setTimeout(() => {
      requestIdleCallback(() => this.renderDiagramsInChunks(xmlList, startIndex + chunkSize));
    }, 1000);

  };
  componentDidUpdate(prevProps, prevState) {
    if (!this.state.isRendering && this.state.bpmnXMLs.length > 0 && this.printRef.current && !this.state.printTriggered) {
      this.setState({ printTriggered: true }, () => {
        this.printRef.current.handlePrint();
      });
    }
  }

  handleAfterPrint = async () => {
    this.setState({
      bpmnXMLs: [],
      renderedDiagrams: [],
    });
    this.props.closeSpinnerRedux()
  };
  onPrintDiagram = () => {
    this.setState({
      PrintLevel: true
    })
  }
  onALMReqOrTestSelectOnClick = async (almType) => {
    try {
      const almData = this.state.almData;
      const selALMData = almData.find(alm => almType === "TESTCASE" ? (alm.type === 'test-folder' || alm.type === "test") : alm.type === "requirement")
      console.log(" almType: ", almType, almData, selALMData);
      this.props.openSpinnerRedux()
      // const almData = this.state.almData;
      const finalResultArray = await getALMConnectedTests(selALMData.almConnectId);
      this.setState({
        almMappedTestcases: finalResultArray,
        isALMTestCaseViewEnable: true,
        AlmDataSource: selALMData,
        isReqOrTestcaseEnable: false,
      })
      this.props.closeSpinnerRedux();
    } catch (error) {
      this.props.closeSpinnerRedux();
      console.error(error);
    }
  }
  render() {
    return (
      <div>
        <div class="bg-[#ebeef6]" id="dottedBgEditor">
          <div className="border-2px border-solid w-full h-4/5">
            <div className="flex justify-center resize-app-container">
              {this.state.isTreeView ?
                <ResizeCompIndex
                  mappingDiagrams={this.state.mappingDiagrams}
                  onClickTreeViewItem={this.onClickTreeViewItem}
                  selectedNodeId={this.state.currentMapDet.id}
                  treeViewToggle={this.treeViewToggle}
                  fromViewer={true}
                  Role={window.localStorage.getItem("userRole")}
                  mapDiagramName={this.props.diagramname}
                // onEditClick ={this.onEditClick}
                />
                :
                <div onClick={this.treeViewToggle} className="relative flex items-center bg-orange-400 mt-5 mb-5 p-1 border-b-2 rounded-r-lg h-[30px] cursor-pointer">
                  <span className=""> <IoChevronForward size={24} color="white" /></span>
                </div>
              }
              <div className="bg-transparent resize-app-frame w-full">
                <div className="rounded-md font-[12px]">
                  <div>
                    <div className="animate-dropdown"></div>
                    <ViewBpmnToolHeader
                      zoomInOutBpmn_OnClick={this.zoomInOutBpmn_OnClick}
                      selectedLanguage={this.state.selectedLanguage}
                      handleSelectLanguageOnChange={this.handleSelectLanguageOnChange}
                      CancelShowDiagram={this.props.CancelShowDiagram}
                      diagramname={this.props.diagramname}
                      downloadBPMN_OnClick={this.onClickBpmnDownload}
                      downloadBpmnSVG_OnClick={this.downloadBpmnSVG_OnClick}
                      OnprintClick={this.OnprintClick}
                      onDiagramNavOnclick={this.onDiagramNavOnclick}
                      isDefaultTemplateEnable={this.props.isDefaultTemplateEnable}
                      onPrintDiagram={this.onPrintDiagram}
                      handleAfterPrint={this.handleAfterPrint}
                    />
                    <ShowDiagram
                      diagramXML={this.state.diagramXML}
                      url={diagramXML}
                      handleBpmnRef={this.handleBpmnRef}
                      CheckElements={this.props.CheckElements}
                      getCurrentDiagramXML={this.getCurrentDiagramXML}
                      mappingDiagrams={this.state.mappingDiagrams}
                      currentMapDet={this.state.currentMapDet}
                      updateXmlByImportXML={this.updateXmlByImportXML}
                      setMappingDiagramsArray={this.setMappingDiagramsArray}
                      popupFlowlineActAvailable={this.popupFlowlineActAvailable}
                      handleElementDblClickByTool={this.handleElementDblClickByTool}
                      targetFlowline={this.targetFlowline}
                      onDiagramNavOnclick={this.onDiagramNavOnclick}
                      templateBgColor={this.props.templateBgColor}
                      isDefaultTemplateEnable={this.props.isDefaultTemplateEnable}
                      diagramname={this.props.diagramname}
                      selectedMapData={this.props.selectedMapData}
                      appliedTemplate={this.props.appliedTemplate}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {this.state.showFlowlinoepopup ? (
          <OnshowFlowlineActivity
            flowLineStructure={this.state.flowLineStructure}
            currentMapDet={this.state.currentMapDet}
            mappingDiagrams={this.state.mappingDiagrams}
            closeDialogPopupBox={this.closeDialogPopupBox}
            handleFlowlineClick={this.handleFlowlineClick}
            handleDeleteFlowActivity={this.handleDeleteFlowActivity}
            fromViewer={true}
            editElementObj={this.state.editElementObj}
            findElementById={this.findElementById}
            verifyTargetId={this.verifyTargetId}

          />
        ) : null}
        {this.state.isActivityFileDocEnable ? (
          <ActivityFileDocuments
            closeDialogPopupBox={this.closeDialogPopupBox}
            selActivityId={this.state.selActivityId}
            selActivityDocFiles={this.state.selActivityDocFiles}
            downloadDocSharePointAPICALL={this.downloadDocSharePointAPICALL}
            fromViewer={true}
          // deleteDocSharePointAPICALL={this.deleteDocSharePointAPICALL}
          />
        ) : null}
        {this.state.showFlowlinoepopupTarget ? (
          <div>
            <AddFlowLineTargetPopup
              closeDialogPopupBox={this.closeDialogPopupBox}
              onClickshowDiagram={this.onClickshowDiagram}
              mappingDiagrams={this.state.mappingDiagrams}
              currentMapDet={this.state.currentMapDet}
              selectedIdFlowLine={this.state.selectedIdFlowLine}
              onClickTreeFlowLine={this.onClickTreeFlowLine}
              onShowActivityBox={this.onShowActivityBox}
              editElementObj={this.state.editElementObj}
              handleFlowlineClick={this.handleFlowlineClick}
              findElementById={this.findElementById}
              verifyTargetId={this.verifyTargetId}
            />
          </div>
        ) : null}
        {this.state.isALMTestCaseViewEnable ? (
          <ALMTestCase
            openSpinnerRedux={this.props.openSpinnerRedux}
            closeSpinnerRedux={this.props.closeSpinnerRedux}
            closeDialogPopupBox={this.closeDialogPopupBox}
            almMappedTestcases={this.state.almMappedTestcases}
            AlmDataSource={this.state.AlmDataSource}
            isMapLocked={true}
            selActivityName={this.state.selActivityName}
          />
        ) : null}
        {
          (this.state.isdownload || this.state.PrintLevel) ?
            <DownloadDiagramPOPUP
              onChangeRadioButton={this.onChangeRadioButton}
              closeDialogPopupBox={this.closeDialogPopupBox}
              downloadBPMN_OnClick={this.downloadBPMN_OnClick}
              isPrint={this.state.PrintLevel}
              handlePrint={this.handlePrint}
            />
            : null
        }
         {this.state.isReqOrTestcaseEnable ?
                <ALMReqTestCaseChoose
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  onALMReqOrTestSelectOnClick={this.onALMReqOrTestSelectOnClick}
                />
                : null}

        <ReactToPrint
          trigger={() => <></>}
          content={() => this.diagramListRef.current}
          onAfterPrint={() => {
            this.handleAfterPrint()
            this.props.closeSpinnerRedux();
          }
          }
          ref={this.printRef}
        />

        <div className="hidden-print" ref={this.diagramListRef}>
          {this.state.renderedDiagrams}
        </div>
      </div>
    )
  }
}

export default ShowDiagramParent

const ViewBpmnToolHeader = (props) => {
  return (
    <div>
      <div class="flex justify-between items-center shadow-sm px-5 py-4 border-b border-black border-opacity-25">
        <div className='flex items-center pl-'>
          {!props.isDefaultTemplateEnable ?
            <>
              <div
                onClick={() => props.onDiagramNavOnclick("HOME")}
                title={BPMN_Common_Labels._HOME_ICON_TOOLTIP}
                class="bg-gray-100 md:mx-1 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
              >
                <FcHome size={22} color="black" />
              </div>
              <div
                onClick={() => props.onDiagramNavOnclick("UP")}
                title={BPMN_Common_Labels._UP_ICON_TOOLTIP}
                class="bg-gray-100 md:mx-1 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
              >
                <svg
                  className="up_icon"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 48 48"
                >
                  <g fill="#F44336">
                    <path d="M46.1 24L33 35V13zM10 20h4v8h-4zm-6 0h4v8H4zm12 0h4v8h-4z" />
                    <path d="M22 20h14v8H22z" />
                  </g>
                </svg>
              </div>
              <div
                onClick={() => props.onDiagramNavOnclick("PREV")}
                title={BPMN_Common_Labels._PREVIOUS_ICON_TOOLTIP}
                class="bg-gray-100 md:mr-2 md:ml-1 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48"><g fill="#F44336"><path d="m4 24l14-11.7v23.4z" /><path d="M15 20h27v8H15z" /></g></svg>
              </div>
            </>
            : null}
          <div onClick={props.CancelShowDiagram} className='flex items-center'>
            <span><BsArrow90DegUp size={15} color="#8d8e94" /></span>
            <span className="text-1xl text-gray-500 cursor-pointer" >{BPMNViewer_Labels._BACK_TO_VIEWER}</span>
          </div>
          <div className='flex items-center'>
            <span className="mx-1"><IoIosArrowForward color="#8d8e94" /></span>
            <span className="w-[380px] text-blue-600" title={props.diagramname}>{props.diagramname}</span>
          </div>

        </div>

        <div class="flex items-center container">
          <div class="flex justify-between items-center">
            <span class="font-bold text-indigo-600 text-xl"></span>
            <button class="border-gray-600 md:hidden opacity-50 hover:opacity-75 px-3 py-1 border border-solid rounded text-gray-600" id="navbar-toggle">
              <i class="fa-bars fas"></i>
            </button>
          </div>
          <div class="md:flex md:flex-row flex-col items-center hidden mt-3 md:mt-0 md:ml-auto" id="navbar-collapse">
            <div>
              <Select
                styles={ReactSelect.dropDownStylesOrange}
                class="block border-grey-light mb-2 p-3 border w-full h-10"
                name='selected_datasource'
                components={{
                  DropdownIndicator,
                  IndicatorSeparator: () => null,
                }}
                id='selected_datasource'
                placeholder={BPMN_Common_Labels._LANGUAGE_PLACEHOLDER}
                options={allLanguages}
                onChange={props.handleSelectLanguageOnChange}
                value={props.selectedLanguage}
              />
            </div>
            {/* hiding this download option for viewer as per defect id 267 */}
            {/* <div
              title={BPMN_Common_Labels._DOWNLOAD_ICON_TOOLTIP}
              class="relative hover:bg-gray-200 md:mx-2 lg:px-4 p-1 pl-2 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
              onClick={props.downloadBPMN_OnClick}
            >
              <BsCloudDownload size={22} color="#0000FF" />
            </div> */}
            <div
              title={BPMN_Common_Labels._PRINT_ICON_TOOLTIP}
              class="hover:bg-gray-200 md:mx-1 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
              onClick={props.onPrintDiagram}
            >
              <IoPrintOutline size={28} color="#0000FF" />
            </div>
            <div title={BPMN_Common_Labels._ZOOM_IN_ICON_TOOLTIP} class="hover:bg-gray-200 md:mx-2 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer" onClick={() => props.zoomInOutBpmn_OnClick("in")}><FiZoomIn size={22} color="#0000FF" /></div>
            <div title={BPMN_Common_Labels._ZOOM_OUT_ICON_TOOLTIP} class="hover:bg-gray-200 md:mx-2 lg:px-4 p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer" onClick={() => props.zoomInOutBpmn_OnClick("out")}><FiZoomOut size={22} color="#0000FF" /></div>
          </div>
        </div>
      </div>
    </div>
  )
}