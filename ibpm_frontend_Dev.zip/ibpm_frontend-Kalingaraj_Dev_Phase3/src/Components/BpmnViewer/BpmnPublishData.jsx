import React from "react";
import { useParams } from "react-router-dom";
import BpmnPublish from "./BpmnPublish";
function BpmnPublishData() {
  // We can use the `useParams` hook here to access
  // the dynamic pieces of the URL.
  let { id } = useParams();
  return (
    <div>
      <BpmnPublish
        diagramname={id}
      />
    </div>
  );
}
export default BpmnPublishData