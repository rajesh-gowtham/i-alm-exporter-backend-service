import React from "react";
import { BiCopy } from 'react-icons/bi';
import { HiOutlineSearch } from 'react-icons/hi';
import { IoTrashOutline } from 'react-icons/io5';
import { ReactDialogBox } from 'react-js-dialog-box';
import { connect } from "react-redux";
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { BPMNViewer_Labels, BPMN_Common_Labels } from "../../Constants/COMMON_LABELS";
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { Auth_Common_Toaster, BPMNViewer_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS";
import BPMNService from "../../Services/BPMNService";
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import ALMTestCase from "./ALMTestCase";
import ShowDiagramParent from "./ShowDiagramParent";
//SCREEN ID -3000
const localControlsConstant = ControlsConstants;
class BpmnViewer extends React.Component {
    constructor(props) {
        super();
        this.state = {
            // templateBgColor: localStorage.getItem(userid + "color"),
            viewDiagram: false,
            isPopupshow: false,
            isPublish: false,
            isPublishOkey: false,
            datasourcetype: '',
            AlmnTestCase: {},
            documentpath: '',
            bpmn_xml: '',
            diagramname: '',
            taskJSON: '',
            deleteId: null,
            isdelete: false,
            diagramName: "",
            Role: window.localStorage.getItem("userRole"),
            columnDefs: [
                {
                    field: "project", headerName: "Project Name", sortable: true, flex: 1, suppressMovable: true,
                    cellRenderer: (params) => {
                        const project = params.data.project;
                        const projectName = project ? project : '';
                        return (
                            <span
                                className='text-orange-500'
                            >
                                {projectName}
                            </span>
                        );
                    }
                },
                {
                    field: 'diagramName', headerName: 'Map Name', sortable: true, suppressMovable: true, flex: 1,
                    cellRenderer: (params) => {
                        return <span onClick={() => this.onMapRowActionClick(params, "VIEW_MAP")} className='text-blue-600 underline-offset-2 hover:underline cursor-pointer decoration-[1.5px] decoration-blue-400 decoration-solid'>{params.data.diagramName} <span className="text-black text-sm">{"(v." + params.data?.diagramVersion + ")"}</span> </span>
                    }
                },
                { field: 'author', headerName: 'Author', sortable: true, suppressMovable: true, flex: 1 },
                {
                    field: 'publishedBy', sortable: true, suppressMovable: true, flex: 1, headerName: 'Published By',
                    cellRenderer: (params) => {
                        return <span >{params.data.publishedBy}</span>
                    }
                },
                {
                    field: 'bpmn_xml', headerName: "Action", suppressMovable: true, flex: 1,
                    cellRenderer: (params) => {
                        return <div class='flex items-center space-x-4 w-full h-full'>
                            <div class='flex items-center space-x-4 w-full h-full'>
                                <div className='flex items-center h-full text-blue-500 text-xs hover:text-blue-800 cursor-pointer'>
                                    <span className='mr-2 font-semibold underline' onClick={() => this.onMapRowActionClick(params, "VIEW_MAP")}>View map </span>
                                </div>
                                {
                                    localStorage.getItem("userRole") === "Admin" ?
                                        <div className='flex items-center space-x-2 cursor-pointer' onClick={() => this.onMapRowActionClick(params, "DELETE")}>
                                            <IoTrashOutline color='red' />
                                        </div>
                                        : null
                                }
                            </div>
                        </div>
                    }
                }],
            rowData: [],
            filterValue: '',
            appliedTemplate: {},
        }
        this.gridApi = null;
        this.gridColumnApi = null;
    }
    CheckElements = () => {
        // console.log(document.querySelector('.djs-element.selected').querySelector('tspan').textContent);
        // console.log(document.querySelector('djs-element.djs-shape.selected'));
        // console.log(document.querySelector('djs-element.djs-shape.selected.hover'));
        console.log(document.getElementById("bio-properties-panel-id"));
        return
        let elementid = document.getElementById("bio-properties-panel-id")?.value;
        console.log(elementid);
        this.GetAlmTestCase();
        const isFound = this.state?.taskJSON?.some(element => {
            return element.taskid === elementid;
        });

        if (isFound) {
            const taskdatasource = this.state.taskJSON?.filter((auto) => auto.taskid.includes(elementid));
            console.log("***** ", taskdatasource[0]);
            if (taskdatasource[0].datasourcenametype === "Data Source")
                this.GetAlmTestCase(taskdatasource[0]);
            else if (taskdatasource[0].datasourcenametype === "Navigation")
                console.log(" Navigation")
            else if (taskdatasource[0].datasourcenametype === "Document")
                this.setState({
                    documentpath: taskdatasource[0].documentpath,
                    isPopupshow: true
                })

            this.setState({
                datasourcetype: taskdatasource[0].datasourcenametype,
            })

        } else {
        }
    }

    closePopup = () => {
        this.setState({
            isPopupshow: false
        })
    }

    GetAlmTestCase = async (datasorce) => {
        console.log("GetAlmTest ", (datasorce))

        const setIsLoading = (() => this.setState({ isLoading: true }))
        setIsLoading();
        try {
            const response = await BPMNService.GetMappingField(datasorce);
            const resData = await response.data;
            console.log("Response ", resData)
            let totalRecords = {};
            resData.forEach((item) => {
                const itemKey = Object.keys(item).at(0);
                totalRecords[itemKey] = item[itemKey].entities;
            })
            this.setState({
                AlmnTestCase: totalRecords,
                AlmDataSource: datasorce,
                isPopupshow: true,
                isLoading: false,
                datasourcetype: 'Data Source',
            })
        }
        catch (err) {
            console.error(" Error ", err);
            this.setState({ isLoading: false })
        }
    }
    componentDidMount() {
        try {
            this.getAllPublishedMaps();
        } catch (error) {
            console.error(error);
        }
    }

    setColumnDefsByRole = () => {
        const newColmn = {
            field: "Action", headerName: "Action", suppressMovable: true, flex: 1,
            cellRendererFramework: (params) =>
                <div class='flex items-center space-x-4 w-full h-full'>
                    <div class='flex items-center space-x-4 w-full h-full'>
                        <div className='flex items-center space-x-2 cursor-pointer' onClick={() => this.OnDeleteClick(params)}>
                            <IoTrashOutline color='red' />
                        </div>

                    </div>
                </div>
        }
        const UpdatedColumn = [
            // {
            //     width: 140, headerName: 'SL No',
            //     cellRenderer: (params, ind) => {
            //         return (<div className='flex items-center h-full text-xs cursor-pointer'> {params.rowIndex + 1} </div>)
            //     }
            // },
            {
                field: "project", headerName: "Project Name", sortable: true, flex: 1, suppressMovable: true,
                cellRenderer: (params) => {
                    const project = params.data.project;
                    const projectName = project ? project.projectName : '';
                    return (
                        <span
                            // onClick={() => openAddEditDeleteImportMap("VIEW_EDIT_MAP", params)}
                            className='text-orange-500'
                        >
                            {projectName}
                        </span>
                    );
                }
            },
            {
                field: 'diagramName', headerName: 'Map Name', sortable: true, suppressMovable: true, flex: 1,
                cellRenderer: (params) => {
                    return <span onClick={() => this.cellClickedListener(params)} className='text-blue-600 underline-offset-2 hover:underline cursor-pointer decoration-[1.5px] decoration-blue-400 decoration-solid'>{params.value} <span className="text-black text-sm">{"(v." + params.data.diagramXmlIds.Master.version + ")"}</span> </span>
                }
            },
            {
                field: 'publishedBy', sortable: true, suppressMovable: true, flex: 1, headerName: 'Published By',
                cellRenderer: (params) => {
                    return <span >{params.data.diagramXmlIds.Master.publishedBy}</span>
                }
            },
            {
                field: 'bpmn_xml', flex: 1, suppressMovable: true, headerName: 'View',
                cellRenderer: (params) => {
                    return (<div className='flex items-center h-full text-blue-500 text-xs hover:text-blue-800 cursor-pointer'> <span className='mr-2 font-semibold underline' onClick={() => this.cellClickedListener(params)}>View map </span> </div>)
                }
            }]
        if (this.state.Role === "Admin") {
            UpdatedColumn.push(newColmn)
            this.setState({
                columnDefs: UpdatedColumn
            })
        } else {
            this.setState({
                columnDefs: UpdatedColumn
            })
        }
    }

    getAllPublishedMaps = async () => {
        try {
            this.openSpinnerRedux();
            const response = await BPMNService.getBPMNServicedata();
            // const response = await BPMNService.getAllPublishedDiagramsAPICALL();
            console.log(response);
            const data = await response.data;
            this.setState({
                rowData: data
            })
            this.closeSpinnerRedux();
        } catch (error) {
            console.error(error);
            this.closeSpinnerRedux();
            ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
        }
    }

    cellOkeyPublishDiagram = () => {
        this.setState({
            isPublishOkey: true,
        })
        let BpmnPublishdata = {
            diagramname: this.state.diagramname,
            // bpmn_xml: window.location.protocol + '//' + window.location.hostname + ":8226/bpmnPublish/" + this.state.diagramname
            bpmn_xml: `${window.origin}/bpmnPublish/${this.state.diagramname}`
        }
        BPMNService.SaveBPMNPublishdata(BpmnPublishdata).then(
            response => {
                console.log(JSON.stringify(response.data))
                if (response.status === 409) {
                    ErrorMessage(BPMNViewer_Toaster.Map_Name_Already_Exist)
                } else if (response.status === 200 || response.status === 201) {
                    SuccessMessage(BPMNViewer_Toaster.Url_Published_Successfully)
                }
            }).catch((e) => {
                console.log(e?.response);
                if (e?.response?.status === 409) {
                    ErrorMessage(BPMNViewer_Toaster.Url_Already_Published_With_The_Map_Name);
                } else {
                    ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong);
                }
            })
    }
    cellCancelPublishDiagram = () => {
        this.setState({
            isPublish: false,
            isPublishOkey: false,
        })
    }
    cellClickedPublishDiagram = (index) => {
        this.setState({
            isPublish: true,
            diagramname: index.data.diagramname,
        })
    }
    onMapRowActionClick = async (params, actionType) => {
        console.log(actionType, params);
        if (actionType === "VIEW_MAP") {

            console.log(" bpmnXml ", params.data)
            const response = await BPMNService.getSavedXmlAPICALL(params.data.taskConnectionId);
            console.log("response:", response.data.bpmnXml)
            const data = await { ...params.data };
            console.log(data);
            let applyTemplate;
            let tempBgColor;
            let isDefaultTemplateEnable;
            if (params.data.template === null || params.data.template === undefined || params.data.template === '') {
                isDefaultTemplateEnable = false
            } else {
                const templateResponse = await BPMNService.getTemplateById(params.data.template)
                console.log(templateResponse);
                const templateData = await templateResponse.data;
                console.log(templateData);
                applyTemplate = templateData
                isDefaultTemplateEnable = true
            }
            console.log(tempBgColor, isDefaultTemplateEnable);
            this.setState({
                // bpmn_xml: params.data.bpmnXml,
                bpmn_xml: response?.data?.bpmnXml,
                viewDiagram: true,
                diagramname: data.diagramName,
                //  taskJSON: JSON.parse(data.taskJSON),
                diagramXmlId: data.diagramXmlId,
                selectedLanguage: { label: data.languageName, value: data.languageCode },
                selectedMapData: { author: params?.data?.author, status: "Published" },
                templateBgColor: tempBgColor,
                isDefaultTemplateEnable: isDefaultTemplateEnable,
                appliedTemplate: applyTemplate,

            })
        } else {
            this.setState({
                isdelete: true,
                // deleteId: params.data.taskConnectionId,
                deleteId: params.data.mapId,
                diagramName: params.data.diagramname ? params.data.diagramname : params.data.diagramName
            })

        }
    }
    CancelShowDiagram = () => {
        this.setState({
            bpmn_xml: '',
            viewDiagram: false,
            diagramname: '',
            taskJSON: '',
        })
    }


    // ********************************************
    async copyTextToClipboard(text) {
        if ('clipboard' in navigator) {
            return await navigator.clipboard.writeText(text);
        } else {
            return document.execCommand('copy', true, text);
        }
    }

    // onClick handler function for the copy button
    handleCopyClick = () => {
        // Asynchronously call copyTextToClipboard
        // let urlValue = window.location.protocol + '//' + window.location.hostname + ":8286/bpmnPublish/" + this.state.diagramname;
        const urlValue = `${window.origin}/bpmnPublish/${this.state.diagramname}`;
        this.copyTextToClipboard(urlValue)
            .then(() => {
                // If successful, update the isCopied state value
                this.setState({ isUrlCopied: true })
                setTimeout(() => {
                    this.setState({ isUrlCopied: false })
                }, 1500);
            })
            .catch((err) => {
                console.log(err);
            })
    }

    openSpinnerRedux = () => {
        this.props.toggleSpinnerFlag(true)
    }
    closeSpinnerRedux = () => {
        this.props.toggleSpinnerFlag(false)
    }
    publishDiagramDelete = async () => {
        try {
            console.log(this.state.deleteId);

            this.openSpinnerRedux()
            const UpdatedData = await BPMNService.PublishDelete(this.state.deleteId)
            if (UpdatedData.status === 200) {
                this.setState({
                    isdelete: false,
                    deleteId: null
                })
                this.closeSpinnerRedux()
                await BPMNService.getBPMNServicedata().then(
                    response => {
                        this.setState({
                            rowData: response.data,
                            isdelete: false,
                            deleteId: null
                        })
                        SuccessMessage(BPMNViewer_Toaster.Published_Map_Deleted_Sucessfully)
                    });
            }
            else {
                ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
            }
        }
        catch (error) {
            this.closeSpinnerRedux()
            console.log(error)
        }
    }
    onCloseConfirmation = () => {
        this.setState({ isdelete: false, deleteId: null })
    }
    // OnDeleteClick = (params) => {
    //     console.log("params".params);
    //     this.setState({ isdelete: true, deleteId: params.data.taskConnectionId, diagramName: params.data.diagramname ? params.data.diagramname : params.data.diagramName })
    // }
    onFilterTextBoxChanged = () => {
        const filterValue = document.getElementById('filter-text-box').value;
        this.setState({ filterValue });
    }
    render() {
        return (
            <>
                <AuthCommonLayout
                    onDiagramNavOnclick={this.CancelShowDiagram}>
                    {this.state.isLoading ?
                        <div>
                            <div class="z-40 absolute bg-gray-50/75 w-full h-[90vh]">
                                <div class="top-[50%] left-[50%] z-40 absolute bg-transparent">
                                    <div class="relative container">
                                        <div class="border-2 shadow-md border-t-transparent border-blue-500 border-solid rounded-full w-12 h-12 animate-spin"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        : null
                    }

                    {this.state.viewDiagram ?
                        <div>
                            <ShowDiagramParent
                                bpmn_xml={this.state.bpmn_xml}
                                selectedLanguage={this.state.selectedLanguage}
                                CancelShowDiagram={this.CancelShowDiagram}
                                diagramname={this.state.diagramname}
                                diagramXmlId={this.state.diagramXmlId}
                                CheckElements={this.CheckElements}
                                openSpinnerRedux={this.openSpinnerRedux}
                                closeSpinnerRedux={this.closeSpinnerRedux}
                                templateBgColor={this.state.templateBgColor}
                                isDefaultTemplateEnable={this.state.isDefaultTemplateEnable}
                                selectedMapData={this.state.selectedMapData}
                                appliedTemplate={this.state.appliedTemplate}
                            />
                        </div>
                        :
                        <div>
                            <div className='flex items-center space-x-5 mb-0 pt-3 pl-4'>
                                <div class="relative flex items-center border-gray-300 border rounded-md h-8 overflow-hidden">
                                    <div class="place-items-center grid w-12 h-full text-search-text">
                                        <HiOutlineSearch color='#0000004D' size={24} />
                                    </div>
                                    <input
                                        id="filter-text-box"
                                        onInput={this.onFilterTextBoxChanged}
                                        class="bg-search-bg pr-2 w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs outline-none peer placeholder-[#0000004D]"
                                        type="text"
                                        autoComplete='off'
                                        placeholder="Search..." />
                                </div>
                            </div>
                            <div id='CustomAgGrid'>
                                <CustomAgGrid
                                    rowData={this.state.rowData}
                                    columnDefs={this.state.columnDefs}
                                    onGridReady={() => { console.log('Grid') }}
                                    filterValue={this.state.filterValue}
                                    OnCheckBoxSelection={() => { console.log("onCheckBoxSelection") }}
                                />
                            </div>
                        </div>}
                </AuthCommonLayout >
                {
                    this.state.isPopupshow && (
                        <>
                            <ReactDialogBox
                                closeBox={this.closePopup}
                                modalWidth='68vw'
                                headerBackgroundColor='#3266b9'
                                headerTextColor='black'
                                headerHeight='40px'
                                closeButtonColor='#fc581c'
                                closeButtonSize='20px'
                                bodyBackgroundColor='#fffdfc'
                                bodyTextColor='black'
                                //   bodyHeight='150px'
                                headerText={this.state.datasourcetype === 'Data Source' ? BPMNViewer_Labels._TEST_CASE : this.state.datasourcetype}
                            >
                                <div>
                                    {this.state.datasourcetype === 'Data Source' ?
                                        <div>
                                            <ALMTestCase
                                                AlmnTestCase={this.state.AlmnTestCase}
                                                AlmDataSource={this.state.AlmDataSource}
                                            />
                                        </div> : null}
                                    {this.state.datasourcetype === 'Document' ?
                                        <div>
                                            <div>
                                                <div class="p-2 text-center">
                                                    {/* <BsCloudDownload size={32} color="green" /> */}
                                                    <h5 class="mb-1 font-normal text-gray-500 text-lg dark:text-gray-400">{BPMNViewer_Labels._ARE_YOU_SURE_YOU_WANT_TO_DOWNLOAD}<br /><span class='text-blue-800'>{this.state.documentpath}</span></h5>
                                                    {/* <h6 class="mb-5 py-2 text-black text-small dark:text-gray-400"><BiCopy size={20}/> : <span class='border-2 p-2 text-blue-700'>{window.location.protocol + '//' + window.location.hostname + ":8286/bpmnPublish/" + this.state.diagramname}</span> <span class='font-semibold text-orange-600'></span></h6> : null} */}
                                                    <div class="flex justify-center pt-2">
                                                        <button
                                                            type="button"
                                                            class="flex bg-blue-600 shadow-lg mx-5 px-4 py-3 rounded-md focus:ring-4 text-white transform transition-transform active:scale-x-75 outline-none"
                                                        >
                                                            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                                            </svg>
                                                            <a class='underline' href={this.state.documentpath}>{BPMN_Common_Labels._DOWNLOAD}</a>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> : null}

                                </div>
                            </ReactDialogBox>
                        </>
                    )
                }

                {
                    this.state.isPublish && (
                        <>
                            <ReactDialogBox
                                closeBox={this.cellCancelPublishDiagram}
                                modalWidth='38vw'
                                headerBackgroundColor='#ffffff'
                                headerTextColor='black'
                                headerHeight='40px'
                                closeButtonColor='#000'
                                closeButtonSize='20px'
                                bodyBackgroundColor='#fffdfc'
                                bodyTextColor='black'
                                //   bodyHeight='150px'
                                headerText={BPMNViewer_Labels._PUBLISH_BPMN}
                            >
                                <div>
                                    <div>
                                        <div class="relative max-h-full">
                                            <div class="relative dark:bg-gray-700">
                                                <div class="p-2 text-center">
                                                    <svg class="mx-auto mb-4 w-10 h-10 text-gray-400 dark:text-gray-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 11V6m0 8h.01M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                                    </svg>
                                                    <h3 class="mb-1 font-normal text-gray-500 text-lg dark:text-gray-400">{BPMNViewer_Labels._ARE_YOU_SURE_YOU_WANT_TO_PUBLISH}<br /><span class='text-blue-800'>{this.state.diagramname}</span></h3>
                                                    {this.state.isPublishOkey ?
                                                        <div class="relative flex justify-center items-center space-x-2 py-4 w-full">
                                                            <input
                                                                type="text"
                                                                class={ControlsConstants.TextBox.textBoxDefault}
                                                                defaultValue={window.location.protocol + '//' + window.location.hostname + ":8286/bpmnPublish/" + this.state.diagramname} />
                                                            <div className="flex">
                                                                <BiCopy className="cursor-pointer" onClick={this.handleCopyClick} size={20} />
                                                                {this.state.isUrlCopied ? <span className="absolute ml-8 text-lg text-slate-900">{BPMNViewer_Labels._COPIED}</span> : null}
                                                            </div>
                                                        </div>
                                                        : null}
                                                    {this.state.isPublishOkey ? null
                                                        :
                                                        <div className="mb-2 py-4">
                                                            <button data-modal-hide="popup-modal" type="button" class="inline-flex items-center bg-[#3266b9] mr-2 px-5 py-2.5 rounded-lg font-medium text-center text-sm text-white"
                                                                onClick={this.cellOkeyPublishDiagram}>
                                                                {BPMNViewer_Labels._YES_I_AM_SURE}
                                                            </button>
                                                            <button data-modal-hide="popup-modal" type="button" class="focus:z-10 border-gray-200 dark:border-gray-500 bg-white hover:bg-gray-100 dark:hover:bg-gray-600 dark:bg-gray-700 px-5 py-2.5 border rounded-lg focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-600 font-medium text-gray-500 text-sm hover:text-gray-900 dark:hover:text-white dark:text-gray-300 focus:outline-none"
                                                                onClick={this.cellCancelPublishDiagram}>
                                                                {BPMNViewer_Labels._CANCEL_BTN}
                                                            </button>
                                                        </div>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </ReactDialogBox>
                        </>
                    )
                }
                {
                    this.state.isdelete ?
                        <ReactDialogBox
                            closeBox={this.onCloseConfirmation}
                            modalWidth={localControlsConstant.Model.modalWidth}
                            headerBackgroundColor={localControlsConstant.Model.headerbg}
                            headerTextColor={localControlsConstant.Model.bodybg}
                            headerHeight={localControlsConstant.Model.headerheight}
                            closeButtonColor={localControlsConstant.Model.closebtncolor}
                            bodyBackgroundColor={localControlsConstant.Model.bodybg}
                            bodyTextColor={localControlsConstant.Model.bodytextcolor}
                            headerText={localControlsConstant.Model.modelConfirm}
                        >
                            <div>
                                <div class='flex items-center pl-7 max-lg:pl-2 h-16 max-lg:h-8'>
                                    <h1>{BPMNViewer_Labels._ARE_YOU_SURE_WANT_TO_DELETE_PUBLISHED_DIAGRAM} <span className='text-blue-500'>{this.state.diagramName}</span>?</h1>
                                </div>
                                <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                                    <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                        onClick={this.publishDiagramDelete} >{BPMNViewer_Labels._YES_BTN}</button>
                                    <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                        onClick={this.onCloseConfirmation}>{BPMNViewer_Labels._CANCEL_BTN}
                                    </button>
                                </div>

                            </div>
                        </ReactDialogBox>
                        : null}
            </>
        )
    }
}
const mapStateToProps = (state) => ({
    isSpinnerLoading: state.isSpinnerLoading,
});

const mapDispatchToProps = (dispatch) => ({
    toggleSpinnerFlag: (value) =>
        dispatch({ type: "SET_SPINNER_LOADING", payload: value }),
});

export default connect(mapStateToProps, mapDispatchToProps)(BpmnViewer);
