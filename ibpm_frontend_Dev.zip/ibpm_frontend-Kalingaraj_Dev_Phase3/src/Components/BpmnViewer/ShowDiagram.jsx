import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from "bpmn-js-properties-panel";
import { isNumber } from "lodash";
import React from 'react';
import { navIcons } from "../../CommonUtils/ComponentUtil.jsx";
import CustomBPMNComments from "../../CommonUtils/CustomBPMNComments/Index.js";
import CustomBPMNDocuments from "../../CommonUtils/CustomBPMNDocumentClip/CustomDocIndex.js";
import CustomBPMNALMDatasource from "../../CommonUtils/CustomBPMN_ALMDatasource/CustomBPMN_ALMIndex.js";
import CustomBPMNProcess from "../../CommonUtils/CustomBPMNProcessIndex/CustomBPMNProcessIndex.js";
import { BPMN_Common_Labels, Default_Template_Labels } from "../../Constants/COMMON_LABELS.jsx";
import pncLOGO_v1 from "../../Images/pncLOGO_v1.png";
import { getXmlDiagram } from '../BpmnDiagrams/getBpmnDiagrams';
import CustomBpmnModeler from "../ComundaTool/CustomRenderModules/CustomBpmnModeler.jsx";

// const extraActivityElements = ["bpmn:SubProcess", "bpmn:UserTask", "bpmn:ServiceTask", "bpmn:SendTask", "bpmn:ReceiveTask", "bpmn:ManualTask", "bpmn:BusinessRuleTask", "bpmn:ScriptTask", "bpmn:CallActivity", "bpmn:SubProcess"]

class ShowDiagram extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
    this.containerRef = React.createRef();
  }

  async componentDidMount() {
    console.log("componentDidUpdate props ", this.props)
    const { url, diagramXML } = this.props;
    const container = this.containerRef.current;

    this.bpmnModeler = new CustomBpmnModeler({
      container: container,
      propertiesPanel: {
        parent: "#propview",
        enabled: false
      },
      keyboard: {
        bindTo: null
      },
      additionalModules: [CustomBPMNComments, BpmnPropertiesProviderModule, BpmnPropertiesPanelModule, CustomBPMNDocuments,CustomBPMNALMDatasource,CustomBPMNProcess,
        {
          __init__: ["labelEditingProvider"],
          labelEditingProvider: ['value', null],
        },
        { moveCanvas: ['value', null] },
        {
          dragging: ["value", { init: function () { } }]
        },
      ],
      customActions: {
        handleElementDblClickByTool: this.props.handleElementDblClickByTool
      }
    });
    this.eventBus = this.bpmnModeler.get("eventBus");
    console.log(this.eventBus);

    this.eventBus.on("root.set", async (event) => {
      console.log(event);
      if (event.element?.type === "bpmn:SubProcess") {
        try {
          //this.props.setMappingDiagramsArray("isDiagNavigationClicked", false)
          const tempCurrMap = { ...this.props.currentMapDet };
          let tempMappDiags = [...this.props.mappingDiagrams];
          console.log(tempMappDiags);
          const version = tempCurrMap?.id + "." + event.element.businessObject.$attrs.AutoNumCount;
          const name = event.element.businessObject.name ? "-" + event.element.businessObject.name : "";

          let diagramXMLTemp;
          async function getChildDiagramXml(arr, parentId) {
            for (let i = 0; i < arr.length; i++) {
              console.log(arr[i].id === parentId, arr[i]);
              if (arr[i].id === parentId) {
                console.log("pass", arr[i].diagramXml)
                diagramXMLTemp = arr[i].diagramXML
                return arr[i];
              } else if (arr[i].children.length === 0) {
                continue;
              }
              else {
                const isObjFinded = await getChildDiagramXml(arr[i].children, parentId);
                if (isObjFinded) {
                  return isObjFinded.diagramXML
                }
              }
            }
            return "";
          }
          console.log(version);
          await getChildDiagramXml(tempMappDiags, version);
          //const currentXML = await this.props.getCurrentDiagramXML();

          const updatedMapDet = {
            id: version,
            name: name,
            key: version + name,
            meta: {
              collapsed: true,
              label: version + name,
            },
            parentId: tempCurrMap?.id,
            diagramXML: "",
            // children: []
          }
          console.log(tempCurrMap);

          // function updateCurrDiagramXml(arr, parentId) {
          //   for (let i = 0; i < arr.length; i++) {
          //     if (arr[i].id === parentId) {
          //       arr[i].diagramXML = currentXML;
          //       return arr;
          //     } else if (arr[i].children.length === 0) {
          //       continue;
          //     }
          //     else {
          //       updateCurrDiagramXml(arr[i].children, parentId);
          //     }
          //   }
          //   return arr;
          // }
          // const updatedArr = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id);
          // console.log("##### ", updatedArr);
          console.log(diagramXMLTemp)
          // this.props.setMappingDiagramsArray("mappingDiagrams", updatedArr);
          this.props.setMappingDiagramsArray("currentMapDet", updatedMapDet);
          await this.props.updateXmlByImportXML(diagramXMLTemp);
          return false
        } catch (error) {
          console.error(error);
        }
      }
    });
    this.eventBus.on("element.click", 1500, (e) => {
      console.log(e);
      // console.log("element.click", e);
      const currElementId = e.element.id;
      if (e.element.type === 'bpmn:EndEvent' && e.element.di["background-color"] === '#009432') {
        this.props.popupFlowlineActAvailable(e);
        e.stopPropagation();
      }
      if (e.element.type === 'bpmn:StartEvent' && e.element.di["background-color"] === '#44bd32') {
        this.props.targetFlowline(e);
        e.stopPropagation();
      }

      if (currElementId.includes("Actor") || e.element.type === "bpmn:DataObjectReference") {
        e.stopPropagation();
      }
      this.bpmnModeler.get('comments')?.collapseAll();

    });
    this.eventBus.on("element.dblclick", 1500, (e) => {
      console.log("dblclick ", e);
      const tempBussObj = e.element.businessObject;
      const tempBussObjAttr = e.element.businessObject.$attrs;
      if (e.element?.type === "bpmn:DataObjectReference") {
        this.props.handleElementDblClickByTool(e, "FILE", tempBussObj?.name, tempBussObjAttr);
        e.stopPropagation();
        e.preventDefault();
      }
    })
    // this.eventBus.on("element.hover", 1500, (e) => {
    //   if ((e.element.type === 'bpmn:Task' && e.element.height !== 25) || extraActivityElements.includes(e.element.type)) {
    //     let tooltips = this.bpmnModeler.get("tooltips");
    //     let businessObject = e.element.businessObject;
    //     let value = businessObject.$attrs.fullNametxt;
    //     if (value && value !== undefined && value !== null && value !== "" && value.length > 20) {
    //       let toolTipText = ` <div style="position: relative; width: 300px ; color: #717D7E; padding: 12px; border: 1px solid #BDC3C7; background-color: #ffffff; font-size: small; border-radius: 4px;">${value}<div style="position: absolute; top: 50%; left: -10px; width: 0; height: 0; border-top: 10px solid transparent; border-bottom: 10px solid transparent; border-right: 10px solid #BDC3C7; transform: translateY(-50%);"></div></div>`;
    //       let toolTipId = 'toolTipId' + e.element.id;
    //       tooltips.remove(toolTipId);
    //       let xx = e.element.x + (e.element.width / 3);
    //       let yy = e.element.y + (e.element.height / 4)

    //       toolTipId = tooltips.add({
    //         position: {
    //           x: xx,
    //           y: yy
    //         },
    //         id: toolTipId,
    //         timeout: 1000,
    //         html: toolTipText
    //       });

    //     } else {
    //       let toolTipId = 'toolTipId' + e.element.id;
    //       return tooltips.remove(toolTipId);
    //     }
    //   }
    // });

    this.props.handleBpmnRef.current = this;
    if (url) {
      return this.fetchDiagram(url);
    }

    if (diagramXML) {
      return this.updateXmlDiagram(diagramXML);
    }
  }

  componentWillUnmount() {
    this.bpmnModeler.destroy();
  }

  componentDidUpdate(prevProps, prevState) {
    const { props, state } = this;
    if (props.url !== prevProps.url) {
      return this.fetchDiagram(props.url);
    }
    const currentXML = props.diagramXML || state.diagramXML;
    const previousXML = prevProps.diagramXML || prevState.diagramXML;
    if (currentXML && currentXML !== previousXML) {
      return this.updateXmlDiagram(currentXML);
    }
    this.eventBus.on('import.render.complete', async (event) => {
      const bpmnCanvas = this.bpmnModeler.get('canvas');
      bpmnCanvas.zoom('fit-viewport', "center");
    });
  }

  async updateXmlDiagram(diagramXML) {
    try {
      // console.trace("this.bpmnModeler ", this.bpmnModeler);
      // const xml = await getXmlDiagram("vertical")
      // console.log(this.props);
      await this.bpmnModeler.importXML(this.props.mappingDiagrams[0].diagramXML);
    } catch (error) {
      console.error(error);
    }
  }

  async fetchDiagram(url) {
    console.log('loading diagram');
    try {
      const xml = await getXmlDiagram("vertical")
      console.log("refreshed xml", xml);
      this.setState({ diagramXML: xml })
    } catch (error) {
      console.error(" fetchDiagr 111 ", error);
    }
  }
  renderElementsByIconsId = (groupId) => {
    const tempGroupId = isNumber(groupId) ? groupId : parseInt(groupId)
    return navIcons.find(item => item.id === tempGroupId)
  }

  render() {
    return (
      <>
        <div
          id="propview"
          style={{
            width: "0%",
            float: "right",
            // maxHeight: "98vh",
            position: "absolute",
            right: '0px',
            zIndex: 20,
            // border: '1px solid #0000004d'
          }}>
        </div>

        <div className="py-2 pr-1">
          <div className={`relative ${this.props.isDefaultTemplateEnable ? this.props.isTreeView ? 'mr-[70px] ' : ' ' : ''} p-2 rounded border-4`}
            style={{
              background: `${this.props.isDefaultTemplateEnable ? `linear-gradient(to bottom, ${this.props.appliedTemplate.colorCode}, #fff)` : `linear-gradient(to bottom, #fff, #fff)`}` // Adjust as needed
            }}

          >
            {this.props.isDefaultTemplateEnable ?
              <>
                <div class="relative z-0 w-full">
                  <div class="flex justify-between items-center">
                    <div class="flex space-x-4">
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("HOME")}
                        title={BPMN_Common_Labels._HOME_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.homeIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navHomeIcon} alt="home_icon" />
                        }
                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("UP")}
                        title={BPMN_Common_Labels._UP_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.upIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navUpIcon} alt="home_icon" />
                        }
                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("PREV")}
                        title={BPMN_Common_Labels._PREVIOUS_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.previousIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navPreviousIcon} alt="previous_icon" />
                        }
                      </div>
                      <p className="mt-6 text-xs">{this.props.currentMapDet.name.substring(0, 1) === '-' ? this.props?.currentMapDet?.name.substring(1, this.props?.currentMapDet.name.length) : this.props.currentMapDet.name}</p>
                    </div>
                    <div class="flex items-center">
                      <p class="mt-4 pr-4 text-xs">{this.props?.currentMapDet.id}</p>
                      <div class="p-1 w-16">
                        <img src={this.props.isDefaultTemplateEnable ? this.props.appliedTemplate?.companyLogo?.imgcontent : pncLOGO_v1} alt="company_logo" />
                      </div>
                    </div>
                  </div>
                  <p class="-top-4 left-1/2 absolute py-2 font-semibold transform -translate-x-1/2">{this.props?.diagramname}</p>
                </div>
                <hr class="border-0 bg-gray-900 mt-1 h-px" />
              </> : null}

            <div id='viewonly'
               onClick={this.props.CheckElements}
              ref={this.containerRef} style={{ height: this.props.isDefaultTemplateEnable ? "68vh" : "78vh" }}>
            </div>
            {this.props.isDefaultTemplateEnable ?
              <>
                <div class="relative z-50 w-full">
                  <hr class="border-0 bg-gray-900 h-px" />
                  <div class="flex justify-between items-center">
                    <div class="flex space-x-4">
                      <p className="mt-1 text-xs">{BPMN_Common_Labels._AUTHOR_TEMPLATE} : {this.props.selectedMapData?.author}</p>
                    </div>
                    <div class="flex items-center">
                      <p class="mt-1 text-xs">{BPMN_Common_Labels._STATUS_TEMPLATE} : {this.props.selectedMapData?.status}</p>
                    </div>
                  </div>
                </div>
              </>
              : null}
          </div>

        </div>
      </>
    );
  }
}

export default ShowDiagram

