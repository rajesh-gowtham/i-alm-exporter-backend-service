import moment from 'moment/moment';
import React, { useEffect, useRef, useState } from 'react';
import { HiOutlineSearch } from 'react-icons/hi';
import { MdOutlineClose } from 'react-icons/md';
import { useDispatch } from 'react-redux';
import Select from "react-select";
import { ErrorMessage } from '../../CommonUtils/CustomToast';
import { AuditTrail_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import BPMNService from '../../Services/BPMNService';
import UserService from '../../Services/UserService';
import CustomAgGridResource from '../Aggrid/CustomAgGrid_Resource';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';

function AuditTrail(props) {
    const gridRef = useRef();
    const [rowData, setRowData] = useState([]);
    const [columnDefs] = useState([
        { headerName: 'Action Type', field: 'modificationType' },
        { headerName: 'Modified By', field: 'changedBy' },
        {
            headerName: 'Modified At',
            field: 'changedAt',
            cellRenderer: (params) => (
                <span>{moment(params.value).format('DD-MM-YYYY HH:mm')}</span>
            )
        },
        {
            headerName: 'View',
            field: '',
            cellRenderer: (params) => (
                <button
                    href=""
                    onClick={(e) => {
                        e.preventDefault();
                        handleViewChanges(params.data);
                    }}
                    style={{ color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}
                >
                    View Changes
                </button>
            )
        }
    ].map(col => ({
        ...col,
        flex: 1,
        resizable: true,
        suppressMovable: true,
        sortable: true
    })));

    const dispatch = useDispatch()
    const [filterData, setFilterData] = useState({});
    const [selectedOption, setSelectedOption] = useState({});
    const [moduleOptions, setModuleOptions] = useState([]);
    const [suggestionData, setSuggestionData] = useState([]);
    const [selectedRecord, setSelectedRecord] = useState({});
    const [isActive, setIsActive] = useState(false);
    const [searchText, setSearchText] = useState('');
    const [filteredSuggestions, setFilteredSuggestions] = useState([]);
    const [isGridVisible, setIsGridVisible] = useState(false);
    const [selectedRowData, setSelectedRowData] = useState(null);
    const [popupData, setPopupData] = useState(false);

    const loginUserRole = window.localStorage.getItem("userRole");


    useEffect(() => {
        // let defaultOption = [{ label: "maps", value: "maps" }];
        // if (loginUserRole === "Admin") {
        //     defaultOption.push({ label: "users", value: "users" });
        // }
        // setModuleOptions(defaultOption)
        // moduleSelectChange({ label: "maps", value: "maps" })
        // setSelectedOption({ label: "maps", value: "maps" })
        const defaultOption = loginUserRole === "Editor" ? [{ label: "maps", value: "maps" }] : [{ label: "users", value: "users" }];
        setModuleOptions(defaultOption);
        moduleSelectChange(defaultOption[0]);
        setSelectedOption(defaultOption[0]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const moduleSelectChange = async (selected) => {
        try {
            setSelectedOption(selected);
            openSpinnerRedux()
            if (selected.value === "users") {
                const response = await UserService.getAllUsersAPIcall()
                const data = await response.data;
                if (response.status === 200 || response.status === 201) {
                    const alteredData = data.map((item) => ({
                        field1: (item.firstname + " " + item.lastname),
                        field2: item.email,
                        id: item.userid,
                    }))
                    setSuggestionData(alteredData)
                    console.log("🚀 ~ alteredData:", alteredData);
                    closeSpinnerRedux()
                }
            } else if (selected.value === "maps") {
                const response = await BPMNService.getBPMNDiagramsByUserIdAPICALL()
                const data = await response.data;
                console.log("🚀 ~ data:", data);
                if (response.status === 200 || response.status === 201) {
                    const alteredData = data.map((item) => ({
                        field1: item.diagramName,
                        field2: item.mapPrivacyType,
                        id: item.id,
                    }))
                    setSuggestionData(alteredData)
                    console.log("🚀 ~ alteredData:", alteredData);
                    closeSpinnerRedux()
                }
            }
            setSearchText('')
            setRowData([])
            console.log("Selected option:", selected);
        } catch (error) {
            console.error(error);
            closeSpinnerRedux()
        }
    };

    const isRowSelectable = (params) => {
        return true;
    }

    const filterOnChangeHandler = (e) => {
        let value = "";
        let name = "";
        let formattedDate = ""
        if (e.target.type === "date") {
            name = e.target.name;
            value = e.target.value;
            if (!moment(value, "YYYY-MM-DD", true).isValid()) {
                ErrorMessage("Invalid date entered. Please provide a valid date.");
                return;
            }
            formattedDate = name === 'startDate' ? moment(value).set({ hour: "00", minute: "00", second: "00" }).format('YYYY-MM-DDTHH:mm:ss') : moment(value).set({ hour: "23", minute: "59", second: "59" }).format('YYYY-MM-DDTHH:mm:ss');
        }
        setFilterData(prevState => ({
            ...prevState,
            [name]: formattedDate
        }));
    }
    const filterSubmitOnClick = async () => {
        // const dates = rowData.map(item => moment(item.changedAt).startOf("day"));
        // const minDate = moment.min(dates);
        // const maxDate = moment.max(dates);

        const startDate = moment(filterData.startDate).startOf("day");
        const endDate = moment(filterData.endDate).startOf("day");

        if (!filterData.startDate || !filterData.endDate) {
            ErrorMessage("Both start date and end date are required.");
            return;
        }
        if (startDate.isAfter(endDate)) {
            ErrorMessage("Start date cannot be after the end date.");
            return;
        }
        console.log(filterData);
        const tempFormData = filterData
        const payload = {
            entityId: `${selectedRecord.id}`,
            startDate: tempFormData.startDate,
            endDate: tempFormData.endDate
        }
        const response = await BPMNService.auditTrail(payload)
        console.log("response", response)
        const data = await response.data;
        const status = response.status
        if (status === 200 || status === 201) {
            setRowData(data);
        }
    }
    const handleInputChange = (e) => {
        const searchTxt = e.target.value;
        setSearchText(searchTxt);
        if (searchTxt) {
            console.log("🚀 ~ suggestionData:", suggestionData);
            const filteredArray = suggestionData.filter((data) => {
                return (data.field1.toLowerCase().includes(searchTxt.toLowerCase()) || data.field2.toLowerCase().includes(searchTxt.toLowerCase()));
            });
            setFilteredSuggestions(filteredArray);
            setIsActive(true);
        } else {
            setFilteredSuggestions([]);
            setIsActive(false);
            setIsGridVisible(false);
        }
    };
    const handleSuggestSelect = (suggestion) => {
        console.log("🚀 ~ suggestion:", suggestion);
        setSelectedRecord(suggestion);
        setIsActive(false);
        setSearchText(suggestion.field1)
        searchSubmitOnClick(suggestion, "SELECT")
    };
    const searchSubmitOnClick = async (datas, type) => {
        console.log("🚀 ~ datas:", datas);
        openSpinnerRedux()
        try {
            if (searchText === "") {
                closeSpinnerRedux();
                ErrorMessage("Please enter text")
                return;
            }
            console.log(selectedRecord);
            const payload = {
                entityId: type === "SELECT" ? datas.id : selectedRecord.id,
                startDate: "",
                endDate: ""
            }
            const response = await BPMNService.auditTrail(payload);
            const data = await response.data;
            console.log(response);
            if (response.status === 200 || response.status === 201) {
                closeSpinnerRedux()
                setIsGridVisible(true);
                setRowData(data)
            }

        } catch (error) {
            console.error(error);
            closeSpinnerRedux()
        }
    }
    const openSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: true });
    };
    const closeSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: false });
    };
    const handleViewChanges = (rowData) => {
        console.log("🚀 ~ rowData:", rowData);
        setPopupData(true);
        setSelectedRowData(rowData);
    };
    const closeDialogPopupBox = () => {
        setPopupData(false);
    }
    return (
        <AuthCommonLayout>
            <div className="flex flex-wrap mt-4 px-5">
                <div className="flex items-center">
                    <h1 className="mr-2 font-semibold text-lg">{AuditTrail_Labels._AUDIT_TRAIL}</h1>
                    <div className="w-[130px] h-full">
                        <Select
                            name="auditTrail"
                            id="auditTrail"
                            options={moduleOptions}
                            placeholder="Select Option"
                            value={selectedOption}
                            onChange={moduleSelectChange}
                        />
                    </div>
                </div>

                <div className="mx-2 w-4/12">
                    <SearchComponent
                        selectedOption={selectedOption}
                        suggestionData={suggestionData}
                        searchSubmitOnClick={searchSubmitOnClick}
                        selectedRecord={selectedRecord}
                        isActive={isActive}
                        handleSuggestSelect={handleSuggestSelect}
                        handleInputChange={handleInputChange}
                        searchText={searchText}
                        filteredSuggestions={filteredSuggestions}
                    />
                </div>

                {isGridVisible && rowData.length > 0 && (
                    <div id="date-range-picker" className="flex flex-wrap items-center gap-2 ml-8">
                        <span className="text-gray-500 whitespace-nowrap">{AuditTrail_Labels._FROM}</span>
                        <input
                            id="datepicker-range-start"
                            name="startDate"
                            type="date"
                            onChange={filterOnChangeHandler}
                            className="flex-grow border-gray-300 bg-gray-50 px-2 py-1 border focus:border-blue-500 rounded focus:ring-blue-500 min-w-[120px] text-sm"
                        />
                        <span className="ml-2 text-gray-500 whitespace-nowrap">{AuditTrail_Labels._TO}</span>
                        <input
                            id="datepicker-range-end"
                            name="endDate"
                            type="date"
                            onChange={filterOnChangeHandler}
                            className="flex-grow border-gray-300 bg-gray-50 px-2 py-1 border focus:border-blue-500 rounded focus:ring-blue-500 min-w-[120px] text-sm"
                        />
                        <button
                            type="button"
                            onClick={filterSubmitOnClick}
                            className={`${ControlsConstants.Responsive.btnResponsive.btn_white} px-8`}
                        >
                            {AuditTrail_Labels._APPLY}
                        </button>
                    </div>
                )}
            </div>

            {isGridVisible && (
                <div className="mt-3 w-full">
                    <div className="overflow-auto">
                        <div id="auditGrid" className="w-full h-[480px] md:h-[520px] ag-theme-alpine">
                            <CustomAgGridResource
                                rowData={rowData}
                                columnDefs={columnDefs}
                                onGridReady={() => { }}
                                ref={gridRef}
                                rowSelection
                                isRowSelectable={isRowSelectable}
                                rowBuffer={15}
                                suppressColumnVirtualisation
                                suppressRowVirtualisation
                            />
                        </div>
                    </div>
                </div>
            )}

            {popupData && (
                <SearchedRecords
                    closeDialogPopupBox={closeDialogPopupBox}
                    data={selectedRowData}
                />
            )}
        </AuthCommonLayout>
    )
}
export default AuditTrail

const SearchComponent = (props) => {
    return (
        <div className="w-full h-[40px]">
            <div className="relative border-gray-300 bg-white shadow-sm border rounded-lg h-full">
                <input
                    type="search"
                    className="pr-12 pl-4 rounded-lg w-full h-full text-sm placeholder:text-gray-400 focus:outline-none"
                    placeholder={`Search by ${props?.selectedOption?.label}...`}
                    value={props.searchText}
                    onChange={props.handleInputChange}
                />

                <div
                    className="top-0 right-0 absolute flex justify-center items-center border-gray-200 px-3 border-l h-full text-purple-600 cursor-pointer"
                    onClick={props?.searchSubmitOnClick}
                >
                    <HiOutlineSearch color="#644bff" size={24} />
                </div>

                {props.isActive && (
                    <ul className="right-0 left-0 z-10 absolute bg-white shadow-lg mt-2 rounded-lg max-h-72 overflow-y-auto">
                        {props.filteredSuggestions.length > 0 ? (
                            props.filteredSuggestions.map((suggestion, index) => (
                                <li
                                    key={index}
                                    className="flex justify-between items-center hover:bg-gray-100 px-4 py-2 cursor-pointer"
                                    onClick={() => props.handleSuggestSelect(suggestion)}
                                >
                                    <span>{suggestion?.field1}</span>
                                    <span className="bg-sky-50 px-2 rounded-lg text-[13px]">
                                        {suggestion?.field2}
                                    </span>
                                </li>
                            ))
                        ) : (
                            <li className="px-4 py-2">{AuditTrail_Labels._NO_SUGGESTIONS_AVAILABLE}</li>
                        )}
                    </ul>
                )}
            </div>
        </div>
    );
};

const SearchedRecords = (props) => {
    console.log("🚀 ~ props:", props);
    const extractProjectNames = (newValue) => {
        // eslint-disable-next-line
        const regex = /name=([^\}]+)\}/g;
        let matches;
        const projectNames = [];
        while ((matches = regex.exec(newValue)) !== null) {
            projectNames.push(matches[1]);
        }
        return projectNames.join(', ');
    };
    const extractCustomerName = (newValue) => {
        // eslint-disable-next-line
        const regex = /name=([^\}]+)\}/;
        const match = regex.exec(newValue);
        return match ? match[1] : newValue;
    };
    const extractAssignedUser = (newValue) => {
        // eslint-disable-next-line
        const regex = /user=([^\}]+)\}/g;
        const match = regex.exec(newValue);
        console.log("🚀 ~ match:", match?.input);
        let AssignedUser = match?.input.split(',').map(el => {
            return el.substring(el.indexOf('=') + 1, el.length - 1)
        }).join(',')
        return match ? AssignedUser : newValue;
    }
    const filteredDetails = props.data.details.filter(detail => detail.fieldName !== 'password' && detail.fieldName !== 'imgcontent');
    return (
        <>
            <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                <div className="flex justify-center items-center w-full h-full">
                    <div className="bg-white rounded-md w-[50vw]">
                        <div className="border-box font-sans text-gray-900">
                            <div className="flex justify-center mx-auto w-full">
                                <div className="flex flex-col justify-center items-center mx-2 w-full">
                                    <div className="flex justify-between px-2 py-1.5 border-black w-full cursor-pointer">
                                        <span className="font-semibold text-lg">
                                            {AuditTrail_Labels._MODIFIED_RECORDS}
                                        </span>
                                        <span
                                            className="hover:bg-gray-400 p-[2px] rounded"
                                            onClick={props.closeDialogPopupBox}
                                        >
                                            <MdOutlineClose size={22} />
                                        </span>
                                    </div>
                                    <div className="border-slate-300 border-t w-full min-h-[15rem] max-h-[24rem] overflow-y-auto">
                                        <table className="border-collapse w-full text-sm">
                                            <thead className="top-0 z-10 sticky bg-slate-100">
                                                <tr>
                                                    <th scope="col" className="border-slate-300 px-2 py-3 border-b">
                                                        {AuditTrail_Labels._FIELD}
                                                    </th>
                                                    <th scope="col" className="border-slate-300 px-2 py-3 border-b">
                                                        {AuditTrail_Labels._OLD_VALUE}
                                                    </th>
                                                    <th scope="col" className="border-slate-300 px-2 py-3 border-b">
                                                        {AuditTrail_Labels._NEW_VALUE}
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody className="bg-white">
                                                {filteredDetails.map((detail) => (
                                                    <tr className="border-b w-full" key={detail.id}>
                                                        <td className="px-2 py-2 border-r w-[33%] font-medium text-gray-900 whitespace-nowrap">
                                                            {detail.fieldName}
                                                        </td>
                                                        <td className="px-2 py-2 border-r w-[33%]">
                                                            {detail.fieldName === 'projects'
                                                                ? extractProjectNames(detail.oldValue)
                                                                : detail.fieldName === 'customers'
                                                                    ? extractCustomerName(detail.oldValue)
                                                                    : detail.fieldName === 'assignedUsers'
                                                                        ? extractAssignedUser(detail.oldValue)
                                                                        : detail.oldValue}
                                                        </td>
                                                        <td className="px-2 py-2 w-[33%]">
                                                            {detail.fieldName === 'projects'
                                                                ? extractProjectNames(detail.newValue)
                                                                : detail.fieldName === 'customers'
                                                                    ? extractCustomerName(detail.newValue)
                                                                    : detail.fieldName === 'assignedUsers'
                                                                        ? extractAssignedUser(detail.newValue)
                                                                        : detail.newValue}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};