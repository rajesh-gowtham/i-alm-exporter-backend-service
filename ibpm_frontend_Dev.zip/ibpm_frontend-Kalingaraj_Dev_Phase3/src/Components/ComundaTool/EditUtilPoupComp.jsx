/* eslint-disable react-hooks/exhaustive-deps */
import BpmnModeler from "bpmn-js/lib/Modeler";
import { isNumber } from "lodash";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { BsCloudDownload, BsEye } from "react-icons/bs";
import { CiMail } from "react-icons/ci";
import { FaEdit, FaRegEdit, FaRegFilePdf, FaTrash } from "react-icons/fa";
import { FcCancel, FcHome } from "react-icons/fc";
import { FiZoomIn, FiZoomOut } from "react-icons/fi";
import { HiOutlineDownload, HiOutlineSearch } from "react-icons/hi";
import { IoCloseCircleOutline, IoDocumentTextOutline, IoPrintOutline, IoTrashBin, IoTrashOutline } from "react-icons/io5";
import { MdClear, MdOutlineClose, MdOutlineDelete, MdOutlineDone } from "react-icons/md";
import { RiArrowGoBackFill } from "react-icons/ri";
import { TfiComments } from "react-icons/tfi";
import { VscSend } from "react-icons/vsc";
import { ReactDialogBox } from "react-js-dialog-box";
import { useNavigate } from 'react-router-dom';
import Select from "react-select";
import ReactToPrint from "react-to-print";
import Propertiespanel from "../../CommonUtils/BpmnViewerActivityView";
import { convertFileToBase64, createCellStyle, dateTime, downloadExcel, DropdownIndicator, navIcons, ReactSelect, validateFileOnChange } from "../../CommonUtils/ComponentUtil";
import { ErrorMessage, SuccessMessage } from "../../CommonUtils/CustomToast";
import { BPMN_Common_Labels, BPMNEditor_Labels, Default_Template_Labels, Integrity_Check_Labels, Resource_Label, Users_Labels } from "../../Constants/COMMON_LABELS";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { BPMN_Editor_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS";
import { FileTypes } from "../../Constants/UtilJSON";
import flowLine from '../../Images/flowline.png';
// import pncLOGO_v1 from "../../Images/pncLOGO_v1.png";
import ExcelJS from 'exceljs';
import { AiOutlineCloudUpload } from "react-icons/ai";
import { BiTrashAlt } from "react-icons/bi";
import { CiLock } from "react-icons/ci";
import { FaMailBulk } from "react-icons/fa";
import { IoIosSave } from "react-icons/io";
import { IoSend } from 'react-icons/io5';
import { MdOutlineRemoveRedEye } from "react-icons/md";
import BPMNService from "../../Services/BPMNService";
import CustomAgGridResource from "../Aggrid/CustomAgGrid_Resource";
import allLanguages from "../GoogleTranstor/transLanguages.json";
import MultiSelect from "../MultiSelect/MultiSelect";
import TreeListContainer from "../TreeViewModel/TreeListContainer";
import { AssignUsers } from "./BpmndiagramGrid";
// import { PieChart } from 'react-minimal-pie-chart';
import ApexCharts from 'apexcharts';
export const extraActivityElements = ["bpmn:SubProcess", "bpmn:UserTask", "bpmn:ServiceTask", "bpmn:SendTask", "bpmn:ReceiveTask", "bpmn:ManualTask", "bpmn:BusinessRuleTask", "bpmn:ScriptTask", "bpmn:CallActivity", "bpmn:SubProcess"]

export const EditBpmnToolHeader = (props) => {

    const Role = window.localStorage.getItem("userRole");
    const navigate = useNavigate();

    useEffect(() => {
        const handlePopState = async (e) => {
            // e.preventDefault();
            const isBothXMLSame = await props.getIsUnSavedXMLExist();
            if (!isBothXMLSame) {
                if (window.confirm("Changes you made may not be saved?")) {
                    console.log('if if in changes u ');
                    BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(props.selectedMapData?.diagramXmlIds.Draft.diagramXmlId, 'checkOut')
                    navigate(-1);
                } else {
                    window.history.pushState(null, null, window.location.pathname);
                }
            } else {
                console.log("Back to the previous page");
                BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(props.selectedMapData?.diagramXmlIds.Draft.diagramXmlId, 'checkOut')
                navigate(-1);
            }
        };

        window.history.pushState(null, null, window.location.pathname);
        window.addEventListener('popstate', handlePopState);
        return () => {
            window.removeEventListener('popstate', handlePopState);
        };

    }, []);
    useEffect(() => {
        const handleBeforeUnload = async (event) => {
            const isBothXMLSame = await props.getIsUnSavedXMLExist();
            console.log(isBothXMLSame);
            if (!(isBothXMLSame)) {
                console.log("if handleBeforeUnload");
                event.preventDefault();
                event.returnValue = "You have unsaved changes. Are you sure you want to leave?";
                localStorage.setItem('unsavedChanges', 'true');
                localStorage.setItem('diagramXmlId', "" + props.selectedMapData?.diagramXmlIds.Draft?.diagramXmlId);
            } else {
                console.log("else handleBeforeUnload");
                BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(props.selectedMapData?.diagramXmlIds.Draft?.diagramXmlId, 'checkOut')
            }
            //  event.returnValue = "data will get lost"
        };
        window.addEventListener('beforeunload', handleBeforeUnload, { capture: true });
        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload, { capture: true });
        };

    }, []);
    // console.log("Editutil", props.mapLevelOptions, props);
    return (
        <div>
            <div class="z-40 relative">
                <div className={`absolute left-0 flex ${props.isDefaultTemplateEnable ? ' px-4 py-2 ' : 'py-4 px-4'}`}>
                    {/* <div
onClick={() => props.onDiagramNavOnclick("BACKTOPARENT")}
title={"All Diagrams"}
class="hover:bg-gray-200 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
>
<IoArrowBackCircleSharp size={26} color="blue" />
</div> */}
                    {!(props.isDefaultTemplateEnable) ? <>
                        <div
                            onClick={() => props.onDiagramNavOnclick("HOME")}
                            title={BPMN_Common_Labels._HOME_ICON_TOOLTIP}
                            class="md:mx-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                        >
                            <FcHome size={22} color="black" />
                        </div>
                        <div
                            onClick={() => props.onDiagramNavOnclick("UP")}
                            title={BPMN_Common_Labels._UP_ICON_TOOLTIP}
                            class="md:mx-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                        >
                            <svg
                                className="up_icon"
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 48 48"
                            >
                                <g fill="#F44336">
                                    <path d="M46.1 24L33 35V13zM10 20h4v8h-4zm-6 0h4v8H4zm12 0h4v8h-4z" />
                                    <path d="M22 20h14v8H22z" />
                                </g>
                            </svg>
                        </div>
                        <div
                            onClick={() => props.onDiagramNavOnclick("PREV")}
                            title={BPMN_Common_Labels._PREVIOUS_ICON_TOOLTIP}
                            class="md:mx-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48"><g fill="#F44336"><path d="m4 24l14-11.7v23.4z" /><path d="M15 20h27v8H15z" /></g></svg>
                        </div>

                    </> : null}
                    <div className="flex items-center ml-2 font-bold text-black">
                        {props.isMapLocked ?
                            <div className="flex items-center space-x-1 bg-red-50 px-2 py-1 border border-red-600 rounded">
                                <CiLock size={16} color="red" />
                                <span className="text-red-900 text-xs">Locked</span>
                            </div>
                            : null
                        }
                        <div className="mx-2 w-[140px]">
                            <Select
                                styles={ReactSelect.dropDownStylesOrangeBigDraft}
                                name="mapLevel"
                                components={{
                                    // DropdownIndicator,
                                    IndicatorSeparator: () => null,
                                }}
                                id="mapLevel"
                                options={props.mapLevelOptions}
                                onChange={props.onSlectMapTypeOnChange}
                                // value={props.mapLevelOptions.find(item => item.value === props.selectedMapType)}
                                value={props.selectedMapType}
                            />
                        </div>
                        {
                            (["Master", "Archive"].includes(props.selectedMapType?.mapLevel) && Role === "Admin") ?
                                <div>
                                    <button onClick={props.revokeToDraftAPICALL} className="bg-green-200 px-2 py-[2px] border border-black border-opacity-10 rounded-md font-medium text-green-900">
                                        Revoke To Draft
                                    </button>
                                </div>
                                :
                                null
                        }
                        {
                            (["Draft"].includes(props.selectedMapType?.mapLevel) && Role === "Admin") && (!props.isMapLocked) && props.mapLevelOptions?.length > 1 ?
                                <div>
                                    <button onClick={props.deleteRevokedDraftAPICALL} className="flex items-center bg-red-200 px-2 py-[2px] border border-black border-opacity-10 rounded-md font-medium text-red-900">
                                        delete
                                        <BiTrashAlt size={20} className="pl-1" />
                                    </button>
                                </div>
                                :
                                null
                        }

                    </div>

                </div>
                <div className="right-0 absolute mt-2">
                    {/* {!(props.isDefaultTemplateEnable) ?
                        <div class="flex flex-col items-center px-2 py-4">
                            <div className="mr-8 mb-6 p-1 w-16">
                                {/* <img src={pncLOGO_v1} /> 
                            </div>
                        </div> : null*/}
                    {/* }  */}

                    {props.isTreeView ?
                        <div class="flex flex-col items-center">
                            <div className="my-2 mr-2">
                                <Select
                                    styles={ReactSelect.dropDownStylesOrange}
                                    name="selected_datasource"
                                    components={{
                                        DropdownIndicator,
                                        IndicatorSeparator: () => null,
                                    }}
                                    id="selected_datasource"
                                    placeholder={BPMN_Common_Labels._LANGUAGE_PLACEHOLDER}
                                    options={allLanguages}
                                    onChange={props.handleSelectLanguageOnChange}
                                    value={props.selectedLanguage}
                                />
                            </div>
                            <div className="ml-8">
                                <div
                                    onClick={props.onOpenComment}
                                    title={BPMN_Common_Labels._COMMENTS_ICON_TOOLTIP}
                                    class="hover:bg-gray-200 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                >
                                    <CommentsIcon Role={Role} getcomment={props.getcomment} CommentsReaderStorage={props.CommentsReaderStorage} color="#0000FF" />
                                </div>
                                <div>
                                    {
                                        props.isCommentOpened ?
                                            <div className='z-[100] DropdownBox'>
                                                <CommentBoxPOPUP
                                                    mapStatus={props.selectedMapData?.diagramXmlIds.Draft.status}
                                                    isMapLocked={props.isMapLocked}
                                                    getcomment={props.getcomment}
                                                    onOpenComment={props.onOpenComment}
                                                    comment={props.comment}
                                                    onChangeComments={props.onChangeComments}
                                                    onCommentPostClick={props.onCommentPostClick}
                                                    closeDialogPopupBox={props.closeDialogPopupBox}
                                                    currentMapDet={props.currentMapDet}
                                                    getActivity={props.getActivityId}
                                                    getActivityElementId={props.getActivityElementId}
                                                    handleCommentsClick={props.handleCommentsClick}
                                                    levelNavigationFlag={props.levelNavigationFlag}
                                                    handleCommentsEdit={props.handleCommentsEdit}
                                                    handleCommentsDelete={props.handleCommentsDelete}
                                                    isEditing={props.isEditing}
                                                    copiedComments={props.copiedComments}
                                                    mapDiagramRecord={props.mapDiagramRecord}
                                                    deleteAllComments={props.deleteAllComments}
                                                    publicUsers={props.publicUsers}
                                                />
                                            </div>
                                            : null
                                    }
                                </div>

                                <div
                                    title={BPMN_Common_Labels._PRINT_ICON_TOOLTIP}
                                    class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                    onClick={props.onPrintDiagram}
                                >
                                    <IoPrintOutline size={28} color="#0000FF" />{/* color={hoverStates['Print'] ? "#0000FF" : "#000"} */}
                                </div>
                                {localStorage.getItem("userRole") === "Admin" && !(props.isMapLocked) && ["InReview", "InProgress"].includes(props.selectedMapData?.diagramXmlIds.Draft.status) ? <div
                                    title={BPMN_Common_Labels._UPLOAD_ICON_TOOLTIP}
                                    class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                    onClick={props.openBpmnFileUpload}
                                >
                                    <AiOutlineCloudUpload size={28} color="#0000FF" />
                                </div>
                                    : null}
                                {localStorage.getItem("userRole") === "Admin" ?
                                    <div
                                        title={BPMN_Common_Labels._DOWNLOAD_ICON_TOOLTIP}
                                        class="relative hover:bg-gray-100 md:mx-1 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                        onClick={props.onClickBpmnDownload}
                                    >
                                        <BsCloudDownload size={22} color="#0000FF" />

                                    </div>
                                    : null}
                                {/* <div
                            title={"Clear"}
                            class="hover:bg-gray-200 md:mx-1 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                            onClick={props.refreshBpmn_OnClick}
                        >
                            <IoRefresh size={22} color="#000" />
                        </div> */}
                                <div
                                    title={BPMN_Common_Labels._ZOOM_IN_ICON_TOOLTIP}
                                    class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                    onClick={() => props.zoomInOutBpmn_OnClick("in")}
                                >
                                    <FiZoomIn size={22} color="#0000FF" />
                                </div>
                                <div
                                    title={BPMN_Common_Labels._ZOOM_OUT_ICON_TOOLTIP}
                                    class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                    onClick={() => props.zoomInOutBpmn_OnClick("out")}
                                >
                                    <FiZoomOut size={22} color="#0000FF" />
                                </div>
                                {/* <div
                                title={BPMN_Common_Labels._ADD_RESOURCE_ICON_TOOLTIP}
                                class="hover:bg-gray-200 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                onClick={props.onClickAddResource}
                            >
                                <FaUsersCog size={28} color="#0000FF" />
                            </div> */}

                                {/*  DON'T REMOVE THIS DIV. CustomReplacePadProvider.jsx                              */}
                                <div
                                    title={BPMN_Common_Labels._ADD_DOCUMENT_ICON_TOOLTIP}
                                    // class="flex justify-center cursor-pointer"
                                    class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                    style={{ display: 'none' }}
                                    onClick={props.openAddDocument}
                                >
                                    <IoDocumentTextOutline size={28} color="#0000FF" />
                                    <input
                                        type="file"
                                        ref={props.fileUploadRef}
                                        multiple
                                        style={{ display: "none" }}
                                        onClick={(e) => { e.target.value = null }}
                                        onChange={props.handleAddDocFileOnChange}
                                    />
                                </div>

                                {/* <div
                                title={BPMN_Common_Labels._FLOW_LINE_CONNECTOR_ICON_TOOLTIP}
                                class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                onClick={props.onClickflowlinepopup}
                            >
                                <IoReturnDownForwardOutline size={28} color="#0000FF" />
                            </div>
                            */}
                                {!(props.isMapLocked || Role === "Admin" ||
                                    (Role === "Editor" && ["InReview", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Reviewer" && ["InProgress", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status))
                                )
                                    ?
                                    <div
                                        title={BPMN_Common_Labels._RE_ARRANGE_ICON_TOOLTIP}
                                        class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                        onClick={() => {
                                            if (!props.editAutoNumflag) {
                                                props.handlerearrangePopupflag()
                                            }
                                            else {
                                                ErrorMessage(BPMN_Editor_Toaster.Do_The_Re_Arrange_And_Then_Try_To_Navigate);
                                                return;
                                            }
                                        }}
                                    >
                                        {<FaEdit size={20} color="#0000FF" />}
                                        {props.reArrangePopupFlag && (
                                            <div class="right-14 z-50 absolute w-[100px] h-[100px] text-black">
                                                <div class="bg-white shadow-lg rounded overflow-hidden">
                                                    <div>
                                                        <div>
                                                            <ul class="flex flex-col max-w-xs">
                                                                <li class="inline-flex items-center gap-x-1 bg-white hover:bg-gray-100 dark:bg-gray-800 -mt-px first:mt-0 px-4 py-2 border dark:border-gray-700 first:rounded-t-lg last:rounded-b-lg font-medium text-gray-800 dark:text-white text-sm">
                                                                    <div
                                                                        title={BPMN_Common_Labels._MANUAL_RE_ARRANGE_ICON_TOOLTIP}
                                                                        class="flex justify-between w-full cursor-pointer"
                                                                        onClick={() => {
                                                                            if (props.rearrangeArray.length === 0) {
                                                                                props.handleeditAutoNumflag(props.editAutoNumflag)
                                                                            }
                                                                            else {
                                                                                ErrorMessage(BPMN_Editor_Toaster.Do_The_Re_Arrange_And_Then_Try_To_Navigate);
                                                                                return;
                                                                            }
                                                                        }}
                                                                    >
                                                                        Manual
                                                                    </div>
                                                                </li>
                                                                <li class="inline-flex items-center gap-x-1 bg-white hover:bg-gray-100 dark:bg-gray-800 -mt-px first:mt-0 px-4 py-2 border dark:border-gray-700 first:rounded-t-lg last:rounded-b-lg font-medium text-gray-800 dark:text-white text-sm">
                                                                    <div
                                                                        title={BPMN_Common_Labels._AUTOMATED_RE_ARRANGE_ICON_TOOLTIP}
                                                                        class="flex justify-between w-full cursor-pointer"
                                                                        onClick={() => {
                                                                            if (props.rearrangeArray.length === 0) {
                                                                                props.handleAutomatedReArrange()
                                                                            }
                                                                            else {
                                                                                ErrorMessage(BPMN_Editor_Toaster.Do_The_Re_Arrange_And_Then_Try_To_Navigate);
                                                                                return;
                                                                            }
                                                                        }
                                                                        }
                                                                    >
                                                                        Automated
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </div> : null}
                                {/* {!(props.isMapLocked || Role === "Admin" ||
                                    (Role === "Editor" && ["InReview", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Reviewer" && ["InProgress", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status))
                                )
                                    ?
                                    <divtitle=
                                        {BPMN_Common_Labels._RE_ARRANGE_ICON_TOOLTIP}
                                        class="hover:bg-gray-100 my-1 p-1 lg:px-4 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                        onClick={() => {
                                            if (props.rearrangeArray.length === 0) {
                                                props.handleeditAutoNumflag(props.editAutoNumflag)
                                            }
                                            else {
                                                ErrorMessage(BPMN_Editor_Toaster.Do_The_Re_Arrange_And_Then_Try_To_Navigate);
                                                return;
                                            }
                                        }}
                                    >
                                        {<FaEdit size={20} color="#0000FF" />}
                                    </divtitle=> : null} */}
                            </div>
                        </div> : null}

                </div>
            </div>
        </div>
    );
};
export const UploadBpmnPopup = (props) => {
    console.log(props);
    const options = props?.projectsDataContainer?.map(project => ({
        label: `${project.customerName}-${project.projectName}`,
        value: project.projectName,
        id: project.id,
        customerId: project.customerId,
        customerName: project.customerName,
    }));
    const selectedOption = options?.find(option => option.value === props?.mapDiagramRecord?.project?.projectName) || null;

    return (
        <>
            {
                (!props?.isSpecificUsersEnable) ?
                    <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                        <div className="flex justify-center items-center w-full h-full">
                            <div className="w-[30vw]">
                                <div class="bg-white border-box rounded-md font-sans text-gray-900">
                                    <div class="flex justify-center mx-auto w-full sm:max-w-lg">
                                        <div class="flex flex-col justify-center items-center bg-white my-5 w-full h-auto">
                                            <div className="flex items-center w-full">
                                                <h2 class="flex justify-end mb-2 w-2/3 font-semibold text-2xl">{props?.isFromMapImport ? BPMNEditor_Labels._IMPORT_MAP : BPMNEditor_Labels._UPLOAD_HERE}</h2>
                                                <span
                                                    onClick={props.IsUploadBpmn ? props.closeDialogPopupBox : props.closeAddEditPOPUP}
                                                    className="flex justify-end mr-3 w-1/3 cursor-pointer"
                                                >
                                                    <MdOutlineClose className="hover:bg-gray-200 p-[2px] rounded" size={26} />
                                                </span>
                                            </div>
                                            <div class="mb-5 text-center">
                                                {props.isFromMapImport ?
                                                    <p class="text-gray-500 text-xs">
                                                        {BPMNEditor_Labels._FILE_SHOULD_BE_OF_FORMAT_TXT}
                                                    </p>
                                                    :
                                                    <>
                                                        <p class="text-gray-500 text-xs">
                                                            {BPMNEditor_Labels._FILE_SHOULD_BE_OF_FORMAT_BPMN_OR_TXT_OR_XML}
                                                        </p>
                                                        <p class="text-[11px] text-gray-500">
                                                            {BPMNEditor_Labels._FILE_MUST_CONTAIN_XML_FORMATTED_CONTENT}
                                                        </p>
                                                        <p class="text-gray-500 text-xs">{BPMNEditor_Labels._FILE_SIZE_5MB}</p>
                                                    </>
                                                }
                                            </div>

                                            <div onDrop={props.uploadBpmnFileOnChange} onDragOver={(e) => { e.preventDefault() }} className="relative bg-gray-200 mb-2 border-2 border-gray-400 border-dashed rounded-lg w-[70%] max-w-xs h-[100px]">
                                                <input
                                                    type="file"
                                                    id="file-upload"
                                                    accept={".txt"}
                                                    className="hidden"
                                                    required
                                                    onChange={props.uploadBpmnFileOnChange}
                                                />

                                                <label
                                                    htmlFor="file-upload"
                                                    className="z-20 flex flex-col-reverse justify-center items-center w-full h-[100px] cursor-pointer"
                                                >
                                                    <span
                                                        title={props.mapDiagramRecord ? props.mapDiagramRecord?.diagramName : props.selectedXmlFileName}
                                                        className="mt-1 w-[90%] overflow-ellipsis overflow-hidden text-blue-400 text-center whitespace-nowrap"
                                                    >
                                                        {props.mapDiagramRecord ? props.mapDiagramRecord?.diagramName : props.selectedXmlFileName}
                                                    </span>
                                                    <p className="z-10 font-light text-gray-500 text-xs text-center">
                                                        {BPMNEditor_Labels._DRAG_DROP_YOUR_FILES_HERE}
                                                    </p>
                                                    <svg
                                                        className="z-10 w-8 h-8 text-indigo-400"
                                                        fill="currentColor"
                                                        viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"></path>
                                                    </svg>
                                                </label>


                                            </div>
                                            {props.mapDiagramRecord ? <>
                                                <div className="mt-1 w-[80%]">
                                                    <div className="md:items-center mb-2">
                                                        <div className="mb-2">
                                                            <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                                {BPMNEditor_Labels._CHOOSE_STORAGE_LOCATION} :
                                                            </label>
                                                        </div>
                                                        <div className="ml-16 w-full">
                                                            <div className="items-center mr-2">
                                                                <input
                                                                    className="border border-gray-300 w-4 h-4"
                                                                    id="database"
                                                                    name="database"
                                                                    type="checkbox"
                                                                    value="database"
                                                                    onChange={(e) => props.addEditMapDiagramOnChange(e, null, "docStorageType")}
                                                                    checked={props.mapDiagramRecord?.docStorageType === "database"}
                                                                    disabled={props?.isEditMap}
                                                                />
                                                                <label
                                                                    htmlFor="database"
                                                                    className={`ml-2 ${props.mapDiagramRecord?.docStorageType === "database" ? " text-blue-500 font-medium " : " text-opacity-40 text-black  font-normal "}  text-sm`}
                                                                >
                                                                    {BPMNEditor_Labels._APPLICATION_STORAGE}
                                                                </label>
                                                            </div>
                                                            <div className="items-center mr-2">
                                                                <input
                                                                    id="sharepoint"
                                                                    type="checkbox"
                                                                    name="sharepoint"
                                                                    className="border border-gray-300 w-4 h-4"
                                                                    onChange={(e) => props.addEditMapDiagramOnChange(e, null, "docStorageType")}
                                                                    checked={props.mapDiagramRecord.docStorageType === "sharepoint"}
                                                                    disabled={props?.isEditMap}
                                                                />
                                                                <label
                                                                    htmlFor="sharepoint"
                                                                    className={`ml-2 ${props.mapDiagramRecord.docStorageType === "sharepoint" ? " text-blue-500 font-medium " : " text-opacity-40 text-black  font-normal "}  text-sm`}
                                                                >
                                                                    {BPMNEditor_Labels._SHAREPOINT}
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                {props.mapDiagramRecord.docStorageType === "sharepoint" && (
                                                    <div className="mt-1 w-[80%]">
                                                        <div className="flex justify-center mb-2">
                                                            <Select
                                                                styles={ReactSelect.dropDownStylesOrangeBig}
                                                                name="sharepointConfig"
                                                                components={{
                                                                    DropdownIndicator: DropdownIndicator,
                                                                    IndicatorSeparator: () => null,
                                                                }}
                                                                id="sharepointConfig"
                                                                placeholder={BPMNEditor_Labels._SHAREPOINT_PLACEHOLDER}
                                                                options={props.sharepointConfigOptions}
                                                                onChange={props.addEditMapDiagramOnChange}
                                                                value={
                                                                    props.mapDiagramRecord.configId === "" || props.mapDiagramRecord.configId === null
                                                                        ? null
                                                                        : props.sharepointConfigOptions?.find((option) => option.value === props.mapDiagramRecord.configId)
                                                                }
                                                                isDisabled={props?.isEditMap}
                                                            />
                                                        </div>
                                                    </div>
                                                )}
                                                {/* {implementation for project organization} */}
                                                <div className="mt-1 w-[80%]">
                                                    <div className="md:items-center mb-2">
                                                        <div className="mb-2">
                                                            <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                                {BPMNEditor_Labels._PROJECTS}
                                                            </label>
                                                        </div>
                                                        <div className="w-full">

                                                            <Select
                                                                styles={ReactSelect.dropDownStylesForm}
                                                                class="block z-50 mb-2 p-3 border border-grey-light w-full h-10"
                                                                name='organization'
                                                                components={{ DropdownIndicator, IndicatorSeparator: () => null }}
                                                                id='selected_datasource'
                                                                placeholder={Users_Labels._PROJECT_PLACEHOLDER}
                                                                options={props.projectsDataContainer.map(project => ({
                                                                    label: `${project.customerName}-${project.projectName}`,
                                                                    value: project.projectName,
                                                                    id: project.id,
                                                                    customerId: project.customerId,
                                                                    customerName: project.customerName
                                                                }))}
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "project")}
                                                                value={selectedOption}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="mt-1 w-[80%]">
                                                    <div className="md:items-center mb-2">
                                                        <div className="mb-2">
                                                            <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                                {BPMNEditor_Labels._CHOOSE_PRIVACY_TYPE} :
                                                            </label>
                                                        </div>
                                                        <div className="flex justify-between ml-2 w-full">
                                                            <div className="items-center mr-2">
                                                                <input
                                                                    className="border border-gray-300 w-4 h-4"
                                                                    id="public"
                                                                    name="public"
                                                                    type="checkbox"
                                                                    value="public"
                                                                    onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                    checked={props.mapDiagramRecord.mapPrivacyType === "public"}
                                                                // disabled={props?.isEditMap}
                                                                />
                                                                <label
                                                                    htmlFor="public"
                                                                    className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "public" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                                >
                                                                    {BPMNEditor_Labels._PRIVACY_PUBLIC}
                                                                </label>
                                                            </div>
                                                            <div className="items-center mr-2">
                                                                <input
                                                                    id="private"
                                                                    type="checkbox"
                                                                    name="private"
                                                                    className="border border-gray-300 w-4 h-4"
                                                                    onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                    checked={props.mapDiagramRecord.mapPrivacyType === "private"}
                                                                // disabled={props?.isEditMap}
                                                                />
                                                                <label
                                                                    htmlFor="private"
                                                                    className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "private" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                                >
                                                                    {BPMNEditor_Labels._PRIVACY_PRIVATE}
                                                                </label>
                                                            </div>
                                                            <div className="items-center mr-2">
                                                                <input
                                                                    id="specific"
                                                                    type="checkbox"
                                                                    name="specific"
                                                                    className="border border-gray-300 w-4 h-4"
                                                                    onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                    checked={props.mapDiagramRecord.mapPrivacyType === "specific"}
                                                                // disabled={props?.isEditMap}
                                                                />
                                                                <label
                                                                    htmlFor="specific"
                                                                    className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "specific" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                                >
                                                                    {BPMNEditor_Labels._PRIVACY_SPECIFIC}
                                                                </label>
                                                                {props.mapDiagramRecord.mapPrivacyType === "specific" ?
                                                                    <div onClick={props.toggleSpecificUsersFlag}
                                                                        className="ml-4 font-medium text-blue-500 text-base decoration-blue-700 underline cursor-pointer">
                                                                        {props?.mapDiagramRecord?.mapAuthorizedUsers?.length !== 0 ? props?.mapDiagramRecord?.mapAuthorizedUsers?.length + BPMNEditor_Labels._SPECIFIC_TITLE_USER_ASSIGNED : BPMNEditor_Labels._SPECIFIC_TITLE_ASSIGN_USERS}
                                                                    </div>
                                                                    : null}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </>
                                                : null}
                                            {(props.mapDiagramRecord ? props.mapDiagramRecord?.diagramName : props.selectedXmlFileName) !== "" ? (
                                                <div class="flex justify-center py-3">
                                                    <button
                                                        class="bg-blue-500 px-2 py-1 rounded-md w-52 text-white"
                                                        onClick={props.uploadBpmnFile_OnClick}
                                                    >
                                                        {BPMNEditor_Labels._UPLOAD_BTN}
                                                    </button>
                                                </div>
                                            ) : null}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    :
                    <AssignUsers
                        allUsers={props.allUsers}
                        selectedUsers={props.mapDiagramRecord?.mapAuthorizedUsers}
                        toggleSpecificUsersFlag={props.toggleSpecificUsersFlag}
                        assignEditUsersOnClick={props.addEditMapDiagramOnChange}
                    />
            }
        </>
    );
};
export const AddResourcePopup = (props) => {
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[25vw] h-[200px] font-sans text-gray-900">
                    <div className="sm:col-span-3">
                        <label
                            htmlFor="resourceName"
                            className="block font-medium text-gray-900 text-sm leading-6"
                        >
                            Resource Name
                        </label>
                        <div className="mt-3">
                            <input
                                type="text"
                                value={props.resourceName}
                                id="resourceName"
                                name="resourceName"
                                autoFocus={true}
                                onChange={props.compHandleTextOnChange}
                                className="block shadow-sm px-2 py-1.5 border-0 rounded-md outline-none ring-1 ring-gray-300 focus:ring-2 focus:ring-indigo-600 ring-inset focus:ring-inset w-full text-gray-900 placeholder:text-gray-400 sm:text-sm sm:leading-6"
                            />
                        </div>
                    </div>
                    <div class="flex justify-center space-x-2">
                        <button
                            class="px-2 py-1 border border-black border-opacity-30 rounded-md w-52 text-blue-600"
                            onClick={props.closeDialogPopupBox}
                        >
                            Cancel
                        </button>

                        <button
                            class="px-2 py-1 border border-black border-opacity-30 rounded-md w-52 text-blue-600"
                            onClick={props.deleteResourceOnClick}
                        >
                            Delete
                        </button>
                        {props.isEditResourceEnable ? (
                            <button
                                class="bg-blue-500 px-2 py-1 rounded-md w-52 text-white"
                                onClick={props.editResourceNameOnClick}
                            >
                                EDIT
                            </button>
                        ) : (
                            <button
                                class="bg-blue-500 px-2 py-1 rounded-md w-52 text-white"
                                onClick={props.addResourceNameOnClick}
                            >
                                ADD
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
export const ActivityNameTextPopup = (props) => {
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[25vw] h-[250px] font-sans text-gray-900">
                    <span className="font-medium text-gray-900 dark:text-white text-sm">
                        Select Activity Type :
                    </span>
                    <div class="flex justify-center pl-[7rem] rounded-md">

                        <div class={`inline-flex items-center pr-2 ${props.selActivityType === 'default' ? 'text-black ' : 'text-gray-500'}`}>
                            <label
                                class="relative flex items-center p-1.5 rounded-full cursor-pointer"
                                for="defaultActivity"
                                data-ripple-dark="false"
                            >
                                <input
                                    type="checkbox"
                                    onChange={props.compHandleTextOnChangeforInput}
                                    class="peer before:block before:top-2/4 before:left-2/4 before:absolute relative before:bg-blue-gray-500 checked:before:bg-blue-500 checked:bg-blue-500 before:opacity-0 hover:before:opacity-10 border border-gray-400 checked:border-blue-500 rounded-md before:rounded-full w-5 before:w-8 h-5 before:h-8 transition-all before:transition-opacity before:-translate-y-2/4 before:-translate-x-2/4 appearance-none cursor-pointer before:content['']"
                                    id="default"
                                    name="selActivityType"
                                    value="default"
                                    checked={props.selActivityType === 'default'}
                                />
                                <div class="top-2/4 left-2/4 absolute opacity-0 peer-checked:opacity-100 text-white transition-opacity -translate-x-2/4 -translate-y-2/4 pointer-events-none">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        class="w-3.5 h-3.5"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        stroke="currentColor"
                                        stroke-width="1"
                                    >
                                        <path
                                            fill-rule="evenodd"
                                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                            clip-rule="evenodd"
                                        ></path>
                                    </svg>
                                </div>
                            </label>
                            Default
                        </div>
                        <div class={`inline-flex items-center ${props.selActivityType === 'process' ? ' text-black ' : 'text-gray-500'}`}>
                            <label
                                class="relative flex items-center p-1.5 rounded-full cursor-pointer"
                                for="processActicity"
                                data-ripple-dark="false"
                            >
                                <input
                                    type="checkbox"
                                    class="peer before:block before:top-2/4 before:left-2/4 before:absolute relative before:bg-blue-gray-500 checked:before:bg-blue-500 checked:bg-blue-500 before:opacity-0 hover:before:opacity-10 border border-gray-400 checked:border-blue-500 rounded-md before:rounded-full w-5 before:w-8 h-5 before:h-8 transition-all before:transition-opacity before:-translate-y-2/4 before:-translate-x-2/4 appearance-none cursor-pointer before:content['']"
                                    id="processActicity"
                                    name="selActivityType"
                                    value="process"
                                    onChange={props.compHandleTextOnChangeforInput}
                                    checked={props.selActivityType === 'process'}
                                />
                                <div class="top-2/4 left-2/4 absolute opacity-0 peer-checked:opacity-100 text-white transition-opacity -translate-x-2/4 -translate-y-2/4 pointer-events-none">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        class="w-3.5 h-3.5"
                                        viewBox="0 0 20 20"
                                        fill="currentColor"
                                        stroke="currentColor"
                                        stroke-width="1"
                                    >
                                        <path
                                            fill-rule="evenodd"
                                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                            clip-rule="evenodd"
                                        ></path>
                                    </svg>
                                </div>
                            </label>
                            Process
                        </div>
                    </div>
                    <label
                        for="message"
                        class="block mb-2 font-medium text-gray-900 dark:text-white text-sm"
                    >
                        {BPMNEditor_Labels._CONTENT}
                    </label>
                    <textarea
                        autoFocus={true}
                        id="message"
                        rows="4"
                        name="selActivityName"
                        value={props.selActivityName}
                        onChange={props.compHandleTextOnChange}
                        class="block bg-gray-50 dark:bg-gray-700 p-2.5 border border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 rounded-lg focus:ring-blue-500 dark:focus:ring-blue-500 w-full text-gray-900 dark:text-white text-sm dark:placeholder-gray-400"
                    ></textarea>
                    <div className="flex justify-center space-x-2">
                        <div
                            onClick={props.editActNameTxtOnClick}
                            className="flex justify-center items-center space-x-2 bg-blue-500 mt-2 px-2 py-1 rounded-md w-[90px] text-white cursor-pointer"
                        >
                            <span>{BPMNEditor_Labels._SAVE_BTN}</span>
                            <span>
                                <MdOutlineDone size={18} />
                            </span>
                        </div>
                        <div
                            class="flex justify-center items-center space-x-2 hover:bg-gray-200 mt-2 px-2 py-1 border border-black border-opacity-30 rounded-md w-[90px] text-black cursor-pointer"
                            onClick={props.closeDialogPopupBox}
                        >
                            <span>{BPMNEditor_Labels._CANCEL_BTN}</span>
                            <span>
                                <MdClear size={18} />
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
export const PublishDiagramPOPUP = (props) => {
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[45vw]">
                    <div class="bg-white border-box rounded-md font-sans text-gray-900">
                        <div class="flex justify-center mx-auto w-full sm:max-w-lg">
                            <div class="flex flex-col justify-center items-center bg-white mt-5 w-full h-auto">
                                <div className="flex justify-between pr-5 border-b border-black border-opacity-30 w-full cursor-pointer">
                                    <span className="flex justify-center items-center w-full font-bold text-lg">Pubish Map</span>
                                    <span
                                        onClick={props.closeDialogPopupBox}
                                        className="hover:bg-gray-200 p-[2px] rounded"
                                    >
                                        <MdOutlineClose size={22} />
                                    </span>
                                </div>
                                <div className="w-[80%]">
                                    <div className="flex flex-wrap justify-center px-2 py-6 w-full font-semibold text-base">Are You Sure You Want to Publish Map <span className="pl-2 text-blue-500">{props.mapDiagramRecord.diagramName}?</span></div>
                                    {/* <div class="md:items-center mb-3">
                                        <div className="mb-2">
                                            <label class={ControlsConstants.label.labelDefault} for="inline-full-name">
                                                {BPMNEditor_Labels._MAP_NAME}
                                            </label>
                                        </div>
                                        <div class="w-full">
                                            <input
                                                class={ControlsConstants.TextBox.textBoxDefault}
                                                id="diagramname"
                                                name="diagramname"
                                                type="text"
                                                value={props.diagramname}
                                                placeholder={BPMNEditor_Labels._MAP_NAME_PLACEHOLDER}
                                                onChange={props.compHandleTextOnChange}
                                                autoComplete="off"
                                            />
                                        </div>
                                    </div> */}
                                    <div class='flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md'>
                                        <button onClick={props.closeDialogPopupBox} class={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8"}>{BPMNEditor_Labels._CANCEL_BTN}</button>
                                        <button class={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-[50px]"} onClick={props.SubmitChangesChanges} >{BPMNEditor_Labels._YES_BTN}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
export const AddFlowLinePopup = (props) => {
    useEffect(() => {
        props.revertRearrangeFlag()
    }, [])


    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[28vw] h-[350px] font-sans text-gray-900">
                    <div className="sm:col-span-3">
                        <label htmlFor="resourceName" className="block font-medium text-gray-900 text-sm leading-6">
                            {BPMNEditor_Labels._1_PROCESS_MAPS}
                        </label>
                        <div className="mt-3">
                            <div className="relative w-full min-w-[250px] h-10">
                                <select className="peer bg-transparent disabled:bg-blue-gray-50 empty:!bg-gray-900 px-3 py-2.5 border placeholder-shown:border focus:border-2 focus:border-gray-900 disabled:border-0 border-t-transparent focus:border-t-transparent placeholder-shown:border-t-blue-gray-200 border-blue-gray-200 placeholder-shown:border-blue-gray-200 rounded-[7px] outline outline-0 focus:outline-0 w-full h-full font-sans font-normal text-blue-gray-700 text-sm transition-all">
                                    <option value="">{props.mappingDiagrams[0].id}</option>
                                </select>
                                <label className="before:block after:block -top-1.5 left-0 before:box-border after:box-border absolute flex after:flex-grow before:mt-[6.5px] after:mt-[6.5px] before:mr-1 after:ml-1 peer-focus:before:border-gray-900 peer-focus:after:border-gray-900 before:border-t peer-placeholder-shown:before:border-transparent peer-focus:before:border-t-2 peer-disabled:before:border-transparent after:border-t peer-placeholder-shown:after:border-transparent peer-focus:after:border-t-2 peer-disabled:after:border-transparent after:border-r peer-focus:after:border-r-2 before:border-blue-gray-200 after:border-blue-gray-200 before:border-l peer-focus:before:border-l-2 before:rounded-tl-md after:rounded-tr-md w-full before:w-2.5 after:w-2.5 h-full before:h-1.5 after:h-1.5 font-normal text-[11px] text-blue-gray-400 peer-focus:text-[11px] peer-focus:text-gray-900 peer-disabled:text-transparent peer-disabled:peer-placeholder-shown:text-blue-gray-500 peer-placeholder-shown:text-blue-gray-500 peer-placeholder-shown:text-sm leading-tight peer-focus:leading-tight peer-placeholder-shown:leading-[3.75] transition-all before:transition-all after:transition-all pointer-events-none before:pointer-events-none after:pointer-events-none select-none '] '] before:content[' after:content['">
                                    {BPMNEditor_Labels._SELECT_A_PARENT_DIAGRAM}
                                </label>
                            </div>
                        </div>
                        <div className="mt-3">
                            <label htmlFor="resourceName" className="block font-medium text-gray-900 text-sm leading-6">
                                {BPMNEditor_Labels._SELECT_THE_DIAGRAM}
                            </label>
                        </div>
                        <div className="w-full h-[150px]" style={{ maxHeight: "150", overflowY: 'auto', overflowX: "hidden" }}>
                            <TreeListContainer
                                treeData={props.mappingDiagrams}
                                onClickItem={props.onClickTreeFlowLine}
                                selectedNode={props.selectedIdFlowLine}
                            />
                        </div>
                    </div>
                    <div className="flex justify-center space-x-2 mt-3">
                        <button
                            className="px-2 py-1 border border-black border-opacity-30 rounded-md w-28 text-blue-600"
                            onClick={props.closeDialogPopupBox}
                        >
                            {BPMNEditor_Labels._CLOSE_BTN}
                        </button>
                        <button
                            className="px-2 py-1 border border-black border-opacity-30 rounded-md w-28 text-blue-600"
                            onClick={props.onShowActivityBox}
                        >
                            {BPMNEditor_Labels._NEXT_BTN}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export const AddFlowLineTargetPopup = (props) => {
    const currId = props.currentMapDet.id;
    const [currentMap, setCurrentMap] = useState([]);

    const currentId = props?.currentMapDet?.id
    console.log("currId", currId);

    useEffect(() => {
        const fetchData = async () => {
            console.log(currentId);
            const id = props.findElementById(props.mappingDiagrams, currentId);
            console.log(id);
            console.log(currentMap.flowlineMap);
            setCurrentMap(id);
        };
        fetchData();
    }, []);
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[30vw]">
                    <div className="bg-white shadow-xl rounded-lg sm:max-w-lg overflow-hidden text-left transition-all transform">
                        <div className="bg-white sm:p-6 px-4 pt-5 pb-4 w-[350px] h-[200px] overflow-x-hidden overflow-y-auto">
                            <div className="sm:flex sm:items-start">
                                <ul>
                                    {currentMap.flowlineMap && currentMap.flowlineMap.length !== 0 && (
                                        <ul>
                                            {currentMap.flowlineMap.map((item, index) => {
                                                console.log(item);

                                                return (
                                                    (item.targetActivityId === props.editElementObj.element.businessObject.$attrs.parentActivityId && item.targetMapId === currId && props.verifyTargetId(item.originMapId, item.parentActivityId)) ?
                                                        <div className="flex justify-between items-center shadow-sm mb-2 p-2 border border-gray-300 rounded w-[300px] h-9" key={index}>
                                                            <ul className="flex items-center">
                                                                <img src={flowLine} className="mr-4 h-[25px]" alt="Flow Line" />
                                                                <li
                                                                    style={{ listStyle: 'none', textDecoration: 'underline', textDecorationColor: 'blue', color: 'blue', fontSize: '10px' }}
                                                                    className="cursor-pointer list-disc list-inside"
                                                                    onClick={() => props.handleFlowlineClick(item.originMapId, item, 'source')}>
                                                                    {/* Source Link To: (Diagram: {item.originMapId}, Activity Number: {`${item.SourceAutoNumCount} ,Description: ${item?.SourceFullnameText ? item.SourceFullnameText.substring(0, 25) : ''}`}) */}
                                                                    {BPMN_Common_Labels._GET_END_FLOWLINK_LIST_LABEL(item)}
                                                                </li>
                                                            </ul>
                                                            {/* {(props.fromViewer && item.targetMapId === currId) ? null :
                                                                <span style={{ color: "grey", cursor: 'pointer' }} onClick={() => props.handleDeleteFlowActivity(index, currId, item)}><FaTrash size={'14px'} /></span>
                                                            } */}

                                                        </div> : ((item.targetActivityId === props.editElementObj.element.businessObject.$attrs.parentActivityId) &&
                                                            <div className="flex items-center">
                                                                <div className="flex justify-between items-center shadow-sm mb-2 p-2 border border-gray-300 rounded w-[300px] h-9 text-sm" key={index}>
                                                                    <span title={BPMN_Common_Labels._GET_END_FLOWLINK_LIST_LABEL(item)} style={{ color: "red" }}>{BPMN_Common_Labels._LinkageBroken}</span>

                                                                    <div className="" key={index}>
                                                                        {(props.fromViewer || window.localStorage.getItem('userRole') === 'Admin') ? null :
                                                                            <span style={{ color: "grey", cursor: 'pointer' }} onClick={() => props.handleExpiredDeleteStartFlowActivity(index, currId, item)}><FaTrash size={'14px'} /></span>
                                                                        }
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )
                                                )
                                            })}
                                        </ul>
                                    )}
                                </ul>
                            </div>
                        </div>
                        <div className="sm:flex sm:flex-row-reverse bg-gray-50 px-4 sm:px-6 py-3">
                            <button onClick={props.closeDialogPopupBox} type="button" className="inline-flex justify-center bg-white hover:bg-gray-50 shadow-sm mt-3 sm:mt-0 sm:ml-3 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-200 focus:ring-offset-2 w-full sm:w-auto font-medium text-gray-700 sm:text-sm text-base">{BPMN_Common_Labels._FLOWLINK_LIST_END_CLOSE_BTN}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export const OnshowActivityBoxComp = (props) => {

    const elementid = document.getElementById("bio-properties-panel-id")?.value;
    const [currentMap, setCurrentMap] = useState([]);
    const [currentMapId, setcurrentMapId] = useState([])

    const currentId = props?.currentMapDet?.id
    console.log("currentId", currentId);
    useEffect(() => {
        const fetchData = async () => {
            console.log(currentId);
            const id = props.findElementById(props.mappingDiagrams, currentId);
            console.log(id);
            setCurrentMap(id);
        };
        fetchData();
    }, []);
    let storingActivityArray = []
    let storingData = {};
    let diagramXml = ''
    async function storingActivity(activity, bpmnDigXml) {

        const tempDivEle = document.createElement("div");
        const tempBpmnModeling = new BpmnModeler({
            tempDivEle,
        })
        console.log(tempBpmnModeling);
        await tempBpmnModeling.importXML(currentMap.diagramXML)
        const bpmnCanvas = tempBpmnModeling.get('canvas');
        const bpmnModeling = tempBpmnModeling.get('modeling');
        console.log(bpmnCanvas, bpmnModeling);
        const findTargetActivityforStart = await bpmnCanvas._elementRegistry.get(elementid);
        console.log(findTargetActivityforStart);
        diagramXml = bpmnDigXml
        storingActivityArray.push(activity)
        storingData = ({
            parentActivityId: elementid,
            targetActivityId: activity.element.id,
            originMapId: currentId,
            targetMapId: props.TreeviewId,
            diagramName: props.mapDiagramRecord.diagramName,
            TargetAutoNumCount: activity.element.businessObject.$attrs.AutoNumCount,
            SourceAutoNumCount: props.sourceAutoNum,
            SourceFullnameText: findTargetActivityforStart?.businessObject?.$attrs?.fullNametxt === undefined || findTargetActivityforStart?.businessObject?.$attrs?.fullNametxt === "" ? 'nil' : findTargetActivityforStart?.businessObject?.$attrs?.fullNametxt,
            TargetFullnameText: activity.element?.businessObject?.$attrs?.fullNametxt === "" || activity.element?.businessObject?.$attrs?.fullNametxt === undefined ? 'nil' : activity.element?.businessObject?.$attrs?.fullNametxt
        })
    }
    function findElementByTargetId(data, id) {
        for (let i = 0; i < data.length; i++) {
            const element = data[i];
            if (element.id === id) {
                return element;
            }
            if (element.children && element.children.length > 0) {
                const foundInChildren = props.findElementById(element.children, id);
                if (foundInChildren) {
                    return foundInChildren;
                }
            }
        }
        return null;
    }
    console.log("currentId", currentId);
    const finishActivity = () => {
        if (storingActivityArray.length === 0) {
            ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity)
            return;
        }
        else {

            const findElementByTarget = findElementByTargetId(props.mappingDiagrams, storingData['targetMapId']);
            console.log("findElementByTargetId", findElementByTarget, storingData);
            setcurrentMapId(findElementByTarget)
            console.log(storingData['targetMapId']);
            if (currentMap.flowlineMap.length === 0) {
                const pushAuditObject = {
                    diagramLevel: props?.currentMapDet?.id,
                    id: elementid,
                    AutoNumCount: storingData['TargetAutoNumCount'],
                    field: "Flow Line",
                    newValue: `Source activity: ${storingData['originMapId']} (${storingData['SourceAutoNumCount']}) - ${storingData['SourceFullnameText']},Targeted activity: ${storingData['targetMapId']} (${storingData['TargetAutoNumCount']}) - ${storingData['TargetFullnameText']}`,
                    oldValue: " ",
                    type: "FLOWLINE",

                }
                console.log("🚀 ~ pushAuditObject:", pushAuditObject);
                props.audittrailpushingObj(pushAuditObject, "FLOWLINE")
                currentMap.flowlineMap.push(storingData)
                findElementByTarget.flowlineMap.push(storingData)
            }
            else {
                const activityChecker = currentMap.flowlineMap.find(el => el.targetActivityId === storingData.targetActivityId && el.targetMapId === storingData.targetMapId && el.parentActivityId === storingData.parentActivityId)
                console.log(activityChecker);
                if (activityChecker) {
                    return
                }
                else {
                    console.log(currentMap);

                    const activityChecker = currentMap.flowlineMap.filter(el =>
                        el.parentActivityId === storingData.parentActivityId
                    );
                    console.log(activityChecker);
                    let pushAuditObject = {}
                    if (activityChecker.length === 0) {
                        pushAuditObject = {
                            diagramLevel: props?.currentMapDet?.id,
                            id: elementid,
                            AutoNumCount: storingData['TargetAutoNumCount'],
                            field: "Flow Line",
                            newValue: `Source activity: ${storingData['originMapId']} (${storingData['SourceAutoNumCount']}) - ${storingData['SourceFullnameText']} Targeted activity: ${storingData['targetMapId']} (${storingData['TargetAutoNumCount']}) - ${storingData['TargetFullnameText']} `,
                            oldValue: '',
                            type: "FLOWLINE",
                        }
                    }
                    else {
                        const oldValue = activityChecker?.map(el => {
                            return {
                                description: ` Source activity: ${el['originMapId']} (${el['SourceAutoNumCount']}) - ${el['SourceFullnameText']} Targeted activity: ${el['targetMapId']} (${el['TargetAutoNumCount']}) - ${el['TargetFullnameText']}`
                            };
                        });
                        const resultString = oldValue.map(el => el.description + ',\n').join(',');
                        const formattedOldValue = resultString.replace(/, /g, '\n');
                        console.log(resultString);
                        console.log("🚀 ~ finishActivity ~ oldValue:", oldValue)
                        pushAuditObject = {
                            diagramLevel: props?.currentMapDet?.id,
                            id: elementid,
                            AutoNumCount: storingData['TargetAutoNumCount'],
                            field: "Flow Line",
                            // newValue: `Targeted activity: ${storingData['targetMapId']} (${storingData['TargetAutoNumCount']}) - ${storingData['TargetFullnameText']}, \n\n Source activity: ${storingData['originMapId']} (${storingData['SourceAutoNumCount']}) - ${storingData['SourceFullnameText']}`,
                            newValue: `Source activity: ${storingData['originMapId']} (${storingData['SourceAutoNumCount']}) - ${storingData['SourceFullnameText']} Targeted activity: ${storingData['targetMapId']} (${storingData['TargetAutoNumCount']}) - ${storingData['TargetFullnameText']}`,
                            oldValue: formattedOldValue,
                            type: "FLOWLINE",
                        }

                    }
                    console.log("🚀 ~ pushAuditObject:", pushAuditObject);
                    props.audittrailpushingObj(pushAuditObject, "FLOWLINE")
                    currentMap.flowlineMap.push(storingData)
                    findElementByTarget.flowlineMap.push(storingData)
                }
            }
            console.log(props.mappingDiagrams);
            console.log(storingData.targetMapId);
            const updatedMappingDiagrams = updateElement(props.mappingDiagrams, currentMap);
            console.log(updatedMappingDiagrams);
            props.addFlowLineActivity(updatedMappingDiagrams, diagramXml, storingData['targetMapId'])
            storingActivityArray = []
            storingData = {}
            props.closeDialogPopupBox()
        }
    }
    const updateElement = (data, updatedElement) => {
        return data.map(item => {
            if (item.id === updatedElement.id) {
                return updatedElement;
            } else if (item.children && item.children.length > 0) {
                return {
                    ...item,
                    children: updateElement(item.children, updatedElement)
                };
            }
            return item;
        });
    };
    const checkActivity = () => {
        console.log(props.TreeviewId);
        const findElementByTarget = findElementByTargetId(props.mappingDiagrams, props.TreeviewId);
        console.log("findElementByTargetId", findElementByTarget);
        setcurrentMapId(findElementByTarget)
    }
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[30vw]">
                    <div className="bg-white shadow-xl rounded-lg sm:max-w-lg overflow-hidden text-left transition-all transform">

                        <div className="bg-gray-100 px-4 sm:px-6 py-3">
                            <h2 className="font-bold text-sm">{BPMNEditor_Labels._TARGET_DIAGRAM_ID} :{props.TreeviewId}</h2>
                        </div>

                        <div className="bg-white p-2 w-[450px] h-[350px]">

                            <Propertiespanel xml={props.xml} storingActivity={storingActivity} checkActivity={checkActivity} currentMapId={currentMapId} TreeviewId={props.TreeviewId} storingData={storingData} className="z-[-999]" currentMapDet={props.currentMapDet} />

                        </div>

                        <div className="z-50 sm:flex sm:flex-row-reverse bg-gray-50 px-4 sm:px-6 py-3">
                            <button onClick={props.onBackActivityBox} type="button" className="inline-flex justify-center bg-white hover:bg-gray-50 shadow-sm mt-3 sm:mt-0 sm:ml-3 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-200 focus:ring-offset-2 w-full sm:w-auto font-medium text-gray-700 sm:text-sm text-base cursor-pointer">{BPMNEditor_Labels._BACK_BTN}</button>
                            <button onClick={finishActivity} type="button" className="inline-flex justify-center bg-white hover:bg-gray-50 shadow-sm mt-3 sm:mt-0 sm:ml-3 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-200 focus:ring-offset-2 w-full sm:w-auto font-medium text-gray-700 sm:text-sm text-base cursor-pointer">{BPMNEditor_Labels._FINISH_BTN}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export const OnshowFlowlineActivity = (props) => {
    console.log(props, props.editElementObj);
    console.log(props.currentMapDet.id);
    const currId = props.currentMapDet.id;
    console.log(props.mappingDiagrams)
    const [currentMap, setCurrentMap] = useState([]);

    const currentId = props?.currentMapDet?.id

    useEffect(() => {
        const fetchData = async () => {
            console.log(currentId);
            const id = props.findElementById(props.mappingDiagrams, currentId);
            console.log(id);
            console.log(currentMap.flowlineMap);
            setCurrentMap(id);
        };
        fetchData();
    }, []);

    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[30vw]">

                    <div className="bg-white shadow-xl rounded-lg sm:max-w-lg overflow-hidden text-left transition-all transform">
                        <div className="bg-white sm:p-6 px-4 pt-5 pb-4 w-[400px] h-[220px] overflow-x-hidden overflow-y-auto">

                            <div className="sm:flex sm:items-start">
                                <ul>
                                    {currentMap?.flowlineMap && currentMap?.flowlineMap.length !== 0 && (
                                        <ul>
                                            {currentMap.flowlineMap.map((item, index) => {
                                                return (
                                                    (item.parentActivityId === props.editElementObj.element.businessObject.$attrs.parentActivityId &&
                                                        item.originMapId === currId)
                                                        && props.verifyTargetId(item.targetMapId, item.targetActivityId) ?
                                                        <div className="flex justify-between items-center shadow-sm mb-2 p-2 border border-gray-300 rounded w-[320px] h-9" key={index}>
                                                            <ul className="flex items-center">
                                                                <img src={flowLine} className="mr-4 h-[25px]" alt="Flow Line" />
                                                                <li
                                                                    style={{ listStyle: 'none', textDecoration: 'underline', textDecorationColor: 'blue', color: 'blue', fontSize: '10px' }}
                                                                    className="cursor-pointer list-disc list-inside"
                                                                    onClick={() => props.handleFlowlineClick(item.targetMapId, item, 'target')}>
                                                                    {/* Target Link To: (Diagram: {item.targetMapId}, Activity Number: {`${item.TargetAutoNumCount},Description:${item?.TargetFullnameText ? item.TargetFullnameText.substring(0, 25) : ''}`}) */}
                                                                    {BPMN_Common_Labels._GET_START_FLOWLINK_LIST_LABEL(item)}
                                                                </li>
                                                            </ul>
                                                            {(props.fromViewer || window.localStorage.getItem('userRole') === 'Admin') ? null :
                                                                <span style={{ color: "grey", cursor: 'pointer' }} onClick={() => props.handleDeleteFlowActivity(index, currId, item)}><FaTrash size={'14px'} /></span>
                                                            }
                                                        </div> :
                                                        ((item.parentActivityId === props.editElementObj.element.businessObject.$attrs.parentActivityId) &&
                                                            <div>
                                                                <div className="flex justify-between items-center shadow-sm mb-2 p-2 border border-gray-300 rounded w-[320px] h-9 text-sm" key={index}>
                                                                    <span title={BPMN_Common_Labels._GET_START_FLOWLINK_LIST_LABEL(item)} style={{ color: "red" }}>{BPMN_Common_Labels._LinkageBroken}</span>
                                                                    {props.fromViewer ? null :
                                                                        <span style={{ color: "grey", cursor: 'pointer' }} onClick={() => props.handleExpiredDeleteFlowActivity(index, currId, item)}><FaTrash size={'14px'} /></span>
                                                                    }
                                                                </div>
                                                            </div>

                                                        )
                                                )
                                            })}
                                        </ul>
                                    )}
                                </ul>
                            </div>
                        </div>
                        <div className="sm:flex sm:flex-row-reverse bg-gray-50 px-4 sm:px-6 py-3">
                            <button onClick={props.closeDialogPopupBox} type="button" className="inline-flex justify-center bg-white hover:bg-gray-50 shadow-sm mt-3 sm:mt-0 sm:ml-3 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-200 focus:ring-offset-2 w-full sm:w-auto font-medium text-gray-700 sm:text-sm text-base">{BPMN_Common_Labels._FLOWLINK_LIST_START_OK_BTN}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export const ActivityFileDocuments = (props) => {
    console.log(props);
    return (

        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[25vw]">
                    <div className="bg-white shadow-xl rounded-lg sm:max-w-lg overflow-hidden text-left transition-all transform">
                        <div className="bg-white w-full">
                            <span className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-opacity-30">
                                <span className="font-medium text-base">{`Documents (${props.selActivityDocFiles?.length})  ${props.selActivityName ? "-" + props.selActivityName : ""} `}</span>
                                <span onClick={props.closeDialogPopupBox} className="cursor-pointer"><IoCloseCircleOutline size={28} /></span>
                            </span>
                            <div className="drop-shadow-lg my-2 px-2 w-full h-[160px] overflow-y-auto">
                                {props.selActivityDocFiles?.map(item =>
                                    <div className="flex items-center shadow-sm my-2 border border-black border-opacity-30 rounded-lg h-[40px]">
                                        <span
                                            className="flex justify-start items-center px-2 w-3/4 text-blue-600 text-base">
                                            <span className="px-2">
                                                <FaRegFilePdf />
                                            </span>
                                            <span title={item.fileName} className="w-[90%] overflow-ellipsis overflow-hidden whitespace-nowrap">
                                                {item.fileName}
                                            </span>
                                        </span>
                                        {props.fromViewer ? null :
                                            <span onClick={() => { props.deleteDocSharePointAPICALL("SINGLE", props.selActivityId, item) }} title={"Delete"} className="flex justify-center items-center bg-gray-400 hover:bg-gray-600 mx-1 rounded-full w-[25px] h-[25px] cursor-pointer">
                                                <MdOutlineDelete size={16} color="white" />
                                            </span>
                                        }
                                        <span onClick={() => { props.downloadDocSharePointAPICALL("PREVIEW", item) }} title={"Preview"} className="flex justify-center items-center bg-gray-400 hover:bg-gray-600 mx-1 rounded-full w-[25px] h-[25px] cursor-pointer"
                                        >
                                            <MdOutlineRemoveRedEye size={16} color="white" />
                                        </span>
                                        <span onClick={() => { props.downloadDocSharePointAPICALL("DOWNLOAD", item) }} title={"Download"} className="flex justify-center items-center bg-gray-400 hover:bg-gray-600 mx-1 rounded-full w-[25px] h-[25px] cursor-pointer"
                                        >
                                            <HiOutlineDownload size={16} color="white" />
                                        </span>
                                    </div>)
                                }
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export const AddEditMapDiagramPOPUP = (props) => {
    const org = localStorage.getItem('organization') === 'iGO Solutions' ? true : false;
    const loginEnterBtnHandle = (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            if (props.isEditMap) {
                props.onMapDiagramEditOnClick(event);
            } else {
                console.log('#454 TEST AddEditMapDiagramPOPUP')
                console.log("add", props);
                props.onMapDiagramAddOnClick(event);

            }
        }
    };

    useEffect(() => {
        document.addEventListener("keydown", loginEnterBtnHandle, false)
        return () => {
            document.removeEventListener("keydown", loginEnterBtnHandle, false);
        };
    }, [props.mapDiagramRecord]);

    // const options = props.projectsData.map(project => ({
    //     value: project.projectName,
    //     label: project.projectName,
    //     id: project.id,
    //     customerId: project.customerId,
    //     customerName: project.customerName
    // }));
    const options = [{
        value: props?.mapDiagramRecord?.project.projectName,
        label: props?.mapDiagramRecord?.project.projectName,
        id: props?.mapDiagramRecord?.project.id,
        customerId: props?.mapDiagramRecord?.project.customerId,
        customerName: props?.mapDiagramRecord?.project.customerName
    }];


    const selectedOption = props?.mapDiagramRecord?.project ? options.find(option => option.value === props.mapDiagramRecord.project.projectName) || null : null;

    // const optionsImport = props.projectsDataContainer.map(project => ({
    //     value: project.projectName,
    //     label: project.projectName,
    //     id: project.id,
    //     customerId: project.customerId,
    //     customerName: project.customerName
    // }));
    const selectedOptionImport = props?.mapDiagramRecord?.project ? options.find(option => option.value === props.mapDiagramRecord.project.projectName) || null : null;
    return (
        <>
            {
                (!props?.isSpecificUsersEnable) ?
                    <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                        <div className="flex justify-center items-center w-full h-full">
                            <div className="w-[30vw]">
                                <div className="bg-white border-box rounded-md font-sans text-gray-900">
                                    <div className="flex justify-center mx-auto w-full sm:max-w-lg">
                                        <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                            <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                                <span className="font-semibold text-lg">
                                                    {props.isEditMap ? "Edit Map" : "Create Map"}
                                                </span>
                                                <span className="hover:bg-gray-200 p-[2px] rounded" onClick={props.closeAddEditPOPUP}>
                                                    <MdOutlineClose size={22} />
                                                </span>
                                            </div>
                                            <div className="mt-1 w-[80%]">
                                                <div className="md:items-center mb-2">
                                                    <div className="mb-2">
                                                        <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                            {BPMNEditor_Labels._MAP_NAME}
                                                        </label>
                                                    </div>
                                                    <div className="w-full">
                                                        <input
                                                            className={ControlsConstants.TextBox.textBoxDefault}
                                                            id="diagramName"
                                                            name="diagramName"
                                                            type="text"
                                                            value={props.mapDiagramRecord.diagramName}
                                                            onChange={props.addEditMapDiagramOnChange}
                                                            placeholder={BPMNEditor_Labels._MAP_NAME_PLACEHOLDER}
                                                            autoComplete="off"
                                                            autoFocus={true}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="mt-1 w-[80%]">
                                                <div className="md:items-center mb-2">
                                                    <div className="mb-2">
                                                        <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                            {BPMNEditor_Labels._CHOOSE_STORAGE_LOCATION} :
                                                        </label>
                                                    </div>
                                                    <div className="ml-16 w-full">
                                                        <div className="items-center mr-2">
                                                            <input
                                                                className="border border-gray-300 w-4 h-4"
                                                                id="database"
                                                                name="database"
                                                                type="checkbox"
                                                                value="database"
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "docStorageType")}
                                                                checked={props.mapDiagramRecord.docStorageType === "database"}
                                                                disabled={props?.isEditMap}
                                                            />
                                                            <label
                                                                htmlFor="database"
                                                                className={`ml-2 ${props.mapDiagramRecord.docStorageType === "database" ? " text-blue-500 font-medium " : " text-opacity-40 text-black  font-normal "}  text-sm`}
                                                            >
                                                                {BPMNEditor_Labels._APPLICATION_STORAGE}
                                                            </label>
                                                        </div>
                                                        <div className="items-center mr-2">
                                                            <input
                                                                id="sharepoint"
                                                                type="checkbox"
                                                                name="sharepoint"
                                                                className="border border-gray-300 w-4 h-4"
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "docStorageType")}
                                                                checked={props.mapDiagramRecord.docStorageType === "sharepoint"}
                                                                disabled={props?.isEditMap}
                                                            />
                                                            <label
                                                                htmlFor="sharepoint"
                                                                className={`ml-2 ${props.mapDiagramRecord.docStorageType === "sharepoint" ? " text-blue-500 font-medium " : " text-opacity-40 text-black  font-normal "}  text-sm`}
                                                            >
                                                                {BPMNEditor_Labels._SHAREPOINT}
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {props.mapDiagramRecord.docStorageType === "sharepoint" && (
                                                <div className="mt-1 w-[80%]">
                                                    <div className="flex justify-center mb-2">
                                                        <Select
                                                            styles={ReactSelect.dropDownStylesOrangeBig}
                                                            name="sharepointConfig"
                                                            components={{
                                                                DropdownIndicator: DropdownIndicator,
                                                                IndicatorSeparator: () => null,
                                                            }}
                                                            id="sharepointConfig"
                                                            placeholder={BPMNEditor_Labels._SHAREPOINT_PLACEHOLDER}
                                                            options={props.sharepointConfigOptions}
                                                            onChange={props.addEditMapDiagramOnChange}
                                                            value={
                                                                props.mapDiagramRecord.configId === "" || props.mapDiagramRecord.configId === null
                                                                    ? null
                                                                    : props.sharepointConfigOptions?.find((option) => option.value === props.mapDiagramRecord.configId)
                                                            }
                                                            isDisabled={props?.isEditMap}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                            {/* {implementation for project organization} */}
                                            {org ? <div className="mt-1 w-[80%]">
                                                <div className="md:items-center mb-2">
                                                    <div className="mb-2">
                                                        <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                            {BPMNEditor_Labels._PROJECTS}
                                                        </label>
                                                    </div>
                                                    <div className="w-full">

                                                        <Select
                                                            styles={ReactSelect.dropDownStylesForm}
                                                            class="block mb-2 p-3 border border-grey-light w-full h-10"
                                                            name='organization'
                                                            components={{ DropdownIndicator, IndicatorSeparator: () => null }}
                                                            id='selected_datasource'
                                                            placeholder={Users_Labels._PROJECT_PLACEHOLDER}
                                                            options={props.projectsData.map(project => ({
                                                                // value: `${project.projectName}-${project.customerName}`,
                                                                label: `${project.customerName}-${project.projectName}`,
                                                                value: project.projectName,
                                                                //  label: project.projectName,
                                                                id: project.id,
                                                                customerId: project.customerId,
                                                                customerName: project.customerName
                                                            }))}
                                                            onChange={(e) => props.addEditMapDiagramOnChange(e, null, "project")}
                                                            //    value={filterArray.filter(option => option.value === props?.mapDiagramRecord?.project?.projectName)}
                                                            value={selectedOption}
                                                            isDisabled={props?.isEditMap}
                                                        />
                                                    </div>
                                                </div>
                                            </div> : <div className="mt-1 w-[80%]">
                                                <div className="md:items-center mb-2">
                                                    <div className="mb-2">
                                                        <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                            {BPMNEditor_Labels._PROJECTS}
                                                        </label>
                                                    </div>
                                                    <div className="w-full">

                                                        <Select
                                                            styles={ReactSelect.dropDownStylesForm}
                                                            class="block mb-2 p-3 border border-grey-light w-full h-10"
                                                            name='organization'
                                                            components={{ DropdownIndicator, IndicatorSeparator: () => null }}
                                                            id='selected_datasource'
                                                            placeholder={Users_Labels._PROJECT_PLACEHOLDER}
                                                            options={props.projectsDataContainer.map(project => ({
                                                                label: `${project.customerName}-${project.projectName}`,
                                                                value: project.projectName,
                                                                id: project.id,
                                                                customerId: project.customerId,
                                                                customerName: project.customerName
                                                            }))}
                                                            onChange={(e) => props.addEditMapDiagramOnChange(e, null, "project")}
                                                            //    value={filterArray.filter(option => option.value === props?.mapDiagramRecord?.project?.projectName)}
                                                            value={selectedOptionImport}
                                                            isDisabled={props?.isEditMap}
                                                        />
                                                    </div>
                                                </div>
                                            </div>}

                                            <div className="mt-1 w-[80%]">
                                                <div className="md:items-center mb-2">
                                                    <div className="mb-2">
                                                        <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                                                            {BPMNEditor_Labels._CHOOSE_PRIVACY_TYPE} :
                                                        </label>
                                                    </div>
                                                    <div className="flex justify-between ml-2 w-full">
                                                        <div className="items-center mr-2">
                                                            <input
                                                                className="border border-gray-300 w-4 h-4"
                                                                id="public"
                                                                name="public"
                                                                type="checkbox"
                                                                value="public"
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                checked={props.mapDiagramRecord.mapPrivacyType === "public"}
                                                            // disabled={props?.isEditMap}
                                                            />
                                                            <label
                                                                htmlFor="public"
                                                                className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "public" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                            >
                                                                {BPMNEditor_Labels._PRIVACY_PUBLIC}
                                                            </label>
                                                        </div>
                                                        <div className="items-center mr-2">
                                                            <input
                                                                id="private"
                                                                type="checkbox"
                                                                name="private"
                                                                className="border border-gray-300 w-4 h-4"
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                checked={props.mapDiagramRecord.mapPrivacyType === "private"}
                                                            // disabled={props?.isEditMap}
                                                            />
                                                            <label
                                                                htmlFor="private"
                                                                className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "private" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                            >
                                                                {BPMNEditor_Labels._PRIVACY_PRIVATE}
                                                            </label>
                                                        </div>
                                                        <div className="items-center mr-2">
                                                            <input
                                                                id="specific"
                                                                type="checkbox"
                                                                name="specific"
                                                                className="border border-gray-300 w-4 h-4"
                                                                onChange={(e) => props.addEditMapDiagramOnChange(e, null, "mapPrivacyType")}
                                                                checked={props.mapDiagramRecord.mapPrivacyType === "specific"}
                                                            // disabled={props?.isEditMap}
                                                            />
                                                            <label
                                                                htmlFor="specific"
                                                                className={`ml-2 ${props.mapDiagramRecord.mapPrivacyType === "specific" ? "" : "text-opacity-30"} text-black text-sm font-normal`}
                                                            >
                                                                {BPMNEditor_Labels._PRIVACY_SPECIFIC}
                                                            </label>
                                                            {props.mapDiagramRecord.mapPrivacyType === "specific" ?
                                                                <div onClick={props.toggleSpecificUsersFlag}
                                                                    className="ml-4 font-medium text-blue-500 text-base decoration-blue-700 underline cursor-pointer">
                                                                    {props?.mapDiagramRecord?.mapAuthorizedUsers?.length !== 0 ? props?.mapDiagramRecord?.mapAuthorizedUsers?.length + BPMNEditor_Labels._SPECIFIC_TITLE_USER_ASSIGNED : BPMNEditor_Labels._SPECIFIC_TITLE_ASSIGN_USERS}
                                                                </div>
                                                                : null}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md">
                                                <button onClick={props.closeAddEditPOPUP} className={`${ControlsConstants.Responsive.btnResponsive.btn_success} px-8`}>
                                                    Cancel
                                                </button>
                                                {props?.isEditMap ? (
                                                    <button onClick={props.onMapDiagramEditOnClick} className={`${ControlsConstants.Responsive.btnResponsive.btn_warning} px-[50px]`}>
                                                        Update
                                                    </button>
                                                ) : (
                                                    <button onClick={props.onMapDiagramAddOnClick} className={`${ControlsConstants.Responsive.btnResponsive.btn_warning} px-[50px]`}>
                                                        Create
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    :
                    <AssignUsers
                        isEditMap={props.isEditMap}
                        allUsers={props.allUsers}
                        selectedUsers={props.mapDiagramRecord?.mapAuthorizedUsers}
                        toggleSpecificUsersFlag={props.toggleSpecificUsersFlag}
                        assignEditUsersOnClick={props.addEditMapDiagramOnChange}
                    />
            }
        </>
    );
};
export const DownloadDiagramPOPUP = (props) => {
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[30vw]">
                    <div class="bg-white border-box rounded-md font-sans text-gray-900">
                        <div class="flex justify-center mx-auto w-full sm:max-w-lg">
                            <div class="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                    <span className="font-semibold text-lg">
                                        {props.isPrint ? BPMN_Common_Labels._CHOOSE_PRINT_OPTION : props.isFromUpload ? BPMN_Common_Labels._CHOOSE_UPLOAD_OPTION : BPMN_Common_Labels._CHOOSE_DOWNLOAD_OPTION}
                                    </span>
                                    <span className="hover:bg-gray-200 p-[2px] rounded"
                                        onClick={props.closeDialogPopupBox}
                                    >
                                        <MdOutlineClose size={22} />
                                    </span>
                                </div>
                                <div className="mt-1 w-[80%]">
                                    <div class="items-center mb-2">
                                        <input
                                            class="bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2 dark:ring-offset-gray-800 w-4 h-4 text-blue-600"
                                            id="CurrentLevel"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentLevel" class="ms-2 ml-2 font-medium text-gray-900 text-sm">{BPMN_Common_Labels._CURRENT_DIAGRAM}</label>
                                    </div>
                                    <div class="items-center mb-2">
                                        <input
                                            class="bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2 dark:ring-offset-gray-800 w-4 h-4 text-blue-600"
                                            id="CurrentAndLower"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentAndLower" class="ms-2 ml-2 font-medium text-gray-900 text-sm">{BPMN_Common_Labels._CURRENT_AND_LOWER_DIAGRAM}</label>
                                    </div>
                                    <div class="items-center">
                                        <input
                                            class="bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2 dark:ring-offset-gray-800 w-4 h-4 text-blue-600"
                                            id="CurrentProcessMap"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            defaultChecked={true}
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentProcessMap" class="ms-2 ml-2 font-medium text-gray-900 text-sm">{BPMN_Common_Labels._CURRENT_PROCESS_MAP}</label>
                                    </div>

                                </div>
                                <div class='flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md'>
                                    <button
                                        class={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8"}
                                        onClick={props.closeDialogPopupBox}>
                                        {BPMN_Common_Labels._UPLOADDOWNLOAD_CANCEL_BTN}
                                    </button>
                                    <button class={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-[50px]"} onClick={props.isPrint ? props.handlePrint : props.isFromUpload ? props.openBpmnFileUpload : props.downloadBPMN_OnClick} >{props.isPrint ? "Print" : props.isFromUpload ? "Upload" : "Download"}</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const AssignReviewierName = (props) => {

    const options = props.ReviewerData
        ? props.ReviewerData.map((dropdown) => ({
            value: dropdown.userId,
            label: dropdown.userName
        }))
        : [];
    const defaultValue = options?.filter(ele => props?.Reviewername?.find(el => el.label === ele.label && el.value === ele.value))

    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="flex flex-col justify-around bg-white px-4 py- border-box rounded-md w-[28vw] h-[250px] font-sans text-gray-900">
                    <div className="sm:col-span-3">
                        <label htmlFor="resourceName" className="block font-medium text-gray-900 text-sm leading-6">
                            {BPMNEditor_Labels._ASSIGN_REVIEWER}
                        </label>
                        <div className="mt-3">
                            <div className="relative w-full min-w-[250px] h-10">
                                <Select
                                    onChange={props.onChangeReviewerSelect}
                                    options={options}
                                    value={defaultValue}
                                    isMulti
                                />
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-center space-x-1 mt-2">
                        <button
                            className="px-2 py-2 border border-black border-opacity-30 rounded-md w-28 text-blue-600"
                            onClick={props.closeDialogPopupBox}
                        >
                            {BPMNEditor_Labels._CANCEL_BTN}
                        </button>
                        <button
                            className="px-2 py-2 border border-black border-opacity-30 rounded-md w-28 text-blue-600"
                            onClick={() => props.draftMapStatusChnageOnClick('InReview', BPMN_Editor_Toaster.Map_Successfully_Sent_To_Reviewer)}
                        >
                            {BPMNEditor_Labels._SEND_BTN}
                        </button>
                    </div>
                </div>
            </div>
        </div>


    );
}


export const CommentsIcon = (props) => {
    const [showDot, setShowDot] = useState(true);
    const findUnreadStatus = (role) => {
        const CommentsReceiverFinder = props?.CommentsReaderStorage?.find(el => el.userRole === role);
        // console.log("CommentsReceiverFinder:", CommentsReceiverFinder);
        return CommentsReceiverFinder?.userReadStatuses?.some(el => el.isRead === false);
    };

    useEffect(() => {
        if (props.Role) {
            const role = props.Role === "Editor" ? "Reviewer" : "Editor";
            setShowDot(findUnreadStatus(role));
        }
    }, [props.Role, props.CommentsReaderStorage]);

    const handleDotClick = () => {
        setShowDot(false);
    };

    const hasComments = props?.getcomment?.length > 0;
    const shouldShowDot = showDot && hasComments;

    return (
        <div className="inline-block relative" onClick={handleDotClick}>
            <TfiComments size={25} color={props.color} />
            {shouldShowDot && (
                <span className="top-0 right-0 absolute bg-blue-500 rounded-full w-3 h-3 -translate-y-1/2 translate-x-1/2 transform"></span>
            )}
        </div>
    );
};

export const CommentBoxPOPUP = (props) => {
    const componentRef = useRef();
    const scrollRef = useRef();
    const loggedOnUser = window.localStorage.getItem("userName");
    const role = window.localStorage.getItem("userRole");
    const [digLevel, setDigLevel] = useState({
        level: "",
        autoNum: ''
    })
    const [isSendingMailFlag, setIsSendingMailFlag] = useState(false);
    const [isDeleteEnable, setisDeleteEnable] = useState(false);
    const Role = window.localStorage.getItem("userRole");
    const [receipients, setReceipients] = useState([]);
    let mappingReviewerRes = [], mappingSpecificRes = [];
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
        if (props.getActivity !== '' && props.getActivity !== undefined) {
            setDigLevel({
                level: props.currentMapDet.id,
                autoNum: props.getActivity,
                activityId: props.getActivityElementId,
            })
        }
        else {
            setDigLevel({
                level: '',
                autoNum: '',
                activityId: ''
            })
        }
    }, [props.comment, props.getActivity]);
    const handleChangeReceipients = (selected) => {
        setReceipients(selected)
    };
    const handleCancelMailClick = () => {
        setIsSendingMailFlag(false)
        setReceipients([])
    };

    const handleSendGroupedMailClick = async () => {
        if (receipients.length === 0) {
            ErrorMessage("Please select a receipient and proceed further");
            return;
        }
        if (props?.getcomment.length === 0) {
            ErrorMessage("Please add a comment and proceed further");
            return;
        }

        setIsSendingMailFlag(false)
        // emailBody: (comment.currentXmlId!=='' && comment.activityNum!=='' && comment.activityNum!==0) ? `${comment.currentXmlId}:${comment.activityNum} ${comment.commentMessage}`:comment.commentMessage,

        const constructComment = props?.getcomment?.map(el => (
            {
                commentMessage: (el.currentXmlId !== '' && el.activityNum !== '' && el.activityNum !== 0) ? `${el.currentXmlId}:${el.activityNum} ${el.commentMessage}` : el.commentMessage,
                timeStamp: el.timeStamp.split('T')[0] + ' ' + el.timeStamp.split('T')[1].slice(0, 5),
                userName: el.userName,
                commentedUserId: el.commentedUserId
            }
        ));

        const reqPayload = {
            recipients: receipients.map(el => ({ userId: el.value })),
            senderUserId: localStorage.getItem('userid'),
            emailBody: constructComment,
            diagramName: props.mapDiagramRecord.diagramName
        }
        console.log("🚀 ~ handleSendMailClick ~ reqPayload:", reqPayload)
        const res = await BPMNService.groupCommentsPdf(reqPayload)
        try {
            if (res.status === 200 || res.status === 201) {
                SuccessMessage("Mail sent successfully")
                setReceipients([])
            }
        } catch (error) {
            ErrorMessage("Error while sending mail");
            return;
        }
    };
    if (isSendingMailFlag) {
        if (localStorage.getItem('userRole') === 'Reviewer') {
            mappingReviewerRes = props.mapDiagramRecord?.assignedUsers?.filter(item => item.assignedUserId + '' !== localStorage.getItem('userid'))
        }
        if (props.mapDiagramRecord.mapPrivacyType === 'private') {
            mappingReviewerRes = props.mapDiagramRecord?.assignedUsers?.filter(item => item.assignedUserId + '' !== localStorage.getItem('userid'))
        }
        if (props.mapDiagramRecord.mapPrivacyType === 'specific') {
            console.log(props.mapDiagramRecord);
            const constructObj = {
                userId: Number(props.mapDiagramRecord.authorUserId),
                email: '',
                name: props.mapDiagramRecord.author
            }
            mappingSpecificRes = [...props.mapDiagramRecord?.mapAuthorizedUsers, constructObj]?.filter(item => item.userId + '' !== localStorage.getItem('userid'))
            console.log("🚀 ~ CommentBoxPOPUP ~ mappingSpecificRes:", mappingSpecificRes)
        }
    }

    return (
        <div className="flex w-[25em] h-[35em] text-gray-800 antialiased">
            <div className="flex flex-row w-full h-full overflow-hidden">
                <div className="flex flex-col flex-auto p-6 h-full">
                    <div className="relative flex flex-col flex-shrink-0 flex-auto bg-gray-100 p-4 rounded-2xl h-full">
                        <div className="border-y-gray-950 h-[20px]">
                            <div className="top-2 right-2 z-10 absolute flex items-center space-x-2 border-yellow-300">
                                {/* email */}
                                {(localStorage.getItem('userRole') !== 'Admin') && <div className="relative flex justify-end w-[100px]">
                                    <div
                                        className="text-gray-600 hover:text-gray-800 cursor-pointer"
                                        onClick={() => setIsSendingMailFlag(true)}
                                        title="Grouped Comments"
                                    >
                                        <CiMail size={20} color='#4B5563' />
                                    </div>
                                    {isSendingMailFlag && (
                                        <div className="z-50 absolute bg-white shadow-lg mt-2 border border-gray-300 rounded-lg" style={{ width: '250px' }}>
                                            <div className="p-2">
                                                <Select
                                                    className=""
                                                    id="selected_datasource"
                                                    placeholder={Users_Labels._SELECT_recipients}
                                                    options={localStorage.getItem('userRole') === 'Reviewer' ? mappingReviewerRes.map(item => ({
                                                        value: item.assignedUserId,
                                                        label: item.assignedUser
                                                    })) :
                                                        props?.mapDiagramRecord?.mapPrivacyType === 'public' ? props?.publicUsers?.map(item => ({
                                                            value: item.userId,
                                                            label: item.userName ? item.userName : item.name
                                                        })) : props?.mapDiagramRecord?.mapPrivacyType === 'private' ? props.mapDiagramRecord?.mapAuthorizedUsers?.map(item => ({
                                                            value: item.userId,
                                                            label: item.userName ? item.userName : item.name
                                                        })) :
                                                            mappingSpecificRes?.map(item => ({
                                                                value: item.userId,
                                                                label: item.userName ? item.userName : item.name
                                                            }))
                                                    }
                                                    onChange={handleChangeReceipients}
                                                    isMulti
                                                />
                                            </div>
                                            <div className="flex justify-end space-x-2 p-1">
                                                <button
                                                    onClick={handleSendGroupedMailClick}
                                                    className="text-blue-500 hover:text-blue-600"
                                                    title="Send"
                                                >
                                                    <IoSend size={16} />
                                                </button>
                                                <button
                                                    onClick={handleCancelMailClick}
                                                    className="text-red-500 hover:text-red-600"
                                                    title="Cancel"
                                                >
                                                    <FcCancel size={16} />
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>}
                                {!(props.mapStatus === 'Published' || props.mapStatus === 'Approved') && (localStorage.getItem('userRole') !== 'Admin') && <div
                                    className="text-gray-600 hover:text-gray-800 cursor-pointer"
                                    onClick={() => setisDeleteEnable(true)}
                                    title="Delete all comments"
                                >
                                    <IoTrashBin size={17} color={'grey'} />
                                </div>}
                                <ReactToPrint
                                    trigger={() => (
                                        <button className="text-gray-600 hover:text-gray-800" title="Print">
                                            <IoPrintOutline size={20} />
                                        </button>
                                    )}
                                    content={() => componentRef.current}
                                />
                                <div
                                    className="text-gray-600 hover:text-gray-800 cursor-pointer"
                                    onClick={props.closeDialogPopupBox}
                                    title="Close"
                                >
                                    <MdOutlineClose size={20} />
                                </div>
                                {isDeleteEnable ?
                                    <div className="top-0 right-0 bottom-0 left-0 z-[1100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                                        <div className="flex justify-center items-center w-full h-full">
                                            <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[25vw] h-[100px] font-sans text-gray-900">
                                                <h1>{BPMN_Common_Labels._ARE_YOU_SURE_WANT_TO_DELETE_COMMENTS}</h1>
                                                <div class="flex justify-center space-x-2">
                                                    <button
                                                        class="px-2 py-1 border border-black border-opacity-30 rounded-md w-20 text-blue-600"
                                                        //   onClick={() => setIsDeleteEnable(false)}
                                                        onClick={() => setisDeleteEnable(false)}
                                                    >
                                                        {Resource_Label._CANCEL_BTN}
                                                    </button>
                                                    <button
                                                        className="bg-blue-500 px-2 py-1 rounded-md w-20 text-white"
                                                        onClick={() => {
                                                            setisDeleteEnable(false);
                                                            props.deleteAllComments(); // Call the function here
                                                        }}
                                                    >
                                                        {Resource_Label._OK_BTN} {/* Display the button text */}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    : null}
                            </div>
                        </div>
                        <div className="flex flex-col h-full overflow-y-auto" ref={scrollRef}>
                            <div className="flex flex-col h-full">
                                <div className="flex flex-col space-y-2" ref={componentRef}>
                                    {props?.getcomment?.map((x, index) => {
                                        const isLoggedOnUser = x.userName === loggedOnUser && ["InProgress", "InReview"].includes(props.mapStatus) && (!props.isMapLocked)
                                        return (
                                            <div key={index} className={`flex ${isLoggedOnUser ? 'justify-end' : 'justify-start'} w-full`}>
                                                <div className={`flex ${isLoggedOnUser ? 'flex-row-reverse' : 'flex-row'} items-center w-full max-w-[90%]`}>
                                                    {!isLoggedOnUser && (
                                                        <div
                                                            className={`flex items-center justify-center h-10 w-10 rounded-full ${isLoggedOnUser ? 'bg-cyan-500' : 'bg-blue-500'} text-white flex-shrink-0`}
                                                        >
                                                            {x.userName.charAt(0).toUpperCase()}
                                                        </div>
                                                    )}
                                                    <CommentItem
                                                        key={index}
                                                        loggedOnUser={loggedOnUser}
                                                        comment={x}
                                                        index={index}
                                                        isLoggedOnUser={isLoggedOnUser}
                                                        onEditComment={props.handleCommentsEdit}
                                                        onDeleteComment={props.handleCommentsDelete}
                                                        handleCommentsClick={props.handleCommentsClick}
                                                        role={role}
                                                        mapDiagramRecord={props.mapDiagramRecord}
                                                        publicUsers={props.publicUsers}
                                                    />
                                                </div>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        </div>
                        {((!props.isMapLocked) && ((Role === "Reviewer" || Role === "Editor") && (["InReview", "InProgress"].includes(props.mapStatus)))) && (
                            <div className="items-start bg-white p-1 rounded-xl w-full h-30">
                                {(props.getActivity !== '' && props.getActivity !== undefined && digLevel.autoNum !== '' && props.comment) && <div className="flex-shrink-0 p-1">
                                    <input
                                        type="text"
                                        className="m-1 text-blue-700"
                                        value={`${props.currentMapDet.id}:${props.getActivity}`}
                                        readOnly
                                    />
                                </div>}
                                <div className="flex flex-grow items-center">
                                    <textarea
                                        style={{ maxHeight: '60px', padding: '5px' }}
                                        rows={1}
                                        cols={30}
                                        onChange={props.onChangeComments}
                                        value={props.comment}
                                        className="pl-2 border focus:border-indigo-300 rounded-xl focus:outline-none w-full h-10 resize-none"
                                    />
                                    {props?.comment && (
                                        <div className="flex items-center mt-2 ml-1">
                                            <button
                                                className="flex justify-center items-center bg-indigo-500 hover:bg-indigo-600 px-2 py-0.5 rounded-xl h-6 text-white text-sm"
                                                onClick={props.getActivity === 'Process_0tz6k3o' && props.getActivity === '' && props.getActivity === undefined ? () => props.onCommentPostClick : () => {
                                                    props.onCommentPostClick(digLevel)
                                                    setDigLevel({
                                                        level: '',
                                                        autoNum: '',
                                                        activityId: ''
                                                    })
                                                }}
                                            >
                                                <VscSend />
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>

                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};


export const CommentItem = ({ role, comment, index, isLoggedOnUser, onEditComment, onDeleteComment, handleCommentsClick, loggedOnUser, mapDiagramRecord, publicUsers }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [isSendingMail, setIsSendingMail] = useState(false);
    const [editedComment, setEditedComment] = useState(comment.commentMessage);
    const [receipients, setReceipients] = useState([]);
    let mappingReviewerRes = [], mappingSpecificRes = [];

    const handleEditClick = () => {
        if (isLoggedOnUser) {
            setIsEditing(true);
        } else {
            ErrorMessage("You are not authorized to make changes to comments");
            return;
        }
    };

    const handleSaveClick = (comment, index) => {
        onEditComment(comment, editedComment, index);
        setIsEditing(false);
    };

    const handleCancelClick = () => {
        setEditedComment(comment.commentMessage);
        setIsEditing(false);
    };

    const handleCancelMailClick = () => {
        setIsSendingMail(false)
        setReceipients([])
    };

    const handleSendMailClick = async () => {
        if (receipients.length === 0) {
            ErrorMessage("Please select a receipient and proceed further");
            return;
        }
        setIsSendingMail(false);
        const reqPayload = {
            recipients: receipients.map(el => ({ userId: el.value })),
            senderUserId: localStorage.getItem('userid'),
            emailBody: (comment.currentXmlId !== '' && comment.activityNum !== '' && comment.activityNum !== 0) ? `${comment.currentXmlId}:${comment.activityNum} ${comment.commentMessage}` : comment.commentMessage,
            diagramName: mapDiagramRecord.diagramName
        }
        console.log("🚀 ~ handleSendMailClick ~ reqPayload:", reqPayload)
        const res = await BPMNService.sendCommentsviaMail(reqPayload)
        try {
            setReceipients([])
            if (res.status === 200 || res.status === 201) {
                SuccessMessage("Mail sent successfully")
            }
        } catch (error) {
            ErrorMessage("Error while sending mail");
            return;
        }

    };
    const handleChangeReceipients = (selected) => {
        console.log(selected);
        setReceipients(selected)
    };
    if (isSendingMail) {
        if (localStorage.getItem('userRole') === 'Reviewer') {
            mappingReviewerRes = mapDiagramRecord?.assignedUsers?.filter(item => item.assignedUserId + '' !== localStorage.getItem('userid'))
        }
        if (mapDiagramRecord.mapPrivacyType === 'private') {
            mappingReviewerRes = mapDiagramRecord?.assignedUsers?.filter(item => item.assignedUserId + '' !== localStorage.getItem('userid'))
        }
        if (mapDiagramRecord.mapPrivacyType === 'specific') {

            const constructObj = {
                userId: Number(mapDiagramRecord.authorUserId),
                email: '',
                name: mapDiagramRecord.author
            }
            mappingSpecificRes = [...mapDiagramRecord?.mapAuthorizedUsers, constructObj].filter(item => item.userId + '' !== localStorage.getItem('userid'))
            console.log("🚀 ~ CommentBoxPOPUP ~ mappingSpecificRes:", mappingSpecificRes)
        }
    }


    return (
        <div className={`relative ml-2 text-sm ${isLoggedOnUser ? 'bg-green-100' : 'bg-white'} py-2 px-4 shadow rounded-xl mb-4 break-words whitespace-pre-wrap mr-3`}>
            <div className="flex justify-between">
                <span className="text-[11px] text-blue-500">
                    {comment.userName?.split(' ')
                        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                        .join(' ') + ' ' + comment.timeStamp.split('T')[0] + ' ' + comment.timeStamp.split('T')[1].slice(0, 5)}
                </span>
                {/* <span className="text-[9px] text-blue-500">{'  '+}</span> */}
                {isLoggedOnUser && (
                    <div className="flex items-center ml-3">
                        {(!isEditing && !isSendingMail) ? (
                            <>
                                <button onClick={() => setIsSendingMail(true)} className="ml-2 pr-2" title="Email">
                                    <FaMailBulk color='green' />
                                </button>
                                <button onClick={handleEditClick} className="ml-1" title="Edit">
                                    <FaRegEdit color='blue' />
                                </button>
                                <button onClick={() => {
                                    if (!isLoggedOnUser) {
                                        ErrorMessage("You are not authorized to delete the comments");
                                        return;
                                    } else {
                                        onDeleteComment(comment, index);
                                    }
                                }} className="ml-2" title="Delete">
                                    <IoTrashOutline color='red' />
                                </button>
                            </>
                        ) : !isSendingMail ? (
                            <>
                                <button onClick={() => handleSaveClick(comment, index)} className="ml-1" title="Save">
                                    <IoIosSave color='green' />
                                </button>
                                <button onClick={handleCancelClick} className="ml-2" title="Cancel">
                                    <FcCancel />
                                </button>
                            </>
                        ) : null}
                    </div>
                )}
            </div>

            <div className="relative flex justify-between items-start rounded-lg">
                {!isSendingMail && !isEditing && comment.activityNum !== 0 && comment.activityNum !== "" && (
                    <span className='pr-2 text-blue-500 underline cursor-pointer' onClick={() => handleCommentsClick(comment, index)}>
                        {comment.currentXmlId}:{comment.activityNum}
                    </span>
                )}

                {isEditing ? (
                    <textarea
                        value={editedComment}
                        onChange={(e) => setEditedComment(e.target.value)}
                        className="mt-2 p-2 border rounded-lg w-full"
                    />
                ) : null}
                {(!isEditing && !isSendingMail) && (
                    <span className="flex-1 mr-2">{comment.commentMessage}</span>
                )}
                {isSendingMail ? (
                    <>
                        <div className="mt-1 w-full">
                            <Select
                                className="z-50 mb-3"
                                id='selected_datasource'
                                placeholder={Users_Labels._SELECT_recipients}
                                // options={mapDiagramRecord?.
                                //     mapAuthorizedUsers
                                //     ?.map(item => ({
                                //         value: item.userId,
                                //         label: item.name
                                //     }))}
                                options={localStorage.getItem('userRole') === 'Reviewer' ? mappingReviewerRes.map(item => ({
                                    value: item.assignedUserId,
                                    label: item.assignedUser
                                })) : mapDiagramRecord?.mapPrivacyType === 'public' ? publicUsers?.map(item => ({
                                    value: item.userId,
                                    label: item.userName ? item.userName : item.name
                                })) : mapDiagramRecord?.mapPrivacyType === 'private' ?
                                    mapDiagramRecord?.mapAuthorizedUsers?.map(item => ({
                                        value: item.userId,
                                        label: item.userName ? item.userName : item.name
                                    })) : mappingSpecificRes.map(item => ({
                                        value: item.userId,
                                        label: item.userName ? item.userName : item.name
                                    }))
                                }
                                onChange={handleChangeReceipients}
                                isMulti
                            />
                        </div>
                        <div className="flex justify-end mt-2">
                            <button onClick={handleSendMailClick} className="ml-2 text-blue-500" title="Send">
                                <IoSend size={16} />
                            </button>
                            <button onClick={handleCancelMailClick} className="ml-2 text-red-500" title="Cancel">
                                <FcCancel size={16} />
                            </button>
                        </div>
                    </>
                ) : null}
            </div>

            <div className="mt-0" title='navigated'>
                {comment.flagToggleActivity && (
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="14"
                        height="14"
                        viewBox="0 0 48 48"
                        className="right-0 absolute bg-[#083680] rounded-full text-green-500 cursor-pointer"
                    >
                        <path fill="#E6EAF2" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"></path>
                        <path fill="#083680" d="M34.586,14.586l-13.57,13.586l-5.602-5.586l-2.828,2.828l8.434,8.414l16.395-16.414L34.586,14.586z"></path>
                    </svg>
                )}
            </div>
        </div>
    );
};



export const CreateTemplate = (props) => {
    const [isIconsListEnable, setIsIconsListEnable] = useState(false);
    const [isPreviewEnable, setIsPreviewEnable] = useState(false);

    const renderElementsByIconsId = (groupId) => {
        const tempGroupId = isNumber(groupId) ? groupId : parseInt(groupId)
        return navIcons.find(item => item.id === tempGroupId)
    }

    const closetemp = () => {
        console.log(props.newTemplateRecord.iconSource === "userDefined");
        if (props.newTemplateRecord.iconSource === "userDefined") {
            const { navHomeIcon, navPreviousIcon, navUpIcon } = props.newTemplateRecord;
            const icons = [navHomeIcon, navPreviousIcon, navUpIcon];
            const allIconsValid = icons.every(icon => typeof icon === "string" && icon?.includes("base64")); // after v2.0.0 code. typeof issue fixed for base64
            // // console.log("🚀 ~ allIconsValid:", allIconsValid);
            if (!allIconsValid) {
                ErrorMessage(BPMN_Editor_Toaster.Please_Enter_All_Data);
                return;
            }
        }
        setIsIconsListEnable(!isIconsListEnable)
    }
    const previewOpenCloseOnclick = () => {
        setIsPreviewEnable(!isPreviewEnable)

    }
    const parsedNavGroupId = isNumber(props.newTemplateRecord.navHomeIcon) ? props.newTemplateRecord.navHomeIcon : parseInt(props.newTemplateRecord.navHomeIcon)
    console.log(props.newTemplateRecord);
    console.log(props);
    return (
        <>
            {
                (!isPreviewEnable) ?
                    <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                        < div className="flex justify-center items-center w-full h-full" >
                            <div className="w-[40vw]">
                                <div className="bg-white border-box rounded-md font-sans text-gray-900">
                                    <div className="flex justify-center mx-auto w-full sm:max-w-lg">
                                        <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                            <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                                <span className="font-semibold text-lg">
                                                    {props?.isFromEditView ? Default_Template_Labels._EDIT_TEMPLATE : Default_Template_Labels._CREATE_TEMPLATE}
                                                </span>

                                            </div>
                                            {!(isIconsListEnable) ?
                                                <div className="mt-1">
                                                    <span className="inline-grid gap-x-10 grid-cols-2">
                                                        <div className="items-center mb-2">
                                                            <label htmlFor="templateName" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._TEMPLATE_NAME}</label>
                                                            <input
                                                                className="block bg-gray-50 p-2 border border-gray-300 focus:border-blue-500 rounded-lg focus:ring-blue-500 w-full text-gray-900 text-sm"
                                                                placeholder={Default_Template_Labels._ENTER_TEMPLATE_NAME}
                                                                onChange={props.templatehandleOnChange}
                                                                type="text"
                                                                id="templateName"
                                                                name="templateName"
                                                                autoComplete="off"
                                                                required={true}
                                                                value={props.newTemplateRecord.templateName}
                                                            />

                                                        </div>
                                                        <div className="items-center mb-2">
                                                            <label htmlFor="companyName" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._COMPANY_NAME}</label>
                                                            <input
                                                                className="block bg-gray-50 p-2 border border-gray-300 focus:border-blue-500 rounded-lg focus:ring-blue-500 w-full text-gray-900 text-sm"
                                                                placeholder={Default_Template_Labels._ENTER_COMPANY_NAME}
                                                                type="text"
                                                                id="companyName"
                                                                name="companyName"
                                                                autoComplete="off"
                                                                required={true}
                                                                value={props.newTemplateRecord.companyName}
                                                                onChange={props.templatehandleOnChange} />
                                                        </div>
                                                        <div className="items-center mb-2">
                                                            <label htmlFor="companyLogo" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._COMPANY_LOGO}</label>
                                                            <div className="flex items-center gap-[15px]">
                                                                <label className="block w-full" htmlFor="companyLogo">
                                                                    <input
                                                                        type="file"
                                                                        name="companyLogo"
                                                                        id="companyLogo"
                                                                        accept={FileTypes._IMAGE}
                                                                        className="hidden text-sm cursor-pointer"
                                                                        onChange={props.templatehandleOnChange}
                                                                        placeholder={Default_Template_Labels._UPLOAD_IMAGE_FILE}
                                                                    />

                                                                    <div className="flex justify-between items-center gap-2.5 bg-white focus:bg-orange-100 px-2.5 py-[13px] border border-black border-opacity-30 rounded-lg focus:outline-none w-full h-10 placeholder:font-normal text-gray-700 text-text-black placeholder:text-black placeholder:text-sm text-opacity-50 placeholder:text-opacity-30 leading-tight placeholder:leading-snug appearance-none cursor-pointer text">
                                                                        <span className="overflow-hidden font-normal text-black text-base text-opacity-50 text-ellipsis leading-tight tracking-tight whitespace-nowrap">
                                                                            {props.newTemplateRecord.companyLogo?.imgname || Default_Template_Labels._NO_FILE_CHOSEN}
                                                                        </span>
                                                                        {!props.newTemplateRecord.companyLogo?.imgname && (
                                                                            <svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                width="20"
                                                                                height="20"
                                                                                viewBox="0 0 24 24"
                                                                                fill="none"
                                                                            >
                                                                                <path
                                                                                    fillRule="evenodd"
                                                                                    clipRule="evenodd"
                                                                                    d="M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L17.7071 8.29289C18.0976 8.68342 18.0976 9.31658 17.7071 9.70711C17.3166 10.0976 16.6834 10.0976 16.2929 9.70711L13 6.41421V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V6.41421L7.70711 9.70711C7.31658 10.0976 6.68342 10.0976 6.29289 9.70711C5.90237 9.31658 5.90237 8.68342 6.29289 8.29289L11.2929 3.29289ZM4 16C4.55228 16 5 16.4477 5 17V19C5 19.2652 5.10536 19.5196 5.29289 19.7071C5.48043 19.8946 5.73478 20 6 20H18C18.2652 20 18.5196 19.8946 18.7071 19.7071C18.8946 19.5196 19 19.2652 19 19V17C19 16.4477 19.4477 16 20 16C20.5523 16 21 16.4477 21 17V19C21 19.7957 20.6839 20.5587 20.1213 21.1213C19.5587 21.6839 18.7957 22 18 22H6C5.20435 22 4.44129 21.6839 3.87868 21.1213C3.31607 20.5587 3 19.7957 3 19V17C3 16.4477 3.44772 16 4 16Z"
                                                                                    fill="black"
                                                                                    fillOpacity="0.3"
                                                                                />
                                                                            </svg>
                                                                        )}
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="items-center mb-2">
                                                            <label htmlFor="colorCode" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._COLOR_CODE}</label>
                                                            <span className="flex justify-between">
                                                                <input className="block border-none outline-none w-14 h-8 text-gray-900 text-sm cursor-pointer"
                                                                    id="colorCode"
                                                                    name="colorCode"
                                                                    type="color"
                                                                    autoComplete="off"
                                                                    onChange={props.templatehandleOnChange}
                                                                    value={props.newTemplateRecord.colorCode} />
                                                                <input
                                                                    type="text"
                                                                    id="hexcolor"
                                                                    name="colorCode"
                                                                    autoComplete="off"
                                                                    className="block bg-gray-50 border border-gray-300 focus:border-blue-500 rounded-lg focus:ring-blue-500 w-40 text-gray-900 text-sm"
                                                                    placeholder={Default_Template_Labels._COLOR_CODE_EXAMPLE}
                                                                    onChange={props.templatehandleOnChange}
                                                                    value={props.newTemplateRecord.colorCode}
                                                                />
                                                            </span>
                                                        </div>
                                                    </span>

                                                    <div className="items-center mt-2 mb-2">
                                                        <span className="flex justify-between items-center">
                                                            <button htmlFor="" className="block mb-2 font-medium text-blue-600 text-sm text-center underline" onClick={closetemp}>{Default_Template_Labels._SELECT_ICONS}</button>
                                                        </span>
                                                        <span className="flex items-center mb-3">
                                                            <input
                                                                className="hidden bg-gray-100 mt-2 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 w-4 h-4 text-blue-600"
                                                                id="default-checkbox-1"
                                                                checked={true}
                                                                type="checkbox"
                                                                name="checkbox"
                                                                onChange={props.templatehandleOnChange}
                                                            />
                                                            {props.newTemplateRecord.iconSource === Default_Template_Labels._DEFAULT ?
                                                                <span className="flex gap-x-12">
                                                                    {renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.homeIcon}
                                                                    {renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.upIcon}
                                                                    {renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.previousIcon}
                                                                </span>
                                                                :
                                                                <span className="flex gap-x-12 h-10">
                                                                    <img src={props.newTemplateRecord.navHomeIcon} alt="home_icom" />
                                                                    <img src={props.newTemplateRecord.navUpIcon} alt="up_icom" />
                                                                    <img src={props.newTemplateRecord.navPreviousIcon} alt="previous_icom" />
                                                                </span>
                                                            }
                                                        </span>
                                                    </div>

                                                    <div className='flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md w-full'>
                                                        <button onClick={props.closeDialogPopupBox} className={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8"}>{Default_Template_Labels._CANCEL_BTN}</button>
                                                        <button onClick={previewOpenCloseOnclick} className={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8"}>{Default_Template_Labels._PREVIEW_BTN}</button>
                                                        {props.isFromEditView ?

                                                            <button onClick={props.editTemplateOnClick} className={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-8"} >{Default_Template_Labels._SAVE_BTN}</button>
                                                            :
                                                            <button onClick={props.createTemplateOnClick} className={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-8"} >{Default_Template_Labels._CREATE_BTN}</button>

                                                        }
                                                    </div>
                                                </div>
                                                :
                                                <div className="my-4 w-full">
                                                    <div>
                                                        {navIcons.map((icon) => (
                                                            <div className="flex justify-center items-center mb-3">
                                                                <input
                                                                    className="bg-gray-100 mt-2 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 w-4 h-4 text-blue-600"
                                                                    id="navIcons"
                                                                    key={icon.value}
                                                                    value={icon.value}
                                                                    htmlFor="navIcons"
                                                                    type="checkbox"
                                                                    name="navIcons"
                                                                    checked={props?.newTemplateRecord?.iconSource === Default_Template_Labels._DEFAULT && parsedNavGroupId === icon.id}
                                                                    onChange={(e) => props.templatehandleOnChange(e, icon)} />
                                                                <span className="flex gap-x-12 ml-6">
                                                                    {icon.homeIcon}
                                                                    {icon.upIcon}
                                                                    {icon.previousIcon}
                                                                </span>
                                                            </div>
                                                        ))}
                                                        {props?.newTemplateRecord.navHomeImg?.includes("base64") ?
                                                            <div className="flex justify-center items-center mb-3">
                                                                <input
                                                                    className="bg-gray-100 mt-2 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 w-4 h-4 text-blue-600"
                                                                    id="navIcons"
                                                                    // key={icon.value}
                                                                    // value={icon.value}
                                                                    htmlFor="userDefined"
                                                                    type="checkbox"
                                                                    name="userDefined"
                                                                    checked={props?.newTemplateRecord?.iconSource === Default_Template_Labels._USER_DEFINED} // && parsedNavGroupId === icon.id
                                                                    onChange={(e) => props.templatehandleOnChange(e)} /> {/** , icon */}
                                                                <span className="flex gap-x-12 ml-6">
                                                                    <img alt={""} className="h-7" src={props.newTemplateRecord.navHomeImg}></img>
                                                                    <img alt={""} className="h-7" src={props.newTemplateRecord.navPreviousImg}></img>
                                                                    <img alt={""} className="h-7" src={props.newTemplateRecord.navUpImg}></img>
                                                                </span>
                                                            </div>
                                                            : null}
                                                        <div className="flex items-center my-2">
                                                            <hr className="hr-gradient-end" />
                                                            <span className="mx-2 text-gray-400"> {Default_Template_Labels._OR_UPLOAD_CUSTOM_ICONS} </span>
                                                            <hr className="hr-gradient-start" />
                                                        </div>
                                                    </div>

                                                    <div className="flex justify-around items-center">
                                                        <div className="flex flex-col items-center">
                                                            <label htmlFor="navHomeIcon" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._CREATE_HOME_LOGO}</label>
                                                            <div className="flex items-center gap-[15px]">
                                                                <label className="block w-full">
                                                                    <input
                                                                        type="file"
                                                                        name="navHomeIcon"
                                                                        id="navHomeIcon"
                                                                        accept={FileTypes._IMAGE}
                                                                        className="hidden text-sm cursor-pointer"
                                                                        onChange={props.templatehandleOnChange}
                                                                    />
                                                                    <div className="flex justify-between items-center gap-2.5 bg-white focus:bg-orange-100 px-2.5 py-[13px] border border-black border-opacity-30 rounded-lg focus:outline-none w-full h-10 placeholder:font-normal text-gray-700 text-text-black placeholder:text-black placeholder:text-sm text-opacity-50 placeholder:text-opacity-30 leading-tight placeholder:leading-snug appearance-none cursor-pointer first-letter text">
                                                                        <span className="font-normal text-black text-base text-opacity-50 leading-tight tracking-tight">
                                                                            {Default_Template_Labels._CHOOSE_FILE}
                                                                        </span>
                                                                        <svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            width="20"
                                                                            height="20"
                                                                            viewBox="0 0 24 24"
                                                                            fill="none"
                                                                        >
                                                                            <path
                                                                                fillRule="evenodd"
                                                                                clipRule="evenodd"
                                                                                d="M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L17.7071 8.29289C18.0976 8.68342 18.0976 9.31658 17.7071 9.70711C17.3166 10.0976 16.6834 10.0976 16.2929 9.70711L13 6.41421V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V6.41421L7.70711 9.70711C7.31658 10.0976 6.68342 10.0976 6.29289 9.70711C5.90237 9.31658 5.90237 8.68342 6.29289 8.29289L11.2929 3.29289ZM4 16C4.55228 16 5 16.4477 5 17V19C5 19.2652 5.10536 19.5196 5.29289 19.7071C5.48043 19.8946 5.73478 20 6 20H18C18.2652 20 18.5196 19.8946 18.7071 19.7071C18.8946 19.5196 19 19.2652 19 19V17C19 16.4477 19.4477 16 20 16C20.5523 16 21 16.4477 21 17V19C21 19.7957 20.6839 20.5587 20.1213 21.1213C19.5587 21.6839 18.7957 22 18 22H6C5.20435 22 4.44129 21.6839 3.87868 21.1213C3.31607 20.5587 3 19.7957 3 19V17C3 16.4477 3.44772 16 4 16Z"
                                                                                fill="black"
                                                                                fill-opacity="0.3"
                                                                            />
                                                                        </svg>
                                                                    </div>
                                                                </label>

                                                            </div>
                                                            <div className="w-full">
                                                                <div className="flex justify-center my-2">
                                                                    {props.newTemplateRecord.navHomeIcon === "" ? (
                                                                        <span>{Default_Template_Labels._NO_FILE_CHOSEN}</span>
                                                                    ) : (
                                                                        <img alt={""} className="h-10" src={props.newTemplateRecord.navHomeIcon}></img>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="flex flex-col items-center">
                                                            <label htmlFor="navUpIcon" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._CREATE_UP_LOGO}</label>
                                                            <div className="flex items-center gap-[15px]">
                                                                <label className="block w-full">
                                                                    <input
                                                                        type="file"
                                                                        name="navUpIcon"
                                                                        id="navUpIcon"
                                                                        accept={FileTypes._IMAGE}
                                                                        className="hidden text-sm cursor-pointer"
                                                                        onChange={props.templatehandleOnChange}
                                                                    />
                                                                    <div className="flex justify-between items-center gap-2.5 bg-white focus:bg-orange-100 px-2.5 py-[13px] border border-black border-opacity-30 rounded-lg focus:outline-none w-full h-10 placeholder:font-normal text-gray-700 text-text-black placeholder:text-black placeholder:text-sm text-opacity-50 placeholder:text-opacity-30 leading-tight placeholder:leading-snug appearance-none cursor-pointer first-letter text">
                                                                        <span className="font-normal text-black text-base text-opacity-50 leading-tight tracking-tight">
                                                                            {Default_Template_Labels._CHOOSE_FILE}
                                                                        </span>
                                                                        <svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            width="20"
                                                                            height="20"
                                                                            viewBox="0 0 24 24"
                                                                            fill="none"
                                                                        >
                                                                            <path
                                                                                fillRule="evenodd"
                                                                                clipRule="evenodd"
                                                                                d="M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L17.7071 8.29289C18.0976 8.68342 18.0976 9.31658 17.7071 9.70711C17.3166 10.0976 16.6834 10.0976 16.2929 9.70711L13 6.41421V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V6.41421L7.70711 9.70711C7.31658 10.0976 6.68342 10.0976 6.29289 9.70711C5.90237 9.31658 5.90237 8.68342 6.29289 8.29289L11.2929 3.29289ZM4 16C4.55228 16 5 16.4477 5 17V19C5 19.2652 5.10536 19.5196 5.29289 19.7071C5.48043 19.8946 5.73478 20 6 20H18C18.2652 20 18.5196 19.8946 18.7071 19.7071C18.8946 19.5196 19 19.2652 19 19V17C19 16.4477 19.4477 16 20 16C20.5523 16 21 16.4477 21 17V19C21 19.7957 20.6839 20.5587 20.1213 21.1213C19.5587 21.6839 18.7957 22 18 22H6C5.20435 22 4.44129 21.6839 3.87868 21.1213C3.31607 20.5587 3 19.7957 3 19V17C3 16.4477 3.44772 16 4 16Z"
                                                                                fill="black"
                                                                                fill-opacity="0.3"
                                                                            />
                                                                        </svg>
                                                                    </div>
                                                                </label>

                                                            </div>
                                                            <div className="w-full">
                                                                <div className="flex justify-center my-2">
                                                                    {props.newTemplateRecord.navUpIcon === "" ? (
                                                                        <span>{Default_Template_Labels._NO_FILE_CHOSEN}</span>
                                                                    ) : (
                                                                        <img alt={""} className="h-10" src={props.newTemplateRecord.navUpIcon}></img>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="flex flex-col items-center">
                                                            <label htmlFor="navPreviousIcon" className="block mb-2 font-medium text-gray-900 text-sm">{Default_Template_Labels._CREATE_PREVIOUS_LOGO}</label>
                                                            <div className="flex items-center gap-[15px]">
                                                                <label className="block w-full">
                                                                    <input
                                                                        type="file"
                                                                        name="navPreviousIcon"
                                                                        id="navPreviousIcon"
                                                                        accept={FileTypes._IMAGE}
                                                                        className="hidden text-sm cursor-pointer"
                                                                        onChange={props.templatehandleOnChange}
                                                                    />
                                                                    <div className="flex justify-between items-center gap-2.5 bg-white focus:bg-orange-100 px-2.5 py-[13px] border border-black border-opacity-30 rounded-lg focus:outline-none w-full h-10 placeholder:font-normal text-gray-700 text-text-black placeholder:text-black placeholder:text-sm text-opacity-50 placeholder:text-opacity-30 leading-tight placeholder:leading-snug appearance-none cursor-pointer first-letter text">
                                                                        <span className="font-normal text-black text-base text-opacity-50 leading-tight tracking-tight">
                                                                            {Default_Template_Labels._CHOOSE_FILE}
                                                                        </span>
                                                                        <svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            width="20"
                                                                            height="20"
                                                                            viewBox="0 0 24 24"
                                                                            fill="none"
                                                                        >
                                                                            <path
                                                                                fillRule="evenodd"
                                                                                clipRule="evenodd"
                                                                                d="M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L17.7071 8.29289C18.0976 8.68342 18.0976 9.31658 17.7071 9.70711C17.3166 10.0976 16.6834 10.0976 16.2929 9.70711L13 6.41421V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V6.41421L7.70711 9.70711C7.31658 10.0976 6.68342 10.0976 6.29289 9.70711C5.90237 9.31658 5.90237 8.68342 6.29289 8.29289L11.2929 3.29289ZM4 16C4.55228 16 5 16.4477 5 17V19C5 19.2652 5.10536 19.5196 5.29289 19.7071C5.48043 19.8946 5.73478 20 6 20H18C18.2652 20 18.5196 19.8946 18.7071 19.7071C18.8946 19.5196 19 19.2652 19 19V17C19 16.4477 19.4477 16 20 16C20.5523 16 21 16.4477 21 17V19C21 19.7957 20.6839 20.5587 20.1213 21.1213C19.5587 21.6839 18.7957 22 18 22H6C5.20435 22 4.44129 21.6839 3.87868 21.1213C3.31607 20.5587 3 19.7957 3 19V17C3 16.4477 3.44772 16 4 16Z"
                                                                                fill="black"
                                                                                fill-opacity="0.3"
                                                                            />
                                                                        </svg>
                                                                    </div>
                                                                </label>

                                                            </div>
                                                            <div className="w-full">
                                                                <div className="flex justify-center my-2">
                                                                    {props.newTemplateRecord.navPreviousIcon === "" ? (
                                                                        <span>{Default_Template_Labels._NO_FILE_CHOSEN}</span>
                                                                    ) : (
                                                                        <img alt={""} className="h-10" src={props.newTemplateRecord.navPreviousIcon}></img>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md w-full'>
                                                        <button onClick={closetemp} className={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8"}>{Default_Template_Labels._OK_BTN}</button>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div >
                    </div >
                    :
                    <Previewtemplate
                        selectedMapData={props.selectedMapData}
                        currentMapDet={props.currentMapDet}
                        mapDiagramRecord={props.mapDiagramRecord}
                        newTemplateRecord={props.newTemplateRecord}
                        previewOpenCloseOnclick={previewOpenCloseOnclick}

                    />
            }
        </>
    )
};

export const Previewtemplate = (props) => {
    const renderElementsByIconsId = (groupId) => {
        const tempGroupId = isNumber(groupId) ? groupId : parseInt(groupId)
        return navIcons.find(item => item.id === tempGroupId)
    }

    console.log("iii ", props);
    return (
        <div>
            <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                <div className="flex justify-center items-center w-full h-full">
                    <div className="w-[40vw]">
                        <div className="bg-white border-box rounded-md font-sans text-gray-900">
                            <div className="flex justify-center mx-auto w-full sm:max-w-lg">
                                <div className="flex flex-col justify-center bg-white my-5 w-full h-auto">
                                    <div className="flex justify-start items-center mt-2 mb-2">
                                        <button
                                            className="bg-[#089de3] hover:bg-blue-700 mr-2 px-2 py-2 rounded-full transition-all duration-200 ease-in-out cursor-pointer"
                                            htmlFor="'"
                                            title="close"
                                            onClick={props.previewOpenCloseOnclick}>
                                            <RiArrowGoBackFill color="white" />
                                        </button>
                                        <label htmlFor="" className="block font-medium text-gray-900 text-sm">{Default_Template_Labels._BACK_BTN} </label>
                                    </div>
                                    <div
                                        className="flex flex-col justify-between p-2 border-4 rounded w-full h-[60vh]"
                                        style={{
                                            background: `linear-gradient(to bottom, ${props.newTemplateRecord.colorCode}, #fff)`
                                        }}
                                    >
                                        <div className="w-full">
                                            <div className="flex justify-between items-center">
                                                <div className="flex space-x-4">
                                                    <div
                                                        className="p-1 rounded w-4 h-4 text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                                        title="Home"
                                                    >
                                                        {props.newTemplateRecord.iconSource === Default_Template_Labels._DEFAULT ?
                                                            renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.homeIcon
                                                            :
                                                            <img className="max-w-[20px] max-h-5" src={props.newTemplateRecord?.navHomeIcon} alt="home_icom" />
                                                        }
                                                    </div>
                                                    <div
                                                        className="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                                        title="UP"
                                                    >
                                                        {/* {renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.upIcon} */}
                                                        {props.newTemplateRecord.iconSource === Default_Template_Labels._DEFAULT ?
                                                            renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.upIcon
                                                            :
                                                            <img className="max-w-[20px] max-h-5" src={props.newTemplateRecord?.navUpIcon} alt="up_icom" />
                                                        }
                                                    </div>
                                                    <div
                                                        className="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                                                        title="Previous"
                                                    >
                                                        {/* {renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.previousIcon} */}
                                                        {props.newTemplateRecord.iconSource === Default_Template_Labels._DEFAULT ?
                                                            renderElementsByIconsId(props.newTemplateRecord?.navHomeIcon)?.previousIcon
                                                            :
                                                            <img className="max-w-[20px] max-h-5" src={props.newTemplateRecord?.navPreviousIcon} alt="previous_icom" />
                                                        }
                                                    </div>
                                                </div>
                                                <span className="mt-4 text-xs">{props?.mapDiagramRecord.diagramName}</span>
                                                <span className="font-semibold">{props.currentMapDet.name.includes('-') ? props?.currentMapDet?.name.substring(1, props?.currentMapDet.name.length) : props.currentMapDet.name}</span>
                                                <span className="mt-4 pr-4 text-xs">{props?.currentMapDet.id}</span>
                                                {/* {props.newTemplateRecord.companyLogo?.imgname?.length > 0 ?: null} */}
                                                <div className="p-1 w-16">
                                                    <img src={props.newTemplateRecord.companyLogo?.imgcontent} alt="company_logo" />
                                                </div>
                                            </div>
                                            <hr className="bg-gray-900 mt-2 border-0 h-px" />
                                        </div>
                                        <div className='w-full h-[60%]'>

                                        </div>
                                        <div className="w-full">
                                            <hr className="bg-gray-900 border-0 h-px" />
                                            <div className="flex justify-between items-center">
                                                <span className="mt-1 text-xs">{BPMN_Common_Labels._AUTHOR_TEMPLATE} : {props.selectedMapData.author}</span>
                                                <span className="mt-1 text-xs">{BPMN_Common_Labels._STATUS_TEMPLATE} : {Default_Template_Labels._DRAFT}</span>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
};

export const ApplyTemplate = (props) => {
    const gridRef = useRef();
    const [gridApi, setGridApi] = useState(null);
    const [isDeleteEnable, setIsDeleteEnable] = useState(false)
    const [isPreviewEditEnable, setIsPreviewEditEnable] = useState(false)
    const [deleteTemplateData, setDeleteTemplateData] = useState()
    const [filterValue, setFilterValue] = useState('')
    const [actionType, setActionType] = useState('')
    const [templateDetails, setTemplateDetails] = useState({})
    console.log(props);
    const [rowData, setRowData] = useState([])

    const [columnDefs] = useState([
        {
            field: "Selected",
            headerCheckboxSelection: true,
            checkboxSelection: true,
            width: 50,

        },
        { headerName: 'Template Name', field: 'templateName', flex: 1 },
        { headerName: 'Company Name', field: 'companyName', flex: 1 },
        {
            headerName: "Action", field: "Action", width: 120,
            cellRendererFramework: (params) =>
                <div className='flex items-center space-x-4 w-full h-full'>
                    <button onClick={(e) => editData(e, params.data, "PREVIEW")} title={"Preview"}><BsEye color='orange' /></button>
                    <button title={"Edit"}><FaRegEdit onClick={(e) => editData(e, params.data, "EDIT")} color='blue' /></button>
                    <button onClick={(e) => deleteUserOpen(params.data)} title={"Delete"}><IoTrashOutline color='red' /></button>
                </div>
        }
    ]);
    console.log(props);
    const getAllTemplates = async () => {
        try {

            const response = await BPMNService.getAllTemplatesAPICALL();
            console.log(response);
            const data = await response?.data;
            console.log(data);
            if (response?.status === 200 || response?.status === 201) {
                setRowData(data);
            }
        } catch (error) {
            console.error("getAllUsersAPIcall", error)
        }
    }

    useEffect(() => {
        getAllTemplates();
    }, [])


    const selectedData = async () => {
        if (gridApi) {
            const selectedNodes = gridApi.getSelectedNodes();
            const selectedData = selectedNodes.map(node => node.data);
            console.log(props.selectedMapData)
            if ((localStorage.getItem("userRole") === "Editor" || localStorage.getItem("userRole") === "Admin") && (props.selectedMapData?.diagramXmlIds?.Draft?.status === "InProgress")) {
                if (selectedData.length === 1) {
                    await props.setTemplateBgColor(selectedData[0])
                    props.closeDialogPopupBox()
                } else {
                    ErrorMessage("Please select One Template at a time")
                }
            }
            else {
                ErrorMessage("Editor or Admin can change the template when the map is in 'In Progress' status")
            }
        } else {
            console.log("else")
        }
    }

    const onGridReady = (params) => {
        setGridApi(params.api);

    };
    const deleteTemplateOnClick = async () => {
        try {
            console.log(deleteTemplateData);
            const deleteTemplateByIds = [
                {
                    templateId: deleteTemplateData.id
                }
            ]
            const response = await BPMNService.deleteMultipleTemplates(deleteTemplateByIds);
            if (response?.status === 200 || response?.status === 201 || response?.status === 204) {
                getAllTemplates();
                SuccessMessage(BPMN_Editor_Toaster.Template_Deleted_Successfully)
                setIsDeleteEnable(false);
                setDeleteTemplateData({});
            }
            setIsDeleteEnable(false);

        } catch (error) {
            console.error("getAllUsersAPIcall", error)
            ErrorMessage(error.response.data)
        }
    };
    const deleteUserOpen = async (deleteData) => {
        console.log(deleteData);
        setIsDeleteEnable(true);
        setDeleteTemplateData(deleteData);
    }

    const editData = (e, data, type) => {
        console.log("data", data);
        setIsPreviewEditEnable(true)
        setTemplateDetails(data)
        setActionType(type)
    }
    const onRowDataChanged = params => {
        console.log(params, props)
        console.log(params.api.forEachNode)

        params.api.forEachNode((node) => {
            node.setSelected(props.appliedTemplate.id === node.data.id);
        })
    }

    const onFilterTextBoxChanged = useCallback(() => {
        setFilterValue(document.getElementById('filter-text-box').value);

    }, []);
    const previewOpenCloseOnclick = useCallback(() => {
        setIsPreviewEditEnable(prev => !prev)
    }, []);
    const templatehandleOnChange = async (e, icon) => {
        console.log(e, icon);
        let value = "";
        let name = "";
        let parsedtemplatedata;
        console.log(e.target?.name, icon);
        parsedtemplatedata = { ...templateDetails }
        // // console.log("🚀 ~ templateDetails:", templateDetails);
        if (e.target.type === "text") {
            name = e.target.name;
            value = e.target.value;
        } else if (e.target.type === "file") {
            const currFile = e.target.files[0];
            const customErrorMessage = e.target.name === "companyLogo" ? Default_Template_Labels._ACCEPT_ONLY_IMAGE : null;
            const isImageValid = await validateFileOnChange(e, customErrorMessage);
            if (!isImageValid) {
                return;
            }
            name = e.target.name;
            value = e.target.value;
            const tempImgContent = await convertFileToBase64(currFile);
            if (e.target.name === "companyLogo") {
                value = {
                    imgname: currFile.name,
                    imgcontent: tempImgContent
                }
            } else {
                console.log("333", name, value);
                value = tempImgContent
                parsedtemplatedata["iconSource"] = "userDefined"
            }

        } else if (e.target.type === "color") {
            name = e.target.name;
            value = e.target.value;

        } else if (e.target.type === "checkbox") {
            if (e.target.name === "userDefined") {
                parsedtemplatedata["navHomeIcon"] = parsedtemplatedata.navHomeImg
                parsedtemplatedata["navUpIcon"] = parsedtemplatedata.navUpImg
                parsedtemplatedata["navPreviousIcon"] = parsedtemplatedata.navPreviousImg
                parsedtemplatedata["iconSource"] = 'userDefined'

            }
            if (e.target.name === "navIcons") {

                value = e.target.checked;
                if (value) {
                    parsedtemplatedata["navHomeIcon"] = icon.id
                    parsedtemplatedata["navUpIcon"] = icon.id
                    parsedtemplatedata["navPreviousIcon"] = icon.id
                } else {
                    parsedtemplatedata["navHomeIcon"] = "1"
                    parsedtemplatedata["navUpIcon"] = "1"
                    parsedtemplatedata["navPreviousIcon"] = "1"
                }
                parsedtemplatedata["iconSource"] = 'default'
            }
            setTemplateDetails(parsedtemplatedata)
            return
        }
        parsedtemplatedata[name] = value;
        console.log(name, value);
        setTemplateDetails(parsedtemplatedata)
    }
    const editTemplateOnClick = async () => {
        let payload = { ...templateDetails };
        payload["navHomeImg"] = payload.iconSource === "userDefined" ? payload["navHomeIcon"] : payload["navHomeImg"]
        payload["navUpImg"] = payload.iconSource === "userDefined" ? payload["navUpIcon"] : payload["navUpImg"]
        payload["navPreviousImg"] = payload.iconSource === "userDefined" ? payload["navPreviousIcon"] : payload["navPreviousImg"]
        console.log("🚀 ~ payload111111:", payload);
        const tempPayLoad = { ...payload };
        delete tempPayLoad["navHomeImg"]
        delete tempPayLoad["navUpImg"]
        delete tempPayLoad["navPreviousImg"]
        console.log("tempPayLoad", tempPayLoad);
        const isValid = Object.values(tempPayLoad).every(value => value !== "" && value !== null && value !== undefined)
        if (isValid) {
            try {
                const response = await BPMNService.editTemplateAPICALL(payload)
                console.log(response);
                await getAllTemplates();
                setIsPreviewEditEnable(false)
                SuccessMessage(BPMN_Editor_Toaster.Template_Edited_Successfully);
                if (props.appliedTemplate.id === response.data.id) {
                    await props.setTemplateBgColor(response.data)
                }
            } catch (error) {
                console.error(error);
            }
        } else {
            ErrorMessage(BPMN_Editor_Toaster.Please_Enter_All_Data);
            return isValid
        }
    }
    console.log(templateDetails);
    return (
        <div>
            {!(isPreviewEditEnable) ?
                <ReactDialogBox
                    closeBox={props.closeDialogPopupBox}
                    modalWidth="35vw"
                    headerBackgroundColor='#fff'
                    headerTextColor='black'
                    headerHeight='40px'
                    closeButtonColor='#000'
                    closeButtonSize='20px'
                    bodyBackgroundColor='#fffdfc'
                    bodyTextColor='black'
                    // bodyHeight='50vh'
                    headerText={"Template Lists"}
                >
                    <div className='flex lg:flex-row flex-col gap-3 overflow-y-auto'>
                        <div className="px-4 w-full">
                            <div>
                                <div className='flex justify-between px-4 py-1'>
                                    <div></div>
                                    <div className="relative flex items-center border border-[#a4a5a6] rounded-md h-8 overflow-hidden">
                                        <div className="place-items-center grid bg-[#a4a5a6] w-12 h-full text-search-text">
                                            <HiOutlineSearch color='white' size={24} />
                                        </div>
                                        <input
                                            id="filter-text-box"
                                            onInput={onFilterTextBoxChanged}
                                            className="peer bg-white pr-2 pl-2 outline-none w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs placeholder-[#0000004D]"
                                            type="text"
                                            placeholder={Default_Template_Labels._SEARCH} />
                                    </div>
                                </div>
                            </div>
                            <CustomAgGridResource
                                rowData={rowData}
                                columnDefs={columnDefs}
                                onGridReady={onGridReady}
                                filterValue={filterValue}
                                ref={gridRef}
                                onRowDataChanged={onRowDataChanged}
                                rowSelection={true}
                            />
                            <div className='flex justify-end space-x-2'>
                                <button className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:outline-none focus:ring-0 font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm" onClick={props.closeDialogPopupBox}>
                                    {Default_Template_Labels._CANCEL_BTN}
                                </button>
                                <button
                                    className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:outline-none focus:ring-0 font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm"
                                    onClick={selectedData}
                                >
                                    {Default_Template_Labels._OK_BTN}
                                </button>
                            </div>
                        </div>
                    </div>

                </ReactDialogBox>

                : <>
                    {actionType === "PREVIEW" ?
                        <Previewtemplate
                            newTemplateRecord={templateDetails}
                            previewOpenCloseOnclick={previewOpenCloseOnclick}
                            selectedMapData={props.selectedMapData}
                            currentMapDet={props.currentMapDet}
                            mapDiagramRecord={props.mapDiagramRecord}
                        />
                        : null}
                    {actionType === "EDIT" ?
                        <CreateTemplate
                            newTemplateRecord={templateDetails}
                            closeDialogPopupBox={previewOpenCloseOnclick}
                            templatehandleOnChange={templatehandleOnChange}
                            createTemplateOnClick={props.createTemplateOnClick}
                            isFromEditView={true}
                            editTemplateOnClick={editTemplateOnClick}
                            selectedMapData={props.selectedMapData}
                            currentMapDet={props.currentMapDet}
                            mapDiagramRecord={props.mapDiagramRecord}
                        />
                        : null}
                </>
            }
            {isDeleteEnable ?
                <div className="top-0 right-0 bottom-0 left-0 z-[1100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                    <div className="flex justify-center items-center w-full h-full">
                        <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[25vw] h-[100px] font-sans text-gray-900">
                            <h1>{Default_Template_Labels._ARE_YOU_SURE_WANT_TO_DELETE} <span className='text-blue-500'>{deleteTemplateData?.templateName}</span>?</h1>
                            <div className="flex justify-center space-x-2">
                                <button
                                    className="px-2 py-1 border border-black border-opacity-30 rounded-md w-20 text-blue-600"
                                    onClick={() => setIsDeleteEnable(false)}
                                >
                                    {Default_Template_Labels._CANCEL_BTN}
                                </button>
                                <button
                                    className="bg-blue-500 px-2 py-1 rounded-md w-20 text-white"
                                    onClick={deleteTemplateOnClick}
                                >
                                    {Default_Template_Labels._OK_BTN}
                                </button>

                            </div>
                        </div>
                    </div>
                </div>
                : null}

        </div>
    )
};

export const IntegrityCheckPopup = (props) => {
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[30vw]">
                    <div className="bg-white border-box rounded-md font-sans text-gray-900">
                        <div className="flex justify-center mx-auto w-full sm:max-w-lg">
                            <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                    <span className="font-semibold text-lg">
                                        {Integrity_Check_Labels._INTEGRITY_CHECK}
                                    </span>
                                    <span className="hover:bg-gray-200 p-[2px] rounded"
                                        onClick={props.closeDialogPopupBox}
                                    >
                                        <MdOutlineClose size={22} />
                                    </span>
                                </div>
                                <div className="mt-1 w-[90%]">
                                    <div className="items-center mb-2">
                                        <input
                                            className={ControlsConstants.common.radio}
                                            id="CurrentLevel"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentLevel" className={ControlsConstants.common.label}>{BPMN_Common_Labels._CURRENT_DIAGRAM}</label>
                                    </div>
                                    <div className="items-center mb-2">
                                        <input
                                            className={ControlsConstants.common.radio}
                                            id="CurrentAndLower"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentAndLower" className={ControlsConstants.common.label}>{BPMN_Common_Labels._CURRENT_AND_LOWER_DIAGRAM}</label>
                                    </div>
                                    <div className="items-center">
                                        <input
                                            className={ControlsConstants.common.radio}
                                            id="CurrentProcessMap"
                                            type="radio"
                                            name="default-radio"
                                            value=""
                                            defaultChecked={true}
                                            onClick={props.onChangeRadioButton}
                                        />
                                        <label for="CurrentProcessMap" className={ControlsConstants.common.label}>{BPMN_Common_Labels._CURRENT_PROCESS_MAP}</label>
                                    </div>
                                    <div className="flex items-center my-2">
                                        <hr className="hr-gradient-end" />
                                        <span className="mx-2 text-gray-400 text-sm"> {Integrity_Check_Labels._OBJECTS_TO_CHECK} </span>
                                        <hr className="hr-gradient-start" />
                                    </div>
                                    <div className="inline-grid gap-x-5 grid-cols-2">
                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="activitiesText"
                                                name="activitiesText"
                                                value=""
                                                checked={props.IC_objectsChecked.activitiesText}
                                            />
                                            <label
                                                htmlFor="activitiesText"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._ACTIVITES_HAVE_TEXT}
                                            </label>
                                        </div>
                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="activityResources"
                                                name="activityResources"
                                                value=""
                                                checked={props.IC_objectsChecked.activityResources}
                                            />
                                            <label
                                                htmlFor="activityResources"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._RESOURCE_NAME}
                                            </label>
                                        </div>
                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="activityDocuments"
                                                name="activityDocuments"
                                                value=""
                                                checked={props.IC_objectsChecked.activityDocuments}
                                            />
                                            <label
                                                htmlFor="activityDocuments"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._DOCUMENT_IN_BPMN_TASK}
                                            </label>
                                        </div>

                                        {/* <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="flowlineText"
                                                name="flowlineText"
                                                value=""
                                                checked={props.IC_objectsChecked.flowlineText}
                                            />
                                            <label
                                                htmlFor="flowlineText"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._SEQUENCE_FLOW_LABEL}
                                            </label>
                                        </div> */}

                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="flowLinkConnections"
                                                name="flowLinkConnections"
                                                value=""
                                                checked={props.IC_objectsChecked.flowLinkConnections}
                                            />
                                            <label
                                                htmlFor="flowLinkConnections"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._FLOWLINE_CONNECTOR}
                                            </label>
                                        </div>
                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="testCaseCoverage"
                                                name="testCaseCoverage"
                                                value=""
                                                checked={props.IC_objectsChecked.testcasecoverage}
                                            />
                                            <label
                                                htmlFor="testcasecoverage"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._TEST_CASE_COVERAGE}
                                            </label>
                                        </div>
                                        <div className='mb-2'>
                                            <input
                                                onChange={props.integrityCheckOnChangeHandler}
                                                className={ControlsConstants.common.input}
                                                type="checkbox"
                                                id="requirementCoverage"
                                                name="requirementCoverage"
                                                value=""
                                                checked={props.IC_objectsChecked.requirementCoverage}
                                            />
                                            <label
                                                htmlFor="requirementcoverage"
                                                className={ControlsConstants.common.label}>
                                                {Integrity_Check_Labels._REQUIREMENT_COVERAGE}
                                            </label>
                                        </div>
                                    </div>

                                </div>

                                <div className='flex justify-center max-lg:justify-center items-center py-2 border-footer-border border-t rounded-b-md'>
                                    <button className={ControlsConstants.Responsive.btnResponsive.btn_success + " px-4"} onClick={props.closeDialogPopupBox}>
                                        {Integrity_Check_Labels._CANCEL_BTN}
                                    </button>
                                    <button className={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-4"} onClick={props.integrityCheckOnClick}>
                                        {Integrity_Check_Labels._GENERATE_REPORT_BTN}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const IntegrityCheckReport = (props) => {
    const gridRef = useRef();
    const [rowData] = useState(props.integrityCheckReport.records.filter(el =>
        el.checkResult !== 'Process Added with ALM' && el.checkResult !== 'Activity with ALM Added'
    ));
    const [isShowChartProgress, setisShowChartProgress] = useState(false)
    // const [columnDefs] = useState([
    //     // { headerName: 'Diagram Name', field: 'diagramName', flex: 1, sortable: true, flex: 1, suppressMovable: true, resizable: true },
    //     { headerName: 'Diagram Level', field: 'label',flex: 1, resizable: true, suppressMovable: true,filter: true, sortable: true},
    //     { headerName: 'Object Type', field: 'objectType', flex: 1, resizable: true, suppressMovable: true,filter: true, sortable: true },
    //     { headerName: 'Check Result', field: 'checkResult', flex: 1, resizable: true, suppressMovable: true,filter: true, sortable: true},
    //     { headerName: 'Object Id', field: 'toggleId', flex: 1, resizable: true, suppressMovable: true,filter: true, sortable: true},
    //     { headerName: 'Object Text', field: 'objectText', flex: 1, resizable: true, suppressMovable: true,filter: true, sortable: true},
    // ]);
    const columnDefinitions = [
        { headerName: 'Diagram Level', field: 'label' },
        { headerName: 'Object Type', field: 'objectType' },
        { headerName: 'Check Result', field: 'checkResult' },
        { headerName: 'Object Id', field: 'toggleId' },
        { headerName: 'Object Text', field: 'objectText' }
    ];

    const [columnDefs] = useState(
        columnDefinitions.map(def => ({
            ...def,
            flex: 1,
            resizable: true,
            suppressMovable: true,
            filter: true,
            sortable: true,
        }))
    );


    const isRowSelectable = (params) => {
        return true;
    }

    const onBtnExport = async () => {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Integrity Check');

        worksheet.columns = [
            { header: 'Diagram Level', key: 'label', width: 50 },
            // { header: 'Diagram Name', key: 'diagramName', width: 20 },
            { header: 'Object Type', key: 'objectType', width: 20 },
            { header: 'Check Result', key: 'checkResult', width: 20 },
            { header: 'Object Id', key: 'toggleId', width: 20 },
            { header: 'Object Text', key: 'objectText', width: 50 },
        ];

        rowData.forEach((data) => worksheet.addRow(data));

        worksheet.getRow(1).eachCell((cell) => createCellStyle(cell, true));

        worksheet.eachRow({ includeEmpty: true }, (row, rowNumber) => {
            row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                createCellStyle(cell, false, colNumber === 5 && rowNumber > 1);
            });
        });
        const { formattedDate, formattedTime } = dateTime();
        const filename = `integrity_check_${formattedDate}_${formattedTime}.xlsx`;
        await downloadExcel(workbook, filename);
    };

    const showChartProgress = () => {
        setisShowChartProgress(!isShowChartProgress)
    }
    console.log(props)
    let isAlmAdded = props.integrityCheckReport.records.some(el => el.checkResult.includes('ALM Added'))

    console.log(props)
    return (
        <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
                <div className="w-[90vw]">
                    <div class="bg-white border-box rounded-md font-sans text-gray-900">
                        <div class="flex justify-center mx-auto w-full">
                            <div class="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                <div className="flex justify-between items-center px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                    <div className="flex-1">
                                        {!isShowChartProgress && <span className="font-semibold text-lg">
                                            {Integrity_Check_Labels._INTEGRITY_CHECK_REPORT}
                                        </span>}
                                    </div>

                                    <div className="flex items-center space-x-5">
                                        {(props.IC_objectsChecked.requirementCoverage || props.IC_objectsChecked.testCaseCoverage) &&
                                            <label className="inline-flex items-center cursor-pointer">
                                                <input
                                                    type="checkbox"
                                                    value=""
                                                    checked={isShowChartProgress}
                                                    onChange={showChartProgress}
                                                    className="sr-only peer"
                                                />
                                                <div className="m-2 relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600 dark:peer-checked:bg-blue-600" />
                                                <span className="ms-3 text-sm font-medium text-gray-900">
                                                    Graphical View
                                                </span>
                                            </label>}
                                        <span className="hover:bg-gray-200 p-[2px] rounded cursor-pointer" onClick={props.closeDialogPopupBox}>
                                            <MdOutlineClose size={22} />
                                        </span>
                                    </div>
                                </div>
                                <div className="mt-1 w-full">
                                    <div className="flex lg:flex-row flex-col gap-3 overflow-hidden auto">
                                        <div className="px-4 w-full">
                                            {!isShowChartProgress ? (
                                                <div className="ag-theme-alpine sm:h-[500px] md:h-[500px] max-h-500px screen-h" style={{ width: '100%' }}>
                                                    <CustomAgGridResource
                                                        rowData={rowData}
                                                        columnDefs={columnDefs}
                                                        onGridReady={() => { console.log("ongrid") }}
                                                        ref={gridRef}
                                                        rowSelection={true}
                                                        isRowSelectable={isRowSelectable}
                                                        rowBuffer={15}
                                                        suppressColumnVirtualisation={true}
                                                        suppressRowVirtualisation={true}
                                                        integrityPageSize={true}
                                                    />
                                                </div>
                                            ) :

                                                (props.IC_objectsChecked.testCaseCoverage && props.IC_objectsChecked.requirementCoverage) ? (
                                                    <div className="flex h-[564px] w-[90%] gap-6">
                                                        <div className="flex-1 h-full h-[320px] items-center justify-center">
                                                            <PieChart
                                                                graphicalViewChart={props.integrityCheckReport.records}
                                                                IC_objectsChecked={props.IC_objectsChecked}
                                                            />
                                                        </div>
                                                        <div className="flex-1 h-full h-[564px]">
                                                        <div style={{ height: '564px', width: '530px', margin: 'auto' }}>
                                                            <PieChartProcess
                                                                graphicalViewChart={props.integrityCheckReport.records}
                                                                IC_objectsChecked={props.IC_objectsChecked}
                                                                reportFlag={true}
                                                            />
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                                    :
                                                    (
                                                        (<div style={{ height: '564px', width: '500px', margin: 'auto' }}>
                                                            <PieChartProcess
                                                                graphicalViewChart={props.integrityCheckReport.records}
                                                                IC_objectsChecked={props.IC_objectsChecked}
                                                                reportFlag={false}
                                                            />                                                        </div>)

                                                    )
                                            }
                                        </div>
                                    </div>
                                </div>

                                {!isShowChartProgress && <div class='flex justify-between max-lg:justify-center items-center py-2 border-footer-border rounded-b-md w-full'>
                                    <p className="ml-8 text-red-600">{Integrity_Check_Labels._BROKEN_LINK_COUNT} {props.integrityCheckReport.brokenFLCount}</p>
                                    <div class="flex space-x-4 mr-8">
                                        <button
                                            class={ControlsConstants.Responsive.btnResponsive.btn_success + " px-8 "}
                                            onClick={props.closeDialogPopupBox}>
                                            {Integrity_Check_Labels._CANCEL_BTN}
                                        </button>
                                        <button onClick={onBtnExport} class={ControlsConstants.Responsive.btnResponsive.btn_warning + " px-8"}>
                                            {Integrity_Check_Labels._PRINT_TO_EXCEL}
                                        </button>
                                    </div>
                                </div>}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
};

const PieChart = (props) => {
    console.log(props)
    const { colors = [], graphicalViewChart } = props;
    console.log(graphicalViewChart)
    const chartRef = useRef(null);
    const chartInstance = useRef(null);
    var process_linked_with_test_case = 0
    var process_without_test_case = 0
    var process_linked_with_requirement = 0
    var process_without_requirement = 0
    var Process_Added_Total_ALM = 0
    var Process_Added_ALM = 0
    var Process_Added_ALM_Requirement_and_Test = 0
    var label = []
    useEffect(() => {
        const getGraphicalViewReport = () => {

            graphicalViewChart?.forEach(item => {
                if (item.checkResult === 'ALM Added with test Case') {
                    process_linked_with_test_case += 1
                }
                else if (item.checkResult === 'ALM Added with test-folder') {
                    process_linked_with_test_case += 1
                }
                else if (item.checkResult === 'ALM Added with Requirement and Test Cases') {
                    Process_Added_ALM_Requirement_and_Test += 1
                }
                else if (item.checkResult === 'ALM Added with requirement') {
                    process_linked_with_requirement += 1
                }
                else if (item.checkResult === 'Process Added') {
                    Process_Added_Total_ALM += 1
                }
                else if (item.checkResult === 'Process Added with ALM') {
                    Process_Added_ALM += 1
                }
            });
        };

        getGraphicalViewReport();
        const defaultColors = ['#FF6F61', '#6B8E23', '#3CB371', '#1E90FF', '#FF8C00', '#8A2BE2', '#FF1493', '#32CD32', '#FFD700', '#FF6347', '#9ACD32', '#D2691E', '#FF4500', '#20B2AA'];
        if (chartInstance.current) {
            chartInstance.current.destroy();
        }
        console.log(process_linked_with_requirement, process_linked_with_test_case, Process_Added_Total_ALM, Process_Added_ALM, Process_Added_ALM_Requirement_and_Test)
        const value = [process_linked_with_test_case + Process_Added_ALM_Requirement_and_Test, (Process_Added_Total_ALM - process_linked_with_test_case - Process_Added_ALM_Requirement_and_Test),]
        const options = {
            series: value,
            chart: {
                width: '100%',
                height: '100%',
                type: 'pie',
            },
            labels: ['Process Linked with test case', 'Process Without test case'],
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: true,  // Enable data labels on the pie chart slices
                        offset: -5,     // Optional: Adjust the offset (space between label and slice)
                    },
                },
            },
            colors: colors.length > 0 ? colors : defaultColors,
            grid: {
                padding: {
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                },
            },
            dataLabels: {
                enabled: true,  // Enable data labels over the pie chart
                formatter: function (val) {
                    // Return percentage value with one decimal
                    return val.toFixed(1) + '%';
                },
            },
            tooltip: {
                enabled: true,  // Enable tooltips on hover
                formatter: function (val) {
                    // Show percentage in the tooltip with one decimal
                    return val.toFixed(1) + '%';
                },
            },
            legend: {
                show: true,  // Keep the legend visible
            },
        };


        chartInstance.current = new ApexCharts(chartRef.current, options);
        chartInstance.current.render();
        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
                chartInstance.current = null;
            }
        };
    }, [graphicalViewChart]);
    useEffect(() => {
    }, [colors]);
    return (
        <>
            <h1 className="flex justify-center">
                Test Case Coverage Report
            </h1>
            <div ref={chartRef} className="flex justify-center" style={{ height: '100%', width: '100%', padding: '10px' }} />

        </>)
};

const PieChartProcess = (props) => {
    console.log(props)
    const { colors = [], graphicalViewChart } = props;
    console.log(graphicalViewChart)
    const chartRef = useRef(null);
    const chartInstance = useRef(null);
    var process_linked_with_test_case = 0
    var process_without_test_case = 0
    var process_linked_with_requirement = 0
    var process_without_requirement = 0
    var Process_Added_Total_ALM = 0
    var Process_Added_ALM = 0
    var Process_Added_ALM_Requirement_and_Test = 0
    var label = []
    useEffect(() => {
        const getGraphicalViewReport = () => {

            graphicalViewChart?.forEach(item => {
                if (item.checkResult === 'ALM Added with test Case') {
                    process_linked_with_test_case += 1
                }
                else if (item.checkResult === 'ALM Added with test-folder') {
                    process_linked_with_test_case += 1
                }
                else if (item.checkResult === 'ALM Added with Requirement and Test Cases') {
                    Process_Added_ALM_Requirement_and_Test += 1
                }
                else if (item.checkResult === 'ALM Added with requirement') {
                    process_linked_with_requirement += 1
                }
                else if (item.checkResult === 'Process Added') {
                    Process_Added_Total_ALM += 1
                }
                else if (item.checkResult === 'Process Added with ALM') {
                    Process_Added_ALM += 1
                }
            });
        };

        getGraphicalViewReport();
        const defaultColors = ['#FF6F61', '#6B8E23', '#3CB371', '#1E90FF', '#FF8C00', '#8A2BE2', '#FF1493', '#32CD32', '#FFD700', '#FF6347', '#9ACD32', '#D2691E', '#FF4500', '#20B2AA'];
        if (chartInstance.current) {
            chartInstance.current.destroy();
        }
        console.log(process_linked_with_requirement, process_linked_with_test_case, Process_Added_Total_ALM, Process_Added_ALM, Process_Added_ALM_Requirement_and_Test)
        const value = props.IC_objectsChecked.testCaseCoverage && props.IC_objectsChecked.requirementCoverage ? [process_linked_with_requirement + Process_Added_ALM_Requirement_and_Test, (Process_Added_Total_ALM - process_linked_with_requirement - Process_Added_ALM_Requirement_and_Test)]
            : props.IC_objectsChecked.testCaseCoverage ?
                [process_linked_with_test_case + Process_Added_ALM_Requirement_and_Test, (Process_Added_Total_ALM - process_linked_with_test_case - Process_Added_ALM_Requirement_and_Test)]
                : [process_linked_with_requirement + Process_Added_ALM_Requirement_and_Test, (Process_Added_Total_ALM - process_linked_with_requirement - Process_Added_ALM_Requirement_and_Test)]
        const options = {
            series: value,
            chart: {
                width: '100%',
                height: '100%',
                type: 'pie',
            },
            labels: props.IC_objectsChecked.testCaseCoverage && props.IC_objectsChecked.requirementCoverage ? ['Process Linked with Requirement', 'Process Without Requirement'] : props.IC_objectsChecked.testCaseCoverage ? ['Process Linked with test case', 'Process Without test case '] :
                ['Process Linked with Requirement', 'Process Without Requirement'],
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: true,  // Enable data labels on the pie chart slices
                        offset: -5,     // Optional: Adjust the offset (space between label and slice)
                    },
                },
            },
            colors: colors.length > 0 ? colors : defaultColors,
            grid: {
                padding: {
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                },
            },
            dataLabels: {
                enabled: true,  // Enable data labels over the pie chart
                formatter: function (val) {
                    // Return percentage value with one decimal
                    return val.toFixed(1) + '%';
                },
            },
            tooltip: {
                enabled: true,  // Enable tooltips on hover
                formatter: function (val) {
                    // Show percentage in the tooltip with one decimal
                    return val.toFixed(1) + '%';
                },
            },
            legend: {
                show: true,  // Keep the legend visible
            },
        };


        chartInstance.current = new ApexCharts(chartRef.current, options);
        chartInstance.current.render();
        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
                chartInstance.current = null;
            }
        };
    }, [graphicalViewChart]);
    useEffect(() => {
    }, [colors]);
    return (
        <>
            <h1 className="flex justify-center items-center">
                {props.IC_objectsChecked.testCaseCoverage && !props.reportFlag
                    ? 'Test Case Coverage Report'
                    : 'Requirement Coverage Report'}
            </h1>
            <div ref={chartRef} className="flex justify-center items-center" style={{ height: '100%', width: '100%',marginTop: props.reportFlag ? '10px' : '20px',
}} />

        </>)
};

export default PieChart;
