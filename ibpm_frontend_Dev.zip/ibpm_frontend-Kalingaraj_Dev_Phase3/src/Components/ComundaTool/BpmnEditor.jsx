import BpmnModeler from "bpmn-js/lib/Modeler";
import _, { cloneDeep, isArray, isEmpty } from "lodash";
import React, { Component } from "react";
import toast from "react-hot-toast";
import { IoChevronForward } from "react-icons/io5";
import { ReactDialogBox } from 'react-js-dialog-box';
import ReactToPrint from "react-to-print";
import { js2xml, xml2js } from "xml-js";
import { ALMReqTestCaseChoose, compareTwoXmlStringSame, convertFileToBase64, getALMConnectedTests, getMimeTypeByFileName, isValidValue, validateFileOnChange } from "../../CommonUtils/ComponentUtil";
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import ShowDiagramPrint from "../../CommonUtils/DiagramPrint";
import { translateXmlNamesByLanguage } from "../../CommonUtils/translateXml";
import { BPMNEditor_Labels } from "../../Constants/COMMON_LABELS";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { Auth_Common_Toaster, BPMN_Common_Tosters, BPMN_Editor_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS";
import BPMNService from "../../Services/BPMNService";
import ResourceService from "../../Services/ResourceService";
import { getXmlDiagram } from "../BpmnDiagrams/getBpmnDiagrams";
import ALMTestCase from "../BpmnViewer/ALMTestCase";
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import Resource from "../Resource/Resource";
import BpmnTool, { extraActivityElements } from "./BpmnTool";
import BpmnToolMap from "./BpmnToolMap";
import { ActivityFileDocuments, ActivityNameTextPopup, AddFlowLinePopup, AddFlowLineTargetPopup, ApplyTemplate, AssignReviewierName, CreateTemplate, DownloadDiagramPOPUP, EditBpmnToolHeader, IntegrityCheckPopup, IntegrityCheckReport, OnshowActivityBoxComp, OnshowFlowlineActivity, PublishDiagramPOPUP, UploadBpmnPopup } from "./EditUtilPoupComp";
import ResizeCompIndex from "./ResizeComponent/TreeViewSideBarResize";

const localControlsConstant = ControlsConstants;
// import diagramXML from '../../assets/diagram.bpmn';

//SCREEN ID -3000
const userid = localStorage.getItem('userid');
export const defaultDiagramXml =
  `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" id="Definitions_0xcv3nk"
  targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler"
  exporterVersion="3.0.0-dev">
  <bpmn:process id="Process_0tz6k3o" isExecutable="true" />
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_0tz6k3o" />
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`
class BpmnEditor extends Component {

  constructor(props) {
    super(props);
    this.initialState = {
      isDataSourceMappingEnable: false,
      Taskid_Config: [],
      element_data_id: null,
      documentpath: null,
      navigationpath: null,
      AvailabeDataSource: [],
      selectedFileXml: "",
      selectedXmlFileName: "",
      IsUploadBpmn: false,
      selectedLanguage: { label: "English", value: "en" },
      userSavedData: {},
      isAddresouceOpen: false,
      selectedResources: [],
      flowLinePopup: false,
      onshowdiagram: false,
      isTreeView: true,
      showFlowlinoepopup: false,
      isdownload: false,
      diagramLevel: "CurrentProcessMap",
      isFromUpload: false,
      isSendToReviewer: false,
      ReviewerData: [],
      ReviewerId: [],
      Reviewername: [],
      author: this.props.selectedMapData?.author,
      authorId: this.props.selectedMapData?.authorUserId,
      userName: window.localStorage.getItem("userName"),
      userId: window.localStorage.getItem("userid"),
      userRole: window.localStorage.getItem("userRole"),
      FromReviewsentback: false,
      FromDiagramApprove: false,
      comment: "",
      getComment: [],
      isDefaultTemplateEnable: false,
      mappingDiagrams: [
        {
          id: "1",
          name: "",
          key: "1",
          meta: {
            collapsed: true,
            label: "1"
          },
          diagramXML: defaultDiagramXml,
          parentId: null,
          children: [],
          flowlineMap: []
        },
      ],
      currentMapDet: {
        id: "1",
        meta: {
          collapsed: true,
          label: "1-Map"
        },
        name: "Map",
        key: "",
        diagramXML: "",
        parentId: "",
        children: [],
        flowlineMap: []
      },
      newTemplateRecord: {},
      appliedTemplate: {},
      isDiagNavigationClicked: false,
      isActivityReplaceEnable: false,
      selectedIdFlowLine: '',
      filesData: [],
      newDataFromConsole: {},
      flowLineflag: false,
      treelineFlag: false,
      editAutoNumflag: false,
      rearrangeflag: false,
      rearrangeArray: [],
      elementFinderLoop: [],
      filteredDataArray: [],
      lastOccurances: {},
      showActivityBoxMapping: false,
      OnshowActivityBoxComp: [],
      storingActivityBox: [],
      mapDiagramRecord: {
        diagramName: "",
        docStorageType: "database",
        configId: "",
        configName: "",
        project: {}
      },
      templateBgColor: localStorage.getItem(userid + "color"),
      showFlowlinoepopupTarget: false,
      parentActivityId: '',
      targetActivityId: '',
      deleteStartActivityLoop: [],
      mappingAutoNumcount: [],
      createTemplateState: false,
      createTemplateErrorFlags: false,
      isApplyTemplateEnable: false,
      bpmnXMLs: [],
      renderedDiagrams: [],
      isRendering: false,
      PrintLevel: false,
      diagramXml: [],
      printTriggered: false,
      resourceData: [],
      diagramBpmnXML: defaultDiagramXml,
      getActivity: '',
      getActivityElementId: '',
      levelNavigationFlag: false,
      isEditing: false,
      copyGetComment: [],
      reArrangePopupFlag: false,
      isIntegrityCheckEnable: false,
      IC_objectsChecked: {},
      integrityCheckReport: { records: [], brokenFLCount: 0 },
      auditInsideMap: [],
      count: 1,
      CommentsReaderId: [],
      CommentsReaderStorage: [],
      copiedComments: [],
      selActivityType: 'default',
      EditedResFlag: {
        flag: false,
        ResDetails: {},
        oldName: '',
        type: ''
      },
      selActivityTypeFlag: false
    };
    this.state = this.initialState;
    this.handleBpmnRef = React.createRef();
    this.fileUploadRef = React.createRef();
    this.containerRef = React.createRef();
    this.diagramListRef = React.createRef();
    this.printRef = React.createRef();
  }
  resetToInitialState = () => {
    this.setState(this.initialState);
  };

  async componentDidMount() {
    try {
      // await this.updateStatesFromParentProps()
      // await this.getLastSavedXmlByUser(4716, {
      //   "id": 4717,
      //   "diagramXmlIds": {
      //     "Master": null,
      //     "Draft": {
      //       "version": null,
      //       "diagramXmlId": 4716,
      //       "status": "InProgress"
      //     },
      //     "Archive": []
      //   },
      //   "assignedUser": null,
      //   "assignedUserId": 0,
      //   "author": "balaji n",
      //   "authorUserId": "775",
      //   "diagramName": "IC report Aug-06th",
      //   "mapPrivacyType": "private",
      //   "organization": "iGO Solutions",
      //   "mapAuthorizedUsers": []
      // });
      // await this.GetComments();

      // this.intervalId = setInterval(this.myFunction, 1 * 60 * 1000);

      // this.myFunction();
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
    }

    // this.Get_Availabe_DataSource(); dont remove this func calling
  };
  componentDidUpdate(prevProps, prevState) {
    // console.log("didupdate");
    if (!this.state.isRendering && this.state.bpmnXMLs.length > 0 && this.printRef.current && !this.state.printTriggered) {
      this.setState({ printTriggered: true }, () => {
        this.printRef.current.handlePrint();
      });
    }
    // const { props, state } = this;
    // const currMapDiagramRecord = props.editMapDiagramRecord
    // if (Object.keys(currMapDiagramRecord).length !== 0) {
    //   console.log("changed", currMapDiagramRecord);

    // let tempMappDiags = [...state.mappingDiagrams];
    // tempMappDiags[0].name = currMapDiagramRecord.diagramName
    // tempMappDiags[0].meta.label = tempMappDiags[0].id + "-" + currMapDiagramRecord.diagramName
    // this.setState({
    //   mappingDiagrams: tempMappDiags,
    //   mapDiagramRecord: currMapDiagramRecord
    // })

    //   // this.props.closeAddEditPOPUP("YES");
    // }
  }


  // updateStatesFromParentProps = async () => {
  //   console.log(this.props);
  //   await this.setState({
  //     resSavedData: this.props.resSavedData,
  //     diagramXmlId: this.props.diagramXmlId,
  //     userSavedData: this.props.userSavedData,
  //     mappingDiagrams: this.props.mappingDiagrams,
  //     selectedLanguage: this.props.selectedLanguage,
  //     currentMapDet: this.props.currentMapDet,
  //     templateBgColor: this.props.templateBgColor,
  //     appliedTemplate: this.props.appliedTemplate,
  //     isDefaultTemplateEnable: this.props.isDefaultTemplateEnable,
  //     ReviewerId: this.props.selectedMapData.assignedUserId ? this.props.selectedMapData.assignedUserId : null,
  //     Reviewername: this.props.selectedMapData.assignedUser ? this.props.selectedMapData.assignedUser : null,
  //     author: this.props.selectedMapData.author,
  //     authorId: this.props.selectedMapData.authorUserId,
  //     mapDiagramRecord: this.props.mapDiagramRecord
  //   })
  // }

  // componentWillUnmount() {
  //   clearInterval(this.intervalId);
  // }
  // myFunction = () => {
  //   // Your function logic here
  //   console.log('Function triggered', new Date().getDate());
  //   BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(this.props.selectedMapData?.diagramXmlId, 'checkIn')
  // }
  GetCommentsReaderIds = async (diagramXmlId) => {
    const Response = await BPMNService.getcommentsIsread(diagramXmlId, userid)
    if (Response.status === 200 || Response.status === 201) {
      this.setState({
        CommentsReaderId: Response.data.map(el => el.id),
        CommentsReaderStorage: Response.data
      })
      // console.log("getcommentsIsread:", Response)
    }
  }
  GetComments = async (diagramXmlId) => {
    try {
      const Res = await BPMNService.getComments(diagramXmlId)
      if (Res.status === 200 || Res.status === 201) {
        this.setState({
          getComment: Res.data,
          copiedComments: Res.data
        })
      }
    }
    catch (error) {
      console.error(error);
      ErrorMessage(error.message)
    }
  }
  SubmitChangesChanges = async () => {
    try {
      this.openSpinnerRedux()
      const tempMapData = this.state.selectedMapData
      console.log(tempMapData);
      const reqPayload = {
        mapId: tempMapData.id,
        diagramXmlId: this.state.resSavedData.diagramXmlId,
        diagramName: this.state.mapDiagramRecord.diagramName,
        publishedBy: localStorage.getItem('userid'),
      }
      const response = await BPMNService.publishBpmDiagramAPICALL(reqPayload, tempMapData.id);
      if (response.status === 200 || response.status === 201) {
        this.props.BackToParent("checkOut", "success", BPMN_Editor_Toaster.Map_Published_Successfully)
      }
      console.log(response);
    } catch (error) {
      this.closeSpinnerRedux()
      console.error(error);
      ErrorMessage("Something went wrong")

    }
  };
  saveALMConnectActivity = async (almConfig, selectedNode) => {
    console.log(almConfig, selectedNode);
    if ((!isValidValue(almConfig)) || Object.keys(almConfig).length === 0) {
      ErrorMessage("Please select the ALM Datasource !");
      return;
    }
    if ((!isValidValue(selectedNode)) || Object.keys(selectedNode).length === 0) {
      ErrorMessage("Please select any folder !");
      return;
    }
    this.openSpinnerRedux()
    const tempTestIds = {
      id: selectedNode.map(item => item.id),
      type: selectedNode[0].type,
      folderName: selectedNode.length // selectedNode.name
    }
    console.log("almConfig", almConfig)
    try {
      const reqPayload = {
        mapId: this.state.selectedMapData?.id,
        diagramXmlId: this.state.resSavedData.diagramXmlId,
        currLevelId: this.state.currentMapDet.id,
        activityId: this.state.element_data_id,
        almModuleType: almConfig.modulename,
        dataSourceId: almConfig.value,
        testIds: JSON.stringify(tempTestIds)
      }
      console.log(reqPayload);
      const response = await BPMNService.upsertActivityALMConnectIdAPICALL(reqPayload);
      console.log(response);
      const data = await response.data;
      if (response.status === 200 || response.status === 201) {
        this.openCloseALMConnectActivity();
        this.closeSpinnerRedux()
        SuccessMessage("Alm mapped successfully!");
        const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
        const parentElement = elementRegistry.get(reqPayload.activityId);
        console.log(parentElement);
        let bo = parentElement.businessObject;
        let docs = bo.get('documentation');
        console.log("docs ", docs)
        let attachment;
        const isDocAlreadyAdded = docs.find(d => d.textFormat === 'json/file-ALMConnect' && (attachment = d))
        console.log("isDocAlreadyAdded ", isDocAlreadyAdded)
        // const tempFiles = (isValidValue(isDocAlreadyAdded) && isValidValue(isDocAlreadyAdded?.text)) ? isDocAlreadyAdded.text : null;
        // console.log("tempFiles ", tempFiles)
        console.log("@@@@@@ ", attachment);
        let isNewALMConnection = false;
        if (!attachment) {
          isNewALMConnection = true;
          console.log("@@@@ inside create file-doc");
          attachment = bo.$model.create('bpmn:Documentation', {
            textFormat: 'json/file-ALMConnect'
          });
          docs.push(attachment);
        }
        console.log("attachment ", attachment, data)
        let dataTemp = JSON.parse(data.testIds);
        dataTemp["almConnectId"] = data.almConnectId;
        let alreadyAddedALM = (attachment.text === "" || attachment.text === null || attachment.text === undefined) ? [] : (isArray(JSON.parse(attachment.text)) ? JSON.parse(attachment.text) : [JSON.parse(attachment.text)])
        console.log(alreadyAddedALM, dataTemp);
        if (alreadyAddedALM?.length > 0) {
          if (dataTemp.type === 'requirement') {
            console.log(alreadyAddedALM?.findIndex(item => item.type === dataTemp.type));
            const ReqIndex = alreadyAddedALM?.findIndex(item => item.type === 'requirement');
            console.log(ReqIndex);
            if (ReqIndex === -1) {
              alreadyAddedALM.push(dataTemp);
            } else {
              alreadyAddedALM[ReqIndex] = dataTemp;
            }
          } else {
            console.log(alreadyAddedALM?.findIndex(item => item.type === 'test' || item.type === 'test-folder'));
            const tesIndex = alreadyAddedALM?.findIndex(item => item.type === 'test' || item.type === 'test-folder');
            console.log(tesIndex);
            if (tesIndex === -1) {
              alreadyAddedALM.push(dataTemp);
            } else {
              alreadyAddedALM[tesIndex] = dataTemp;
            }
          }
        } else {
          alreadyAddedALM = [dataTemp]
          console.log(" else ", alreadyAddedALM);
        }
        console.log(" alreadyAddedALM ", alreadyAddedALM);

        attachment.text = JSON.stringify(alreadyAddedALM);
        console.log(attachment.text);
        console.log("attachment ", attachment)
        console.log("parentElement ", parentElement);
        this.closeSpinnerRedux();
        if (isNewALMConnection) {
          this.handleBpmnRef.current.bpmnModeler?.get('attachment')?.renderALMConnectByElement(parentElement)
        }
        const elementRegistryALM = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
        const parent_Id = this.state.element_data_id;
        const parentElementALM = elementRegistryALM.get(parent_Id);
        console.log(parentElementALM);
        const valueALMAuditParse = JSON.parse(attachment.text);
        console.log(valueALMAuditParse)
        let valueALMAuditParseMap = valueALMAuditParse.map(el => el.type === 'requirement' ? 'requirement' : 'testCase').join(',');
        console.log(valueALMAuditParseMap);
        const pushAuditObject = {
          diagramLevel: this.state.currentMapDet.id,
          AutoNumCount: parentElement?.businessObject?.$attrs?.AutoNumCount,
          id: parent_Id,
          field: "Data Source(ALM)",
          newValue: `${this.state.currentMapDet.id} (${parentElement?.businessObject?.$attrs?.AutoNumCount}) - ALM Type:${valueALMAuditParseMap}`,
          oldValue: '',
          type: "DATASOURCE",
        }
        this.audittrailpushingObj(pushAuditObject, "DATASOURCE")
      }
    } catch (error) {
      console.error(error);
      ErrorMessage(error.response?.data)
    }
  };


  Get_Availabe_DataSource = async () => {

    try {
      const response = await BPMNService.getConfigDataByTypeAPICALL("alm");
      const resData = await response.data;
      const tempAlmOptions = resData.map(item => ({
        ...item,
        label: item.datasourcename,
        value: item.id,
      }))
      console.log(response, tempAlmOptions);
      this.setState({
        AvailabeDataSource: tempAlmOptions,
      });
      // DataSourceService.getDataSourcedata().then((response) => {
      //   // console.log(response)
      //   const options = response.data.map((todo, index) => ({
      //     value: response.data[index]["datasourcename"],
      //     label: response.data[index]["datasourcename"],
      //   }));
      //   this.setState({
      //     AvailabeDataSource: options,
      //   });
      // }).catch(errors => {
      //   console.error(errors);
      // })
    } catch (error) {
      console.error(error);
    }
  };
  openCloseALMConnectActivity = () => {
    let elementid = document.getElementById("bio-properties-panel-id")?.value;
   console.log(elementid)
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const parentActivity = bpmnCanvas._elementRegistry.get(elementid)
    console.log(parentActivity);
    let docs = parentActivity.businessObject.get('documentation');
      console.log("docs ", docs)
      const almActivityType = docs.find(d => d.textFormat === 'text/process-activity')
      console.log("almActivityType ", almActivityType)
    if(almActivityType===undefined)
    {
      ErrorMessage(BPMN_Editor_Toaster.Process_Activity);
      return;
    }
    if (this.state.isDataSourceMappingEnable) {
      this.setState({
        isDataSourceMappingEnable: false,
        element_data_id: "",
      });
    } else {
      this.Get_Availabe_DataSource();
      let elementid = document.getElementById("bio-properties-panel-id")?.value;
      console.log("elementid", elementid);
      if (elementid === null || elementid === undefined || elementid === "" || elementid === "Process_0tz6k3o" || (!elementid?.includes("Activity"))) {
        ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
        return;
      }
      this.setState({
        isDataSourceMappingEnable: true,
        element_data_id: elementid
      });
    }
  };
  deleteALMOnClick = async (folderName) => {
    try {
      console.log(this.state.AlmDataSource);
      const res = await BPMNService.deleteActivityALMConnectByIdAPICALL(this.state.AlmDataSource.almConnectId)
      console.log(res);
      const overlays = this.handleBpmnRef.current.bpmnModeler.get("overlays")
      console.log("overlays ", overlays)
      const tempEditElementObj = this.state.editElementObj
      console.log("tempEditElementObj ", tempEditElementObj)

      let bussObj = tempEditElementObj.businessObject;
      let documents = bussObj.get('documentation');
      console.log("documents ", documents)
      let otherOverLayItems = documents?.filter(overlayItem => overlayItem.textFormat !== "json/file-ALMConnect")
      let almConnectItems = documents?.find(overlayItem => overlayItem.textFormat === "json/file-ALMConnect")
      const almItems = isArray(JSON.parse(almConnectItems.text)) ? JSON.parse(almConnectItems.text) : [JSON.parse(almConnectItems.text)]
      console.log(almConnectItems, almItems.length <= 1);
      if (almItems.length > 1) {
        almConnectItems.text = JSON.stringify(almItems.find(item => item.type !== this.state.AlmDataSource.type));
        console.log(almConnectItems, almItems);
        otherOverLayItems = [...otherOverLayItems, almConnectItems]
      }
      console.log(" otherOverLayItems ", otherOverLayItems);
      bussObj.set('documentation', otherOverLayItems)
      const overlay = overlays.get({ element: tempEditElementObj }).find(ol => ol.type === "attachment")
      console.log("overlays ", overlay)
      if (almItems.length <= 1) {
        overlays?.remove(overlay.id);
      }
      this.closeDialogPopupBox()
      const reqPayload = {
        mapId: this.state.selectedMapData?.id,
        diagramXmlId: this.state.resSavedData.diagramXmlId,
        currLevelId: this.state.currentMapDet.id,
        activityId: tempEditElementObj.id,
        // dataSourceId: almConfig.value,
        // testIds: JSON.stringify(tempTestIds)
      }
      console.log(reqPayload);
      const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
      const parentElement = elementRegistry.get(tempEditElementObj.id);
      if (almItems.length <= 1) {
        this.handleBpmnRef.current.bpmnModeler?.get('attachment')?.renderALMConnectByElement(parentElement)
      }
      const elementRegistryALM = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
      const parent_Id = tempEditElementObj.id;
      const parentElementALM = elementRegistryALM.get(parent_Id);
      console.log(parentElementALM);
      const pushAuditObject = {
        diagramLevel: this.state.currentMapDet.id,
        AutoNumCount: parentElement?.businessObject?.$attrs?.AutoNumCount,
        id: parent_Id,
        field: "Delete Data Source(ALM)",
        type: "DELETE_DATASOURCE",
        newValue: `${this.state.currentMapDet.id} (${parentElement?.businessObject?.$attrs?.AutoNumCount}) - DataSource Deleted`,
        oldValue: ``,
        type: "DATASOURCE",
      }
      console.log("🚀 ~ BpmnEditor ~ deleteALMOnClick ~ pushAuditObject:", pushAuditObject)
      this.audittrailpushingObj(pushAuditObject, "DELETE_RESOURCE");

    } catch (error) {
      console.error(error);
    }

  }
  checkMapDiagramIsEmpty = async () => {
    const elementid = document.getElementById("bio-properties-panel-id")?.value;
    console.log(document.getElementById("bio-properties-panel-id"));
    console.log("elementid", elementid);
    const tempLatestXML = await this.getCurrentDiagramXML();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(tempLatestXML, "application/xml");
    console.log(xmlDoc);
    const isShapeAdded = xmlDoc.getElementsByTagNameNS('http://www.omg.org/spec/BPMN/20100524/DI', 'BPMNShape').length === 0;
    console.log(isShapeAdded);
    return isShapeAdded;
  };
  getLastSavedXmlByUser = async (diagramXmlId, selectedMapData, fromMapLevelSelect) => {
    try {
      console.log('diagramXmlId', diagramXmlId, "selectedMapData ", selectedMapData);
      this.openSpinnerRedux();
      console.log(this.props);
      const response = await BPMNService.getLastSavedXmlAPICALL(diagramXmlId);
      console.log("🚀 ~ response:", response);
      const data = await { ...response.data };
      await this.getAllusers()
      console.log("data ", data);
      const ReviewerId = []
      const Reviewername = []
      selectedMapData?.assignedUsers?.forEach(user => {
        ReviewerId.push(user.assignedUserId);
        Reviewername.push({ label: user.assignedUser, value: user.assignedUserId });
      });
      this.setState({
        resSavedData: await response.data,
        diagramXmlId: response.data.diagramXmlId,
        ReviewerId: ReviewerId,
        Reviewername: Reviewername
      })
      console.log(response, response.data);
      if (response.status === 200 || response.status === 201) {
        let selLang = { label: '', value: '' }
        if (data.languageCode === undefined || data.languageCode === undefined || data.languageName === null) {
          selLang.value = "en";
          selLang.label = "English"
        } else {
          selLang.value = data.languageCode;
          selLang.label = data.languageName;
        }
        let parsedMappingDiagrams;
        if (data.xmlData === "" || data.xmlData === null) {
          parsedMappingDiagrams = [
            {
              id: "1",
              name: "",
              key: "1",
              meta: {
                collapsed: true,
                label: "1"
              },
              diagramXML: defaultDiagramXml,
              parentId: null,
              children: [],
              flowlineMap: []
            },
          ]
          parsedMappingDiagrams[0].meta.label = parsedMappingDiagrams[0].id + "-" + data.diagramName
          parsedMappingDiagrams[0].name = data.diagramName

          const dataTemp = await response.data;
          dataTemp.xmlData = JSON.stringify([...parsedMappingDiagrams]);
          this.setState({
            resSavedData: dataTemp
          })
        } else {
          console.log("(data.xmlData) ", JSON.parse(data.xmlData));
          parsedMappingDiagrams = JSON.parse(data.xmlData)
        }
        // data.xmlData = parsedMappingDiagrams[0].diagramXML
        console.log(data);
        let tempBgColor;
        let isDefaultTemplateEnable;
        let applyTemplate;
        if (data.template === null || data.template === undefined || data.template === '') {
          isDefaultTemplateEnable = false
          applyTemplate = {
            "templateId": null,
            "templateName": "",
            "companyName": "",
            "companyLogo": {
              "imgname": "ismile.png",
              "imgcontent": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4nO19eZxdVZXut/YdakxVpUgqAyGBJIQAgZAQIISAgIgIdBQFEWnaHqS1UbRFGx5KP1pRkbbRRujGJ+LYIhgaRIaWQSAhzJlIQhIyQKikkkoNqXm49569Vv+xh3NupUKGOnWreNbiR6rqDuecvdfaa/z22sAIjdAIjdAIjdAIjdAIjdAI/XkRxX1BXnfnqbrlrWuleY2/hQgDApBEbilifwggBICgBBAIIADYvo/wfUif70VJxF6ZICIg/zl7FfvTf5wFKvI+gfx3o98z94xcQwAlFH7G39c/GgDqc393z+hEiX8cEpg5cp8DoPpcUwRAIo3UqZ9CctoZdyamnPoaYqDYBEBkt5Jty+/Vb/7oUuhsOTQbnkWYZoZmX4xMKtm3BGKFBH7uHQMk+qIYYRA3+RS5pr0X5TEz5AJFr5fHHeR/lgEndOKvKZbhKvycff58QaPIcyDvGv5eke/vdW8AJAJxQu/mDQASRVCTZnWmjj3v5NTJn9rULzMOgpIDvYAjXnffidj50gIJesqh0sDoGSClACE/cYYIAjGr3TJQiKyGiE4SRYTBTqZnsn0ZsOvWXEuA8DvI/27+dcV/B3bt99Uo0RXsrhm9NkmEKfa9PAEOpdYKidNk7rFCzQGvUSI3YAFROFYAkO4WoHkH+J0V5Tpd8R0Al2GAFJsA6PqXp1OufQZUMahq2g941NG/IaWgKAGALSPIK9uo6gxVaGQFsPK/+8li2bfKcp9xK5JCwYiwyWqPyOp07ziGR67X9zPvdX/Juz9BKF8jRe7Uh/mAsgp/bwHI12K8522gZPQK3rEG0lZ/XrDhmfOSx573zL6m5EAoNgFA124ADJQfCVTPerlo1hdWxnbtEfKUeemX3di+phQcVEnH7qqBXk/t/yMHRnT4OadDFACCUsVxXXaE+lKmazULIEJg7qtdDp5iEwAkikqjfs0IDQ4JrHMIIA4fPj4BCDLdzgaOiMAgEuvevf2KQ6f4TADrwDlgsScXRsgTsQSAy58M/HrxaQCVSgOwDxXfZUconwTC0eTUQCk2TknQ2y3oE0qNUPyU7d1jfqFhpgE8jbB/sMm7gDScnEAAEJMK3StPP0KxEbmkakzzHLMAuH9GBGDQqN/s4qFTfJlAhIWP4ewCBrtXHUe9DR+XhjcgXQ2QbIeZ0OIxUKXjocbNAcomPKQOm75+qJ/1PUkkFkGITwCSJRUMgQKB9//pgpF++5FiqX2qnCZ98HHseA65l79erVKV0znbCRXkwMymNEu1EEpCb38J0tv+md5nb9qTmHjy87xrzfcTE+a2J2f+RXaoxwJEnf94NG18AkAJv/CHgwEIOmrHU92zZ/HO5y6hTMun9OofggVIMIN7OgEwRFs7yrb8KoBIMwQ0XW15BsHmp06lcSddn+to+E/9xgMPJGZfvnSox5VXZYwh4RKfAASZbkQclKEmeesXv5XWzQukbXtaREBsapHMCoCAHCAjUs8na1+J2Q+Bd70BQuKabGfjotyLd76UOuPay4dsUJbCOuXAjW185lrnsm4Ch1IAgnV33hQ8d3WH7HjubG57N03CENFgCIRNJh0sEFZgsbgEU10xZVr7OxgQJmMedA7ctG1SbtV9n+x5+EtvBWsf+tshG2AUYzD88gAUk1wePEnPrmp++YYvyc4lt+jWt8qVNuAMFlj4lUCxgLT528DUyMC03GfYgjbEwcrMm2IBHaID8LZXZwRrH7635/nv/+UQDBMA8rAEA6UYeUUKIhH1VDiSljdr9LYnXuXmdbdJVyOIAQ0NCINYW0YTRBQEbHw+BhQLhBlgDqFiIhAGhAFmApisNhBAC8Aaeud6yFtL/qP7/r8fEiFwuRaJQQLiE4BUaYVTS1RAAQjaN03n5tX/w5vvm865jmJiWDtuJ0nI2ne2zEYes90zSwRniCiI1YVbUdiWCKRtV4U0bft1z++uvaBgg0X47ASAh5UA5Hq7AZenKKATsOFXc/ntR+YKB6GDbIVARIHErHRox2ACsYWoibKfC2Fi5rsW1SvWX3DOoUMbO7+hoxHSWvfzzBPfPqtwA3b4wniYF18xKFlcGpYoCyMAvP5nc6Vt0wPo2g3SlinMAIzzRtbWM5IGSCEAWEOgwMLeD3AOoGjj/CHiF/iohq1psAqChMFC0A3vjNftDUuCxi1zCzJoAKGmHTjFpwE8zwuj/oOWDXO5a/ti6d7tbaLLk4toz1hKlINKxvxUVU4FCRnAprX5xBZhE0Ebexh7lPlO7dvvkAiYyWsD3rwMwapHbizEuCUPCz1wilEA4ilPHijRpvvOloYVU92KVZZpxAJhgvHtBIIUqHT8k2rahaeo6Rc8hJKxICRBTGCwcfIkuvId8ykSHZjXlVUBTjCI2fsWetMLF3Y/dceFgz7wZHGFg8DHwb7YEkFEAqt8C0Kcbb1dMm2GWWC/kUOEQQyAyWP1BYL08Z9eDuATua3P3Kprn/8Y3n11JmXaIMwQ6ycYE4Ewl+GdRPMZzQTlNA3ERpfKCF3Tu6UoXnElgCcGc9xikVdxUawhO1l1Otg+oN68+BZpWmu8eliGI/TqRSLPYdW2o9S0825MHfeJS9S0D9+oxs9rF5UCcbjaBeydQpcjYJsvcILgsoYkymgeAUQzuHH7p3ufvrt0UAfPQbffaJO31+zQKD4n0KlRYFAFgBtWTtbvPnEescviOebBO2pgCu26y+xFKDFuzsb0mV/7XtFH/7Myffxl96vqo2qZEsZn0GZFg63H751JGDPnTIKG0R5sGaEF0tEC3rP9l4M3ekN+ODFU3eJMBCG6J26wiJtWn0rM80W0wcX7VRnacecQhip839dLnfmPVySOu/hKNeaYu1A+ARCJyAxZixAVJoS+jsAIG8OElCyQxm2n5rYuP3XQJsA+V1zTHGsUUJBC0J51M9G5zThvka1eLnvnEjWhM7f/fFlqzlXLEpNP+2pyxnlHJKaeuUmVjwUxwJqt40cgplALiNiQE5HowTiI3N40OXjtocmDNXxJFVW5PY1xUKyAkEKQlE28RYLXrMNGEWaTZz7ZRE1eJm8/lD7jmiyAHbrlnY8GG576ONe/9R1sfRmczUCJgBFeT/rkCgBYARFIWzOku33qoE1AzG52zE7g4JM0rke449jYYNE25odL64aqmiTcYHkglBh91MaiBZ/7rpp25pz0GZ/9nRo1bo8kUlDahJfCztmNaDxbZSQBEGSAipp/GpzRA8qbH46lFhC7BhAMbjVQOmrh6vu+XGtTtGJXfn6e/8A0QF8qmn3JagCX59Y+Pjd486nPcXPt31PjNjDDRg2musjWASXnlAtBmuvGxD3ukNzGMInF3MboA4SMGCxHMGjb/DXK9ZoKH5NP+/oGDX7VCyjaRGIAj5M64aKVJZ+643OJKXM/SjMWvgRK2mtS6Hi6WoIVBmmqi2O4+ySDvRxumUCEadTB8gOpZ89pZtIVBNokRdkCPZzDJ+J9gfD1gd+7+OJ//gNNmHFmas5fnJOYdlotFZVZDRTJGdiohDtaBn7DfZAIhf5NDBRfJhDwIcpgEWc6vbPnVqBEU9De8aOIlx5fyFR6zrUM4Pls87arcg/dugRvvQKTKYLPQ0AIurcnnhv2Q271R/cID4RiEwBR6fLBjgEV2KB4XTaO4fMAYbLG+QE2VIrxkXKvLp6Y3frahdlfXHeDNO+wvohFFlknlIWQjCFDt0+KpILjGFp8GoAznXFda5+UqrTeNoXM9swPy7ouLHTaII6Z6nnmruty65d8hre8eiJnsiBhKDYMJ5stZNvXSNKDlw3mrrYdoaYduA6IPw8wiJlAKR79pLBcaibeoX6AaN+f0ClzDuChe8u6bn2a92w/K7dh6Y28/LFzdUs9oNnkBXyUEZqkhNjnKq2Ma8j7JhmOeAA314MkBMnqo3+KRCm0vRf7okh/gA6bCeynFnAglFn75IX6rWXP9T7xw6f1ikfP5T27ANbW5JABoAiBNINYQUBGKFigxk6Je+h9yHY5i+FKg6MBBlELqPKJ4OYtVr0ry5Aw8SM2DHT5AIehOxjKPv79z+deeeB22bG+VDI9JsDnhE0JOzOjQKzBIEAYJMprnUTNUYMwckMO2RQX7C4+J9Cp3LguuC8ac9weatpcbaqA2tt+h/kDcx7jhSWvHLwv6n31vmqs+9NUpsTjmdcXVyCTLTaoYgJEgZmhALDFESoxzA+RSGyyhJRC9s2Xrh7kWYiNYuwQkoy0BhtEMejt+KFQyisZcSVgm4MIYWGRJNB+Fktu7eOXBqueuFu37Hpdb32tBplMMZjtdcPun8LhxhEHGSfnczBBMUBVNUhMPbF1sIZPYlrqxpQIjNEEqFRxWCodvGQwlY1ZQ2U1vWjZUSyATcOGRaEwFLRPsQ8nMKhbWxyseaIC6bJHM3/68XRp2VUtQQbCygI/yAsV2OIHOfzbvScCQIdbzYT1K+lZC18ZtAmA9T1MNWTAFDModPDLQenTv/oHyeUeMxNvsYDe4UNEE4jFC+yNUcg1v3N28MYfbufGd3bnnr/nVGnaXk1BDg7eBY60rtWUDxPzv5v/SVufw9rm1Ikf3JGa9+EdgzYBzvuPydzGuFQjBZlBTgilTrnapERBCDd0IG/FhubAJoQsdT3+rfnZP/3o17m1T16jt7xsH12MMEXxA/Y6YVo5cn13L5f9YwCsgNJKqJmn3z6YY6dUujxsVD3weY41CnC2crBJjZ5yZeLweZdy7euABXWGzLfev0X9GuyeRubRb57NmbYbg5WPnA3NaWGBYgMRhwBCBNamFXx+jiHC/KhGiYSbRsYUUieft674lHMHVf2DVBKAXQADp5iNtdh20IPbIkKNm51Vh8/5Lyqu7Gflm+dgWGEIstCtjZ/RO9c9pzc8fz4FnAYbiLfD2JMo4+AhEjp6jKE1B3sxX3zEAQFo4tFAzRHfHNSB59EwCwPzn6cA0JCe1i+o8vFjdFfLBWEbeeuISbj5Q3o7gUz3xaw5LBax/YwgXOns+gSwdyLNuMTvExAJdxyFwkAglURqyvG/Sh5/+lODP3BXd4hHAGJHBFFMOer9Ufqsr7Unzv7q4kTVkXaFwm/dCquCNkwMtMnXO8aK2+Xj7Dt7BDCYAI18G2+ZrWz+38gZW/OfQGL2B4LSq7/9mfRRJ7QP+sCjFIMMxI4HKOTG0OTEk35G4479LkqqI3kBNhU6XxMgjxEUjT7Mh4V42dctwsibFX+sS6j2HfgTWqBYQU06GslTPvS9gg0a0Y4mw61PoKMCCkHxhbd8Q0084QZKl8Hl6VmSkUSQTd1a/8Cnin3kEPHyXazvVj6Qpwk4kvQRUVCHHY70xX99Q/EZi/65YAO2j6xAw2x3MABXF4/LQTlQKrnkB/+aqDnmJ1RUZbqAQANw9j3KfLfZA36FO+0QIoxdAojC3+3nSUI/IlFzJNJnXfKTktMX/WtBB2tGFlvJJT4nMNPe4FEqheU/AIBGjf9KYsIJgV7z2DXS0Riqch3i9SiiBQwjyReNDLIXcM0hvJOnJQz1hECUBspH1ZZc+U+PIacHDf1bKIpPANIVNYCE++wKTOlFt3QD+EL2lV+251Y//jHZtXmm0dmWnH/izQAQ9hIg7/YLu/eijGeAk0AyjeQJCzcqJC5LnXTOusKPMqLFhmMUMBSM70vp+Z+5UU2Zd0nqzL9ppbLqLJAALIAELjy0hR6TK9A2+6cidQU7FIaxtKoIauyk1uSMk25InHbBJSVf/vchYb4jL8AxUKx5gH3UXQpOJR+5fiOA0Xr76i/1/vGuD1FXy0I01FaJzvgNpeRNgPLJHYHrM2CrfKWjQFXjaxPjpy0r/cLtV5qr/3wIR+Z2JSO2iY4XENJP4WUoKXHEST/Ktdb9Qq9fshBvrzqDSqu+FGxZUY7GbUAma715A+oE2ISGJRVQ46eBxk9+Td7deEfq/M/WFp1+0bKhHkseucU2rJxAIDaYUpyUqjq8HcATurH2KV238Ta9e7vCnjoUffHux9HeCN3VDqUUUFYJ6em6NffIXcvosImgOedky/761m7c/PBQDyGPHONVTGDXGAXAPFlctiluSoydHAAIM3XfO+2MfX/6eQDfH+xHOiSidFE1xPUIHPhkx35gRGFbRP4ZUqrIHhYZT9E91iZRhWwQ+edKIuR5NswAIY5GhGBQqaej1v06rLaGmQLFMHUA+hA3vHoSb3t6PBrXIuioA2kFVTENGDcHOPqi+tToaauH+hn3RaR1Ns54O8Y8gOT/HKYUvP4vd+qN/3WBdLdMp55WQAMsDOqsh+gVkNbtW3Kv3/PH1ClXXzvUz9ovJVN+39mwCgMl09Hg0TT60K4RrLh/Enc1zaPiihv17k1jkO2ElB4GNXYagjceuyh9yqdaUycuqj+Ua+s3fvBZNK+5Mdj5ylRkO01XL00W0cvgTAukYw+E35ouyVVfzDzxfy5UR551a+q4C396KPfLLfvdzMxTP0Vy4aWP693vAD3dUOVVoMMOX5Zb9dStpR/7Wmdi5vyDBo+KSqbFFapioPg0QFFFDYBDVk2ZF3/8tWDrC1fpurUnSm+HKyuBhBEIQKPGbQjWPPFSz7M/uLXk3OseO9DrSm9dqSy/fRHvfPEe7mkCNNu277A/I3/blvCSbUOw6U9TVevOe7LP/KA+fd6B30/vfmdG8PJDi4KNL32fezuQ/cMdFrwqMPAzTKWqsX+Vfe2xNZlli28rWnjZfQc1UVb7xxVvxegDSOS8gAOn7GPfSEq69OZg7RM3UfsOW78xqHcSAbtjqDrqodsbFlDbjnt7n/6329InXXaXGjtlvwc5Ba9/91x01d/NPQ2W6QYswoHdMaTFQ8rF/u3AI1z3JiSHezNL7rqq6ANf3C/cK7vykXRu+WP/nVv99Cxp3m6ZZbKjCaGwk+qe3ci+9tiJia2r786+/tixYPpm+rSLggOeNIdzGE6nh0uiuML8cnAiwNnMbcGGZ2+i1u1mt43f2WEmz4A3CIKEiXyb62r0iodv11tfvG1/187VPjofvXsele7dVcTkV7oEAndCiGj7fyBAENlgqjVIM3jH2hpu2Prkfsex4ZVJeufWJZk/3jOLm7ZbP801pyBohHsHhBQQBNC736nIPPrjm6Sjeb9jiZJLtg2/MPAgl3+w+flr9K43r0NvqwXgsOnA5S4kDmfoMowEIYJku5B79Vcf637w+nnvdX3avuSr0lFnoF6BOSUMGn6njxcIjwYKTYNi2HOFCHrjC+h59FvXvNe9el98YH7w6mPzCWYPIYmZ2oTNjhIEyqGT7OBIAN69DbkVT1534JOW6/ZzE4MXGJ8AdO95GweBVQ1WLa7OvfDjT6Cj3kCyyTRbgBCUO8gBNrQkswtYsQCiARJwe8ORqqT8T/u6vl575yLpqrsYGoBmr95Du8++hxA0INY0OD9Aa4A5gNIM5ALwplevyr3xxKT+7iVNtZOkpe5eaW0AhKBBxkcTApOyql8BUCACzG5i8juL9dY30PXT638rzXX77yxBKp3XlGqAFOfx8aWmebOAD2A7blC/4VzOdJ4rZqZsjZsjmGLyP51ZEYKZQAveDNb/qYIbtnyyv+sz81XS2VAszIAmy2CDAIYOVb/5nUOn0MHHWUABgd1ns7n52bXPze/vXtnaN7+ht2+oIKu/SMjjCowWs8qa3D9mzA7OTsLgui3nZzet7Pf6UaLyqhlueuOAhscmAPrtF5YIKVCQA+VyFfv/QnCmtO/2m0gM1r0PpNyoAC8A5hQwM8kQQLpaEGx+8bJ+r5/tuBS5XtPIQcMz20C+bX9f93rEGQS71+weAA2ACdzaAN6+rqrfoSy9b4xIpMdwVNU70Kkv4YaoJCcgwoDs2V0dLHmger/zluk90tUBODlwHz6+KKC8ppt0FtK2E9Ja/8Oeh/+R98KtWtgVCUEyHV+CBGG4Z/8LJw57OZRi/yG3gpBE7s3+/TPZs9U4lXZFR7191+07Gv6J3eEr2n5GG81hogKGBILUsWffA/xPXl4gW7vhyN6ffeVId/rIe1ZDJez06eDoYv0c6WwB7yn6YPePvlTOpCNzAI+zyDXtQHbZH4pZBElJbEvWTNn2Hnc7IIpPACbMeoU6G18Sblug33qqAmXVP/eqz3KO2HrAIuAeU5l1TSUIKp/5/ZDAqCzXjkUJg5u39//h7j3GqxeAtF11bm8A723zfTsZtk2nrOaANoARxQBaG/e6jeppm5eomjBPN+4AgUxPYf/A4UDyehV55osfl5BAd3V+Xt5e/XnDb2WdvHCbusr0QrpaARCSJ5y+PDn7zOXvyZQDoNgEoPjc63foXauezDxyUwV07yzpbjOKioEoR8Wjb8UDMIn6qH37fh7ZSWN3FhBgVkYu0+/ziNZWhVt17h1BhDt6nR/gNYBlOoc+gxMG1mbzaF9izsIcTBU+vBKER7rZCCAEpUYcOJ83sT5Dbzekt9vEEVGBETNPQgqJmilIHH/GOjV5xpX7ZcoBUKyIoMSEOd8KXv7Z/bp+7cV6xyqI2HDK6jIj1dYMjDnydt6xDh7jDqfajYfs1D3sTwKB3YY9YoATECVQo8fv42HKQbrJr3oR8cwXb+/dGUMuHBTjMDIb2y8CCRIAM0gzEiV7uzZUXLFeOvasV4zjxKg4I6TRIF2i/+d77yGKSkCkfoVk0RtEyn/GbWJRAKS4HMlzLkVyzlmPpY6YGctp5rE3iUqe/rebAPxgf5/rXXr5P8mO9ePFbuF2ImBWigmcwj0GbkOkgobZ1k0wK1pNOwPAH/a6PlVMBjfV2uPhBBRI6PQ5vL/PAJINDWGjBPs5OEHREFaQqrF71SGSYyZsZJ1dD5LjYJ/apemjJ5nlCYF/yLCXoRSVQlWOfXTUbf/z4HtO3I+e3d/UHhQNxTG/AACpXX0tSirMHNuYOfTyor19QseQwd6JYgKQTKNo+oLH+71+qvKPEAEFDNIaCChc+UGo9s2qZ5A2m0LJOoekAeTgi0ZUVAletXSvCiGNGsfFZ11pmWuOpnUNsymP8fkr34UFLGa/oRo3Ganzrohjag+KhkwA1MQTloHUUnGrANZUCPksWpT55gPuJDDTtkUddSqrGWf+ot8b9LbdKyXVprVs4HYAuQbSfcM/gCO+ANgoBNFkVr8WJGqmcNH5f9PvrWjqCbeo6sOt9jLmK+9gx74r3zl/VsCBBBJlVUuTU08oOPp4yASg6Nwv1yfnXvEoJYt9Fw8XFDvHKEreDlqToaomQJVUXL6v6ydO/eJGGn30RtIKvplD4FQ/2zAQXt2TtprBhYdOW2hAaQEmH/NQ8pTz+1XP6aPmrEl94LLlKCmzHbzIP7M7y7gvjtszXwSqeizSn7rh0eS0OYdU6h4IDZkAAEDRWZ/9t0T5YT/hRBpiljZIEpEVEl39TouayU3O/sjK9Bl/tXJf105WTV6XrJpyLRKlYNZQ2nUQj4aCCFPBPkcgkUiBjec/6VikPnDp/3vPwUj28sRRJ6x0Dp3blLoXSsr/bQW8fDTUjFN+kpp8zL8d4LTFSkMqAACQPvfaWxOTZj9IqXJ7No+JCthpAqMU4CQgUVKJ5Omf3qYOn/GhxMRj336vaycXfuWZxLyrtlGyAloCY0I0gZztZwYFtiFEoEyoGJg+AaIBBAQqP6xVlR12eXry8c+8172KP/yFt6my5kPJmfO3Ubok9Gd8dtPmsW2dA1CgUdVIHb/gLqjklwc+k4dGwwbBmXn0W/+tG7Z8nLevgVGNBHcWKYmGqCIkx80AJh7z3dTpV/w2WXP0Ae3Py25bPgvvvLQ49+qvZ3IuZzRAIFDaHC+LwMb7gY3zbb6AAgHKx0CNGXfFqP+7+P4DHUf25Udm5V78/RXc2vB1rn/XNKswhssmfwiiCMkJR29Ux53yUNmnv/6NQ5mvuGjYCIDe+eaY7PqnZxDzP0hz7cV610Yg2wMUVyJZMxU06cRl6Gy6tejC61866GtvXz0ju+yez/HOzV/k1oY0sUACs2FU5Sw0zCWDtEAkATVuWm/iiJk3l37u1kPa/99917UL1LgpN2a3rV9IjduA7l6gvAJq+hxIkLs1VVnz+6Irrt90KNeOk4aNABSCgvVPfTHzwm8uR6ZnIe98G5LLAllz/hCzQKVHAeWja6Vy/NKyv/nmw8mxkx8a6mcebPqzEgAAyG1bMVm/s3qBXvJrJGZ/+Mug1HxGAgBe4VXP3ZGcv6i2+COfPWgt836lYScAun3LGOlunonGteD23UBnEyToASQJFFVCVU0GqmcgNe2cAcfMXLu6VLe3JFmloA6bGKTGTe0e6DWzLW+NSXTumsnN60Hde8wpIqkyoPoYSOmYjemJpzQN9B5x0rARAN79+nW69umx0lo7k0pqPiadDZBMF5Dphuis2cevikGpUUDxaPC2V79Hk+cjNfuStckppx8csjbuZ8/srtK1z95A7y4BBz0zqWzix6SrCZTrMSVpSgLF1eC2Hb8njY1q4jzQlAVrU1POGNLnBoZYAHq33D8m0V1/vnTU3ygtm6Yj212M3k6bnNFh/d4BOXSkcKMBShVDEmXtiQmzaqWp7iKaeV5T8Qf+bq9VHNS/NkbVv1zK9W8gqDq6Jjn+5BvR3TwD2Q6wzgKShCoqA1LlQKrkN7ml/36fmjQXatJ8pI5dVLv3kwO5V24qxcQzb0fdcwulaW2SkJrJ2Q4gmzHnB9kTRaADW3Cy7eaRgiRKQUC7JEtr0zM+vI2TxbeqI07elJx4YsG1w5AJgN7028/r5jeuRsOKuchmAK1N+KUBzdojcSSwTporz2obRruYXQClAYwaj+SMc35adNH1VwMAt7w5Ve/ZeD62PAxUHnM1ehvnoq0OQVcDFAdgbYEo2jaIFsCdRQRVAlU1BVQ1BbmtS/8hdeQC0KyPv52eNM9Dw3Mrvn2P1L/8WfR22Eqjg5VFEk5sDpzw2EObgnanjog296eK8VBHn7uSu1suK6Y5P9UAAAqUSURBVP2Lb79nbiNuGpLDo4P1/3E9b3/8NnTUQXJBXlWONJtkiWaPGYA79YMJwoH9KQDYVOkYQFk1UDF2DwBkNv7s+mDFbZeLqLmquxG67V3bF8ge9+pwCI4xgGkuLfZZgi7o3RtAu9aDkLhb164Cdr+zM/PgtSsTC65+ITnxxH9V5VP26OJ3QN3tJt+jlT3DSMO3pXPPbX/35WcxZWdiCxVv2QVevnguiisX53aseSA16cSCtZ4ruAbIrfiX71DD6q9Ld5sttOgQn8faonBMLl5EgMDky0UbhiFwwsIGwJEsBY2durrog5dfJDufOQm5rkepZYtirc3Ea20FyRSS2KKD3DmDAhih87Bwsv0AbdKGOazksUBSZUgedyGrXM8pybP+rl0v/epi6W4+iXMZKCZobTe0uOd1R8kEBiugrQZwmozZtp/VAERDjTsBydOv+nZ69gUFaT6ZKMRNHOnO2rNly+/uRVcjRAKwaJBWIdNdLp4p/N1OvLOjHtnDZtdQct7lK9Wk4z+ZzKz7sbRuvRkd24m1aaZsbC5ZhtvijEXtevyey9fbSp5D7/gV7HL6djVLkIXUvUmSzXwQJdU1JJ3XIVG8kLuaJkAsY5nDVrT+wInIeCQ6TvbPJkyQ9kaQSi34zoPLbikETwpaC+DN9/8dd7wLZrdJw+bcI02boQGxx8KHBRvY3TvagzpJpVF08id3JCcfebmSVTcH9S9fID2NEM0WLCKeib6JtESFTMLXLFPIvu7wgRbC758PcKqbwM3bpueev+carvnQzTThjMtU6cQGaItuitw73IGE0KENbFk62pncwteEBcGaZ5LBOyv/oxA8KZgABO21E9GwaippZfLj0U0aHpgJC9iAx+2R27DpdvFYAAWNnrqJKiZcpLrfuhltW/+SgizC8wLZl2E90FNCZtgmgXlA0FAIJbLynWYQixEQ02bOqnVub0Bu6S8+HbTRSWrCvH+W4moPInVVxvAomwjq2Aui0RDCALHtUxgIOJdB9o0nawrBl8JpgJ76eZyummuYCWNrfTk2nPhw1SB8zdbmSSzCVwvUyYteS846bSY3Lv9LZDqN9mBtK4nWy3ZqNsJYcY6lZ6xjFPx93b4BcX6BRM2IPVDKRSk7NylsX3MLjZn5e6Qrnjd7ECnCfHePiCD4swZCITOCAysMDLVrS0HYUjABUN0N6USQK3YQLPZxfrhDx8f70UnT7CeHNUOYkBg9BeljTrpRr7/nK9LdHKpZmDAy9Cv6mego850giviV6tvE2jDOf5dNG1yRUGuJMEQzgg0vHBdsr5+eOv7TSw0GMfo9hBouCk/3CGRnHiQ0h0zQVJgArWACIAhtudt1wzYc8qsyAtmW6JYtgQ39bEOHSSdCGlfPR8+e+fAnhxpnyzh3biVHGN+X+f51lwcQ85xeCyCC6RPrPhg0MpxDaVcr53II3l39FZk09w5KlHmAiTdhEUfTnzXkTYBFDTk/wz57omx0QfhSOBNQUgNWRSBtVg2xTcKwDmFYdoLMaghDMyM49iCIQKCqJ0NvfhDcsd2qaBcZwGL44SdT7EoW7z+4VUkRU2M9dQcDE3PknHPOwuNjLHrYawqEexsy2UXSvHshlY+Dy1v4Z2d34nnEzGkXWYTPZyBpxnzw6H73ocZOBRMASlesR1fzOolMDHtcXmTVs0CCSFwewe5Bk+FPsihQExZcTkEmPODJRRF2xXonMvJ+dIWF3cANitcfMWO/H/bkJet7INRQ1kw4X4JYQTpa07x5eZqpCMQ69G38ptTQkQ01RJjqDuFo5juJyrEF4UvhfIDqmevRVrcx3JXDeXYxDJciDIraTztxSgso0AolNYtC8wBrryPX8UySPE8+PD8g4gxGVnseg933JBoO5l/X+wqZHnBrPSTX7TWKW/nh9+GFiPL8Heu7OK0kAqoaVxi+FOQujiqm5DlEPrmS5wxyZGUg9NDdHn4BpKNFcUfdr8SGZqGwAGHWLjxVPBp2UXTlRWyyOKGBSzMDLvLwzM5jvjUHItaQJ6FSZaCutoiGCcfmfQF//8hzR6Ig8x0CVY5bXwiWFFYAqmfm2UB3ahflMR9mcnU+Yz2uXxO4vQmya/mTREWG0c6Rijp//kRRxyz4v0PVjb2dRXeQpGNGVPV7wQl9Ab+zKFkCNXoiqLcnz5GM+iZ77VD25oAi97f3G1V5ZyFYUlABSI6bBQlcdQwmEtACdnh9ociKQKSBg30/AJAT6D27ocadDBSNNgkURFZ5NOzzkywRBor/THQ1EuCZ45gcHheL0KzkaRSyVUsA6eJemXR0Vmc77Wcl1Dg6uuL7EWxv/gwMPZEqRWr0xIKUhgsqADT6qJ+DUn5S2G3FsoWasGePeNWf5xw5e9vaBKqcCqTKrK23q9F52X3trmMcw3bvgBeWvMjAhoLhyaHo41PAayxfkXQhbdPO5VQ59jV/2ESek+deI0SFNDSB9r3AglNHF8b+AwUWADVu9hOJmuPrSSsTr1sNAI7k/r3n77pzcMQJtCuusxMyajKQLA5Vp2OM/d2vrDy7HTp/TlhMWdh28/LOG7wzFl3N0ejCP6/4vEO9SkkvnAA6DcZ2h683fWT3KdpwjyPt6oQBSiAxdXbBdggVfmNI5eHXovIIP0F56VgNo+aDqDBQWDRyGbNMBonSsbWSzdSG27sjKtrF1X1UNzmbHhEO8YxFHoN9rUDsKvfvURj7e+ECEpOOgTB93uQ3tK0CUl4oGNYhjNCTmBPLodmGwAqJKbO2UFfHRwrFjoIDQpKzPro01935IVV++OO6djWop916+EAYhwN+u7YTBmcuVBo4bAKotGKltGxbKcKTo98La/p9GCzO03eMIG8CjHD0Wel9agkh88WreC9YTFBHHIeEDqZJcVUWXR0A57yG8So+kgV1ggRtMIOJI2cgOefcLHd1faL0iq+tKRQ/hg0o9FCod/Eli6Vt96UuHHP59GgqOPQDnFbhvR27qFduk0AOOBLWJRD6ETb6876JMEqv+9mD6eMX9N+wahjTkO8NHAhR5VQ45rNlptubL45ZAGDxAeJyun1MQ1gnCJ2zPOY7c6IRdi9hiQiMQqJq/N2FHn8c9L4WAFVzgg3ELcwqkkjxqV6fcUPohdswL/TWuU/4KJHPk/9dYCFi9prkHL7K8UgcPvXZIZyKQ6b3tQBQ9fT/ZiTCZItzzjiM4R3i1wlKFO4V1gWi9X9YL57R1yE0DFc26cQ+ckhMnT1kczBQel8LQHLywvsTE07pBCf8bmzWph5PkXDSATvDBE4YDubF+767Z+ishYJkXifbYpbFoJGpqDRLnHvfniH8vhYAAFBlYz6oJp9WmygbB0IC5JJKrsOUuIKMMu85++7Amnn5ApuPCOAzfC6G9+bEOpEkBKqeiFRZ9VfLvnzXkDR3iIPe11GAo1ztawt4zYOTde1KJOZ88rfoagV0AOEAyGVhGwzaDKF41e2bN4pzIJ13734333FRBQGQVDGEEqBkySvcuOOO8mt/eMC9A4Yj/X8hAFHK1a0qR2s9oDOAzoFzGSgrAOzsP2zpVVx/4jAf4OsRZssGYM8WJhHT4aNklKn8TZwWpI48rncIhzpCIzRCIzRCIzRCI3TI9L9wXAdXACGNUQAAAABJRU5ErkJggg=="
            },
            "colorCode": "#fff",
            "navUpIcon": "1",
            "navPreviousIcon": "1",
            "navHomeIcon": "1"
          }
        } else {
          const templateResponse = await BPMNService.getTemplateById(data.template)
          console.log(templateResponse);
          const templateData = await templateResponse.data;
          console.log(templateData);
          applyTemplate = templateData
          isDefaultTemplateEnable = true
        }

        console.log("#####", parsedMappingDiagrams);
        this.setState({
          isMapLocked: (data.diagramEditStatus === "Locked"),
          userSavedData: data,
          mappingDiagrams: parsedMappingDiagrams,
          selectedLanguage: selLang,
          mapDiagramRecord: {
            id: selectedMapData.id,
            diagramXmlId: diagramXmlId,
            diagramName: selectedMapData.diagramName,
            docStorageType: data.docStorageType,
            configId: data.configId,
            mapPrivacyType: selectedMapData.mapPrivacyType,
            mapAuthorizedUsers: selectedMapData.mapAuthorizedUsers,
            project: selectedMapData.project,
            assignedUsers: selectedMapData.assignedUsers,
            author: selectedMapData.author,
            authorUserId: selectedMapData.authorUserId,
          },
          currentMapDet: parsedMappingDiagrams[0],
          appliedTemplate: applyTemplate,
          templateBgColor: tempBgColor,
          isDefaultTemplateEnable: isDefaultTemplateEnable,
          selectedMapData: selectedMapData,
          diagramBpmnXML: parsedMappingDiagrams[0].diagramXML,
          authorId: selectedMapData?.authorUserId ? selectedMapData?.authorUserId : null,
        });
        if (fromMapLevelSelect === "YES") {
          await this.updateXmlByImportXML(parsedMappingDiagrams[0].diagramXML);
        }
        this.props.setEditorOpenFunc();
        this.closeSpinnerRedux()
      }
      await this.GetComments(diagramXmlId);
      await this.GetCommentsReaderIds(diagramXmlId);
      this.closeSpinnerRedux()
    } catch (error) {
      console.error("getLastSavedXmlAPICALL", error);
      this.closeSpinnerRedux();
      // this.props.BackToParent("Error");
      if (error?.response?.status === 406) {
        return error.response?.status;
      } else {
        ErrorMessage(error.message)
      }
    }
  };

  // getLastSavedXmlByUser = async () => {
  //   try {
  //     this.openSpinnerRedux();
  //     console.log(this.props);
  //     const response = await BPMNService.getLastSavedXmlAPICALL(this.props.selectedMapData.diagramXmlId, this.props.selectedMapData.authorUserId);
  //     const data = await { ...response.data };
  //     console.log("data ", data);
  //     this.setState({
  //       resSavedData: await response.data,
  //       diagramXmlId: response.data.diagramXmlId,
  //     })
  //     console.log(response, response.data);
  //     if (response.status === 204) {
  //       const tempData = {
  //         diagramXmlId: 384,
  //         userid: null,
  //         xmlData: "",
  //         languageName: null,
  //         languageCode: null

  //       }
  //       this.setState({
  //         userSavedData: tempData,
  //         selectedLanguage: { label: "English", value: "en" }
  //       });
  //       this.closeSpinnerRedux()
  //     }
  //     else if (response.status === 200 || response.status === 201) {
  //       let selLang = { label: this.props.selectedMapData.languageName, value: this.props.selectedMapData.languageCode }
  //       if (!(this.props.selectedMapData.languageCode || this.props.selectedMapData.languageName)) {
  //         selLang.value = "en";
  //         selLang.label = "English"
  //       }
  //       let parsedMappingDiagrams;
  //       if (data.xmlData === "" || data.xmlData === null) {
  //         parsedMappingDiagrams = [...this.state.mappingDiagrams]
  //         const dataTemp = await response.data;
  //         dataTemp.xmlData = JSON.stringify([...this.state.mappingDiagrams]);
  //         this.setState({
  //           resSavedData: dataTemp
  //         })
  //       } else {
  //         console.log("(data.xmlData) ", data.xmlData);
  //         parsedMappingDiagrams = JSON.parse(data.xmlData)
  //       }
  //       data.xmlData = parsedMappingDiagrams[0].diagramXML
  //       // parsedMappingDiagrams[0].name = data.diagramName
  //       parsedMappingDiagrams[0].meta.label = parsedMappingDiagrams[0].id + "-" + data.diagramName
  //       parsedMappingDiagrams[0].name = data.diagramName
  //       console.log(data);
  //       let tempBgColor;
  //       let isDefaultTemplateEnable;
  //       if (data.template === null || data.template === undefined || data.template === '') {
  //         isDefaultTemplateEnable = false
  //       } else {
  //         tempBgColor = JSON.parse(data.template).templateBgColor
  //         isDefaultTemplateEnable = JSON.parse(data.template).isDefaultTemplateEnable
  //       }
  //       console.log("#####", parsedMappingDiagrams);
  //       this.setState({
  //         userSavedData: data,
  //         mappingDiagrams: parsedMappingDiagrams,
  //         selectedLanguage: selLang,
  //         mapDiagramRecord: {
  //           diagramXmlId: data.diagramXmlId,
  //           diagramName: data.diagramName,
  //           docStorageType: data.docStorageType,
  //           configId: data.configId,
  //           mapPrivacyType: data.mapPrivacyType,
  //           mapAuthorizedUsers: data.mapAuthorizedUsers,
  //         },
  //         currentMapDet: parsedMappingDiagrams[0],
  //         templateBgColor: tempBgColor,
  //         isDefaultTemplateEnable: isDefaultTemplateEnable

  //       });
  //       this.closeSpinnerRedux()
  //     }
  //     this.closeSpinnerRedux()
  //   } catch (error) {
  //     console.log("getLastSavedXmlAPICALL", error);
  //     this.closeSpinnerRedux();
  //     this.props.BackToParent("Error");
  //     if (error?.response?.status === 406) {
  //       ErrorMessage("Map already opened by another user")
  //     } else {
  //       ErrorMessage(error.message)
  //     }
  //   }
  // };

  saveLatestXmlOnclick = async () => {
    const isBothXMLSame = await this.getIsUnSavedXMLExist();


    // if (getCommentLen !== copiedCommentsLen) {
    //   let Url = await BPMNService.deleteExistingComment(this.state.copiedComments, this.state.userSavedData.diagramXmlId)
    //   if (Url.status === 200 || Url.status === 201) {
    //     this.setState({
    //       copiedComments: Url.data
    //     })
    //   }
    // }
    // // const response = await BPMNService.updateAllComments(this.state.copiedComments);
    // // if (response) {
    // //   this.setState({
    // //     copiedComments: []
    // //   })
    // // }
    // // console.log("****  response.data ", response.data);

    if (isBothXMLSame) {
      ErrorMessage(BPMN_Editor_Toaster.No_Changes_Detected)
      return;
    }
    const tempCurrDiagMapps = [...this.state.mappingDiagrams]
    console.log(tempCurrDiagMapps);
    const selLang = this.state.selectedLanguage;
    const reqPayload = {
      xmlData: JSON.stringify(tempCurrDiagMapps),
      languageName: selLang.label,
      languageCode: selLang.value
    };
    try {
      this.openSpinnerRedux();
      const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
      const data = await { ...response.data };
      console.log("****  data ", data);
      console.log("****  response.data ", response.data);
      try {
        console.log("🚀 ~ this.state.auditInsideMap:", this.state.auditInsideMap);
        const reqAuditPL = [...this.state.auditInsideMap].map(item => {
          return {
            "field": item.field,
            "oldValue": item.oldValue,
            "newValue": item.newValue
          }
        })
        if (reqAuditPL.length > 0) {
          const res = await BPMNService.setAuditinsideMap(this.state.selectedMapData.id, reqAuditPL);
          console.log(res);
        }
        this.setState({
          auditInsideMap: []
        })
      } catch (error) {
        console.error(error);

      }
      this.setState({
        resSavedData: await response.data
      })
      if (response.status === 200 || response.status === 201) {
        console.log(data);
        let selLang = { label: data.languageName, value: data.languageCode }
        if (!(data.languageCode || data.languageName)) {
          selLang.value = "en";
          selLang.label = "English"
        }
        let parsedMappingDiagrams;
        if (data.xmlData === "" || data.xmlData === null) {
          parsedMappingDiagrams = [...this.state.mappingDiagrams]
        } else {
          parsedMappingDiagrams = JSON.parse(data.xmlData)
        }
        console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
        data.xmlData = parsedMappingDiagrams[0].diagramXML
        this.setState({
          // userSavedData: data,
          mappingDiagrams: parsedMappingDiagrams,
          selectedLanguage: selLang
        });
        this.closeSpinnerRedux()
        SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);

        // //setting the updated comments after the changes
        // if (this.state.copyGetComment.length > 0) {
        //   console.log("comments called after save changes");
        //   const response = await BPMNService.updateAllComments(this.state.copyGetComment);
        //   if (response) {
        //     this.setState({
        //       copyGetComment: []
        //     })
        //   }
        //   console.log("****  response.data ", response.data);
        // }

      }
    } catch (error) {
      console.log("saveLatestXmlAPICALL", error);
      this.closeSpinnerRedux()
      ErrorMessage(error?.response?.data);
    }
  };
  uploadDocSharePointAPICALL = async (tempFilesData) => {

    const formData = new FormData();
    tempFilesData.forEach(file => {
      formData.append("files", file)
    });
    console.log("filesformData ", formData.getAll("files"));
    return BPMNService.uploadActivityDocuments(formData, this.state.selectedMapData.id);
  };
  downloadDocSharePointAPICALL = async (type, file) => {
    try {
      if (type === 'PREVIEW') {
        const extension = file.fileName.split('.').pop().toLowerCase();
        console.log("preview", extension);
        const nonPreviewableFormats = ['zip', 'rar', 'tar', 'gz', 'xls', 'xlsx', 'doc', 'docx', 'ppt', 'pptx'];
        if (nonPreviewableFormats.includes(extension)) {
          ErrorMessage(BPMN_Common_Tosters.The_File_Type_Preview_Msg_Start + extension + BPMN_Common_Tosters.The_File_Type_Preview_Msg_End)
          return
        }
      }
      this.openSpinnerRedux()
      const response = await BPMNService.getActivityUploadedDocuments(file.fileName, file.documentId);
      console.log(response);
      if (type === "DOWNLOAD") {

        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', file.fileName);
        document.body.appendChild(link);
        link.click();

        link.parentNode.removeChild(link);
        window.URL.revokeObjectURL(url);

      } else if (type === "PREVIEW") {
        const mimeType = getMimeTypeByFileName(file.fileName);
        const blob = new Blob([response.data], { type: mimeType });
        const resURL = URL.createObjectURL(blob);

        if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
          window.open(resURL, '_blank');
        }
        // For Excel (.xlsx) files
        else if (mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
          window.open(resURL, '_blank');
        }
        // For other file types, just open the URL in a new tab
        else {
          const customUrl = `${resURL}#toolbar=0&navpanes=0&scrollbar=0&filename=${encodeURIComponent(file.fileName)}`;
          window.open(customUrl, '_blank');
        }

        this.closeSpinnerRedux();
      }
      this.closeSpinnerRedux()
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
      ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
    }

  };
  deleteDocSharePointAPICALL = async (type, activityId, file, event) => {
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    // const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');
    const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
    // const parent_Id = this.state.element_data_id;
    const parentActivity = elementRegistry.get(activityId)
    console.log(parentActivity)
    console.log(bpmnModeling);
    console.log(type);

    try {
      let deleteReqPayLoad = [];
      let tempEditElementObj;
      if (type === "MULTIPLE") {
        console.log("Multiple delete ", this.state.isActivityReplaceEnable, event, type, activityId, file)
        if (this.state.isActivityReplaceEnable) {
          console.log("inside is navi condi");
          //  this.setState({
          //   isActivityReplaceEnable: false
          // })
          return
        }
        deleteReqPayLoad = JSON.parse(event.element.businessObject.$attrs.allFileNamesWithId)
      } else {
        console.log("Single");
        console.log("single delete ", this.state.isActivityReplaceEnable, event, type, activityId, file)
        tempEditElementObj = this.state.editElementObj
        deleteReqPayLoad.push(
          {
            documentId: file.documentId,
            fileName: file.fileName
          })
      }
      let docs = tempEditElementObj.businessObject.get('documentation');
      console.log("docs ", docs)
      const allFileNamesWithId = docs.find(d => d.textFormat === 'json/file-document')
      console.log("allFileNamesWithId ", allFileNamesWithId)
      const activityFiles = isValidValue(allFileNamesWithId?.text) ? [] : JSON.parse(allFileNamesWithId.text);
      console.log("fileName ", activityFiles);
      this.openSpinnerRedux()
      const response = await BPMNService.deleteActivityUploadedDocuments(deleteReqPayLoad);
      console.log(response);
      // if (response.status === 200 || response.status === 201) {
      let isAuditDocRemains = []
      let isOldAuditDocs = []
      if (type !== "MULTIPLE") {
        // const tempbusObj = tempEditElementObj?.element?.businessObject;
        const tempSelDocs = this.state.selActivityDocFiles;
        const remainDocs = tempSelDocs.filter(item => item.documentId !== file.documentId)
        console.log("selectedfilenmae ", tempSelDocs);
        console.log("remainDocs ", remainDocs,);
        isOldAuditDocs = tempSelDocs
        isAuditDocRemains = remainDocs
        // tempbusObj.$attrs.allFileNamesWithId = JSON.stringify(remainDocs);
        allFileNamesWithId.text = JSON.stringify(remainDocs);
        if (remainDocs.length === 0) {
          allFileNamesWithId.text = null;
          const overlays = this.handleBpmnRef.current.bpmnModeler.get("overlays")
          console.log("overlays ", overlays)
          console.log("tempEditElementObj ", tempEditElementObj)
          const overlay = overlays.get({ element: tempEditElementObj }).find(ol => ol.type === "documents")
          console.log("overlays ", overlay)

          let bussObj = tempEditElementObj.businessObject;
          let documents = bussObj.get('documentation');
          console.log("documents ", documents)
          let overlayCmnt;
          if (documents.length > 0) {
            overlayCmnt = overlays.get({ element: tempEditElementObj }).find(olcmnt => olcmnt?.type === "comments")
          }
          console.log("overlayCmnt ", overlayCmnt)
          if (overlayCmnt) {
            overlayCmnt.position.right = 24;
            console.log("overlayCmnt 1111", overlayCmnt)
            overlays._updateOverlay(overlayCmnt)
          }
          overlays?.remove(overlay.id);
          // const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
          // const parentActivity = bpmnCanvas._elementRegistry.get(activityId)
          // const tempAddedChild_Ids = parentActivity.businessObject.$attrs.mapped_Child_Ids?.split(',').filter(item => item !== this.state.editElementObj.element.id)
          // const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
          // console.log(tempAddedChild_Ids);
          // bpmnModeling.updateProperties(parentActivity, {
          //   mapped_Child_Ids: tempAddedChild_Ids?.length === 0 ? "" : tempAddedChild_Ids.toString(),
          // });
          // bpmnModeling.removeElements([this.state.editElementObj.element])
          this.setState({
            isActivityFileDocEnable: false,
          })

        }
        this.setState({
          selActivityDocFiles: remainDocs
        });
      }
      this.closeSpinnerRedux();
      const isOldDocs = isOldAuditDocs.map(el => el.fileName).join(', ')
      const isNewDocs = isAuditDocRemains.map(el => el.fileName).join(', ')
      const pushAuditObject = {
        diagramLevel: this.state.currentMapDet.id,
        AutoNumCount: parentActivity?.businessObject?.$attrs.AutoNumCount,
        id: parentActivity.id,
        field: "Remove Document",
        type: "REMOVE_DOCUMENT",
        newValue: `${this.state.currentMapDet.id} (${parentActivity?.businessObject?.$attrs.AutoNumCount}) - ${!isNewDocs ? 'Document Removed' : isNewDocs}`,
        oldValue: `${this.state.currentMapDet.id} (${parentActivity?.businessObject?.$attrs.AutoNumCount}) - ${isOldDocs}`
      }
      this.audittrailpushingObj(pushAuditObject, "REMOVE_DOCUMENT");
    } catch (error) {
      this.closeSpinnerRedux();
      console.error(error);
      ErrorMessage(error?.response?.date)
    }
  };

  normalizeXML(xmlString) {
    try {
      const jsonObj = xml2js(xmlString, { compact: true, spaces: 0 });
      return js2xml(jsonObj, { compact: true, spaces: 0 });
      // console.log(xmlString);
      // const placeholder = '###AMP###';
      // const xmlWithPlaceholder = xmlString.replace(/&#38;/g, placeholder);
      // const jsonObj = xml2js(xmlWithPlaceholder, { compact: true, spaces: 0 });
      // let normalizedXml = js2xml(jsonObj, { compact: true, spaces: 0 });
      // normalizedXml = normalizedXml.replace(new RegExp(placeholder, 'g'), '&#38;');


      // const placeholder = '###AMP###';
      // const xmlWithPlaceholder = xmlString.replace(/&/g, placeholder);
      // const jsonObj = xml2js(xmlWithPlaceholder, { compact: true, spaces: 0 });
      // let normalizedXml = js2xml(jsonObj, { compact: true, spaces: 0 });
      // normalizedXml = normalizedXml.replace(new RegExp(placeholder, 'g'), '&amp;');

      // return normalizedXml;


    } catch (error) {
      console.error(error);
      return xmlString;
    }
  }

  compareArrays(arr1, arr2) {
    try {
      const normalizeObject = (obj) => {
        if (obj.diagramXML) {
          console.log("@@@@@@@@@@@@@@", obj.diagramXML);
          obj.diagramXML = this.normalizeXML(obj.diagramXML);
          console.log("@@@@@@@@@@@@@@", obj.diagramXML);
        }
        if (obj.children && obj.children.length > 0) {
          obj.children = obj.children.map(normalizeObject);
        }
        return obj;
      };

      const normalizedArr1 = arr1.map(normalizeObject);
      const normalizedArr2 = arr2.map(normalizeObject);
      console.log(normalizedArr1, normalizedArr2);
      return _.isEqual(normalizedArr1, normalizedArr2);
    } catch (error) {
      console.error(error);
    }
  }


  getIsUnSavedXMLExist = async () => {
    try {
      if (this.state.isMapLocked ||
        (localStorage.getItem("userRole") === "Admin" && ["Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
        (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
        (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status))
      ) {
        return true;
      }
      const currXML = await this.getCurrentDiagramXML();
      let tempMappDiags = [...this.state.mappingDiagrams];
      const tempResData = { ...this.state.resSavedData }
      const tempCurrMap = this.state.currentMapDet;
      console.log("Initial ", tempResData, tempMappDiags);
      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            // lastSavedXML = arr[i].diagramXML;
            console.log(arr[i].diagramXML);
            console.log(currXML);
            const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currXML)
            console.log("isBothXMLSame ", isBothXMLSame);
            if (!(isBothXMLSame)) {
              arr[i].diagramXML = currXML;
            }
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
      console.log("##### ", updatedArray);
      const tempCurrDiagMapps = [...updatedArray]
      this.setState({
        mappingDiagrams: updatedArray
      })

      let resString;
      let resArray = [];
      console.log(tempResData);
      if (tempResData.xmlData === "" || tempResData.xmlData === null || tempResData.xmlData === undefined) {
        resString = ""
        resArray = []
      } else {
        resString = JSON.stringify(JSON.parse(tempResData.xmlData))
        resArray = JSON.parse(tempResData.xmlData);
      }

      const currString = JSON.stringify(tempCurrDiagMapps);
      console.log(resString, currString);
      console.log("**** comp", currString.localeCompare(resString) === 0);
      console.log("****", currString.length, resString.length, currString === resString, currString.replace(/(?:\r\n|\r|\n)/g, '') === resString.replace(/(?:\r\n|\r|\n)/g, ''));

      console.log("++++", resArray, tempCurrDiagMapps);
      const areEqual = this.compareArrays(resArray, tempCurrDiagMapps);
      console.log("++++", areEqual ? 'Arrays are equal' : 'Arrays are not equal');
      return areEqual
    } catch (error) {
      console.error(error);
    }
  }
  getCurrentDiagramXML = async () => {
    const xmlResult = await this.handleBpmnRef.current.bpmnModeler.saveXML();
    const result = await xmlResult.xml;
    return result;
  };
  updateXmlByImportXML = async (xmlString) => {
    try {
      console.log(' xmlString ', xmlString);
      await this.handleBpmnRef.current.bpmnModeler.importXML(xmlString);
    } catch (error) {
      console.error(error);
      ErrorMessage(BPMN_Common_Tosters.Error_While_Updating_Diagram)
    }
  }
  compHandleTextOnChange = (e) => {
    const { name, value } = e.target;
    console.log(name, value);
    this.setState({
      [name]: value,
    });

  };
  compHandleTextOnChangeforInput = (e) => {
    const { name, value } = e.target;
    console.log(name, value);
    this.setState({
      [name]: value,
      selActivityTypeFlag: true
    })
  }


  handleElementDblClickByTool = async (e, type, selActivityName, tempBussObjAttr) => {
    console.log("HANDLE dblClick ", e, type, selActivityName, tempBussObjAttr);
    if (type === "RENAME") {
      console.log("isActivitytextEnable RENAMEEE");
      let docs = e.element.businessObject.get('documentation');
      console.log("docs ", docs)
      const almActivityType = docs.find(d => d.textFormat === 'text/process-activity')
      console.log("almActivityType ", almActivityType)

      this.setState({
        selActivityName: selActivityName,
        isActivitytextEnable: true,
        selActivityType: almActivityType ? 'process' : 'default',
        editElementObj: e,
        selActivityTypeFlag: false
      });
    } else if (type === "FILE") {
      let docs = e.businessObject.get('documentation');
      console.log("docs ", docs)
      const allFileNamesWithId = docs.find(d => d.textFormat === 'json/file-document')
      console.log("allFileNamesWithId ", allFileNamesWithId)
      const activityFiles = allFileNamesWithId?.text === undefined || allFileNamesWithId?.text === null || allFileNamesWithId?.text === "" ? [] : JSON.parse(allFileNamesWithId.text);
      console.log("fileName ", activityFiles);
      // console.log("nameOrActId ", tempBussObjAttr);
      this.setState({
        isActivityFileDocEnable: true,
        selActivityId: e.id,
        selActivityDocFiles: activityFiles,
        selActivityName: selActivityName,
        editElementObj: e,
      })
      // this.downloadDocSharePointAPICALL(nameOrActId, fileName)
    } else if (type === "ALM") {
      try {
        let docs = e.businessObject.get('documentation');
        const almDataAdded = docs.find(d => d.textFormat === 'json/file-ALMConnect')
        let almData = isValidValue(almDataAdded.text) ? JSON.parse(almDataAdded.text) : []
        console.log(" almData ", almData);
        if (!isArray(almData) || almData.length === 1) {
          console.log(" almData iff ", almData);
          this.openSpinnerRedux()
          const selALMData = isArray(almData) ? almData[0] : almData
          console.log("selALMData ", selALMData);
          const finalResultArray = await getALMConnectedTests(selALMData.almConnectId);
          this.closeSpinnerRedux()
          this.setState({
            editElementObj: e,
            almMappedTestcases: finalResultArray,
            selActivityName: selActivityName,
            AlmDataSource: selALMData,
            isALMTestCaseViewEnable: true,
            // isReqOrTestcaseEnable: true,
          })
        } else {
          this.setState({
            isReqOrTestcaseEnable: true,
            almData: almData,
            editElementObj: e,
            // isALMTestCaseViewEnable: false,
          })
        }

      } catch (error) {
        this.closeSpinnerRedux()
        console.error(error);
      }
    }
  };
  onALMReqOrTestSelectOnClick = async (almType) => {
    try {
      const almData = this.state.almData;
      const selALMData = almData.find(alm => almType === "TESTCASE" ? (alm.type === 'test-folder' || alm.type === "test") : alm.type === "requirement")
      console.log(" almType: ", almType, almData, selALMData);
      this.openSpinnerRedux()
      // const almData = this.state.almData;
      const finalResultArray = await getALMConnectedTests(selALMData.almConnectId);
      this.setState({
        almMappedTestcases: finalResultArray,
        isALMTestCaseViewEnable: true,
        AlmDataSource: selALMData,
        isReqOrTestcaseEnable: false,
      })
      this.closeSpinnerRedux()
    } catch (error) {
      this.closeSpinnerRedux()
      console.error(error);
    }
  }
  addResourceNameOnClick = async (selectedData) => {
    console.log("selectedData ", selectedData)
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');
    const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
    const parent_Id = this.state.element_data_id;

    const parentActivity = elementRegistry.get(parent_Id)
    console.log(bpmnModeling);
    console.log(parentActivity.businessObject.$attrs.mapped_Child_Ids);
    const targetResChildIds = parentActivity.businessObject.$attrs.mapped_Child_Ids.split(',')?.filter(id => id?.includes("Actor"));
    // let tempBussObj = event.element.businessObject;
    const remainChildIds = parentActivity.businessObject.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (!id?.includes("Actor")));
    const childResCount = elementRegistry.filter((item) => targetResChildIds?.includes(item.id))
    console.log("childResCount", childResCount, childResCount[0]?.incoming, childResCount[0]?.outgoing);
    let removedResFlList = [];
    let replacedResFlList = [];
    let oldResNames = [];
    let newResNames;
    if (childResCount.length !== 0) {
      oldResNames = childResCount.map(res => res.businessObject.$attrs.fullNametxt);
      console.log("oldResNames", oldResNames);

      await childResCount.forEach(async (item, index) => {
        console.log("item ", item)
        let pushObj = {
          resourceId: item.businessObject.$attrs?.resourceId,
          incoming: [],
          outgoing: [],
        }
        item.incoming?.forEach(income => {
          console.log("income ", income)
          return pushObj.incoming.push({
            source: income.source,
            type: income.type,
            waypoints: income.waypoints,
            name: income.businessObject.name
          })
        })
        item.outgoing?.forEach(outgo => {
          console.log("outgo ", outgo)
          return pushObj.outgoing.push({
            target: outgo.target,
            type: outgo.type,
            waypoints: outgo.waypoints,
            name: outgo.businessObject.name
          })
        })
        console.log("pushObj ", pushObj)
        const isResReplaced = selectedData.some(ress => ress.id === pushObj.resourceId)
        if (isResReplaced) {
          replacedResFlList.push(pushObj)
        } else {
          removedResFlList.push(pushObj)
        }
        if (childResCount.length === index + 1) {
          await bpmnModeling.removeElements(childResCount)
        }
      });
      // if (childResCount.some(res => res.businessObject.$attrs?.resourceId === item.id)) {

      // }
    }
    let resAudit = selectedData.map(item => item.displayName.trim()).join(', ');
    console.log(resAudit);
    console.log("🚀 ~ childResCount:", childResCount);
    console.log(selectedData);
    let newAppendResourceIds = "";
    if (selectedData.length !== 0) {
      try {
        selectedData.forEach((resource, index) => {
          console.log("resource ", resource);
          console.log("id ", parent_Id);
          console.log("parentActivity ", parentActivity);
          const currResName = resource.displayName;
          newResNames = newResNames ? newResNames + "," + currResName : currResName
          console.log("🚀 ~ currResName:", currResName);
          if (currResName === undefined || currResName === "") {
            ErrorMessage(BPMN_Editor_Toaster.Resource_Name_Cant_Be_Empty);
            return;
          }
          const newResourceBox = elementFactory.createShape({ type: 'bpmn:Task' });
          bpmnModeling.createShape(newResourceBox, { x: parentActivity.x, y: parentActivity.y + parentActivity.height + (25 * (index)), width: parentActivity.width, height: 25 },
            // bpmnCanvas.getRootElement()
            parentActivity.parent
          );
          console.log(newResourceBox);
          newResourceBox.businessObject.$attrs.parentActivityId = parentActivity.id;
          // tempbusObj.$attrs.fullNametxt = currResName;
          newResourceBox.businessObject.$attrs.fullNametxt = currResName;
          newResourceBox.businessObject.$attrs.resourceId = resource.id;
          newResourceBox.businessObject.$attrs.resourceName = resource.resourceName;
          newResourceBox.businessObject.$attrs.resourceType = resource.type;
          bpmnModeling.updateLabel(newResourceBox, currResName)//.length > 12 ? currResName.substring(0, 12) + "..." : currResName);
          bpmnModeling.updateProperties(newResourceBox, {
            id: "Actor_" + parent_Id + "_" + (index + 1),
          });
          bpmnModeling.setColor(newResourceBox, {
            fill: resource.type === "SYSTEM" ? '#fec76f' : '#bbdefb',
          });
          console.log("replacedResFlList ", replacedResFlList)
          const isResAlreadyAdded = replacedResFlList.find(res => res.resourceId === resource.id);
          console.log("isResAlreadyAdded ", isResAlreadyAdded)
          if (isResAlreadyAdded) {
            console.log("isResAlreadyAdded if", isResAlreadyAdded)
            const copiedIncomingFlows = [...isResAlreadyAdded.incoming];
            const copiedOutgoingFlows = [...isResAlreadyAdded.outgoing];
            console.log("copiedIncomingFlows ", copiedIncomingFlows);
            console.log("copiedOutgoingFlows ", copiedOutgoingFlows);//waypoints
            copiedIncomingFlows.forEach(flow => {
              const newFlow = bpmnModeling.connect(flow.source, newResourceBox, { type: flow.type, waypoints: flow.waypoints });
              if (flow.businessObject?.name) {
                newFlow.businessObject.name = flow.name;
                bpmnModeling.updateLabel(newFlow, flow.name);
              }
            });
            copiedOutgoingFlows.forEach(flow => {
              const newFlow = bpmnModeling.connect(newResourceBox, flow.target, { type: flow.type, waypoints: flow.waypoints });
              if (flow?.name) {
                newFlow.businessObject.name = flow.name;
                bpmnModeling.updateLabel(newFlow, flow.name);
              }
            });
          }
          if (selectedData.length === (index + 1)) {
            const copiedIncomingFlows = removedResFlList.flatMap(resObj => resObj.incoming)
            const copiedOutgoingFlows = removedResFlList.flatMap(resObj => resObj.outgoing)
            copiedIncomingFlows.forEach(flow => {
              const newFlow = bpmnModeling.connect(flow.source, newResourceBox, { type: flow.type });
              if (flow.businessObject?.name) {
                newFlow.businessObject.name = flow.name;
                bpmnModeling.updateLabel(newFlow, flow.name);
              }
            });
            copiedOutgoingFlows.forEach(flow => {
              const newFlow = bpmnModeling.connect(newResourceBox, flow.target, { type: flow.type });
              if (flow?.name) {
                newFlow.businessObject.name = flow.name;
                bpmnModeling.updateLabel(newFlow, flow.name);
              }
            });
          }
          newAppendResourceIds = newAppendResourceIds === "" ? newResourceBox.id : (newAppendResourceIds + "," + newResourceBox.id)
          console.log(newAppendResourceIds, newResourceBox.id);
          console.log(parentActivity);
        })
      } catch (error) {
        console.error(error);
      }
    } else {
      // if flowlines exist with res and all res are deleted the it will be connect to activity.
      const copiedIncomingFlows = removedResFlList.flatMap(resObj => resObj.incoming)
      const copiedOutgoingFlows = removedResFlList.flatMap(resObj => resObj.outgoing)
      copiedIncomingFlows.forEach(flow => {
        const newFlow = bpmnModeling.connect(flow.source, parentActivity, { type: flow.type });
        if (flow.businessObject?.name) {
          newFlow.businessObject.name = flow.name;
          bpmnModeling.updateLabel(newFlow, flow.name);
        }
      });
      copiedOutgoingFlows.forEach(flow => {
        const newFlow = bpmnModeling.connect(parentActivity, flow.target, { type: flow.type });
        if (flow?.name) {
          newFlow.businessObject.name = flow.name;
          bpmnModeling.updateLabel(newFlow, flow.name);
        }
      });
    }
    let extractedOldResNames = oldResNames.join(",")
    const formattedNewNames = newResNames?.replace(/,/g, ", ");
    const OldResName = extractedOldResNames?.replace(/,/g, ", ");
    if (!this.state.EditedResFlag.flag && this.state.EditedResFlag.type === '') {
      const pushAuditObject = {
        diagramLevel: this.state.currentMapDet.id,
        AutoNumCount: parentActivity.businessObject.$attrs.AutoNumCount,
        id: parentActivity.id,
        field: "Resource",
        type: "RESOURCE",
        newValue: `${this.state.currentMapDet.id} (${parentActivity.businessObject.$attrs.AutoNumCount}) - ${formattedNewNames === undefined ? 'Resource Removed' : formattedNewNames}`,
        oldValue: OldResName.length > 0 ? `${this.state.currentMapDet.id} (${parentActivity.businessObject.$attrs.AutoNumCount}) - ${OldResName}` : null
      }
      console.log(pushAuditObject.oldValue);
      this.audittrailpushingObj(pushAuditObject, "RESOURCE");
    }
    else if (this.state.EditedResFlag.flag && this.state.EditedResFlag.type === 'Edit') {
      console.log(this.state.EditedResFlag);
      const pushAuditObject = {
        diagramLevel: this.state.currentMapDet.id,
        AutoNumCount: parentActivity.businessObject.$attrs.AutoNumCount,
        id: parentActivity.id,
        field: "Edit Resource",
        type: "EDIT_RESOURCE",
        newValue: `${this.state.currentMapDet.id} (${parentActivity.businessObject.$attrs.AutoNumCount}) - ${this.state.EditedResFlag.ResDetails.displayName}`,
        oldValue: this.state.EditedResFlag.oldName
      }
      this.audittrailpushingObj(pushAuditObject, "EDIT_RESOURCE");
    }
    // else {
    //   console.log(this.state.EditedResFlag);
    //   const pushAuditObject = {
    //     diagramLevel: this.state.currentMapDet.id,
    //     AutoNumCount: parentActivity.businessObject.$attrs.AutoNumCount,
    //     id: parentActivity.id,
    //     field: "Delete Resource",
    //     type: "DELETE_RESOURCE",
    //     newValue: `Resource Deleted`,
    //     oldValue: `${this.state.currentMapDet.id} (${parentActivity.businessObject.$attrs.AutoNumCount}) - ${this.state.EditedResFlag.ResDetails.displayName}`
    //   }
    //   console.log("DELETE_RESOURCE", pushAuditObject)
    //   this.audittrailpushingObj(pushAuditObject, "DELETE_RESOURCE");
    // }

    const tempAddedChild_Ids = newAppendResourceIds === "" ? remainChildIds?.toString() : (remainChildIds?.toString() + "," + newAppendResourceIds)
    console.log(newAppendResourceIds, tempAddedChild_Ids);
    bpmnModeling.updateProperties(parentActivity, {
      mapped_Child_Ids: tempAddedChild_Ids,
    });
    this.setState(prevState => ({
      EditedResFlag: {
        oldName: '',
        ResDetails: {},
        flag: false,
        type: ''
      }
    }));
    this.closeDialogPopupBox();
  };

  deleteResourceForActivity = async (deleteData) => {
    console.log("deleteData ", deleteData)
    const deleteResName = deleteData.displayName;
    const elementid = this.state.element_data_id;
    console.log("elementid", elementid);
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const parentActivity = bpmnCanvas._elementRegistry.get(elementid)
    console.log(parentActivity);
    const resourceBoxIds = parentActivity.businessObject.$attrs.mapped_Child_Ids?.split(",")?.filter(id => id?.includes("Actor"))
    console.log("resourceBoxIds ", resourceBoxIds)
    const remainChildIds = parentActivity.businessObject.$attrs.mapped_Child_Ids?.split(',')?.filter(id => !(id?.includes("Actor")));
    console.log("remainChildIds ", remainChildIds)
    let actorRemove = [];
    let actorRemoveNill = [];
    let newAppendResourceIds = "";
    let isMovedElementStart = false;
    resourceBoxIds.forEach((resId) => {
      const resShapeImpl = bpmnCanvas._elementRegistry.get(resId)
      console.log(resShapeImpl);
      if (resShapeImpl.businessObject?.name === deleteResName || resShapeImpl.businessObject.$attrs?.fullNametxt === deleteResName || resShapeImpl.businessObject.$attrs?.resourceId === deleteData.resourceId) {
        actorRemove.push(resShapeImpl)
        isMovedElementStart = true
      } else {
        if (isMovedElementStart) {
          actorRemoveNill.push(resShapeImpl)
        }
        newAppendResourceIds = newAppendResourceIds === "" ? resShapeImpl.id : newAppendResourceIds + "," + resShapeImpl.id
      }
    })
    console.log(actorRemove);
    console.log(actorRemoveNill);
    if (actorRemove.length > 0) {
      console.log("resource name is available in activity", deleteResName, actorRemove);
      this.setMappingDiagramsArray("isDiagNavigationClicked", false)
      bpmnModeling.removeElements(actorRemove)
      const tempAddedChild_Ids = newAppendResourceIds === "" ? remainChildIds?.toString() : (remainChildIds?.toString() + "," + newAppendResourceIds)
      console.log(remainChildIds, newAppendResourceIds, tempAddedChild_Ids);
      bpmnModeling.updateProperties(parentActivity, {
        mapped_Child_Ids: tempAddedChild_Ids,
      });
      if (actorRemoveNill.length > 0) {
        bpmnModeling.moveElements(actorRemoveNill, {
          x: 0,
          y: -25
        });
      }
    }
    else {
      console.log("no");
    }
  }


  addFlowLineActivity = async (updatedMappingDiagrams, diagramXml, targetId) => {
    console.log(targetId);
    console.log("updatedMappingDiagrams", updatedMappingDiagrams);
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');

    const elementid = document.getElementById("bio-properties-panel-id")?.value;
    console.log(elementid);
    const findElementById = (data, id) => { //this.state.currentMapDet.id
      for (let i = 0; i < data.length; i++) {
        const element = data[i];
        if (element.id === id) {
          return element;
        }
        if (element.children && element.children.length > 0) {
          const foundInChildren = findElementById(element.children, id);
          if (foundInChildren) {
            return foundInChildren;
          }
        }
      }
      return null;
    };
    const currentId = this.state.currentMapDet?.id;

    const foundElement = findElementById(updatedMappingDiagrams, currentId);
    console.log("foundElement", foundElement);
    let tempMappDiags = [...this.state.mappingDiagrams];
    function updateCurrDiagramXml(arr, parentId) {
      console.log(parentId);
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === parentId) {
          // lastSavedXML = arr[i].diagramXML;
          arr[i].diagramXML = diagramXml;
          return arr;
        } else {
          if (arr[i].children.length === 0) {
            continue;
          }
          updateCurrDiagramXml(arr[i].children, parentId);
        }
      }
      return arr;
    }
    const updatedArray = updateCurrDiagramXml(tempMappDiags, targetId)
    console.log("updatedArray", updatedArray);
    foundElement.flowlineMap.forEach(async (el) => {
      const parentActivityId = bpmnCanvas._elementRegistry.get(el.parentActivityId)
      // const targetActivityId = bpmnCanvas._elementRegistry.get(el.targetActivityId)
      // console.log(parentActivityId, targetActivityId);
      // console.log(bpmnModeling);
      if (parentActivityId && el.targetMapId === targetId) {
        const tempBussObjParent_Ids = parentActivityId.businessObject.$attrs?.mapped_Child_Ids;
        console.log(tempBussObjParent_Ids);
        const targetResMapIds = tempBussObjParent_Ids?.split(',')?.filter(item => item.includes("FLE_"))
        console.log(targetResMapIds);
        if (targetResMapIds.length === 0) {
          const newEndEvent = elementFactory.createShape({ type: 'bpmn:EndEvent', width: 20, height: 5 });
          bpmnModeling.createShape(newEndEvent, { x: parentActivityId.width + parentActivityId.x + 30, y: parentActivityId.y + (parentActivityId.height * (.10)) },
            parentActivityId.parent
          );

          bpmnModeling.connect(parentActivityId, newEndEvent)
          const waypoints = [
            { x: parentActivityId.width + parentActivityId.x, y: parentActivityId.y + (parentActivityId.height * (.10)) },
            { x: newEndEvent.x, y: parentActivityId.y + (parentActivityId.height * (.10)) },
          ]
          console.log(waypoints);
          bpmnModeling.updateProperties(newEndEvent, {
            id: "FLE_" + newEndEvent.id,
          });

          await bpmnModeling.updateWaypoints(newEndEvent.incoming[0], waypoints);
          bpmnModeling.layoutConnection(newEndEvent.incoming[0], {
            connectionStart: waypoints[0],
            connectionEnd: waypoints[waypoints.length - 1]
          });
          newEndEvent.businessObject.$attrs.parentActivityId = parentActivityId.id;
          bpmnModeling.setColor(newEndEvent, {
            stroke: '#dcdde1',
            fill: '#009432',
          }
          );
          const tempBussObjChild_Ids = parentActivityId.businessObject.$attrs?.mapped_Child_Ids;
          const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? newEndEvent.id : (tempBussObjChild_Ids + "," + newEndEvent.id);
          parentActivityId.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
          console.log(tempAddedChild_Ids);
        }
      }
      else {
        return null;
      }

      this.closeDialogPopupBox();
    })

  }

  removeFlowLineActivity = async (missingData) => {
    console.log("me triggerd");
    console.log("MISSINGDATA", missingData);
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const removeActivity = bpmnCanvas._elementRegistry.get(missingData[0])
    console.log(removeActivity);
    const filtermapped = removeActivity.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => el.includes('FLE_'))
    console.log(filtermapped);
    const removeEndshapeEvent = bpmnCanvas._elementRegistry.get(filtermapped[0])
    const filtermappedWithoutFLS = removeActivity.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLE_'))
    removeActivity.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLS.join(',');
    console.log(removeActivity);
    await bpmnModeling.removeElements([removeEndshapeEvent])
    this.closeDialogPopupBox()
  }



  popupFlowlineActAvailable = (e) => {
    console.log("im clicked");
    this.setState({
      showFlowlinoepopup: true,
      editElementObj: e
    })
  }
  targetFlowline = (e) => {
    this.setState({
      showFlowlinoepopupTarget: true,
      editElementObj: e,
    })
  }

  editActNameTxtOnClick = (e) => {
   
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const tempbusObj = this.state.editElementObj.element.businessObject;
    const tempName = this.state.selActivityName;
    const tempCurrMap = { ...this.state.currentMapDet };
    const tempMappDiags = [...this.state.mappingDiagrams];
    const tempEditElementObj = this.state.editElementObj
      console.log("tempEditElementObj ", tempEditElementObj)
      let docss = tempEditElementObj.element.businessObject.get('documentation');
      console.log("docs ", docss)
      const almType = docss.find(d => d.textFormat === 'text/process-activity')
      const isALMAdded = docss.find(d => d.textFormat === 'json/file-ALMConnect')
      if(almType && this.state.selActivityTypeFlag)
      {
        if(isALMAdded)
        {
          ErrorMessage("remove the ALM and change the activity type")
          return
        }
      }
      console.log("almActivityType ", isALMAdded,almType)
      console.log(tempName, " tempbusObj ", tempbusObj, this.state.currentMapDet);
    const oldValue = tempbusObj.$attrs.fullNametxt;
    tempbusObj.$attrs.fullNametxt = tempName;
    this.handleBpmnRef.current.bpmnModeler.get("modeling")
      .updateProperties(this.state.editElementObj.element, {
        name: tempName,//.length > 25 ? tempName.substring(0, 25) + "..." : tempName,
      });
    if (this.state.editElementObj.element.type === "bpmn:SubProcess") {
      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            console.log("0000000 ", arr[i]);
            arr[i].meta.label = arr[i].id + "-" + tempName;
            arr[i].name = tempName;
            return arr;
          } else if (arr[i].children.length === 0) {
            continue;
          }
          else {
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      const labelObjId = tempCurrMap.id + "." + tempbusObj.$attrs.AutoNumCount
      const updatedArr = updateCurrDiagramXml(tempMappDiags, labelObjId);
      console.log("##### ", updatedArr);
      this.setState({
        mappingDiagrams: updatedArr
      })
    }
    const currId = this.state.currentMapDet.id;
    let structureArray = [];
    const storingData = { parentActivityId: this.state.editElementObj.element.id, FullnameText: this.state.editElementObj.element?.businessObject?.$attrs?.fullNametxt }
    console.log(storingData);
    structureArray.push(storingData)
    function updateFullNameText(mappingDiagram, structureArray) {
      async function updateFlowline(flowline) {
        // console.log(flowline);
        const matchTarget = structureArray.find(item => flowline.parentActivityId === item.parentActivityId && flowline.originMapId === currId);
        const matchOrigin = structureArray.find(item => flowline.targetActivityId === item.parentActivityId && flowline.targetMapId === currId);
        // console.log(matchTarget, matchOrigin);

        if (matchTarget) {
          const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.parentActivityId);
          console.log(findTargetAutoNumId, findTargetAutoNumId.businessObject.$attrs.fullNametxt);
          // flowline.SourceAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
          flowline.SourceFullnameText = findTargetAutoNumId.businessObject.$attrs.fullNametxt
        }
        if (matchOrigin) {
          const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.targetActivityId);
          console.log(findTargetAutoNumId);
          // flowline.TargetAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
          flowline.TargetFullnameText = findTargetAutoNumId.businessObject.$attrs.fullNametxt
        }

        return flowline;
      }
      function updateFlowlineMap(node) {
        if (node.flowlineMap && node.flowlineMap.length > 0) {
          node.flowlineMap.forEach(async flowline => {
            await updateFlowline(flowline);
          });
        }

        if (node.children && node.children.length > 0) {
          node.children.forEach(child => {
            updateFlowlineMap(child);

            if (child.flowlineMap && child.flowlineMap.length > 0) {
              child.flowlineMap.forEach(async flowline => {
                await updateFlowline(flowline);
              });
            }
          });
        }
      }

      mappingDiagram.forEach(rootNode => {
        updateFlowlineMap(rootNode);
      });

      return mappingDiagram;
    }
    const updatedDiagramauto = updateFullNameText(this.state.mappingDiagrams, structureArray);
    console.log(updatedDiagramauto);

    const selElement = this.state.editElementObj.element;
    console.log(selElement);
    let bo = selElement.businessObject;
    let docs = bo.get('documentation');
    console.log("docs ", docs)
    let attachment;
    const isAlreadyProcessActivity = docs.find(d => d.textFormat === 'text/process-activity' && (attachment = d))
    console.log("isAlreadyProcessActivity ", isAlreadyProcessActivity)


    if ((this.state.selActivityType === 'process' && (!isAlreadyProcessActivity))) {

      if (!attachment) {
        attachment = bo.$model.create('bpmn:Documentation', {
          textFormat: 'text/process-activity',
        });
        docs.push(attachment);
      }
      attachment.text = "process"
      console.log("attachment ", attachment)
      console.log("selElement ", selElement);
      this.closeSpinnerRedux();
      this.handleBpmnRef.current.bpmnModeler?.get('process-activity')?.renderProcessConnectyElement(selElement)

    } else if (this.state.selActivityType === "default" && isAlreadyProcessActivity) {
      const overlays = this.handleBpmnRef.current.bpmnModeler.get("overlays")
      console.log("overlays ", overlays)
      const tempEditElementObj = this.state.editElementObj.element
      let bussObj = tempEditElementObj.businessObject;
      let documents = bussObj.get('documentation');
      let otherOverLayItems = documents?.filter(overlayItem => overlayItem.textFormat !== "text/process-activity")
      console.log(" otherOverLayItems ", otherOverLayItems);
      bussObj.set('documentation', otherOverLayItems)
      const overlayTotal = overlays.get({ element: tempEditElementObj });
      console.log(' overlayTotal ', overlayTotal);
      const overlay = overlayTotal.find(ol => ol.type === "process-activity")
      console.log("overlays ", overlay)
      overlays?.remove(overlay.id);
      this.closeDialogPopupBox()
      const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
      const parentElement = elementRegistry.get(tempEditElementObj.id);
      this.handleBpmnRef.current.bpmnModeler?.get('process-activity')?.renderProcessConnectyElement(parentElement)
    }


    this.closeDialogPopupBox();
    structureArray = [];
    let arrValues = `${this.state.currentMapDet.id} (${this.state.editElementObj.element.businessObject.$attrs.AutoNumCount}) -`
    if (this.state.selActivityTypeFlag) {
      const pushAuditObject = {
        diagramLevel: currId,
        id: this.state.editElementObj.element.id,
        AutoNumCount: this.state.editElementObj.element.businessObject.$attrs.AutoNumCount,
        field: "Activity Type",
        newValue: `${this.state.currentMapDet.id} (${this.state.editElementObj.element.businessObject.$attrs.AutoNumCount}) - ${this.state.selActivityType}`,
        oldValue: ``,
        type: "ACTIVITY TYPE"
      }
      this.audittrailpushingObj(pushAuditObject, "ACTIVITY TYPE");
    }
    else {
      const pushAuditObject = {
        diagramLevel: currId,
        id: this.state.editElementObj.element.id,
        AutoNumCount: this.state.editElementObj.element.businessObject.$attrs.AutoNumCount,
        field: "Activity Text",
        newValue: `${tempName.length > 0 ? `${arrValues} ${tempName}` : `${arrValues} Text Removed`}`, // text removed
        oldValue: `${oldValue.length > 0 ? `${arrValues} ${oldValue}` : ' '}`,
        type: "RENAME"
      }
      this.audittrailpushingObj(pushAuditObject, "RENAME");
    }
    this.setState({
      selActivityTypeFlag: false
    })

  };

  openBpmnFileUpload = () => {
    // this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    this.setState({
      isdownload: false,
      IsUploadBpmn: true,
      isDiagNavigationClicked: false
    });
  };

  uploadBpmnFileOnChange = async (e) => {
    console.log(e.type);
    e.preventDefault();
    if (e.type === "drop") {
      const isDrop = e.type + "".toLowerCase() === "drop";
      // const files = isDrop ? e.dataTransfer.files : e.target.files;
      const file = isDrop ? e.dataTransfer.files[0] : e.target.files[0];
      // const fileName = isDrop ? e.dataTransfer.files[0].name : e.target.files[0].name;
      console.log(file);
      const allowedExtensions = /\.(txt)$/i;
      if (!allowedExtensions.test(file?.name)) {
        ErrorMessage(BPMN_Editor_Toaster.File_Type_Mismatch);
        return;
      }
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;
        console.log(JSON.parse(text));
        // console.log("parsed", JSON.parse(text));
        const woExtFileName = file?.name.substring(0, file?.name.lastIndexOf('.'));
        const onlyMapName = woExtFileName.split("-");
        const result = onlyMapName.slice(1, -1).join("-");
        console.log(result);
        console.log("onlyMapName", result);
        this.setState({
          selectedFileXml: JSON.parse(text),
          selectedXmlFileName: file?.name,
        });
      };
      reader.readAsText(file);
    } else {
      console.log("else");

      const file = e.target.files[0];
      const isValid = await validateFileOnChange(e);
      if (!isValid) {
        return;
      }
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;
        console.log(JSON.parse(text),);
        this.setState({
          selectedFileXml: JSON.parse(text),
          selectedXmlFileName: file?.name,
        });
      };
      reader.readAsText(file);
    }
  };
  updateTreeIdsByBaseId = (oldArray, currentId, baseId) => {
    console.log(oldArray)
    const normalizeObject = (obj) => {
      let LoopId = obj.id
      const parentId = LoopId.split(".").slice(0, LoopId.split(".").length - 1).join(".")
      const resId = currentId + LoopId.substring(baseId.length)
      console.log(resId, LoopId)
      obj.id = resId
      obj.key = resId + (obj?.name.startsWith("-") ? obj.name : '-' + obj.name)
      obj.meta.label = resId + (obj?.name.startsWith("-") ? obj.name : '-' + obj.name)
      obj.parentId = parentId

      if (obj.children && obj.children.length > 0) {
        obj.children = obj.children.map(normalizeObject);
      }
      return obj;
    };

    const normalizedArr1 = oldArray.map(normalizeObject);
    return normalizedArr1;
  }
  uploadBpmnFile_OnClick = async () => {
    try {
      const tempSelFile = this.state.selectedFileXml;
      let tempMappDiags = cloneDeep([...this.state.mappingDiagrams])
      const currentId = this.state.currentMapDet.id
      const baseId = tempSelFile.id

      console.log("tempSelFile", tempSelFile);

      const UpdateUploadedXml = await this.updateTreeIdsByBaseId([tempSelFile], currentId, baseId)
      console.log(UpdateUploadedXml)
      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            const name = arr[i].meta.label
            const diagramName = arr[i].name
            arr[i] = UpdateUploadedXml[0]
            arr[i].meta.label = name
            arr[i].name = diagramName
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      tempMappDiags = updateCurrDiagramXml([...tempMappDiags], this.state.currentMapDet.id)
      console.log("##### ", tempMappDiags, isValidValue(tempSelFile.selectedLanguage), this.state.selectedLanguage.label);
      console.log("tempSelFile.selectedLangua", tempSelFile.selectedLanguage?.label === this.state.selectedLanguage.label);

      if ((isValidValue(tempSelFile.selectedLanguage) ? (tempSelFile.selectedLanguage?.label === this.state.selectedLanguage.label) : this.state.selectedLanguage.label === "English")) {
        console.log("innn ")
        this.setState({
          selectedLanguage: tempSelFile.selectedLanguage ? tempSelFile.selectedLanguage : { label: "English", value: "en" },
          mappingDiagrams: tempMappDiags
        })
        await this.updateXmlByImportXML(this.state.selectedFileXml.diagramXML);
      } else {
        ErrorMessage("Language Mismatch !")
      }
      console.log("tempSelFile:", tempSelFile)
      this.closeDialogPopupBox();
    } catch (error) {
      console.error("Error ", error);
    }
  };
  downloadBpmnSVG_OnClick = async () => {
    try {
      const svgResult = await this.handleBpmnRef.current.bpmnModeler.saveSVG();
      const result = await svgResult.svg;

      const svgBlob = new Blob([result], {
        type: "image/svg+xml;charset=utf-8",
      });
      const svgUrl = URL.createObjectURL(svgBlob);
      const downloadLink = document.createElement("a");
      downloadLink.href = svgUrl;
      downloadLink.download = "your_svg_filename.svg";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      URL.revokeObjectURL(svgUrl);
    } catch (error) {
      console.error(" Error ", error);
    }
  };
  OnprintClick = async () => {
    try {
      const svgResult = await this.handleBpmnRef.current.bpmnModeler.saveSVG();
      const result = await svgResult.svg;

      // Create a hidden iframe
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);

      // Append the SVG content to the iframe document body
      const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

      // Set the page size to be the size of the SVG content
      const svgWrapper = document.createElement('div');
      svgWrapper.style.display = 'flex';
      svgWrapper.style.justifyContent = 'center';
      svgWrapper.style.alignItems = 'center';
      svgWrapper.style.height = '100vh'; // Ensure SVG fills the entire page
      svgWrapper.innerHTML = result;
      iframeDocument.body.appendChild(svgWrapper);

      // Add CSS for page styling
      const style = document.createElement('style');
      style.textContent = `
  @page {
      size: auto; /* Set page size to auto */
      margin: 0; /* Remove default margin */
    }
  body {
      margin: 0; /* Remove body margin */
    }
    `;
      iframeDocument.head.appendChild(style);

      // Print the SVG content
      iframe.contentWindow.print();

      // Remove the iframe after printing
      document.body.removeChild(iframe);

    }
    catch (error) {
      console.error(" Error ", error);
    }
  };
  //working direct
  // excludeDocumentIds = async (resultDiagrams) => {
  //   console.log(resultDiagrams);
  //   const getCurrDiagramXmlById = async (arr) => {
  //     console.log(arr)
  //     for (let i = 0; i < arr.length; i++) {
  //       console.log(arr[i])
  //       const importXMLResponse = arr[i].diagramXML;

  //       const tempDivEle = document.createElement("div");
  //       const tempBpmnModeling = new BpmnModeler({
  //         tempDivEle,
  //       })
  //       console.log(tempBpmnModeling);
  //       console.log(importXMLResponse);
  //       await tempBpmnModeling.importXML(importXMLResponse)
  //       const bpmnCanvas = tempBpmnModeling.get('canvas');
  //       const bpmnModeling = tempBpmnModeling.get('modeling');
  //       console.log(bpmnCanvas, bpmnModeling);
  //       const findDocumentActivity = await bpmnCanvas._elementRegistry.filter(el => el.type === "bpmn:Task" || extraActivityElements.includes(el.type));
  //       console.log("findDocumentActivity", findDocumentActivity)
  //       findDocumentActivity.forEach(async element => {
  //         const DocumentId = element.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('Document_'))
  //         console.log(DocumentId);
  //         if (DocumentId !== undefined) {
  //           const filtermappedWithoutDoc = element.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('Document_'))
  //           element.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutDoc.join(',');
  //           const removeDocEventonShapeImpl = await bpmnCanvas._elementRegistry.get(DocumentId);
  //           console.log(removeDocEventonShapeImpl);
  //           await bpmnModeling.removeElements([removeDocEventonShapeImpl])
  //           const latestDiagram = (await tempBpmnModeling.saveXML()).xml
  //           console.log(latestDiagram);
  //           arr[i].diagramXML = latestDiagram
  //         }
  //       });
  //       if (arr[i].children.length === 0) {
  //         continue;
  //       }
  //       await getCurrDiagramXmlById(arr[i].children);
  //     }
  //     return arr;
  //   }
  //   const documentRemove = await getCurrDiagramXmlById(resultDiagrams)
  //   console.log(documentRemove);
  //   return documentRemove;
  // }
  excludeDocumentIds = async (resultDiagrams) => {
    console.log(resultDiagrams);
    const getCurrDiagramXmlById = async (arr) => {
      console.log(arr)
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i])
        const importXMLResponse = arr[i].diagramXML;
        if (importXMLResponse !== '') {
          const parser = new DOMParser();
          console.log(importXMLResponse);

          // const allDefShapes = xml2js(importXMLResponse, { compact: true, spaces: 4 });
          // console.log("~ allDefShapes:", allDefShapes);
          // const currDiagramShapes = allDefShapes['bpmn:definitions']['bpmn:process'];
          // console.log(currDiagramShapes);
          // let documentIdContainer = [];
          // const entriesArray = currDiagramShapes["bpmn:dataObjectReference"];
          // if (entriesArray !== undefined && entriesArray !== null) {
          //   documentIdContainer = isArray(entriesArray) ? entriesArray : [entriesArray]
          // }
          // console.log(documentIdContainer);
          const xmlDoc = parser.parseFromString(importXMLResponse, 'text/xml');
          const allDocNodes = xmlDoc.querySelectorAll('[textFormat="json/file-document"], [textFormat="json/file-ALMConnect"]');
          allDocNodes.forEach(node => {
            node.remove()
          })
          console.log("allDocNodes ", allDocNodes)
          // documentIdContainer.forEach(async (doc) => {
          //   if (doc._attributes.id.includes('Document')) {
          //     const parentActivityId = doc._attributes.parentActivityId
          //     const docId = doc._attributes.id
          //     const element = xmlDoc.querySelector(`[id="${parentActivityId}"]`)
          //     const getMappedChildIds = element.getAttribute('mapped_Child_Ids').split(',').filter(el => !el.includes('Document_')).join(',')
          //     element.setAttribute('mapped_Child_Ids', getMappedChildIds)
          //     xmlDoc.querySelector(`[id="${docId}"]`).remove();
          //     xmlDoc.querySelector(`[bpmnElement="${docId}"]`).remove();
          //     xmlDoc.querySelector(`[id="${doc._attributes.dataObjectRef}"]`).remove();
          //   }
          // })
          console.log(xmlDoc);
          const updatedBpmnXmlString = new XMLSerializer().serializeToString(xmlDoc);
          console.log("updatedBpmnXmlString ", updatedBpmnXmlString);
          arr[i].diagramXML = updatedBpmnXmlString
        }

        if (arr[i].children?.length === 0) {
          continue;
        }
        await getCurrDiagramXmlById(arr[i].children);
      }
      return arr;
    }
    const documentRemove = await getCurrDiagramXmlById(resultDiagrams)
    console.log(documentRemove);
    return documentRemove;
  }


  downloadBPMN_OnClick = async (callFrom) => {
    try {
      let xmlResult = cloneDeep(this.state.mappingDiagrams);
      const currentXML = await this.getCurrentDiagramXML();
      let exportResult;
      if (this.state.diagramLevel === "CurrentProcessMap") {
        exportResult = xmlResult[0]
      }
      if (this.state.diagramLevel === "CurrentAndLower" || this.state.diagramLevel === "CurrentLevel") {
        const updateCurrDiagramXml = (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              // console.log(arr[i].diagramXML, currentXML);
              const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
              console.log("isBothXMLSame ", isBothXMLSame);
              if (!(isBothXMLSame)) {
                arr[i].diagramXML = currentXML;
              }
              if (this.state.diagramLevel === "CurrentLevel") {
                arr[i].children.map((child) => {
                  child.children = []
                  return child.diagramXML = "";
                  // return child
                })
              }
              exportResult = arr[i]
              return arr;
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              updateCurrDiagramXml(arr[i].children, parentId);
            }
          }
          return arr;
        }
        const updatedArray = updateCurrDiagramXml(xmlResult, this.state.currentMapDet.id)
        console.log("##### ", updatedArray);
      }
      console.log(exportResult)
      console.log(this.state.mappingDiagrams);
      if (callFrom === "FromIC") {
        return exportResult;
      }
      console.log("cureent diagram");

      const excludeDocumentxml = await this.excludeDocumentIds([exportResult])
      excludeDocumentxml[0].selectedLanguage = this.state.selectedLanguage;
      console.log(excludeDocumentxml);

      if (callFrom === "FromIC") {
        return exportResult;
      }
      const blob = new Blob([JSON.stringify(excludeDocumentxml[0], null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      // link.setAttribute("download", exportResult.meta.label + "-(" + this.state.diagramLevel + ") .txt");
      //reconstructed the name
      link.setAttribute("download", exportResult.name === '' ? exportResult.key + ".txt" : exportResult.name + ".txt");
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error("Error ,", error);
    }
    this.setState({
      diagramLevel: "CurrentProcessMap",
      isdownload: false
    })
  };



  refreshBpmn_OnClick = async () => {
    try {
      const xml = await getXmlDiagram("default");
      console.log("refreshed xml", xml);
      await this.updateXmlByImportXML(xml);
    } catch (error) {
      console.error("refresh ", error);
    }
    this.setState({ selectedLanguage: { label: "English", value: "en" }, });
  };
  zoomInOutBpmn_OnClick = (key) => {
    console.log(key, " key  ", this.handleBpmnRef.current.bpmnModeler.get("zoomScroll"));
    switch (key) {
      case "in":
        this.handleBpmnRef.current.bpmnModeler.get("zoomScroll").stepZoom(1);
        break;
      case "out":
        this.handleBpmnRef.current.bpmnModeler.get("zoomScroll").stepZoom(-1);
        break;
      case "reset":
        console.log("Zoom Reset ");
        break;
      default:
        break;
    }
  };
  changeTemplate_Onclick = async (temptype) => {
    console.log(" changeTemplate_Onclick");
    const tempxml = await getXmlDiagram(temptype);
    await this.updateXmlByImportXML(tempxml);
  };

  handleSelectLanguageOnChange = async (selLang) => {
    this.revertRearrangeFlag()
    try {
      this.openSpinnerRedux();
      const userSavedData = this.state.resSavedData;
      const prevLanguage = this.state.selectedLanguage;
      console.log(selLang);
      if (prevLanguage.value === selLang.value) {
        console.log("same language selected");
        this.closeSpinnerRedux();
        return
      }
      console.log("prev ", prevLanguage, "Sel ", selLang, "user ", this.state.userSavedData, " ----", userSavedData.languageCode);
      if (userSavedData.languageCode === selLang.value) {
        console.log("if origin lang selected");
        // const parsedMappingDiagrams = JSON.parse(this.state.resSavedData.xmlData)
        const parsedMappingDiagrams = JSON.parse(this.state.userSavedData.xmlData === null ? this.state.resSavedData.xmlData : this.state.userSavedData.xmlData)
        console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
        this.setState({
          mappingDiagrams: parsedMappingDiagrams,
        });
        let importXMLResponse
        const getCurrDiagramXmlById = async (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {

            if (arr[i].id === parentId) {
              importXMLResponse = arr[i].diagramXML;
              return arr;
            }
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children, parentId);
          }
          return arr;
        }
        await getCurrDiagramXmlById(parsedMappingDiagrams, this.state.currentMapDet.id);
        this.setMappingDiagramsArray("isDiagNavigationClicked", false)
        this.setMappingDiagramsArray("isDiagNavigationClicked", false)
        this.updateXmlByImportXML(importXMLResponse);
        this.closeSpinnerRedux();
      } else {
        console.log("else");
        let tempMappDiags = [...this.state.mappingDiagrams];
        const currentXML = await this.getCurrentDiagramXML();

        try {
          function updateCurrDiagramXml(arr, parentId) {
            for (let i = 0; i < arr.length; i++) {
              if (arr[i].id === parentId) {
                console.log(arr[i].diagramXML, currentXML);
                const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
                console.log("isBothXMLSame ", isBothXMLSame);
                if (!(isBothXMLSame)) {
                  arr[i].diagramXML = currentXML;
                }
                return arr;
              } else {
                if (arr[i].children.length === 0) {
                  continue;
                }
                updateCurrDiagramXml(arr[i].children, parentId);
              }
            }
            return arr;
          }
          const updatedArray = updateCurrDiagramXml(tempMappDiags, this.state.currentMapDet.id)
          console.log("##### ", updatedArray);
          this.setState({
            mappingDiagrams: updatedArray,
            selectedLanguage: selLang,
          })

          // **************************************************//
          // this.displayLanguageOnChange(xmlResult, prevLanguage, selLang);
          await this.displayLanguageOnChange(updatedArray, prevLanguage, selLang);
        } catch (error) {
          console.error(error);
        }
      }
      this.setState({
        selectedLanguage: selLang,
      });
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
    }
  };
  displayLanguageOnChange = async (updatedArray, prevLanguage, selLang) => {
    console.log(prevLanguage, selLang, updatedArray);
    try {
      let tempMappDiags = [...this.state.mappingDiagrams];

      let importXMLResponse;
      const updateCurrDiagramXml = async (arr, parentId) => {
        for (let i = 0; i < arr.length; i++) {
          const currDiagXML = arr[i].diagramXML;
          if (currDiagXML !== "") {
            const response = await translateXmlNamesByLanguage(currDiagXML, prevLanguage.value, selLang.value, arr[i].name);
            console.log("translate response ", arr[i].id, arr[i].meta.label, response);

            if (arr[i].id === parentId) {
              console.log("&&& parentId diag IMPORT XML ");
              importXMLResponse = response.xmlResponse;
            }
            arr[i].diagramXML = response.xmlResponse;
            // arr[i].name = response.diagramTitleResult;
            // arr[i].meta.label = arr[i].id + (response.diagramTitleResult ? ("-" + response.diagramTitleResult) : "")
            if (arr[i].children.length === 0) {
              continue;
            }
          }
          await updateCurrDiagramXml(arr[i].children, parentId);
        }
        return arr;
      }
      this.setMappingDiagramsArray("isDiagNavigationClicked", false)
      const updatedArray = await updateCurrDiagramXml(tempMappDiags, this.state.currentMapDet.id)
      console.log("##### after lang Convert", updatedArray);

      await this.refreshBpmn_OnClick();
      console.log("importXMLResponse ******* ", importXMLResponse);
      await this.updateXmlByImportXML(importXMLResponse);
      this.setState({
        mappingDiagrams: updatedArray
      })
      this.closeSpinnerRedux();
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux();
    }
  };

  openAddDocument = () => {
    let elementid = document.getElementById("bio-properties-panel-id")?.value;
    console.log("elementid", elementid);
    if (elementid === null || elementid === undefined || elementid === "" || elementid === "Process_0tz6k3o" || (!elementid?.includes("Activity"))) {
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
      return;
    }
    this.setState({
      element_data_id: elementid,
    });
    this.fileUploadRef.current.click();
  };
  handleAddDocFileOnChange = async (e) => {

    const files = e.target.files
    const file = e.target.files[0]
    const maxSizeInBytes = 5 * 1024 * 1024;
    console.log(files);
    if (files.length > 0) {
      // const file = files[0];
      for (let i = 0; i < files.length; i++) {
        const allowedExtensions = /\.(pdf|xlsx|xls|docx|txt|pptx|mp4|mov|jpeg|jpg|png)$/i;
        console.log(files[i].name);
        if (!allowedExtensions.test(files[i].name)) {
          ErrorMessage("Invalid format");
          return;
        }
      }
    }
    console.log(file, files);
    console.log(Object.keys(files), Object.values(files));
    if (file) {
      if (file.size > maxSizeInBytes) {
        ErrorMessage('Uploaded file exceeds 5MB, please try again.');
        return;
      }
      const parent_Id = this.state.element_data_id,
        currXmlId = this.state.currentMapDet.id,
        diagramXmlId = this.state.resSavedData.diagramXmlId;
      console.log(diagramXmlId, currXmlId);

      let tempFilesData = [];
      Object.values(files).forEach(file => {
        const newFileName = `${diagramXmlId}/${currXmlId}/${parent_Id}/${file?.name}`
        const newFile = new File([file], newFileName);
        console.log(newFile);
        tempFilesData.push(newFile);
      })

      this.openSpinnerRedux();
      try {
        const response = await this.uploadDocSharePointAPICALL(tempFilesData);
        console.log("response ", response);
        const resData = await response.data;
        if (response.status === 200 || response.status === 201) {
          SuccessMessage(tempFilesData.length + BPMN_Editor_Toaster.Document_Uploaded)

          // const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
          // const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');
          const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
          // const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
          const parentElement = elementRegistry.get(parent_Id);
          console.log(parentElement);
          // const parentMapIds = parentElement.businessObject.$attrs.mapped_Child_Ids;
          // let childDocElement;
          // if (parentMapIds === undefined || (!parentMapIds?.includes("Document_"))) {
          //   console.log("Doc Not Exist");
          // const newShapeDocument = elementFactory.createShape({ type: 'bpmn:DataObjectReference', height: 20, width: 15 });
          // console.log(newShapeDocument);
          // bpmnModeling.createShape(newShapeDocument, { x: (parentElement.x + parentElement.width - 35), y: parentElement.y + 15 },
          //   parentElement.parent
          // );
          // bpmnModeling.setColor(newShapeDocument, {
          //   fill: '#D2DDE1', //'#bbdefb',
          //   stroke: '#131E36', //'#bbdefb'
          // })
          // bpmnModeling.updateProperties(newShapeDocument, {
          //   id: "Document_" + parent_Id,
          // });
          // newShapeDocument.businessObject.$attrs.parentActivityId = parent_Id;
          // childDocElement = newShapeDocument
          // } else {
          //   const childDocId = parentMapIds?.split(',')?.filter(id => (id?.includes("Document")))
          //   console.log(childDocId);
          //   childDocElement = elementRegistry.get(childDocId[0]);
          //   console.log("childDocElement 1 ", childDocElement);
          // }
          // const tempFiles = childDocElement.businessObject.$attrs.allFileNamesWithId;
          let bo = parentElement.businessObject;
          let docs = bo.get('documentation');
          console.log("docs ", docs)
          let attachment;

          const isDocAlreadyAdded = docs.find(d => d.textFormat === 'json/file-document' && (attachment = d))
          console.log("isDocAlreadyAdded ", isDocAlreadyAdded)

          const tempFiles = isValidValue(isDocAlreadyAdded) && isValidValue(isDocAlreadyAdded?.text) ? isDocAlreadyAdded.text : [];
          console.log("tempFiles ", tempFiles)
          let updatedAllFilesWithId = isArray(tempFiles) ? [] : JSON.parse(tempFiles);
          console.log("updatedAllFilesWithId ", updatedAllFilesWithId);
          if (updatedAllFilesWithId?.length === 0) {
            console.log("if ", [...resData]);
            updatedAllFilesWithId = [...resData]
          } else {
            console.log("else ", [...resData]);
            resData.forEach(file => {
              const isFileAlreadyExists = updatedAllFilesWithId.some(fileItem => fileItem.documentId === file.documentId);
              console.log("exist file new file ", isFileAlreadyExists);
              if (!(isFileAlreadyExists)) {
                updatedAllFilesWithId.push(file)
              }
            })
          }
          console.log("updatedAllFilesWithId ,", updatedAllFilesWithId);
          // childDocElement.businessObject.$attrs.allFileNamesWithId = JSON.stringify(updatedAllFilesWithId);
          // create if not existing
          if (!attachment) {
            attachment = bo.$model.create('bpmn:Documentation', {
              textFormat: 'json/file-document'
            });
            docs.push(attachment);
          }
          console.log("attachment ", attachment)
          attachment.text = JSON.stringify(updatedAllFilesWithId);
          // const tempBussObjChild_Ids = parentElement.businessObject.$attrs?.mapped_Child_Ids;
          // const tempAddedChild_Ids = tempBussObjChild_Ids === "" ? childDocElement.id : (tempBussObjChild_Ids?.includes(childDocElement.id) ? tempBussObjChild_Ids : tempBussObjChild_Ids + "," + childDocElement.id);
          // console.log(tempAddedChild_Ids);
          // bpmnModeling.updateProperties(parentElement, {
          //   mapped_Child_Ids: tempAddedChild_Ids,
          // });

          // if (parentElement.type === "bpmn:SubProcess") {
          //   this.setMappingDiagramsArray("isDiagNavigationClicked", false)
          //   setTimeout(async () => {
          //     const currXML = await this.getCurrentDiagramXML()
          //     this.updateXmlByImportXML(currXML);
          //   }, 500);
          // }
          // console.log("childDocElement ", childDocElement);
          console.log("parentElement ", parentElement);
          this.closeSpinnerRedux();
          this.handleBpmnRef.current.bpmnModeler?.get('documents')?.renderFileDocByElement(parentElement)
          const auditDocs = updatedAllFilesWithId.map(el => el.fileName).join(', ');
          const oldDocValue = (tempFiles && typeof tempFiles === "string" && tempFiles.trim() !== "") ? JSON.parse(tempFiles).length > 0 ? JSON.parse(tempFiles).map(el => el.fileName).join(', ') : ' ' : ' ';
          const pushAuditObject = {
            diagramLevel: this.state.currentMapDet.id,
            AutoNumCount: parentElement?.businessObject?.$attrs?.AutoNumCount,
            id: parent_Id,
            field: "Document Names",
            newValue: `${this.state.currentMapDet.id} (${parentElement?.businessObject?.$attrs?.AutoNumCount}) - ${auditDocs}`,
            oldValue: oldDocValue.trim().length > 0
              ? `${this.state.currentMapDet.id} (${parentElement?.businessObject?.$attrs?.AutoNumCount}) - ${oldDocValue}`
              : " ",
            type: "DOCUMENT",
          }
          this.audittrailpushingObj(pushAuditObject, "DOCUMENT")
        }
      } catch (error) {
        this.closeSpinnerRedux();
        ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
        console.error(error);
      }
    }
  };

  handleResourcePopup = (selectedData) => {
    this.addResourceNameOnClick(selectedData)
  }

  closeDialogPopupBox = () => {
    this.setState({
      editAutoNumflag: false,
      IsUploadBpmn: false,
      isActivitytextEnable: false,
      isPublishPopupEnable: false,
      element_data_id: "",
      selectedXmlFileName: "",
      flowLinePopup: false,
      onshowdiagram: false,
      showFlowlinoepopup: false,
      selectedIdFlowLine: false,
      isActivityFileDocEnable: false,
      isdownload: false,
      isFromUpload: false,
      diagramLevel: "CurrentProcessMap",
      showActivityBoxMapping: false,
      showFlowlinoepopupTarget: false,
      isSendToReviewer: false,
      FromReviewsentback: false,
      FromDiagramApprove: false,
      isCommentOpened: false,
      comment: "",
      isAddresouceOpen: false,
      createTemplateState: false,
      isApplyTemplateEnable: false,
      PrintLevel: false,
      reArrangePopupFlag: false,
      isIntegrityCheckEnable: false,
      isICReportExportEnable: false,
      isALMTestCaseViewEnable: false,
      isReqOrTestcaseEnable: false
    });
    if (this.state.editElementObj?.element) {
      this.handleBpmnRef.current.bpmnModeler.get("modeling").updateProperties(this.state.editElementObj?.element, {});
    }
  };
  openSpinnerRedux = () => {
    // this.props.toggleSpinnerFlag(true);
    this.props.openSpinnerRedux()
  };
  closeSpinnerRedux = () => {
    // this.props.toggleSpinnerFlag(false);
    this.props.closeSpinnerRedux()
  };
  onClickAddResource = async () => {
    let elementid = document.getElementById("bio-properties-panel-id")?.value;
    console.log("🚀 ~ elementid:", elementid);
    if (elementid === null || elementid === undefined || elementid === "" || elementid === "Process_0tz6k3o" || (!elementid?.includes("Activity"))) {
      console.log(elementid, "im triggred");
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
      return;
    }

    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const parent_Id = elementid;
    const selectedResource = await bpmnCanvas._elementRegistry.filter((item) => item.id === parent_Id);

    const resourceBoxIds = selectedResource[0].businessObject.$attrs.mapped_Child_Ids?.split(",")?.filter(item => item.includes("Actor"))
    console.log("resourecNames", resourceBoxIds);
    console.log(resourceBoxIds);
    let selectedResources = [];
    if (resourceBoxIds) {
      selectedResources = resourceBoxIds.map((resId) => {
        const selResEle = bpmnCanvas._elementRegistry.get(resId);
        const selResBusObjAtr = selResEle?.businessObject.$attrs;
        console.log(selResBusObjAtr, selResEle);
        if (selResBusObjAtr?.resourceId) {
          return {
            resourceId: selResBusObjAtr.resourceId,
            resourceName: selResBusObjAtr.resourceName,
            resourceType: selResBusObjAtr.resourceType,
            displayName: selResBusObjAtr.fullNametxt,
          }
        } else {
          return selResBusObjAtr?.fullNametxt
        }
      })
    }

    this.setState(prevState => ({
      selectedResources: selectedResources,
      element_data_id: elementid,
      isAddresouceOpen: !prevState.isAddresouceOpen
    }))


  }
  onClickflowlinepopup = async () => {
    let elementid = document.getElementById("bio-properties-panel-id")?.value;
    console.log("elementid", elementid);
    if (elementid === null || elementid === undefined || elementid === "" || elementid === "Process_0tz6k3o" || (!elementid?.includes("Activity"))) {
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
      return;
    }
    else {
      this.setState(prevState => ({
        flowLinePopup: !prevState.flowLinePopup
      }));
    }
  }

  onClickTreeFlowLine = async (treeItem) => {
    console.log(treeItem);
    this.setState({
      treelineFlag: true
    })
    console.log("onclicketreeline");
    if (treeItem.id === this.state.currentMapDet.id) {
      toast.error("A flow line cannot be made to the same diagram");
      this.setState({
        flowLineflag: true,
        treelineFlag: false
      })
      return;
    }
    else {
      const newDataFromId = {
        id: treeItem.id,
        name: treeItem.name,
        key: treeItem.key,
        diagramXML: treeItem.diagramXML
      };
      this.setState({
        newDataFromConsole: newDataFromId,
        selectedIdFlowLine: treeItem.id,
        flowLineflag: false,
        selectedDiagramXml: treeItem
      })
    }

  }


  onClickshowDiagram = async () => {
    if (this.state.treelineFlag) {
      if (this.state.flowLineflag && this.state.selectedIdFlowLine !== null) {
        this.closeDialogPopupBox()
        return
      }
      else {
        const findElementById = (data, id) => {
          for (let i = 0; i < data.length; i++) {
            const element = data[i];
            if (element.id === id) {
              return element;
            }
            if (element.children && element.children.length > 0) {
              const foundInChildren = findElementById(element.children, id);
              if (foundInChildren) {
                return foundInChildren;
              }
            }
          }
          return null;
        };

        const updateElement = (data, updatedElement) => {
          return data.map(item => {
            if (item.id === updatedElement.id) {
              return updatedElement;
            } else if (item.children && item.children.length > 0) {
              return {
                ...item,
                children: updateElement(item.children, updatedElement)
              };
            }
            return item;
          });
        };

        const fetchData = () => {
          console.log("fetchdata is running");
          const currentId = this.state.currentMapDet?.id;
          const mappingDiagrams = [...this.state.mappingDiagrams];
          console.log(mappingDiagrams);
          const foundElement = findElementById(mappingDiagrams, currentId);
          console.log("found element", foundElement);
          if (foundElement.flowlineMap && foundElement.flowlineMap.length > 0) {
            console.log("im inside the flowline length greater than 0");
            const foundElementExists = foundElement.flowlineMap.find(el => el.id === this.state.selectedIdFlowLine);
            if (!foundElementExists) {
              foundElement.flowlineMap.push(this.state.newDataFromConsole);
              const updatedMappingDiagrams = updateElement(this.state.mappingDiagrams, foundElement);
              console.log(updatedMappingDiagrams);
              this.setState({ mappingDiagrams: updatedMappingDiagrams });
              this.closeDialogPopupBox()
              this.addFlowLineActivity()
              this.setState({
                treelineFlag: false
              })
            } else {
              toast.error("This flow line already has a link to the selected destination flow line");
              return;
            }
          } else {
            console.log("im inside the flowline length lesser than or equal to 0");
            foundElement.flowlineMap = [this.state.newDataFromConsole];
            const updatedMappingDiagrams = updateElement(this.state.mappingDiagrams, foundElement);
            this.setState({ mappingDiagrams: updatedMappingDiagrams });
            this.closeDialogPopupBox()
            this.addFlowLineActivity()
            this.setState({
              treelineFlag: false
            })
          }
        };
        if (!this.state.flowLineflag) {
          fetchData()
          this.setState({
            selectedIdFlowLine: '',
            flowLineflag: false,
            treelineFlag: false
          });
        }
      }
    }
    else {
      toast.error("Please select any destination flow line ");
      return;
    }
  }
  onShowActivityBox = async () => {
    const elementid = document.getElementById("bio-properties-panel-id")?.value;
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');

    const sourceAutoNum = bpmnCanvas._elementRegistry.get(elementid)
    if (this.state.treelineFlag && this.state.selectedIdFlowLine) {
      const digXml = await this.state.newDataFromConsole.diagramXML
      console.log(digXml);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(digXml, "application/xml");
      console.log(xmlDoc);
      const bpmnNamespace = 'http://www.omg.org/spec/BPMN/20100524/MODEL'
      const bpmnElements = xmlDoc.getElementsByTagNameNS(bpmnNamespace, '*');
      console.log(bpmnElements);

      if (bpmnElements.length === 2 || bpmnElements.length === 0 || bpmnElements === null || bpmnElements === undefined) {

        toast('There is no diagram available inside this, so please add any task and proceed.', {
          icon: '⚠️',
        });
        return;
      }
      this.setState({
        showActivityBoxMapping: true,
        flowLinePopup: false,
        sourceAutoNum: sourceAutoNum?.businessObject.$attrs.AutoNumCount
      })
    }
    else {
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity)
      return
    }
  }
  onBackActivityBox = () => {
    this.setState({
      showActivityBoxMapping: false,
      flowLinePopup: true
    })
  }
  previousforDiagrampop = () => {
    this.setState({
      onshowdiagram: false,
      flowLinePopup: true
    })
  }


  treeViewToggle = () => {
    if (document.getElementsByClassName("djs-palette open")[0].style.display === 'none') {
      document.getElementsByClassName("djs-palette open")[0].style.display = "block"
    }
    else {
      document.getElementsByClassName("djs-palette open")[0].style.display = "none"
    }

    this.setState({
      isTreeView: !this.state.isTreeView
    })
  }
  setMappingDiagramsArray = (stateName, updatedValue) => {
    switch (stateName) {
      case "mappingDiagrams":
        this.setState({
          mappingDiagrams: updatedValue
        })
        break;
      case "currentMapDet":
        this.setState(prevState => ({
          prevCurrMapDet: prevState.currentMapDet,
          currentMapDet: updatedValue,
        }))
        break;
      case "isDiagNavigationClicked":
        this.setState({
          isDiagNavigationClicked: updatedValue
        })
        break;
      case "mapDiagramRecord":
        this.setState({
          mapDiagramRecord: updatedValue
        })
        break;
      case "resSavedData":
        this.setState({
          resSavedData: updatedValue
        })
        break;

      default:
        console.log("default", stateName, updatedValue);
        this.setState({
          [stateName]: updatedValue
        })
        break;
    }
    console.log("setMappingDiagramsArray TRIGGEREDDDD", stateName, updatedValue);
  }
  onClickTreeViewItem = async (treeItem) => {
    console.log(this.state.rearrangeArray);
    this.setState({
      getActivity: '',
      getActivityElementId: '',
    })

    if (this.state.rearrangeArray.length > 0 && this.state.editAutoNumflag) {
      ErrorMessage(BPMN_Editor_Toaster.Please_Save_The_Changes_For_Rearrange_And_Move_Forward)
      return
    }
    console.log(treeItem)
    let tempMappDiags = [...this.state.mappingDiagrams];
    const tempCurrMap = { ...this.state.currentMapDet };
    console.log(treeItem, tempMappDiags, tempCurrMap);
    if (treeItem.id === tempCurrMap.id) {
      console.log("Same Level");
      return
    }
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    const currentXML = await this.getCurrentDiagramXML();
    const upadtedCurMap = {
      id: treeItem.id,
      name: treeItem.name,
      key: treeItem.key,
      meta: {
        collapsed: true,
        label: treeItem.meta.label
      },
      diagramXML: treeItem.diagramXML,
      parentId: tempCurrMap.id,
      children: [],

    }
    try {

      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            console.log(arr[i].diagramXML, currentXML);
            const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
            console.log("isBothXMLSame ", isBothXMLSame);
            if (!(isBothXMLSame)) {
              arr[i].diagramXML = currentXML;
            }
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
      console.log("##### ", updatedArray);

      this.setState(prevState => ({
        mappingDiagrams: updatedArray,
        prevCurrMapDet: prevState.currentMapDet,
        currentMapDet: upadtedCurMap,
        filteredDataArray: [],
        lastOccurances: {},
        rearrangeArray: [],
        getActivity: '',
        getActivityElementId: '',
      }))

      const xml = await getXmlDiagram("default");
      console.log(treeItem, treeItem.diagramXML);
      const diagramXML = treeItem.diagramXML === "" ? xml : treeItem.diagramXML
      this.updateXmlByImportXML(diagramXML)

    } catch (error) {
      console.error(error);
    }
  }
  onDiagramNavOnclick = async (navType) => {
    try {

      if (this.state.rearrangeArray.length > 0 && this.state.editAutoNumflag) {
        ErrorMessage(BPMN_Editor_Toaster.Please_Save_The_Changes_For_Rearrange_And_Move_Forward)
        return
      }

      console.log("navv ", navType);
      let tempMappDiags = [...this.state.mappingDiagrams];
      const tempCurrMap = { ...this.state.currentMapDet };
      const tempPrevCurrMap = { ...this.state.prevCurrMapDet };
      console.log(tempMappDiags, tempCurrMap);

      const currentXML = await this.getCurrentDiagramXML();

      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            // console.log(arr[i].diagramXML, currentXML);
            const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
            console.log("isBothXMLSame ", isBothXMLSame);
            if (!(isBothXMLSame)) {
              arr[i].diagramXML = currentXML;
            }
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }

      const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
      console.log("##### ", updatedArray);

      let upadtedCurMap = {}
      function getChildDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          console.log(arr[i].id === parentId, i);
          if (arr[i].id === parentId) {
            return arr[i];
          } else if (arr[i].children.length === 0) {
            continue;
          }
          else {
            const isObjFinded = getChildDiagramXml(arr[i].children, parentId);
            if (isObjFinded) {
              return isObjFinded
            }
          }
        }
        return "";
      }
      if (navType === "BACKTOPARENT") {
        const isBothXMLSame = await this.getIsUnSavedXMLExist();
        console.log(isBothXMLSame);
        if (this.state.copyGetComment.length > 0) {
          const tempCurrDiagMapps = [...this.state.mappingDiagrams]
          console.log(tempCurrDiagMapps);
          const selLang = this.state.selectedLanguage;
          const reqPayload = {
            xmlData: JSON.stringify(tempCurrDiagMapps),
            languageName: selLang.label,
            languageCode: selLang.value
          };
          try {
            const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
            const data = await { ...response.data };
            console.log("****  data ", data);
            console.log("****  response.data ", response.data);
            this.setState({
              resSavedData: await response.data
            })
            if (response.status === 200 || response.status === 201) {
              console.log(data);
              let selLang = { label: data.languageName, value: data.languageCode }
              if (!(data.languageCode || data.languageName)) {
                selLang.value = "en";
                selLang.label = "English"
              }
              let parsedMappingDiagrams;
              if (data.xmlData === "" || data.xmlData === null) {
                parsedMappingDiagrams = [...this.state.mappingDiagrams]
              } else {
                parsedMappingDiagrams = JSON.parse(data.xmlData)
              }
              console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
              data.xmlData = parsedMappingDiagrams[0].diagramXML
              this.setState({
                // userSavedData: data,
                mappingDiagrams: parsedMappingDiagrams,
                selectedLanguage: selLang
              });

              // SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);    
            }
          } catch (error) {
            console.log("saveLatestXmlAPICALL", error);
            ErrorMessage(error?.response?.data);
          }
          this.setState({
            copyGetComment: []

          })
          this.props.BackToParent("checkOut")
          return
        }
        if (isBothXMLSame) {
          this.props.BackToParent("checkOut")
          return
        }
        else if (window.confirm("Changes you made may not be saved.")) {
          this.setState({
            filteredDataArray: [],
            lastOccurances: {},
            rearrangeArray: [],
          })
          this.props.BackToParent("checkOut")
          return
        }
        this.setState({
          filteredDataArray: [],
          lastOccurances: {},
          rearrangeArray: [],
        })
        return
      }
      switch (navType) {
        case "HOME":
          if (tempCurrMap.id === tempMappDiags[0].id) {
            toast.error("Currently at the home level !");
            return
          }

          upadtedCurMap = tempMappDiags[0]
          break;
        case "UP":
          let splittedId = tempCurrMap.id.split(".");
          splittedId.pop();
          let upParentId = splittedId.join(".");
          console.log("uppp ", upParentId);
          if (upParentId === "" || upParentId === undefined) {
            toast.error("The parent level does not exist!")
            return
          }
          upadtedCurMap = getChildDiagramXml(tempMappDiags, upParentId)
          console.log("111 ", upadtedCurMap);
          break;
        case "PREV":
          console.log("PREVV ", tempPrevCurrMap);
          if (tempPrevCurrMap === undefined || tempPrevCurrMap.id === undefined) {
            toast.error("The previous diagram is not available.!");
            return
          }
          upadtedCurMap = getChildDiagramXml(tempMappDiags, tempPrevCurrMap.id)
          break;

        default:
          break;
      }
      this.setMappingDiagramsArray("isDiagNavigationClicked", false)
      console.log(upadtedCurMap, updatedArray, this.state.prevCurrMapDet);

      const xml = await getXmlDiagram("default");
      const diagramXML = upadtedCurMap.diagramXML === "" ? xml : upadtedCurMap.diagramXML
      await this.updateXmlByImportXML(diagramXML)
      this.setState(prevState => ({
        mappingDiagrams: updatedArray,
        prevCurrMapDet: prevState.currentMapDet,
        currentMapDet: upadtedCurMap,
        filteredDataArray: [],
        lastOccurances: {},
        rearrangeArray: [],
      }))

    } catch (error) {
      console.error(error);
      if (navType === "BACKTOPARENT") {
        this.props.BackToParent("checkOut")
      }
    }
  }
  handleCommentsEdit = async (x, editedComment, index) => {
    const payload = {
      commentMessage: editedComment
    }
    // const updatedComments = [...this.state.copiedComments];
    // updatedComments[index].commentMessage = editedComment;
    // console.log("updatedComments", updatedComments);

    // this.setState(prevState => ({
    //   copiedComments: updatedComments
    // }))
    const res = await BPMNService.editCommentsById(x.commentId, payload)
    try {
      if (res.status === 200 || res.status === 201) {
        await this.GetComments(this.state.userSavedData.diagramXmlId)
      }
    } catch (error) {
      console.error(error);
    }
  }
  handleCommentsDelete = async (x, index) => {
    // const updatedComments = this.state.copiedComments.filter((_, i) => i !== index);
    // this.setState(prevState => ({
    //   copiedComments: updatedComments
    // }))
    const res = await BPMNService.deleteCommentsById(x.commentId)
    try {
      if (res.status === 200 || res.status === 201) {
        this.GetComments(this.state.userSavedData.diagramXmlId)
      }
    } catch (error) {
      console.error(error);
    }
  }
  //comments navigation
  handleCommentsClick = async (commentMsg, index) => {

    const id = commentMsg.currentXmlId
    console.log("id:", id);
    const tempCurrMap = { ...this.state.currentMapDet };
    const currentXML = await this.getCurrentDiagramXML();
    function updateCurrDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === parentId) {
          arr[i].diagramXML = currentXML;
          return arr;
        } else {
          if (arr[i].children.length === 0) {
            continue;
          }
          updateCurrDiagramXml(arr[i].children, parentId);
        }
      }
      return arr;
    }
    let tempMappDiags = [...this.state.mappingDiagrams];
    const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
    console.log("##### ", updatedArray)
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    let diagramXMLTemp;
    function getChildDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i].id === parentId, arr[i]);
        if (arr[i].id === parentId) {
          diagramXMLTemp = arr[i]
          return arr[i];
        } else if (arr[i].children.length === 0) {
          continue;
        }
        else {
          getChildDiagramXml(arr[i].children, parentId);
        }
      }
      return "";
    }
    console.log(id);
    getChildDiagramXml([...tempMappDiags], id);

    console.log(diagramXMLTemp);
    console.log(tempMappDiags);
    console.log(diagramXMLTemp);
    if (diagramXMLTemp !== undefined) {

      await this.updateXmlByImportXML(diagramXMLTemp?.diagramXML)
    }
    this.setState(prevState => ({
      showFlowlinoepopup: false,
      showFlowlinoepopupTarget: false,
      currentMapDet: { ...diagramXMLTemp },
      mappingDiagrams: updatedArray,
      prevCurrMapDet: prevState.currentMapDet,
    }))

    let selectionService = await this.handleBpmnRef.current.bpmnModeler.get("selection")
    const parentActivityId = this.handleBpmnRef.current.bpmnModeler.get('canvas')._elementRegistry.get(commentMsg.activityId)
    if (parentActivityId !== undefined) {
      console.log(commentMsg, index);
      function setComment(params, index) {
        return params.map((el, idx) =>
          idx === index
            ? { ...el, flagToggleActivity: commentMsg.role === "Editor" ? false : true }
            : el
        );
      }
      const setComments = this.state.userRole === 'Editor' ? setComment(this?.state?.getComment, index) : this.state.getComment;
      const setcopiedComments = this.state.userRole === 'Editor' ? setComment(this?.state?.copiedComments, index) : this.state.copiedComments;
      this.setState(
        {
          getComment: setComments,
          copiedComments: setcopiedComments
        },
      );
      selectionService.select(parentActivityId);
      this.setState({
        getActivity: '',
        getActivityElementId: '',

      })
      if (this.state.userRole === 'Editor' && commentMsg.role !== "Editor") {
        await BPMNService.updatePostComments(commentMsg.commentId, true)
        return;
      }
    }
    else {
      ErrorMessage("The activity has been deleted, or the diagram may not have been saved properly")
      return;
    }
  }

  findElementById = (data, id) => {
    for (let i = 0; i < data.length; i++) {
      const element = data[i];
      if (element.id === id) {
        return element;
      }
      if (element.children && element.children.length > 0) {
        const foundInChildren = this.findElementById(element.children, id);
        if (foundInChildren) {
          return foundInChildren;
        }
      }
    }
    return null;
  }
  flowlinkIdFinder = (resultDiagrams, activityId) => {
    console.log(activityId);
    const importXMLResponse = resultDiagrams;
    if (importXMLResponse !== '') {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(importXMLResponse, 'text/xml');
      console.log(xmlDoc);
      const element = xmlDoc.querySelector(`[id="${activityId}"]`)
      console.log(element);
      if (element === undefined || element === null) {
        return false;
      }
      else {
        return true
      }
    }
  }
  verifyTargetId = (targetId, activityId) => {
    console.log(targetId, this.state.mappingDiagrams);
    const targetMap = this.findElementById(this.state.mappingDiagrams, targetId);
    console.log(targetMap);
    const isActivitypresent = this.flowlinkIdFinder(targetMap?.diagramXML, activityId)
    console.log(isActivitypresent);
    return isActivitypresent
  }


  //flowlink navigation
  handleFlowlineClick = async (id, item, receiver) => {
    // const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    // const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const digName = this.state.mapDiagramRecord.diagramName
    console.log(digName, item);
    const tempCurrMap = { ...this.state.currentMapDet };
    const currentXML = await this.getCurrentDiagramXML();
    function updateCurrDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === parentId) {
          const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
          console.log("isBothXMLSame ", isBothXMLSame);
          if (!(isBothXMLSame)) {
            arr[i].diagramXML = currentXML;
          }
          return arr;
        } else {
          if (arr[i].children.length === 0) {
            continue;
          }
          updateCurrDiagramXml(arr[i].children, parentId);
        }
      }
      return arr;
    }
    let tempMappDiags = [...this.state.mappingDiagrams];
    const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
    console.log("##### ", updatedArray)
    this.setMappingDiagramsArray("isDiagNavigationClicked", false)
    let diagramXMLTemp;
    function getChildDiagramXml(arr, parentId) {
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i].id === parentId, arr[i]);
        if (arr[i].id === parentId) {
          diagramXMLTemp = arr[i]
          return arr[i];
        } else if (arr[i].children.length === 0) {
          continue;
        }
        else {
          getChildDiagramXml(arr[i].children, parentId);
        }
      }
      return "";
    }
    console.log(id);
    getChildDiagramXml([...tempMappDiags], id);

    console.log(diagramXMLTemp);
    console.log(tempMappDiags);
    console.log(diagramXMLTemp);
    await this.updateXmlByImportXML(diagramXMLTemp.diagramXML)
    this.setState(prevState => ({
      showFlowlinoepopup: false,
      showFlowlinoepopupTarget: false,
      currentMapDet: { ...diagramXMLTemp },
      mappingDiagrams: updatedArray,
      prevCurrMapDet: prevState.currentMapDet,
    }))
    let selectionService = await this.handleBpmnRef.current.bpmnModeler.get("selection");
    const parentActivityId = this.handleBpmnRef.current.bpmnModeler.get('canvas')._elementRegistry.get(item.targetActivityId)
    const targetActivityId = this.handleBpmnRef.current.bpmnModeler.get('canvas')._elementRegistry.get(item.parentActivityId)
    // if (parentActivityId === undefined && targetActivityId === undefined) {
    //   // ErrorMessage('The diagram was imported from a different map, so please remove the old linkages and establish new ones')
    //   if (receiver === 'source') {
    //     const isOKbuttonClicked = window.confirm('The diagram was imported from a different map, so old linkage will be removed now and establish new ones')
    //     if (isOKbuttonClicked === true) {
    //       function findElementById(data, id) {
    //         for (let i = 0; i < data.length; i++) {
    //           const element = data[i];
    //           if (element.id === id) {
    //             return element;
    //           }
    //           if (element.children && element.children.length > 0) {
    //             const foundInChildren = findElementById(element.children, id);
    //             if (foundInChildren) {
    //               return foundInChildren;
    //             }
    //           }
    //         }
    //         return null;
    //       }
    //       const fetchData = async () => {
    //         const mapDiagram = this.state.mappingDiagrams;
    //         const currMapId = this.state.currentMapDet.id
    //         if (receiver === 'source') {
    //           const originflowEndObj = await findElementById(mapDiagram, item.targetMapId);
    //           console.log(originflowEndObj);
    //           if (originflowEndObj) {
    //             const updatedFlowLine = originflowEndObj?.flowlineMap.filter(el => {
    //               return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.targetMapId === el.targetMapId)
    //             });
    //             console.log(updatedFlowLine);
    //             const remainSourceConnectCheck = updatedFlowLine.filter(el => el.targetActivityId === item.targetActivityId
    //             )
    //             console.log(remainSourceConnectCheck);

    //             if (remainSourceConnectCheck.length === 0) {
    //               const deleteActivity = async (xml) => {
    //                 console.log("delete activity called", xml.diagramXML)
    //                 const tempDivEle = document.createElement("div");
    //                 const tempBpmnModeling = new BpmnModeler({
    //                   tempDivEle,
    //                 })
    //                 console.log(tempBpmnModeling);
    //                 await tempBpmnModeling.importXML(xml.diagramXML)
    //                 const bpmnCanvas = tempBpmnModeling.get('canvas');
    //                 const bpmnModeling = tempBpmnModeling.get('modeling');
    //                 console.log(bpmnCanvas, bpmnModeling);
    //                 const findTargetActivityforStart = await bpmnCanvas._elementRegistry.get(item.targetActivityId);
    //                 console.log(findTargetActivityforStart);
    //                 const flowLineStartId = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLS_'))
    //                 const filtermappedWithoutFLS = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLS_'))
    //                 findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLS.join(',');
    //                 console.log(flowLineStartId);
    //                 const removeStartEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineStartId);
    //                 console.log(removeStartEventonShapeImpl);
    //                 await bpmnModeling.removeElements([removeStartEventonShapeImpl])
    //                 const xmlResult = (await tempBpmnModeling.saveXML()).xml;
    //                 console.log(xmlResult);
    //                 originflowEndObj.diagramXML = xmlResult;
    //                 const updatedMappingDiagrams1 = mapDiagram.map(item => {
    //                   if (item.id === item.targetMapId) {
    //                     return originflowEndObj;
    //                   } else {
    //                     return item;
    //                   }
    //                 });
    //                 this.setState({ mappingDiagrams: updatedMappingDiagrams1 });
    //                 this.closeDialogPopupBox()
    //                 this.setState({
    //                   parentActivityId: '',
    //                   targetActivityId: ''
    //                 })
    //                 return;
    //               }
    //               deleteActivity(originflowEndObj)
    //             };
    //             originflowEndObj.flowlineMap = updatedFlowLine;
    //             this.closeDialogPopupBox()
    //           }
    //         }
    //         else {
    //           const targetflowStartObj = await findElementById(mapDiagram, item.targetMapId);
    //           console.log({ ...targetflowStartObj })
    //           const updatedFlowLine1 = { ...targetflowStartObj }?.flowlineMap.filter(el => {
    //             return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.originMapId === el.originMapId);
    //           });
    //           console.log(updatedFlowLine1, updatedFlowLine1.filter(el => el.targetActivityId === item.targetActivityId));
    //           const remainTargetConnectCheck = updatedFlowLine1.filter(el => el.parentActivityId === item.parentActivityId && el.originMapId === this.state.currentMapDet.id)
    //           console.log(remainTargetConnectCheck);
    //           if (remainTargetConnectCheck.length === 0) {
    //             console.log("target end calling");
    //             const tempDivEle = document.createElement("div");
    //             const tempBpmnModeling = new BpmnModeler({
    //               tempDivEle,
    //             })
    //             console.log(tempBpmnModeling);
    //             await tempBpmnModeling.importXML(targetflowStartObj.diagramXML)
    //             const bpmnCanvas = tempBpmnModeling.get('canvas');
    //             const bpmnModeling = tempBpmnModeling.get('modeling');
    //             console.log(bpmnCanvas, bpmnModeling);
    //             console.log(this.state.editElementObj.element, this.state.editElementObj.element.businessObject.$attrs.parentActivityId)
    //             const findTargetActivityforEnd = await bpmnCanvas._elementRegistry.get(this.state.editElementObj.element.businessObject.$attrs.parentActivityId);
    //             console.log(findTargetActivityforEnd);
    //             const flowLineEndId = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLE_'))
    //             const filtermappedWithoutFLE = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLE_'))
    //             findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLE.join(',');
    //             console.log(flowLineEndId);
    //             const removeEndEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineEndId);
    //             console.log(removeEndEventonShapeImpl);
    //             await bpmnModeling.removeElements([removeEndEventonShapeImpl])
    //             // await bpmnModeling.removeElements([this.state.editElementObj.element])

    //             this.closeDialogPopupBox()
    //           };

    //           const updatedFlowLine1bool = targetflowStartObj?.flowlineMap.filter(el => {
    //             return el.targetActivityId === item.targetActivityId;
    //           });

    //           console.log(updatedFlowLine);
    //           console.log(updatedFlowLine1);
    //           console.log(updatedFlowLine1bool);
    //           targetflowStartObj.flowlineMap = updatedFlowLine1;

    //           const updatedMappingDiagrams1 = mapDiagram.map(item => {
    //             if (item.id === item.targetMapId) {
    //               return targetflowStartObj;
    //             } else {
    //               return item;
    //             }
    //           });
    //           console.log(updatedMappingDiagrams1);

    //           this.setState({ mappingDiagrams: updatedMappingDiagrams1 });


    //         }
    //       };
    //       fetchData();
    //     }
    //     return
    //   }
    //   else {
    //     ErrorMessage('The diagram was imported from a different map, so please remove the old linkages and establish new ones')
    //     return;

    //   }
    // }
    if (parentActivityId !== undefined) {
      selectionService.select(parentActivityId);
      return;
    }
    else {
      selectionService.select(targetActivityId);
      return;
    }

  }
  //delete activity for target with automatic source delete
  handleDeleteFlowActivity = (indexid, currMapId, item) => {
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    // const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');
    const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
    const parent_Id = item.parentActivityId;
    const parentActivity = elementRegistry.get(parent_Id)
    console.log(item, parentActivity);
    const mapDiagram = this.state.mappingDiagrams;
    console.log(indexid, currMapId);
    function findElementById(data, id) {
      for (let i = 0; i < data.length; i++) {
        const element = data[i];
        if (element.id === id) {
          return element;
        }
        if (element.children && element.children.length > 0) {
          const foundInChildren = findElementById(element.children, id);
          if (foundInChildren) {
            return foundInChildren;
          }
        }
      }
      return null;
    }

    const fetchData = async () => {
      const originflowEndObj = await findElementById(mapDiagram, currMapId);
      const targetflowStartObj = await findElementById(mapDiagram, item.targetMapId);
      console.log(originflowEndObj);
      console.log({ ...targetflowStartObj })

      if (originflowEndObj) {
        const updatedFlowLine = originflowEndObj?.flowlineMap.filter(el => {
          return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.targetMapId === el.targetMapId)
        });
        console.log(updatedFlowLine);

        const updatedFlowLine1 = { ...targetflowStartObj }?.flowlineMap.filter(el => {
          return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.originMapId === el.originMapId);
        });
        console.log(updatedFlowLine1, updatedFlowLine1.filter(el => el.targetActivityId === item.targetActivityId));
        // const remainSourceConnectCheck = updatedFlowLine1.filter(el => el.targetActivityId === item.targetActivityId && el.targetMapId === item.targetMapId
        const remainSourceConnectCheck = updatedFlowLine1.filter(el => el.targetActivityId === item.targetActivityId
        )
        console.log(remainSourceConnectCheck);

        if (remainSourceConnectCheck.length === 0) {
          const deleteActivity = async (xml) => {
            console.log("delete activity called", xml.diagramXML)
            const tempDivEle = document.createElement("div");
            const tempBpmnModeling = new BpmnModeler({
              tempDivEle,
            })
            console.log(tempBpmnModeling);
            await tempBpmnModeling.importXML(xml.diagramXML)
            const bpmnCanvas = tempBpmnModeling.get('canvas');
            const bpmnModeling = tempBpmnModeling.get('modeling');
            console.log(bpmnCanvas, bpmnModeling);
            const findTargetActivityforStart = await bpmnCanvas._elementRegistry.get(item.targetActivityId);
            if (findTargetActivityforStart !== undefined) {
              console.log(findTargetActivityforStart);
              const flowLineStartId = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLS_'))
              const filtermappedWithoutFLS = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLS_'))
              findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLS.join(',');
              console.log(flowLineStartId);
              const removeStartEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineStartId);
              console.log(removeStartEventonShapeImpl);
              await bpmnModeling.removeElements([removeStartEventonShapeImpl])
            }
            const xmlResult = (await tempBpmnModeling.saveXML()).xml;
            console.log(xmlResult);
            targetflowStartObj.diagramXML = xmlResult;
            const updatedMappingDiagrams1 = mapDiagram.map(item => {
              if (item.id === item.targetMapId) {
                return targetflowStartObj;
              } else {
                return item;
              }
            });
            this.setState({ mappingDiagrams: updatedMappingDiagrams1 });
            this.closeDialogPopupBox()
            this.setState({
              parentActivityId: '',
              targetActivityId: ''
            })
            return;
          }
          deleteActivity(targetflowStartObj)
        };


        // const remainTargetConnectCheck=updatedFlowLine.filter(el=>el.originMapId===this.state.currentMapDet.id)
        const remainTargetConnectCheck = updatedFlowLine.filter(el => el.parentActivityId === item.parentActivityId && el.originMapId === this.state.currentMapDet.id)
        console.log(remainTargetConnectCheck);

        if (remainTargetConnectCheck.length === 0) {
          console.log("target end calling");
          console.log(this.state.editElementObj.element, this.state.editElementObj.element.businessObject.$attrs.parentActivityId)
          const findTargetActivityforEnd = await bpmnCanvas._elementRegistry.get(this.state.editElementObj.element.businessObject.$attrs.parentActivityId);
          console.log(findTargetActivityforEnd);
          const flowLineEndId = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLE_'))
          const filtermappedWithoutFLE = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLE_'))
          findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLE.join(',');
          console.log(flowLineEndId);
          const removeEndEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineEndId);
          console.log(removeEndEventonShapeImpl);
          await bpmnModeling.removeElements([removeEndEventonShapeImpl])
          // await bpmnModeling.removeElements([this.state.editElementObj.element])

          this.closeDialogPopupBox()
        };

        const updatedFlowLine1bool = targetflowStartObj?.flowlineMap.filter(el => {
          return el.targetActivityId === item.targetActivityId;
        });

        console.log(updatedFlowLine);
        console.log(updatedFlowLine1);
        console.log(updatedFlowLine1bool);
        originflowEndObj.flowlineMap = updatedFlowLine;
        targetflowStartObj.flowlineMap = updatedFlowLine1;
        const updatedMappingDiagrams = mapDiagram.map(item => {
          if (item.id === currMapId) {
            return originflowEndObj;
          } else {
            return item;
          }
        });
        const updatedMappingDiagrams1 = mapDiagram.map(item => {
          if (item.id === item.targetMapId) {
            return targetflowStartObj;
          } else {
            return item;
          }
        });
        console.log(updatedMappingDiagrams1);
        this.setState({ mappingDiagrams: updatedMappingDiagrams });
        this.setState({ mappingDiagrams: updatedMappingDiagrams1 });

        // console.log("updatedFlowLine1", updatedFlowLine1);
        // if (updatedFlowLine1bool.length === 1) {
        //   deleteActivity(targetflowStartObj)
        // }

        //  const removeActivityLoop = bpmnCanvas._elementRegistry.filter((item) => item.type === 'bpmn:StartEvent' && item.di["background-color"] === '#44bd32' && item.businessObject.$attrs?.parentActivityId === this.state.targetActivityId && item.businessObject.$attrs?.TargetActivityId === this.state.parentActivityId)
        //   console.log(removeActivityLoop);
        //   if (removeActivityLoop.length > 0) {
        //     deleteActivity(targetflowStartObj)
        //     this.closeDialogPopupBox()
        //   }
      }
    };
    fetchData();
    const pushAuditObject = {
      diagramLevel: this.state.currentMapDet.id,
      id: parentActivity.id,
      field: "Delete Flowlink",
      type: "DELETE_FLOWLINK",
      newValue: '',
      oldValue: `Targeted activity: ${item['targetMapId']}, (${item['TargetAutoNumCount']}) - ${item['TargetFullnameText']}, Source activity: ${item['originMapId']}, (${item['SourceAutoNumCount']}) - ${item['SourceFullnameText']}`
    }
    console.log("🚀 ~ BpmnEditor ~ handleDeleteFlowActivity ~ pushAuditObject:", pushAuditObject)
    this.audittrailpushingObj(pushAuditObject, "DELETE_FLOWLINK");
  }
  //delete activity for target(END)
  handleExpiredDeleteFlowActivity = (indexid, currMapId, item) => {
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    console.log(item);
    const mapDiagram = this.state.mappingDiagrams;
    console.log(indexid, currMapId);
    function findElementById(data, id) {
      for (let i = 0; i < data.length; i++) {
        const element = data[i];
        if (element.id === id) {
          return element;
        }
        if (element.children && element.children.length > 0) {
          const foundInChildren = findElementById(element.children, id);
          if (foundInChildren) {
            return foundInChildren;
          }
        }
      }
      return null;
    }
    const fetchData = async () => {
      const originflowEndObj = await findElementById(mapDiagram, currMapId);
      const targetflowStartObj = await findElementById(mapDiagram, item.targetMapId);

      console.log(originflowEndObj);
      if (originflowEndObj) {
        const updatedFlowLine = originflowEndObj?.flowlineMap.filter(el => {
          return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.targetMapId === el.targetMapId)
        });
        console.log(updatedFlowLine);
        const remainTargetConnectCheck = updatedFlowLine.filter(el => el.parentActivityId === item.parentActivityId && el.originMapId === this.state.currentMapDet.id)
        console.log(remainTargetConnectCheck);
        if (remainTargetConnectCheck.length === 0) {
          console.log("target end calling");
          console.log(this.state.editElementObj.element, this.state.editElementObj.element.businessObject.$attrs.parentActivityId)
          const findTargetActivityforEnd = await bpmnCanvas._elementRegistry.get(this.state.editElementObj.element.businessObject.$attrs.parentActivityId);
          console.log(findTargetActivityforEnd);
          const flowLineEndId = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLE_'))
          const filtermappedWithoutFLE = findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLE_'))
          findTargetActivityforEnd.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLE.join(',');
          console.log(flowLineEndId);
          const removeEndEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineEndId);
          console.log(removeEndEventonShapeImpl);
          await bpmnModeling.removeElements([removeEndEventonShapeImpl])
          // await bpmnModeling.removeElements([this.state.editElementObj.element])

          this.closeDialogPopupBox()
        };
        originflowEndObj.flowlineMap = updatedFlowLine;
        const updatedMappingDiagrams = mapDiagram.map(item => {
          if (item.id === currMapId) {
            return originflowEndObj;
          } else {
            return item;
          }
        });
        const updatedMappingDiagrams1 = mapDiagram.map(item => {
          if (item.id === item.targetMapId) {
            return targetflowStartObj;
          } else {
            return item;
          }
        });
        console.log(updatedMappingDiagrams1);
        this.setState({ mappingDiagrams: updatedMappingDiagrams });
        this.setState({ mappingDiagrams: updatedMappingDiagrams1 });
      }
    };
    fetchData();
  }
  //delete activity for source(START)
  handleExpiredDeleteStartFlowActivity = (indexid, currMapId, item) => {
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    console.log(item);
    const mapDiagram = this.state.mappingDiagrams;
    console.log(indexid, currMapId);
    function findElementById(data, id) {
      for (let i = 0; i < data.length; i++) {
        const element = data[i];
        if (element.id === id) {
          return element;
        }
        if (element.children && element.children.length > 0) {
          const foundInChildren = findElementById(element.children, id);
          if (foundInChildren) {
            return foundInChildren;
          }
        }
      }
      return null;
    }

    const fetchData = async () => {
      const originflowEndObj = await findElementById(mapDiagram, currMapId);
      // const targetflowStartObj = await findElementById(mapDiagram, item.targetMapId);
      console.log(originflowEndObj);
      // console.log({ ...targetflowStartObj })

      if (originflowEndObj) {
        const updatedFlowLine = originflowEndObj?.flowlineMap.filter(el => {
          return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.targetMapId === el.targetMapId)
        });
        console.log(updatedFlowLine);

        // const updatedFlowLine1 = { ...targetflowStartObj }?.flowlineMap.filter(el => {
        //   return !(el.parentActivityId === item.parentActivityId && el.targetActivityId === item.targetActivityId && item.originMapId === el.originMapId);
        // });
        // console.log(updatedFlowLine1, updatedFlowLine1.filter(el => el.targetActivityId === item.targetActivityId));
        const remainSourceConnectCheck = updatedFlowLine.filter(el => el.targetActivityId === item.targetActivityId && el.targetId === item.targetId

        )
        console.log(remainSourceConnectCheck);

        if (remainSourceConnectCheck.length === 0) {
          const deleteActivity = async (xml) => {
            console.log("delete activity called", xml.diagramXML)

            console.log(bpmnCanvas, bpmnModeling);
            const findTargetActivityforStart = await bpmnCanvas._elementRegistry.get(item.targetActivityId);
            console.log(findTargetActivityforStart);
            const flowLineStartId = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('FLS_'))
            const filtermappedWithoutFLS = findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids.split(',').filter(el => !el.includes('FLS_'))
            console.log(filtermappedWithoutFLS);

            findTargetActivityforStart.businessObject.$attrs.mapped_Child_Ids = filtermappedWithoutFLS.join(',');
            console.log(flowLineStartId);
            const removeStartEventonShapeImpl = await bpmnCanvas._elementRegistry.get(flowLineStartId);
            console.log(removeStartEventonShapeImpl);
            await bpmnModeling.removeElements([removeStartEventonShapeImpl])

            this.closeDialogPopupBox()
            this.setState({
              parentActivityId: '',
              targetActivityId: ''
            })
            return;
          }
          deleteActivity(originflowEndObj)
        };
        originflowEndObj.flowlineMap = updatedFlowLine;
        this.closeDialogPopupBox()

      }
    };
    fetchData();

  }
  onAddEditMapDiagramOpen = async (type) => {
    console.log(this.state.mapDiagramRecord);
    this.props.openAddEditDeleteImportMap(type, this.state.mapDiagramRecord)
  }

  handleeditAutoNumflag = (flagsym) => {
    this.setState({
      editAutoNumflag: !flagsym
    })
  };

  handlerearrangePopupflag = () => {
    this.setState({
      reArrangePopupFlag: !(this.state.reArrangePopupFlag)
    })
  }
  // based on sorting autonumber
  // handleAutomatedReArrange = async () => {

  //   //check for duplicate as weelll important 
  //   console.log("automated re arrange");
  //   this.handlerearrangePopupflag();
  //   const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get("canvas");
  //   const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get("modeling");
  //   const autoNumFinder = await bpmnCanvas._elementRegistry.filter((item) => item.id.includes("AutoNum_") && item.type === "bpmn:Group");
  //   console.log("autoNumFinder", autoNumFinder);
  //   let rearrangeArray=[];
  //   const mappingAutoNumcount = await autoNumFinder.map((el, index) => ({ 'autoNumValue': el.businessObject.categoryValueRef.value, 'Activity': el }))
  //   const sortMappingAutoNumCount = mappingAutoNumcount.sort((a, b) => a.autoNumValue.localeCompare(b.autoNumValue, undefined, { numeric: true }));
  //   console.log("mappingAutoNumcount", sortMappingAutoNumCount);
  //   let i = 0;
  //   while (i < mappingAutoNumcount.length) {
  //     let parentID=mappingAutoNumcount[i].Activity.businessObject.$attrs.parentActivityId;
  //     // element.businessObject.$attrs?.AutoNumCount
  //     const parentActivityId = bpmnCanvas._elementRegistry.get(parentID)
  //     console.log("parent",parentActivityId);

  //     let oldValue=mappingAutoNumcount[i].Activity.businessObject.categoryValueRef.value;
  //     let newValue = i + 1;
  //     bpmnModeling.updateLabel(mappingAutoNumcount[i].Activity, newValue + '');
  //     parentActivityId.businessObject.$attrs.AutoNumCount=newValue
  //     i++;
  //     let constructObjLoop = { 'newValue': newValue, 'oldValue': oldValue, 'parentActivityId': mappingAutoNumcount[i]?.Activity?.id }
  //     rearrangeArray.push(constructObjLoop)
  //   }
  //   console.log("rearrangeArray",rearrangeArray);

  //   const currentId = this.state.currentMapDet.id;
  //   const addcurrIdtoreArrange = rearrangeArray.map((el) => {
  //     return {
  //       ...el, oldValue: currentId + "." + el.oldValue, newValue: currentId + "." + el.newValue,
  //     };
  //   });

  //   console.log("addcurrIdtoreArrange",addcurrIdtoreArrange);


  //   //updating the tree structure
  //   function findElementById(data, id) {
  //     for (let i = 0; i < data.length; i++) {
  //       const element = data[i];
  //       if (element.id === id) {
  //         return element;
  //       }
  //       if (element.children && element.children.length > 0) {
  //         const foundInChildren = findElementById(element.children, id);
  //         if (foundInChildren) {
  //           return foundInChildren;
  //         }
  //       }
  //     }
  //     return null;
  //   }

  //   const currentElement = findElementById(this.state.mappingDiagrams, currentId);
  //   console.log("currentElement", currentElement);

  //   const childrenArray = Object.values(currentElement.children).map((child) => ({ ...child }));
  //   console.log(childrenArray);
  //   const rearrangedChildren = childrenArray.map((child) => {
  //     return addcurrIdtoreArrange.reduce((updatedChild, item) => {
  //       console.log(item);
  //       if (child.id.includes(item.oldValue)) {
  //         return this.updateValues([{ ...updatedChild }], item.oldValue, item.newValue)[0];
  //       }
  //       return updatedChild;
  //     }, child);
  //   }).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
  //   console.log(rearrangedChildren);

  //   function updateCurrDiagramXml(arr, parentId) {
  //     for (let i = 0; i < arr.length; i++) {
  //       if (arr[i].id === parentId) {
  //         // arr[i] = currentFlowlineLoop
  //         arr[i].children = rearrangedChildren;
  //         return arr;
  //       } else {
  //         if (arr[i].children.length === 0) {
  //           continue;
  //         }
  //         updateCurrDiagramXml(arr[i].children, parentId);
  //       }
  //     }
  //     return arr;
  //   }
  //   let mappigDig = [...this.state.mappingDiagrams];
  //   const updatedArray = updateCurrDiagramXml(mappigDig, currentId);
  //   console.log("##### ", updatedArray);
  //   SuccessMessage(BPMN_Editor_Toaster.Auto_Resequence_Completed);
  //   this.setMappingDiagramsArray("mappingDiagrams", updatedArray);
  //   console.log("updatedMappingDiagrams", updatedArray);
  // }
  handleAutomatedReArrange = async () => {
    const { mappingDiagrams } = this.state;
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get("modeling");
    console.log("re arrange clicked");
    const tempCurrDiagMapps = [...this.state.mappingDiagrams]
    console.log("tempCurrDiagMapps", tempCurrDiagMapps);
    const tempCurrMap = { ...this.state.currentMapDet };
    const currentId = this.state?.currentMapDet?.id
    let tempCurrMapId = tempCurrMap.id
    let foundChildrenById = {}
    const fetchData = async () => {
      console.log(currentId);
      const id = this.findElementById(tempCurrDiagMapps, currentId);
      foundChildrenById = { ...id }

    };
    fetchData();
    console.log(foundChildrenById);
    console.log("tempCurrMap", tempCurrMap, tempCurrMapId);
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');

    const AutoNumFinder = await bpmnCanvas._elementRegistry.filter(el => (extraActivityElements.includes(el.type) || el.type === "bpmn:Task") && !(el?.id?.includes("Actor_")) && !(el?.layer));

    console.log(AutoNumFinder, "AutoNumFinder");
    if (AutoNumFinder.length !== 0) {

      let ActivityLoop = []
      AutoNumFinder.forEach((element, index) => {
        const flowLineStartId = element.businessObject.$attrs.mapped_Child_Ids.split(',').find(el => el.includes('AutoNum_'))
        ActivityLoop.push({ x: element.x, y: element.y, activityId: element.id, autonumCount: element.businessObject.$attrs.AutoNumCount, autonumId: flowLineStartId })
      })
      // console.log(ActivityLoop);
      const sortedLoopY = ActivityLoop.sort((a, b) => {
        return a.y - b.y;
      });

      console.log("sortedLoopY", sortedLoopY);
      const finalLoopCount = []
      function sortXbyLayer(sort) {
        const initialLoop = sort.sort((a, b) => a.x - b.x).map(el => ({ autonum: el.autonumCount, activityId: el.activityId, autonumId: el.autonumId }))
        console.log(initialLoop, "initialLoop");

        initialLoop.forEach(el => finalLoopCount.push(el))
        console.log(finalLoopCount); //[1,4,2] 
      }
      let minInitialIndex = 0
      while (minInitialIndex < sortedLoopY.length) { //3 <=7

        let minValue = sortedLoopY[minInitialIndex].y;
        console.log(minValue); //286
        let maxValue = minValue + 80;
        console.log(maxValue); //372
        const sort = sortedLoopY.filter((el, index) => el.y <= maxValue && el.y >= minValue) //[286,292]
        console.log("ylayers", minInitialIndex, sort);
        minInitialIndex += sort.length;
        console.log(minInitialIndex);//0+3
        sortXbyLayer(sort)
      }
      console.log("finalLoopCount", finalLoopCount);
      let index = 0;
      let rearrangeArray = []
      for (let i = 0; i < finalLoopCount.length; i++) {
        console.log(finalLoopCount[i])
        let parentID = finalLoopCount[i]?.activityId;
        const autoNumParentActivityId = bpmnCanvas._elementRegistry.get(finalLoopCount[i].autonumId)

        const parentActivityId = bpmnCanvas._elementRegistry.get(parentID)
        console.log("parent", parentActivityId);
        let oldValue = finalLoopCount[i]?.autonum
        let newValue = index + 1;
        bpmnModeling.updateLabel(autoNumParentActivityId, newValue + '');
        parentActivityId.businessObject.$attrs.AutoNumCount = newValue
        index++;
        const fullName = parentActivityId?.businessObject.name
        const pushAuditObject = {
          diagramLevel: this.state.currentMapDet.id,
          id: parentActivityId.id,
          field: "Activity Number",
          newValue: `${this.state.currentMapDet.id}, (${newValue}) - ${fullName}`,
          oldValue: `${this.state.currentMapDet.id}, (${oldValue}) - ${fullName}`,
          type: "REARRANGE"
        }
        this.audittrailpushingObj(pushAuditObject, "REARRANGE");
        let constructObjLoop = { 'newValue': newValue, 'oldValue': oldValue, 'parentActivityId': finalLoopCount[i]?.activityId, currentMapId: this.state.currentMapDet.id }
        rearrangeArray.push(constructObjLoop)
      }
      console.log("rearrangeArray", rearrangeArray);

      const addcurrIdtoreArrange = rearrangeArray.map((el) => {
        return {
          ...el, oldValue: currentId + "." + el.oldValue, newValue: currentId + "." + el.newValue, currentMapId: el.currentMapId
        };
      });

      console.log("addcurrIdtoreArrange", addcurrIdtoreArrange);
      /*updating the comments after auto resequence*/
      const getComment = this.state.getComment
      // const copyGetComment = this.state.copyGetComment
      let currId = this.state?.currentMapDet?.id
      console.log("getComment", getComment);
      const nullGetComment = await getComment?.find(el => el.activityId !== "")
      if (getComment.length > 0 && nullGetComment !== undefined) {
        this.openSpinnerRedux()
        // const addcurrIdstoreArrange = addcurrIdtoreArrange
        const updateCommentValues = async (comment, oldValue, newValue) => {
          // console.log(`Updating comment with oldValue ${oldValue} to newValue ${newValue}`);
          // return { ...comment, currentXmlId: newValue }; // Example update
          console.log(comment);
          let newObj = { ...comment }
          const substringLength = (this.state.currentMapDet.id).split('.').length + 1
          let splitedIdArray = comment.currentXmlId.split(".")
          console.log("2", splitedIdArray);
          let substringLengthiD = splitedIdArray.slice(substringLength, splitedIdArray.length)
          console.log("3", substringLengthiD);
          let newIdValue = newValue;
          if (substringLengthiD.length > 0) {

            newIdValue = newValue + '.' + substringLengthiD.join('.');
          }
          console.log(newIdValue);
          console.log("newIdValue", newIdValue);
          newObj['currentXmlId'] = newIdValue
          console.log(newObj)
          // }
          return newObj;
          ;
        };
        const processComments = async () => {
          if (!Array.isArray(addcurrIdtoreArrange) || !Array.isArray(getComment)) {
            console.error('Invalid input arrays.');
            return;
          }

          const updatedCommentIds = new Set();
          // const commentMap = getComment.reduce((map, comment) => {
          //     map[comment.currentXmlId] = comment;
          //     return map;
          // }, {});
          // console.log("commentMap",commentMap);
          const updatedCommentsPromises = addcurrIdtoreArrange.map(async (item) => {
            const matchingComments = getComment.filter(comment =>
              comment.currentXmlId === item.oldValue || comment.currentXmlId.startsWith(item.oldValue + '.')
            );
            console.log("matchingComments", matchingComments);


            if (matchingComments.length > 0) {
              return Promise.all(matchingComments.map(async (comment) => {
                updatedCommentIds.add(comment.commentId);
                return await updateCommentValues(comment, item.oldValue, item.newValue);
              }));
            }
            return [];
          });
          const updatedComments = await Promise.all(updatedCommentsPromises);
          const flatUpdatedComments = updatedComments.flat();
          const remainingComments = getComment.filter(comment => !updatedCommentIds.has(comment.commentId));
          const finalResult = [...flatUpdatedComments, ...remainingComments];
          console.log("finalResult", finalResult);
          return finalResult;
        };
        const finalResult = await processComments();
        console.log("finalResult", finalResult);

        const matchingComments = finalResult.filter(el => addcurrIdtoreArrange.some(ele => ele.parentActivityId === el.activityId)
        );
        console.log("matchingComments", matchingComments);
        const matchcom = addcurrIdtoreArrange.filter(el => matchingComments.some(ele => ele.activityId === el.parentActivityId))
        console.log(matchcom)
        async function mappingcomments() {
          try {
            const mappingCommentss = await Promise.all(
              finalResult.map(async (el) => {
                console.log('Processing element:', el);
                const matchingComments = matchcom.find(ele => ele.parentActivityId === el.activityId && ele.currentMapId === el.currentXmlId);
                console.log('Matching comments:', matchingComments);
                if (matchingComments) {
                  return { ...el, activityNum: matchingComments.newValue.split('.').pop() };
                } else {
                  return el;
                }
              })
            );
            return mappingCommentss;
          } catch (error) {
            console.error('Error in mapping comments:', error);
          }
        }
        const mappedComments = await mappingcomments();
        console.log("mappedComments", mappedComments);
        const Url = await BPMNService.deleteExistingComment(mappedComments, this.state.userSavedData.diagramXmlId)
        if (Url.status === 200 || Url.status === 201) {
          // this.saveLatestXmlOnclick();
          const tempCurrDiagMapps = [...this.state.mappingDiagrams]
          console.log(tempCurrDiagMapps);
          const selLang = this.state.selectedLanguage;
          const reqPayload = {
            xmlData: JSON.stringify(tempCurrDiagMapps),
            languageName: selLang.label,
            languageCode: selLang.value
          };
          try {
            const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
            const data = await { ...response.data };
            console.log("****  data ", data);
            console.log("****  response.data ", response.data);
            this.setState({
              resSavedData: await response.data
            })
            if (response.status === 200 || response.status === 201) {
              console.log(data);
              let selLang = { label: data.languageName, value: data.languageCode }
              if (!(data.languageCode || data.languageName)) {
                selLang.value = "en";
                selLang.label = "English"
              }
              let parsedMappingDiagrams;
              if (data.xmlData === "" || data.xmlData === null) {
                parsedMappingDiagrams = [...this.state.mappingDiagrams]
              } else {
                parsedMappingDiagrams = JSON.parse(data.xmlData)
              }
              console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
              data.xmlData = parsedMappingDiagrams[0].diagramXML
              this.setState({
                // userSavedData: data,
                mappingDiagrams: parsedMappingDiagrams,
                selectedLanguage: selLang
              });

              // SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);    
            }
          } catch (error) {
            console.log("saveLatestXmlAPICALL", error);
            this.closeSpinnerRedux()
            ErrorMessage(error?.response?.data);
          }
          this.setState({
            getComment: Url.data,
            comment: "",
            getActivity: '',
            getActivityElementId: '',
            copyGetComment: Url.data
          })
        }


      }
      function findElementById(data, id) {
        for (let i = 0; i < data.length; i++) {
          const element = data[i];
          if (element.id === id) {
            return element;
          }
          if (element.children && element.children.length > 0) {
            const foundInChildren = findElementById(element.children, id);
            if (foundInChildren) {
              return foundInChildren;
            }
          }
        }
        return null;
      }

      const currentElement = findElementById(mappingDiagrams, currentId);
      console.log("currentElement", currentElement);

      /*updating flowlinemap after autoresequence*/
      async function updateFlowlineMap(mappingDiagram, addcurrIdtoreArrange) {
        async function updateFlowline(flowline) {
          const isMatch = (mapId, oldValue) => {
            return mapId === oldValue || mapId.startsWith(oldValue + '.');
          };

          const matchTarget = addcurrIdtoreArrange.find((item) => isMatch(flowline.targetMapId, item.oldValue));
          const matchOrigin = addcurrIdtoreArrange.find((item) => isMatch(flowline.originMapId, item.oldValue));
          console.log("matchTarget", matchTarget);
          console.log("matchOrigin", matchOrigin);
          if (matchTarget) {
            const regex = new RegExp(`^${escapeRegExp(matchTarget.oldValue)}(?!\\d)`);
            console.log(regex);

            flowline.targetMapId = flowline.targetMapId.replace(regex, matchTarget.newValue);
          }
          if (matchOrigin) {
            const regex = new RegExp(`^${escapeRegExp(matchOrigin.oldValue)}(?!\\d)`);
            flowline.originMapId = flowline.originMapId.replace(regex, matchOrigin.newValue);
          }
          return flowline;
        }
        const getCurrDiagramXmlById = async (arr) => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].flowlineMap && arr[i].flowlineMap.length > 0) {
              arr[i].flowlineMap.forEach((flowline) => {
                updateFlowline(flowline, arr[i].id, "1");
              });
            }
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children);
          }
          console.log("🚀 ~ arr:", arr);
          return arr;
        }

        return await getCurrDiagramXmlById(mappingDiagram)
      }
      function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      }

      const updatedDiagram = await updateFlowlineMap(mappingDiagrams, addcurrIdtoreArrange);
      console.log(updatedDiagram);

      //Changing the activityNumber based on the rearrange
      async function updateAutonumcount(mappingDiagram, addcurrIdtoreArrange) {
        async function updateFlowline(flowline) {
          console.log(flowline);
          const matchTarget = addcurrIdtoreArrange.find((item) => flowline.parentActivityId === item.parentActivityId && flowline.originMapId === currId);
          const matchOrigin = addcurrIdtoreArrange.find((item) => flowline.targetActivityId === item.parentActivityId && flowline.targetMapId === currId);
          console.log(matchTarget, matchOrigin);
          if (matchTarget) {
            const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.parentActivityId);
            console.log(findTargetAutoNumId);
            flowline.SourceAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
          }
          if (matchOrigin) {
            const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.targetActivityId);
            console.log(findTargetAutoNumId);
            flowline.TargetAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
          }
          return flowline;
        }
        function updateFlowlineMap(node) {
          if (node.flowlineMap && node.flowlineMap.length > 0) {
            node.flowlineMap.forEach(async (flowline) => {
              await updateFlowline(flowline);
            });
          }

          if (node.children && node.children.length > 0) {
            node.children.forEach((child) => {
              updateFlowlineMap(child);

              if (child.flowlineMap && child.flowlineMap.length > 0) {
                child.flowlineMap.forEach(async (flowline) => {
                  await updateFlowline(flowline);
                });
              }
            });
          }
        }

        mappingDiagram.forEach((rootNode) => {
          updateFlowlineMap(rootNode);
        });

        return mappingDiagram;
      }

      const updatedDiagramauto = await updateAutonumcount(mappingDiagrams, addcurrIdtoreArrange);
      console.log(updatedDiagramauto);
      // *** /

      // const getCurrDiagramXmlById = async (arr) => {
      //   for (let i = 0; i < arr.length; i++) {
      //     if (arr[i].children && arr[i].children.length > 0) {
      //       console.log("im inside thsi");

      //       arr[i].children.forEach((child) => {
      //         return addcurrIdtoreArrange.reduce((updatedChild, item) => {
      //               console.log(item);
      //               if (child.id.includes(item.oldValue)) {
      //                 return this.updateValues([{ ...updatedChild }], item.oldValue, item.newValue)[0];
      //               }
      //               return updatedChild;
      //             }, child);
      //       });
      //     }

      //     // await getCurrDiagramXmlById(arr[i].children);
      //   }
      //   console.log("🚀 ~ arr:", arr);
      //   return arr;
      // }

      const childrenArray = Object.values(currentElement.children).map((child) => ({ ...child }));
      console.log(childrenArray);
      const rearrangedChildren = childrenArray.map((child) => {
        return addcurrIdtoreArrange.reduce((updatedChild, item) => {
          console.log(item, child);
          if (child.id === item.oldValue) {
            return this.updateValues([{ ...updatedChild }], item.oldValue, item.newValue)[0];
          }
          return updatedChild;
        }, child);
      }).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
      console.log(rearrangedChildren);

      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            // arr[i] = currentFlowlineLoop
            arr[i].children = rearrangedChildren;
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      let mappigDig = [...this.state.mappingDiagrams];
      const updatedArray = updateCurrDiagramXml(mappigDig, currentId);
      console.log("##### ", updatedArray);
      SuccessMessage(BPMN_Editor_Toaster.Auto_Resequence_Completed);
      this.setMappingDiagramsArray("mappingDiagrams", updatedArray);
      console.log("updatedMappingDiagrams", updatedArray);
      this.closeSpinnerRedux()
    }
  }
  updateCommentValues(objArray, oldValue, newValue) {
    const substringLength = (this.state.currentMapDet.id).split('.').length + 1
    console.log("1", substringLength);
    console.log("objArray", objArray, oldValue, newValue);
    return objArray.map(obj => {
      console.log(obj);
      let newObj = { ...obj }
      let splitedIdArray = obj.currentXmlId.split(".")
      console.log("2", splitedIdArray);
      let substringLengthiD = splitedIdArray.slice(substringLength, splitedIdArray.length)
      console.log("3", substringLengthiD);
      let newIdValue = newValue;
      if (substringLengthiD.length > 0) {

        newIdValue = newValue + '.' + substringLengthiD.join('.');
      }
      console.log(newIdValue);
      console.log("newIdValue", newIdValue);
      newObj['currentXmlId'] = newIdValue
      console.log(newObj);

      // newObj['meta']['label'] = newIdValue + name
      // newObj['key'] = newIdValue
      // if (obj.children !== null || obj.children.length !== 0) {
      //   newObj['children'] = this.updateValues(obj['children'], oldValue, newValue);
      // }
      return newObj;
    });
  }

  handleReArrange = async () => {
    this.setState({
      editAutoNumflag: false
    })
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get("canvas");
    const autoNumFinder = await bpmnCanvas._elementRegistry.filter((item) => item.id.includes("AutoNum_") && item.type === "bpmn:Group");
    console.log(autoNumFinder);
    const mappingAutoNumcount = await autoNumFinder.map((el, index) => el.businessObject.categoryValueRef.value);
    console.log(mappingAutoNumcount);
    let setElementFinderLoop = [...new Set(mappingAutoNumcount)];
    console.log(setElementFinderLoop);
    if (setElementFinderLoop.length !== mappingAutoNumcount.length) {
      console.log("im inside");
      ErrorMessage(BPMN_Editor_Toaster.Sequence_Is_Repeated_So_Do_The_Changes_And_Retry);
      this.setState({
        editAutoNumflag: true
      })
      return
    } else {
      const { rearrangeArray, currentMapDet, mappingDiagrams, elementFinderLoop, } = this.state;
      console.log(rearrangeArray, elementFinderLoop);
      if (rearrangeArray.length === 0) {
        toast("There is no proper changes done in the resequence so please try again", {
          icon: "⚠️",
        });
        this.setState({
          editAutoNumflag: true
        });
        return;
      }
      if (elementFinderLoop && elementFinderLoop?.length > 0 && elementFinderLoop !== undefined && rearrangeArray.length !== 0) {
        let setElementFinderLoop = [...new Set(elementFinderLoop)];
        console.log(setElementFinderLoop, elementFinderLoop);
        const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get("canvas");
        rearrangeArray.forEach((el) => {
          const ActivityUpdateAutoNum = bpmnCanvas._elementRegistry.get(el.parentActivityId);
          ActivityUpdateAutoNum.businessObject.$attrs.AutoNumCount = el.newValue;
          console.log(ActivityUpdateAutoNum);
        })
        console.log(mappingDiagrams, rearrangeArray);
        const currentId = currentMapDet.id;
        console.log("currentId", currentId);
        const addcurrIdtoreArrange = rearrangeArray.map((el) => {
          return {
            ...el, oldValue: currentId + "." + el.oldValue, newValue: currentId + "." + el.newValue,
          };
        });
        console.log("addcurrIdtoreArrange", addcurrIdtoreArrange);

        //changing the commentsId based on the rearrange
        const getComment = this.state.getComment
        let currId = this.state?.currentMapDet?.id
        console.log("getComment", getComment);
        const nullGetComment = await getComment?.find(el => el.activityId !== "")
        console.log(nullGetComment);
        if (getComment.length > 0 && nullGetComment !== undefined) {
          this.openSpinnerRedux()
          const updateCommentValues = async (comment, oldValue, newValue) => {
            // console.log(`Updating comment with oldValue ${oldValue} to newValue ${newValue}`);
            // return { ...comment, currentXmlId: newValue }; // Example update
            console.log(comment);
            let newObj = { ...comment }
            const substringLength = (this.state.currentMapDet.id).split('.').length + 1
            let splitedIdArray = comment.currentXmlId.split(".")
            console.log("2", splitedIdArray);
            let substringLengthiD = splitedIdArray.slice(substringLength, splitedIdArray.length)
            console.log("3", substringLengthiD);
            let newIdValue = newValue;
            if (substringLengthiD.length > 0) {

              newIdValue = newValue + '.' + substringLengthiD.join('.');
            }
            console.log(newIdValue);
            console.log("newIdValue", newIdValue);
            newObj['currentXmlId'] = newIdValue
            console.log(newObj)
            // }
            return newObj;
            ;
          };
          //   if (!Array.isArray(addcurrIdtoreArrange)) {
          //     return;
          //   }
          //   if (!Array.isArray(getComment)) {
          //     console.error('getComment is not an array.');
          //     return;
          //   }
          //   const updatedCommentIds = new Set();
          //   const commentMap = getComment.reduce((map, comment) => {
          //     map[comment.currentXmlId] = comment;
          //     return map;
          //   }, {});
          //   const updatedComments = addcurrIdtoreArrange.map((item) => {
          //     const matchingComments = Object.values(commentMap).filter(comment =>
          //       comment.currentXmlId === item.oldValue || comment.currentXmlId.startsWith(item.oldValue + '.')
          //     );
          //     console.log(matchingComments);

          //     if (matchingComments.length > 0) {
          //       const updated = matchingComments.map(async comment => {
          //         updatedCommentIds.add(comment.commentId);
          //         return await updateCommentValues(comment, item.oldValue, item.newValue);
          //       });
          //       return updated;
          //     } else {
          //       return [];
          //     }
          //   }).flat();
          //   const remainingComments = getComment.filter(comment => !updatedCommentIds.has(comment.commentId));
          //   // console.log(rema);

          //   const finalResult = [...updatedComments, ...remainingComments];
          //   return finalResult
          // };

          // latest one 
          const processComments = async () => {
            if (!Array.isArray(addcurrIdtoreArrange) || !Array.isArray(getComment)) {
              console.error('Invalid input arrays.');
              return;
            }
            const updatedCommentIds = new Set();
            const updatedCommentsPromises = addcurrIdtoreArrange.map(async (item) => {
              const matchingComments = getComment.filter(comment =>
                comment.currentXmlId === item.oldValue || comment.currentXmlId.startsWith(item.oldValue + '.')
              );
              console.log("matchingComments", matchingComments);
              if (matchingComments.length > 0) {
                return Promise.all(matchingComments.map(async (comment) => {
                  updatedCommentIds.add(comment.commentId);
                  return await updateCommentValues(comment, item.oldValue, item.newValue);
                }));
              }
              return [];
            });
            const updatedComments = await Promise.all(updatedCommentsPromises);
            const flatUpdatedComments = updatedComments.flat();
            const remainingComments = getComment.filter(comment => !updatedCommentIds.has(comment.commentId));
            const finalResult = [...flatUpdatedComments, ...remainingComments];
            console.log("finalResult", finalResult);
            return finalResult;
          };
          const finalResult = await processComments();
          console.log("finalResult", finalResult);
          const matchingComments = finalResult.filter(el => addcurrIdtoreArrange.some(ele => ele.parentActivityId === el.activityId)
          );
          console.log("matchingComments", matchingComments);
          const matchcom = addcurrIdtoreArrange.filter(el => matchingComments.some(ele => ele.activityId === el.parentActivityId))
          console.log(matchcom)
          async function mappingcomments() {
            try {
              const mappingCommentss = await Promise.all(
                finalResult.map(async (el) => {
                  console.log('Processing element:', el);
                  const matchingComments = matchcom.find(ele => ele.parentActivityId === el.activityId && ele.currentMapId === el.currentXmlId);
                  console.log('Matching comments:', matchingComments);
                  if (matchingComments) {
                    return { ...el, activityNum: matchingComments.newValue.split('.').pop() };
                  } else {
                    return el;
                  }
                })
              );
              return mappingCommentss;
            } catch (error) {
              console.error('Error in mapping comments:', error);
            }
          }
          const mappedComments = await mappingcomments();
          console.log("mappedComments", mappedComments);

          //updating the comments after the comments
          const Url = await BPMNService.deleteExistingComment(mappedComments, this.state.userSavedData.diagramXmlId)
          if (Url.status === 200 || Url.status === 201) {
            // this.saveLatestXmlOnclick();
            const tempCurrDiagMapps = [...this.state.mappingDiagrams]
            console.log(tempCurrDiagMapps);
            const selLang = this.state.selectedLanguage;
            const reqPayload = {
              xmlData: JSON.stringify(tempCurrDiagMapps),
              languageName: selLang.label,
              languageCode: selLang.value
            };
            try {
              const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
              const data = await { ...response.data };
              console.log("****  data ", data);
              console.log("****  response.data ", response.data);
              this.setState({
                resSavedData: await response.data
              })
              if (response.status === 200 || response.status === 201) {
                console.log(data);
                let selLang = { label: data.languageName, value: data.languageCode }
                if (!(data.languageCode || data.languageName)) {
                  selLang.value = "en";
                  selLang.label = "English"
                }
                let parsedMappingDiagrams;
                if (data.xmlData === "" || data.xmlData === null) {
                  parsedMappingDiagrams = [...this.state.mappingDiagrams]
                } else {
                  parsedMappingDiagrams = JSON.parse(data.xmlData)
                }
                console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
                data.xmlData = parsedMappingDiagrams[0].diagramXML
                this.setState({
                  // userSavedData: data,
                  mappingDiagrams: parsedMappingDiagrams,
                  selectedLanguage: selLang
                });

                // SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);    
              }
            } catch (error) {
              console.log("saveLatestXmlAPICALL", error);
              this.closeSpinnerRedux()
              ErrorMessage(error?.response?.data);
            }
            this.setState({
              getComment: Url.data,
              comment: "",
              getActivity: '',
              getActivityElementId: '',
              copyGetComment: Url.data
            })
          }
        }
        //********** */
        function findElementById(data, id) {
          for (let i = 0; i < data.length; i++) {
            const element = data[i];
            if (element.id === id) {
              return element;
            }
            if (element.children && element.children.length > 0) {
              const foundInChildren = findElementById(element.children, id);
              if (foundInChildren) {
                return foundInChildren;
              }
            }
          }
          return null;
        }

        const currentElement = findElementById(mappingDiagrams, currentId);
        console.log("currentElement", currentElement);
        //Changing the flowline based on the rearrange
        async function updateFlowlineMap(mappingDiagram, addcurrIdtoreArrange) {
          async function updateFlowline(flowline, id) {
            const isMatch = (mapId, oldValue) => {
              return mapId === oldValue || mapId.startsWith(oldValue + '.');
            };
            const matchTarget = addcurrIdtoreArrange.find(item => isMatch(flowline.targetMapId, item.oldValue));
            const matchOrigin = addcurrIdtoreArrange.find(item => isMatch(flowline.originMapId, item.oldValue));

            if (matchTarget) {
              const regex = new RegExp(`^${escapeRegExp(matchTarget.oldValue)}(?!\\d)`);
              flowline.targetMapId = flowline.targetMapId.replace(regex, matchTarget.newValue);
            }

            if (matchOrigin) {
              const regex = new RegExp(`^${escapeRegExp(matchOrigin.oldValue)}(?!\\d)`);
              flowline.originMapId = flowline.originMapId.replace(regex, matchOrigin.newValue);
            }
            return flowline;
          }
          const getCurrDiagramXmlById = async (arr) => {
            for (let i = 0; i < arr.length; i++) {
              if (arr[i].flowlineMap && arr[i].flowlineMap.length > 0) {
                arr[i].flowlineMap.forEach((flowline) => {
                  updateFlowline(flowline, arr[i].id, "1");
                });
              }
              if (arr[i].children.length === 0) {
                continue;
              }
              await getCurrDiagramXmlById(arr[i].children);
            }
            console.log("🚀 ~ arr:", arr);
            return arr;
          }
          await getCurrDiagramXmlById(mappingDiagram)
          // function updateFlowlineMap(node) {
          //   if (node.flowlineMap && node.flowlineMap.length > 0) {
          //     node.flowlineMap.forEach((flowline) => {
          //       updateFlowline(flowline, node.id, "1");
          //     });
          //   }

          //   if (node.children && node.children.length > 0) {
          //     node.children.forEach((child) => {
          //       updateFlowlineMap(child);

          //       if (child.flowlineMap && child.flowlineMap.length > 0) {
          //         child.flowlineMap.forEach((flowline) => {
          //           updateFlowline(flowline, child.id, "2");
          //         });
          //       }
          //     });
          //   }
          // }

          // mappingDiagram.forEach((rootNode) => {
          //   updateFlowlineMap(rootNode);
          // });
          // return mappingDiagram;
        }
        function escapeRegExp(string) {
          return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        }

        const updatedDiagram = await updateFlowlineMap(mappingDiagrams, addcurrIdtoreArrange);
        console.log(updatedDiagram);

        //Changing the activityNumber based on the rearrange
        async function updateAutonumcount(mappingDiagram, addcurrIdtoreArrange) {
          async function updateFlowline(flowline) {
            console.log(flowline);
            const matchTarget = addcurrIdtoreArrange.find((item) => flowline.parentActivityId === item.parentActivityId && flowline.originMapId === currId);
            const matchOrigin = addcurrIdtoreArrange.find((item) => flowline.targetActivityId === item.parentActivityId && flowline.targetMapId === currId);
            console.log(matchTarget, matchOrigin);
            if (matchTarget) {
              const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.parentActivityId);
              console.log(findTargetAutoNumId);
              flowline.SourceAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
            }
            if (matchOrigin) {
              const findTargetAutoNumId = await bpmnCanvas._elementRegistry.get(flowline.targetActivityId);
              console.log(findTargetAutoNumId);
              flowline.TargetAutoNumCount = findTargetAutoNumId.businessObject.$attrs.AutoNumCount;
            }
            return flowline;
          }
          const getCurrDiagramXmlById = async (arr) => {
            for (let i = 0; i < arr.length; i++) {
              if (arr[i].flowlineMap && arr[i].flowlineMap.length > 0) {
                arr[i].flowlineMap.forEach((flowline) => {
                  updateFlowline(flowline, arr[i].id, "1");
                });
              }
              if (arr[i].children.length === 0) {
                continue;
              }
              await getCurrDiagramXmlById(arr[i].children);
            }
            console.log("🚀 ~ arr:", arr);
            return arr;
          }
          await getCurrDiagramXmlById(mappingDiagram)
        }

        const updatedDiagramauto = await updateAutonumcount(mappingDiagrams, addcurrIdtoreArrange);
        console.log(updatedDiagramauto);
        // *** /

        //updating tree structure map with old and new values
        const childrenArray = Object.values(currentElement.children).map((child) => ({ ...child }));
        console.log(childrenArray);
        const rearrangedChildren = childrenArray.map((child) => {
          return addcurrIdtoreArrange.reduce((updatedChild, item) => {
            console.log(item);
            if (child.id === (item.oldValue)) {
              return this.updateValues([{ ...updatedChild }], item.oldValue, item.newValue)[0];
            }
            return updatedChild;
          }, child);
        }).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
        console.log(rearrangedChildren);

        function updateCurrDiagramXml(arr, parentId) {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              // arr[i] = currentFlowlineLoop
              arr[i].children = rearrangedChildren;
              return arr;
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              updateCurrDiagramXml(arr[i].children, parentId);
            }
          }
          return arr;
        }
        let mappigDig = [...mappingDiagrams];
        const updatedArray = updateCurrDiagramXml(mappigDig, currentId);
        console.log("##### ", updatedArray);
        SuccessMessage(BPMN_Editor_Toaster.Resequence_Completed);
        console.log("updatedMappingDiagrams", updatedArray);
        this.setMappingDiagramsArray("mappingDiagrams", updatedArray);
        this.setState({
          filteredDataArray: [],
          lastOccurances: {},
        });
      }
      this.closeSpinnerRedux()

      this.setState({
        rearrangeArray: [],
        reArrangePopupFlag: false
      });
    }
    console.log("props.getcomment", this.state.getComment);
  };

  handleReArrangeCancel = () => {
    console.log(this.state.rearrangeArray);
    if (this.state.rearrangeArray.length > 0) {
      console.log("cancel clicked", this.state.rearrangeArray);
      let { rearrangeArray } = this.state;
      const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get("canvas");
      const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get("modeling");
      console.log(rearrangeArray);
      rearrangeArray.forEach(async (el) => {
        console.log(el);
        const parentActivityId = bpmnCanvas._elementRegistry.get(el.parentActivityId);
        console.log(parentActivityId);
        const filtermapped = parentActivityId.businessObject?.$attrs.mapped_Child_Ids.split(",").filter((el) => el.includes("AutoNum_")).toString();
        console.log(filtermapped);
        console.log(`AutoNum_${el.parentActivityId}`);
        const parentActivityIdLabel = bpmnCanvas._elementRegistry.get(filtermapped);
        console.log(parentActivityIdLabel);
        const values = parentActivityId.businessObject?.$attrs.AutoNumCount;
        console.log(values);
        await bpmnModeling.updateLabel(parentActivityIdLabel, el.oldValue + "");
      })
      this.setState({
        editAutoNumflag: false,
        rearrangeArray: [],
        lastOccurances: {},
        reArrangePopupFlag: false
      })
    }
    this.setState({
      editAutoNumflag: false,
      rearrangeArray: [],
      lastOccurances: {}
    });

  };

  handleReArrangeActivity = (filteredData, elementFinderLoop, mappingAutoNumcount = []) => {

    this.setState({
      rearrangeArray: [...filteredData],
      elementFinderLoop: [...elementFinderLoop],
      mappingAutoNumcount: [...mappingAutoNumcount]
    })
  }


  // {new one }
  updateValues(objArray, oldValue, newValue) {
    console.log("im inside");

    const substringLength = (this.state.currentMapDet.id).split('.').length + 1
    console.log("1", substringLength);
    console.log("objArray", objArray, oldValue, newValue);
    return objArray.map(obj => {
      console.log(obj);
      let newObj = { ...obj }
      let splitedIdArray = obj.id.split(".")
      console.log("2", splitedIdArray);
      let substringLengthiD = splitedIdArray.slice(substringLength, splitedIdArray.length)
      console.log("3", substringLengthiD);
      let newIdValue = newValue;
      if (substringLengthiD.length > 0) {

        newIdValue = newValue + '.' + substringLengthiD.join('.');
      }
      console.log(newIdValue);
      console.log("newIdValue", newIdValue, obj['id']);
      newObj['id'] = newIdValue
      const name = obj['name'] !== "" ? "-" + obj['name'] : "";
      newObj['meta']['label'] = newIdValue + name
      newObj['key'] = newIdValue
      if (obj.children !== null || obj.children.length !== 0) {
        newObj['children'] = this.updateValues(obj['children'], oldValue, newValue);
      }
      return newObj;
    });
  }

  onChangeRadioButton = (e) => {
    this.setState({ diagramLevel: e.target.id });
  }
  onClickBpmnDownload = () => {
    this.setState({
      isdownload: true
    })
  }

  // onChangeReviewerSelect = (e) => {
  //   this.setState({
  //     ReviewerId: e.target.value,
  //     Reviewername: e.target.options[e.target.selectedIndex].getAttribute('customId')
  //   })
  // }
  draftMapStatusChnageOnClick = async (changeStatus, msgText) => {
    if (changeStatus === 'InReview') {
      console.log(this.state.Reviewername, this.state.selectedMapData);
      if (isEmpty(this.state.Reviewername) || this.state.Reviewername === null) {
        ErrorMessage(BPMN_Editor_Toaster.Please_Select_Reviewer_Name)
        return
      }
    }
    this.openSpinnerRedux()
    try {
      console.log(this.state.userSavedData)
      const payloadData = {
        diagramXmlId: this.state.userSavedData?.diagramXmlId,
        diagramName: this.state.mapDiagramRecord?.diagramName,
        assignedUserIds: (this.state.ReviewerId),// Number(this.state.ReviewerId),
        authorUserId: this.state.authorId,
        status: changeStatus,//"InReview",
      }
      const res = await BPMNService.ReviewerPostData(payloadData, this.state.mapDiagramRecord.id)
      if (res.status === 200 || res.status === 201) {
        this.closeSpinnerRedux()
        this.props.BackToParent("checkOut", "success", msgText)
      }
    } catch (error) {
      this.closeSpinnerRedux()
      console.error(error);
      ErrorMessage(error?.response?.data)
    }
  }
  revokeToDraftAPICALL = async () => {
    try {
      const tempResSavedData = this.state.resSavedData;
      console.log(tempResSavedData);
      this.openSpinnerRedux()
      const tempMappDiags = JSON.parse(tempResSavedData.xmlData);
      let xmlResult = cloneDeep(tempMappDiags);
      console.log(tempMappDiags);
      let exportResult = await this.excludeDocumentIds(xmlResult)
      // let exportResult = await this.excludeDocumentIds(xmlResult)
      const reqPayload = { xmlData: JSON.stringify(exportResult) };
      const tempMapData = this.state.selectedMapData
      console.log(tempMapData);
      const response = await BPMNService.revokeToDraftAPICALL(reqPayload, tempMapData.id, this.state.userSavedData.diagramXmlId)
      console.log(response);
      await response.data;
      if (response.status === 200 || response.status === 201) {
        this.props.setMapLevelOptionsByChild()
        this.closeSpinnerRedux()
        // SuccessMessage("Map revoked successfully")
        this.props.BackToParent("checkOut", "success", "Map revoked successfully")
      }
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
      ErrorMessage(error.response?.data)
    }
  }
  deleteRevokedDraftAPICALL = async () => {
    try {
      this.openSpinnerRedux()
      const tempMapData = this.state.selectedMapData
      console.log(tempMapData);
      const response = await BPMNService.deleteRevokedDraftAPICALL(tempMapData.id)
      console.log(response);
      // const resData = await response.data;
      if (response.status === 200 || response.status === 201) {
        // this.props.setMapLevelOptionsByChild()
        this.closeSpinnerRedux()
        // SuccessMessage("Map revoked successfully")
        this.props.BackToParent("checkOut", "success", "Revoked draft deleted successfully")
      }
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
      ErrorMessage(error.response.data)
    }
  }
  headerSecondaryBtnOnClick = async (btnLabel) => {
    console.log(btnLabel);
    if (this.state.copyGetComment.length > 0) {
      const tempCurrDiagMapps = [...this.state.mappingDiagrams]
      console.log(tempCurrDiagMapps);
      const selLang = this.state.selectedLanguage;
      const reqPayload = {
        xmlData: JSON.stringify(tempCurrDiagMapps),
        languageName: selLang.label,
        languageCode: selLang.value
      };
      try {
        const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
        const data = await { ...response.data };
        console.log("****  data ", data);
        console.log("****  response.data ", response.data);
        this.setState({
          resSavedData: await response.data
        })
        if (response.status === 200 || response.status === 201) {
          console.log(data);
          let selLang = { label: data.languageName, value: data.languageCode }
          if (!(data.languageCode || data.languageName)) {
            selLang.value = "en";
            selLang.label = "English"
          }
          let parsedMappingDiagrams;
          if (data.xmlData === "" || data.xmlData === null) {
            parsedMappingDiagrams = [...this.state.mappingDiagrams]
          } else {
            parsedMappingDiagrams = JSON.parse(data.xmlData)
          }
          console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
          data.xmlData = parsedMappingDiagrams[0].diagramXML
          this.setState({
            // userSavedData: data,
            mappingDiagrams: parsedMappingDiagrams,
            selectedLanguage: selLang
          });

          // SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);    
        }
      } catch (error) {
        console.log("saveLatestXmlAPICALL", error);
        ErrorMessage(error?.response?.data);
      }
      this.setState({
        copyGetComment: []

      })

    }
    let comments = this.state.getComment;
    console.log(comments);

    if (btnLabel !== 'cancel') {
      const isMapEmpty = await this.checkMapDiagramIsEmpty();
      console.log(isMapEmpty, 'ismapEmpty');
      if (isMapEmpty) {
        ErrorMessage("Please create a diagram to proceed");
        return;
      }
      if (btnLabel === 'Revert to Editor') {
        if (this.state.copyGetComment.length > 0) {
          const tempCurrDiagMapps = [...this.state.mappingDiagrams]
          console.log(tempCurrDiagMapps);
          const selLang = this.state.selectedLanguage;
          const reqPayload = {
            xmlData: JSON.stringify(tempCurrDiagMapps),
            languageName: selLang.label,
            languageCode: selLang.value
          };
          try {
            const response = await BPMNService.saveLatestXmlAPICALL(reqPayload, this.state.userSavedData.diagramXmlId);
            const data = await { ...response.data };
            console.log("****  data ", data);
            console.log("****  response.data ", response.data);
            this.setState({
              resSavedData: await response.data
            })
            if (response.status === 200 || response.status === 201) {
              console.log(data);
              let selLang = { label: data.languageName, value: data.languageCode }
              if (!(data.languageCode || data.languageName)) {
                selLang.value = "en";
                selLang.label = "English"
              }
              let parsedMappingDiagrams;
              if (data.xmlData === "" || data.xmlData === null) {
                parsedMappingDiagrams = [...this.state.mappingDiagrams]
              } else {
                parsedMappingDiagrams = JSON.parse(data.xmlData)
              }
              console.log("parsedMappingDiagrams ", parsedMappingDiagrams);
              data.xmlData = parsedMappingDiagrams[0].diagramXML
              this.setState({
                // userSavedData: data,
                mappingDiagrams: parsedMappingDiagrams,
                selectedLanguage: selLang
              });

              // SuccessMessage(BPMN_Editor_Toaster.Map_Saved_Successfully);    
            }
          } catch (error) {
            console.log("saveLatestXmlAPICALL", error);
            ErrorMessage(error?.response?.data);
          }
          this.setState({
            copyGetComment: []

          })

        }
        async function handleComments() {
          const findRoleforComments = comments.filter(el => el.role === 'Reviewer');
          return findRoleforComments
        }
        const findRoleforComments = await handleComments()
        console.log(findRoleforComments);

        if (isEmpty(this.state.getComment) || findRoleforComments.length === 0) {
          ErrorMessage(BPMN_Editor_Toaster.Please_Add_Comments_Before_Revert_To_Editor)
          return
        }

      }
      const isBothXMLSame = await this.getIsUnSavedXMLExist();
      console.log("isBothXmlSame", isBothXMLSame, this.state.copyGetComment);
      if (!isBothXMLSame && this.state.copyGetComment.length === 0) {
        if (!window.confirm("There are some changes are you sure you want to proceed without changes"))
          return;
      }
    }
    switch (btnLabel) {
      case 'Cancel':
        console.log("cancel clickec");

        this.handleReArrangeCancel();
        break;
      case 'Send to Reviewer':
        const projectId = this.state.mapDiagramRecord.project.id;

        const res = await BPMNService.getUsersByRoleNameAPICALL('Reviewer/', projectId);
        const reviewerDatas = await res.data;
        this.setState({
          ReviewerData: reviewerDatas,
          isSendToReviewer: true
        })
        break;
      case 'Revert to Editor':
        console.log(this.state.getComment)
        this.setState({
          FromReviewsentback: true
        })
        break;
      case 'Publish':
        this.setState({
          isPublishPopupEnable: true,
        })
        break;
      case 'Send to Publish':
        async function handleComments() {

          const findRoleforComments = comments.filter(el => el.role === 'Reviewer');
          return findRoleforComments
        }
        const findRoleforComments = await handleComments()
        console.log(findRoleforComments);
        if (isEmpty(this.state.getComment) || (findRoleforComments.length === 0)) {
          ErrorMessage(BPMN_Editor_Toaster.Please_Add_Comments_Before_Approve_The_Map)
        } else {
          this.setState({
            FromDiagramApprove: true
          })
        }
        break;
      default:
        break;
    }

  }
  headerPrimaryBtnOnClick = async (btnLabel) => {
    switch (btnLabel) {
      case 'Re-arrange':
        await this.handleReArrange()
        break;
      case 'Save Changes':
        await this.saveLatestXmlOnclick();
        break;
      case 'Revert to Editor':
        this.headerSecondaryBtnOnClick('Revert to Editor');
        break;
      default:
        console.log("default switch")
        break;
    }
  }
  onChangeComments = (e) => {
    this.setState({
      comment: e?.target?.value
    })
  }
  onCommentPostClick = async (digLevel = {}) => {
    const comments = this.state.comment
    try {
      const requesPayload = {
        commentMessage: comments,
        commentedUserId: window.localStorage.getItem("userid"),
        mapDiagramStatus: "InReview",
        activityId: digLevel?.activityId,
        activityNum: digLevel?.autoNum,
        flagToggleActivity: false,
        // currentXmlId: this.state.currentMapDet.id,
        // role: window.localStorage.getItem("userRole"),
        // userName: window.localStorage.getItem("userName")
      }
      console.log(requesPayload);
      this.setState({
        comment: "",
      })
      const Url = await BPMNService.postComments([requesPayload], this.state.userSavedData.diagramXmlId, this.state.currentMapDet.id)
      if (Url.status === 200 || Url.status === 201) {
        this.setState({
          getComment: Url.data,
          comment: "",
          getActivity: '',
          getActivityElementId: ''
        })

      }
      let selectionService = await this.handleBpmnRef.current.bpmnModeler.get("selection");
      let element = this.handleBpmnRef.current.bpmnModeler.get('selection')._selectedElements[0];
      selectionService.deselect(element);
    }
    catch (error) {
      console.error(error);
      ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
    }
  }
  markAsCommentRead = async (CommentsReaderId, userId) => {
    const Response = await BPMNService.postCommentsMarkAsRead(CommentsReaderId, userId)
    if (Response.status === 200 || Response.status === 201) {
      // this.setState({
      //   getComment: Res.data
      // })
      console.log("markAsCommentRead:", Response.data)
    }
  }
  onOpenComment = async () => {
    this.setState({
      isCommentOpened: true
    })
    const commentsReceivedFlag = this.state.CommentsReaderStorage.length > 0
    console.log("commentsReceivedFlag", commentsReceivedFlag);
    if (commentsReceivedFlag) {
      this.setState({
        CommentsReaderStorage: []
      })
      this.markAsCommentRead(this.state.CommentsReaderId, userid)
    }
  }
  deleteAllComments = async () => {
    console.log(this.state.getComment);

    const removeCommentsforUserIds = this.state.getComment.find(el => el.commentedUserId + '' === userid)
    console.log("🚀 ~ deleteAllComments ~ removeCommentsforUserIds:", removeCommentsforUserIds)
    if (removeCommentsforUserIds && removeCommentsforUserIds !== undefined) {
      const res = await BPMNService.deleteAllComments(this.state.userSavedData.diagramXmlId, userid)
      try {
        if (res.status === 200 || res.status === 201) {
          const removeCommentsforUserId = this.state.getComment.filter(el => el.commentedUserId + '' !== userid)
          console.log("🚀 ~ deleteAllComments ~ removeCommentsforUserId:", removeCommentsforUserId)
          this.setState({
            getComment: removeCommentsforUserId
          })
          SuccessMessage(`Comments added by the ${this.state.userName} has been deleted successfully`)
          return;
        }
      } catch (error) {
        console.error(error);
      }
    }
    else {
      ErrorMessage('Add the comments and try to delete')
    }


  }

  openCreateEditTemplate = (type, data) => {
    if ((this.state.userRole === "Editor" || this.state.userRole === "Admin")) {
      if (type === "ADD") {
        const templateRecord = {
          templateName: "",
          companyName: "",
          companyLogo: "",
          colorCode: "",
          navHomeIcon: "1",
          navUpIcon: "1",
          navPreviousIcon: "1",
          iconSource: "default"
        }
        this.setState({
          createTemplateState: true,
          newTemplateRecord: templateRecord
        })
      }
    } else {
      ErrorMessage("Templates can be created by either Editor or Admin")
    }
  }

  templatehandleOnChange = async (e, icon) => {
    let value = "";
    let name = "";
    let parsedtemplatedata;
    console.log(e.target?.name, icon);
    parsedtemplatedata = { ...this.state.newTemplateRecord }
    if (e.target.type === "text") {
      name = e.target.name;
      value = e.target.value;
    } else if (e.target.type === "file") {
      const currFile = e.target.files[0];
      const customErrorMessage = e.target.name === "companyLogo" ? "Accepts only image file!" : null;
      const isImageValid = await validateFileOnChange(e, customErrorMessage);
      if (!isImageValid) {
        console.log("not a valid file");
        return;
      }
      name = e.target.name;
      value = e.target.value;
      const tempImgContent = await convertFileToBase64(currFile);
      if (e.target.name === "companyLogo") {
        value = {
          imgname: currFile.name,
          imgcontent: tempImgContent
        }
      } else {
        console.log("else");
        value = tempImgContent
        parsedtemplatedata["iconSource"] = "userDefined"
      }

    } else if (e.target.type === "color") {
      name = e.target.name;
      value = e.target.value;

    } else if (e.target.type === "checkbox") {
      if (e.target.name === "navIcons") {

        value = e.target.checked;
        if (value) {
          parsedtemplatedata["navHomeIcon"] = icon.id
          parsedtemplatedata["navUpIcon"] = icon.id
          parsedtemplatedata["navPreviousIcon"] = icon.id
        } else {
          parsedtemplatedata["navHomeIcon"] = "1";
          parsedtemplatedata["navUpIcon"] = "1";
          parsedtemplatedata["navPreviousIcon"] = "1";
        }
        parsedtemplatedata["iconSource"] = 'default'
      }
      this.setState({
        newTemplateRecord: parsedtemplatedata
      })
      return
    }
    parsedtemplatedata[name] = value;
    console.log(name, value);
    this.setState({
      newTemplateRecord: parsedtemplatedata
    })
  }
  isBase64(str) {
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const base64Regex = /^(?:[A-Za-z0-9+\\/]{4})*?(?:[A-Za-z0-9+\\/]{2}==|[A-Za-z0-9+\\/]{3}=)?$/;
    console.log("🚀 ~ base64Regex:", base64Regex.test(str));
    return base64Regex.test(str);
  }
  validateTemplateForm = (e) => {
    console.log(this.state.newTemplateRecord.navHomeIcon);
    const validateData = {
      templateName: this.state.newTemplateRecord.templateName,
      companyName: this.state.newTemplateRecord.companyName,
      companyLogo: this.state.newTemplateRecord.companyLogo,
      colorCode: this.state.newTemplateRecord.colorCode,

    }
    // navHomeIcon: this.state.newTemplateRecord.iconSource === "userDefined"
    // const isValid = Object.values(validateData).every(value => value !== "" && value !== null && value !== undefined)
    // return isValid
    const isValid = Object.values(validateData).every(value => value !== "" && value !== null && value !== undefined);
    if (this.state.newTemplateRecord.iconSource === "default") {
      return isValid;
    } else if (this.state.newTemplateRecord.iconSource === "userDefined") {
      const { navHomeIcon, navPreviousIcon, navUpIcon } = this.state.newTemplateRecord;
      const icons = [navHomeIcon, navPreviousIcon, navUpIcon];
      const allIconsValid = icons.every(icon => icon && icon?.includes("base64"));
      return isValid && allIconsValid;
    }
    else {
      return isValid;
    }

  };

  createTemplateOnClick = async (e) => {
    e.preventDefault();
    const isValid = this.validateTemplateForm();
    if (isValid) {
      console.log("isValid", isValid);
      const tempFormData = this.state.newTemplateRecord
      // console.log("🚀 ~ tempFormData:", tempFormData);
      const payload = {
        templateName: tempFormData.templateName,
        companyName: tempFormData.companyName,
        companyLogo: tempFormData.companyLogo,
        colorCode: tempFormData.colorCode,
        navHomeIcon: tempFormData.navHomeIcon,
        navUpIcon: tempFormData.navUpIcon,
        navPreviousIcon: tempFormData.navPreviousIcon,
        iconSource: tempFormData.iconSource,
        navUpImg: tempFormData.iconSource === "userDefined" ? tempFormData.navUpIcon : "",
        navPreviousImg: tempFormData.iconSource === "userDefined" ? tempFormData.navPreviousIcon : "",
        navHomeImg: tempFormData.iconSource === "userDefined" ? tempFormData.navHomeIcon : "",
      }
      console.log(payload);
      try {
        console.log(tempFormData);
        console.log(payload);
        const response = await BPMNService.createTemplateAPICALL(payload);
        // const data = await response.data;
        const status = response.status
        if (status === 200 || status === 201) {
          // this.setState({
          //   createTemplateState: false
          // })
          this.closeDialogPopupBox();
          SuccessMessage("Template created successfully!");
        }
      } catch (error) {
        console.error("setTemplateCreation", error,);
        ErrorMessage(`${error?.response.data}`)
      }
    } else {
      ErrorMessage(BPMN_Editor_Toaster.Please_Enter_All_Data);
    }

  }
  setTemplateBgColor = async (templateData, type) => {

    const loginUserRole = localStorage.getItem('userRole');
    console.log("loginUserRole ", loginUserRole)
    if ((loginUserRole === "Editor" || loginUserRole === "Admin") && this.props.selectedMapType.mapLevel === "Draft" && (this.props.selectedMapData?.diagramXmlIds?.Draft?.status === 'InProgress')) {
      console.log(templateData);
      // const templateBg = this.state.templateBgColor === 'from-[#AAACF7]' ? 'from-[#fff]' : templateData;
      // const templateEnabled = !(this.state.isDefaultTemplateEnable)
      // const temp = {
      //   templateBgColor: templateBg,
      //   isDefaultTemplateEnable: templateEnabled
      // };
      let templatePayload = {
        "diagramXmlId": this.state.userSavedData.diagramXmlId,
        "template": null
      };
      let isDefaultTemplateEnable;
      if (type === 'HEADERCLICK') {
        isDefaultTemplateEnable = false

        templateData = {
          "id": null,
          "templateName": "",
          "companyName": "",
          "companyLogo": {
            "imgname": "ismile.png",
            "imgcontent": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4nO19eZxdVZXut/YdakxVpUgqAyGBJIQAgZAQIISAgIgIdBQFEWnaHqS1UbRFGx5KP1pRkbbRRujGJ+LYIhgaRIaWQSAhzJlIQhIyQKikkkoNqXm49569Vv+xh3NupUKGOnWreNbiR6rqDuecvdfaa/z22sAIjdAIjdAIjdAIjdAIjdAI/XkRxX1BXnfnqbrlrWuleY2/hQgDApBEbilifwggBICgBBAIIADYvo/wfUif70VJxF6ZICIg/zl7FfvTf5wFKvI+gfx3o98z94xcQwAlFH7G39c/GgDqc393z+hEiX8cEpg5cp8DoPpcUwRAIo3UqZ9CctoZdyamnPoaYqDYBEBkt5Jty+/Vb/7oUuhsOTQbnkWYZoZmX4xMKtm3BGKFBH7uHQMk+qIYYRA3+RS5pr0X5TEz5AJFr5fHHeR/lgEndOKvKZbhKvycff58QaPIcyDvGv5eke/vdW8AJAJxQu/mDQASRVCTZnWmjj3v5NTJn9rULzMOgpIDvYAjXnffidj50gIJesqh0sDoGSClACE/cYYIAjGr3TJQiKyGiE4SRYTBTqZnsn0ZsOvWXEuA8DvI/27+dcV/B3bt99Uo0RXsrhm9NkmEKfa9PAEOpdYKidNk7rFCzQGvUSI3YAFROFYAkO4WoHkH+J0V5Tpd8R0Al2GAFJsA6PqXp1OufQZUMahq2g941NG/IaWgKAGALSPIK9uo6gxVaGQFsPK/+8li2bfKcp9xK5JCwYiwyWqPyOp07ziGR67X9zPvdX/Juz9BKF8jRe7Uh/mAsgp/bwHI12K8522gZPQK3rEG0lZ/XrDhmfOSx573zL6m5EAoNgFA124ADJQfCVTPerlo1hdWxnbtEfKUeemX3di+phQcVEnH7qqBXk/t/yMHRnT4OadDFACCUsVxXXaE+lKmazULIEJg7qtdDp5iEwAkikqjfs0IDQ4JrHMIIA4fPj4BCDLdzgaOiMAgEuvevf2KQ6f4TADrwDlgsScXRsgTsQSAy58M/HrxaQCVSgOwDxXfZUconwTC0eTUQCk2TknQ2y3oE0qNUPyU7d1jfqFhpgE8jbB/sMm7gDScnEAAEJMK3StPP0KxEbmkakzzHLMAuH9GBGDQqN/s4qFTfJlAhIWP4ewCBrtXHUe9DR+XhjcgXQ2QbIeZ0OIxUKXjocbNAcomPKQOm75+qJ/1PUkkFkGITwCSJRUMgQKB9//pgpF++5FiqX2qnCZ98HHseA65l79erVKV0znbCRXkwMymNEu1EEpCb38J0tv+md5nb9qTmHjy87xrzfcTE+a2J2f+RXaoxwJEnf94NG18AkAJv/CHgwEIOmrHU92zZ/HO5y6hTMun9OofggVIMIN7OgEwRFs7yrb8KoBIMwQ0XW15BsHmp06lcSddn+to+E/9xgMPJGZfvnSox5VXZYwh4RKfAASZbkQclKEmeesXv5XWzQukbXtaREBsapHMCoCAHCAjUs8na1+J2Q+Bd70BQuKabGfjotyLd76UOuPay4dsUJbCOuXAjW185lrnsm4Ch1IAgnV33hQ8d3WH7HjubG57N03CENFgCIRNJh0sEFZgsbgEU10xZVr7OxgQJmMedA7ctG1SbtV9n+x5+EtvBWsf+tshG2AUYzD88gAUk1wePEnPrmp++YYvyc4lt+jWt8qVNuAMFlj4lUCxgLT528DUyMC03GfYgjbEwcrMm2IBHaID8LZXZwRrH7635/nv/+UQDBMA8rAEA6UYeUUKIhH1VDiSljdr9LYnXuXmdbdJVyOIAQ0NCINYW0YTRBQEbHw+BhQLhBlgDqFiIhAGhAFmApisNhBAC8Aaeud6yFtL/qP7/r8fEiFwuRaJQQLiE4BUaYVTS1RAAQjaN03n5tX/w5vvm865jmJiWDtuJ0nI2ne2zEYes90zSwRniCiI1YVbUdiWCKRtV4U0bft1z++uvaBgg0X47ASAh5UA5Hq7AZenKKATsOFXc/ntR+YKB6GDbIVARIHErHRox2ACsYWoibKfC2Fi5rsW1SvWX3DOoUMbO7+hoxHSWvfzzBPfPqtwA3b4wniYF18xKFlcGpYoCyMAvP5nc6Vt0wPo2g3SlinMAIzzRtbWM5IGSCEAWEOgwMLeD3AOoGjj/CHiF/iohq1psAqChMFC0A3vjNftDUuCxi1zCzJoAKGmHTjFpwE8zwuj/oOWDXO5a/ti6d7tbaLLk4toz1hKlINKxvxUVU4FCRnAprX5xBZhE0Ebexh7lPlO7dvvkAiYyWsD3rwMwapHbizEuCUPCz1wilEA4ilPHijRpvvOloYVU92KVZZpxAJhgvHtBIIUqHT8k2rahaeo6Rc8hJKxICRBTGCwcfIkuvId8ykSHZjXlVUBTjCI2fsWetMLF3Y/dceFgz7wZHGFg8DHwb7YEkFEAqt8C0Kcbb1dMm2GWWC/kUOEQQyAyWP1BYL08Z9eDuATua3P3Kprn/8Y3n11JmXaIMwQ6ycYE4Ewl+GdRPMZzQTlNA3ERpfKCF3Tu6UoXnElgCcGc9xikVdxUawhO1l1Otg+oN68+BZpWmu8eliGI/TqRSLPYdW2o9S0825MHfeJS9S0D9+oxs9rF5UCcbjaBeydQpcjYJsvcILgsoYkymgeAUQzuHH7p3ufvrt0UAfPQbffaJO31+zQKD4n0KlRYFAFgBtWTtbvPnEescviOebBO2pgCu26y+xFKDFuzsb0mV/7XtFH/7Myffxl96vqo2qZEsZn0GZFg63H751JGDPnTIKG0R5sGaEF0tEC3rP9l4M3ekN+ODFU3eJMBCG6J26wiJtWn0rM80W0wcX7VRnacecQhip839dLnfmPVySOu/hKNeaYu1A+ARCJyAxZixAVJoS+jsAIG8OElCyQxm2n5rYuP3XQJsA+V1zTHGsUUJBC0J51M9G5zThvka1eLnvnEjWhM7f/fFlqzlXLEpNP+2pyxnlHJKaeuUmVjwUxwJqt40cgplALiNiQE5HowTiI3N40OXjtocmDNXxJFVW5PY1xUKyAkEKQlE28RYLXrMNGEWaTZz7ZRE1eJm8/lD7jmiyAHbrlnY8GG576ONe/9R1sfRmczUCJgBFeT/rkCgBYARFIWzOku33qoE1AzG52zE7g4JM0rke449jYYNE25odL64aqmiTcYHkglBh91MaiBZ/7rpp25pz0GZ/9nRo1bo8kUlDahJfCztmNaDxbZSQBEGSAipp/GpzRA8qbH46lFhC7BhAMbjVQOmrh6vu+XGtTtGJXfn6e/8A0QF8qmn3JagCX59Y+Pjd486nPcXPt31PjNjDDRg2musjWASXnlAtBmuvGxD3ukNzGMInF3MboA4SMGCxHMGjb/DXK9ZoKH5NP+/oGDX7VCyjaRGIAj5M64aKVJZ+643OJKXM/SjMWvgRK2mtS6Hi6WoIVBmmqi2O4+ySDvRxumUCEadTB8gOpZ89pZtIVBNokRdkCPZzDJ+J9gfD1gd+7+OJ//gNNmHFmas5fnJOYdlotFZVZDRTJGdiohDtaBn7DfZAIhf5NDBRfJhDwIcpgEWc6vbPnVqBEU9De8aOIlx5fyFR6zrUM4Pls87arcg/dugRvvQKTKYLPQ0AIurcnnhv2Q271R/cID4RiEwBR6fLBjgEV2KB4XTaO4fMAYbLG+QE2VIrxkXKvLp6Y3frahdlfXHeDNO+wvohFFlknlIWQjCFDt0+KpILjGFp8GoAznXFda5+UqrTeNoXM9swPy7ouLHTaII6Z6nnmruty65d8hre8eiJnsiBhKDYMJ5stZNvXSNKDlw3mrrYdoaYduA6IPw8wiJlAKR79pLBcaibeoX6AaN+f0ClzDuChe8u6bn2a92w/K7dh6Y28/LFzdUs9oNnkBXyUEZqkhNjnKq2Ma8j7JhmOeAA314MkBMnqo3+KRCm0vRf7okh/gA6bCeynFnAglFn75IX6rWXP9T7xw6f1ikfP5T27ANbW5JABoAiBNINYQUBGKFigxk6Je+h9yHY5i+FKg6MBBlELqPKJ4OYtVr0ry5Aw8SM2DHT5AIehOxjKPv79z+deeeB22bG+VDI9JsDnhE0JOzOjQKzBIEAYJMprnUTNUYMwckMO2RQX7C4+J9Cp3LguuC8ac9weatpcbaqA2tt+h/kDcx7jhSWvHLwv6n31vmqs+9NUpsTjmdcXVyCTLTaoYgJEgZmhALDFESoxzA+RSGyyhJRC9s2Xrh7kWYiNYuwQkoy0BhtEMejt+KFQyisZcSVgm4MIYWGRJNB+Fktu7eOXBqueuFu37Hpdb32tBplMMZjtdcPun8LhxhEHGSfnczBBMUBVNUhMPbF1sIZPYlrqxpQIjNEEqFRxWCodvGQwlY1ZQ2U1vWjZUSyATcOGRaEwFLRPsQ8nMKhbWxyseaIC6bJHM3/68XRp2VUtQQbCygI/yAsV2OIHOfzbvScCQIdbzYT1K+lZC18ZtAmA9T1MNWTAFDModPDLQenTv/oHyeUeMxNvsYDe4UNEE4jFC+yNUcg1v3N28MYfbufGd3bnnr/nVGnaXk1BDg7eBY60rtWUDxPzv5v/SVufw9rm1Ikf3JGa9+EdgzYBzvuPydzGuFQjBZlBTgilTrnapERBCDd0IG/FhubAJoQsdT3+rfnZP/3o17m1T16jt7xsH12MMEXxA/Y6YVo5cn13L5f9YwCsgNJKqJmn3z6YY6dUujxsVD3weY41CnC2crBJjZ5yZeLweZdy7euABXWGzLfev0X9GuyeRubRb57NmbYbg5WPnA3NaWGBYgMRhwBCBNamFXx+jiHC/KhGiYSbRsYUUieft674lHMHVf2DVBKAXQADp5iNtdh20IPbIkKNm51Vh8/5Lyqu7Gflm+dgWGEIstCtjZ/RO9c9pzc8fz4FnAYbiLfD2JMo4+AhEjp6jKE1B3sxX3zEAQFo4tFAzRHfHNSB59EwCwPzn6cA0JCe1i+o8vFjdFfLBWEbeeuISbj5Q3o7gUz3xaw5LBax/YwgXOns+gSwdyLNuMTvExAJdxyFwkAglURqyvG/Sh5/+lODP3BXd4hHAGJHBFFMOer9Ufqsr7Unzv7q4kTVkXaFwm/dCquCNkwMtMnXO8aK2+Xj7Dt7BDCYAI18G2+ZrWz+38gZW/OfQGL2B4LSq7/9mfRRJ7QP+sCjFIMMxI4HKOTG0OTEk35G4479LkqqI3kBNhU6XxMgjxEUjT7Mh4V42dctwsibFX+sS6j2HfgTWqBYQU06GslTPvS9gg0a0Y4mw61PoKMCCkHxhbd8Q0084QZKl8Hl6VmSkUSQTd1a/8Cnin3kEPHyXazvVj6Qpwk4kvQRUVCHHY70xX99Q/EZi/65YAO2j6xAw2x3MABXF4/LQTlQKrnkB/+aqDnmJ1RUZbqAQANw9j3KfLfZA36FO+0QIoxdAojC3+3nSUI/IlFzJNJnXfKTktMX/WtBB2tGFlvJJT4nMNPe4FEqheU/AIBGjf9KYsIJgV7z2DXS0Riqch3i9SiiBQwjyReNDLIXcM0hvJOnJQz1hECUBspH1ZZc+U+PIacHDf1bKIpPANIVNYCE++wKTOlFt3QD+EL2lV+251Y//jHZtXmm0dmWnH/izQAQ9hIg7/YLu/eijGeAk0AyjeQJCzcqJC5LnXTOusKPMqLFhmMUMBSM70vp+Z+5UU2Zd0nqzL9ppbLqLJAALIAELjy0hR6TK9A2+6cidQU7FIaxtKoIauyk1uSMk25InHbBJSVf/vchYb4jL8AxUKx5gH3UXQpOJR+5fiOA0Xr76i/1/vGuD1FXy0I01FaJzvgNpeRNgPLJHYHrM2CrfKWjQFXjaxPjpy0r/cLtV5qr/3wIR+Z2JSO2iY4XENJP4WUoKXHEST/Ktdb9Qq9fshBvrzqDSqu+FGxZUY7GbUAma715A+oE2ISGJRVQ46eBxk9+Td7deEfq/M/WFp1+0bKhHkseucU2rJxAIDaYUpyUqjq8HcATurH2KV238Ta9e7vCnjoUffHux9HeCN3VDqUUUFYJ6em6NffIXcvosImgOedky/761m7c/PBQDyGPHONVTGDXGAXAPFlctiluSoydHAAIM3XfO+2MfX/6eQDfH+xHOiSidFE1xPUIHPhkx35gRGFbRP4ZUqrIHhYZT9E91iZRhWwQ+edKIuR5NswAIY5GhGBQqaej1v06rLaGmQLFMHUA+hA3vHoSb3t6PBrXIuioA2kFVTENGDcHOPqi+tToaauH+hn3RaR1Ns54O8Y8gOT/HKYUvP4vd+qN/3WBdLdMp55WQAMsDOqsh+gVkNbtW3Kv3/PH1ClXXzvUz9ovJVN+39mwCgMl09Hg0TT60K4RrLh/Enc1zaPiihv17k1jkO2ElB4GNXYagjceuyh9yqdaUycuqj+Ua+s3fvBZNK+5Mdj5ylRkO01XL00W0cvgTAukYw+E35ouyVVfzDzxfy5UR551a+q4C396KPfLLfvdzMxTP0Vy4aWP693vAD3dUOVVoMMOX5Zb9dStpR/7Wmdi5vyDBo+KSqbFFapioPg0QFFFDYBDVk2ZF3/8tWDrC1fpurUnSm+HKyuBhBEIQKPGbQjWPPFSz7M/uLXk3OseO9DrSm9dqSy/fRHvfPEe7mkCNNu277A/I3/blvCSbUOw6U9TVevOe7LP/KA+fd6B30/vfmdG8PJDi4KNL32fezuQ/cMdFrwqMPAzTKWqsX+Vfe2xNZlli28rWnjZfQc1UVb7xxVvxegDSOS8gAOn7GPfSEq69OZg7RM3UfsOW78xqHcSAbtjqDrqodsbFlDbjnt7n/6329InXXaXGjtlvwc5Ba9/91x01d/NPQ2W6QYswoHdMaTFQ8rF/u3AI1z3JiSHezNL7rqq6ANf3C/cK7vykXRu+WP/nVv99Cxp3m6ZZbKjCaGwk+qe3ci+9tiJia2r786+/tixYPpm+rSLggOeNIdzGE6nh0uiuML8cnAiwNnMbcGGZ2+i1u1mt43f2WEmz4A3CIKEiXyb62r0iodv11tfvG1/187VPjofvXsele7dVcTkV7oEAndCiGj7fyBAENlgqjVIM3jH2hpu2Prkfsex4ZVJeufWJZk/3jOLm7ZbP801pyBohHsHhBQQBNC736nIPPrjm6Sjeb9jiZJLtg2/MPAgl3+w+flr9K43r0NvqwXgsOnA5S4kDmfoMowEIYJku5B79Vcf637w+nnvdX3avuSr0lFnoF6BOSUMGn6njxcIjwYKTYNi2HOFCHrjC+h59FvXvNe9el98YH7w6mPzCWYPIYmZ2oTNjhIEyqGT7OBIAN69DbkVT1534JOW6/ZzE4MXGJ8AdO95GweBVQ1WLa7OvfDjT6Cj3kCyyTRbgBCUO8gBNrQkswtYsQCiARJwe8ORqqT8T/u6vl575yLpqrsYGoBmr95Du8++hxA0INY0OD9Aa4A5gNIM5ALwplevyr3xxKT+7iVNtZOkpe5eaW0AhKBBxkcTApOyql8BUCACzG5i8juL9dY30PXT638rzXX77yxBKp3XlGqAFOfx8aWmebOAD2A7blC/4VzOdJ4rZqZsjZsjmGLyP51ZEYKZQAveDNb/qYIbtnyyv+sz81XS2VAszIAmy2CDAIYOVb/5nUOn0MHHWUABgd1ns7n52bXPze/vXtnaN7+ht2+oIKu/SMjjCowWs8qa3D9mzA7OTsLgui3nZzet7Pf6UaLyqhlueuOAhscmAPrtF5YIKVCQA+VyFfv/QnCmtO/2m0gM1r0PpNyoAC8A5hQwM8kQQLpaEGx+8bJ+r5/tuBS5XtPIQcMz20C+bX9f93rEGQS71+weAA2ACdzaAN6+rqrfoSy9b4xIpMdwVNU70Kkv4YaoJCcgwoDs2V0dLHmger/zluk90tUBODlwHz6+KKC8ppt0FtK2E9Ja/8Oeh/+R98KtWtgVCUEyHV+CBGG4Z/8LJw57OZRi/yG3gpBE7s3+/TPZs9U4lXZFR7191+07Gv6J3eEr2n5GG81hogKGBILUsWffA/xPXl4gW7vhyN6ffeVId/rIe1ZDJez06eDoYv0c6WwB7yn6YPePvlTOpCNzAI+zyDXtQHbZH4pZBElJbEvWTNn2Hnc7IIpPACbMeoU6G18Sblug33qqAmXVP/eqz3KO2HrAIuAeU5l1TSUIKp/5/ZDAqCzXjkUJg5u39//h7j3GqxeAtF11bm8A723zfTsZtk2nrOaANoARxQBaG/e6jeppm5eomjBPN+4AgUxPYf/A4UDyehV55osfl5BAd3V+Xt5e/XnDb2WdvHCbusr0QrpaARCSJ5y+PDn7zOXvyZQDoNgEoPjc63foXauezDxyUwV07yzpbjOKioEoR8Wjb8UDMIn6qH37fh7ZSWN3FhBgVkYu0+/ziNZWhVt17h1BhDt6nR/gNYBlOoc+gxMG1mbzaF9izsIcTBU+vBKER7rZCCAEpUYcOJ83sT5Dbzekt9vEEVGBETNPQgqJmilIHH/GOjV5xpX7ZcoBUKyIoMSEOd8KXv7Z/bp+7cV6xyqI2HDK6jIj1dYMjDnydt6xDh7jDqfajYfs1D3sTwKB3YY9YoATECVQo8fv42HKQbrJr3oR8cwXb+/dGUMuHBTjMDIb2y8CCRIAM0gzEiV7uzZUXLFeOvasV4zjxKg4I6TRIF2i/+d77yGKSkCkfoVk0RtEyn/GbWJRAKS4HMlzLkVyzlmPpY6YGctp5rE3iUqe/rebAPxgf5/rXXr5P8mO9ePFbuF2ImBWigmcwj0GbkOkgobZ1k0wK1pNOwPAH/a6PlVMBjfV2uPhBBRI6PQ5vL/PAJINDWGjBPs5OEHREFaQqrF71SGSYyZsZJ1dD5LjYJ/apemjJ5nlCYF/yLCXoRSVQlWOfXTUbf/z4HtO3I+e3d/UHhQNxTG/AACpXX0tSirMHNuYOfTyor19QseQwd6JYgKQTKNo+oLH+71+qvKPEAEFDNIaCChc+UGo9s2qZ5A2m0LJOoekAeTgi0ZUVAletXSvCiGNGsfFZ11pmWuOpnUNsymP8fkr34UFLGa/oRo3Ganzrohjag+KhkwA1MQTloHUUnGrANZUCPksWpT55gPuJDDTtkUddSqrGWf+ot8b9LbdKyXVprVs4HYAuQbSfcM/gCO+ANgoBNFkVr8WJGqmcNH5f9PvrWjqCbeo6sOt9jLmK+9gx74r3zl/VsCBBBJlVUuTU08oOPp4yASg6Nwv1yfnXvEoJYt9Fw8XFDvHKEreDlqToaomQJVUXL6v6ydO/eJGGn30RtIKvplD4FQ/2zAQXt2TtprBhYdOW2hAaQEmH/NQ8pTz+1XP6aPmrEl94LLlKCmzHbzIP7M7y7gvjtszXwSqeizSn7rh0eS0OYdU6h4IDZkAAEDRWZ/9t0T5YT/hRBpiljZIEpEVEl39TouayU3O/sjK9Bl/tXJf105WTV6XrJpyLRKlYNZQ2nUQj4aCCFPBPkcgkUiBjec/6VikPnDp/3vPwUj28sRRJ6x0Dp3blLoXSsr/bQW8fDTUjFN+kpp8zL8d4LTFSkMqAACQPvfaWxOTZj9IqXJ7No+JCthpAqMU4CQgUVKJ5Omf3qYOn/GhxMRj336vaycXfuWZxLyrtlGyAloCY0I0gZztZwYFtiFEoEyoGJg+AaIBBAQqP6xVlR12eXry8c+8172KP/yFt6my5kPJmfO3Ubok9Gd8dtPmsW2dA1CgUdVIHb/gLqjklwc+k4dGwwbBmXn0W/+tG7Z8nLevgVGNBHcWKYmGqCIkx80AJh7z3dTpV/w2WXP0Ae3Py25bPgvvvLQ49+qvZ3IuZzRAIFDaHC+LwMb7gY3zbb6AAgHKx0CNGXfFqP+7+P4DHUf25Udm5V78/RXc2vB1rn/XNKswhssmfwiiCMkJR29Ux53yUNmnv/6NQ5mvuGjYCIDe+eaY7PqnZxDzP0hz7cV610Yg2wMUVyJZMxU06cRl6Gy6tejC61866GtvXz0ju+yez/HOzV/k1oY0sUACs2FU5Sw0zCWDtEAkATVuWm/iiJk3l37u1kPa/99917UL1LgpN2a3rV9IjduA7l6gvAJq+hxIkLs1VVnz+6Irrt90KNeOk4aNABSCgvVPfTHzwm8uR6ZnIe98G5LLAllz/hCzQKVHAeWja6Vy/NKyv/nmw8mxkx8a6mcebPqzEgAAyG1bMVm/s3qBXvJrJGZ/+Mug1HxGAgBe4VXP3ZGcv6i2+COfPWgt836lYScAun3LGOlunonGteD23UBnEyToASQJFFVCVU0GqmcgNe2cAcfMXLu6VLe3JFmloA6bGKTGTe0e6DWzLW+NSXTumsnN60Hde8wpIqkyoPoYSOmYjemJpzQN9B5x0rARAN79+nW69umx0lo7k0pqPiadDZBMF5Dphuis2cevikGpUUDxaPC2V79Hk+cjNfuStckppx8csjbuZ8/srtK1z95A7y4BBz0zqWzix6SrCZTrMSVpSgLF1eC2Hb8njY1q4jzQlAVrU1POGNLnBoZYAHq33D8m0V1/vnTU3ygtm6Yj212M3k6bnNFh/d4BOXSkcKMBShVDEmXtiQmzaqWp7iKaeV5T8Qf+bq9VHNS/NkbVv1zK9W8gqDq6Jjn+5BvR3TwD2Q6wzgKShCoqA1LlQKrkN7ml/36fmjQXatJ8pI5dVLv3kwO5V24qxcQzb0fdcwulaW2SkJrJ2Q4gmzHnB9kTRaADW3Cy7eaRgiRKQUC7JEtr0zM+vI2TxbeqI07elJx4YsG1w5AJgN7028/r5jeuRsOKuchmAK1N+KUBzdojcSSwTporz2obRruYXQClAYwaj+SMc35adNH1VwMAt7w5Ve/ZeD62PAxUHnM1ehvnoq0OQVcDFAdgbYEo2jaIFsCdRQRVAlU1BVQ1BbmtS/8hdeQC0KyPv52eNM9Dw3Mrvn2P1L/8WfR22Eqjg5VFEk5sDpzw2EObgnanjog296eK8VBHn7uSu1suK6Y5P9UAAAqUSURBVP2Lb79nbiNuGpLDo4P1/3E9b3/8NnTUQXJBXlWONJtkiWaPGYA79YMJwoH9KQDYVOkYQFk1UDF2DwBkNv7s+mDFbZeLqLmquxG67V3bF8ge9+pwCI4xgGkuLfZZgi7o3RtAu9aDkLhb164Cdr+zM/PgtSsTC65+ITnxxH9V5VP26OJ3QN3tJt+jlT3DSMO3pXPPbX/35WcxZWdiCxVv2QVevnguiisX53aseSA16cSCtZ4ruAbIrfiX71DD6q9Ld5sttOgQn8faonBMLl5EgMDky0UbhiFwwsIGwJEsBY2durrog5dfJDufOQm5rkepZYtirc3Ea20FyRSS2KKD3DmDAhih87Bwsv0AbdKGOazksUBSZUgedyGrXM8pybP+rl0v/epi6W4+iXMZKCZobTe0uOd1R8kEBiugrQZwmozZtp/VAERDjTsBydOv+nZ69gUFaT6ZKMRNHOnO2rNly+/uRVcjRAKwaJBWIdNdLp4p/N1OvLOjHtnDZtdQct7lK9Wk4z+ZzKz7sbRuvRkd24m1aaZsbC5ZhtvijEXtevyey9fbSp5D7/gV7HL6djVLkIXUvUmSzXwQJdU1JJ3XIVG8kLuaJkAsY5nDVrT+wInIeCQ6TvbPJkyQ9kaQSi34zoPLbikETwpaC+DN9/8dd7wLZrdJw+bcI02boQGxx8KHBRvY3TvagzpJpVF08id3JCcfebmSVTcH9S9fID2NEM0WLCKeib6JtESFTMLXLFPIvu7wgRbC758PcKqbwM3bpueev+carvnQzTThjMtU6cQGaItuitw73IGE0KENbFk62pncwteEBcGaZ5LBOyv/oxA8KZgABO21E9GwaippZfLj0U0aHpgJC9iAx+2R27DpdvFYAAWNnrqJKiZcpLrfuhltW/+SgizC8wLZl2E90FNCZtgmgXlA0FAIJbLynWYQixEQ02bOqnVub0Bu6S8+HbTRSWrCvH+W4moPInVVxvAomwjq2Aui0RDCALHtUxgIOJdB9o0nawrBl8JpgJ76eZyummuYCWNrfTk2nPhw1SB8zdbmSSzCVwvUyYteS846bSY3Lv9LZDqN9mBtK4nWy3ZqNsJYcY6lZ6xjFPx93b4BcX6BRM2IPVDKRSk7NylsX3MLjZn5e6Qrnjd7ECnCfHePiCD4swZCITOCAysMDLVrS0HYUjABUN0N6USQK3YQLPZxfrhDx8f70UnT7CeHNUOYkBg9BeljTrpRr7/nK9LdHKpZmDAy9Cv6mego850giviV6tvE2jDOf5dNG1yRUGuJMEQzgg0vHBdsr5+eOv7TSw0GMfo9hBouCk/3CGRnHiQ0h0zQVJgArWACIAhtudt1wzYc8qsyAtmW6JYtgQ39bEOHSSdCGlfPR8+e+fAnhxpnyzh3biVHGN+X+f51lwcQ85xeCyCC6RPrPhg0MpxDaVcr53II3l39FZk09w5KlHmAiTdhEUfTnzXkTYBFDTk/wz57omx0QfhSOBNQUgNWRSBtVg2xTcKwDmFYdoLMaghDMyM49iCIQKCqJ0NvfhDcsd2qaBcZwGL44SdT7EoW7z+4VUkRU2M9dQcDE3PknHPOwuNjLHrYawqEexsy2UXSvHshlY+Dy1v4Z2d34nnEzGkXWYTPZyBpxnzw6H73ocZOBRMASlesR1fzOolMDHtcXmTVs0CCSFwewe5Bk+FPsihQExZcTkEmPODJRRF2xXonMvJ+dIWF3cANitcfMWO/H/bkJet7INRQ1kw4X4JYQTpa07x5eZqpCMQ69G38ptTQkQ01RJjqDuFo5juJyrEF4UvhfIDqmevRVrcx3JXDeXYxDJciDIraTztxSgso0AolNYtC8wBrryPX8UySPE8+PD8g4gxGVnseg933JBoO5l/X+wqZHnBrPSTX7TWKW/nh9+GFiPL8Heu7OK0kAqoaVxi+FOQujiqm5DlEPrmS5wxyZGUg9NDdHn4BpKNFcUfdr8SGZqGwAGHWLjxVPBp2UXTlRWyyOKGBSzMDLvLwzM5jvjUHItaQJ6FSZaCutoiGCcfmfQF//8hzR6Ig8x0CVY5bXwiWFFYAqmfm2UB3ahflMR9mcnU+Yz2uXxO4vQmya/mTREWG0c6Rijp//kRRxyz4v0PVjb2dRXeQpGNGVPV7wQl9Ab+zKFkCNXoiqLcnz5GM+iZ77VD25oAi97f3G1V5ZyFYUlABSI6bBQlcdQwmEtACdnh9ociKQKSBg30/AJAT6D27ocadDBSNNgkURFZ5NOzzkywRBor/THQ1EuCZ45gcHheL0KzkaRSyVUsA6eJemXR0Vmc77Wcl1Dg6uuL7EWxv/gwMPZEqRWr0xIKUhgsqADT6qJ+DUn5S2G3FsoWasGePeNWf5xw5e9vaBKqcCqTKrK23q9F52X3trmMcw3bvgBeWvMjAhoLhyaHo41PAayxfkXQhbdPO5VQ59jV/2ESek+deI0SFNDSB9r3AglNHF8b+AwUWADVu9hOJmuPrSSsTr1sNAI7k/r3n77pzcMQJtCuusxMyajKQLA5Vp2OM/d2vrDy7HTp/TlhMWdh28/LOG7wzFl3N0ejCP6/4vEO9SkkvnAA6DcZ2h683fWT3KdpwjyPt6oQBSiAxdXbBdggVfmNI5eHXovIIP0F56VgNo+aDqDBQWDRyGbNMBonSsbWSzdSG27sjKtrF1X1UNzmbHhEO8YxFHoN9rUDsKvfvURj7e+ECEpOOgTB93uQ3tK0CUl4oGNYhjNCTmBPLodmGwAqJKbO2UFfHRwrFjoIDQpKzPro01935IVV++OO6djWop916+EAYhwN+u7YTBmcuVBo4bAKotGKltGxbKcKTo98La/p9GCzO03eMIG8CjHD0Wel9agkh88WreC9YTFBHHIeEDqZJcVUWXR0A57yG8So+kgV1ggRtMIOJI2cgOefcLHd1faL0iq+tKRQ/hg0o9FCod/Eli6Vt96UuHHP59GgqOPQDnFbhvR27qFduk0AOOBLWJRD6ETb6876JMEqv+9mD6eMX9N+wahjTkO8NHAhR5VQ45rNlptubL45ZAGDxAeJyun1MQ1gnCJ2zPOY7c6IRdi9hiQiMQqJq/N2FHn8c9L4WAFVzgg3ELcwqkkjxqV6fcUPohdswL/TWuU/4KJHPk/9dYCFi9prkHL7K8UgcPvXZIZyKQ6b3tQBQ9fT/ZiTCZItzzjiM4R3i1wlKFO4V1gWi9X9YL57R1yE0DFc26cQ+ckhMnT1kczBQel8LQHLywvsTE07pBCf8bmzWph5PkXDSATvDBE4YDubF+767Z+ishYJkXifbYpbFoJGpqDRLnHvfniH8vhYAAFBlYz6oJp9WmygbB0IC5JJKrsOUuIKMMu85++7Amnn5ApuPCOAzfC6G9+bEOpEkBKqeiFRZ9VfLvnzXkDR3iIPe11GAo1ztawt4zYOTde1KJOZ88rfoagV0AOEAyGVhGwzaDKF41e2bN4pzIJ13734333FRBQGQVDGEEqBkySvcuOOO8mt/eMC9A4Yj/X8hAFHK1a0qR2s9oDOAzoFzGSgrAOzsP2zpVVx/4jAf4OsRZssGYM8WJhHT4aNklKn8TZwWpI48rncIhzpCIzRCIzRCIzRCI3TI9L9wXAdXACGNUQAAAABJRU5ErkJggg=="
          },
          "colorCode": "#fff",
          "navUpIcon": "1",
          "navPreviousIcon": "1",
          "navHomeIcon": "1"
        }
      } else {
        templatePayload["template"] = templateData.id
        isDefaultTemplateEnable = true
        // try {
        //   templateData["companyLogo"] = templateData.companyLogo
        // } catch (error) {
        //   templateData["companyLogo"] = templateData.companyLogo
        // }
      }
      console.log("templatePayload", templatePayload);
      const res = await BPMNService.setDefaultTemplate(templatePayload)
      console.log("res ", res)
      this.setState({
        appliedTemplate: templateData,
        isDefaultTemplateEnable: isDefaultTemplateEnable
      })

    }
    else {
      ErrorMessage("Templates can be applied by either Admin or Editor in 'In Progress' status of draft")
    }

  }
  openApplyTemplate = () => {
    const loginUserRole = localStorage.getItem('userRole');
    console.log("loginUserRole ", loginUserRole)
    if ((loginUserRole === "Editor" || loginUserRole === "Admin") && this.props.selectedMapType.mapLevel === "Draft" && (this.props.selectedMapData?.diagramXmlIds?.Draft?.status === 'InProgress')) {
      this.setState({
        isApplyTemplateEnable: true
      })
    }
    else {
      ErrorMessage("Templates can be applied by either Admin or Editor in 'In Progress' status of draft")
    }
  }
  onPrintClick = async () => {
    try {
      let tempMappDiags = [...this.state.mappingDiagrams];
      const tempCurrMap = { ...this.state.currentMapDet };
      const currentXML = await this.getCurrentDiagramXML();

      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            console.log(arr[i].diagramXML, currentXML);
            const isBothXMLSame = compareTwoXmlStringSame(arr[i].diagramXML, currentXML)
            console.log("isBothXMLSame ", isBothXMLSame);
            if (!(isBothXMLSame)) {
              arr[i].diagramXML = currentXML;
            }
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }

      const updatedArray = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id)
      console.log("##### ", updatedArray);

      let xmlResult = cloneDeep(updatedArray);
      let exportResult = []
      if (this.state.diagramLevel === "CurrentProcessMap") {
        const getCurrDiagramXmlById = async (arr) => {
          console.log(arr)
          for (let i = 0; i < arr.length; i++) {
            console.log(arr[i])
            const importXMLResponse = arr[i];
            // await this.updateXmlByImportXML(importXMLResponse);
            this.setState({
              diagramXml: importXMLResponse
            })
            exportResult.push(importXMLResponse)
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children);
          }
          return arr;
        }
        await getCurrDiagramXmlById(xmlResult)
        console.log(exportResult)
        return exportResult
      }
      if (this.state.diagramLevel === "CurrentAndLower" || this.state.diagramLevel === "CurrentLevel") {
        const updateCurrDiagramXml = async (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              if (this.state.diagramLevel === "CurrentLevel") {
                return exportResult.push(arr[i])
              }
              const getCurrDiagramXmlById = async (arr) => {
                console.log(arr)
                for (let i = 0; i < arr.length; i++) {
                  console.log(arr[i])
                  const importXMLResponse = arr[i];
                  // await this.updateXmlByImportXML(importXMLResponse);
                  exportResult.push(importXMLResponse)
                  if (arr[i].children.length === 0) {
                    continue;
                  }
                  await getCurrDiagramXmlById(arr[i].children);
                }

              }
              await getCurrDiagramXmlById([arr[i]])
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              await updateCurrDiagramXml(arr[i].children, parentId);
            }
          }
          return arr;
        }
        const updatedArray = await updateCurrDiagramXml(xmlResult, this.state.currentMapDet.id)
        console.log("updatedArray ", updatedArray)
        console.log(exportResult)
        return exportResult
      }
    } catch (error) {
      console.error("Error ,", error);
    }
  };

  onPrintClicked = async () => {
    console.log("print")
    let temp = []
    const getCurrDiagramXmlById = async (arr) => {
      console.log(arr)
      for (let i = 0; i < arr.length; i++) {
        console.log(arr[i])
        const importXMLResponse = arr[i];
        // await this.updateXmlByImportXML(importXMLResponse);
        this.setState({
          diagramXml: importXMLResponse
        })
        temp.push(importXMLResponse)
        if (arr[i].children.length === 0) {
          continue;
        }
        await getCurrDiagramXmlById(arr[i].children);
      }
      return arr;
    }
    await getCurrDiagramXmlById(this.state.mappingDiagrams)
    console.log(temp)
    return temp;
  }
  handlePrint = async () => {
    this.openSpinnerRedux()
    const bpmnXml = await this.onPrintClick(); // Fetch your XMLs here
    this.setState(
      {
        bpmnXMLs: bpmnXml,
        renderedDiagrams: [],
        isRendering: true,
        PrintLevel: false,
        printTriggered: false
      },
      () => this.renderDiagramsInChunks(bpmnXml, 0)
    );
  };

  renderDiagramsInChunks = (xmlList, startIndex) => {
    const chunkSize = 10; // Adjust chunk size as needed

    if (startIndex >= xmlList.length) {
      this.setState({ isRendering: false }); // Mark rendering as complete
      return;
    }

    const nextChunk = xmlList.slice(startIndex, startIndex + chunkSize).map((xml, index) => (
      <div key={startIndex + index} className="print-page">
        <ShowDiagramPrint
          selectedMapType={this.props.selectedMapType}
          templateBgColor={this.state.templateBgColor}
          isDefaultTemplateEnable={this.state.isDefaultTemplateEnable}
          currentMapDet={this.state.currentMapDet}
          CheckElements={this.props.CheckElements}
          diagramXML={xml}
          // diagramname={this.state.diagramname}
          selectedMapData={this.props.selectedMapData}
          appliedTemplate={this.state.appliedTemplate}
        />
      </div>
    ));

    this.setState((prevState) => ({
      renderedDiagrams: [...prevState.renderedDiagrams, ...nextChunk],
    }));

    // Schedule the next chunk to render
    setTimeout(() => {
      requestIdleCallback(() => this.renderDiagramsInChunks(xmlList, startIndex + chunkSize));
    }, 1000);

  };

  // componentDidUpdate(prevProps, prevState) {
  //   if (!this.state.isRendering && this.state.bpmnXMLs.length > 0 && this.printRef.current && !this.state.printTriggered) {
  //     this.setState({ printTriggered: true }, () => {
  //       this.printRef.current.handlePrint();
  //     });
  //   }
  // }

  handleAfterPrint = () => {
    this.setState({
      bpmnXMLs: [],
      renderedDiagrams: [],
    });
  };
  onPrintDiagram = () => {
    this.setState({
      PrintLevel: true
    })
  }
  getAllusers = async () => {
    try {

      const response = await ResourceService.getAllResourceAPIcall();
      const data = await response?.data;
      if (response?.status === 200 || response?.status === 201) {
        // const updatedData = data.map(el => ({ ...el, Selected: false }))
        this.setState({ resourceData: data });
      }
    } catch (error) {
      console.error("getAllUsersAPIcall", error)
    }
  }
  EditResource = async (updatedResource, oldName) => {
    // const elementFactory = this.handleBpmnRef.current.bpmnModeler.get('elementFactory');
    const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
    const parent_Id = this.state.element_data_id;
    const parentActivity = elementRegistry.get(parent_Id)
    console.log(parentActivity);
    console.log(updatedResource)
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const resourceElements = await bpmnCanvas._elementRegistry.filter((el => el.id.includes("Actor") && el.businessObject.$attrs?.resourceId === updatedResource.id))
    console.log(resourceElements)
    resourceElements.forEach((resource) => {
      bpmnModeling.updateProperties(resource, {
        name: updatedResource.displayName,
        fullNametxt: updatedResource.displayName,
        resourceType: updatedResource.type
      });
      bpmnModeling.setColor(resource, {
        fill: updatedResource.type === "SYSTEM" ? '#fec76f' : '#bbdefb',
      });
    })
    await this.getAllusers()
    this.setState(prevState => ({
      EditedResFlag: {
        ...prevState.EditedResFlag,
        flag: true,
        ResDetails: updatedResource,
        oldName: oldName,
        type: 'Edit'
      }
    }));
  }
  OnDeleteResource = async (DeletedResource) => {
    console.log("DeletedResource ", DeletedResource)
    const bpmnCanvas = this.handleBpmnRef.current.bpmnModeler.get('canvas');
    const bpmnModeling = this.handleBpmnRef.current.bpmnModeler.get('modeling');
    const elementRegistry = this.handleBpmnRef.current.bpmnModeler.get("elementRegistry")
    const parent_Id = this.state.element_data_id;

    const parentActivity = elementRegistry.get(parent_Id)
    // all resources that deleted in resource repository 
    const resourceElements = bpmnCanvas._elementRegistry.filter((el => el.id.includes("Actor") && el.businessObject.$attrs?.resourceId === DeletedResource.id))
    console.log("resourceElements ", resourceElements)
    resourceElements.forEach((tempResData) => {
      // get parent Activity of deleted resource box
      const parentElement = bpmnCanvas._elementRegistry.get(tempResData.businessObject.$attrs.parentActivityId)
      console.log("parentElement ", parentElement)
      // parent Activity 's all resource elements
      const parentAllResIds = parentElement.businessObject.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (id?.includes("Actor")))
      console.log("parentAllResIds ", parentAllResIds)
      // parent Activity 's other elements
      let parentRemainIds = parentElement.businessObject.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (!id?.includes("Actor")))
      console.log("parentRemainIds ", parentRemainIds)
      // parent Activity 's all resource shape elements
      const allResElements = bpmnCanvas._elementRegistry.filter((el => parentAllResIds?.includes(el.id)))
      console.log("allResElements ", allResElements)
      let positionRes = []
      allResElements.forEach((res) => {
        if (tempResData.id !== res.id) {
          parentRemainIds = parentRemainIds === undefined ? res.id : parentRemainIds + "," + res.id
        }
        if (tempResData.y < res.y) {
          positionRes.push(res)
        }
      })
      console.log("parentRemainIds ", parentRemainIds, isArray(parentRemainIds) ? parentRemainIds.toString() : parentRemainIds)
      bpmnModeling.updateProperties(parentElement, {
        mapped_Child_Ids: isArray(parentRemainIds) ? parentRemainIds.toString() : parentRemainIds
      });
      const copiedIncomingFlows = [...tempResData.incoming];
      const copiedOutgoingFlows = [...tempResData.outgoing];
      console.log("tempResData ", tempResData);
      console.log("copiedIncomingFlows ", copiedIncomingFlows);
      console.log("copiedOutgoingFlows ", copiedOutgoingFlows);//waypoints
      copiedIncomingFlows.forEach(flow => {
        const newFlow = bpmnModeling.connect(flow.source, parentElement, { type: flow.type });
        if (flow.businessObject?.name) {
          newFlow.businessObject.name = flow.businessObject.name;  // Copy the name (label)
          bpmnModeling.updateLabel(newFlow, flow.businessObject.name);  // Update the label on the diagram
        }
      });
      copiedOutgoingFlows.forEach(flow => {
        const newFlow = bpmnModeling.connect(parentElement, flow.target, { type: flow.type });
        if (flow.businessObject?.name) {
          newFlow.businessObject.name = flow.businessObject.name;  // Copy the name (label)
          bpmnModeling.updateLabel(newFlow, flow.businessObject.name);  // Update the label on the diagram
        }
      });
      bpmnModeling.removeElements([tempResData])
      if (positionRes?.length !== 0) {
        bpmnModeling.moveElements(positionRes, {
          x: 0,//(dragParentX + (width - 40)) - positionRes[0].x,
          y: -25,//(((dragParentY + 8) - positionRes[0].y))
        });
      }
    })
    await this.getAllusers()
    this.setState(prevState => ({
      EditedResFlag: {
        ...prevState,
        ...prevState.EditedResFlag,
        ResDetails: DeletedResource,
        oldName: '',
      }
    }));
    const pushAuditObject = {
      diagramLevel: this.state.currentMapDet.id,
      AutoNumCount: parentActivity.businessObject.$attrs.AutoNumCount,
      id: parentActivity.id,
      field: "Delete Resource",
      type: "DELETE_RESOURCE",
      newValue: `Resource Deleted`,
      oldValue: `${this.state.currentMapDet.id} (${parentActivity.businessObject.$attrs.AutoNumCount}) - ${DeletedResource.displayName}`
    }
    console.log("DELETE_RESOURCE", pushAuditObject)
    this.audittrailpushingObj(pushAuditObject, "DELETE_RESOURCE");
  }
  getActivityId = async (e) => {


    let selectionService = await this.handleBpmnRef.current.bpmnModeler.get("selection");
    console.log(selectionService);
    let element = this.handleBpmnRef.current.bpmnModeler.get('selection')._selectedElements[0];
    // console.log(element)
    const id = element?.id;
    // console.log(id);
    const version = element?.businessObject?.$attrs?.AutoNumCount;
    // console.log(version);
    if (id !== undefined && version !== undefined) {
      this.setState({
        getActivity: version,
        getActivityElementId: id,
      })
    }
    else {
      this.setState({
        getActivity: '',
        getActivityElementId: '',
        getCurrentMapId: ''
      })
    }


  }

  onChangeReviewerSelect = (data) => {
    // const ReviewerId = []
    // const ReviewerName = []
    // data.map((x) => ReviewerId.push(x.value))
    // data.map((x) => ReviewerName.push({value: x.value, label: x.label} ))
    this.setState({
      ReviewerId: data.map(x => x.value),
      Reviewername: data
    })
  }
  updateCurrDiagramXmlById = async (arr, parentId) => {
    try {
      const currentXML = await this.getCurrentDiagramXML();
      console.log("currentXML ", currentXML)
      function updateCurrDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            arr[i].diagramXML = currentXML;
            return arr;
          } else {
            if (arr[i].children.length === 0) {
              continue;
            }
            updateCurrDiagramXml(arr[i].children, parentId);
          }
        }
        return arr;
      }
      return updateCurrDiagramXml(arr, parentId)

    } catch (error) {
      console.error(error);
    }
  }

  openIntegrityCheck = () => {
    this.setState({
      isIntegrityCheckEnable: true,
      IC_objectsChecked: {
        activitiesText: true,
        activityResources: true,
        activityDocuments: true,
        // flowlineText: true,
        flowLinkConnections: true,
        // endEvent: true,
        testCaseCoverage: false,
        requirementCoverage:false
      }
    })
  }

  integrityCheckValidationCheck = () => {
    const IC_objectsChecked = this.state.IC_objectsChecked;
    const isValid = Object.values(IC_objectsChecked).some(value => value === true);
    return isValid;
  }
  integrityCheckOnChangeHandler = (e) => {
    const { name, checked } = e.target;
    this.setState(prevState => ({
      IC_objectsChecked: {
        ...prevState.IC_objectsChecked,
        [name]: checked
      }

    }));
    console.log(this.state.IC_objectsChecked, name, checked);
  }
  integrityCheckOnClick = async (e) => {
    e.preventDefault()
    const isValid = this.integrityCheckValidationCheck();
    if (isValid) {
      try {
        // this.openSpinnerRedux()
        // console.log("OPEN 111111111", moment().format('HH:mm:ss:SSS'), Store.getState());
        let tempCurrMap = { ...this.state.currentMapDet };
        console.log('tempCurrMap', tempCurrMap);
        // const tempMappingDiags = cloneDeep(this.state.mappingDiagrams)
        // console.log("🚀 ~ iCcheckFlags:", this.state.IC_objectsChecked);
        let finalResults = [];
        let tempBrokenLinkCount = 0;
        const getCurrDiagramXmlById = async (arr, parentId) => {
          for (let i = 0; i < arr.length; i++) {
            const tempResult = await this.getFilteredActivities(arr[i]);
            console.log("###### ", tempResult);
            finalResults = finalResults.concat(tempResult.report)
            tempBrokenLinkCount += tempResult.brokenFLCount;
            if (arr[i].children.length === 0) {
              continue;
            }
            await getCurrDiagramXmlById(arr[i].children, parentId);
          }
          // console.log("🚀 ~ arr:", arr);
          return arr;
        }
        const loopResult = await this.downloadBPMN_OnClick("FromIC")
        if (this.state.diagramLevel === "CurrentLevel") {
          console.log("loopResult", loopResult);

          loopResult.children = []
        }
        // console.log("🚀 ~ loopResult:", loopResult);
        await getCurrDiagramXmlById([loopResult], tempCurrMap.id)
        // console.log("OPEN 22222222", moment().format('HH:mm:ss:SSS'), Store.getState());

        this.setState({
          isICReportExportEnable: true,
          integrityCheckReport: { records: finalResults, brokenFLCount: tempBrokenLinkCount },
        })
      } catch (error) {
        // this.closeSpinnerRedux();
        console.error(error);
      }

    } else {
      // this.props.closeSpinnerRedux()
      ErrorMessage(BPMN_Editor_Toaster.At_least_one_object_needs_to_be_checked);
    }
  }
  getFilteredActivities = async (treeObj) => {
    // console.log("@@@ ~ treeObj:", treeObj);
    try {
      const iCcheckFlags = this.state.IC_objectsChecked
      console.log(iCcheckFlags);
      const allDefShapes = xml2js(treeObj.diagramXML, { compact: true, spaces: 4 });
      // console.log("🚀 ~ allDefShapes:", allDefShapes);

      const tempMappingDiags = cloneDeep(this.state.mappingDiagrams)
      const currDiagramShapes = allDefShapes['bpmn:definitions']['bpmn:process'];
      // console.log("🚀 ~ currDiagramShapes:", currDiagramShapes);
      let finalActivityResult = [];
      let brokenFlowLineCount = 0;
      let allActivitiesArr = [], allSequenceFlowsArr = [], allEndEventsArr = [];
      let filteredArray = [];
      const caseSensitiveActivityElements = extraActivityElements.map(data => data.toLowerCase())
      await Object.keys(currDiagramShapes).forEach((item, ind) => {
        if (caseSensitiveActivityElements.includes(item.toLowerCase()) || "bpmn:task" === item.toLowerCase()) {
          const resItem = currDiagramShapes[item];
          allActivitiesArr = allActivitiesArr.concat(resItem);
          if (item.toLowerCase() === "bpmn:subprocess") {
            console.log("subprocess", item, resItem);
            const subprocessResult = isArray(resItem) ? resItem : [resItem];
            subprocessResult.forEach(subItem => {
              if (Object.keys(subItem).length > 0) {
                Object.keys(subItem).forEach(subKey => {
                  console.log(" subKey ", subKey);
                  const resSubItem = subItem[subKey];
                  console.log('resSubItem', resSubItem);
                  if (subKey.toLowerCase() === caseSensitiveActivityElements.includes(subKey.toLowerCase()) || "bpmn:task" === subKey.toLowerCase()) {
                    allActivitiesArr = allActivitiesArr.concat(resSubItem);
                  }
                  if (subKey === "bpmn:sequenceFlow") {
                    allSequenceFlowsArr = allSequenceFlowsArr.concat(resSubItem)
                    console.log(' allSequenceFlowsArr ', allSequenceFlowsArr);
                  }
                })

              }
            })
          }
        } else if (item === 'bpmn:sequenceFlow') {
          allSequenceFlowsArr = allSequenceFlowsArr.concat(currDiagramShapes['bpmn:sequenceFlow']);
          // allSequenceFlowsArr.forEach(flowLine => {
          //   console.log('11111', flowLine);
          //   if (!((flowLine._attributes.sourceRef.includes("FLE") || flowLine._attributes.sourceRef.includes("FLS")) || (flowLine._attributes.targetRef.includes("FLE") || flowLine._attributes.targetRef.includes("FLS")))) {
          //     console.log("flllll", false, flowLine);
          //     filteredArray = false
          //     return
          //   }
          // }
          // )
          filteredArray = allSequenceFlowsArr.filter(item => {
            const { sourceRef, targetRef } = item._attributes;
            console.log(item, sourceRef, targetRef);

            return !sourceRef.startsWith('FLS') && !sourceRef.startsWith('FLE') &&
              !targetRef.startsWith('FLS') && !targetRef.startsWith('FLE');
          });

        } else if (item === 'bpmn:endEvent') {
          allEndEventsArr = allEndEventsArr.concat(currDiagramShapes['bpmn:endEvent']);
        }
      })

      console.log("allActivitiesArr ", allActivitiesArr);
      allActivitiesArr.forEach((activity) => {
        let newObj = {
          diagramName: treeObj.name,
          toggleId: activity._attributes.AutoNumCount,
          elementId: activity._attributes.id,
          objectType: "Activity Box",
          objectText: "",
          checkResult: "",
          id: treeObj.id,
          label: treeObj.meta.label
        }

        if (!activity._attributes.id.includes('Actor')) {

          // Text check
          if (iCcheckFlags.activitiesText && (activity._attributes.fullNametxt === "" || activity._attributes.fullNametxt === undefined)) {
            newObj.checkResult = "No Text"
            finalActivityResult.push(newObj)
          } else {
            newObj.objectText = activity._attributes.fullNametxt
          }
          // resource check
          if (iCcheckFlags.activityResources && (!activity._attributes.mapped_Child_Ids?.includes("Actor"))) {
            const res = cloneDeep(newObj)
            res.checkResult = "No Resource"
            finalActivityResult.push(res)
          }
          // Document check
          console.log("activity ", activity)
          const isDocResAdded = activity["bpmn:documentation"] ? (isArray(activity["bpmn:documentation"]) ? activity["bpmn:documentation"].find(d => d._attributes.textFormat === 'json/file-document') : activity["bpmn:documentation"]._attributes.textFormat === 'json/file-document') : false;
          const isAlmAdded = activity["bpmn:documentation"] ? (isArray(activity["bpmn:documentation"]) ? activity["bpmn:documentation"].find(d => d._attributes.textFormat === 'json/file-ALMConnect') : activity["bpmn:documentation"]._attributes.textFormat === 'json/file-ALMConnect') : false;
          const isProcessAdded = activity["bpmn:documentation"] ? (isArray(activity["bpmn:documentation"]) ? activity["bpmn:documentation"].find(d => d._attributes.textFormat === 'text/process-activity') : activity["bpmn:documentation"]._attributes.textFormat === 'text/process-activity') : false;
          if (iCcheckFlags.activityDocuments && (activity._attributes.mapped_Child_Ids?.includes("Document") || isDocResAdded)) {
            console.log("doc inside", activity);
            let newObj1 = {
              diagramName: treeObj.name,
              toggleId: activity._attributes.AutoNumCount,
              elementId: activity._attributes.id,
              objectType: "Activity Box",
              objectText: "",
              checkResult: "Document Added",
              id: treeObj.id,
              label: treeObj.meta.label
            }

            finalActivityResult.push(newObj1)
          }

          // Test case coverage with ALM 
          if (((iCcheckFlags.testCaseCoverage||iCcheckFlags.requirementCoverage) && (activity._attributes.mapped_Child_Ids?.includes("Document") || isProcessAdded)) && 
          (iCcheckFlags.testCaseCoverage||iCcheckFlags.requirementCoverage) && (activity._attributes.mapped_Child_Ids?.includes("Document") || isAlmAdded)
        ) {
            console.log("doc inside", activity);
            let newObj1 = {
              diagramName: treeObj.name,
              toggleId: activity._attributes.AutoNumCount,
              elementId: activity._attributes.id,
              objectType: "Activity Box",
              objectText: "",
              checkResult: "Process Added with ALM",
              id: treeObj.id,
              label: treeObj.meta.label
            }
            finalActivityResult.push(newObj1)
          }
          //both added like process and ALM
          if ((iCcheckFlags.testCaseCoverage||iCcheckFlags.requirementCoverage) && (activity._attributes.mapped_Child_Ids?.includes("Document") || isProcessAdded)) {
            console.log("doc inside", activity);
            let newObj1 = {
              diagramName: treeObj.name,
              toggleId: activity._attributes.AutoNumCount,
              elementId: activity._attributes.id,
              objectType: "Activity Box",
              objectText: "",
              checkResult: "Process Added",
              id: treeObj.id,
              label: treeObj.meta.label
            }
            finalActivityResult.push(newObj1)
          }
          if ((iCcheckFlags.testCaseCoverage || iCcheckFlags.requirementCoverage) && (activity._attributes.mapped_Child_Ids?.includes("Document") || isAlmAdded)) {
            console.log("doc insideww", activity);

            console.log("text aextra", activity["bpmn:documentation"]["_text"])
            let textValue = "";
            let testCaseType = "";
            let documentation = activity["bpmn:documentation"];
            if (Array.isArray(documentation)) {
              documentation.forEach(item => {
                if (item["_attributes"].textFormat === "json/file-ALMConnect") {
                  try {
                    textValue = item["_text"];
                    testCaseType = JSON.parse(textValue);
                    console.log(testCaseType);
                  } catch (error) {
                    console.error(error);
                  }
                }
              });
            } else if (documentation && documentation["_attributes"].textFormat === "json/file-ALMConnect") {
              try {
                textValue = documentation["_text"];
                testCaseType = JSON.parse(textValue);
                console.log(testCaseType);
              } catch (error) {
                console.error(error);
              }
            }
            testCaseType = textValue === undefined || textValue === null || textValue === "" ? [] : testCaseType;
            console.log(textValue, testCaseType);
            if(testCaseType.length===1)
            {
              console.log("length is 1",testCaseType[0].type)
              if(testCaseType[0].type==='requirement' && iCcheckFlags.requirementCoverage)
              {
                let newObj1 = {
                  diagramName: treeObj.name,
                  toggleId: activity._attributes.AutoNumCount,
                  elementId: activity._attributes.id,
                  objectType: "Activity Box",
                  objectText: "",
                  checkResult:'ALM Added with requirement',
                  id: treeObj.id,
                  label: treeObj.meta.label
                }
                console.log(newObj1)
              finalActivityResult.push(newObj1)
              }
            else if((testCaseType[0].type==='test' || testCaseType[0].type==='test-folder') && iCcheckFlags.testCaseCoverage){
              console.log("length is 2");
              let newObj1 = {
                diagramName: treeObj.name,
                toggleId: activity._attributes.AutoNumCount,
                elementId: activity._attributes.id,
                objectType: "Activity Box",
                objectText: "",
                checkResult: `ALM Added with test Case`,
                id: treeObj.id,
                label: treeObj.meta.label
              }
              console.log(newObj1)
              finalActivityResult.push(newObj1)
              }
              
            }
            else {
              console.log("length is 2");
              if(iCcheckFlags.testCaseCoverage || iCcheckFlags.requirementCoverage)
             { let newObj1 = {
                diagramName: treeObj.name,
                toggleId: activity._attributes.AutoNumCount,
                elementId: activity._attributes.id,
                objectType: "Activity Box",
                objectText: "",
                checkResult: `ALM Added with Requirement and Test Cases`,
                id: treeObj.id,
                label: treeObj.meta.label
              }
              console.log(newObj1)
              finalActivityResult.push(newObj1)}
            }

          }
          if (iCcheckFlags.testCaseCoverage && isAlmAdded && !isProcessAdded) {

            let newObj1 = {
              diagramName: treeObj.name,
              toggleId: activity._attributes.AutoNumCount,
              elementId: activity._attributes.id,
              objectType: "Activity Box",
              objectText: "",
              checkResult: "Activity with ALM Added",
              id: treeObj.id,
              label: treeObj.meta.label
            }
            finalActivityResult.push(newObj1)
          }
          // unjoined check
          console.log("", filteredArray, allSequenceFlowsArr);
          // if (allSequenceFlowsArr.length !== 0 && filteredArray.length !== 0) {
          //   // console.log("🚀 ~ 3333333333:", activity);
          //   if (!(activity["bpmn:incoming"] && activity["bpmn:outgoing"])) {
          //     console.log("3333333333 yesssss");
          //     const res = cloneDeep(newObj)
          //     res.checkResult = "Un Joined"
          //     finalActivityResult.push(res)
          //   }
          // }

        }
      });

      function getChildDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].id === parentId) {
            return arr[i];
          } else if (arr[i].children.length === 0) {
            continue;
          } else {
            const isObjFinded = getChildDiagramXml(arr[i].children, parentId);
            if (isObjFinded) {
              return isObjFinded;
            }
          }
        }
        return null;
      }

      async function checkIsBrokenLink(mapId, activityId) {
        const findObj = await getChildDiagramXml(tempMappingDiags, mapId);
        // console.log("🚀 ~ findObj11:", findObj);
        if (findObj) {
          const parser = new DOMParser();
          const xmlDoc = parser.parseFromString(findObj.diagramXML, 'text/xml');
          const element = xmlDoc.querySelector(`[id="${activityId}"]`);
          if (element) {
            console.log(`Element with ID ${activityId} found!`);
            return false
          } else {
            console.log(`not foundddd ${activityId} `);
            return true
          }
        } else {
          console.log(`not foundddd ${activityId} `);
          return true
        }

      }
      console.log(' allSequenceFlowsArr ', allSequenceFlowsArr);
      // Sequence Flow
      async function processSequenceFlows(allSequenceFlowsArr, treeObj, tempMappingDiags, finalActivityResult) {
        for (const sequenceFlow of allSequenceFlowsArr) {
          let newObj = {
            id: treeObj.id,
            label: treeObj.meta.label,
            elementId: sequenceFlow._attributes.id,
            toggleId: "Flow Line",
            diagramName: treeObj.name,
            objectType: "Sequence Flow",
            checkResult: "",
            objectText: sequenceFlow._attributes.name ? sequenceFlow._attributes.name : "",
          };

          // console.log("🚀 ~ sequenceFlow:", sequenceFlow);
          if (iCcheckFlags.flowLinkConnections && (sequenceFlow._attributes.sourceRef?.includes("FLS") || sequenceFlow._attributes.targetRef?.includes("FLE"))) {
            // console.log("~ sequenceFlow True", sequenceFlow);

            for (const flowItem of treeObj.flowlineMap) {
              // console.log("🚀 ~ flowItem:", flowItem);

              if (flowItem.targetActivityId === sequenceFlow._attributes.targetRef) {
                console.log("innnnn startEvent", flowItem, sequenceFlow);
                let isBrokenLine;
                if (treeObj.id === flowItem.targetMapId) {
                  console.log("treee if");
                  isBrokenLine = await checkIsBrokenLink(flowItem.originMapId, flowItem.parentActivityId);
                } else {
                  console.log("treee else");
                  isBrokenLine = true;
                }
                if (isBrokenLine) {
                  brokenFlowLineCount += 1;
                  let resObj = _.cloneDeep(newObj);
                  resObj.checkResult = "Broken Flow Line Link";
                  resObj.objectType = "Flow Link Connections";
                  resObj.toggleId = flowItem.TargetAutoNumCount;
                  finalActivityResult.push(resObj);
                }
              } else if (flowItem.parentActivityId === sequenceFlow._attributes.sourceRef) {
                console.log("outttt end Event", flowItem, sequenceFlow);
                let isBrokenLine;
                if (treeObj.id === flowItem.originMapId) {
                  console.log("treee if");
                  isBrokenLine = await checkIsBrokenLink(flowItem.targetMapId, flowItem.targetActivityId);
                } else {
                  console.log("treee else");
                  isBrokenLine = true;
                }
                if (isBrokenLine) {
                  brokenFlowLineCount += 1;
                  let resObj = _.cloneDeep(newObj);
                  resObj.checkResult = "Broken Flow Line Link";
                  resObj.objectType = "Flow Link Connections";
                  resObj.toggleId = flowItem.SourceAutoNumCount;
                  finalActivityResult.push(resObj);
                }
              }
            }
          }
          else if (iCcheckFlags.flowlineText && (sequenceFlow._attributes.name === "" || sequenceFlow._attributes.name === undefined || sequenceFlow._attributes.name === null)) {
            let resObj = _.cloneDeep(newObj);
            // resObj.toggleId =allActivitiesArr.find(activity => activity._attributes.id === sequenceFlow._attributes.sourceRef);
            resObj.checkResult = "No Text in Sequence Flow";
            finalActivityResult.push(resObj);
          }
        }
      }

      // Call the function with your parameters
      await processSequenceFlows(allSequenceFlowsArr, treeObj, tempMappingDiags, finalActivityResult);


      //End Event
      allEndEventsArr.forEach((endEvent) => {
        // console.log("endEvent",  endEvent);
        if (iCcheckFlags.endEvent && !endEvent._attributes.id.includes('FLE')) {
          let newObj = {
            id: treeObj.id,
            label: treeObj.meta.label,
            elementId: endEvent._attributes.id,
            toggleId: "End Event",
            diagramName: treeObj.name,
            objectType: "End Event",
            checkResult: !endEvent._attributes.name ? "No Text in End Event" : null,
            objectText: endEvent._attributes.name || "",
          };
          finalActivityResult.push(newObj);
        } else {
          //for flow line link
          // let newObj = {
          //   id: treeObj.id,
          //   label: treeObj.meta.label,
          //   diagramName: treeObj.name,
          //   objectType: "Flow Link",
          //   checkResult: "",
          //   toggleId: endEvent._attributes.id,
          //   objectText: endEvent._attributes.name || "",
          // };
          // finalActivityResult.push(newObj);
        }

      });
      console.log("finalActivityResult", finalActivityResult);
      return { "report": finalActivityResult, "brokenFLCount": brokenFlowLineCount }
    } catch (err) {
      console.error('Failed to parse XML:', err);
      return { "report": [], "brokenFLCount": 0 }
    }
  };


  // AUDIT TRAIL REPORT
  audittrailpushingObj = async (newobj, type, event) => {
    if (this.props?.selectedMapData.assignedUsers && this.props?.selectedMapData?.assignedUsers?.length !== 0) {
      console.log("audit args ", newobj, type, event);
      this.setState((prevState) => {
        let tempAudiMap = cloneDeep([...prevState.auditInsideMap]);
        if (newobj.type === 'FLOWLINE') {
          tempAudiMap.push(newobj);
        }
        else if (newobj.type === 'DELETE_FLOWLINK') {
          tempAudiMap.push(newobj);
        } else if (newobj.type === 'REARRANGE') {
          const indexToCheck = tempAudiMap.findIndex(el =>
            el.id === newobj.id && el.type === newobj.type
          );
          if (indexToCheck === -1) {
            tempAudiMap.push(newobj);
          } else {
            console.log("Merging", tempAudiMap[indexToCheck], newobj);
            tempAudiMap[indexToCheck] = { ...tempAudiMap[indexToCheck], ...newobj };
          }
        }
        else if (newobj.type === 'DOCUMENT') {
          const value = tempAudiMap.findIndex(el =>
            el.newValue === newobj.newValue && el.type === newobj.type && el.id === newobj.id
          );
          if (value === -1) {
            tempAudiMap.push(newobj);
          }
        }
        else if (newobj.type === 'DATASOURCE') {
          const indexToCheck = tempAudiMap.findIndex(el =>
            el.id === newobj.id && el.type === newobj.type
          );
          if (indexToCheck === -1) {
            tempAudiMap.push(newobj);
          } else {
            console.log("Merging", tempAudiMap[indexToCheck], newobj);
            tempAudiMap[indexToCheck] = { ...tempAudiMap[indexToCheck], ...newobj };
          }
        }
        else {
          console.log(tempAudiMap);
          const value = tempAudiMap.findIndex(el =>
            el.id === newobj.id && el.type === newobj.type
          );
          if (value === -1) {
            tempAudiMap.push(newobj);
          } else {
            console.log("Updating", tempAudiMap[value], newobj);
            tempAudiMap[value] = { ...tempAudiMap[value], ...newobj };
          }
          // const updatedTempAudimap = tempAudiMap.filter(el => !(el.newValue.includes('Activity Created') && el.type.toLowerCase().includes('resource')))
          // tempAudiMap = updatedTempAudimap
        }
        console.log("After audit result :", tempAudiMap);
        return { auditInsideMap: tempAudiMap };
      });
    }
  };

  revertRearrangeFlag = () => {
    this.setState({
      editAutoNumflag: false
    })
  }


  render() {
    return (
      <>
        {this.props.isEditorOpen ?
          <AuthCommonLayout
            isMapLocked={this.state.isMapLocked}
            getIsUnSavedXMLExist={this.getIsUnSavedXMLExist}
            setTemplateBgColor={this.setTemplateBgColor}
            selectedMapData={this.props.selectedMapData}
            editAutoNumflag={this.state.editAutoNumflag}
            // handleReArrange={this.handleReArrange}
            headerPrimaryBtnOnClick={this.headerPrimaryBtnOnClick}
            // handleReArrangeCancel={this.handleReArrangeCancel}
            headerSecondaryBtnOnClick={this.headerSecondaryBtnOnClick}
            onDiagramNavOnclick={this.onDiagramNavOnclick}
            isEditorScreenActive={true}
            openCreateEditTemplate={this.openCreateEditTemplate}
            closeDialogPopupBox={this.closeDialogPopupBox}
            openApplyTemplate={this.openApplyTemplate}
            saveLatestXmlOnclick={this.saveLatestXmlOnclick}
            openIntegrityCheck={this.openIntegrityCheck}
          >
            <div id="defaultEditorTemplate">
              <div className="border-2px border-solid w-full h-4/5">
                <div className="flex justify-center resize-app-container">
                  {this.state.isTreeView ?
                    <ResizeCompIndex
                      mappingDiagrams={this.state.mappingDiagrams}
                      Role={this.state.userRole}
                      selectedMapData={this.props.selectedMapData}
                      onClickTreeViewItem={this.onClickTreeViewItem}
                      selectedNodeId={this.state.currentMapDet.id}
                      treeViewToggle={this.treeViewToggle}
                      onAddEditMapDiagramOpen={this.onAddEditMapDiagramOpen}
                      mapDiagramName={this.state.mapDiagramRecord.diagramName}
                    />
                    :
                    <div onClick={this.treeViewToggle} className="relative flex items-center bg-orange-400 mt-5 mb-5 p-1 border-b-2 rounded-r-lg h-[30px] cursor-pointer">
                      <IoChevronForward size={24} color="white" />
                    </div>
                  }
                  <div className="bg-transparent w-full resize-app-frame">
                    <div className="rounded-md font-[12px]">
                      <div className="animate-dropdown">

                        <EditBpmnToolHeader
                          isMapLocked={this.state.isMapLocked}
                          mapLevelOptions={this.props.mapLevelOptions}
                          onSlectMapTypeOnChange={this.props.onSlectMapTypeOnChange}
                          selectedMapType={this.props.selectedMapType}
                          revokeToDraftAPICALL={this.revokeToDraftAPICALL}
                          deleteRevokedDraftAPICALL={this.deleteRevokedDraftAPICALL}
                          isTreeView={this.state.isTreeView}
                          onDiagramNavOnclick={this.onDiagramNavOnclick}
                          openBpmnFileUpload={this.openBpmnFileUpload}
                          refreshBpmn_OnClick={this.refreshBpmn_OnClick}
                          downloadBpmnSVG_OnClick={this.downloadBpmnSVG_OnClick}
                          changeTemplate_Onclick={this.changeTemplate_Onclick}
                          zoomInOutBpmn_OnClick={this.zoomInOutBpmn_OnClick}
                          selectedLanguage={this.state.selectedLanguage}
                          handleSelectLanguageOnChange={this.handleSelectLanguageOnChange}
                          openAddDocument={this.openAddDocument}
                          handleAddDocFileOnChange={this.handleAddDocFileOnChange}
                          fileUploadRef={this.fileUploadRef}
                          saveLatestXmlOnclick={this.saveLatestXmlOnclick}
                          getIsUnSavedXMLExist={this.getIsUnSavedXMLExist}
                          OnprintClick={this.OnprintClick}
                          onClickAddResource={this.onClickAddResource}
                          onClickflowlinepopup={this.onClickflowlinepopup}
                          onClickEndTermination={this.onClickEndTermination}
                          editAutoNumflag={this.state.editAutoNumflag}
                          handleeditAutoNumflag={this.handleeditAutoNumflag}
                          // handleReArrange={this.handleReArrange}
                          // handleReArrangeCancel={this.handleReArrangeCancel}
                          rearrangeArray={this.state.rearrangeArray}
                          treeViewToggle={this.treeViewToggle}
                          onClickBpmnDownload={this.onClickBpmnDownload}
                          deleteStartActivityLoop={this.deleteStartActivityLoop}
                          selectedMapData={this.props.selectedMapData}
                          CurrentXmlId={this.state.currentMapDet.id}
                          onChangeComments={this.onChangeComments}
                          onCommentPostClick={this.onCommentPostClick}
                          comment={this.state.comment}
                          getcomment={this.state.getComment}
                          copiedComments={this.state.copiedComments}
                          onOpenComment={this.onOpenComment}
                          isCommentOpened={this.state.isCommentOpened}
                          closeDialogPopupBox={this.closeDialogPopupBox}
                          isDefaultTemplateEnable={this.state.isDefaultTemplateEnable}
                          openCreateEditTemplate={this.openCreateEditTemplate}
                          onPrintDiagram={this.onPrintDiagram}
                          currentMapDet={this.state.currentMapDet}
                          getActivityId={this.state.getActivity}
                          getActivityElementId={this.state.getActivityElementId}
                          getCurrentMapId={this.state.getCurrentMapId}
                          handleCommentsClick={this.handleCommentsClick}
                          onChangeReviewerSelect={this.onChangeReviewerSelect}
                          levelNavigationFlag={this.state.levelNavigationFlag}
                          handleCommentsEdit={this.handleCommentsEdit}
                          handleCommentsDelete={this.handleCommentsDelete}
                          isEditing={this.state.isEditing}
                          reArrangePopupFlag={this.state.reArrangePopupFlag}
                          handlerearrangePopupflag={this.handlerearrangePopupflag}
                          handleAutomatedReArrange={this.handleAutomatedReArrange}
                          getComment={this.state.getComment}
                          CommentsReaderStorage={this.state.CommentsReaderStorage}
                          mapDiagramRecord={this.state.mapDiagramRecord}
                          deleteAllComments={this.deleteAllComments}
                          publicUsers={this.props.publicUsers}
                          revertRearrangeFlag={this.revertRearrangeFlag}
                        />
                        <BpmnTool
                          {...this.state}
                          isActivityReplaceEnable={this.state.isActivityReplaceEnable}
                          selectedLanguage={this.state.selectedLanguage}
                          isMapLocked={this.state.isMapLocked}
                          diagramXML={this.state.diagramBpmnXML}
                          handleBpmnRef={this.handleBpmnRef}
                          mappingDiagrams={this.state.mappingDiagrams}
                          isDiagNavigationClicked={this.state.isDiagNavigationClicked}
                          currentMapDet={this.state.currentMapDet}
                          editAutoNumflag={this.state.editAutoNumflag}
                          rearrangeflag={this.state.rearrangeflag}
                          isTreeView={this.state.isTreeView}
                          filteredDataArray={this.state.filteredDataArray}
                          lastOccurances={this.state.lastOccurances}
                          mapDiagramRecord={this.state.mapDiagramRecord}
                          selectedMapData={this.props.selectedMapData}
                          templateBgColor={this.state.templateBgColor}
                          isDefaultTemplateEnable={this.state.isDefaultTemplateEnable}
                          resSavedData={this.state.userSavedData}
                          updateCurrDiagramXmlById={this.updateCurrDiagramXmlById}
                          onDiagramNavOnclick={this.onDiagramNavOnclick}
                          handleElementDblClickByTool={this.handleElementDblClickByTool}
                          setMappingDiagramsArray={this.setMappingDiagramsArray}
                          popupFlowlineActAvailable={this.popupFlowlineActAvailable}
                          deleteDocSharePointAPICALL={this.deleteDocSharePointAPICALL}
                          handleReArrangeActivity={this.handleReArrangeActivity}
                          getCurrentDiagramXML={this.getCurrentDiagramXML}
                          updateXmlByImportXML={this.updateXmlByImportXML}
                          targetFlowline={this.targetFlowline}
                          appliedTemplate={this.state.appliedTemplate}
                          onOpenComment={this.onOpenComment}
                          OnprintClick={this.OnprintClick}
                          openBpmnFileUpload={this.openBpmnFileUpload}
                          onClickBpmnDownload={this.onClickBpmnDownload}
                          zoomInOutBpmn_OnClick={this.zoomInOutBpmn_OnClick}
                          onClickAddResource={this.onClickAddResource}
                          openAddDocument={this.openAddDocument}
                          onClickflowlinepopup={this.onClickflowlinepopup}
                          openCloseALMConnectActivity={this.openCloseALMConnectActivity}
                          rearrangeArray={this.state.rearrangeArray}
                          handleeditAutoNumflag={this.handleeditAutoNumflag}
                          resourceData={this.state.resourceData}
                          getActivityId={this.getActivityId}
                          updateTreeIdsByBaseId={this.updateTreeIdsByBaseId}
                          setCopiedContentToRedux={this.props.setCopiedContentToRedux}
                          excludeDocumentIds={this.excludeDocumentIds}
                          audittrailpushingObj={this.audittrailpushingObj}
                          EditedResFlag={this.state.EditedResFlag}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {this.state.isDataSourceMappingEnable ? (
                <BpmnToolMap
                  openSpinnerRedux={this.openSpinnerRedux}
                  closeSpinnerRedux={this.closeSpinnerRedux}
                  element_data_id={this.state.element_data_id}
                  openCloseALMConnectActivity={this.openCloseALMConnectActivity}
                  saveALMConnectActivity={this.saveALMConnectActivity}
                  AvailabeDataSource={this.state.AvailabeDataSource}
                  handleBpmnRef={this.handleBpmnRef}

                />
              ) : null}
              {this.state.isALMTestCaseViewEnable ? (
                <ALMTestCase
                  openSpinnerRedux={this.openSpinnerRedux}
                  closeSpinnerRedux={this.closeSpinnerRedux}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  deleteALMOnClick={this.deleteALMOnClick}
                  almMappedTestcases={this.state.almMappedTestcases}
                  AlmDataSource={this.state.AlmDataSource}
                  selActivityName={this.state.selActivityName}
                  isMapLocked={(this.state.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
                    (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                    (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)))
                  }
                />
              ) : null}
              {this.state.IsUploadBpmn ? (
                <div>
                  <UploadBpmnPopup
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    uploadBpmnFileOnChange={this.uploadBpmnFileOnChange}
                    uploadBpmnFile_OnClick={this.uploadBpmnFile_OnClick}
                    selectedXmlFileName={this.state.selectedXmlFileName}
                    IsUploadBpmn={this.state.IsUploadBpmn}
                  />
                </div>
              ) : null}
              {this.state.flowLinePopup ? (
                <div>
                  <AddFlowLinePopup
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    onClickshowDiagram={this.onClickshowDiagram}
                    mappingDiagrams={this.state.mappingDiagrams}
                    currentMapDet={this.state.currentMapDet}
                    selectedIdFlowLine={this.state.selectedIdFlowLine}
                    onClickTreeFlowLine={this.onClickTreeFlowLine}
                    onShowActivityBox={this.onShowActivityBox}
                    revertRearrangeFlag={this.revertRearrangeFlag}
                  />
                </div>
              ) : null}
              {this.state.showFlowlinoepopupTarget ? (
                <div>
                  <AddFlowLineTargetPopup
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    onClickshowDiagram={this.onClickshowDiagram}
                    mappingDiagrams={this.state.mappingDiagrams}
                    currentMapDet={this.state.currentMapDet}
                    selectedIdFlowLine={this.state.selectedIdFlowLine}
                    onClickTreeFlowLine={this.onClickTreeFlowLine}
                    onShowActivityBox={this.onShowActivityBox}
                    editElementObj={this.state.editElementObj}
                    handleFlowlineClick={this.handleFlowlineClick}
                    flowlinkIdFinder={this.flowlinkIdFinder}
                    verifyTargetId={this.verifyTargetId}
                    findElementById={this.findElementById}
                    handleExpiredDeleteStartFlowActivity={this.handleExpiredDeleteStartFlowActivity}
                    handleDeleteFlowActivity={this.handleDeleteFlowActivity}
                  />
                </div>
              ) : null}
              {this.state.isActivitytextEnable ? (
                <div>
                  <ActivityNameTextPopup
                    editActNameTxtOnClick={this.editActNameTxtOnClick}
                    selActivityName={this.state.selActivityName}
                    selActivityType={this.state.selActivityType}
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    compHandleTextOnChange={this.compHandleTextOnChange}
                    compHandleTextOnChangeforInput={this.compHandleTextOnChangeforInput}
                  />
                </div>
              ) : null}
              {this.state.isPublishPopupEnable ? (
                <div>
                  <PublishDiagramPOPUP
                    mapDiagramRecord={this.state.mapDiagramRecord}
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    compHandleTextOnChange={this.compHandleTextOnChange}
                    compHandleTextOnChangeforInput={this.compHandleTextOnChangeforInput}
                    SubmitChangesChanges={this.SubmitChangesChanges}
                  />
                </div>
              ) : null}
              {this.state.isAddresouceOpen ? (
                <div>
                  <Resource
                    getAllusers={this.getAllusers}
                    onClickAddResource={this.onClickAddResource}
                    handleResourcePopup={this.handleResourcePopup}
                    selectedResources={this.state.selectedResources}
                    deleteResourceForActivity={this.deleteResourceForActivity}
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    openSpinnerRedux={this.openSpinnerRedux}
                    closeSpinnerRedux={this.closeSpinnerRedux}
                    EditResource={this.EditResource}
                    OnDeleteResource={this.OnDeleteResource}
                    resourceData={this.state.resourceData}
                  />
                </div>
              ) : null}
              {this.state.showFlowlinoepopup ? (
                <OnshowFlowlineActivity
                  fromViewer={(this.state.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
                    (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                    (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)))
                  }
                  flowLineStructure={this.state.flowLineStructure}
                  currentMapDet={this.state.currentMapDet}
                  mappingDiagrams={this.state.mappingDiagrams}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  handleFlowlineClick={this.handleFlowlineClick}
                  flowlinkIdFinder={this.flowlinkIdFinder}
                  verifyTargetId={this.verifyTargetId}
                  findElementById={this.findElementById}
                  handleDeleteFlowActivity={this.handleDeleteFlowActivity}
                  handleExpiredDeleteFlowActivity={this.handleExpiredDeleteFlowActivity}
                  editElementObj={this.state.editElementObj}
                />
              ) : null}
              {this.state.isActivityFileDocEnable ? (
                <ActivityFileDocuments
                  fromViewer={(this.state.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
                    (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                    (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)))
                  }
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  selActivityId={this.state.selActivityId}
                  selActivityDocFiles={this.state.selActivityDocFiles}
                  downloadDocSharePointAPICALL={this.downloadDocSharePointAPICALL}
                  deleteDocSharePointAPICALL={this.deleteDocSharePointAPICALL}
                />
              ) : null}
              {
                (this.state.isdownload || this.state.PrintLevel) ?
                  <DownloadDiagramPOPUP
                    onChangeRadioButton={this.onChangeRadioButton}
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    downloadBPMN_OnClick={this.downloadBPMN_OnClick}
                    isPrint={this.state.PrintLevel}
                    handlePrint={this.handlePrint}
                  />
                  : null
              }
              {
                this.state.createTemplateState ?
                  <CreateTemplate
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    newTemplateRecord={this.state.newTemplateRecord}
                    templatehandleOnChange={this.templatehandleOnChange}
                    openCreateEditTemplate={this.openCreateEditTemplate}
                    createTemplateOnClick={this.createTemplateOnClick}
                    selectedMapData={this.props.selectedMapData}
                    currentMapDet={this.state.currentMapDet}
                    mapDiagramRecord={this.state.mapDiagramRecord}
                  />
                  : null
              }

              {
                this.state.isApplyTemplateEnable ?
                  <ApplyTemplate
                    openApplyTemplate={this.openApplyTemplate}
                    closeDialogPopupBox={this.closeDialogPopupBox}
                    setTemplateBgColor={this.setTemplateBgColor}
                    openCreateEditTemplate={this.openCreateEditTemplate}
                    appliedTemplate={this.state.appliedTemplate}
                    selectedMapData={this.props.selectedMapData}
                    currentMapDet={this.state.currentMapDet}
                    mapDiagramRecord={this.state.mapDiagramRecord}
                  />
                  : null
              }
              {this.state.showActivityBoxMapping ?
                <OnshowActivityBoxComp
                  mapDiagramRecord={this.state.mapDiagramRecord}
                  xml={this.state.newDataFromConsole.diagramXML}
                  TreeviewId={this.state.selectedIdFlowLine}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  storingActivityBox={this.state.storingActivityBox}
                  flowLineStructure={this.state.flowLineStructure}
                  currentMapDet={this.state.currentMapDet}
                  mappingDiagrams={this.state.mappingDiagrams}
                  handleFlowlineClick={this.handleFlowlineClick}
                  flowlinkIdFinder={this.flowlinkIdFinder}
                  verifyTargetId={this.verifyTargetId}
                  findElementById={this.findElementById}
                  handleDeleteFlowActivity={this.handleDeleteFlowActivity}
                  handleExpiredDeleteFlowActivity={this.handleExpiredDeleteFlowActivity}
                  onBackActivityBox={this.onBackActivityBox}
                  addFlowLineActivity={this.addFlowLineActivity}
                  sourceAutoNum={this.state.sourceAutoNum}
                  audittrailpushingObj={this.audittrailpushingObj}
                />
                : null}
              {this.state.isSendToReviewer ?
                <AssignReviewierName
                  ReviewerData={this.state.ReviewerData}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  onChangeReviewerSelect={this.onChangeReviewerSelect}
                  draftMapStatusChnageOnClick={this.draftMapStatusChnageOnClick}
                  ReviewerName={this.props.selectedMapData.assignedUser}
                  Reviewername={this.state.Reviewername}
                />
                : null}
              {(this.state.FromReviewsentback || this.state.FromDiagramApprove) ?
                <div class="max-lg:p-10">
                  <ReactDialogBox
                    closeBox={this.closeDialogPopupBox}
                    modalWidth={localControlsConstant.Model.modalWidth}
                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                    headerTextColor={localControlsConstant.Model.bodybg}
                    headerHeight={localControlsConstant.Model.headerheight}
                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                    headerText={localControlsConstant.Model.modelConfirm}
                  >
                    <div>
                      <div class='flex items-center pl-7 max-lg:pl-2 h-16 max-lg:h-8'>
                        {this.state.FromReviewsentback ? <h1>{BPMNEditor_Labels._ARE_YOU_SURE_YOU_WANT_TO_REVERT_TO_EDITOR}</h1> : <h1>{BPMNEditor_Labels._ARE_YOU_SURE_WANT_TO_APPROVE_THE_DIAGRAM} <span className='text-blue-500'>{this.state.mapDiagramRecord.diagramName}</span>?</h1>}
                      </div>
                      <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                        <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                          onClick={() => { this.state.FromReviewsentback ? this.draftMapStatusChnageOnClick('InProgress', BPMN_Editor_Toaster.Map_Successfully_Reverted_To_Editor) : this.draftMapStatusChnageOnClick('Approved', BPMN_Editor_Toaster.Map_Approved_Successfully) }} >{BPMNEditor_Labels._YES_BTN}</button>
                        <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                          onClick={this.closeDialogPopupBox}>{BPMNEditor_Labels._CANCEL_BTN}
                        </button>
                      </div>

                    </div>
                  </ReactDialogBox>
                </div>
                : null
              }
              <ReactToPrint
                trigger={() => <></>}
                content={() => this.diagramListRef.current}
                onAfterPrint={() => {
                  this.handleAfterPrint()
                  this.closeSpinnerRedux();
                }
                }
                ref={this.printRef}
              />

              {this.state.isIntegrityCheckEnable ?
                <IntegrityCheckPopup
                  openIntegrityCheck={this.openIntegrityCheck}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  onChangeRadioButton={this.onChangeRadioButton}
                  integrityCheckOnChangeHandler={this.integrityCheckOnChangeHandler}
                  integrityCheckOnClick={this.integrityCheckOnClick}
                  IC_objectsChecked={this.state.IC_objectsChecked}
                />
                : null}
              {this.state.isICReportExportEnable ?
                <IntegrityCheckReport
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  integrityCheckReport={this.state.integrityCheckReport}
                  IC_objectsChecked={this.state.IC_objectsChecked}
                />
                : null}
              {this.state.isReqOrTestcaseEnable ?
                <ALMReqTestCaseChoose
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  onALMReqOrTestSelectOnClick={this.onALMReqOrTestSelectOnClick}
                />
                : null}
              <div className="hidden-print" ref={this.diagramListRef}>
                {this.state.renderedDiagrams}
              </div>
            </div>
          </AuthCommonLayout>
          : null}
      </>
    );
  };
}
// const mapStateToProps = (state) => ({
//   isSpinnerLoading: state.isSpinnerLoading,
// });

// const mapDispatchToProps = (dispatch) => ({
//   // toggleSpinnerFlag: (value) => dispatch({type: "SET_SPINNER_LOADING", payload: value }),
//   getActivityId:()=>  dispatch({ type: "GET_ACTIVITY_ID", payload: this.state.getActivity })
// })
export default (BpmnEditor);