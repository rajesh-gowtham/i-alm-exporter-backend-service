import BpmnColorPickerModule from "bpmn-js-color-picker";
import 'bpmn-js-embedded-comments/assets/comments.css';
import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule, } from "bpmn-js-properties-panel";
import resizeTask from 'bpmn-js-task-resize/lib';
import camundaModdleDescriptors from "camunda-bpmn-moddle/resources/camunda.json";
import { cloneDeep, isNumber, isArray } from "lodash";
import React from "react";
import { isValidValue, navIcons, PopupMenu } from "../../CommonUtils/ComponentUtil.jsx";
import "../../CommonUtils/CustomBPMNComments/CustomBPMNStyle.css";
import CustomBPMNComments from "../../CommonUtils/CustomBPMNComments/Index.js";
import CustomBPMNDocuments from "../../CommonUtils/CustomBPMNDocumentClip/CustomDocIndex.js";
import CustomBPMNALMDatasource from "../../CommonUtils/CustomBPMN_ALMDatasource/CustomBPMN_ALMIndex.js";
import customBPMNProcessActivity from "../../CommonUtils/CustomBPMNProcessIndex/CustomBPMNProcessIndex.js";
import { ErrorMessage } from "../../CommonUtils/CustomToast";
import { BPMN_Common_Labels, Default_Template_Labels } from "../../Constants/COMMON_LABELS.jsx";
import { BPMN_Editor_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS.jsx";
import pncLOGO_v1 from "../../Images/pncLOGO_v1.png";
import Store from "../../Redux/Store.jsx";
import { getXmlDiagram } from "../BpmnDiagrams/getBpmnDiagrams";
import CustomBpmnModeler from "./CustomRenderModules/CustomBpmnModeler.jsx";
import CustomContextPadProvider from './CustomRenderModules/DeleteElementinterface.js';
import customReplacePadProvider from "./CustomRenderModules/customReplacePadProvider.jsx";

//SCREEN ID -3000

export const extraActivityElements = ["bpmn:SubProcess", "bpmn:UserTask", "bpmn:ServiceTask", "bpmn:SendTask", "bpmn:ReceiveTask", "bpmn:ManualTask", "bpmn:BusinessRuleTask", "bpmn:ScriptTask", "bpmn:CallActivity", "bpmn:SubProcess"]
var isActivityReplaceEnable = false
class BpmnTool extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isPropPanelEnable: false,
      count: 1,
      prevCount: 0,
      updatedArrayCurrent: [],
      menuPosition: { x: 0, y: 0 },
      menuOpen: false,
    };
    this.containerRef = React.createRef();
  }
  copySelectOnClick = async () => {
    // element to be copied
    let element = this.bpmnModeler.get('selection')._selectedElements[0];
    console.log('selection', element, this.bpmnModeler.get('selection'));
    if (element === null || element === undefined) {
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
      return;
    }
    const elementid = element?.id;
    if (elementid === null || elementid === undefined || elementid === "" || elementid === "Process_0tz6k3o" || (!elementid?.includes("Activity"))) {
      ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
      return;
    }
    if (element.type === "bpmn:SubProcess") {
      if (!element.collapsed) {
        ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Activity);
        return;
      }
      const tempMappDiags = [...this.props.mappingDiagrams];
      const tempCurrMap = this.props.currentMapDet;
      console.log(tempCurrMap, tempMappDiags);
      const version = tempCurrMap?.id + "." + element.businessObject.$attrs.AutoNumCount;
      let currentAndLowerResults = {};
      function getChildDiagramXml(arr, parentId) {
        for (let i = 0; i < arr.length; i++) {
          console.log(arr[i].id === parentId, arr[i]);
          if (arr[i].id === parentId) {
            currentAndLowerResults = arr[i]
            return arr[i];
          } else if (arr[i].children.length === 0) {
            continue;
          }
          else {
            getChildDiagramXml(arr[i].children, parentId);
          }
        }
        return "";
      }
      await getChildDiagramXml(tempMappDiags, version);
      console.log(currentAndLowerResults);
      let exportResult = await this.props.excludeDocumentIds(cloneDeep([currentAndLowerResults]))
      console.log(exportResult);
      await this.props.setCopiedContentToRedux({ element: element, content: exportResult[0] })
    } else {
      await this.props.setCopiedContentToRedux({ element: element, content: {} })
    }
    this.handleCloseMenu()
    // element.businessObject.$attrs.copiedLevels = JSON.stringify(currentAndLowerResults)
    // console.log("element ", element)
    // copyPaste.copy(element);
    // const copied = clipboard.get();
    // const canvas = this.bpmnModeler.get('canvas');
    // const rootElement = canvas.getRootElement();
    // console.log('copied ', copied);
    // copyPaste.paste({
    //   element: rootElement,
    //   point: {
    //     x: 400,
    //     y: 10
    //   }
    // });
    // localStorage.setItem('bpmnClipboard', JSON.stringify(copied));
    this.handleCloseMenu()
  }
  pasteSelectOnClick = async () => {
    // Convert to canvas coordinates
    const { element, content } = Store.getState().copiedLowerLevels;
    console.log("copiedResult ", element, content)
    if (element === undefined || element === null) {
      ErrorMessage("No Copied element found")
      return
    }
    const clientX = this.state.menuPosition.x;
    const clientY = this.state.menuPosition.y;
    // console.log("clientX, clientY ", clientX, clientY)
    // console.log(" this.bpmnCanvas ", this.bpmnCanvas)
    const viewbox = this.bpmnCanvas.viewbox();

    // Convert the client coordinates to canvas coordinates
    const canvasPosition = {
      x: (clientX - this.bpmnCanvas._container.getBoundingClientRect().left) / viewbox.scale + viewbox.x,
      y: (clientY - this.bpmnCanvas._container.getBoundingClientRect().top) / viewbox.scale + viewbox.y
    };
    console.log("canvasPosition ", canvasPosition)

    const newElement = {
      type: element.type,
      x: canvasPosition.x,
      y: canvasPosition.y,
      width: element.width,
      height: element.height
    };

    // Create the element on the canvas
    let rootElementToCreate = this.bpmnCanvas.getRootElement();
    if (this.bpmnCanvas._rootElement.type === "bpmn:Collaboration") {
      const ParticipantShapes = this.bpmnElementRegistry.filter(element => element.type === "bpmn:Participant")
      // console.log("ParticipantShapes ", ParticipantShapes)
      rootElementToCreate = ParticipantShapes[0]
      if (ParticipantShapes.length > 1) {
        let element = this.bpmnModeler.get('selection')._selectedElements[0];
        // console.log('selection', element, this.bpmnModeler.get('selection'));
        if (element && element.type === "bpmn:Participant") {
          rootElementToCreate = element
        } else {
          ErrorMessage("Please select a participant to paste")
          return
        }

      }
    }
    // isActivityReplaceEnable = true
    const newShapeImpl = await this.bpmnModeling.createShape(newElement, canvasPosition,
      rootElementToCreate
    );
    console.log("newShapeImpl ", newShapeImpl.businessObject.$attrs.AutoNumCount)

    const oldElement = {
      id: element.id,
      AutoNumCount: element.businessObject.$attrs?.AutoNumCount,
      x: element.x,
      y: element.y,
      width: element.width,
      height: element.height,
      tempBussObjAttr: element.businessObject.$attrs,
    }
    console.log("element.businessObject.$attrs ", element.businessObject.$attrs)
    let count = this.state.count + 1
    const pushAuditObject = {
      diagramLevel: this.props.currentMapDet.id,
      id: newShapeImpl.id,
      AutoNumCount: oldElement.AutoNumCount,
      type: "COPY_PASTE",
      field: "Copy_Paste",
      oldValue: `${this.props.currentMapDet.id} (${element.businessObject.$attrs.AutoNumCount}) - ${element.type}`,
      newValue: `${this.props.currentMapDet.id} (${count}) - ${newShapeImpl.type}`,
    }
    this.props.audittrailpushingObj(pushAuditObject, "COPY_PASTE");
    const resultShape = await this.createAndReplaceAttrShapes(oldElement, newShapeImpl, "FROM_COPYPASTE")
    console.log("resultShape ", resultShape)
    const tempBussObjAttr = resultShape;
    this.bpmnModeling.updateProperties(newShapeImpl, {
      name: tempBussObjAttr.fullNametxt
    });
    newShapeImpl.businessObject.$attrs.fullNametxt = tempBussObjAttr.fullNametxt;
    newShapeImpl.businessObject.$attrs.AutoNumCount = tempBussObjAttr.AutoNumCount;
    newShapeImpl.businessObject.$attrs.mapped_Child_Ids = tempBussObjAttr.mapped_Child_Ids;
    console.log("newShapeImpl ", newShapeImpl)
    this.handleCloseMenu()
    // retrieve from local storage
    // var serializedCopy = localStorage.getItem('bpmnClipboard');
    // console.log("serializedCopy ", serializedCopy)

    // parse tree, reinstantiating contained objects
    // var parsedCopy = JSON.parse(serializedCopy, this.createReviver(moddle));

    // put into clipboard
    // clipboard.set(parsedCopy);

    // paste tree directly
    // copyPaste.paste({
    //   element: rootElement,
    //   point: {
    //     x: 400,
    //     y: 10
    //   }
    // });

    // alternatively paste using two-step pasting
    // copyPaste.paste();
    this.handleCloseMenu()
  }

  async componentDidMount() {
    const { diagramXML } = this.props;

    const { onOpenComment, OnprintClick, openBpmnFileUpload, onClickBpmnDownload, zoomInOutBpmn_OnClick, onClickAddResource, openAddDocument, onClickflowlinepopup, handleeditAutoNumflag, rearrangeArray, editAutoNumflag, handleElementDblClickByTool } = this.props;
    const container = this.containerRef.current;
    this.bpmnModeler = new CustomBpmnModeler({
      container: container,
      propertiesPanel: {
        parent: "#propview",
      },

      bpmnRenderer: {
        //  defaultFillColor: '#ff9f43',//'#333'
        // defaultStrokeColor: '#ffbf47'
      },

      keyboard: {
        bindTo: window,
      },
      // position: "left",
      // width: 1170,
      // height: 700,
      // bpmnRenderer: {
      //   defaultFillColor: '#11174a',//'#333'
      //   defaultStrokeColor: '#ffbf47'
      // },//'#fff'
      additionalModules: [resizeTask, CustomBPMNComments, BpmnPropertiesProviderModule, BpmnPropertiesPanelModule, BpmnColorPickerModule, CustomContextPadProvider, customReplacePadProvider, CustomBPMNDocuments, CustomBPMNALMDatasource ,  customBPMNProcessActivity],
      moddleExtensions: {
        camunda: [camundaModdleDescriptors],
      },
      taskResizingEnabled: true,
      // eventResizingEnabled: true
      customActions: {
        onOpenComment: onOpenComment,
        OnprintClick: OnprintClick,
        openBpmnFileUpload: openBpmnFileUpload,
        onClickBpmnDownload: onClickBpmnDownload,
        zoomInOutBpmn_OnClick: zoomInOutBpmn_OnClick,
        onClickAddResource: onClickAddResource,
        openAddDocument: openAddDocument,
        onClickflowlinepopup: onClickflowlinepopup,
        handleeditAutoNumflag: handleeditAutoNumflag,
        handleElementDblClickByTool: handleElementDblClickByTool,
        state: this.state,
        props: this.props,
      },
      rearrangeArray: rearrangeArray,
      editAutoNumflag: editAutoNumflag,
    });
    this.props.handleBpmnRef.current = this;
    this.eventBus = this.bpmnModeler.get("eventBus");
    this.bpmnCanvas = this.bpmnModeler.get("canvas");
    this.bpmnModeling = this.bpmnModeler.get("modeling");
    this.bpmnElementFactory = this.bpmnModeler.get("elementFactory");
    this.bpmnElementRegistry = this.bpmnModeler.get("elementRegistry");
    this.bpmnKeyboard = this.bpmnModeler.get("keyboard");
    // console.log("eventBus ", this.eventBus)
    // console.log("bpmnCanvas ", this.bpmnCanvas)
    // console.log("bpmnModeling ", this.bpmnModeling)
    // console.log("bpmnElementFactory ", this.bpmnElementFactory)
    // console.log("bpmnElementRegistry ", this.bpmnElementRegistry)
    // console.log("bpmnKeyboard ", this.bpmnKeyboard);


    this.eventBus.on("commandStack.shape.replace.preExecute", async (event) => {
      if (event.context?.oldShape?.id?.includes("Activity") || event.context?.newShape?.id?.includes("Activity")) {
        console.log("replace enabling flag ON ", event);
        isActivityReplaceEnable = true;
        await this.props.setMappingDiagramsArray("isActivityReplaceEnable", true);
      }
      // if (event.context.oldShape.businessObject.$attrs?.mapped_Child_Ids?.includes("Document")) {
      // }
    })

    this.eventBus.on('import.render.complete', async (event) => {
      // console.log(event);
      const bpmnCanvas = this.bpmnModeler.get('canvas');
      const bpmnModeling = this.bpmnModeler.get('modeling');
      const resourceElements = await bpmnCanvas._elementRegistry.filter((el => el.id.includes("Actor")))
      // console.log("resourceElements ", resourceElements)
      // const resourceElements= await bpmnCanvas._elementRegistry.filter((el=>el.id.includes("Actor") && el.businessObject.$attrs?.resourceId===Resource.id))
      const isMapLocked = this.props.isMapLocked;
      // console.log("isMapLocked ", isMapLocked, this.props.selectedLanguage.value)
      if ((!isMapLocked) && this.props.selectedLanguage.value === "en") {
        let isMapResUpdated = false;
        // console.log(this.props.resourceData);
        resourceElements.forEach(async (tempResData, index) => {
          console.log(" tempResData", tempResData)
          const findData = this.props.resourceData.find((res) => tempResData?.businessObject?.$attrs?.resourceId === res.id)
          console.log(" findData ", findData);
          if (findData) {
            if (findData.type !== tempResData.businessObject.$attrs?.resourceType) {
              // D301 - ResourceName color - Machine/FTE
              bpmnModeling.updateProperties(tempResData, {
                resourceType: findData.type
              })
              bpmnModeling.setColor(tempResData, {
                fill: findData.type === "SYSTEM" ? '#fec76f' : '#bbdefb',
              });
            }
            if (findData.displayName !== tempResData.businessObject.$attrs?.fullNametxt) {
              console.log(findData.displayName)
              bpmnModeling.updateProperties(tempResData, {
                name: findData.displayName,
                fullNametxt: findData.displayName
              })
              isMapResUpdated = true;
            }
          } else {
            const parentElement = this.bpmnElementRegistry.get(tempResData.businessObject.$attrs.parentActivityId)
            console.log("parentElement ", parentElement)
            const parentAllResIds = parentElement?.businessObject?.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (id?.includes("Actor")))
            let parentRemainIds = parentElement?.businessObject?.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (!id?.includes("Actor")))
            console.log("parentRemainIds ", parentRemainIds)
            const allResElements = this.bpmnElementRegistry.filter((el => parentAllResIds?.includes(el.id)))
            let positionRes = []
            console.log(allResElements)
            allResElements.forEach((res) => {
              if (tempResData.id !== res.id) {
                console.log(res.id)
                parentRemainIds = parentRemainIds + "," + res.id
              }
              if (tempResData.y < res.y) {
                positionRes.push(res)
              }
            })
            console.log("parentRemainIds - parentElement", parentRemainIds, parentElement);
            if (parentElement) {
              bpmnModeling.updateProperties(parentElement, {
                mapped_Child_Ids: isArray(parentRemainIds) ? parentRemainIds.toString() : parentRemainIds
              });
              console.log(" deleted tempResData ", positionRes, tempResData);
              await bpmnModeling.removeElements([tempResData])
              if (positionRes?.length !== 0) {
                console.log(positionRes)
                // bpmnModeling.moveElements(positionRes, {
                //   x: 0,//(dragParentX + (width - 40)) - positionRes[0].x,
                //   y: -25,//(((dragParentY + 8) - positionRes[0].y))
                // });
              }
            }
            //  else {
            //   this.bpmnElementRegistry.forEach((element) => {
            //     console.log(" elemen", element)
            //     if (element.id?.includes("Activity") && (!element.id?.includes("Actor"))) {
            //       const tempResIds = element?.businessObject?.$attrs.mapped_Child_Ids?.split(',')?.filter(id => (id?.includes("Actor")))
            //       console.log("tempResIds ", tempResIds)
            //       if (tempResIds?.includes(tempResData))
            //         console.log(" findedddd ", tempResData, element)
            //       tempResData.businessObject.$attrs.parentActivityId = element.id;
            //       bpmnModeling.updateProperties(tempResData, {
            //         parentActivityId: element.id
            //       });
            //     }
            //   })
            // }
            isMapResUpdated = true;
          }
          if (index === resourceElements.length - 1 && isMapResUpdated) {
            const tempResData = { ...this.props.resSavedData }
            console.log("77777 tempResData ", tempResData)
            if (tempResData.xmlData) {
              let resArray;
              resArray = JSON.parse(tempResData.xmlData);
              console.log("77777 resArray ", resArray)
              const updatedArray = await this.props.updateCurrDiagramXmlById(resArray, this.props.currentMapDet.id)
              console.log("updatedArray ", updatedArray)
              tempResData.xmlData = JSON.stringify(updatedArray)
              // console.log("tempResData ", tempResData)
              this.props.setMappingDiagramsArray("resSavedData", tempResData)
            }
          }
        });
      }

      let autoNumCount = 0;
      await bpmnCanvas._elementRegistry.forEach((item) => {
        if ((item.type === "bpmn:Task" || extraActivityElements.includes(item.type)) && item.height >= 80) {
          const tempAutoNum = Number(item.businessObject.$attrs.AutoNumCount);
          if (autoNumCount < tempAutoNum) {
            autoNumCount = tempAutoNum
          }
          // console.log(autoNumCount, "item", tempAutoNum, item);
        }
        bpmnCanvas?.zoom('fit-viewport', 'center');
      });

      setTimeout(async () => {
        await this.props.setMappingDiagramsArray("isDiagNavigationClicked", true);
      }, 1500);

      this.setState({
        count: autoNumCount,
      })
      bpmnCanvas.zoom('fit-viewport', "center");
    })
    this.eventBus.on("element.click", 1500, (e) => {
      console.log(e.element.type, " ", e.element.businessObject.$attrs, e);
      const currElementId = e.element.id;
      this.props.getActivityId(e)
      if (e.element.type === 'bpmn:EndEvent' && e.element.id.includes('FLE')) {
        console.log(e);
        this.props.popupFlowlineActAvailable(e);
        e.stopPropagation();
      }
      if (e.element.type === 'bpmn:StartEvent' && e.element.id.includes('FLS')) {
        this.props.targetFlowline(e);
        e.stopPropagation();
      }
      if (e.element.id.includes('Group')) {
        e.stopPropagation();
        e.preventDefault();
      }
      if (currElementId.includes("Actor") || e.element.height === 25 || (e.element.id.includes("AutoNum"))) {
        e.stopPropagation();
        e.preventDefault();

      }
      this.bpmnModeler.get('comments').collapseAll();

    });

    // this.eventBus.on("element.hover", 1500, (e) => {
    //   if ((e.element.type === 'bpmn:Task' && e.element.height !== 25) || extraActivityElements.includes(e.element.type)) {
    //     let tooltips = this.bpmnModeler.get("tooltips");
    //     let businessObject = e.element.businessObject;
    //     let value = businessObject.$attrs.fullNametxt;
    //     if (value && value !== undefined && value !== null && value !== "" && value.length > 20) {
    //       let toolTipText = ` <div style="position: relative; width: 300px ; color: #717D7E; padding: 12px; border: 1px solid #BDC3C7; background-color: #ffffff; font-size: small; border-radius: 4px;">${value}<div style="position: absolute; top: 50%; left: -10px; width: 0; height: 0; border-top: 10px solid transparent; border-bottom: 10px solid transparent; border-right: 10px solid #BDC3C7; transform: translateY(-50%);"></div></div>`;
    //       let toolTipId = 'toolTipId' + e.element.id;
    //       tooltips.remove(toolTipId);
    //       let xx = e.element.x + (e.element.width / 3);
    //       let yy = e.element.y + (e.element.height / 4)

    //       toolTipId = tooltips.add({
    //         position: {
    //           x: xx,
    //           y: yy
    //         },
    //         id: toolTipId,
    //         timeout: 1000,
    //         html: toolTipText
    //       });

    //     } else {
    //       let toolTipId = 'toolTipId' + e.element.id;
    //       return tooltips.remove(toolTipId);
    //     }
    //   }
    // });

    this.eventBus.on("element.dblclick", 1500, (e) => {
      if (
        (this.props.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
          (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
          (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)))
      ) {
        if (!e.element?.id.includes('Document')) {
          e.stopPropagation();
          e.preventDefault();
          return
        }
      }
      console.log("dblclick ", e);
      if ((e.element?.id.includes("label")) && ((e.element.businessObject.$type === "bpmn:Group") && (e.element.type === 'label') && !this.props.editAutoNumflag)) {

        e.preventDefault();
        e.stopPropagation()
      }
      const tempBussObj = e.element.businessObject;
      const tempBussObjAttr = e.element.businessObject.$attrs;
      if (e.element?.type === "bpmn:DataObjectReference") {
        this.props.handleElementDblClickByTool(e, "FILE", tempBussObj?.name, tempBussObjAttr);
        e.stopPropagation();
        e.preventDefault();
      }
      if (e.element.id.includes("Actor")) {
        if (e.element.id.includes("Actor") || (e?.element.type === "label" && e?.element?.businessObject?.id.includes("AutoNum"))) {
          e.stopPropagation();
          e.preventDefault();
        }
      } else if (e.element.type === "bpmn:Task" || extraActivityElements.includes(e.element.type)) {
        if (this.props.editAutoNumflag) {
          ErrorMessage(BPMN_Editor_Toaster.Please_Do_The_Rearrange_And_Move_Forward)
          return
        }
        let tempName = "";
        console.log("  eee ", tempBussObj);
        if (!tempBussObj.$attrs.fullNametxt) {
          tempBussObj.$attrs.fullNametxt = "";
        } else {
          tempName = tempBussObj.$attrs.fullNametxt;
        }
        this.bpmnModeler.get("modeling").updateProperties(e.element, {
          name: tempName//.length > 25 ? tempName.substring(0, 25) + "..." : tempName,
        });
        this.props.handleElementDblClickByTool(e, "RENAME", tempName);
      }
    });

    this.eventBus.on("directEditing.cancel", async (e) => {
      const bpmnCanvas = this.bpmnModeler.get('canvas');
      console.log(e);
      const autoNumFinder = await bpmnCanvas._elementRegistry.filter((item) => item.id.includes("AutoNum_") && item.type === "bpmn:Group");
      console.log(autoNumFinder);
      const mappingAutoNumcount = await autoNumFinder.map((el, index) => bpmnCanvas._elementRegistry.get(el.businessObject.$attrs.parentActivityId).businessObject.$attrs.AutoNumCount).map(el => el + '');
      console.log(mappingAutoNumcount);
      const regex = /^[0-9]+$/;
      if (e.active.element?.id.includes("Activity") && (!e.active.element.businessObject.$type === "bpmn:Group")) {
        const tempBussObj = e.active.element.businessObject;
        if (!tempBussObj.$attrs.fullNametxt) {
          tempBussObj.$attrs.fullNametxt = tempBussObj.name ? tempBussObj.name : "";
        }
        try {
          this.bpmnModeler.get("modeling")
            .updateProperties(e.active.element, {
              name: tempBussObj.$attrs.fullNametxt//?.length > 25 ? tempBussObj.$attrs?.fullNametxt.substring(0, 25) + "..." : tempBussObj.$attrs.fullNametxt,
            });
        } catch (error) {
          console.error(error);
        }
      }
      if (((e.active.element.businessObject.$type === "bpmn:Group") && e.active.element.type === 'label')) {
        this.setState({
          ActivityLoop: {}
        })
        let filteredDataArray = this.props.filteredDataArray
        let lastOccurrences = this.props.lastOccurances;
        const parentID = e?.active.element?.id
        const parentActivityId = bpmnCanvas._elementRegistry.get(parentID)
        console.log(parentActivityId);
        console.log(parentID);
        let newValue = e.active.element.businessObject.categoryValueRef.value
        console.log(typeof newValue);

        if (regex.test(newValue)) {
          if (parseInt(newValue) > 0) {
            if (mappingAutoNumcount.includes(newValue + '')) {
              ErrorMessage(BPMN_Editor_Toaster.Sequence_Number_Is_Repeated_So_Do_The_Changes_And_Retry);
              const parentActivityId = bpmnCanvas._elementRegistry.get(e.active.element.businessObject.$attrs.parentActivityId)
              console.log(parentActivityId);
              const parentActivityIdLabel = bpmnCanvas._elementRegistry.get(e.active?.element?.businessObject?.id)
              console.log(parentActivityIdLabel);
              const values = parentActivityId.businessObject.$attrs.AutoNumCount;
              console.log(values);
              const bpmnModeling = this.bpmnModeler.get('modeling');
              bpmnModeling.updateLabel(parentActivityIdLabel, values + '');
              // parentActivityIdLabel.businessObject.categoryValueRef['value']='69'
              console.log(parentActivityIdLabel);
              return;
            }
            else {
              console.log("not same");

            }
            console.log("not empty");
            const parentActivityId = bpmnCanvas._elementRegistry.get(e.active.element.businessObject.$attrs.parentActivityId)
            if (extraActivityElements.includes(parentActivityId.type) || parentActivityId.type === 'bpmn:Task') {
              let oldValue = parentActivityId.businessObject.$attrs.AutoNumCount
              let constructObjLoop = { 'newValue': newValue, 'oldValue': oldValue, 'parentActivityId': parentActivityId.id, currentMapId: this.props.currentMapDet.id }
              filteredDataArray.push(constructObjLoop)
              filteredDataArray.forEach(item => {
                lastOccurrences[item.parentActivityId] = item;
              });
              const filteredData = Object.values(lastOccurrences);
              console.log(filteredData);

              // parentActivityId.businessObject.$attrs.AutoNumCount = newValue
              const bpmnCanvas = this.bpmnModeler.get('canvas');
              const elementFinder = await bpmnCanvas._elementRegistry.filter(item => item.id.includes("AutoNum_") && (item.type === "bpmn:Group"));
              console.log(elementFinder);
              const elementFinderLoop = elementFinder.map(el => el.businessObject.categoryValueRef.value)
              console.log("elementFinderLoop", elementFinderLoop);
              this.props.handleReArrangeActivity(filteredData, elementFinderLoop)
            }
          }
          else {
            ErrorMessage("Please enter greater than 0")
            const parentActivityId = bpmnCanvas._elementRegistry.get(e.active.element.businessObject.$attrs.parentActivityId)
            console.log(parentActivityId);
            const parentActivityIdLabel = bpmnCanvas._elementRegistry.get(e.active?.element?.businessObject?.id)
            console.log(parentActivityIdLabel);
            const values = parentActivityId.businessObject.$attrs.AutoNumCount;
            console.log(values);
            const bpmnModeling = this.bpmnModeler.get('modeling');
            bpmnModeling.updateLabel(parentActivityIdLabel, values + '');
            // parentActivityIdLabel.businessObject.categoryValueRef['value']='69'
            console.log(parentActivityIdLabel);
          }
        }
        else {
          ErrorMessage('Please enter only number')
          console.log(e);
          // const parentActivityId = bpmnCanvas._elementRegistry.get(e.active.element?.id.substring(8,24))
          const parentActivityId = bpmnCanvas._elementRegistry.get(e.active.element.businessObject.$attrs.parentActivityId)
          console.log(parentActivityId);
          const parentActivityIdLabel = bpmnCanvas._elementRegistry.get(e.active?.element?.businessObject?.id)
          console.log(parentActivityIdLabel);
          const values = parentActivityId.businessObject.$attrs.AutoNumCount;
          console.log(values);
          const bpmnModeling = this.bpmnModeler.get('modeling');
          bpmnModeling.updateLabel(parentActivityIdLabel, values + '');
          // parentActivityIdLabel.businessObject.categoryValueRef['value']='69'
          console.log(parentActivityIdLabel);
          return;
        }
      }
    })




    this.eventBus.on("commandStack.shape.create.postExecute", 1000, async (event) => {
      // console.log("commandStack.shape.create.postExecute", event);
      const parent_Id = event.context.shape.id
      const parent_IdX = event.context.shape.x
      const parent_IdY = event.context.shape.y
      // if (event.context.shape.id.includes('Activity') && event.context.shape.height === 80 && event.context.shape.type !== "bpmn:SubProcess") {
      console.log(isActivityReplaceEnable, this.props.isActivityReplaceEnable)
      if (event.context.shape.id.includes('Activity') && event.context.shape.height >= 80) {
        if (isActivityReplaceEnable || (event.context.shape.type === "bpmn:SubProcess" && event.context.shape.collapsed === true)) {
          // if ((event.context.shape?.type === "bpmn:SubProcess" && event.context.shape?.collapsed)) {
          console.log("Replace Enabled");
          // isActivityReplaceEnable = false
          return
        }
        console.log("commandStack.shape.create.postExecute", event);
        const bpmnCanvas = this.bpmnModeler.get('canvas');
        const bpmnModeling = this.bpmnModeler.get('modeling');
        const newAutoNumBox = this.bpmnElementFactory.createShape({ type: 'bpmn:Group' });
        // Auto numbering inside activty
        bpmnModeling.createShape(newAutoNumBox, { x: event.context.shape.x + (event.context.shape.width / 2), y: event.context.shape.y, height: 0, width: 0 },
          bpmnCanvas.getRootElement()
        );
        const elementFinder = await bpmnCanvas._elementRegistry.filter(el => el.x === parent_IdX && el.y === parent_IdY);
        console.log(elementFinder, "elementfinder", elementFinder[elementFinder.length - 1]);

        if (elementFinder.length === 1) {
          console.log("else if");
          this.setState({ count: (this.state.count + 1) }, () => {
            const businessObj = bpmnCanvas._elementRegistry.filter(el => el.id === parent_Id);
            console.log("@@@@ ", parent_Id, businessObj);
            const AutoNumUpdatedId = "AutoNum_" + newAutoNumBox.id;
            newAutoNumBox.businessObject.$attrs.parentActivityId = parent_Id
            businessObj[0].businessObject.$attrs.AutoNumCount = this.state.count
            const firstElementMapIds = businessObj[0].businessObject.$attrs.mapped_Child_Ids;
            const restMapIds = firstElementMapIds === "" || firstElementMapIds === undefined ? [] : firstElementMapIds?.split(',')?.filter(id => !(id.includes("AutoNum_")))
            console.log("999999", restMapIds)
            businessObj[0].businessObject.$attrs.mapped_Child_Ids = restMapIds?.length > 0 ? restMapIds.join(',') + "," + AutoNumUpdatedId : AutoNumUpdatedId
            console.log("businessObj ", businessObj[0])
            bpmnModeling.updateLabel(newAutoNumBox, this.state.count + "");
            bpmnModeling.updateProperties(newAutoNumBox, {
              id: AutoNumUpdatedId,
            });

            bpmnModeling.setColor(newAutoNumBox, {
              fill: '#fff', //'#bbdefb',
              stroke: '#fff', //'#bbdefb'
            })
            bpmnModeling.setColor(newAutoNumBox.labels, {
              stroke: '#000',
              // stroke: '#ffbf47',
            })
            bpmnModeling.moveElements(newAutoNumBox.labels, {
              x: -1,
              y: -3
            });
          });
        }
      }
    })

    this.eventBus.on("resize.cleanup", (e) => {
      console.log(e.type, e.shape.width, e);
      const mapped_Child_Ids = e.shape.businessObject.$attrs.mapped_Child_Ids;
      this.updateXY_PositionOnResize(e.shape.id, e.shape.x, e.shape.y, mapped_Child_Ids, e.shape.width, e.shape.height);
    })

    this.eventBus.on("drag.start", 2000, (e) => {
      if (
        (this.props.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
          (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
          (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)))
      ) {
        e.stopPropagation();
        e.preventDefault();
        return
      }
      if (e.shape?.id.includes("Actor") || (e.shape?.type === "bpmn:DataObjectReference" && e.shape.id?.includes("Document")) || (e.shape?.type === "label" && e.shape?.businessObject?.id.includes("AutoNum")) || (e.shape?.type === "bpmn:EndEvent" && e.shape?.di['background-color'] === '#83fca5')) {
        e.preventDefault();
        e.stopPropagation();
      }
    })

    this.eventBus.on("drag.cleanup", 1500, (event) => {
      if (event.shape && event.shape.id.includes('Activity') && event.context.target) {
        const dragParentId = event.shape?.id;
        const dragParentX = event.shape.x;
        const dragParentY = event.shape.y;
        const dragMappedChild_Ids = event.shape.businessObject.$attrs.mapped_Child_Ids;
        console.log(dragMappedChild_Ids);
        if (event.hover && !event.context.connection && (dragMappedChild_Ids && dragMappedChild_Ids !== "")) {
          console.log("drag cleanup", event);
          this.updateXY_PositionOnResize(dragParentId, dragParentX, dragParentY, dragMappedChild_Ids, event.shape.width, event.shape.height);
        }
      }
    })

    this.eventBus.on("shape.added", (event) => {
      // console.log("shape.added", (event));
      let tempBussObj = event.element.businessObject;
      if (event.element.type === "bpmn:Task" || extraActivityElements.includes(event.element.type)) {
        if (!tempBussObj.$attrs.mapped_Child_Ids) {
          event.element.businessObject.$attrs.mapped_Child_Ids = "";
        }
        // console.log(tempBussObj.$attrs.fullNametxt);
        const elementName = event.element.name;
        if (!(tempBussObj.$attrs.fullNametxt)) {
          event.element.businessObject.$attrs.fullNametxt = isValidValue(elementName) ? elementName : "";
          //event.element.businessObject.$attrs.name = isValidValue(elementName) ? elementName : "";
        }
        if (!(isValidValue(elementName))) {
          event.element.name = elementName
          //   this.bpmnModeler.get("modeling")
          //     .updateProperties(event.element, {
          //       name: isValidValue(elementName) ? elementName : "",//?.length > 25 ? tempBussObj.$attrs?.fullNametxt.substring(0, 25) + "..." : tempBussObj.$attrs.fullNametxt,
          //     });
          //   //event.element.businessObject.$attrs.name = isValidValue(elementName) ? elementName : "";
        }
        console.log(this.props.isDiagNavigationClicked, (!this.props.isActivityReplaceEnable), (!isActivityReplaceEnable));
        if (this.props.isDiagNavigationClicked && (!this.props.isActivityReplaceEnable) && (!isActivityReplaceEnable) && (event.element.height === 80)) {
          const pushAuditObject = {
            diagramLevel: this.props.currentMapDet.id,
            id: event.element.id,
            AutoNumCount: this.state.count + 1,
            field: "Activity",
            newValue: `${this.props.currentMapDet.id} (${this.state.count + 1}) - Activity Created`,
            oldValue: " ",
            type: "CREATE",
          }
          // console.log("🚀 ~ newValue:", pushAuditObject.newValue);
          this.props.audittrailpushingObj(pushAuditObject, "CREATE")
          isActivityReplaceEnable = false;
        }
      }
    })
    this.eventBus.on("replace.end", async (event) => {
      console.log("replace.end", event);
      if (event.element.id?.includes("Activity")) {
        const tempBussObjAttr = event.element.businessObject.$attrs;
        // event.newElement.businessObject.$attrs.fullNametxt = tempBussObjAttr.fullNametxt
        // event.newElement.businessObject.$attrs.AutoNumCount = tempBussObjAttr.AutoNumCount
        // const bpmnCanvas = this.bpmnModeler.get('canvas');
        // const bpmnModeling = this.bpmnModeler.get('modeling');
        // if (event.newElement?.collapsed !== false && event.newElement?.type === "bpmn:SubProcess") {
        //   console.log("inside isCollapsed", event.newElement);
        //   this.bpmnModeling.resizeShape(event.newElement, {
        //     x: event.element.x,
        //     y: event.element.y,
        //     width: event.element.width,
        //     height: event.element.height
        //   })
        // }
        this.bpmnModeling.resizeShape(event.newElement, {
          x: event.element.x,
          y: event.element.y,
          width: event.element.width,
          height: event.element.height
        })
        const oldElement = {
          id: event.element.id,
          AutoNumCount: tempBussObjAttr.AutoNumCount,
          x: event.element.x,
          y: event.newElement.y,
          width: event.element.width,
          height: event.element.height,
          tempBussObjAttr: tempBussObjAttr,
        }
        const objValues = `${this.props.currentMapDet.id} (${tempBussObjAttr.AutoNumCount}) -`
        const pushAuditObject = {
          diagramLevel: this.props.currentMapDet.id,
          id: event.element.id,
          AutoNumCount: tempBussObjAttr.AutoNumCount,
          type: "REPLACE",
          field: "Activity Replace",
          oldValue: `${objValues} ${event.element.type}`,
          newValue: `${objValues} ${event.newElement.type}`,
        }
        this.props.audittrailpushingObj(pushAuditObject, "REPLACE");
        await this.createAndReplaceAttrShapes(oldElement, event.newElement, "FROM_REPLACE")
        isActivityReplaceEnable = false
        await this.props.setMappingDiagramsArray("isActivityReplaceEnable", false);

      }
    });
    this.eventBus.on("shape.remove", async (event) => {
      console.log(event);
      const parent_Id = event.element.id
      const isDiagNavigationClicked = this.props.isDiagNavigationClicked;
      if (event.element?.type === "bpmn:DataObjectReference" && isDiagNavigationClicked) {
        //  this.props.deleteDocSharePointAPICALL("MULTIPLE", event.element.businessObject.$attrs.parentActivityId, event.element.businessObject.$attrs.allFileNamesWithId, event)
      }

      if (((event.element.type === 'bpmn:Task' || extraActivityElements.includes(event.element.type)) && isDiagNavigationClicked)) {
        const bpmnCanvas = this.bpmnModeler.get('canvas');
        const bpmnModeling = this.bpmnModeler.get('modeling');
        const tempMapped_Child_Ids = event.element.businessObject.$attrs.mapped_Child_Ids?.split(",")
        const childResCount = await bpmnCanvas._elementRegistry.filter((item) => (item.id.includes(parent_Id) && item.id !== parent_Id) || tempMapped_Child_Ids?.includes(item.id))
        console.log("childResCount ", childResCount);
        if (childResCount.length !== 0)
          await bpmnModeling.removeElements(childResCount)
        const findResourceName = event.element.id;
        const isActorShape = findResourceName.includes("Actor")
        // if (this.props.isDiagNavigationClicked || this.props.isActivityReplaceEnable || isActivityReplaceEnable) {
        if (!isActorShape) {
          if ((!this.props.isActivityReplaceEnable) && (!isActivityReplaceEnable)) {
            const objValues = `${this.props.currentMapDet.id} (${event.element.businessObject.$attrs?.AutoNumCount})`
            const pushAuditObject = {
              diagramLevel: this.props.currentMapDet.id,
              id: event.element.id,
              AutoNumCount: event.element.businessObject.$attrs?.AutoNumCount,
              field: "Activity",
              type: "REMOVE",
              oldValue: event.element.businessObject.name === undefined ? ` ` : `${objValues}- ${event.element.businessObject.name}`,
              newValue: `${objValues}- Activity Removed`
            }
            console.log(event)
            this.props.audittrailpushingObj(pushAuditObject, "REMOVE", event);
          }
        }
      }

      if (event.element.type === 'bpmn:SubProcess' && isDiagNavigationClicked) {
        let tempMappDiags = [...this.props.mappingDiagrams]
        const tempCurrMap = { ...this.props.currentMapDet };
        const version = tempCurrMap?.id + "." + event.element.businessObject.$attrs.AutoNumCount;
        function getChildDiagramXml(arr, parentId) {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              arr.splice(i, 1);
              return arr[i];
            } else if (arr[i].children.length === 0) {
              continue;
            }
            else {
              getChildDiagramXml(arr[i].children, parentId);

            }
          }
          return arr;
        }
        const deletedData = getChildDiagramXml(tempMappDiags, version)
        console.log(deletedData)
        this.props.setMappingDiagramsArray("mappingDiagrams", deletedData)

      }
    })

    this.eventBus.on("root.set", async (event) => {
      // console.log(event);
      if (event.element?.type === "bpmn:SubProcess") {
        try {
          this.props.setMappingDiagramsArray("isDiagNavigationClicked", false)
          const tempCurrMap = { ...this.props.currentMapDet };
          let tempMappDiags = [...this.props.mappingDiagrams];

          const version = tempCurrMap?.id + "." + event.element.businessObject.$attrs.AutoNumCount;
          const name = event.element.businessObject.name ? "-" + event.element.businessObject.name : "";

          let diagramXMLTemp;
          function getChildDiagramXml(arr, parentId) {
            for (let i = 0; i < arr.length; i++) {
              console.log(arr[i].id === parentId, arr[i]);
              if (arr[i].id === parentId) {
                diagramXMLTemp = arr[i].diagramXML
                return arr[i];
              } else if (arr[i].children.length === 0) {
                continue;
              }
              else {
                const isObjFinded = getChildDiagramXml(arr[i].children, parentId);
                if (isObjFinded) {
                  return isObjFinded.diagramXML
                }
              }
            }
            return "";
          }
          getChildDiagramXml(tempMappDiags, version);
          const currentXML = await this.props.getCurrentDiagramXML();

          const updatedMapDet = {
            id: version,
            name: name,
            key: version + name,
            meta: {
              collapsed: true,
              label: version + name,
            },
            parentId: tempCurrMap?.id,
            diagramXML: "",
          }
          console.log(tempCurrMap);

          function updateCurrDiagramXml(arr, parentId) {
            for (let i = 0; i < arr.length; i++) {
              if (arr[i].id === parentId) {
                arr[i].diagramXML = currentXML;
                return arr;
              } else if (arr[i].children.length === 0) {
                continue;
              }
              else {
                updateCurrDiagramXml(arr[i].children, parentId);
              }
            }
            return arr;
          }
          const updatedArr = updateCurrDiagramXml(tempMappDiags, tempCurrMap.id);
          console.log("##### ", updatedArr);

          this.props.setMappingDiagramsArray("mappingDiagrams", updatedArr);
          this.props.setMappingDiagramsArray("currentMapDet", updatedMapDet);
          await this.updateXmlDiagram(diagramXMLTemp);
          return false
        } catch (error) {
          console.error(error);
        }
      }
    });
    this.props.handleBpmnRef.current = this;
    // console.log('66666', diagramXML);
    return await this.updateXmlDiagram(diagramXML);
  }
  createAndReplaceAttrShapes = async (oldElement, newElement, callFrom) => {
    try {
      console.log("oldElement, newElement ", oldElement, newElement)

      const tempBussObjAttr = oldElement.tempBussObjAttr;
      let AutoNumUpdatedId;
      let dynamicShapeCoords = {
        x: oldElement.x,
        y: oldElement.y,
        width: oldElement.width,
        height: oldElement.height,
        AutoNumCount: oldElement.AutoNumCount
      }
      if (callFrom === "FROM_COPYPASTE") {
        dynamicShapeCoords = {
          x: newElement.x,
          y: newElement.y,
          width: newElement.width,
          height: newElement.height,
          AutoNumCount: newElement.type === "bpmn:SubProcess" ? this.state.count + 1 : "1"
        }
        this.setState({
          count: this.state.count + 1
        })
      }
      newElement.businessObject.$attrs.fullNametxt = tempBussObjAttr.fullNametxt
      newElement.businessObject.$attrs.AutoNumCount = dynamicShapeCoords.AutoNumCount

      if (callFrom === "FROM_REPLACE" || (callFrom === "FROM_COPYPASTE" && newElement.type === "bpmn:SubProcess")) {

        const newAutoNumBox = this.bpmnElementFactory.createShape({ type: 'bpmn:Group' });
        // Auto numbering inside activty
        this.bpmnModeling.createShape(newAutoNumBox, { x: dynamicShapeCoords.x + (dynamicShapeCoords.width / 2), y: dynamicShapeCoords.y, height: 0, width: 0 },
          this.bpmnCanvas.getRootElement()
        );
        this.bpmnModeling.updateLabel(newAutoNumBox, dynamicShapeCoords.AutoNumCount + "");
        AutoNumUpdatedId = "AutoNum_" + newAutoNumBox.id;
        newAutoNumBox.businessObject.$attrs.parentActivityId = newElement.id
        try {
          this.bpmnModeling.updateProperties(newAutoNumBox, { id: AutoNumUpdatedId });
        } catch (error) {
          console.error(error);
        }
        // Auto numbering inside activty
        this.bpmnModeling.setColor(newAutoNumBox, {
          fill: '#fff', //'#bbdefb',
          stroke: '#fff', //'#bbdefb'
        })
        this.bpmnModeling.setColor(newAutoNumBox.labels, {
          stroke: '#000',
        })

        this.bpmnModeling.moveElements(newAutoNumBox.labels, {
          x: -1,
          y: -3
        });
      }
      const activityActorIds = tempBussObjAttr.mapped_Child_Ids.split(',')?.filter(id => (id?.includes("Actor")))//?.filter(id => id?.includes("Actor"));
      const activityFileDocIds = tempBussObjAttr.mapped_Child_Ids.split(',')?.filter(id => (id?.includes("Document")))//?.filter(id => id?.includes("Actor"));
      const activityFLSId = tempBussObjAttr.mapped_Child_Ids.split(',')?.find(id => (id?.includes("FLS")))//?.filter(id => id?.includes("Actor"));
      const activityFLEId = tempBussObjAttr.mapped_Child_Ids.split(',')?.find(id => (id?.includes("FLE")))//?.filter(id => id?.includes("Actor"));

      newElement.businessObject.$attrs.mapped_Child_Ids = AutoNumUpdatedId

      if (activityActorIds?.length > 0) {
        activityActorIds.forEach((elementid, index) => {
          const ActorShapeImpl = this.bpmnCanvas._elementRegistry.get(elementid)
          console.log("ActorShapeImpl ", ActorShapeImpl);
          if (!ActorShapeImpl) {
            console.log(" is copied from another level resource won't be copy");
            return
          }
          const copiedIncomingFlows = [...ActorShapeImpl.incoming];
          const copiedOutgoingFlows = [...ActorShapeImpl.outgoing];
          console.log("copiedIncomingFlows ", copiedIncomingFlows);
          console.log("copiedOutgoingFlows ", copiedOutgoingFlows);//waypoints
          const newResourceBox = this.bpmnElementFactory.createShape({ type: 'bpmn:Task' });
          this.bpmnModeling.createShape(newResourceBox, { x: dynamicShapeCoords.x, y: dynamicShapeCoords.y + dynamicShapeCoords.height + (25 * (index)), width: dynamicShapeCoords.width, height: 25 },
            newElement.parent
          );
          const resUpdatedId = "Actor_" + newResourceBox.id + "_" + (index + 1)
          this.bpmnModeling.updateLabel(newResourceBox, ActorShapeImpl?.businessObject.$attrs.fullNametxt)//?.length > 12 ? ActorShapeImpl?.businessObject.$attrs.fullNametxt?.substring(0, 12) + "..." : ActorShapeImpl?.businessObject.$attrs.fullNametxt);
          this.bpmnModeling.updateProperties(newResourceBox, {
            id: resUpdatedId
          });
          newResourceBox.businessObject.$attrs.parentActivityId = newElement.id
          newResourceBox.businessObject.$attrs.fullNametxt = ActorShapeImpl?.businessObject.$attrs.fullNametxt
          newResourceBox.businessObject.$attrs.resourceId = ActorShapeImpl?.businessObject.$attrs.resourceId
          newResourceBox.businessObject.$attrs.resourceName = ActorShapeImpl?.businessObject.$attrs.resourceName
          newResourceBox.businessObject.$attrs.resourceType = ActorShapeImpl?.businessObject.$attrs.resourceType
          console.log(newResourceBox);
          // if (activityActorIds.length === (index + 1)) {
          copiedIncomingFlows.forEach(flow => {
            const newFlow = this.bpmnModeling.connect(flow.source, newResourceBox, { type: flow.type, waypoints: flow.waypoints });
            if (flow.businessObject?.name) {
              newFlow.businessObject.name = flow.businessObject.name;  // Copy the name (label)
              this.bpmnModeling.updateLabel(newFlow, flow.businessObject.name);  // Update the label on the diagram
            }
          });
          copiedOutgoingFlows.forEach(flow => {
            const newFlow = this.bpmnModeling.connect(newResourceBox, flow.target, { type: flow.type, waypoints: flow.waypoints });
            if (flow.businessObject?.name) {
              newFlow.businessObject.name = flow.businessObject.name;  // Copy the name (label)
              this.bpmnModeling.updateLabel(newFlow, flow.businessObject.name);  // Update the label on the diagram
            }
          });
          // }
          this.bpmnModeling.setColor(newResourceBox, {
            fill: ActorShapeImpl?.businessObject.$attrs?.resourceType === "SYSTEM" ? '#fec76f' : '#bbdefb',
          }
          );

          const tempBussObjChild_Ids = newElement.businessObject.$attrs?.mapped_Child_Ids;
          const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? resUpdatedId : (tempBussObjChild_Ids + "," + resUpdatedId);
          newElement.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
          console.log(tempAddedChild_Ids);
        }
        )
      }
      if (callFrom !== "FROM_COPYPASTE" && activityFileDocIds?.length > 0) {
        const elementid = activityFileDocIds[0]
        const FileDocShapeImpl = this.bpmnCanvas._elementRegistry.get(elementid)
        console.log("FileDocShapeImpl ", FileDocShapeImpl);
        const newFileDocShape = this.bpmnElementFactory.createShape({ type: 'bpmn:DataObjectReference', height: 20, width: 15 });
        this.bpmnModeling.createShape(newFileDocShape, { x: (dynamicShapeCoords.x + dynamicShapeCoords.width - 35), y: dynamicShapeCoords.y + 15 },
          newElement.parent
        );
        this.bpmnModeling.setColor(newFileDocShape, {
          fill: '#D2DDE1', //'#bbdefb',
          stroke: '#131E36', //'#bbdefb'
        })
        console.log(newFileDocShape);
        const resUpdatedId = "Document_" + newFileDocShape.id;
        this.bpmnModeling.updateProperties(newFileDocShape, {
          id: resUpdatedId
        });
        this.bpmnModeling.setColor(newFileDocShape, {
          fill: '#D2DDE1', //'#bbdefb',
          stroke: '#131E36', //'#bbdefb'
        })
        newFileDocShape.businessObject.$attrs.parentActivityId = FileDocShapeImpl?.businessObject.$attrs.parentActivityId
        newFileDocShape.businessObject.$attrs.allFileNamesWithId = FileDocShapeImpl?.businessObject.$attrs.allFileNamesWithId

        const tempBussObjChild_Ids = newElement.businessObject.$attrs?.mapped_Child_Ids;
        const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? resUpdatedId : (tempBussObjChild_Ids + "," + newFileDocShape.id);
        newElement.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
        console.log(tempAddedChild_Ids);
      }
      if (callFrom !== "FROM_COPYPASTE" && activityFLSId) {
        const elementid = activityFLSId
        const StartShapeImpl = this.bpmnCanvas._elementRegistry.get(elementid)
        console.log("startShapeImpl ", StartShapeImpl);
        console.log("outgoing", StartShapeImpl.outgoing);
        const newStartEvent = this.bpmnElementFactory.createShape({ type: 'bpmn:StartEvent', width: 20, height: 5 });
        this.bpmnModeling.appendShape(newElement, newStartEvent, { x: newElement.x - 30, y: newElement.y + (newElement.height * .75) },
          newElement.parent
        );
        // this.bpmnModeling.appendShape(newStartEvent, { x: event.newElement.x - 35, y: event.newElement.y + (event.newElement.height * .75) },
        //   event.newElement.parent
        // );
        console.log(newStartEvent.outgoing[0]);
        this.bpmnModeling.connect(newStartEvent, newElement)
        this.bpmnModeling.updateProperties(newStartEvent, {
          id: "FLS_" + newStartEvent.id,
        });
        const waypoints = [
          { x: newStartEvent.x, y: newElement.y + (newElement.height * .75) },
          { x: newElement.x, y: newElement.y + (newElement.height * .75) },
        ]
        console.log(waypoints);
        this.bpmnModeling.updateWaypoints(newStartEvent.outgoing[0], waypoints);
        this.bpmnModeling.layoutConnection(newStartEvent.outgoing[0], {
          connectionStart: waypoints[0],
          connectionEnd: waypoints[waypoints.length - 1]
        });
        newStartEvent.businessObject.$attrs.parentActivityId = StartShapeImpl?.businessObject.$attrs.parentActivityId;
        newStartEvent.businessObject.$attrs.TargetActivityId = StartShapeImpl?.businessObject.$attrs.TargetActivityId;
        this.bpmnModeling.setColor(newStartEvent, {
          fill: '#44bd32',
          stroke: '#dcdde1'
        }
        );
        //
        const tempBussObjChild_Ids = newElement.businessObject.$attrs?.mapped_Child_Ids;
        const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? newStartEvent.id : (tempBussObjChild_Ids + "," + newStartEvent.id);
        newElement.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
        console.log(tempAddedChild_Ids);
      }
      if (callFrom !== "FROM_COPYPASTE" && activityFLEId) {
        const elementid = activityFLEId;
        const StartShapeImpl = this.bpmnCanvas._elementRegistry.get(elementid)
        console.log("startShapeImpl ", StartShapeImpl);
        const newEndEvent = this.bpmnElementFactory.createShape({ type: 'bpmn:EndEvent', width: 20, height: 5 });
        this.bpmnModeling.appendShape(newElement, newEndEvent, { x: dynamicShapeCoords.width + dynamicShapeCoords.x + 30, y: dynamicShapeCoords.y + (dynamicShapeCoords.height * .10) },
          newElement.parent
        );
        const waypoints = [
          { x: newElement.width + newElement.x, y: newElement.y + (newElement.height * .10) },
          { x: newEndEvent.x, y: newElement.y + (newElement.height * .10) },
        ]
        this.bpmnModeling.updateProperties(newEndEvent, {
          id: "FLE_" + newEndEvent.id,
        });
        this.bpmnModeling.updateWaypoints(newEndEvent.incoming[0], waypoints);
        this.bpmnModeling.layoutConnection(newEndEvent.incoming[0], {
          connectionStart: waypoints[0],
          connectionEnd: waypoints[waypoints.length - 1]
        });
        this.bpmnModeling.setColor(newEndEvent, {
          stroke: '#dcdde1',
          fill: '#009432',
        }
        );
        newEndEvent.businessObject.$attrs.parentActivityId = StartShapeImpl?.businessObject.$attrs.parentActivityId;
        newEndEvent.businessObject.$attrs.TargetActivityId = StartShapeImpl?.businessObject.$attrs.TargetActivityId;

        const tempBussObjChild_Ids = newElement.businessObject.$attrs?.mapped_Child_Ids;
        const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? newEndEvent.id : (tempBussObjChild_Ids + "," + newEndEvent.id);
        newElement.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
        console.log(tempAddedChild_Ids);

      }
      if (newElement.type === "bpmn:SubProcess" && newElement?.collapsed !== false) {
        let tempMappDiags = cloneDeep(this.props.mappingDiagrams)
        const tempCurrMap = this.props.currentMapDet;
        console.log(tempCurrMap, tempMappDiags);
        const version = tempCurrMap?.id + "." + dynamicShapeCoords.AutoNumCount;
        const name = tempBussObjAttr.fullNametxt ? tempBussObjAttr.fullNametxt : ""
        const tempDefDiagXml = await getXmlDiagram("default");
        let updatedMapDet = {
          id: version,
          name: name,
          key: version + (isValidValue(name) ? "-" + name : ""),
          meta: {
            collapsed: true,
            label: version + (isValidValue(name) ? "-" + name : "")
          },
          parentId: tempCurrMap?.id,
          diagramXML: tempDefDiagXml,
          children: [],
          flowlineMap: []
        }
        if (callFrom === "FROM_COPYPASTE") {
          const { element, content } = Store.getState().copiedLowerLevels;
          if (element.type === "")
            console.log("element ", element)
          console.log("content ", content)
          const baseId = content.id
          const currentId = version //tempCurrMap?.id;
          console.log("this.props. ", this.props)
          const updatedCopiedTreeObj = await this.props.updateTreeIdsByBaseId([content], currentId, baseId);
          console.log("updatedCopiedTreeObj ", updatedCopiedTreeObj)
          updatedMapDet = {
            id: version,
            name: name,
            key: version + (isValidValue(name) ? "-" + name : ""),
            meta: {
              collapsed: true,
              label: version + (isValidValue(name) ? "-" + name : "")
            },
            parentId: tempCurrMap?.id,
            diagramXML: updatedCopiedTreeObj[0].diagramXML,
            children: updatedCopiedTreeObj[0].children,
            flowlineMap: updatedCopiedTreeObj[0].flowlineMap
          }
        }
        function insertChildObjToParent(arr, parentId, newObj) {
          for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === parentId) {
              console.log(arr[i].children);
              console.log(newObj);
              arr[i].children.push(newObj);
              const sortedchildrenArray = arr[i].children.sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }))
              arr[i].children = sortedchildrenArray;
              return arr;
            } else {
              if (arr[i].children.length === 0) {
                continue;
              }
              const updatedNodes = insertChildObjToParent(arr[i].children, parentId, newObj);
              console.log(updatedNodes)
            }
          }
          return arr;
        }
        const updatedArr = insertChildObjToParent(tempMappDiags, tempCurrMap.id, updatedMapDet);
        console.log("##### ", updatedArr);
        this.props.setMappingDiagramsArray("mappingDiagrams", updatedArr)
      }
      console.log('final replaced shape ', newElement);
      return newElement.businessObject.$attrs;

    } catch (error) {
      console.error(error);
    }

  }

  updateXY_PositionOnResize = (dragParentId, dragParentX, dragParentY, dragMappedChild_Ids, width, height) => {
    const targetResChildIds = dragMappedChild_Ids?.split(',')?.filter((item) => item?.includes("Actor"));
    const targetAutoNoChildIds = dragMappedChild_Ids?.split(',')?.filter((item) => item?.includes("AutoNum"));
    const targetDocChildIds = dragMappedChild_Ids?.split(',')?.filter((item) => item?.includes("Document"));
    const targetEndFlowLineChildIds = dragMappedChild_Ids?.split(',')?.filter((item) => item?.includes("FLE"));
    const targetStartFlowLineChildIds = dragMappedChild_Ids?.split(',')?.filter((item) => item?.includes("FLS"));
    console.log("Resource Child IDs:", targetResChildIds);

    const modeling = this.bpmnModeler.get("modeling");
    const bpmnCanvas = this.bpmnModeler.get("canvas");
    const childResElements = bpmnCanvas._elementRegistry.filter((item) => targetResChildIds?.includes(item.id));
    const childAutoNumElements = bpmnCanvas._elementRegistry.filter(
      (item) => targetAutoNoChildIds?.includes(item.id) && item.type === "bpmn:Group"
    );
    const childDocElement = bpmnCanvas._elementRegistry.filter((item) => targetDocChildIds?.includes(item.id));
    const childFlowlineEndElement = bpmnCanvas._elementRegistry.filter((item) =>
      targetEndFlowLineChildIds?.includes(item.id)
    );
    const childFlowlineStartElement = bpmnCanvas._elementRegistry.filter((item) =>
      targetStartFlowLineChildIds?.includes(item.id)
    );

    console.log("Child Flowline End Elements:", childFlowlineEndElement);

    if (childResElements?.length !== 0) {
      childResElements.forEach((resElement, index) => {
        modeling.resizeShape(resElement, {
          x: dragParentX,
          y: (dragParentY + height) + (25 * index),
          width: width,
          height: 25,
        });
      });
    }
    if (childDocElement?.length !== 0) {
      modeling.moveElements(childDocElement, {
        x: (dragParentX + (width - 40)) - childDocElement[0].x,
        y: (((dragParentY + 8) - childDocElement[0].y))
      });
    }
    if (childAutoNumElements?.length !== 0) {
      modeling.moveElements(childAutoNumElements, {
        x: (dragParentX + (width / 2)) - childAutoNumElements[0].x,
        y: dragParentY - childAutoNumElements[0].y
      });
    }
    if (childFlowlineEndElement?.length !== 0) {
      const incomingConnection = childFlowlineEndElement[0]?.incoming?.[0]; //
      if (incomingConnection) {
        modeling.moveElements(childFlowlineEndElement, {
          x: (dragParentX + (width + 30) - childFlowlineEndElement[0].x),
          y: dragParentY + (height * (.10)) - childFlowlineEndElement[0].y,
        });
        const waypoints = [
          { x: width + dragParentX, y: dragParentY + (height * (.10)) },
          { x: childFlowlineEndElement[0].x, y: dragParentY + (height * (.10)) },
        ]
        console.log(" after waypoints 1", childFlowlineEndElement[0]?.incoming[0], waypoints);
        modeling.updateWaypoints(childFlowlineEndElement[0]?.incoming[0], waypoints);
        modeling.layoutConnection(childFlowlineEndElement[0]?.incoming[0], {
          connectionStart: waypoints[0],
          connectionEnd: waypoints[waypoints.length - 1],
        });
      } else {
        console.warn("Use the lasso tool to select the activity with the flowlink!.");
      }
    }
    if (childFlowlineStartElement?.length !== 0) {
      const outgoingConnection = childFlowlineStartElement[0]?.outgoing?.[0];
      if (outgoingConnection) {
        modeling.moveElements(childFlowlineStartElement, {
          x: (dragParentX - 50) - childFlowlineStartElement[0].x,
          y: dragParentY + (height * .75) - childFlowlineStartElement[0].y,
        });
        const waypoints = [
          { x: childFlowlineStartElement[0].x, y: dragParentY + (height * (.75)) },
          { x: dragParentX, y: dragParentY + (height * (.75)) },
        ]

        modeling.updateWaypoints(childFlowlineStartElement[0]?.outgoing[0], waypoints);
        modeling.layoutConnection(childFlowlineStartElement[0]?.outgoing[0], {
          connectionStart: waypoints[0],
          connectionEnd: waypoints[waypoints.length - 1],
        });
      } else {
        console.warn("Use the lasso tool to select the activity with the flowlink!.");
      }
    }
  };

  componentWillUnmount() {
    this.bpmnModeler.destroy();
  }

  componentDidUpdate(prevProps, prevState) {
    const { props, state } = this;

    const currentXML = props.diagramXML || state.diagramXML;
    const previousXML = prevProps.diagramXML || prevState.diagramXML;
    if (currentXML && currentXML !== previousXML) {
      // console.log('didUpdate trueeee', currentXML);
      return this.updateXmlDiagram(currentXML);
    }
  }

  async updateXmlDiagram(diagramXML) {
    if (diagramXML === null || diagramXML === undefined || diagramXML === "") {
      diagramXML = await getXmlDiagram("default");
    }
    this.setState({ diagramXML: diagramXML })
    // console.log(" diagramXML ", diagramXML);
    await this.bpmnModeler.importXML(diagramXML);
  }


  propPanelOpenCloseOnClick = () => {
    this.setState({
      isPropPanelEnable: !this.state.isPropPanelEnable,
    });
  };

  createAutoNumbByParentCoords = (parent_Id, parent_X, parent_Y) => {
    const bpmnCanvas = this.bpmnModeler.get('canvas');
    const bpmnModeling = this.bpmnModeler.get('modeling');
    const newAutoNumBox = this.bpmnElementFactory.createShape({ type: 'bpmn:Group' });
    bpmnModeling.createShape(newAutoNumBox, { x: parent_X - 10, y: parent_Y - 14, height: 18, width: 18 },
      bpmnCanvas.getRootElement()
    );
    bpmnModeling.updateLabel(newAutoNumBox, this.state.count + "");
    bpmnModeling.updateProperties(newAutoNumBox, {
      id: "AutoNum_" + parent_Id,
    });
    bpmnModeling.moveElements(newAutoNumBox.labels, {
      x: -1,
      y: -3
    });
    this.setState(prevState => ({
      count: (prevState.count + 1)
    }))

  }
  renderElementsByIconsId = (groupId) => {
    const tempGroupId = isNumber(groupId) ? groupId : parseInt(groupId)
    return navIcons.find(item => item.id === tempGroupId)
  }
  rightClick = (e) => {
    e.preventDefault()
    console.log("rightClick", e);
    const { clientX, clientY } = e;
    this.setState({
      menuPosition: { x: clientX, y: clientY },
      menuOpen: true
    });
  }
  handleCloseMenu = () => {
    this.setState({ menuOpen: false });
  };
  render() {
    return (
      <>
        <div
          id="propview"
          style={{
            width: this.state.isPropPanelEnable ? "20%" : "0%",
            float: "right",
            top: "8em",
            position: "absolute",
            right: "10em",
            zIndex: 70,
          }}
        ></div>
        <div className="py-2 pr-1">
          <div className={`relative ${this.props.isDefaultTemplateEnable ? this.props.isTreeView ? ' mt-10 mr-[70px] ' : ' ' : ''} p-2 rounded border-4`}
            style={{
              background: `${this.props.isDefaultTemplateEnable ? `linear-gradient(to bottom, ${this.props.appliedTemplate.colorCode}, #fff)` : `linear-gradient(to bottom, #fff, #fff)`}` // Adjust as needed
            }}>
            {this.props.isDefaultTemplateEnable ?
              <>
                <div class="z-0 relative w-full">
                  <div class="flex justify-between items-center">
                    <div class="flex space-x-4">
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("HOME")}
                        title={BPMN_Common_Labels._HOME_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.homeIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navHomeIcon} alt="home_icom" />
                        }
                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("UP")}
                        title={BPMN_Common_Labels._UP_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.upIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navUpIcon} alt="up_icom" />
                        }

                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("PREV")}
                        title={BPMN_Common_Labels._PREVIOUS_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {/* <IoArrowBack size={22} color="black" /> */}
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.previousIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navPreviousIcon} alt="previous_icom" />
                        }
                      </div>
                      <p className="mt-6 text-xs">{this.props?.currentMapDet?.name?.substring(0, 1) === '-' ? this.props?.currentMapDet?.name.substring(1, this.props?.currentMapDet.name.length) : this.props?.currentMapDet.name}</p>
                    </div>
                    <div class="flex items-center">
                      <p class="mt-4 pr-4 text-xs">{this.props?.currentMapDet.id}</p>
                      <div class="p-1 w-16">
                        <img className="scale-75" src={this.props.isDefaultTemplateEnable ? this.props.appliedTemplate?.companyLogo?.imgcontent : pncLOGO_v1} alt="comapny_logo" />
                      </div>
                    </div>
                  </div>
                  <p class="-top-4 left-1/2 absolute py-2 font-semibold -translate-x-1/2 transform">{this.props?.mapDiagramRecord.diagramName}</p>
                </div>
                <hr class="bg-gray-900 mt-1 border-0 h-px" />

              </>
              : null}

            <div
              id={(this.props.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
                (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status))
              )
                ?
                "viewonly" : "bpmnEditorTool"}
              className="react-bpmn-diagram-container"
              ref={this.containerRef}
              style={{
                height: this.props.isDefaultTemplateEnable ? this.props.isTreeView ? "72vh" : "76vh" : "83vh",
                marginTop: this.props.isDefaultTemplateEnable ? '' : '5vh',
                marginRight: this.props.isDefaultTemplateEnable ? '' : '10vh',
              }}
              onContextMenu={this.rightClick}
            >
              <PopupMenu
                position={this.state.menuPosition}
                open={this.state.menuOpen}
                copySelectOnClick={this.copySelectOnClick}
                pasteSelectOnClick={this.pasteSelectOnClick}
                onClose={this.handleCloseMenu}
                isPasteEnable={!(this.props.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
                  (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                  (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.props.selectedMapData?.diagramXmlIds.Draft.status))
                )}
              />
            </div>

            {this.props.isDefaultTemplateEnable ?
              <>
                <div class="z-50 relative w-full">
                  <hr class="bg-gray-900 border-0 h-px" />
                  <div class="flex justify-between items-center">
                    <div class="flex space-x-4">
                      <p className="mt-1 text-xs">{BPMN_Common_Labels._AUTHOR_TEMPLATE} : {this.props.selectedMapData.author}</p>
                    </div>
                    <div class="flex items-center">
                      <p class="mt-1 text-xs">{BPMN_Common_Labels._STATUS_TEMPLATE} : {this.props.resSavedData?.diagramLevel === "Draft" ? this.props.resSavedData?.diagramStatus : this.props.resSavedData?.diagramLevel}</p>
                    </div>
                  </div>
                </div>
              </>
              : null}

          </div>
        </div>
      </>
    );
  }
}
export default BpmnTool;