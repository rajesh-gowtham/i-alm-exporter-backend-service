import { cloneDeep, isNumber } from 'lodash';
import React, { useEffect, useRef, useState } from 'react';
import { BsFillDiagram3Fill, BsInfoCircleFill } from 'react-icons/bs';
import { FaFileImport } from 'react-icons/fa';
import { HiOutlineSearch } from 'react-icons/hi';
import { IoOpenOutline, IoTrashOutline } from 'react-icons/io5';
import { useDispatch } from 'react-redux';
import { DeleteConfirmPOPUP, HoverPopup, validateFileOnChange } from '../../CommonUtils/ComponentUtil';
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { AxiosConstants } from '../../Constants/AxiosConstants';
import { BPMNEditor_Labels } from '../../Constants/COMMON_LABELS';
import { Auth_Common_Toaster, BPMN_Editor_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import BPMNService from '../../Services/BPMNService';
import ProjectClientService from '../../Services/ClientprojectsService';
import Projectreceiverservice from '../../Services/Projectreceiverservice';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import { ChildCompEditorRef } from './ChildRefComponents';
import { AddEditMapDiagramPOPUP, UploadBpmnPopup } from './EditUtilPoupComp';
import { debounce } from 'lodash';

const BpmndiagramGrid = () => {
  const gridRef = useRef();
  const intervalTimeRef = useRef();
  const childRef = useRef()
  const dispatch = useDispatch();

  const [rowData, setRowData] = useState([]);
  const [initialRowData, setInitialRowData] = useState([]);
  const [isEditorOpen, setEditorOpen] = useState(false);
  const [isDeleteMapEnable, setIsDeleteMapEnable] = useState(false);
  const loginUserRole = localStorage.getItem("userRole");
  const loginUserId = localStorage.getItem('userid');
  const [selectedMapData, setSelectedMapData] = useState()
  const [isAddEDitMapDiagramEnable, setIsAddEDitMapDiagramEnable] = useState(false);
  const [isEditMap, setIsEditMap] = useState(false);
  const [mapDiagramRecord, setMapDiagramRecord] = useState({});
  const [sharepointConfigOptions, setSharepointConfigOptions] = useState([]);
  const [isImportMapEnable, setIsImportMapEnable] = useState(false);
  const [selectedFileData, setSelectedFileData] = useState('');
  const [filterValue] = useState('')
  const [editMapDiagramRecord, setEditMapDiagramRecord] = useState({});
  const [editorUserOptions, setEditorUserOptions] = useState([]);
  const [isSpecificUsersEnable, setIsSpecificUsersEnable] = useState(false);
  const [gridApi, setGridApi] = useState(null);
  const [isCheckboxClicked, setsetIsCheckboxClicked] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectedMapType, setSelectedMapType] = useState({});
  const [mapLevelOptions, setMapLevelOptions] = useState([]);
  const [projectsData, setProjectData] = useState([[]]);
  const [projectsDataContainer, setprojectsDataContainer] = useState([])
  const [publicUsers, setpublicUsers] = useState([])
  const org = localStorage.getItem("organization") === 'iGO Solutions';

  const [columnDefs] = useState([

    // {
    //   field: "", headerName: "Sl.No", sortable: true, width: '70px', suppressMovable: true,
    //   cellRenderer: (params) => {
    //     return <span className='text-blue-600'>{params.rowIndex + 1 + "."}</span>
    //   }
    // },
    {
      field: "project", headerName: "Project Name", sortable: true, flex: 1, suppressMovable: true,
      cellRenderer: (params) => {
        const project = params.data.project;
        const projectName = project ? project.projectName : '';
        return (
          <span
            // onClick={() => openAddEditDeleteImportMap("VIEW_EDIT_MAP", params)}
            className='text-orange-500'
          >
            {projectName}
          </span>
        );
      }
    },
    {
      field: "diagramName", headerName: "Map Name", sortable: true, flex: 1, suppressMovable: true,
      cellRenderer: (params) => {
        return <span onClick={() => openAddEditDeleteImportMap("VIEW_EDIT_MAP", params)} className='text-blue-600 decoration-[1.5px] decoration-blue-400 decoration-solid hover:underline underline-offset-2 cursor-pointer'>{params.value}</span>
      }
      // headerCheckboxSelection: true,
      // headerCheckboxSelectionFilteredOnly: true,
      // checkboxSelection: true,
    },
    // { field: "status", headerName: "Status", sortable: true, flex: 1, suppressMovable: true, },
    { field: "author", headerName: "Author", sortable: true, flex: 1, suppressMovable: true, },
    {
      headerName: "Map Access", field: "mapPrivacyType", sortable: true, flex: 1, suppressMovable: true, minWidth: 130,
      cellRenderer: (params) => {
        if (params.value === "public") {
          return <span class="bg-[#13bf1b26] px-2 py-[3px] rounded text-[#13bf1b] text-xs">Public</span>;
        }
        else if (params.value === "private") {
          return <span class="bg-[#f3381926] px-2 py-[3px] rounded text-[#f33819] text-xs">Private</span>;
        }
        else
          return <span class="bg-[#2346f726] px-2 py-[3px] rounded text-[#2346f7] text-xs">Specific</span>;
      }
    },
    {
      field: 'assignedUsers', headerName: 'Reviewers', suppressMovable: true, sortable: true,
      cellRenderer: (params) => {
        return params.value.map(user => user.assignedUser).join(', ');
      }
    },
    {
      headerName: "Action", field: "diagramXmlIds", flex: 1, sortable: true, suppressMovable: true,
      cellRendererFramework: (params) => {
        const paramData = params.value
        return <div class='flex items-center space-x-4 w-full h-full'>
          {/* {(params.data.status === "Draft" && (loginUserRole === "Editor" || loginUserRole === "Admin")) || (params.data.status === "InReview" && (loginUserRole === "Reviewer" || loginUserRole === "Admin")) || (params.data.status === "Approved" && (loginUserRole === "Admin")) ? */}
          <div class='flex items-center space-x-4 w-full h-full'>
            <div className='flex items-center space-x-2 hover:scale-[2] transition duration-500 ease-in-out cursor-pointer' title='Open' onClick={() => openAddEditDeleteImportMap("VIEW_EDIT_MAP", params)}>
              <IoOpenOutline size={20} color='#1D3989' />
            </div>
            <HoverPopup
              width="auto"
              height="auto"
              position={"right center"}
              triggerElement={
                <div className='flex items-center space-x-2 hover:scale-[1.5] transition duration-500 ease-in-out cursor-pointer' onClick={() => openAddEditDeleteImportMap("VIEW_EDIT", params)}>
                  <BsInfoCircleFill size={18} />
                </div>
              }
              content={
                <div class="w-full h-full">
                  <div className='flex items-center space-x-1'>
                    <span className='font-bold text-blue-500'>Draft <span className='font-medium text-black'>{paramData?.Draft?.version === null || paramData?.Draft?.version === undefined ? "" : "(v." + paramData?.Draft?.version + ")"}</span> </span>
                    <span className='bg-[#ff832b26] px-1 rounded text-[#ff832b]'>{paramData.Draft?.status}</span>
                  </div>
                  {paramData.Master ?
                    <div className='flex items-center space-x-1'>
                      <span className='font-bold text-blue-500'>Master </span>
                      <span>(v.{paramData.Master?.version})</span>
                    </div>
                    : null}
                  {paramData.Archive.length > 0 ?
                    <div className='items-center space-x-1 w-full'>
                      <span className='w-full font-bold text-blue-500 decoration-blue-600 underline'>Archives  </span>
                      <ul className='list-disc list-inside'>
                        {paramData.Archive.map((item, ind) => <li key={ind} className=''>(v.{item.version})</li>)}
                      </ul>
                    </div>
                    : null}
                </div>
              }
            />

            {(loginUserRole === "Admin") || (loginUserRole === "Editor" && (isNumber(params?.data?.authorUserId) ? params?.data?.authorUserId : parseInt(params?.data?.authorUserId) === parseInt(loginUserId))) ?
              <div className='flex items-center space-x-2 cursor-pointer' title='Delete' onClick={() => openAddEditDeleteImportMap("DELETE", params,)}>
                <IoTrashOutline color='red' />
              </div>
              : null
            }
          </div>
          {/* : null
          } */}
        </div>
      }
    }
  ]);


  // const [resSavedData, setResSavedData] = useState({});
  // const [diagramXmlId, setDiagramXmlId] = useState('');
  // const [userSavedData, setUserSavedData] = useState({});
  // const [mappingDiagrams, setMappingDiagrams] = useState([
  //   {
  //     id: "1",
  //     name: "",
  //     key: "1",
  //     meta: {
  //       collapsed: true,
  //       label: "1"
  //     },
  //     diagramXML: defaultDiagramXml,
  //     parentId: null,
  //     children: [],
  //     flowlineMap: []
  //   },
  // ]);
  // const [selectedLanguage, setSelectedLanguage] = useState({ label: "English", value: "en" });
  // const [currentMapDet, setCurrentMapDet] = useState({});
  // const [templateBgColor, setTemplateBgColor] = useState(localStorage.getItem(localStorage.getItem('userid') + "color"));
  // const [isDefaultTemplateEnable, setIsDefaultTemplateEnable] = useState(false);
  // const [appliedTemplate, setAppliedTemplate] = useState({});


  useEffect(() => {
    let intervalId;

    if (isEditorOpen) {
      console.log("inside checkin");
      intervalId = setInterval(() => {
        // BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(selectedMapData.diagramXmlIds?.Draft?.diagramXmlId, 'checkIn');
      }, 0.5 * 60 * 1000);
    }

    return () => {
      try {
        console.log("outside checkout");
        clearInterval(intervalId);
        if (isEditorOpen)
          BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(selectedMapData?.diagramXmlIds?.Draft?.diagramXmlId, 'checkOut');
      } catch (error) {
        console.error(error);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEditorOpen, selectedMapData]);

  useEffect(() => {
    try {
      openSpinnerRedux()
      getDiagramsData();

      // openAddEditDeleteImportMap("VIEW_EDIT_MAP", {
      //   // data: {
      //   //   "id": 122286,
      //   //   "diagramXmlIds": {
      //   //     "Master": null,
      //   //     "Draft": {
      //   //       "version": null,
      //   //       "diagramXmlId": 122285,
      //   //       "status": "InProgress"
      //   //     },
      //   //     "Archive": []
      //   //   },
      //   //   "assignedUsers": [],
      //   //   "author": "Dinesh O",
      //   //   "authorUserId": "3549",
      //   //   "diagramName": "ALM Testing 2 ",
      //   //   "mapPrivacyType": "public",
      //   //   "organization": "iGO Solutions",
      //   //   "mapAuthorizedUsers": [],
      //   //   "project": {
      //   //     "id": 4,
      //   //     "projectName": "Asian Paints ",
      //   //     "customerId": 2,
      //   //     "customerName": "FrontEnd"
      //   //   },
      //   //   "docStorageType": "database",
      //   //   "configName": "",
      //   //   "configId": "",
      //   //   "errorMessage": null
      //   // }
      // })
    } catch (error) {
      closeSpinnerRedux();
      console.error(error);
      ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const unsavedChanges = localStorage.getItem('unsavedChanges');
    const diagramXmlId = localStorage.getItem('diagramXmlId');
    if (unsavedChanges) {
      const url = AxiosConstants.ApiBaseUrl + `bpmnDiagram/updateDiagramTimeByDiagramXmlId/${diagramXmlId}/checkOut`;
      fetch(url, {
        method: 'GET',
        keepalive: true
      }).then(response => {
        console.log("API call made before page reload:", response);
      }).catch(error => {
        console.error("Error during beforeunload API call:", error);
      });
      //BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(selectedMapData?.diagramXmlIds.Draft?.diagramXmlId, 'reloadCheckOut');
      localStorage.removeItem('diagramXmlId');
      localStorage.removeItem('unsavedChanges');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const getDiagramsData = async () => {
    const response = await BPMNService.getBPMNDiagramsByUserIdAPICALL()
    const data = await response.data
    console.log(response);
    setRowData(data);
    setInitialRowData(data);
    closeSpinnerRedux();

  }
  const onGridReady = (params) => {
    setGridApi(params.api);

  };
  const isRowSelectable = () => {
    return true
    // if (isEditorOpen) {
    //   return true
    // } else {

    //   console.log("isrowselectable", params);
    //   const isValidaDeleteData = (loginUserRole === "Editor" && params?.data?.authorUserId === localStorage.getItem('userid')) && (params.data.status === "Draft" && params.data.assignedUser === null)
    //   return isValidaDeleteData;
    // }
  }
  const OnCheckBoxSelection = (params) => {
    console.log(params, gridApi?.getSelectedNodes()?.length);
    if (gridApi?.getSelectedNodes()?.length > 0) {
      setsetIsCheckboxClicked(true);
    } else {
      setsetIsCheckboxClicked(false);
    }
  }
  const getOptionsByName = async (optionName) => {
    if (optionName === 'SHAREPOINT')
      try {
        const response = await BPMNService.getConfigDataByTypeAPICALL("sharepoint");
        const data = await response.data
        const tempSharepointConfigOptions = data.map(item => ({ label: item.datasourcename, value: item.id + "" }))
        console.log(response);
        setSharepointConfigOptions(tempSharepointConfigOptions)
      } catch (error) {
        console.error(error);
      }
    else {
      console.log(mapDiagramRecord);
      if (mapDiagramRecord.project?.id) {
        const userResponse = await BPMNService.getUsersByRoleNameAPICALL('Editor/', mapDiagramRecord.project?.id);;
        const userData = await userResponse.data;
        console.log(selectedMapData, userData);
        let filterUserData = [];
        if (isEditMap) {
          filterUserData = userData?.filter(user => user.userId !== (isNumber(selectedMapData.authorUserId) ? selectedMapData.authorUserId : parseInt(selectedMapData.authorUserId)))
        } else {
          filterUserData = userData?.filter(user => user.userId !== parseInt(loginUserId))
        }
        console.log("filterUserData", filterUserData);
        setEditorUserOptions(filterUserData)
        return filterUserData
      }
    }
  }
  const closeAddEditPOPUP = async (isFromEditorClear) => {
    console.log("close add edit popup", isFromEditorClear);
    // if (isFromEditorClear === "YES") {
    //   setEditMapDiagramRecord({})
    //   return
    // }
    if (isEditMap) {
      setIsAddEDitMapDiagramEnable(false)
      setIsEditMap(false)
      setIsImportMapEnable(false)
    } else {
      closeDialogPopupBox()
    }
  }
  // const getCustomerData = async () => {
  //   const orgName = localStorage.getItem('organization')
  //   // const org = localStorage.getItem('organization') === 'iGO Solutions' ? true : false;
  //   const customerDetails = await ProjectClientService.getCustomerDetails(orgName);
  //   const customerDetailsData = await customerDetails?.data;
  //   console.log(customerDetailsData);
  //   setprojectsDataContainer(customerDetailsData.projects)
  // }
  const openAddEditDeleteImportMap = async (type, params) => {
    const orgName = localStorage.getItem('organization')
    const org = localStorage.getItem('organization') === 'iGO Solutions' ? true : false;
    if (type === "ADD") {
      // await getCustomerData()
      getAllProjectByUserId(loginUserId)
      setMapDiagramRecord(
        {
          diagramName: "",
          docStorageType: "database",
          configId: "",
          configName: "",
          mapPrivacyType: "private",
          mapAuthorizedUsers: [],
          project: {}
        })
      setIsEditMap(false)
      setIsAddEDitMapDiagramEnable(true);

    } else if (type === "EDIT") {
      console.log("edit the map", selectedMapData, loginUserId);
      if (params.mapPrivacyType === "specific")
        await getOptionsByName("EDITORS")
      if (params.docStorageType === "sharepoint")
        await getOptionsByName("SHAREPOINT")
      // if (params.project)
      //commented for the admin while opening the map
      // await getAllProjectByUserId(selectedMapData.authorUserId)
      // if(!org)
      // {
      //   await getCustomerData()
      // }
      setIsEditMap(true)
      setMapDiagramRecord(params)
      setIsAddEDitMapDiagramEnable(true);
    } else if (type === 'VIEW_EDIT_MAP') {
      // console.log(params);
      const tempSelectedMapData = params.data;
      if (params.data.mapPrivacyType === 'public') {
        // console.log(params.data.mapPrivacyType)
        // console.log(params.data)
        // return

        const userResponse = await BPMNService.getUsersByRoleNameAPICALL('Editor/', params.data.project.id);;
        const userData = await userResponse.data;
        // console.log(selectedMapData, userData);
        let filterUserData = [];
        if (isEditMap) {
          filterUserData = userData?.filter(user => user.userId !== (isNumber(selectedMapData.authorUserId) ? selectedMapData.authorUserId : parseInt(selectedMapData.authorUserId)))
        } else {
          filterUserData = userData?.filter(user => user.userId !== parseInt(loginUserId))
        }
        // console.log("filterUserData", filterUserData);
        setEditorUserOptions(filterUserData)
        setpublicUsers(filterUserData)


      }
      // console.log("diagrams", tempSelectedMapData.diagramXmlIds);
      const mapOptions = getMapLevelOptionsByMapData(tempSelectedMapData);
      // console.log('###', mapOptions);
      setMapLevelOptions(mapOptions)
      setSelectedMapData(params.data);
      // if (process.env.NODE_ENV === 'development') {
      //   await BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(tempSelectedMapData?.diagramXmlIds?.Draft?.diagramXmlId, 'checkOut');
      // }
      const mapStatusCode = await childRef?.current.getLastSavedXmlByUser(tempSelectedMapData.diagramXmlIds.Draft.diagramXmlId, tempSelectedMapData);
      console.log("mapStatusCode ", mapStatusCode)
      if (mapStatusCode === 406) {
        // if (mapOptions?.length === 1) {
        ErrorMessage("Map already opened by another user");
        // } else {
        //   setSelectedMapType(mapOptions.find(option => option.mapLevel === "Master"));
        //   // await childRef.current.resetToInitialState();
        //   await childRef.current.getLastSavedXmlByUser(tempSelectedMapData.diagramXmlIds.Master?.diagramXmlId, tempSelectedMapData, "YES");
        //   // ErrorMessage("Map already opened by another user");
        // }
      } else {
        console.log("tempSelectedMapData ", tempSelectedMapData.diagramXmlIds?.Draft?.status, tempSelectedMapData.diagramXmlIds?.Draft?.status === "Published", tempSelectedMapData)
        const isDraftToLock = tempSelectedMapData.diagramXmlIds?.Draft?.status !== 'Published';
        console.log("isDraftToLock ", isDraftToLock)
        if (isDraftToLock) {
          console.log("intervak staterted");
          intervalTimeRef.current = setInterval(() => {
            BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(tempSelectedMapData.diagramXmlIds?.Draft?.diagramXmlId, 'checkIn');
          }, 0.5 * 60 * 1000);
        }
      }

    } else if (type === "DELETE") {
      setIsDeleteMapEnable(true);
      setSelectedMapData(params.data);
    } else if (type === "CHECKBOX_DELETE") {
      setIsDeleteMapEnable(true);
      console.log(gridApi.getSelectedNodes());
      setSelectedRows(gridApi.getSelectedNodes())

    } else if (type === "IMPORT") {
      if (org) {
        try {
          // const customerDetails = await ProjectClientService.getAllCustomerAPIcall();

          const id = window.localStorage.getItem('userid')
          const customerDetails = await Projectreceiverservice.getProjectsByUserId(id);
          const customerDetailsData = await customerDetails?.data;
          setprojectsDataContainer(customerDetailsData)
          setMapDiagramRecord(
            {
              diagramName: "",
              docStorageType: "database",
              configId: "",
              configName: "",
              mapPrivacyType: "private",
              mapAuthorizedUsers: [],
              project: {}
            })
        } catch (error) {
          console.error("getAllRolesAPIcall", error)
        }
      }
      else {
        try {
          const customerDetails = await ProjectClientService.getCustomerDetails(orgName);
          const customerDetailsData = await customerDetails?.data;
          console.log(customerDetailsData);
          setprojectsDataContainer(customerDetailsData.projects)
          setMapDiagramRecord(
            {
              diagramName: "",
              docStorageType: "database",
              configId: "",
              configName: "",
              mapPrivacyType: "private",
              mapAuthorizedUsers: [],
              project: {}
            })
        } catch (error) {
          console.error("getAllRolesAPIcall", error)
        }
      }
      setIsImportMapEnable(true)
      return;
    }
  }
  const clearIntervalRef = () => {
    if (intervalTimeRef.current) {
      clearInterval(intervalTimeRef.current); // Clear the interval using the ref
      intervalTimeRef.current = null; // Set it back to null to avoid multiple clearings
      BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(selectedMapData.diagramXmlIds?.Draft?.diagramXmlId, 'checkOut')
    }
  };
  const getAllProjectByUserId = async (id) => {
    try {
      const response = await Projectreceiverservice.getProjectsByUserId(id);
      console.log("getAllRolesAPIcall", response);
      const data = await response?.data;
      if (response?.status === 200 || response?.status === 201) {
        if (org) {
          setProjectData(data)
        }
        else {
          setprojectsDataContainer(data)
        }
      }
    } catch (error) {

      console.error("getAllRolesAPIcall", error)
    }
  }
  const getMapLevelOptionsByMapData = (selectedMapData) => {
    // console.log('selectedMapData', selectedMapData);
    let mapOptions = [];
    const draftMaps = selectedMapData.diagramXmlIds.Draft;
    const masterMaps = selectedMapData.diagramXmlIds.Master;
    const archiveMaps = selectedMapData.diagramXmlIds.Archive;
    const draftOption = { label: `Draft ${draftMaps.version === null || draftMaps.version === undefined ? "" : "v." + draftMaps.version}`, mapLevel: "Draft", value: draftMaps.diagramXmlId }
    mapOptions.push(draftOption)
    if (masterMaps !== null) {
      mapOptions.push({ label: `Master v.${masterMaps.version}`, mapLevel: "Master", value: masterMaps.diagramXmlId })

      const tempArchives = archiveMaps.map(data => { return { label: `Archive v.${data.version}`, mapLevel: "Archive", value: data.diagramXmlId } })
      mapOptions = [...mapOptions, ...tempArchives]

    }
    setSelectedMapType(draftOption);
    return mapOptions;
  }
  // const getLastSavedXmlByUser = async (params) => {
  //   try {
  //     const tempSelectedMapData = params;
  //     openSpinnerRedux();
  //     console.log(params);
  //     const response = await BPMNService.getLastSavedXmlAPICALL(tempSelectedMapData.diagramXmlId, tempSelectedMapData.authorUserId);
  //     const data = await { ...response.data };
  //     console.log("data ", data);
  //     setResSavedData(await response.data)
  //     setDiagramXmlId(response.data.diagramXmlId)
  //     console.log(response, response.data);
  //     if (response.status === 200 || response.status === 201) {
  //       let selLang = { label: tempSelectedMapData.languageName, value: tempSelectedMapData.languageCode }
  //       if (!(tempSelectedMapData.languageCode || tempSelectedMapData.languageName)) {
  //         selLang.value = "en";
  //         selLang.label = "English"
  //       }
  //       let parsedMappingDiagrams;
  //       if (data.xmlData === "" || data.xmlData === null) {
  //         const dataTemp = await response.data;
  //         let tempMappingDiagramsLocal = [...mappingDiagrams];
  //         tempMappingDiagramsLocal[0].name = data.diagramName
  //         tempMappingDiagramsLocal[0].meta.label = tempMappingDiagramsLocal[0].id + "-" + data.diagramName
  //         parsedMappingDiagrams = [...tempMappingDiagramsLocal]
  //         dataTemp.xmlData = JSON.stringify([...tempMappingDiagramsLocal]);
  //         setResSavedData(dataTemp)
  //       } else {
  //         console.log("(data.xmlData) ", data.xmlData);
  //         parsedMappingDiagrams = JSON.parse(data.xmlData)
  //       }
  //       data.xmlData = parsedMappingDiagrams[0].diagramXML
  //       // parsedMappingDiagrams[0].name = data.diagramName
  //       parsedMappingDiagrams[0].meta.label = parsedMappingDiagrams[0].id + "-" + data.diagramName
  //       parsedMappingDiagrams[0].name = data.diagramName
  //       console.log(data);
  //       let tempBgColor;
  //       let applyTemplate;
  //       let isDefaultTemplateEnable;
  //       if (data.template === null || data.template === undefined || data.template === '') {
  //         isDefaultTemplateEnable = false
  //         applyTemplate = {
  //           "templateId": null,
  //           "templateName": "",
  //           "companyName": "",
  //           "companyLogo": {
  //             "imgname": "ismile.png",
  //             "imgcontent": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4nO19eZxdVZXut/YdakxVpUgqAyGBJIQAgZAQIISAgIgIdBQFEWnaHqS1UbRFGx5KP1pRkbbRRujGJ+LYIhgaRIaWQSAhzJlIQhIyQKikkkoNqXm49569Vv+xh3NupUKGOnWreNbiR6rqDuecvdfaa/z22sAIjdAIjdAIjdAIjdAIjdAI/XkRxX1BXnfnqbrlrWuleY2/hQgDApBEbilifwggBICgBBAIIADYvo/wfUif70VJxF6ZICIg/zl7FfvTf5wFKvI+gfx3o98z94xcQwAlFH7G39c/GgDqc393z+hEiX8cEpg5cp8DoPpcUwRAIo3UqZ9CctoZdyamnPoaYqDYBEBkt5Jty+/Vb/7oUuhsOTQbnkWYZoZmX4xMKtm3BGKFBH7uHQMk+qIYYRA3+RS5pr0X5TEz5AJFr5fHHeR/lgEndOKvKZbhKvycff58QaPIcyDvGv5eke/vdW8AJAJxQu/mDQASRVCTZnWmjj3v5NTJn9rULzMOgpIDvYAjXnffidj50gIJesqh0sDoGSClACE/cYYIAjGr3TJQiKyGiE4SRYTBTqZnsn0ZsOvWXEuA8DvI/27+dcV/B3bt99Uo0RXsrhm9NkmEKfa9PAEOpdYKidNk7rFCzQGvUSI3YAFROFYAkO4WoHkH+J0V5Tpd8R0Al2GAFJsA6PqXp1OufQZUMahq2g941NG/IaWgKAGALSPIK9uo6gxVaGQFsPK/+8li2bfKcp9xK5JCwYiwyWqPyOp07ziGR67X9zPvdX/Juz9BKF8jRe7Uh/mAsgp/bwHI12K8522gZPQK3rEG0lZ/XrDhmfOSx573zL6m5EAoNgFA124ADJQfCVTPerlo1hdWxnbtEfKUeemX3di+phQcVEnH7qqBXk/t/yMHRnT4OadDFACCUsVxXXaE+lKmazULIEJg7qtdDp5iEwAkikqjfs0IDQ4JrHMIIA4fPj4BCDLdzgaOiMAgEuvevf2KQ6f4TADrwDlgsScXRsgTsQSAy58M/HrxaQCVSgOwDxXfZUconwTC0eTUQCk2TknQ2y3oE0qNUPyU7d1jfqFhpgE8jbB/sMm7gDScnEAAEJMK3StPP0KxEbmkakzzHLMAuH9GBGDQqN/s4qFTfJlAhIWP4ewCBrtXHUe9DR+XhjcgXQ2QbIeZ0OIxUKXjocbNAcomPKQOm75+qJ/1PUkkFkGITwCSJRUMgQKB9//pgpF++5FiqX2qnCZ98HHseA65l79erVKV0znbCRXkwMymNEu1EEpCb38J0tv+md5nb9qTmHjy87xrzfcTE+a2J2f+RXaoxwJEnf94NG18AkAJv/CHgwEIOmrHU92zZ/HO5y6hTMun9OofggVIMIN7OgEwRFs7yrb8KoBIMwQ0XW15BsHmp06lcSddn+to+E/9xgMPJGZfvnSox5VXZYwh4RKfAASZbkQclKEmeesXv5XWzQukbXtaREBsapHMCoCAHCAjUs8na1+J2Q+Bd70BQuKabGfjotyLd76UOuPay4dsUJbCOuXAjW185lrnsm4Ch1IAgnV33hQ8d3WH7HjubG57N03CENFgCIRNJh0sEFZgsbgEU10xZVr7OxgQJmMedA7ctG1SbtV9n+x5+EtvBWsf+tshG2AUYzD88gAUk1wePEnPrmp++YYvyc4lt+jWt8qVNuAMFlj4lUCxgLT528DUyMC03GfYgjbEwcrMm2IBHaID8LZXZwRrH7635/nv/+UQDBMA8rAEA6UYeUUKIhH1VDiSljdr9LYnXuXmdbdJVyOIAQ0NCINYW0YTRBQEbHw+BhQLhBlgDqFiIhAGhAFmApisNhBAC8Aaeud6yFtL/qP7/r8fEiFwuRaJQQLiE4BUaYVTS1RAAQjaN03n5tX/w5vvm865jmJiWDtuJ0nI2ne2zEYes90zSwRniCiI1YVbUdiWCKRtV4U0bft1z++uvaBgg0X47ASAh5UA5Hq7AZenKKATsOFXc/ntR+YKB6GDbIVARIHErHRox2ACsYWoibKfC2Fi5rsW1SvWX3DOoUMbO7+hoxHSWvfzzBPfPqtwA3b4wniYF18xKFlcGpYoCyMAvP5nc6Vt0wPo2g3SlinMAIzzRtbWM5IGSCEAWEOgwMLeD3AOoGjj/CHiF/iohq1psAqChMFC0A3vjNftDUuCxi1zCzJoAKGmHTjFpwE8zwuj/oOWDXO5a/ti6d7tbaLLk4toz1hKlINKxvxUVU4FCRnAprX5xBZhE0Ebexh7lPlO7dvvkAiYyWsD3rwMwapHbizEuCUPCz1wilEA4ilPHijRpvvOloYVU92KVZZpxAJhgvHtBIIUqHT8k2rahaeo6Rc8hJKxICRBTGCwcfIkuvId8ykSHZjXlVUBTjCI2fsWetMLF3Y/dceFgz7wZHGFg8DHwb7YEkFEAqt8C0Kcbb1dMm2GWWC/kUOEQQyAyWP1BYL08Z9eDuATua3P3Kprn/8Y3n11JmXaIMwQ6ycYE4Ewl+GdRPMZzQTlNA3ERpfKCF3Tu6UoXnElgCcGc9xikVdxUawhO1l1Otg+oN68+BZpWmu8eliGI/TqRSLPYdW2o9S0825MHfeJS9S0D9+oxs9rF5UCcbjaBeydQpcjYJsvcILgsoYkymgeAUQzuHH7p3ufvrt0UAfPQbffaJO31+zQKD4n0KlRYFAFgBtWTtbvPnEescviOebBO2pgCu26y+xFKDFuzsb0mV/7XtFH/7Myffxl96vqo2qZEsZn0GZFg63H751JGDPnTIKG0R5sGaEF0tEC3rP9l4M3ekN+ODFU3eJMBCG6J26wiJtWn0rM80W0wcX7VRnacecQhip839dLnfmPVySOu/hKNeaYu1A+ARCJyAxZixAVJoS+jsAIG8OElCyQxm2n5rYuP3XQJsA+V1zTHGsUUJBC0J51M9G5zThvka1eLnvnEjWhM7f/fFlqzlXLEpNP+2pyxnlHJKaeuUmVjwUxwJqt40cgplALiNiQE5HowTiI3N40OXjtocmDNXxJFVW5PY1xUKyAkEKQlE28RYLXrMNGEWaTZz7ZRE1eJm8/lD7jmiyAHbrlnY8GG576ONe/9R1sfRmczUCJgBFeT/rkCgBYARFIWzOku33qoE1AzG52zE7g4JM0rke449jYYNE25odL64aqmiTcYHkglBh91MaiBZ/7rpp25pz0GZ/9nRo1bo8kUlDahJfCztmNaDxbZSQBEGSAipp/GpzRA8qbH46lFhC7BhAMbjVQOmrh6vu+XGtTtGJXfn6e/8A0QF8qmn3JagCX59Y+Pjd486nPcXPt31PjNjDDRg2musjWASXnlAtBmuvGxD3ukNzGMInF3MboA4SMGCxHMGjb/DXK9ZoKH5NP+/oGDX7VCyjaRGIAj5M64aKVJZ+643OJKXM/SjMWvgRK2mtS6Hi6WoIVBmmqi2O4+ySDvRxumUCEadTB8gOpZ89pZtIVBNokRdkCPZzDJ+J9gfD1gd+7+OJ//gNNmHFmas5fnJOYdlotFZVZDRTJGdiohDtaBn7DfZAIhf5NDBRfJhDwIcpgEWc6vbPnVqBEU9De8aOIlx5fyFR6zrUM4Pls87arcg/dugRvvQKTKYLPQ0AIurcnnhv2Q271R/cID4RiEwBR6fLBjgEV2KB4XTaO4fMAYbLG+QE2VIrxkXKvLp6Y3frahdlfXHeDNO+wvohFFlknlIWQjCFDt0+KpILjGFp8GoAznXFda5+UqrTeNoXM9swPy7ouLHTaII6Z6nnmruty65d8hre8eiJnsiBhKDYMJ5stZNvXSNKDlw3mrrYdoaYduA6IPw8wiJlAKR79pLBcaibeoX6AaN+f0ClzDuChe8u6bn2a92w/K7dh6Y28/LFzdUs9oNnkBXyUEZqkhNjnKq2Ma8j7JhmOeAA314MkBMnqo3+KRCm0vRf7okh/gA6bCeynFnAglFn75IX6rWXP9T7xw6f1ikfP5T27ANbW5JABoAiBNINYQUBGKFigxk6Je+h9yHY5i+FKg6MBBlELqPKJ4OYtVr0ry5Aw8SM2DHT5AIehOxjKPv79z+deeeB22bG+VDI9JsDnhE0JOzOjQKzBIEAYJMprnUTNUYMwckMO2RQX7C4+J9Cp3LguuC8ac9weatpcbaqA2tt+h/kDcx7jhSWvHLwv6n31vmqs+9NUpsTjmdcXVyCTLTaoYgJEgZmhALDFESoxzA+RSGyyhJRC9s2Xrh7kWYiNYuwQkoy0BhtEMejt+KFQyisZcSVgm4MIYWGRJNB+Fktu7eOXBqueuFu37Hpdb32tBplMMZjtdcPun8LhxhEHGSfnczBBMUBVNUhMPbF1sIZPYlrqxpQIjNEEqFRxWCodvGQwlY1ZQ2U1vWjZUSyATcOGRaEwFLRPsQ8nMKhbWxyseaIC6bJHM3/68XRp2VUtQQbCygI/yAsV2OIHOfzbvScCQIdbzYT1K+lZC18ZtAmA9T1MNWTAFDModPDLQenTv/oHyeUeMxNvsYDe4UNEE4jFC+yNUcg1v3N28MYfbufGd3bnnr/nVGnaXk1BDg7eBY60rtWUDxPzv5v/SVufw9rm1Ikf3JGa9+EdgzYBzvuPydzGuFQjBZlBTgilTrnapERBCDd0IG/FhubAJoQsdT3+rfnZP/3o17m1T16jt7xsH12MMEXxA/Y6YVo5cn13L5f9YwCsgNJKqJmn3z6YY6dUujxsVD3weY41CnC2crBJjZ5yZeLweZdy7euABXWGzLfev0X9GuyeRubRb57NmbYbg5WPnA3NaWGBYgMRhwBCBNamFXx+jiHC/KhGiYSbRsYUUieft674lHMHVf2DVBKAXQADp5iNtdh20IPbIkKNm51Vh8/5Lyqu7Gflm+dgWGEIstCtjZ/RO9c9pzc8fz4FnAYbiLfD2JMo4+AhEjp6jKE1B3sxX3zEAQFo4tFAzRHfHNSB59EwCwPzn6cA0JCe1i+o8vFjdFfLBWEbeeuISbj5Q3o7gUz3xaw5LBax/YwgXOns+gSwdyLNuMTvExAJdxyFwkAglURqyvG/Sh5/+lODP3BXd4hHAGJHBFFMOer9Ufqsr7Unzv7q4kTVkXaFwm/dCquCNkwMtMnXO8aK2+Xj7Dt7BDCYAI18G2+ZrWz+38gZW/OfQGL2B4LSq7/9mfRRJ7QP+sCjFIMMxI4HKOTG0OTEk35G4479LkqqI3kBNhU6XxMgjxEUjT7Mh4V42dctwsibFX+sS6j2HfgTWqBYQU06GslTPvS9gg0a0Y4mw61PoKMCCkHxhbd8Q0084QZKl8Hl6VmSkUSQTd1a/8Cnin3kEPHyXazvVj6Qpwk4kvQRUVCHHY70xX99Q/EZi/65YAO2j6xAw2x3MABXF4/LQTlQKrnkB/+aqDnmJ1RUZbqAQANw9j3KfLfZA36FO+0QIoxdAojC3+3nSUI/IlFzJNJnXfKTktMX/WtBB2tGFlvJJT4nMNPe4FEqheU/AIBGjf9KYsIJgV7z2DXS0Riqch3i9SiiBQwjyReNDLIXcM0hvJOnJQz1hECUBspH1ZZc+U+PIacHDf1bKIpPANIVNYCE++wKTOlFt3QD+EL2lV+251Y//jHZtXmm0dmWnH/izQAQ9hIg7/YLu/eijGeAk0AyjeQJCzcqJC5LnXTOusKPMqLFhmMUMBSM70vp+Z+5UU2Zd0nqzL9ppbLqLJAALIAELjy0hR6TK9A2+6cidQU7FIaxtKoIauyk1uSMk25InHbBJSVf/vchYb4jL8AxUKx5gH3UXQpOJR+5fiOA0Xr76i/1/vGuD1FXy0I01FaJzvgNpeRNgPLJHYHrM2CrfKWjQFXjaxPjpy0r/cLtV5qr/3wIR+Z2JSO2iY4XENJP4WUoKXHEST/Ktdb9Qq9fshBvrzqDSqu+FGxZUY7GbUAma715A+oE2ISGJRVQ46eBxk9+Td7deEfq/M/WFp1+0bKhHkseucU2rJxAIDaYUpyUqjq8HcATurH2KV238Ta9e7vCnjoUffHux9HeCN3VDqUUUFYJ6em6NffIXcvosImgOedky/761m7c/PBQDyGPHONVTGDXGAXAPFlctiluSoydHAAIM3XfO+2MfX/6eQDfH+xHOiSidFE1xPUIHPhkx35gRGFbRP4ZUqrIHhYZT9E91iZRhWwQ+edKIuR5NswAIY5GhGBQqaej1v06rLaGmQLFMHUA+hA3vHoSb3t6PBrXIuioA2kFVTENGDcHOPqi+tToaauH+hn3RaR1Ns54O8Y8gOT/HKYUvP4vd+qN/3WBdLdMp55WQAMsDOqsh+gVkNbtW3Kv3/PH1ClXXzvUz9ovJVN+39mwCgMl09Hg0TT60K4RrLh/Enc1zaPiihv17k1jkO2ElB4GNXYagjceuyh9yqdaUycuqj+Ua+s3fvBZNK+5Mdj5ylRkO01XL00W0cvgTAukYw+E35ouyVVfzDzxfy5UR551a+q4C396KPfLLfvdzMxTP0Vy4aWP693vAD3dUOVVoMMOX5Zb9dStpR/7Wmdi5vyDBo+KSqbFFapioPg0QFFFDYBDVk2ZF3/8tWDrC1fpurUnSm+HKyuBhBEIQKPGbQjWPPFSz7M/uLXk3OseO9DrSm9dqSy/fRHvfPEe7mkCNNu277A/I3/blvCSbUOw6U9TVevOe7LP/KA+fd6B30/vfmdG8PJDi4KNL32fezuQ/cMdFrwqMPAzTKWqsX+Vfe2xNZlli28rWnjZfQc1UVb7xxVvxegDSOS8gAOn7GPfSEq69OZg7RM3UfsOW78xqHcSAbtjqDrqodsbFlDbjnt7n/6329InXXaXGjtlvwc5Ba9/91x01d/NPQ2W6QYswoHdMaTFQ8rF/u3AI1z3JiSHezNL7rqq6ANf3C/cK7vykXRu+WP/nVv99Cxp3m6ZZbKjCaGwk+qe3ci+9tiJia2r786+/tixYPpm+rSLggOeNIdzGE6nh0uiuML8cnAiwNnMbcGGZ2+i1u1mt43f2WEmz4A3CIKEiXyb62r0iodv11tfvG1/187VPjofvXsele7dVcTkV7oEAndCiGj7fyBAENlgqjVIM3jH2hpu2Prkfsex4ZVJeufWJZk/3jOLm7ZbP801pyBohHsHhBQQBNC736nIPPrjm6Sjeb9jiZJLtg2/MPAgl3+w+flr9K43r0NvqwXgsOnA5S4kDmfoMowEIYJku5B79Vcf637w+nnvdX3avuSr0lFnoF6BOSUMGn6njxcIjwYKTYNi2HOFCHrjC+h59FvXvNe9el98YH7w6mPzCWYPIYmZ2oTNjhIEyqGT7OBIAN69DbkVT1534JOW6/ZzE4MXGJ8AdO95GweBVQ1WLa7OvfDjT6Cj3kCyyTRbgBCUO8gBNrQkswtYsQCiARJwe8ORqqT8T/u6vl575yLpqrsYGoBmr95Du8++hxA0INY0OD9Aa4A5gNIM5ALwplevyr3xxKT+7iVNtZOkpe5eaW0AhKBBxkcTApOyql8BUCACzG5i8juL9dY30PXT638rzXX77yxBKp3XlGqAFOfx8aWmebOAD2A7blC/4VzOdJ4rZqZsjZsjmGLyP51ZEYKZQAveDNb/qYIbtnyyv+sz81XS2VAszIAmy2CDAIYOVb/5nUOn0MHHWUABgd1ns7n52bXPze/vXtnaN7+ht2+oIKu/SMjjCowWs8qa3D9mzA7OTsLgui3nZzet7Pf6UaLyqhlueuOAhscmAPrtF5YIKVCQA+VyFfv/QnCmtO/2m0gM1r0PpNyoAC8A5hQwM8kQQLpaEGx+8bJ+r5/tuBS5XtPIQcMz20C+bX9f93rEGQS71+weAA2ACdzaAN6+rqrfoSy9b4xIpMdwVNU70Kkv4YaoJCcgwoDs2V0dLHmger/zluk90tUBODlwHz6+KKC8ppt0FtK2E9Ja/8Oeh/+R98KtWtgVCUEyHV+CBGG4Z/8LJw57OZRi/yG3gpBE7s3+/TPZs9U4lXZFR7191+07Gv6J3eEr2n5GG81hogKGBILUsWffA/xPXl4gW7vhyN6ffeVId/rIe1ZDJez06eDoYv0c6WwB7yn6YPePvlTOpCNzAI+zyDXtQHbZH4pZBElJbEvWTNn2Hnc7IIpPACbMeoU6G18Sblug33qqAmXVP/eqz3KO2HrAIuAeU5l1TSUIKp/5/ZDAqCzXjkUJg5u39//h7j3GqxeAtF11bm8A723zfTsZtk2nrOaANoARxQBaG/e6jeppm5eomjBPN+4AgUxPYf/A4UDyehV55osfl5BAd3V+Xt5e/XnDb2WdvHCbusr0QrpaARCSJ5y+PDn7zOXvyZQDoNgEoPjc63foXauezDxyUwV07yzpbjOKioEoR8Wjb8UDMIn6qH37fh7ZSWN3FhBgVkYu0+/ziNZWhVt17h1BhDt6nR/gNYBlOoc+gxMG1mbzaF9izsIcTBU+vBKER7rZCCAEpUYcOJ83sT5Dbzekt9vEEVGBETNPQgqJmilIHH/GOjV5xpX7ZcoBUKyIoMSEOd8KXv7Z/bp+7cV6xyqI2HDK6jIj1dYMjDnydt6xDh7jDqfajYfs1D3sTwKB3YY9YoATECVQo8fv42HKQbrJr3oR8cwXb+/dGUMuHBTjMDIb2y8CCRIAM0gzEiV7uzZUXLFeOvasV4zjxKg4I6TRIF2i/+d77yGKSkCkfoVk0RtEyn/GbWJRAKS4HMlzLkVyzlmPpY6YGctp5rE3iUqe/rebAPxgf5/rXXr5P8mO9ePFbuF2ImBWigmcwj0GbkOkgobZ1k0wK1pNOwPAH/a6PlVMBjfV2uPhBBRI6PQ5vL/PAJINDWGjBPs5OEHREFaQqrF71SGSYyZsZJ1dD5LjYJ/apemjJ5nlCYF/yLCXoRSVQlWOfXTUbf/z4HtO3I+e3d/UHhQNxTG/AACpXX0tSirMHNuYOfTyor19QseQwd6JYgKQTKNo+oLH+71+qvKPEAEFDNIaCChc+UGo9s2qZ5A2m0LJOoekAeTgi0ZUVAletXSvCiGNGsfFZ11pmWuOpnUNsymP8fkr34UFLGa/oRo3Ganzrohjag+KhkwA1MQTloHUUnGrANZUCPksWpT55gPuJDDTtkUddSqrGWf+ot8b9LbdKyXVprVs4HYAuQbSfcM/gCO+ANgoBNFkVr8WJGqmcNH5f9PvrWjqCbeo6sOt9jLmK+9gx74r3zl/VsCBBBJlVUuTU08oOPp4yASg6Nwv1yfnXvEoJYt9Fw8XFDvHKEreDlqToaomQJVUXL6v6ydO/eJGGn30RtIKvplD4FQ/2zAQXt2TtprBhYdOW2hAaQEmH/NQ8pTz+1XP6aPmrEl94LLlKCmzHbzIP7M7y7gvjtszXwSqeizSn7rh0eS0OYdU6h4IDZkAAEDRWZ/9t0T5YT/hRBpiljZIEpEVEl39TouayU3O/sjK9Bl/tXJf105WTV6XrJpyLRKlYNZQ2nUQj4aCCFPBPkcgkUiBjec/6VikPnDp/3vPwUj28sRRJ6x0Dp3blLoXSsr/bQW8fDTUjFN+kpp8zL8d4LTFSkMqAACQPvfaWxOTZj9IqXJ7No+JCthpAqMU4CQgUVKJ5Omf3qYOn/GhxMRj336vaycXfuWZxLyrtlGyAloCY0I0gZztZwYFtiFEoEyoGJg+AaIBBAQqP6xVlR12eXry8c+8172KP/yFt6my5kPJmfO3Ubok9Gd8dtPmsW2dA1CgUdVIHb/gLqjklwc+k4dGwwbBmXn0W/+tG7Z8nLevgVGNBHcWKYmGqCIkx80AJh7z3dTpV/w2WXP0Ae3Py25bPgvvvLQ49+qvZ3IuZzRAIFDaHC+LwMb7gY3zbb6AAgHKx0CNGXfFqP+7+P4DHUf25Udm5V78/RXc2vB1rn/XNKswhssmfwiiCMkJR29Ux53yUNmnv/6NQ5mvuGjYCIDe+eaY7PqnZxDzP0hz7cV610Yg2wMUVyJZMxU06cRl6Gy6tejC61866GtvXz0ju+yez/HOzV/k1oY0sUACs2FU5Sw0zCWDtEAkATVuWm/iiJk3l37u1kPa/99917UL1LgpN2a3rV9IjduA7l6gvAJq+hxIkLs1VVnz+6Irrt90KNeOk4aNABSCgvVPfTHzwm8uR6ZnIe98G5LLAllz/hCzQKVHAeWja6Vy/NKyv/nmw8mxkx8a6mcebPqzEgAAyG1bMVm/s3qBXvJrJGZ/+Mug1HxGAgBe4VXP3ZGcv6i2+COfPWgt836lYScAun3LGOlunonGteD23UBnEyToASQJFFVCVU0GqmcgNe2cAcfMXLu6VLe3JFmloA6bGKTGTe0e6DWzLW+NSXTumsnN60Hde8wpIqkyoPoYSOmYjemJpzQN9B5x0rARAN79+nW69umx0lo7k0pqPiadDZBMF5Dphuis2cevikGpUUDxaPC2V79Hk+cjNfuStckppx8csjbuZ8/srtK1z95A7y4BBz0zqWzix6SrCZTrMSVpSgLF1eC2Hb8njY1q4jzQlAVrU1POGNLnBoZYAHq33D8m0V1/vnTU3ygtm6Yj212M3k6bnNFh/d4BOXSkcKMBShVDEmXtiQmzaqWp7iKaeV5T8Qf+bq9VHNS/NkbVv1zK9W8gqDq6Jjn+5BvR3TwD2Q6wzgKShCoqA1LlQKrkN7ml/36fmjQXatJ8pI5dVLv3kwO5V24qxcQzb0fdcwulaW2SkJrJ2Q4gmzHnB9kTRaADW3Cy7eaRgiRKQUC7JEtr0zM+vI2TxbeqI07elJx4YsG1w5AJgN7028/r5jeuRsOKuchmAK1N+KUBzdojcSSwTporz2obRruYXQClAYwaj+SMc35adNH1VwMAt7w5Ve/ZeD62PAxUHnM1ehvnoq0OQVcDFAdgbYEo2jaIFsCdRQRVAlU1BVQ1BbmtS/8hdeQC0KyPv52eNM9Dw3Mrvn2P1L/8WfR22Eqjg5VFEk5sDpzw2EObgnanjog296eK8VBHn7uSu1suK6Y5P9UAAAqUSURBVP2Lb79nbiNuGpLDo4P1/3E9b3/8NnTUQXJBXlWONJtkiWaPGYA79YMJwoH9KQDYVOkYQFk1UDF2DwBkNv7s+mDFbZeLqLmquxG67V3bF8ge9+pwCI4xgGkuLfZZgi7o3RtAu9aDkLhb164Cdr+zM/PgtSsTC65+ITnxxH9V5VP26OJ3QN3tJt+jlT3DSMO3pXPPbX/35WcxZWdiCxVv2QVevnguiisX53aseSA16cSCtZ4ruAbIrfiX71DD6q9Ld5sttOgQn8faonBMLl5EgMDky0UbhiFwwsIGwJEsBY2durrog5dfJDufOQm5rkepZYtirc3Ea20FyRSS2KKD3DmDAhih87Bwsv0AbdKGOazksUBSZUgedyGrXM8pybP+rl0v/epi6W4+iXMZKCZobTe0uOd1R8kEBiugrQZwmozZtp/VAERDjTsBydOv+nZ69gUFaT6ZKMRNHOnO2rNly+/uRVcjRAKwaJBWIdNdLp4p/N1OvLOjHtnDZtdQct7lK9Wk4z+ZzKz7sbRuvRkd24m1aaZsbC5ZhtvijEXtevyey9fbSp5D7/gV7HL6djVLkIXUvUmSzXwQJdU1JJ3XIVG8kLuaJkAsY5nDVrT+wInIeCQ6TvbPJkyQ9kaQSi34zoPLbikETwpaC+DN9/8dd7wLZrdJw+bcI02boQGxx8KHBRvY3TvagzpJpVF08id3JCcfebmSVTcH9S9fID2NEM0WLCKeib6JtESFTMLXLFPIvu7wgRbC758PcKqbwM3bpueev+carvnQzTThjMtU6cQGaItuitw73IGE0KENbFk62pncwteEBcGaZ5LBOyv/oxA8KZgABO21E9GwaippZfLj0U0aHpgJC9iAx+2R27DpdvFYAAWNnrqJKiZcpLrfuhltW/+SgizC8wLZl2E90FNCZtgmgXlA0FAIJbLynWYQixEQ02bOqnVub0Bu6S8+HbTRSWrCvH+W4moPInVVxvAomwjq2Aui0RDCALHtUxgIOJdB9o0nawrBl8JpgJ76eZyummuYCWNrfTk2nPhw1SB8zdbmSSzCVwvUyYteS846bSY3Lv9LZDqN9mBtK4nWy3ZqNsJYcY6lZ6xjFPx93b4BcX6BRM2IPVDKRSk7NylsX3MLjZn5e6Qrnjd7ECnCfHePiCD4swZCITOCAysMDLVrS0HYUjABUN0N6USQK3YQLPZxfrhDx8f70UnT7CeHNUOYkBg9BeljTrpRr7/nK9LdHKpZmDAy9Cv6mego850giviV6tvE2jDOf5dNG1yRUGuJMEQzgg0vHBdsr5+eOv7TSw0GMfo9hBouCk/3CGRnHiQ0h0zQVJgArWACIAhtudt1wzYc8qsyAtmW6JYtgQ39bEOHSSdCGlfPR8+e+fAnhxpnyzh3biVHGN+X+f51lwcQ85xeCyCC6RPrPhg0MpxDaVcr53II3l39FZk09w5KlHmAiTdhEUfTnzXkTYBFDTk/wz57omx0QfhSOBNQUgNWRSBtVg2xTcKwDmFYdoLMaghDMyM49iCIQKCqJ0NvfhDcsd2qaBcZwGL44SdT7EoW7z+4VUkRU2M9dQcDE3PknHPOwuNjLHrYawqEexsy2UXSvHshlY+Dy1v4Z2d34nnEzGkXWYTPZyBpxnzw6H73ocZOBRMASlesR1fzOolMDHtcXmTVs0CCSFwewe5Bk+FPsihQExZcTkEmPODJRRF2xXonMvJ+dIWF3cANitcfMWO/H/bkJet7INRQ1kw4X4JYQTpa07x5eZqpCMQ69G38ptTQkQ01RJjqDuFo5juJyrEF4UvhfIDqmevRVrcx3JXDeXYxDJciDIraTztxSgso0AolNYtC8wBrryPX8UySPE8+PD8g4gxGVnseg933JBoO5l/X+wqZHnBrPSTX7TWKW/nh9+GFiPL8Heu7OK0kAqoaVxi+FOQujiqm5DlEPrmS5wxyZGUg9NDdHn4BpKNFcUfdr8SGZqGwAGHWLjxVPBp2UXTlRWyyOKGBSzMDLvLwzM5jvjUHItaQJ6FSZaCutoiGCcfmfQF//8hzR6Ig8x0CVY5bXwiWFFYAqmfm2UB3ahflMR9mcnU+Yz2uXxO4vQmya/mTREWG0c6Rijp//kRRxyz4v0PVjb2dRXeQpGNGVPV7wQl9Ab+zKFkCNXoiqLcnz5GM+iZ77VD25oAi97f3G1V5ZyFYUlABSI6bBQlcdQwmEtACdnh9ociKQKSBg30/AJAT6D27ocadDBSNNgkURFZ5NOzzkywRBor/THQ1EuCZ45gcHheL0KzkaRSyVUsA6eJemXR0Vmc77Wcl1Dg6uuL7EWxv/gwMPZEqRWr0xIKUhgsqADT6qJ+DUn5S2G3FsoWasGePeNWf5xw5e9vaBKqcCqTKrK23q9F52X3trmMcw3bvgBeWvMjAhoLhyaHo41PAayxfkXQhbdPO5VQ59jV/2ESek+deI0SFNDSB9r3AglNHF8b+AwUWADVu9hOJmuPrSSsTr1sNAI7k/r3n77pzcMQJtCuusxMyajKQLA5Vp2OM/d2vrDy7HTp/TlhMWdh28/LOG7wzFl3N0ejCP6/4vEO9SkkvnAA6DcZ2h683fWT3KdpwjyPt6oQBSiAxdXbBdggVfmNI5eHXovIIP0F56VgNo+aDqDBQWDRyGbNMBonSsbWSzdSG27sjKtrF1X1UNzmbHhEO8YxFHoN9rUDsKvfvURj7e+ECEpOOgTB93uQ3tK0CUl4oGNYhjNCTmBPLodmGwAqJKbO2UFfHRwrFjoIDQpKzPro01935IVV++OO6djWop916+EAYhwN+u7YTBmcuVBo4bAKotGKltGxbKcKTo98La/p9GCzO03eMIG8CjHD0Wel9agkh88WreC9YTFBHHIeEDqZJcVUWXR0A57yG8So+kgV1ggRtMIOJI2cgOefcLHd1faL0iq+tKRQ/hg0o9FCod/Eli6Vt96UuHHP59GgqOPQDnFbhvR27qFduk0AOOBLWJRD6ETb6876JMEqv+9mD6eMX9N+wahjTkO8NHAhR5VQ45rNlptubL45ZAGDxAeJyun1MQ1gnCJ2zPOY7c6IRdi9hiQiMQqJq/N2FHn8c9L4WAFVzgg3ELcwqkkjxqV6fcUPohdswL/TWuU/4KJHPk/9dYCFi9prkHL7K8UgcPvXZIZyKQ6b3tQBQ9fT/ZiTCZItzzjiM4R3i1wlKFO4V1gWi9X9YL57R1yE0DFc26cQ+ckhMnT1kczBQel8LQHLywvsTE07pBCf8bmzWph5PkXDSATvDBE4YDubF+767Z+ishYJkXifbYpbFoJGpqDRLnHvfniH8vhYAAFBlYz6oJp9WmygbB0IC5JJKrsOUuIKMMu85++7Amnn5ApuPCOAzfC6G9+bEOpEkBKqeiFRZ9VfLvnzXkDR3iIPe11GAo1ztawt4zYOTde1KJOZ88rfoagV0AOEAyGVhGwzaDKF41e2bN4pzIJ13734333FRBQGQVDGEEqBkySvcuOOO8mt/eMC9A4Yj/X8hAFHK1a0qR2s9oDOAzoFzGSgrAOzsP2zpVVx/4jAf4OsRZssGYM8WJhHT4aNklKn8TZwWpI48rncIhzpCIzRCIzRCIzRCI3TI9L9wXAdXACGNUQAAAABJRU5ErkJggg=="
  //           },
  //           "colorCode": "#fff",
  //           "navUpIcon": "1",
  //           "navPreviousIcon": "1",
  //           "navHomeIcon": "1"
  //         }
  //       } else {
  //         const templateResponse = await BPMNService.getTemplateById(data.template)
  //         console.log(templateResponse);
  //         const templateData = await templateResponse.data;
  //         console.log(templateData);
  //         applyTemplate = templateData
  //         applyTemplate["companyLogo"] = JSON.parse(applyTemplate.companyLogo)
  //         isDefaultTemplateEnable = true
  //       }
  //       console.log("#####", parsedMappingDiagrams);

  //       setUserSavedData(data);
  //       setMappingDiagrams(parsedMappingDiagrams);
  //       setSelectedLanguage(selLang);
  //       setMapDiagramRecord({
  //         diagramXmlId: data.diagramXmlId,
  //         diagramName: data.diagramName,
  //         docStorageType: data.docStorageType,
  //         configId: data.configId,
  //         mapPrivacyType: data.mapPrivacyType,
  //         mapAuthorizedUsers: data.mapAuthorizedUsers,
  //       });
  //       setCurrentMapDet(parsedMappingDiagrams[0]);
  //       setTemplateBgColor(tempBgColor);
  //       setIsDefaultTemplateEnable(isDefaultTemplateEnable);
  //       setAppliedTemplate(applyTemplate)
  //       setEditorOpen(true);
  //       setSelectedMapData(tempSelectedMapData);
  //       setTimeout(() => {
  //         closeSpinnerRedux()
  //       }, 1000);
  //     }
  //   } catch (error) {
  //     console.log("getLastSavedXmlAPICALL", error);
  //     closeSpinnerRedux();
  //     BackToParent("Error");
  //     // setTimeout(() => {
  //     if (error?.response?.status === 406) {
  //       ErrorMessage("Map already opened by another user")
  //     } else {
  //       ErrorMessage(error.message)
  //     }
  //     // }, 1000);
  //   }
  // };


  const toggleSpecificUsersFlag = async () => {
    if (!isSpecificUsersEnable) {
      await getOptionsByName("EDITORS")
    }
    setIsSpecificUsersEnable(prev => !prev)
  }

  // const addEditMapDiagramOnChange = async (e, obj, type) => {
  //   console.log(e,type);
  //   try {
  //     console.log("********** ", e, obj);
  //     let name, value;
  //     let tempMapDiagramRecord = { ...mapDiagramRecord };
  //     if (e?.target === undefined) {
  //       console.log(e, obj, type);
  //       name = "configId" //obj.name;
  //       value = e.value;
  //       tempMapDiagramRecord.configName = e.label
  //     }
  //     else if (type === "mapAuthorizedUsers") {

  //       name = "mapAuthorizedUsers"
  //       value = obj
  //       toggleSpecificUsersFlag()
  //     }
  //     else if (e.target.type === "checkbox" && type!=='project') {

  //       console.log("radiioo ", e.target.name, e.target.value);
  //       value = e.target.name;
  //       name = type
  //       console.log(name, type, value);
  //       switch (value) {
  //         case 'database':
  //           tempMapDiagramRecord.configId = ""
  //           tempMapDiagramRecord.configName = ""
  //           break;
  //         case 'sharepoint':
  //           await getOptionsByName("SHAREPOINT")
  //           break;
  //         // case 'specific':
  //         // await getOptionsByName("EDITORS")
  //         //   break;
  //         case 'public':
  //         case 'private':
  //           tempMapDiagramRecord.mapAuthorizedUsers = [];
  //           break;

  //         default:
  //           console.log("defeult block checkbox");
  //           break;
  //       }
  //     }
  //     else {
  //       e.preventDefault()
  //       name = e.target.name;
  //       value = e.target.value;
  //     }

  //     console.log(name, value, tempMapDiagramRecord);
  //     // tempMapDiagramRecord[name] = value;
  //     setMapDiagramRecord(tempMapDiagramRecord)
  //   } catch (error) {
  //     console.error(error);
  //   }
  // }
  const addEditMapDiagramOnChange = async (e, obj, type) => {
    console.log(e);

    try {
      console.log("********** ", e, obj);
      let name, value;
      let tempMapDiagramRecord = { ...mapDiagramRecord };
      if (e?.target === undefined) {

        if (type === 'project') {
          const constructObj = { projectName: e.value, id: e.id, customerId: e.customerId }
          tempMapDiagramRecord.project = constructObj
          tempMapDiagramRecord.mapAuthorizedUsers = [];

        }
        else {
          console.log(e, obj, type);
          name = "configId" //obj.name;
          value = e.value;
          tempMapDiagramRecord.configName = e.label
        }

      }
      else if (type === "mapAuthorizedUsers") {

        name = "mapAuthorizedUsers"
        value = obj
        toggleSpecificUsersFlag()
      }
      else if (e.target.type === "checkbox") {

        console.log("radiioo ", e.target.name, e.target.value);
        value = e.target.name;
        name = type
        console.log(name, type, value);
        switch (value) {
          case 'database':
            tempMapDiagramRecord.configId = ""
            tempMapDiagramRecord.configName = ""
            break;
          case 'sharepoint':
            await getOptionsByName("SHAREPOINT")
            break;
          // case 'specific':
          // await getOptionsByName("EDITORS")
          //   break;
          case 'public':
            const val = await getOptionsByName("EDITORS")
            setpublicUsers(val)
            break;
          case 'private':
            tempMapDiagramRecord.mapAuthorizedUsers = [];
            break;
          default:
            console.log("defeult block checkbox");
            break;
        }

      }
      else {
        name = e.target.name;
        value = e.target.value;
      }

      console.log(name, value, tempMapDiagramRecord);
      tempMapDiagramRecord[name] = value
      setMapDiagramRecord(tempMapDiagramRecord)
    } catch (error) {
      console.error(error);
    }
  }

  const onMapDiagramAddOnClick = async (e, test) => {


    e.preventDefault()
    try {
      console.log(mapDiagramRecord);

      const tempMapRecord = { ...mapDiagramRecord };

      console.log(tempMapRecord);


      const isValidRecord = validateAddEditMapRecord(tempMapRecord);
      console.log("isValidRecord ", isValidRecord)
      if (!isValidRecord) {
        console.log("not a valid record");
        return;
      }
      console.log("rowData:", rowData, tempMapRecord);

      const isMapNameExist = rowData.find(row => row.diagramName?.toLowerCase()?.trim() === tempMapRecord.diagramName?.toLowerCase()?.trim() && row.project.projectName === tempMapRecord.project.projectName
      )
      console.log(isMapNameExist);
      if (isMapNameExist) {
        return ErrorMessage("Map name already exists");
      }
      openSpinnerRedux();
      const response = await BPMNService.createMapDiagramAPICALL(tempMapRecord);
      console.log(response);
      const data = await response.data;
      if (response.status === 200 || response.status === 201) {
        // data["status"] = "Draft"
        data["author"] = localStorage.getItem("userName")
        setSelectedMapData(data);
        const mapOptions = getMapLevelOptionsByMapData(data);
        console.log('###', mapOptions);
        setMapLevelOptions(mapOptions)
        // await childRef.current.resetToInitialState();
        await childRef.current.getLastSavedXmlByUser(data.diagramXmlIds.Draft.diagramXmlId, data)
        closeSpinnerRedux();
        closeAddEditPOPUP();
        setEditorOpen(true);
        SuccessMessage(BPMN_Editor_Toaster.Map_Created_Successfully);
      }
    } catch (error) {
      closeSpinnerRedux();
      console.error(error);
      ErrorMessage(error?.response?.data)
    }
  }
  const onMapDiagramEditOnClick = async () => {
    console.log("edit UPDATE");
    const tempMapRecord = mapDiagramRecord;
    console.log(tempMapRecord);
    const isValidRecord = validateAddEditMapRecord(tempMapRecord);
    if (!isValidRecord) {
      console.log("not a valid record");
      return
    }

    const compareJsonObjects = (obj1, obj2) => {
      console.log(obj1, obj2);

      const newObj1 = {
        configId: obj1["configId"] ? obj1["configId"] : undefined,
        configName: obj1["configName"] ? obj1["configName"] : undefined,
        diagramName: obj1["diagramName"],
        docStorageType: obj1["docStorageType"],
        mapAuthorizedUsers: obj1["mapAuthorizedUsers"],
        mapPrivacyType: obj1["mapPrivacyType"],
        project: obj1['project']
      }
      const newObj2 = {
        configId: obj2["configId"] ? obj2["configId"] : undefined,
        configName: obj2["configName"] ? obj2["configName"] : undefined,
        diagramName: obj2["diagramName"],
        docStorageType: obj2["docStorageType"],
        mapAuthorizedUsers: obj2["mapAuthorizedUsers"],
        mapPrivacyType: obj2["mapPrivacyType"],
        project: obj2['project']
      }
      console.log(newObj1, newObj2);

      console.log(
        (newObj1["configId"] === newObj2["configId"]),
        (newObj1["configName"] === newObj2["configName"]),
        (newObj1["diagramName"] === newObj2["diagramName"]),
        (newObj1["docStorageType"] === newObj2["docStorageType"]),
        (newObj1["mapPrivacyType"] === newObj2["mapPrivacyType"]),
        (newObj1["project"] === newObj2["project"]),

      )

      if ((newObj1["configId"] === newObj2["configId"]) && (newObj1["configName"] === newObj2["configName"]) && (newObj1["diagramName"] === newObj2["diagramName"]) && (newObj1["docStorageType"] === newObj2["docStorageType"]) && (newObj1["mapPrivacyType"] === newObj2["mapPrivacyType"]) && (newObj1["project"] === newObj2["project"])) {
        if (newObj1["mapPrivacyType"] === "specific" || newObj2["mapPrivacyType"] === "specific") {
          if (newObj1["mapPrivacyType"] === "specific" && newObj1.mapAuthorizedUsers.length === newObj2.mapAuthorizedUsers.length &&
            ([...new Set(newObj1["mapAuthorizedUsers"])].every(el => [...new Set(newObj2["mapAuthorizedUsers"])].includes((el))))
          ) {
            return true
          } else {
            return false
          }
        }
        return true;
      } else {
        console.log("2nd else");
        return false
      }
    };
    console.log(tempMapRecord, selectedMapData);

    const obj1 = tempMapRecord;
    const obj2 = Object.keys(editMapDiagramRecord).length === 0 ? selectedMapData : editMapDiagramRecord;
    const isNoChanges = compareJsonObjects(obj1, obj2)
    console.log("isNoChanges ", isNoChanges);
    if (isNoChanges) {
      ErrorMessage(BPMN_Editor_Toaster.No_Changes_Detected)
      return
    }
    try {
      openSpinnerRedux()
      console.log(tempMapRecord, "Temp Map Record");
      const response = await BPMNService.updateMapDiagramAPICALL(tempMapRecord, tempMapRecord.id);
      console.log(response);
      const editResponse = await response.data;
      if (response.status === 200 || response.status === 201) {
        closeAddEditPOPUP();
        closeSpinnerRedux();
        let tempMappDiags = [...childRef.current.state.mappingDiagrams];
        tempMappDiags[0].name = editResponse.diagramName
        tempMappDiags[0].meta.label = tempMappDiags[0].id + "-" + editResponse.diagramName
        childRef.current.setMappingDiagramsArray("mappingDiagrams", tempMappDiags)
        childRef.current.setMappingDiagramsArray("mapDiagramRecord", editResponse)
        setEditMapDiagramRecord(editResponse);
        SuccessMessage(BPMN_Editor_Toaster.Map_Updated_Successfully);
      }
    } catch (error) {
      console.error(error);
      closeSpinnerRedux()
      ErrorMessage(error?.response?.data);
    }

  }
  const validateAddEditMapRecord = (mapDiagramRecord) => {
    console.log(mapDiagramRecord);
    try {

      if (mapDiagramRecord.diagramName === undefined || mapDiagramRecord.diagramName === "") {
        ErrorMessage(BPMN_Editor_Toaster.Please_Enter_The_Map_Name)
        return false
      } else if (mapDiagramRecord.docStorageType === "sharepoint" && (mapDiagramRecord.configId === undefined || mapDiagramRecord.configId === "")) {
        console.log('sharepoint -- ', mapDiagramRecord.configId, mapDiagramRecord.configId)
        ErrorMessage(BPMN_Editor_Toaster.Please_Select_Sharepoint_Configuration)
        return false
      } else if (mapDiagramRecord.mapPrivacyType === 'specific' && (mapDiagramRecord.mapAuthorizedUsers.length === undefined || mapDiagramRecord.mapAuthorizedUsers.length === 0)) {
        console.log("specific");
        ErrorMessage(BPMN_Editor_Toaster.Please_Select_Specific_Users)
        return false
      }
      else if (Object.keys(mapDiagramRecord?.project).length === 0) {
        ErrorMessage(BPMN_Editor_Toaster.Please_Enter_Project)
        return false
      } else
        return true
    } catch (error) {
      console.error(error);
    }
  }
  const onMapDiagramDeleteOnClick = async () => {
    try {
      console.log("edit");
      let reqPayload = []
      if (isCheckboxClicked) {
        const deleteDatas = selectedRows.map((row) => {
          return {
            diagramName: row.data.diagramName,
            id: row.data.id
          }
        })
        reqPayload = deleteDatas
      } else {
        console.log('selectedMapData', selectedMapData);
        reqPayload.push({
          diagramName: selectedMapData.diagramName,
          id: selectedMapData.id
        }
        )
      }
      console.log(reqPayload);
      openSpinnerRedux();
      try {

      } catch (error) {

      }
      const response = await BPMNService.deleteMapDiagramAPICALL(reqPayload);
      console.log(response);
      if (response.status === 200 || response.status === 201) {
        await getDiagramsData();
        closeSpinnerRedux();
        SuccessMessage(BPMN_Editor_Toaster.Map_Deleted_Successfully)
        closeDialogPopupBox();
      }
    } catch (error) {
      closeSpinnerRedux();
      console.error(error);
      ErrorMessage(error?.response?.data);
    }
  }
  const uploadBpmnFileOnChange = async (e) => {
    e.preventDefault();
    if (e.type === "drop") {
      const isDrop = e.type + "".toLowerCase() === "drop";
      // const files = isDrop ? e.dataTransfer.files : e.target.files;
      const file = isDrop ? e.dataTransfer.files[0] : e.target.files[0];
      // const fileName = isDrop ? e.dataTransfer.files[0].name : e.target.files[0].name;
      console.log(file);
      const allowedExtensions = /\.(txt)$/i;
      if (!allowedExtensions.test(file?.name)) {
        ErrorMessage(BPMN_Editor_Toaster.File_Type_Mismatch);
        return;
      }
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;
        const parseJson = (text) => {
          try {
            return { isValid: true, data: JSON.parse(text) };
          } catch (e) {
            console.error(e);
            return { isValid: false, data: null };
          }
        };
        const resultT = parseJson(text);
        if (resultT.isValid) {
          console.log('Parsed JSON:', resultT.data);
        } else {
          ErrorMessage(BPMN_Editor_Toaster.Invalid_Type_Mismatch)
          return
        }
        console.log(text);
        console.log("parsed", JSON.parse(text));
        const woExtFileName = file?.name.substring(0, file?.name.lastIndexOf('.'));
        const onlyMapName = woExtFileName.split("-");
        const result = onlyMapName.slice(1, -1).join("-");
        console.log(result);
        console.log("onlyMapName", result);
        let tempMapDiagramRecord = mapDiagramRecord;
        tempMapDiagramRecord["diagramName"] = woExtFileName;
        setMapDiagramRecord(tempMapDiagramRecord)
        setSelectedFileData(JSON.parse(text))
      };
      reader.readAsText(file);
    }
    else {
      const file = e.target.files[0];
      const isValid = await validateFileOnChange(e);
      if (!isValid) {
        return;
      }
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;
        // console.log(text);
        const parseJson = (text) => {
          try {
            return { isValid: true, data: JSON.parse(text) };
          } catch (e) {
            console.error(e);
            return { isValid: false, data: null };
          }
        };
        const resultT = parseJson(text);
        if (resultT.isValid) {
          console.log('Parsed JSON:', resultT.data);
        } else {
          ErrorMessage(BPMN_Editor_Toaster.Invalid_Type_Mismatch)
          return
        }
        console.log("parsed", JSON.parse(text));
        const woExtFileName = file?.name.substring(0, file?.name.lastIndexOf('.'));
        const onlyMapName = woExtFileName.split("-");
        console.log(onlyMapName, onlyMapName?.length % 3 === 0);
        const result = onlyMapName?.length % 3 === 0 ? onlyMapName?.slice(1, -1).join("-") : onlyMapName.join("-");
        console.log(result);
        console.log("onlyMapName", result);
        let tempMapDiagramRecord = mapDiagramRecord;
        tempMapDiagramRecord["diagramName"] = result;
        setMapDiagramRecord(tempMapDiagramRecord)
        setSelectedFileData(JSON.parse(text))
      };
      reader.readAsText(file);
    }
  };

  const uploadBpmnFile_OnClick = async () => {
    try {

      const tempMapRecord = mapDiagramRecord;
      console.log(tempMapRecord);
      const isValidRecord = validateAddEditMapRecord(tempMapRecord);
      console.log(isValidRecord);
      if (!isValidRecord) {
        console.log("not a valid record");
        return
      }
      let tempSelFile = Array.isArray(selectedFileData) ? selectedFileData : [selectedFileData]
      console.log(tempSelFile);
      const UploadBaseId = tempSelFile[0].id
      console.log("UploadBaseId:", UploadBaseId)
      if (UploadBaseId !== undefined && tempSelFile.length > 0) {
        function UpdateUploadedXmlIds(arr) {
          console.log(arr)
          const normalizeObject = (obj) => {
            let LoopId = obj.id
            const parentId = LoopId.split(".").slice(0, LoopId.split(".").length - 1).join(".")
            const resId = "1" + LoopId.substring(UploadBaseId.length)
            console.log(obj, resId, LoopId);
            obj.id = resId
            obj.key = resId + (obj.name?.startsWith("-") ? obj.name : '-' + obj.name)
            obj.meta.label = resId + (obj.name?.startsWith("-") ? obj.name : '-' + obj.name)
            obj.parentId = parentId

            if (obj.children && obj.children.length > 0) {
              obj.children = obj.children.map(normalizeObject);
            }
            return obj;
          };

          const normalizedArr1 = arr.map(normalizeObject);
          return normalizedArr1;
        }
        const UpdateUploadedXml = await UpdateUploadedXmlIds(tempSelFile)
        console.log(UpdateUploadedXml)
        openSpinnerRedux();
        const response = await BPMNService.createMapDiagramAPICALL(tempMapRecord);
        console.log(response);
        if (response.status === 200 || response.status === 201) {

          // response.data["status"] = "Draft"
          response.data["author"] = localStorage.getItem("userName")
          const reqPayload = {
            xmlData: JSON.stringify(UpdateUploadedXml),
            languageName: tempSelFile[0]?.selectedLanguage?.label ? tempSelFile[0]?.selectedLanguage?.label : "English",
            languageCode: tempSelFile[0]?.selectedLanguage?.value ? tempSelFile[0]?.selectedLanguage?.value : "en"
          };
          console.log(tempSelFile[0]?.selectedLanguage)
          console.log(reqPayload)
          const saveResponse = await BPMNService.saveLatestXmlAPICALL(reqPayload, response.data.diagramXmlIds.Draft.diagramXmlId);
          console.log(saveResponse);
          const tempSelectedMapData = await response.data;
          setSelectedMapData(tempSelectedMapData);
          const mapOptions = getMapLevelOptionsByMapData(tempSelectedMapData);
          console.log('###', mapOptions);
          setMapLevelOptions(mapOptions)
          // await childRef.current.resetToInitialState();
          await childRef.current.getLastSavedXmlByUser(response.data.diagramXmlIds.Draft.diagramXmlId, tempSelectedMapData)
          closeSpinnerRedux();
          closeAddEditPOPUP();
          setEditorOpen(true);
          setSelectedFileData('')
        }
      }
      else {
        ErrorMessage(BPMN_Editor_Toaster.Valid_Bpm_file)
      }

      // closeSpinnerRedux();
    } catch (error) {
      closeSpinnerRedux();
      console.error("Error ", error);
      ErrorMessage(error?.response?.data)
    }
  };
  const closeDialogPopupBox = () => {
    console.log("triggerd");
    setIsAddEDitMapDiagramEnable(false);
    setIsDeleteMapEnable(false)
    setIsImportMapEnable(false);
    setEditorOpen(false)
    setsetIsCheckboxClicked(false);
  }
  const BackToParent = async (type, messageType, message) => {
    if (type === "checkOut") {
      console.log('selectedMapData', selectedMapData);
      clearIntervalRef()
    }
    // setMappingDiagrams([
    //   {
    //     id: "1",
    //     name: "",
    //     key: "1",
    //     meta: {
    //       collapsed: true,
    //       label: "1"
    //     },
    //     diagramXML: defaultDiagramXml,
    //     parentId: null,
    //     children: [],
    //     flowlineMap: []
    //   },
    // ])
    // setCurrentMapDet({
    //   id: "1",
    //   name: "",
    //   key: "1",
    //   meta: {
    //     collapsed: true,
    //     label: "1"
    //   },
    //   diagramXML: defaultDiagramXml,
    //   parentId: null,
    //   children: [],
    //   flowlineMap: []
    // })
    closeDialogPopupBox()
    setEditMapDiagramRecord({})
    setMapLevelOptions([])
    try {
      openSpinnerRedux()
      await getDiagramsData();
    } catch (error) {
      console.error(error);
      closeSpinnerRedux();
    }
    if (messageType === 'success') {
      SuccessMessage(message)
    }
    childRef.current.resetToInitialState();
    childRef.current.closeDialogPopupBox();
  }


  const onFilterTextBoxChanged = debounce(() => {
    const searchText = document.getElementById('filter-text-box')?.value;
    // console.log("searchText", searchText);
    const filteredArray = cloneDeep([...initialRowData])?.filter((item) =>
      item.project?.projectName.toLowerCase().includes(searchText.toLowerCase()) ||
      item.docStorageType.toLowerCase().includes(searchText.toLowerCase()) ||
      item.mapPrivacyType.toLowerCase().includes(searchText.toLowerCase()) ||
      item.diagramName.toLowerCase().includes(searchText.toLowerCase()) ||
      item.author.toLowerCase().includes(searchText.toLowerCase()) ||
      item.assignedUsers.find(user => user.assignedUser?.toLowerCase()?.includes(searchText.toLowerCase())) ||
      item.diagramXmlIds.Draft.status.toLowerCase().includes(searchText.toLowerCase())
    );
    // console.log(filteredArray);
    setRowData(filteredArray);
  }, 200);

  const openSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: true });
  };
  const closeSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: false });
  };
  const setCopiedContentToRedux = (copiedContent) => {
    dispatch({ type: "SET_COPIED_CONTENT", payload: copiedContent });
  };
  const setEditorOpenFunc = () => {
    setEditorOpen(true);
  };
  const onSlectMapTypeOnChange = async (e, obj) => {
    try {
      console.log(e, obj);
      if (e.value === selectedMapType.value) {
        console.log("same value selected");
        return
      }
      const isBothXMLSame = await childRef.current.getIsUnSavedXMLExist();
      console.log("isBothXmlSame", isBothXMLSame);
      if ((!isBothXMLSame) && !(window.confirm("Changes you made may not be saved."))) {
        console.log("iff");
        return
      }
      console.log("selectedMapType ", selectedMapType)
      if (e.mapLevel === "Draft") {
        await BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(e.value, "checkOut")
      }
      await childRef.current.setMappingDiagramsArray("isDiagNavigationClicked", false)
      await childRef.current.setMappingDiagramsArray("isDiagNavigationClicked", false)
      // await childRef.current.resetToInitialState();
      await childRef.current.getLastSavedXmlByUser(e.value, childRef.current.state.mapDiagramRecord, "YES");
      setSelectedMapType(e);
    } catch (error) {
      console.error(error)
    }
  }
  const setMapLevelOptionsByChild = () => {
    let tempMapLevelOptions = [];
    mapLevelOptions.forEach((item => {
      if (item.mapLevel === "Draft") {
        const masterOption = mapLevelOptions.find(data => data.mapLevel === "Master")
        console.log("masterOption ", masterOption, masterOption.label.split(" ")[1]);
        item.label = "Draft v." + (parseInt(masterOption.label.split(" ")[1].split(".")[1]) + 1);
      }
      tempMapLevelOptions.push(item);
    }))
    console.log("tempMapLevelOptions", tempMapLevelOptions);
    setMapLevelOptions(tempMapLevelOptions)
  }
  return (
    <>

      {/* : */}
      {!isEditorOpen ?
        <AuthCommonLayout>
          <div className='flex justify-between bg-white mb-1 px-5 pt-2 pb-1 border-b-[1px] rounded-t-md'>
            <div className='flex items-center space-x-5'>
              <div class="relative flex items-center border border-gray-300 rounded-md h-8 overflow-hidden">
                <div class="place-items-center grid w-12 h-full text-search-text">
                  <HiOutlineSearch color='#0000004D' size={24} />
                </div>
                <input
                  id="filter-text-box"
                  onInput={onFilterTextBoxChanged}
                  class="peer bg-search-bg pr-2 outline-none w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs placeholder-[#0000004D]"
                  type="text"
                  autoComplete='off'
                  placeholder="Search..." />
              </div>
            </div>
            <div className='flex justify-end space-x-2 bg-white mb-1 px-5 pt-4 pb-2 rounded-t-md'>
              {/* {
              isCheckboxClicked ?
                <button onClick={() => openAddEditDeleteImportMap("CHECKBOX_DELETE")} className="flex items-center space-x-3 focus:bg-red-700 active:bg-red-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 border border-black border-opacity-10 rounded focus:outline-none focus:ring-0 font-medium text-red-500 text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm">
                  <span >
                    <IoTrashOutline size={16} />
                  </span>
                  <span>
                    {BPMNEditor_Labels._MULTI_DELETE_BTN}
                  </span>
                </button>
                : null
            } */}
              {["Admin"].includes(loginUserRole) ?
                <button onClick={() => openAddEditDeleteImportMap("IMPORT")} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:outline-none focus:ring-0 font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm">
                  <span >
                    <FaFileImport size={16} color="white" />
                  </span>
                  <span>
                    {BPMNEditor_Labels._IMPORT_BTN}
                  </span>
                </button>
                : null}
              {["Editor"].includes(loginUserRole) ?
                <button onClick={() => openAddEditDeleteImportMap("ADD")} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:outline-none focus:ring-0 font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm">
                  <span>
                    <BsFillDiagram3Fill size={16} color="white" />
                  </span>
                  <span>
                    {BPMNEditor_Labels._CREATE_BTN}
                  </span>
                </button>
                : null}
            </div>
          </div>

          <div>
            <div id='CustomAgGrid'>
              <CustomAgGrid
                ref={gridRef}
                rowData={rowData}
                columnDefs={columnDefs}
                onGridReady={onGridReady}
                filterValue={filterValue}
                OnCheckBoxSelection={OnCheckBoxSelection}
                isRowSelectable={isRowSelectable}
              />
            </div>
          </div>

        </AuthCommonLayout>
        : null}
      <ChildCompEditorRef
        isEditorOpen={isEditorOpen}
        ref={childRef}
        selectedMapData={selectedMapData}
        mapDiagramRecord={mapDiagramRecord}
        selectedMapType={selectedMapType}
        mapLevelOptions={mapLevelOptions}
        onSlectMapTypeOnChange={onSlectMapTypeOnChange}
        setMapLevelOptionsByChild={setMapLevelOptionsByChild}
        // editMapDiagramRecord={editMapDiagramRecord}
        // resSavedData={resSavedData}
        // diagramXmlId={diagramXmlId}
        // userSavedData={userSavedData}
        // mappingDiagrams={mappingDiagrams}
        // selectedLanguage={selectedLanguage}
        // currentMapDet={currentMapDet}
        // templateBgColor={templateBgColor}
        // isDefaultTemplateEnable={isDefaultTemplateEnable}
        // appliedTemplate={appliedTemplate}
        // closeAddEditPOPUP={closeAddEditPOPUP}
        BackToParent={BackToParent}
        openAddEditDeleteImportMap={openAddEditDeleteImportMap}
        openSpinnerRedux={openSpinnerRedux}
        closeSpinnerRedux={closeSpinnerRedux}
        setEditorOpenFunc={setEditorOpenFunc}
        setCopiedContentToRedux={setCopiedContentToRedux}
        publicUsers={publicUsers}
      />

      {isAddEDitMapDiagramEnable ?
        (
          <AddEditMapDiagramPOPUP
            projectsData={projectsData}
            projectsDataContainer={projectsDataContainer}
            isEditMap={isEditMap}
            mapDiagramRecord={mapDiagramRecord}
            sharepointConfigOptions={sharepointConfigOptions}
            allUsers={editorUserOptions}
            isSpecificUsersEnable={isSpecificUsersEnable}
            addEditMapDiagramOnChange={addEditMapDiagramOnChange}
            onMapDiagramAddOnClick={onMapDiagramAddOnClick}
            onMapDiagramEditOnClick={onMapDiagramEditOnClick}
            toggleSpecificUsersFlag={toggleSpecificUsersFlag}
            closeAddEditPOPUP={closeAddEditPOPUP}
          />)
        : null}

      {isImportMapEnable ? (
        <UploadBpmnPopup
          projectsDataContainer={projectsDataContainer}
          isFromMapImport={true}
          mapDiagramRecord={mapDiagramRecord}
          sharepointConfigOptions={sharepointConfigOptions}
          allUsers={editorUserOptions}
          isSpecificUsersEnable={isSpecificUsersEnable}
          toggleSpecificUsersFlag={toggleSpecificUsersFlag}
          addEditMapDiagramOnChange={addEditMapDiagramOnChange}
          closeAddEditPOPUP={closeAddEditPOPUP}
          uploadBpmnFileOnChange={uploadBpmnFileOnChange}
          uploadBpmnFile_OnClick={uploadBpmnFile_OnClick}
        />)
        : null}

      {isDeleteMapEnable ? (
        <DeleteConfirmPOPUP
          titleName={BPMNEditor_Labels._DELETE_MAP}
          deleteDataName={selectedMapData?.diagramName}
          oKBtnOnClick={onMapDiagramDeleteOnClick}
          cancelBtnOnClick={closeDialogPopupBox}
        />
      )
        : null}

    </>
  )
}

export default BpmndiagramGrid




export const AssignUsers = (props) => {
  let dialogStyles = {
    // width: '500px',
    // maxWidth: '100%',
    margin: '0 auto',
    position: 'fixed',
    left: '50%',
    top: '45%',
    transform: 'translate(-50%,-50%)',
    zIndex: '80',
    backgroundColor: '#fff',
    padding: '10px 0px 15px',
    borderRadius: '8px',
    display: 'flex',
    flexDirection: 'column',
  };

  const [selectedUsers, setSelectedUsers] = useState(props.selectedUsers)
  const [rowData, setRowData] = useState(props.allUsers);
  const [isCheckBox, setIsCheckBox] = useState(false);

  // Sort assigned users at top
  useEffect(() => {
    let assigned = [], unAssigned = [];
    props?.allUsers?.forEach(currUser => {
      if (selectedUsers?.some(user => user.userId === currUser.userId)) {
        assigned.push(currUser)
      }
      else
        unAssigned.push(currUser)
    });
    setRowData([...assigned, ...unAssigned])
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // function for checkBox indetermine hyphen and multicheckbox
  useEffect(() => {
    const checkbox = document.getElementById("MultiCheck");
    checkbox.indeterminate = selectedUsers?.length > 0 ? selectedUsers.length === props.allUsers?.length ? false : true : false
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedUsers])

  const onRemoveOn_Click = (e, currUser) => {
    e?.preventDefault();
    setSelectedUsers((prev) => {
      return [
        ...prev.filter(user => user.userId !== currUser.userId)
      ]
    })
  };

  const onAddOn_Click = (e, currUser) => {
    e?.preventDefault();
    setSelectedUsers([...selectedUsers, currUser]);
  };

  const onSingleCheckSelction = (e, user) => {
    // e.preventDefault();
    if (e.target.checked)
      onAddOn_Click(undefined, user)
    else
      onRemoveOn_Click(undefined, user)

  };

  const onMultiCheckSelction = (e) => {
    // e.preventDefault();
    if (e.target.checked)
      setSelectedUsers(props.allUsers);
    else
      setSelectedUsers([])
  };

  const handleSearch = (event) => {
    const value = event.target.value;
    const filteredDatas = props.allUsers?.filter(
      item => item.userName.toLowerCase().includes(value.toLowerCase())
    );
    setRowData(filteredDatas)
  };

  const getInitialLetters = (name) => {
    return name.split(' ').slice(0, 2).map((name) => name[0]).join('')
  }
  console.log(props);
  return (
    // <div className="top-0 left-0 z-50 absolute h-[100vh] font-roboto">
    <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
      <div id='loginAnimate' className='shadow-2xl drop-shadow-2xl w-[30vw]' style={dialogStyles}>
        <div className='header'>
          <div>
            <div className="pt-5 font-semibold text-black text-xl text-center">Assign User to Maps</div>
            {/* <div className="pt-2.5 font-normal text-[16px] text-black text-center text-opacity-50">User existing team members or add new ones.</div> */}
            <div className='flex justify-center items-center w-full'>
              <div class="relative flex items-center bg-white mt-3 border border-black border-opacity-30 rounded-md w-[85%] h-10 overflow-hidden">
                <div class="place-items-center grid w-12 h-full text-search-text">
                  <HiOutlineSearch color='#0000004D' size={24} />
                </div>
                <input
                  id="filter-text-box"
                  // onInput={props.onFilterTextBoxChanged}
                  class="peer bg-white pr-2 outline-none w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-md placeholder-[#0000004D]"
                  type="search"
                  // value={searchTerm}
                  onChange={handleSearch}
                  placeholder="Search..."
                />
              </div>
            </div>

            <div className='flex items-center shadow-sm px-12 py-2 font-normal text-[15px] text-black text-opacity-30'>
              <input
                onMouseEnter={() => setIsCheckBox(true)}
                onMouseLeave={() => setIsCheckBox(false)}
                checked={selectedUsers?.length === props.allUsers?.length}
                type="checkbox" id="MultiCheck"
                onChange={(e) => onMultiCheckSelction(e)}
                class="w-5 h-5 accent-green-500"
              />
              <span className='ml-7'>Multi Selection Add or Remove</span>
            </div>

          </div>
          <div className="z-0 mt-2 px-2 h-[30vh] overflow-x-clip overflow-y-scroll">{/* group*/}
            {rowData?.map((item, id) =>
              <div key={id} className='flex justify-between hover:bg-violet-100 hover:bg-opacity-80 px-6 py-2 font-roboto'>
                <div className="flex items-center">
                  <div onMouseEnter={() => setIsCheckBox(true)} onMouseLeave={() => setIsCheckBox(false)}
                    class="group relative flex justify-center items-center bg-blue-800 bg-opacity-20 rounded-full w-12 h-12 text-blue-800 text-xl uppercase">
                    <span className={isCheckBox ? ' hidden ' : 'block '}>{getInitialLetters(item.userName)}</span>
                    <input
                      checked={selectedUsers?.some(user => user.userId === item.userId)}
                      onChange={(e) => onSingleCheckSelction(e, item)}
                      type="checkbox"
                      class={`${isCheckBox ? 'block ' : ' hidden '} accent-green-500 h-4 w-4 `}
                    /> {/*hidden group-hover:block*/}
                  </div>
                  <div className='ml-4'>
                    <div className="font-[600] text-[14px] text-black text-opacity-75">{item.userName}</div>
                    <div className="text-[#615c5c] text-[13px]">{item.userEmail}</div>
                  </div>
                </div>
                {selectedUsers?.some(user => user.userId === item.userId) ?
                  <button onClick={(e) => onRemoveOn_Click(e, item)} class='hover:bg-rose-500 shadow-sm my-2 border border-rose-500 hover:border-rose-500 rounded-md w-[70px] font-normal text-rose-500 hover:text-white text-base text-center'>Remove</button>
                  :
                  <button onClick={(e) => onAddOn_Click(e, item)} class='hover:bg-emerald-400 shadow-sm my-2 border hover:border-emerald-400 border-black border-opacity-30 rounded-md w-[70px] text-black hover:text-white text-opacity-50'>Add</button>
                }
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-center space-x-4 pt-2">
          <button class='hover:bg-[#e6e3e35d] shadow px-10 py-1.5 border border-gray-300 rounded-md font-medium text-zinc-500 text-base'
            onClick={props.toggleSpecificUsersFlag}>
            Cancel
          </button>
          <button
            class='bg-blue-800 hover:bg-blue-700 shadow px-6 border border-blue-800 rounded-md font-medium text-white text-base hover:bo'
            onClick={(e) => props.assignEditUsersOnClick(e, selectedUsers, "mapAuthorizedUsers")}>
            {!props.isEditMap ? selectedUsers?.length === 0 ? 'Add User' : `Added ${selectedUsers?.length} user` : 'Update'}
          </button>
        </div>
      </div>
    </div>
  )
}