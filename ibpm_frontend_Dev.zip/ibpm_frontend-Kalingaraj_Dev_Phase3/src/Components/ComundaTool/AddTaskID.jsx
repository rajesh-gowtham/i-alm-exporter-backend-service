import React, { useState } from 'react';
import Select from 'react-select';
import { ErrorMessage } from '../../CommonUtils/CustomToast';
import { ControlsConstants } from "../../Constants/ControlsConstants";

const localControlsConstant = ControlsConstants;
const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
const options = [
    { value: 'Navigation', label: 'Navigation' },
    { value: 'Data Source', label: 'Data Source' },
    { value: 'Document', label: 'Document' }
];

function AddTaskID(props) {
    // alert(JSON.stringify(props.AvailabeDataSource))
    const formArray = [1, 2];
    const [formNo, setFormNo] = useState(formArray[0])

    const next = () => {
        if (formNo === 1 && props.element_data_id && props.task_datasource) {
            setFormNo(formNo + 1)
        }
        else if (formNo === 2) {
            setFormNo(formNo + 1)
        }
        else {
            ErrorMessage('Please fillup all input field');
            // setOperationMessages('Please fillup all input field')
        }
    }

    const pre = () => {
        setFormNo(formNo - 1)
    }
    return (
        <div id='addtaskchild'>
            <div className="card w-full rounded-md  px-5 ">
                <div className='flex justify-center items-center py-2'>
                    {
                        formArray.map((v, i) =>
                            <div key={i} >
                                <div className={`w-[35px] my-1 text-white rounded-full ${formNo - 1 === i || formNo - 1 === i + 1 || formNo === formArray.length ? 'bg-blue-500' : 'bg-slate-400'} h-[35px] flex justify-center items-center`}>
                                    {v}
                                </div>
                                {
                                    i !== formArray.length - 1 && <div className={`w-[165px] h-[2px] ${formNo === i + 2 || formNo === formArray.length ? 'bg-blue-500' : 'bg-slate-400'}`}></div>
                                }
                            </div>)
                    }
                </div>
                {
                    formNo === 1 && <div>
                        <div class="md:flex md:items-center mb-3">
                            <div class="md:w-1/3">
                                <label class={ControlsConstants.label.labelDefault} for="inline-full-name">
                                    Task ID
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <input
                                    class={ControlsConstants.TextBox.textBoxDisabled}
                                    id="inline-full-name"
                                    type="text"
                                    value={props.element_data_id}
                                    disabled={true} />
                            </div>
                        </div>
                        <div class="md:flex md:items-center mb-3">
                            <div class="md:w-1/3">
                                <label class={ControlsConstants.label.labelDefault} for="inline-password">
                                    Data Source Type
                                </label>
                            </div>
                            <div class="md:w-2/3">
                                <Select
                                    styles={dropDownStylesGrey}
                                    class="mb-2 block border border-grey-light w-full h-10 p-3"
                                    type="text"
                                    name='task_datasource'
                                    id='task_datasource'
                                    placeholder={<div className="Choose Defect Tool">data source type</div>}
                                    // defaultValue={{ label: props.task_datasource, value: 1 }}
                                    options={options}
                                    onChange={props.compHandleSelectOnChange}
                                />
                            </div>
                        </div>
                        {/* almtestcase */}
                        {props.task_datasource === "Data Source" ?
                            <div>
                                <div class="md:flex md:items-center mb-3">
                                    <div class="md:w-1/3">
                                        <label class={ControlsConstants.label.labelDefault} for="inline-password">
                                            Availabe Data Source
                                        </label>
                                    </div>
                                    <div class="md:w-2/3">
                                        <Select
                                            styles={dropDownStylesGrey}
                                            class="mb-2 block border border-grey-light w-full h-10 p-3"
                                            type="text"
                                            name='selected_datasource'
                                            id='selected_datasource'
                                            placeholder={<div className="Choose Defect Tool">data source type</div>}
                                            // defaultValue={{ label: props.selected_datasource, value: 1 }}
                                            options={props.AvailabeDataSource}
                                            onChange={props.compHandleSelectOnChange}
                                        />
                                    </div>
                                </div>
                                <div class="md:flex md:items-center mb-3">
                                    <div class="md:w-1/3">
                                        <label class={ControlsConstants.label.labelDefault} for="inline-full-name">
                                            TestCase ID
                                        </label>
                                    </div>
                                    <div class="md:w-2/3">
                                        <input
                                            class={ControlsConstants.TextBox.textBoxDefault}
                                            id="inline-full-name"
                                            type="text"
                                            name='almtestcase'
                                            value={props.almtestcase}
                                            onChange={props.compHandleTextOnChange}
                                        />
                                    </div>
                                </div>
                            </div> : null}

                        {props.task_datasource === "Document" ? <div>
                            <div class="md:flex md:items-center mb-3">
                                <div class="md:w-1/3">
                                    <label class={ControlsConstants.label.labelDefault} for="inline-full-name">
                                        Document Path
                                    </label>
                                </div>
                                <div class="md:w-2/3">
                                    <input
                                        class={ControlsConstants.TextBox.textBoxDefault}
                                        id="inline-full-name"
                                        type="text"
                                        name='documentpath'
                                        value={props.document}
                                        onChange={props.compHandleTextOnChange}
                                    />
                                </div>
                            </div>
                        </div> : null}

                        {props.task_datasource === "Navigation" ? <div>
                            <div class="md:flex md:items-center mb-3">
                                <div class="md:w-1/3">
                                    <label class={ControlsConstants.label.labelDefault} for="inline-password">
                                        Availabe Diagrams
                                    </label>
                                </div>
                                <div class="md:w-2/3">
                                    <Select
                                        styles={dropDownStylesGrey}
                                        class="mb-2 block border border-grey-light w-full h-10 p-3"
                                        type="text"
                                        name='navigationpath'
                                        id='navigationpath'
                                        placeholder={<div className="Choose diagram">select diagram</div>}

                                    />
                                </div>
                            </div>
                        </div> : null}
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={props.SavetaskidChangesChanges} >Save Changes</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={next} >Continue
                            </button>
                        </div>
                    </div>
                }
                {
                    formNo === 2 && <div>
                        <div class="md:flex md:items-center mb-3">
                            <div class="md:w-1/3">
                                <label class={ControlsConstants.label.labelDefault} for="inline-full-name">
                                    Diagram Name
                                </label>
                            </div>
                            <div class="w-full">
                                <input
                                    class={ControlsConstants.TextBox.textBoxDefault}
                                    id="diagramname"
                                    name="diagramname"
                                    type="text"
                                    value={props.diagramname}
                                    placeholder='Enter Diagram Name'
                                    onChange={props.compHandleTextOnChange}
                                />
                            </div>
                        </div>
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={pre} >previous</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={props.SubmitChangesChanges} >Submit Changes
                            </button>
                        </div>
                    </div>
                }
                <div class="md:flex md:items-center">
                    <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-full-name">
                        {props.OperationMessages}
                    </label>
                </div>
            </div>
        </div>
    );
}

export default AddTaskID;