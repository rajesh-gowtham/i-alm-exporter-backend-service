import { isNumber } from "lodash";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { HiPencilAlt } from "react-icons/hi";
import { RxCross2 } from "react-icons/rx";
import TreeListContainer from "../../TreeViewModel/TreeListContainer";
import "./ResizeCompIndex.css";

function ResizeCompIndex({ treeViewToggle, mappingDiagrams, onClickTreeViewItem, selectedNodeId, onAddEditMapDiagramOpen, fromViewer, selectedMapData, Role, mapDiagramName }) {
    const sidebarRef = useRef(null);

    const [isResizing, setIsResizing] = useState(false);
    const [sidebarWidth, setSidebarWidth] = useState(100);

    const startResizing = useCallback((mouseDownEvent) => {
        console.log("mouseDown");
        setIsResizing(true);
    }, []);

    const stopResizing = useCallback(() => {
        setIsResizing(false);
    }, []);

    const resize = useCallback(
        (mouseMoveEvent) => {
            if (isResizing) {
                setSidebarWidth(
                    mouseMoveEvent.clientX -
                    sidebarRef.current.getBoundingClientRect().left
                );
            }
        },
        [isResizing]
    );

    useEffect(() => {
        window.addEventListener("mousemove", resize);
        window.addEventListener("mouseup", stopResizing);
        return () => {
            window.removeEventListener("mousemove", resize);
            window.removeEventListener("mouseup", stopResizing);
        };
    }, [resize, stopResizing]);

    const [selectedOption, setSelectedOption] = useState("");
    const mapName = mapDiagramName.substring(0, 1) === '-' ? mapDiagramName.substring(1, mapDiagramName.length) : mapDiagramName

    const options = [
        { label: mapName, value: mapName },
    ];

    const handleSelectChange = (e) => {
        setSelectedOption(e.target.value);
    };

    return (
        <div
            ref={sidebarRef}
            className="resize-app-sidebar"
            style={{ width: sidebarWidth }}
        >
            <div className="resize-app-sidebar-content" >
                <div className="bg-white border-r-2 border-b-2 h-[93vh] ease-in-out" >
                    <div onClick={treeViewToggle} className="flex items-center py-2.5 p-1 pt-5 border-b-2 w-full h-[50px] cursor-pointer">
                        <span className="w-full text-sm">Diagram Explorer</span>  <span className="flex justify-end w-1/3"><RxCross2 size={18} color="red" /></span>
                    </div>
                    <div>
                        <div className="relative w-full">
                            <select
                                value={selectedOption}
                                onChange={handleSelectChange}
                                className="block border-gray-300 focus:border-indigo-500 shadow-sm px-4 py-2 pr-10 border rounded-md focus:ring-indigo-500 w-full text-base appearance-none focus:outline-none"
                            >
                                {selectedOption === "" && <option disabled hidden>Select an option</option>}
                                {options.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </select>
                            {(!(fromViewer) && ((Role === "Admin" && selectedMapData.diagramXmlIds.Draft?.status === "InProgress") || ((Role === "Editor" && ((isNumber(selectedMapData?.authorUserId) ? selectedMapData?.authorUserId : parseInt(selectedMapData?.authorUserId)) === parseInt(localStorage.getItem('userid')))) && selectedMapData?.diagramXmlIds.Draft?.status === "InProgress"))) ?
                                <div
                                    className="right-0 absolute inset-y-0 flex items-center pr-6 cursor-pointer"
                                    onClick={() => onAddEditMapDiagramOpen("EDIT")}
                                >
                                    <HiPencilAlt className="w-5 h-5 text-gray-400" />
                                </div>
                                :
                                null
                            }
                        </div>
                    </div>
                    <div className="h-[92%]">
                        <TreeListContainer
                            treeData={mappingDiagrams}
                            onClickItem={onClickTreeViewItem}
                            selectedNode={selectedNodeId}
                        />
                    </div>
                </div>
            </div>
            <div className={`resize-app-sidebar-resizer drop-shadow-lg hover:bg-slate-300 ${isResizing ? 'bg-slate-300 ' : ''} `} onMouseDown={startResizing}  ></div>
        </div>

    );
}

export default ResizeCompIndex;
