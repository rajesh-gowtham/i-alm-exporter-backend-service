import React, { useState } from "react";
import { HiPencilAlt } from "react-icons/hi";

const DynamicSelectDropdown = (props) => {
  const [selectedOption, setSelectedOption] = useState("");

  const options = [
    { label: props.mappingDiagrams[0].name, value: props.mappingDiagrams[0].name },
  ];

  const handleSelectChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleEditClick = (e) => {
    e.stopPropagation();
    props.onAddEditMapDiagramOpen("EDIT") // Prevent click event from bubbling up to the select elemen
  };

  return (
    <div className="relative w-full">
      <select
        value={selectedOption}
        onChange={handleSelectChange}
        className="block w-full px-4 py-2 pr-10 text-base border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 appearance-none"
      >
        {selectedOption === "" && <option disabled hidden>Select an option</option>}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      <div
        className="absolute inset-y-0 right-0 flex items-center pr-6 cursor-pointer"
        onClick={() => props.onAddEditMapDiagramOpen("EDIT")}
      >
        <HiPencilAlt className="h-5 w-5 text-gray-400" />
      </div>
    </div>
  );
};

export default DynamicSelectDropdown;
