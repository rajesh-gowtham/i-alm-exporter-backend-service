import React, { useState } from "react";
import { FcOpenedFolder } from "react-icons/fc";
import { MdOutlineClose } from "react-icons/md";
import Select from 'react-select';
import { getRequirementTreeArray, getTestCaseTreeArray, isValidValue, ReactSelect } from "../../CommonUtils/ComponentUtil";
import { ErrorMessage } from "../../CommonUtils/CustomToast";
import { ControlsConstants } from "../../Constants/ControlsConstants";
import BPMNService from "../../Services/BPMNService";
import TreeListContainer from "../TreeViewModel/TreeListContainer";
import { DropdownIndicator } from './../../CommonUtils/ComponentUtil';
//SCREEN ID -3000
function BpmnToolMap(props) {
  console.log(props)
  const [selectedNode, setSelectedNode] = useState({ type: '', items: [] })
  const [isTreeviewEnabled, setIsTreeviewEnabled] = useState(false)
  const [almConfig, setAlmConfig] = useState({})
  const [treeMapData, setTreeMapData] = useState([{
    meta: {
      collapsed: true,
      label: "Root"
    },
    children: [],
  }]);
  const name = props.handleBpmnRef.current.bpmnModeler.get('selection')._selectedElements[0]
  const fullName = name?.businessObject?.$attrs.fullNametxt;
  const autoNum = name?.businessObject?.$attrs.AutoNumCount;

  const handleDataSourceOnChange = async (e, obj) => {
    const name = obj.name;
    console.log(name, e);
    setAlmConfig(e)
    setSelectedNode({ type: "", items: [] })
    await openALMFolderSelect(e)
  };

  const openALMFolderSelect = async (almConfig) => {
    if ((!isValidValue(almConfig)) || Object.keys(almConfig).length === 0) {
      ErrorMessage("Plaese select alm configuration!");
    } else {
      try {
        props.openSpinnerRedux();
        let treeArray;
        const response = await BPMNService.getALMTestCasesFolderByIdAPICALL(almConfig.value);
        console.log(response)
        const resData = await response.data;
        if (almConfig.modulename === "Testing") {
          treeArray = await getTestCaseTreeArray(resData);
        } else {
          treeArray = await getRequirementTreeArray(resData);
        }
        console.log(" treeArray ", treeArray);
        setTreeMapData(treeArray);
        setIsTreeviewEnabled(true);
        props.closeSpinnerRedux()
      } catch (error) {
        console.error(error);
        props.closeSpinnerRedux()
      }
    }
  }
  const onClickTreeViewItem = (treeItem, activeNodes, event) => {
    console.log(treeItem);
    // console.log(treeMapData);
    // const findData = treeMapData.find(item => treeItem.id === item.id)
    // setSelectedNode(treeItem)
    // console.log(" findData ", findData);
    const node = treeItem;
    if (event.ctrlKey) {
      const prevType = selectedNode.type;
      if (prevType === "" || prevType === node.type) {
        let tempItems = [...selectedNode.items];
        const index = tempItems.findIndex((data) => data.id === node.id);
        if (index === -1) {
          console.log('added ');
          tempItems = [...tempItems, node];
        } else {
          const updatedItems = tempItems;
          updatedItems.splice(index, 1);
          tempItems = updatedItems;
          console.log('removed  ');
        }
        if (node.type === "test-folder") {
          const isParentAddedInd = tempItems.find(tempNode => tempNode.parentNodes.some(parentNode => parentNode.id === node.id));
          const isChildAddedInd = node.parentNodes.find(parentNode => tempItems.some(tempNode => tempNode.id === parentNode.id));
          console.log('isParentAdded ', isParentAddedInd, "isChildAddedInd ", isChildAddedInd);
          if (isChildAddedInd || isParentAddedInd) {
            ErrorMessage(`Can't select parent and child node`)
            return
          }
        }
        console.log('tempItems', tempItems);
        setSelectedNode({ type: (tempItems.length === 0 ? "" : node.type), items: tempItems });
      } else {
        ErrorMessage(`Can't select folder and test cases together`)
      }
    }
  }

  const saveFolderOnClick = () => {
    const tempSelectedNode = selectedNode.items;
    console.log(" tempSelectedNode ", tempSelectedNode);
    if (tempSelectedNode.length === 0) {
      ErrorMessage("Please select any folder !");
    } else {
      console.log(" valid");
      setIsTreeviewEnabled(false)
    }
  }
  return (
    <div>
      {/* {props.Map_DataSouceFlag && ( */}
      <>
        {/* <ReactDialogBox
            closeBox={props.openALMConnectActivity}
            modalWidth='40vw'
            headerBackgroundColor='#fff'
            headerTextColor='black'
            headerHeight='40px'
            closeButtonColor='#000'
            closeButtonSize='20px'
            bodyBackgroundColor='#fffdfc'
            bodyTextColor='black'
            //   bodyHeight='150px'
            headerText='Task Element'
          >
            <div id='addtestid'>
              <AddTaskID
                element_data_id={props.element_data_id}
                diagramname={props.diagramname}
                almtestcase={props.almtestcase}
                task_datasource={props.task_datasource}
                OperationMessages={props.OperationMessages}
                selected_datasource={props.selected_datasource}
                compHandleSelectOnChange={props.compHandleSelectOnChange}
                compHandleTextOnChange={props.compHandleTextOnChange}
                SavetaskidChangesChanges={props.SavetaskidChangesChanges}
                SubmitChangesChanges={props.SubmitChangesChanges}
                AvailabeDataSource={props.AvailabeDataSource}
              />
            </div>
          </ReactDialogBox> */}
      </>
      {/* )} */}


      <div className="top-0 right-0 bottom-0 left-0 z-[300] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
        <div className="flex justify-center items-center w-full h-full">
          {!isTreeviewEnabled ?
            <div className="w-[30vw]">
              <div className="bg-white border-box rounded-md font-sans text-gray-900">
                <div className="flex justify-center mx-auto w-full sm:max-w-lg">
                  <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                    <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                      <span className="font-semibold text-lg">
                        ALM Connect
                        <span className="font-normal text-sm">
                          {` - ${fullName}-(${autoNum})`}
                        </span>
                      </span>
                      <span className="hover:bg-gray-200 p-[2px] rounded" onClick={props.openCloseALMConnectActivity}>
                        <MdOutlineClose size={22} />
                      </span>
                    </div>

                    <div className="mt-1 w-[80%]">
                      <div className="md:items-center mb-2">
                        <div className="mb-2">
                          <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                            Data Sources :
                          </label>
                        </div>
                        <div className="w-full">
                          <Select
                            autoFocus={true}
                            styles={ReactSelect.dropDownStylesForm}
                            class="block border-grey-light mb-2 p-3 border w-full h-10"
                            name='almConfig'
                            components={{ DropdownIndicator, IndicatorSeparator: () => null }}
                            id='almConfig'
                            placeholder={"Select ALM Datasource"}
                            options={props.AvailabeDataSource}
                            value={(isValidValue(almConfig) && Object.keys(almConfig).length > 0) ? props.AvailabeDataSource?.find(opt => opt.value === almConfig.value) : null}
                            onChange={handleDataSourceOnChange}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="my-1.5 w-[80%]">
                      <div className="md:items-center mb-2">
                        <div className="mb-2">
                          <label className={ControlsConstants.label.labelDefault} htmlFor="inline-full-name">
                            Select Item :
                          </label>
                        </div>
                        <div className="flex justify-between ml-2 w-full">
                          <div className="items-center mr-2">
                            <div onClick={() => { openALMFolderSelect(almConfig) }}
                              className="font-medium text-base text-blue-500 underline cursor-pointer decoration-blue-700">

                              {
                                (isValidValue(almConfig) && Object.keys(almConfig).length > 0) ?
                                  <div className="flex items-center space-x-2 pl-4">
                                    <span>
                                      <FcOpenedFolder />
                                    </span>
                                    <span>
                                      {`${selectedNode.items?.length} selected`}
                                    </span>
                                  </div>
                                  :
                                  "Choose"
                              }
                            </div>

                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-center max-lg:justify-center items-center border-footer-border py-2 border-t rounded-b-md w-[80%]">
                      <button onClick={props.openCloseALMConnectActivity} className={`${ControlsConstants.Responsive.btnResponsive.btn_success} px-8`}>
                        Cancel
                      </button>
                      <button onClick={() => props.saveALMConnectActivity(almConfig, selectedNode.items)} className={`${ControlsConstants.Responsive.btnResponsive.btn_warning} px-[50px]`}>
                        Update
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            :
            <div className="w-[35vw]">
              <div className="bg-white px-8 pt-5 pb-24 border-box rounded-md w-full h-[80vh] font-sans text-gray-900">
                <div class="almConnect" className="mb-4 px-5 pb-1 border-b border-black border-opacity-50 font-medium"> Select Any Item</div>
                <TreeListContainer
                  treeData={treeMapData}
                  onClickItem={onClickTreeViewItem}
                  selectedNode={selectedNode.items}
                  fromALMFolder={true}
                  selectedColor={selectedNode?.items?.length > 0}
                />
                <div className="flex justify-end items-center space-x-3 mt-1">
                  <button onClick={() => setIsTreeviewEnabled(false)} className="bg-white px-4 py-1.5 border border-black border-opacity-30 rounded">
                    CANCEL
                  </button>
                  <button onClick={saveFolderOnClick} className="bg-white px-4 py-1.5 border border-black border-opacity-30 rounded">
                    OK
                  </button>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
      {/* )} */}
    </div >
  );
}
export default BpmnToolMap;
