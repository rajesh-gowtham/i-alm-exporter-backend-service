import { omit } from 'min-dash';
import ReactDOMServer from 'react-dom/server';
import { FaUsersCog } from 'react-icons/fa';
import { IoDocumentTextOutline, IoReturnDownForwardOutline } from "react-icons/io5";
import { extraActivityElements } from '../BpmnTool';
import { MdManageHistory } from "react-icons/md";

const generateIconDataUrl = (IconComponent) => {
  const svgString = ReactDOMServer.renderToStaticMarkup(<IconComponent />);
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svgString);
};
const customMenuEntries = (customActions) => [

  /** 
  {
    key: 'Messages',
    label: 'Messages',
    icon: TfiComments,
    action: function() {
      customActions.onOpenComment();
    }
  },
  {
    key: 'Print',
    label: 'Print',
    icon: IoPrintOutline,
    action: function() {
      customActions.OnprintClick();
    }
  },
  {
    key: 'Upload',
    label: 'Upload',
    icon: AiOutlineCloudUpload,
    action: function() {
      customActions.openBpmnFileUpload();
    }
  },
  {
    key: 'Download',
    label: 'Download',
    icon: BsCloudDownload,
    action: function() {
      customActions.onClickBpmnDownload();
    }
  },
  {
    key: 'Zoom-In',
    label: 'Zoom In',
    icon: FiZoomIn,
    action: function() {
      customActions.zoomInOutBpmn_OnClick('in');
    }
  },
  {
    key: 'Zoom-Out',
    label: 'Zoom Out',
    icon: FiZoomOut,
    action: function() {
      customActions.zoomInOutBpmn_OnClick('out');
    }
  },
  {
    key: 'Re-Arrange Label',
    label: 'Re-Arrange Label',
    icon: FaEdit,
    action: function() {
      if (rearrangeArray && rearrangeArray.length === 0) {
        customActions.handleeditAutoNumflag(editAutoNumflag);
      }
      else {
        ErrorMessage(BPMN_Editor_Toaster.Do_The_Re_Arrange_And_Then_Try_To_Navigate);
        return;
    }
    }
  }
  */

  {
    key: 'Add Resource',
    label: 'Add Resource',
    icon: FaUsersCog,
    action: function () {
      customActions.onClickAddResource();
    }
  },
  {
    key: 'Add Document',
    label: 'Add Document',
    icon: IoDocumentTextOutline,
    action: function () {
      customActions.openAddDocument();
    }
  },
  {
    key: 'Flow Line Connector',
    label: 'Flow Line Connector',
    icon: IoReturnDownForwardOutline,
    action: function () {
      customActions.onClickflowlinepopup();
    }
  },
  {
    key: 'ALM Connect',
    label: 'ALM Connect',
    icon: MdManageHistory,
    action: function (e,a) {
      customActions.props?.openCloseALMConnectActivity(e,a);
    }
  },
];

class CustomReplacePadProvider {
  constructor(eventBus, modeling, popupMenu, moddle, bpmnFactory, bpmnReplace, customActions, rearrangeArray, editAutoNumflag) {
    this.modeling = modeling;
    this.moddle = moddle;
    this.replace = bpmnReplace;
    this.eventBus = eventBus;
    this.bpmnFactory = bpmnFactory;
    this.customActions = customActions;
    this.rearrangeArray = rearrangeArray;
    this.editAutoNumflag = editAutoNumflag;
    popupMenu.registerProvider('bpmn-replace', this);
  }

  getPopupMenuHeaderEntries(target) {
    return function (entries) {
      return omit(entries, [
        'toggle-parallel-mi',
        'toggle-sequential-mi',
        'toggle-loop'
      ]);
    };
  }

  getPopupMenuEntries(element) {
    return (entries) => {
      const filteredObject = {};

      for (let key in entries) {
        if (element.type === "bpmn:SubProcess" && element.collapsed && key === 'replace-with-expanded-subprocess') {
          continue;
        } else if ((element.type === "bpmn:SubProcess" && element.collapsed === false) || key === 'replace-with-expanded-subprocess') {
          continue
        }
        // if (key !== 'replace-with-collapsed-subprocess' && key !== 'replace-with-task') {
        //   continue;
        // }
        filteredObject[key] = entries[key];
      }
      if (element.type === 'bpmn:Task' || extraActivityElements.includes(element.type)) {
        customMenuEntries(this.customActions).forEach(entry => {
          filteredObject[entry.key] = {
            label: entry.label,
            imageUrl: generateIconDataUrl(entry.icon),
            action: entry.action,
            className: 'add-task-icon'
          };
        });
      }
      return filteredObject;
    };
  }

}

CustomReplacePadProvider.$inject = [
  'eventBus',
  'modeling',
  'popupMenu',
  'moddle',
  'bpmnFactory',
  'replace',
  'customActions',
  'rearrangeArray',
  'editAutoNumflag',
  // 'fileUploadRef'
];

const defCustomPadObj = {
  __init__: ['customReplacePadProvider'],
  customReplacePadProvider: ['type', CustomReplacePadProvider]
};
export default defCustomPadObj