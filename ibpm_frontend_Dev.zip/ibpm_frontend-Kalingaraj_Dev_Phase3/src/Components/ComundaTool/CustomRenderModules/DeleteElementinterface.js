import { isArray } from "min-dash";
import { ErrorMessage } from "../../../CommonUtils/CustomToast";
import { extraActivityElements } from "../BpmnTool";

class CustomContextPadProvider {
  constructor(contextPad, rules, modeling, translate, selection, eventBus, customActions) {
    this._contextPad = contextPad;
    this._rules = rules;
    this._translate = translate;
    this._modeling = modeling;
    this._selection = selection;
    this._customActions = customActions;
    contextPad.registerProvider(this);

    eventBus.on('selection.changed', (event) => {
      const selectedElements = event.newSelection;

      if (selectedElements.length > 1) {
        this._contextPad.close();
      } else if (selectedElements.length === 1 && (selectedElements[0]?.id.includes("FLE_") || selectedElements[0]?.id.includes("FLS_") || selectedElements[0]?.id.includes("Actor_") || selectedElements[0]?.id.includes("AutoNum_"))) {
        this._contextPad.close();
      }
    });
    document.addEventListener('keydown', (event) => {
      if ((event.key === 'Delete' || event.key === 'Del' || event.key === 'Backspace') &&
        !['INPUT', 'TEXTAREA'].includes(event.target.tagName)) {
        event.preventDefault();
        this.handleDeleteKey();
      }
    });
  }
  async handleDeleteKey() {
    // console.log("this._customActions ", this._customActions);
    if (this._customActions?.props?.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
      (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this._customActions.props?.selectedMapData?.diagramXmlIds.Draft.status)) ||
      (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this._customActions.props?.selectedMapData?.diagramXmlIds.Draft.status))) {
      console.log("delete locked");
      return
    }
    const selection = this._selection;
    const modeling = this._modeling;
    const selectedElements = await selection.get();
    if (selectedElements.length > 0) {
      const element = selectedElements[0];
      if (element.type === "bpmn:Task" || extraActivityElements.includes(element.type)) {
        if (element.businessObject.$attrs.mapped_Child_Ids?.includes('FLE') || element.businessObject.$attrs.mapped_Child_Ids?.includes('FLS')) {
          ErrorMessage("Please remove the Flowlink connectivity before removing the activity box")
          return
        }
      }
      if (element.type === "bpmn:SubProcess") {
        if (window.confirm("Are you sure you want to delete the subprocess of this Activity?")) {
          modeling.removeElements([element]);
        }
      } else if (element.type === "bpmn:Participant") {
        if (window.confirm("Are you sure you want to delete the swinlane for this diagram")) {
          modeling.removeElements([element]);
        }
      } else {
        modeling.removeElements([element]);
      }
    }
  }

  getContextPadEntries(element) {
    const rules = this._rules;
    const translate = this._translate;
    const modeling = this._modeling;

    return (entries) => {
      const selectedElements = this._selection.get();

      if (selectedElements.length > 1) {
        return {};
      }

      let deleteAllowed = rules.allowed("elements.delete", {
        elements: [element]
      });

      if (isArray(deleteAllowed)) {
        // was the element returned as a deletion candidate?
        deleteAllowed = deleteAllowed[0] === element;
      }

      delete entries["delete"];

      // Add custom delete entry
      entries["delete"] = {
        group: "edit",
        className: "bpmn-icon-trash",
        title: translate("Remove"),
        action: {
          click: (event) => {
            if (element.type === "bpmn:Task" || extraActivityElements.includes(element.type)) {
              if (element.businessObject.$attrs.mapped_Child_Ids?.includes('FLE') || element.businessObject.$attrs.mapped_Child_Ids?.includes('FLS')) {
                ErrorMessage("Please remove the Flowlink connectivity before removing the activity box");
                return;
              }
            }

            if (element.type === "bpmn:SubProcess") {
              if (window.confirm("Are you sure you want to delete the subprocess of this Activity?")) {
                modeling.removeElements([element]);
              }
            } else if (element.type === "bpmn:Participant") {
              if (window.confirm("Are you sure you want to delete the swimlane for this diagram?")) {
                modeling.removeElements([element]);
              }
            } else {
              modeling.removeElements([element]);
            }
          }
        }
      };

      return entries;
    };
  }
}

CustomContextPadProvider.$inject = [
  "contextPad",
  "rules",
  "modeling",
  "translate",
  "selection",
  "eventBus",
  "customActions"
];

const customContextPadObj = {
  __init__: ["customContextPadProvider"],
  customContextPadProvider: ["type", CustomContextPadProvider]
};
export default customContextPadObj;