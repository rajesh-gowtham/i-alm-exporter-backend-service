import BpmnModeler from 'bpmn-js/lib/Modeler';

class CustomBpmnModeler extends BpmnModeler {
    constructor(options) {
        const additionalModules = options.additionalModules;
        additionalModules.push({
            __init__: ['customActions'],
            customActions: ['value', options.customActions],
            rearrangeArray: ['value', options.rearrangeArray],
            editAutoNumflag: ['value', options.editAutoNumflag],
            // fileUploadRef: ['value', options.fileUploadRef]
        });

        super({
            ...options,
            additionalModules
        });

        this.customizeKeyboardBindings();
    }

    customizeKeyboardBindings() {
        // console.log(this);
        const keyboard = this.get('keyboard');
        const editorActions = this.get('editorActions');

        // Disable default copy (Ctrl+C) and paste (Ctrl+V) actions
        // console.log(keyboard);
        keyboard.addListener((context) => {
            const event = context.keyEvent;

            // Prevent copy (Ctrl+C)
            if (event.ctrlKey && event.key === 'c') {
                console.log("Copy ", context);
                // event.preventDefault();
                // return true;
            }

            // Prevent paste (Ctrl+V)
            if (event.ctrlKey && event.key === 'v') {
                console.log("Paste ", context);
                // event.preventDefault();
                // return true;
            }

            return false;
        });

        // Remove copy and paste actions from the editorActions
        editorActions.unregister('copy');
        editorActions.unregister('paste');
    }
}

export default CustomBpmnModeler;
