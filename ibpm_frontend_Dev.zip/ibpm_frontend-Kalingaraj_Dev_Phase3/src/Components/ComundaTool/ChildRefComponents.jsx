import React, { forwardRef } from 'react';
import BpmnEditor from './BpmnEditor';
import BpmnTool from './BpmnTool';

export const ChildCompEditorRef = forwardRef((props, ref) => (
  <BpmnEditor {...props} ref={ref} />
));
export const ChildCompToolRef = forwardRef((props, ref) => (
  <BpmnTool {...props} ref={ref} />
));

