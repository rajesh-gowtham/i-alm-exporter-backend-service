/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { SuccessMessage } from "../../CommonUtils/CustomToast";
import LoginService from "../../Services/LoginService";
import { Change_Password_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS";
import { ChangePassword_Labels } from "../../Constants/COMMON_LABELS";

const ChangePassword = () => {
  console.log("resetPassword");
  const { email, resetToken } = useParams();
  const [changePasswordStatus, setChangePasswordStatus] = useState("LINK_PENDING");
  const [passWord, setPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [errorFlags, setErrorFlags] = useState({
    passWord: false,
    confirmPassword: false,
  });

  const dispatch = useDispatch();

  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    try {
      openSpinnerRedux();
      const res = await LoginService.LinkpasswordAPIcall(email, resetToken);
      const data = await res.data;
      console.log(res);
      console.log(data);
      const status = await res.status;

      if (status === 200 || status === 201) {
        closeSpinnerRedux();
        setChangePasswordStatus("LINK_VERIFIED");
      } else {
        closeSpinnerRedux();
        setChangePasswordStatus("LINK_EXPIRED");
      }
    } catch (error) {
      console.error(error);
      closeSpinnerRedux();
      setChangePasswordStatus("LINK_EXPIRED");
    }
  }
  const onChangehandler = (e) => {
    console.log(e.target.value);
    if (e.target.name === "password") {
      setPassword(e.target.value);
    }
    if (e.target.name === "confirm-password") {
      setconfirmPassword(e.target.value);
    }
  };
  const passworValiadte = (value) => {
    let passwordError;
    const uppercaseRegExp = /(?=.*?[A-Z])/.test(value);
    const lowercaseRegExp = /(?=.*?[a-z])/.test(value);
    const digitRegExp = /(?=.*?[0-9])/.test(value);
    const splCharRegExp = /(?=.*?[#?!@$%^&*-])/.test(value);
    const lengthRegExp = value.length > 7 && value.length < 16;

    if (
      uppercaseRegExp &&
      lowercaseRegExp &&
      digitRegExp &&
      splCharRegExp &&
      lengthRegExp
    ) {
      passwordError = false;
    } else {
      passwordError = true;
    }
    return passwordError;
  };

  const validateForm = () => {
    const validateData = {
      password: passWord,
      confirmPassword: confirmPassword,
    };
    const isValid =
      Object.values(validateData).every(
        (value) => value !== "" && value !== null && value !== undefined
      ) &&
      !passworValiadte(passWord) &&
      passWord === confirmPassword;
    setErrorFlags({
      passWord: passworValiadte(passWord),
      confirmPassword:
        confirmPassword === "" ? true : passWord !== confirmPassword,
    });
    return isValid;
  };
  const onResetSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      const requestData = {
        userEmail: email,
        resetToken: resetToken,
        newPassword: passWord,
      };
      try {
        openSpinnerRedux();
        const res = await LoginService.confirmResetPasswordAPIcall(requestData);
        console.log(res);
        const data = await res.data;
        console.log("data ", data)
        if (res.status === 200 || res.status === 201) {
          closeSpinnerRedux();
          SuccessMessage(Change_Password_Toaster.Password_Changed_Successfully);
          setChangePasswordStatus("PWD_RESETTED");
          // window.location.href = "/"
        }
      } catch (error) {
        closeSpinnerRedux();
        console.error(error);
        setChangePasswordStatus("LINK_VERIFIED");
      }
    }
  };

  const openSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: true });
  };
  const closeSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: false });
  };
  return (
    <>
      {changePasswordStatus === "LINK_VERIFIED" ? (
        <section class="bg-gray-50 dark:bg-gray-900">
          <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
            <div class="w-full p-6 bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md dark:bg-gray-800 dark:border-gray-700 sm:p-8">
              <h2 class="mb-1 text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                {ChangePassword_Labels._CHANGE_PASSWORD_TITLE}
              </h2>
              <form
                onSubmit={(e) => onResetSubmit(e)}
                class="mt-4 space-y-4 lg:mt-5 md:space-y-5"
                action="#"
              >
                <div>
                  <label
                    for="email"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    {ChangePassword_Labels._YOUR_EMAIL}
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    autoComplete="off"
                    class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder={ChangePassword_Labels._YOUR_EMAIL_PLACEHOLDER}
                    required=""
                    value={email}
                    disabled={true}
                  />
                </div>
                <div>
                  <label
                    for="password"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    {ChangePassword_Labels._NEW_PASSWORD}
                  </label>
                  <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder={ChangePassword_Labels._NEW_PASSWORD_PLACEHOLDER}
                    class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required
                    onChange={(e) => onChangehandler(e)}
                  />
                  {errorFlags.passWord && passWord === "" ? (
                    <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                      {Change_Password_Toaster.Password_Is_Mandatory}
                    </div>
                  ) : null}
                  {passWord !== "" && passworValiadte(passWord) ? (
                    <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                      {Change_Password_Toaster.Password_Validation_Error}
                    </div>
                  ) : null}
                </div>
                <div>
                  <label
                    for="confirm-password"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    {ChangePassword_Labels._CONFIRM_PASSWORD}
                  </label>
                  <input
                    type="confirm-password"
                    name="confirm-password"
                    id="confirm-password"
                    placeholder={ChangePassword_Labels._CONFIRM_PASSWORD_PLACEHOLDER}
                    class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required=""
                    onChange={(e) => onChangehandler(e)}
                  />
                  {errorFlags.confirmPassword && confirmPassword === "" ? (
                    <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                      {Change_Password_Toaster.Confirm_Password_Is_Mandatory}
                    </div>
                  ) : null}

                  {errorFlags.confirmPassword &&
                    confirmPassword !== "" &&
                    passWord !== confirmPassword ? (
                    <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                      {Change_Password_Toaster.Password_And_Confirm_Password_Is_Not_Matched}
                    </div>
                  ) : null}
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600 focus:outline-none focus:shadow-outline-blue"
                >
                  {ChangePassword_Labels._RESET_PASSWORD_BTN}
                </button>
              </form>
            </div>
            <a href="/" class="text-blue-600 text-sm hover:underline">
              <span>{ChangePassword_Labels._CLICK_HERE_TO_LOGIN}</span>
            </a>
          </div>
          <div></div>
        </section>
      ) : null}
      {changePasswordStatus === "LINK_EXPIRED" ? (
        <div class="flex justify-center items-center h-screen bg-gray-200">
          <div class="text-center">
            <p class="text-xl font-medium m-6">{Change_Password_Toaster.Reset_Link_Is_Expired}</p>
            <a
              href="/"
              class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
            >
              {ChangePassword_Labels._BACK_TO_LOGIN_BTN}
            </a>
          </div>
        </div>
      ) : null}
      {changePasswordStatus === "PWD_RESETTED" ? (
        <section class="bg-gray-50 dark:bg-gray-900">
          <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
            <div class="w-full p-6 bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md dark:bg-gray-800 dark:border-gray-700 sm:p-8">
              <div class="flex justify-center items-center ">
                <div class="text-center">
                  <div class="successWrapper">
                    <div>
                      <svg
                        class="checkmark"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 52 52"
                      >
                        <circle
                          class="checkmark__circle"
                          cx="26"
                          cy="26"
                          r="25"
                          fill="none"
                        />
                        <path
                          class="checkmark__check"
                          fill="none"
                          d="M14.1 27.2l7.1 7.2 16.7-16.8"
                        />
                      </svg>
                      <div className="flex flex-col justify-center space-y-2.5">
                        <span className="text-lg font-medium">
                          {Change_Password_Toaster.Password_Changed}
                        </span>
                        <span>
                          {Change_Password_Toaster.Your_Password_Has_Been_Changed_Successfully}
                        </span>
                        <div>
                          <a
                            href="/"
                            class="bg-blue-500 hover:bg-blue-600 text-white rounded py-1.5 px-2 w-[120px]"
                          >
                            {ChangePassword_Labels._BACK_TO_LOGIN_BTN}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : null}
    </>
  );
};

export default ChangePassword;
