import { ForgetPassword_Labels } from "../../Constants/COMMON_LABELS";
import { Forget_Password_Toaster } from "../../Constants/TOASTER_MS_TEXT_MSGS";

const ForgetPasswordModal = (props) => {
  //commented for running two times
  // const forgotLoginBtn = (event) =>{
  //   if (event.key === "Enter") {
  //     console.log("clicked in forgot component");
  //     formRef.current.blur()
  //     props.handleResetSubmit(event);
  //   }

  // }
  // useEffect(() => { 
  //   // document.addEventListener("keyup", forgotLoginBtn, false);
  //   // return () => {
  //   //   document.removeEventListener("keyup", forgotLoginBtn, false);
  //   // };
  // });
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return (
    <div className="min-h-screen flex items-center justify-center ">
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="max-w-md w-full p-6 bg-white opacity-100 rounded-md shadow-md z-10 relative">
          <button
            onClick={props.ForgotOpenclose}
            className="absolute top-2 right-2 text-blue-500"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-5 h-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
          <h2 className="text-2xl font-semibold mb-6">{ForgetPassword_Labels._FORGOT_PASSWORD_TITLE}</h2>
          <form >
            <div className="mb-4">
              <label
                htmlFor="email"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                {ForgetPassword_Labels._EMAILADDRESS}
              </label>
              <input
                type="email"
                id="email"
                className="w-full p-2 border rounded-md"
                placeholder={ForgetPassword_Labels._EMAILADDRESS_PLACEHOLDER}
                value={props.email}
                autoComplete="off"
                onChange={(e) => props.setEmail(e.target.value)}
                autoFocus={true}
              />
              {props.isForgotEmailerror.email && props.email === "" ? (
                <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                  {Forget_Password_Toaster.Email_Is_Mandatory}
                </div>
              ) : null}
              {props.isForgotEmailerror.email &&
                !emailRegex.test(props.email) &&
                props.email !== "" ? (
                <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                  {Forget_Password_Toaster.Email_Is_Not_Valid}
                </div>
              ) : null}
            </div>
            <div>
              <button
                onClick={props.handleResetSubmit}
                type="submit"
                className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600 focus:outline-none focus:shadow-outline-blue"
              >
                {ForgetPassword_Labels._RESET_PASSWORD_BTN}
              </button>
            </div>
          </form>
        </div>
      </div>
      {/* )} */}
    </div>
  );
};

export default ForgetPasswordModal;
