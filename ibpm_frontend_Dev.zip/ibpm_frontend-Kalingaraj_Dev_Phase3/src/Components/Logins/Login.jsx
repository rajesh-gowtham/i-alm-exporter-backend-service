import React, { useEffect, useState } from 'react';
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { convertFileToBase64, validateFileOnChange } from '../../CommonUtils/ComponentUtil';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { getDeviceId } from '../../CommonUtils/DeviceIdGenerate';
import { Login_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from "../../Constants/ControlsConstants";
import { Auth_Common_Toaster, Forget_Password_Toaster, Login_Toaster, Users_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import LoginService from '../../Services/LoginService';
import UserService from '../../Services/UserService';
import AddEditUserForm from '../Users/AddUser';
import ForgetPasswordModal from './ForgotPassword';
import { useRef } from 'react';
import IbpmnLogo from "../../Images/iBPMN_Logo.png";
// import BgImage from '../../Constants/Base64String_Images/BgImage';
import bgimage from "../../Images/bgimage.png";
import { MdOutlineClose } from 'react-icons/md';
const localControlsConstant = ControlsConstants;
function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const buttonRef = useRef(null);
  const resetPswdRef = useRef(null);
  const formRef = useRef(null);
  const [userDetails, setUserDetails] = useState({
    email: "",
    password: "",
    deviceId: null
  });
  const [email, setEmail] = useState("")
  const [isForgotPwdModalOpen, setIsForgotPwdModalOpen] = useState(false);
  const [isForgotEmailerror, setForgotEmailerror] = useState({
    email: false
  })
  const [roleData, setRoleData] = useState()
  const [organization, setOrganization] = useState()
  // const [showFileInput, setShowFileInput] = useState(true);

  const [formData, setFormData] = useState({});

  const [errorFlags, setErrorFlags] = useState({
    email: false,
    password: false,
    organization: false,
    firstname: false,
    role: false,
    // password: false,
    // confirmPassword: false,
  });
  const resetForm = () => {

    setFormData(
      {
        organization: formData.organization,
        firstname: "",
        lastname: "",
        email: "",
        mobileno: "",
        role: formData.role,
        userimage: {
          imgname: "",
          imgcontent: "",
        }
      }
    );
    setErrorFlags({
      organization: false,
      firstname: false,
      email: false,
      role: false,
      // password: false,
      // confirmPassword: false,
    })
  }

  const handleOnChange = async (e, obj) => {
    let value = "";
    let name = "";
    console.log(e, obj);
    if (e.target === undefined) {
      name = obj.name;
      value = e.value;
    }
    else if (e.target.type === "text" || e.target.type === "password") {
      name = e.target.name;
      value = e.target.value;
      if (name === "firstname" || name === "lastname") {
        value = e.target.value.replace(/[^a-zA-Z\s.]/g, '')
      }
    } else if (e.target.type === "tel") {
      name = e.target.name;
      const tempValue = e.target.value.replace(/\D/g, "");
      value = tempValue.length > 25 ? tempValue?.substring(0, 25) : tempValue;
    } else if (e.target.type === "file") {
      const currFile = e.target.files[0];
      const isImageValid = await validateFileOnChange(e);
      console.log("isImageValid", isImageValid);
      if (!isImageValid) {
        return;
      }
      name = e.target.name;
      const tempImgContent = await convertFileToBase64(currFile);
      console.log('value', value);
      console.log('e.target.files', value.name);
      value = {
        imgname: currFile.name,
        imgcontent: tempImgContent
      }
    }
    console.log(name, value);
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
    console.log(name, value);

    // Update error flag for the current field
    setErrorFlags((prevErrorFlags) => ({
      ...prevErrorFlags,
      [name]: value === "" || value === null,
    }));
  }

  const handleOnSubmit = async (e) => {
    const isValid = validateActivationForm();
    console.log("result========>", isValid);
    console.log("isValid out", isValid, formData);
    if (isValid) {
      openSpinnerRedux()
      console.log("isValid", isValid);
      try {
        const response = await UserService.createNewAdminAPICall(formData);
        if (response.status === 200 || response.status === 201) {
          console.log("formData", formData, validateForm);
          setIsLoginAddUser(false);
          closeSpinnerRedux()
          resetForm();
          setFileName('');
          setIsLogin(true);
          SuccessMessage(Users_Toaster.Admin_Account_Creation_Successfully);
        }
      } catch (error) {
        closeSpinnerRedux()
        console.error("createNewAdminAPICall", error,);
        ErrorMessage(`${error?.response.data}`)
      }
    }
  };

  const [isLoginAddUser, setIsLoginAddUser] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  // const [activationKey, setActivationKey] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileContent, setFileContent] = useState('');


  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.name.endsWith('.txt')) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => {
        setFileContent(e.target.result);
      };
      reader.readAsText(file);
    } else {
      setFileName('');
      setFileContent('');
      ErrorMessage(Login_Toaster.Please_Upload_dot_txt_File);
    }
  };

  const [DeviceId, setDeviceId] = useState()
  const [showPassword, setShowPassword] = useState(false);
  const [isfirstLogin, setisfirstLogin] = useState(false)
  const [showPasswordReset, setShowPasswordReset] = useState({
    newpassword: false,
    confirmPassword: false,
  });

  const [isChangePasswordFlag, setisChangePasswordFlag] = useState(false);
  const [newpassword, setNewPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [errorFlagsReset, setErrorFlagsReset] = useState({
    newpassword: false,
    confirmPassword: false,
  });

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const validateLoginForm = () => {
    const isValid = Object.values(userDetails).every(value => value !== "") && emailRegex.test(userDetails.email);
    setErrorFlags({
      email: userDetails.email === "" && !emailRegex.test(userDetails.email) ? true : false,
      password: userDetails.password === "",
    });
    return isValid
  };

  const submit_Onclick = async (event) => {
    event.preventDefault();
    const isValid = validateLoginForm();
    if (isValid) {
      openSpinnerRedux()
      console.log('isValid=============>', isValid, userDetails);
      try {
        userDetails["deviceId"] = DeviceId;
        console.log(userDetails);
        const response = await LoginService.LoginAPIcall(userDetails);
        const data = await response.data;
        console.log(response);
        if (response.status === 200 || response.status === 201) {
          buttonRef.current.blur();
          dispatch({ type: "SET_IS_USER_AUTHENTICATED", payload: true });
          localStorage.setItem("accessToken", data?.accestoken)
          localStorage.setItem("userRole", data?.role)
          localStorage.setItem("userid", data?.userid)
          localStorage.setItem("email", userDetails.email)
          localStorage.setItem("organization", data.organization)
          localStorage.setItem("userImage", JSON.stringify(data?.userimage))
          localStorage.setItem("userName", data?.firstname + " " + data?.lastname);
          localStorage.setItem("isFirstLogin", data?.isFirstLogin)
          const isFirstLoginFromStorage = localStorage.getItem("isFirstLogin") === "true" ? true : false;
          console.log(isFirstLoginFromStorage, typeof (isFirstLoginFromStorage));
          setisfirstLogin(isFirstLoginFromStorage);
          setisChangePasswordFlag(true)
          if (!(isFirstLoginFromStorage)) {
            setTimeout(() => {
              closeSpinnerRedux()
              const Role = window.localStorage.getItem("userRole");
              if (Role === "Editor") {
                // navigate('bpmnEditor');
                navigate('Bpmndiagram');
              }
              if (Role === "Viewer") {
                navigate('bpmnViewer');
              }
              if (Role === "Admin") {
                navigate('Bpmndiagram');
              }
              if (Role === "Reviewer") {
                navigate('Bpmndiagram');
              }
            }, 1000)
          } else {
            closeSpinnerRedux()
          }
          // closeSpinnerRedux()
        }
      } catch (error) {
        closeSpinnerRedux()
        console.error("loginAPIcall", error)
        if (error?.response?.status === 409 || error?.response?.status === 403) {
          ErrorMessage(error?.response.data.message)
        } else {
          dispatch({ type: "SET_IS_USER_AUTHENTICATED", payload: false });
          ErrorMessage(error?.response?.data?.message ? error?.response?.data?.message : Auth_Common_Toaster.Something_Went_Wrong)
        }
      }
    }
    else {
      setErrorFlags({
        email: emailRegex.test(userDetails.email) ? false : true,
        password: userDetails.password === "",
      });
    }
  }

  useEffect(() => {
    document.addEventListener("keyup", loginEnterBtnHandle, false);
    return () => {
      document.removeEventListener("keyup", loginEnterBtnHandle, false);
    };
  });
  useEffect(() => {
    console.log("ttttttttttt");
    const deviceId = getDeviceId()
    removeAllLocStoargeItem()
    dispatch({ type: "SET_IS_USER_AUTHENTICATED", payload: false });
    setDeviceId(deviceId)
    setUserDetails({
      ...userDetails,
      deviceId: DeviceId
    })

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const removeAllLocStoargeItem = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("userid")
    localStorage.removeItem("email")
    localStorage.removeItem("organization")
    localStorage.removeItem("userImage")
    localStorage.removeItem("userName")
    localStorage.removeItem("navpath")
    localStorage.removeItem("accessToken")
    localStorage.removeItem("isFirstLogin")
  }

  const loginEnterBtnHandle = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      if (window.localStorage.getItem('isFirstLogin') === "true") {
        buttonRef.current.blur();
        onSubmitPasswordReset(event)
      }
      else if (isForgotPwdModalOpen) {
        buttonRef.current.blur();
      }
      else if (!isForgotPwdModalOpen || formRef.current.focus()) {
        submit_Onclick(event);
      }
    }
  };
  const ForgotOpenclose = () => {
    console.log("cliked");
    setIsForgotPwdModalOpen(prev => !prev);
  }

  const handleActivationSubmit = async (e) => {
    e.preventDefault();
    if (!fileName.endsWith('.txt')) {
      ErrorMessage(Login_Toaster.Please_Upload_dot_txt_File);
      return;
    }
    const formData = new FormData();
    const file = new Blob([fileContent], { type: 'text/plain' });
    formData.append('file', file);

    try {
      openSpinnerRedux();
      const response = await LoginService.uploadActivationFile(formData);
      const data = await response.data;
      if (response.status === 200) {
        SuccessMessage(Login_Toaster.Activation_Successful);

        setRoleData([{ label: 'Admin', value: 'Admin' }]);
        setOrganization(data.organization);
        setFormData({
          organization: data.organization,
          firstname: "",
          lastname: "",
          email: "",
          mobileno: "",
          role: "Admin",
          userimage: {
            imgname: "",
            imgcontent: "",
          }
        })
        console.log('organization', data.organization)
        setIsLoginAddUser(true);
      }
      else if (response.status === 201) {
        console.log("when Update :" + response.data.message)
        SuccessMessage(response.data.message);
      }
      else {
        ErrorMessage(Login_Toaster.Activation_Failed);
      }
      closeSpinnerRedux();
    } catch (error) {
      console.error("Activation API call error", error);
      // console.log('organization', error.response.data.organization)
      if (error.response && error.response.status === 406) {

        setRoleData([{ label: 'Admin', value: 'Admin' }]);
        setOrganization(error.response.data.organization);
        setFormData({
          organization: error.response.data.organization,
          firstname: "",
          lastname: "",
          email: "",
          mobileno: "",
          role: "Admin",
          userimage: {
            imgname: "",
            imgcontent: "",
          }
        })
        // ErrorMessage(Login_Toaster.Activation_Failed)
        // console.log('organization', data.organization)
        setIsLoginAddUser(true);
        setFileName('');
        closeSpinnerRedux();
      }
      else {
        ErrorMessage(error.response.data.message);
        closeSpinnerRedux();
        setFileName('');
      }
    }
  };
  const validateActivationForm = () => {
    console.log(formData);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const validateData = {
      "organization": organization,
      "firstname": formData.firstname,
      "email": formData.email,
      "role": roleData,
      // "password": formData.password,
      // "confirmPassword": formData.confirmPassword
    }
    const isValid = Object.values(validateData).every(value => value !== "" && value !== null && value !== undefined) &&
      emailRegex.test(formData.email);
    setErrorFlags({
      organization: formData.organization === null,
      firstname: formData.firstname === "",
      email: formData.email === "" ? true : !emailRegex.test(formData.email),
      role: formData.role === null,
      // password: passworValiadte(formData.password),
      // confirmPassword: formData.confirmPassword === "" ? true : formData.password !== formData.confirmPassword,
    });
    console.log("!emailRegex.test(formData.email)", !emailRegex.test(formData.email));
    return isValid
  };
  //console.log("Forget password request submitted for email:", email);

  const setBackButtonOnClick = () => {
    setIsLogin(true);
    setFileName('');
  }
  const handleLoginOnChange = (e) => {
    const { name, value } = e.target;

    setUserDetails((prevDetails) => ({ ...prevDetails, [name]: value }));
    switch (name) {
      case "email":
        if (value === "") {
          setErrorFlags((prevFlags) => ({ ...prevFlags, email: true }));
        } else {
          setErrorFlags((prevFlags) => ({ ...prevFlags, email: false }));
        }
        break;
      case "password":
        if (value === "") {
          setErrorFlags((prevFlags) => ({ ...prevFlags, password: true }));
          // setErrorText((prevText) => ({ ...prevText, password: "Please enter password!" }));
        } else {
          setErrorFlags((prevFlags) => ({ ...prevFlags, password: false }));
        }
        break;
      default:
        break;
    }
  };
  const openSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: true });
  };
  const closeSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: false });
  };
  const validateForm = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const validateData = {
      "email": email,
    }
    const isValid = Object.values(validateData).every(value => value !== "" && value !== null && value !== undefined) &&
      emailRegex.test(email);
    setForgotEmailerror({
      email: email === "" ? true : !emailRegex.test(email),
    });
    return isValid
  };
  const handleResetSubmit = async (e) => {
    e.preventDefault();
    console.log("enter button is clicked for forgot password");
    const valid = validateForm();
    if (valid) {
      try {
        openSpinnerRedux()
        const resData = await LoginService.ForgotAPIcall(email)
        if (resData.status === 200) {
          SuccessMessage(Forget_Password_Toaster.Reset_Link_Successfully_Sent_To_Your_Register_Email)
          setForgotEmailerror({ email: false });
          setEmail("")
          setIsForgotPwdModalOpen(false)
          closeSpinnerRedux()
          setUserDetails({ ...userDetails, password: '' })
          formRef.current.blur()
          return;
        }
      }
      catch (error) {
        console.error(error);
        setEmail("")
        closeSpinnerRedux()
        ErrorMessage(`${error?.response.data}`)
      }
    }

  }

  //console.log("Forget password request submitted for email:", email);
  const handleChangePasswordFlag = () => {
    buttonRef.current.focus()
    removeAllLocStoargeItem()
    setNewPassword('')
    setconfirmPassword('')
    setisChangePasswordFlag(prev => !prev)
    Object.keys(errorFlagsReset).forEach(element => {
      setErrorFlagsReset(prev =>
      (
        { ...prev, [element]: false }
      )
      )
    });

  }
  const onChangehandler = (e) => {
    if (e.target.name === "new-password") {
      setNewPassword(e.target.value);
    }
    if (e.target.name === "confirm-password") {
      setconfirmPassword(e.target.value);
    }
  };
  const passworValiadte = (value) => {
    let passwordError;
    const uppercaseRegExp = /(?=.*?[A-Z])/.test(value);
    const lowercaseRegExp = /(?=.*?[a-z])/.test(value);
    const digitRegExp = /(?=.*?[0-9])/.test(value);
    const splCharRegExp = /(?=.*?[#?!@$%^&*-])/.test(value);
    const lengthRegExp = value.length > 7 && value.length < 16;

    if (
      uppercaseRegExp &&
      lowercaseRegExp &&
      digitRegExp &&
      splCharRegExp &&
      lengthRegExp
    ) {
      passwordError = false;
    } else {
      passwordError = true;
    }
    return passwordError;
  };
  const validateFormResetPswd = () => {
    const validateData = {
      password: newpassword,
      confirmPassword: confirmPassword,
    };
    console.log("validateData:", validateData)
    const isValid = Object.values(validateData).every((value) => value !== "" && value !== null && value !== undefined) && !passworValiadte(newpassword) && newpassword === confirmPassword;
    setErrorFlagsReset({
      newpassword: passworValiadte(newpassword),
      confirmPassword: confirmPassword === "" ? true : newpassword !== confirmPassword,
    });
    return isValid;
  };
  const onSubmitPasswordReset = async (e) => {
    e.preventDefault()
    console.log("onSubmitPasswordReset:", "onSubmitPasswordReset")
    console.log("enter button is clicked for reset temporary password");
    const isValid = validateFormResetPswd();
    console.log("isvalid", isValid);
    if (isValid) {
      const requestData = {
        tempPassword: userDetails.password,
        userId: localStorage.getItem('userid'),
        newPassword: newpassword,
      };
      console.log(requestData);
      try {
        openSpinnerRedux();
        const res = await LoginService.changeTempPassword(requestData);
        console.log(res);
        const data = await res.data;
        console.log("data ", data)
        if (res.status === 200 || res.status === 201) {
          removeAllLocStoargeItem()
          closeSpinnerRedux();
          SuccessMessage(Login_Toaster.Password_Updated_Successfully);
          setisChangePasswordFlag(false)
          setUserDetails({ ...userDetails, password: '' })
          setNewPassword('');
          setconfirmPassword('')
          // await (LoginService.LogOutSession({ email: window.localStorage.getItem('email') }))
          navigate('/')
        }
      } catch (error) {
        // closeSpinnerRedux();
        console.error(error);
        ErrorMessage(error.message)
        // setChangePasswordStatus("LINK_VERIFIED");
      }
    }
  };

  return (
    <div>
      {isLoginAddUser ?
        <div>
          <div>
            <h1 className='font-semibold text-center text-xl'>Create Admin Account</h1>
          </div>
          <div className='flex justify-center p-5'>

            < AddEditUserForm
              formData={formData}
              isEditData={false}
              isLoginAddUser={isLoginAddUser}
              errorFlags={errorFlags}
              roleData={roleData}
              organization={organization}
              resetForm={resetForm}
              handleOnChange={handleOnChange}
              handleOnSubmit={handleOnSubmit}
            // handleOnUpdate={handleOnUpdate}
            // cancel={userBackOnClick}
            />
          </div>
        </div>
        :
        <div className="bg-gradient-to-br from-blue-300 to-indigo-300 p-[50px] h-screen">
          <div className="flex bg-white shadow rounded-[30px] h-full">
            <div className="w-3/5 login_img" style={{ backgroundImage: `url(${bgimage})` }}>
              {/* <div className="w-2/3 overflow-y-hidden">
                <div className="font-bold text-[32px] text-white uppercase">
                  We are port people, backed by 50+ years of collective expertise.
                </div>
                <hr className="border-[##FFFFFF] bg-[#FFFFFF] px-5 border w-full h-[2px]" />
                <div className="font-normal text-white text-xl">
                  Our team is here to deliver unparalleled experience at your service.
                </div>
              </div> */}
            </div>
            <div className="rounded-r-[30px] w-2/5 overflow-y-hidden">
              <div className="flex flex-col justify-center items-center px-6 h-full">
                <span className="flex justify-center items-center">
                  <img
                    className="mr-2 w-[112px] h-[80px]"
                    src={IbpmnLogo}
                    alt="logo"
                  />
                </span>
                <div className="bg-white w-full">
                  <div className="px-[30px] pt-6">
                    {isLogin ?
                      <form>
                        <div className="mb-5">
                          <label
                            for="email"
                            className="font-normal text-base text-black text-opacity-80 leading-[18px]"
                          >
                            {Login_Labels._EMAIL}
                          </label>
                          <input
                            type="email"
                            name="email"
                            id="email"
                            value={userDetails.email}
                            className={errorFlags.email && userDetails.email === ""
                              ? 'appearance-none h-10 block w-full text-black leading-tight focus:outline-none text-base focus:border-[#e50000] p-2.5  bg-[#FFEEDE] rounded-lg border-[1px] border-[#e50000] border-opacity-30 justify-start items-center gap-2.5 placeholder:text-black placeholder:text-opacity-30 placeholder:text-sm placeholder:font-normal placeholder:leading-snug'
                              : 'w-full p-2.5 bg-[#EDF2F7] rounded-md border focus:outline-none  focus:border-[#0093af] border-black border-opacity-20 justify-between items-center gap-2.5 inline-flex placeholder:text-black placeholder:text-opacity-30 placeholder:text-sm placeholder:font-normal placeholder:leading-[18px]'
                            }
                            placeholder="Enter email"
                            onChange={handleLoginOnChange}
                          />
                          {errorFlags.email ? (
                            <span className='pl-2.5 font-normal text-[#e50000] text-xs leading-tight tracking-tight'>
                              {Login_Toaster.Please_Enter_Email_Address}
                            </span>
                          ) : null}
                        </div>
                        <div className="relative mb-[10px]">
                          <label
                            for="password"
                            className="font-normal text-base text-black text-opacity-80 leading-[18px]"
                          >
                            {Login_Labels._PASSWORD}
                          </label>
                          <input
                            type={showPassword ? "text" : "password"}
                            name="password"
                            id="password"
                            // onPaste={(e) => e.preventDefault()}
                            value={userDetails.password}
                            className={
                              errorFlags.password && userDetails.password === ""
                                ? 'appearance-none h-10 block w-full text-black leading-tight focus:outline-none text-base focus:border-[#e50000] p-2.5  bg-[#FFEEDE] rounded-lg border-[1px] border-[#e50000] border-opacity-30 justify-start items-center gap-2.5 placeholder:text-black placeholder:text-opacity-30 placeholder:text-sm placeholder:font-normal placeholder:leading-snug'
                                : 'w-full p-2.5 bg-[#EDF2F7] rounded-md border focus:outline-none  focus:border-[#0093af] border-black border-opacity-20 justify-between items-center gap-2.5 inline-flex placeholder:text-black placeholder:text-opacity-30 placeholder:text-sm placeholder:font-normal placeholder:leading-[18px]'
                            }
                            // className='inline-flex justify-between items-center gap-2.5 focus:border-[#1F52A3] bg-[#EDF2F7] p-2.5 border border-black border-opacity-20 rounded-md w-full placeholder:font-normal placeholder:text-black placeholder:text-sm placeholder:text-opacity-30 placeholder:leading-[18px] focus:outline-none'
                            placeholder="Enter password"
                            onChange={handleLoginOnChange}
                            ref={formRef}
                          />
                          <div
                            type="button"
                            className={`absolute inset-y-0 right-0 flex items-center text-gray-700 pr-3  ${errorFlags.password && userDetails.password === "" ? ' pt-[10px] ' : 'pt-[25px]'}`}
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            <span className='cursor-pointer'>
                              {showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
                            </span>
                          </div>
                          {errorFlags.password && userDetails.password === "" && (
                            <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                              {Login_Toaster.Please_Enter_Password}
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-center mb-[35px]">
                          <span
                            className="font-medium text-[#0093af] text-sm underline leading-[18px] cursor-pointer"
                            onClick={ForgotOpenclose}
                          // style={{ display: "none" }}
                          >
                            {Login_Labels._FORGOT_PASSWORD}
                          </span>
                          <span
                            className="font-medium text-[#0093af] text-sm hover:text-[#165562] underline leading-[18px] cursor-pointer"
                            onClick={() => setIsLogin(false)}
                          // style={{ display: "none" }}
                          >
                            {Login_Labels._ACTIVATION_KEY}
                          </span>
                        </div>
                        <div className="flex justify-center w-full">
                          <button
                            ref={buttonRef}
                            type="button"
                            className={` w-[80%] bg-[#0093af]  p-2.5 mb-[50px] rounded-md justify-center items-center gap-2.5 flex text-white text-lg font-medium leading-[18px]`}
                            onClick={submit_Onclick}
                          >
                            {Login_Labels._LOGIN_BTN}
                          </button>
                        </div>
                        <p className="py-1 pt-2 font-light text-[10px] text-center text-gray-500 cursor-pointer">
                          © 2024 iBPM . All Rights Reserved. Version {process.env.REACT_APP_BUILD_VERSION}
                        </p>
                      </form>
                      :
                      <form className='flex justify-center items-center w-full' onSubmit={handleActivationSubmit}>
                        <div className='w-[70%]'>
                          <div className="mb-4">
                            <label className="block mb-2 font-semibold text-[#2A69CE] text-lg" htmlFor="activationFile">
                              {Login_Labels._ACTIVATION_KEY}
                            </label>
                            <div className="relative">
                              <input
                                className="absolute inset-0 opacity-0 focus:shadow-outline w-full h-full text-gray-700 leading-tight cursor-pointer focus:outline-none"
                                onChange={handleFileChange}
                                id="activationFile"
                                name="activationFile"
                                type="file"
                                onClick={(e) => { e.target.value = null }}
                              />
                              <div className="flex justify-center items-center shadow focus:shadow-outline px-3 py-2 border rounded-full w-full text-gray-700 leading-tight appearance-none focus:outline-none">
                                <span className="font-normal text-base text-black text-opacity-50 leading-tight tracking-tight">
                                  Choose File
                                </span>
                              </div>
                            </div>
                            <div className="mt-2 font-normal text-base text-black text-opacity-50 leading-tight tracking-tight">
                              {fileName || "No file chosen"}
                            </div>
                          </div>
                          <div className="font-normal text-black text-sm text-opacity-30 leading-tight tracking-tight">
                            {Login_Labels._ACTIVATION_FILE_FORMAT_SIZE}
                          </div>
                          <div className="flex justify-between items-center mt-4" >
                            <button
                              type="submit"
                              className="bg-[#0093af] hover:bg-[#1f97e8] focus:shadow-outline px-[25px] py-2 rounded-md font-bold hover:font-bold text-white transition hover:-translate-y-1 duration-300 delay-150 ease-in-out hover:scale-110 focus:outline-none"
                            >
                              {Login_Labels._VALIDATE_BTN}
                            </button>
                            <button
                              type="submit"
                              className="border-[#0093af] focus:shadow-outline px-4 py-2 border rounded-md font-bold hover:font-bold text-[#0093af] transition hover:-translate-y-1 duration-300 delay-150 ease-in-out hover:scale-110 focus:outline-none"
                              onClick={setBackButtonOnClick}
                            >
                              {Login_Labels._BACK_BTN}
                            </button>
                          </div>
                        </div>
                      </form>
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      }
      {isForgotPwdModalOpen && (
        <ForgetPasswordModal
          ForgotOpenclose={ForgotOpenclose}
          handleResetSubmit={handleResetSubmit}
          email={email}
          setEmail={setEmail}
          isForgotEmailerror={isForgotEmailerror}
        />
      )}
      {(isfirstLogin && isChangePasswordFlag) &&
        <div class="z-50 max-lg:p-12">
          <div className="top-0 right-0 bottom-0 left-0 z-[1100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
            <div className="flex justify-center items-center w-full h-full">
              <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                <div className="flex justify-center items-center w-full h-full">
                  <div className="w-[30vw]">
                    <div class="bg-white border-box rounded-md font-sans text-gray-900">
                      <div class="flex justify-center mx-auto w-full sm:max-w-lg">
                        <div class="flex flex-col justify-center items-center bg-white rounded-md w-full">
                          <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                            <span className="font-semibold text-lg">
                              {localControlsConstant.Model.resetTempPassword}
                            </span>
                            <span className="hover:bg-gray-200 p-[2px] rounded"
                              onClick={handleChangePasswordFlag}
                            >
                              <MdOutlineClose size={22} />
                            </span>
                          </div>
                          <form className='p-3'>
                            <div className="relative">
                              <label htmlFor="password" className="block mb-2 font-medium text-gray-900 text-sm">
                                {Login_Labels._NEW_PASSWORD}
                              </label>
                              <div className="relative">
                                <input
                                  type={showPasswordReset.newpassword ? "text" : "password"}
                                  name="new-password"
                                  id="password"
                                  placeholder={Login_Labels._PASSWORD_PLACEHOLDER}
                                  className="block border-gray-300 focus:border-primary-600 dark:border-gray-600 p-2.5 border dark:focus:border-blue-500 rounded-lg focus:ring-primary-600 dark:focus:ring-blue-500 w-[300px] text-gray-900 text-sm dark:placeholder-gray-400"
                                  required
                                  onChange={onChangehandler}
                                  value={newpassword}
                                />
                                <button
                                  type="button"
                                  className="right-0 absolute inset-y-0 flex items-center pr-3 text-gray-700"
                                  style={{ top: '50%', transform: 'translateY(-50%)' }}
                                  onClick={() => setShowPasswordReset(prev => ({
                                    ...prev,
                                    newpassword: !showPasswordReset.newpassword
                                  }))}
                                >
                                  {showPasswordReset.newpassword ? <FaRegEyeSlash /> : <FaRegEye />}
                                </button>
                              </div>
                              {errorFlagsReset.newpassword && newpassword === "" ? (
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                  {Login_Toaster.Password_Is_Mandatory}
                                </div>
                              ) : null}
                              {newpassword !== "" && passworValiadte(newpassword) ? (
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                  Password needs minimum 8 characters,uppercase, <br /> lowercase,special character, and number.
                                </div>
                              ) : null}
                            </div>
                            <div className="relative py-1">
                              <label htmlFor="confirm-password" className="block mb-2 font-medium text-gray-900 text-sm">
                                {Login_Labels._CONFIRM_PASSWORD}
                              </label>
                              <input
                                type={showPasswordReset.confirmPassword ? "text" : "password"}
                                name="confirm-password"
                                id="confirm-password"
                                placeholder={Login_Labels._CONFIRM_PASSWORD}
                                className="block border-gray-300 focus:border-primary-600 dark:border-gray-600 p-2.5 border dark:focus:border-blue-500 rounded-lg focus:ring-primary-600 dark:focus:ring-blue-500 w-[300px] text-gray-900 text-sm dark:placeholder-gray-400"
                                required
                                onChange={onChangehandler}
                                value={confirmPassword}
                              />
                              <button
                                type="button"
                                className="right-0 absolute inset-y-2 flex items-center mt-6 pr-3 text-gray-700"
                                onClick={() => setShowPasswordReset(prev => {
                                  return ({ ...prev, confirmPassword: !showPasswordReset.confirmPassword })
                                })}
                              >
                                {showPasswordReset.confirmPassword ? <FaRegEyeSlash /> : <FaRegEye />}
                              </button>
                              {errorFlagsReset.confirmPassword && confirmPassword === "" ? (
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                  {Login_Toaster.Confirm_Password_Is_Mandatory}
                                </div>
                              ) : null}

                              {errorFlagsReset.confirmPassword &&
                                confirmPassword !== "" &&
                                newpassword !== confirmPassword ? (
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                  {Login_Toaster.Password_And_Confirm_Password_Is_Not_Matched}
                                </div>
                              ) : null}

                            </div>
                          </form>
                          <div className="flex justify-end w-full">
                            <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer} ref={resetPswdRef}>
                              <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={onSubmitPasswordReset} >{Login_Labels._RESET_PASSWORD_BTN}</button>
                            </div>
                            <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                              <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={handleChangePasswordFlag} >{Login_Labels._CLOSE_BTN}</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      }
    </div>
  );
}

export default Login
