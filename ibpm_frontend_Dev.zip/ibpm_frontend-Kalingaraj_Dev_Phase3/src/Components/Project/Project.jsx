import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FaProjectDiagram, FaRegEdit } from "react-icons/fa";
import { HiOutlineSearch } from 'react-icons/hi';
import { IoTrashOutline } from "react-icons/io5";
import { ReactDialogBox } from 'react-js-dialog-box';
import { useDispatch } from 'react-redux';
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { Project_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { BPMN_Editor_Toaster, Project_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import ProjectService from '../../Services/ProjectService';
import { AddEditProjectForm } from './ProjectForm';
// import { AddEditRoleForm } from './RoleForm';
const localControlsConstant = ControlsConstants;
const Project = () => {
    const gridRef = useRef();
    const dispatch = useDispatch();
    const [roleData, setRoleData] = useState([]);
    const [isAddEnable, setIsAddEnable] = useState(false);
    const [isEditEnable, setIsEditEnable] = useState(false);
    const [filterValue, setFilterValue] = useState('')
    const [isdelete, setdelete] = useState(false);
    const [deleteRoleData, setdeleteRoleData] = useState();
    const [formData, setFormData] = useState({
        customerName: "",
        projects: []
    });
    const [tasks, setTasks] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [errorFlags, setErrorFlags] = useState({
        customerName: false,
        projects: false,
    });
    const [tempEditFormData, settempEditFormData] = useState([])
    // const org = localStorage.getItem('organization') === 'iGO Solutions' ? true : false;
    const handleInputChange = (e) => {
        setInputValue(e.target.value);
        const { name, value } = e.target
        setErrorFlags((prevErrorFlags) => ({
            ...prevErrorFlags,
            [name]: value === "" || value === null,
        }));
    };
    const handleAddTask = () => {
        if (inputValue.trim() !== '') {
            const isNameExist = tasks?.find(row => row?.projectName?.toLowerCase()?.trim() === inputValue?.toLowerCase()?.trim())
            if (isNameExist) {
                return ErrorMessage("Project name already exists");
            }
            else {
                setTasks(prev => ([...prev, { projectName: inputValue.trim() }]));
                setInputValue('');
            }
            Object.keys(errorFlags).map(el => {
                return (
                    setErrorFlags(prev => ({ [el]: false }))
                )
            })
        }

    };
    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleAddTask();
        }
    };
    const handleDeleteTask = (index) => {
        const updatedTasks = [...tasks];
        updatedTasks.splice(index, 1);
        setTasks(updatedTasks);
    };
    const handleToggleEdit = (index) => {
        const updatedTasks = [...tasks];
        updatedTasks[index] = {
            ...updatedTasks[index],
            editing: !updatedTasks[index].editing
        };
        setTasks(updatedTasks);
    };
    const handleUpdateTask = (index) => {
        const updatedTasks = [...tasks];
        updatedTasks[index] = {
            ...updatedTasks[index],
            editing: false
        };
        setTasks(updatedTasks);
    };
    const handleEditKeyDown = (e, index) => {
        if (e.key === 'Enter') {
            handleUpdateTask(index);
        }
    };
    const handleEditChange = (value, index) => {
        const updatedTasks = [...tasks];
        updatedTasks[index] = {
            ...updatedTasks[index],
            projectName: value
        };
        setTasks(updatedTasks);
    };
    const userColumnDef = [
        { field: 'customerName', headerName: 'Customer', sortable: true, suppressMovable: true, flex: 1 },
        {
            headerName: "Projects", field: "projects", sortable: true, suppressMovable: true, flex: 4, width: 400,
            cellRendererFramework: (params) => {
                const projects = params.data.projects.map(module => module.projectName).join(', ');
                return <div className='flex items-center space-x-4 w-full h-full'>{projects}</div>;
            }
        },
        {
            headerName: "Action", field: "Action", suppressMovable: true, width: 200,
            cellRendererFramework: (params) =>
                <div class='flex items-center space-x-4 w-full h-full'>
                    <button onClick={() => addEditProjectOpen(params, "EDIT")}><FaRegEdit color='blue' /></button>
                    <button onClick={(e) => deleteProjectOpen(params.data)} ><IoTrashOutline color='red' /></button>
                </div>
        }
    ];
    const getAllProject = async () => {
        try {
            openSpinnerRedux();
            const response = await ProjectService.getAllCustomerAPIcall();
            console.log("getAllRolesAPIcall", response);
            const data = await response?.data;
            console.log("getAllRolesAPIcall", data);
            if (response?.status === 200 || response?.status === 201) {
                setRoleData(data);
                closeSpinnerRedux();
            }
        } catch (error) {
            closeSpinnerRedux();
            console.error("getAllRolesAPIcall", error)
        }
    }
    useEffect(() => {
        getAllProject();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const handleOnChange = async (e) => {
        const { name, value } = e.target;
        console.log(name, value);
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));
        setErrorFlags((prevErrorFlags) => ({
            ...prevErrorFlags,
            [name]: value === "" || value === null,
        }));
    }
    const deleteProjectOpen = (deleteData) => {
        setdelete(true);
        console.log(deleteData);
        setdeleteRoleData(deleteData);
    }
    const addEditProjectOpen = (e, type) => {
        console.log(e);
        console.log("clicked");
        if (type === "ADD") {
            setIsAddEnable(true);
            setIsEditEnable(false);
            setFormData({
                customerName: "",
                projects: []
            })
            setTasks([])
            setErrorFlags({
                customerName: false,
                projects: false,
            })
        } else {
            console.log(e.data);
            setIsAddEnable(false);
            setIsEditEnable(true);
            setFormData({
                customerName: e.data.customerName,
                projects: e.data.projects,
                id: e.data.id
            })
            const tempEditData1 = {
                customerName: e.data.customerName,
                projects: e.data.projects,
                id: e.data.id
            };
            settempEditFormData(tempEditData1)
            setTasks(e.data.projects)
            setErrorFlags({
                customerName: false,
                projects: false
            });
        }
    }
    const closeDialogBox = () => {
        setIsAddEnable(false);
        setIsEditEnable(false);
        setdelete(false);
        setInputValue('')
    }
    const deleteRoleOnClick = async () => {
        console.log(deleteRoleData);
        try {
            openSpinnerRedux();
            const response = await ProjectService.deleteCustomerAPIcall(deleteRoleData?.id);
            console.log(response);
            if (response?.status === 200 || response?.status === 201 || response?.status === 204) {
                getAllProject();
                setdelete(false);
                closeSpinnerRedux();
                closeDialogBox()
                SuccessMessage(Project_Toaster.Customer_Deleted_Successfully);
            }
        } catch (error) {
            console.error("deleteRoleAPIcall", error)
            closeSpinnerRedux();
            closeDialogBox()
            ErrorMessage(error?.response?.data)
        }
        setdeleteRoleData(null);
    };
    const validateForm = () => {
        const { customerName } = formData;
        const isFormDataValid = Object.values({ customerName })
            .every(value => value.trim() !== "" && value.trim() !== null && value.trim() !== undefined);
        const hasProjects = Array.isArray(tasks) && tasks.length > 0
        const isValid = isFormDataValid && hasProjects
        console.log(isFormDataValid);
        setErrorFlags({
            customerName: isFormDataValid === false ? true : false,
            projects: hasProjects === false ? true : false
        });
        return isValid;
    };
    const handleAddProjectData = async () => {
        const isValid = validateForm();
        console.log("isValid out", isValid, formData);
        if (isValid) {
            const tempData = {
                customerName: formData.customerName.trim(),
                projects: tasks
            }
            console.log(tempData)
            try {
                console.log(tempData);
                if (tempData.customerName === "" || tempData.customerName === undefined) {
                    ErrorMessage(Project_Toaster.Project_Name_Cant_Be_Empty)
                    return
                }
                openSpinnerRedux();
                const response = await ProjectService.createNewCustomerAPICall(tempData);
                const data = await response?.data;
                console.log(response, data);
                if (response.status === 200 || response.status === 201) {
                    console.log("formData", formData);
                    // resetForm();
                    closeDialogBox()
                    getAllProject()
                    SuccessMessage(Project_Toaster.Customer_Created_Successfully)
                    closeSpinnerRedux();
                    setErrorFlags({
                        customerName: false,
                        projects: false
                    });
                }
            } catch (error) {
                console.error("createNewRoleAPICall", error,);
                ErrorMessage(error?.response.data)
                closeSpinnerRedux();
            }
        }
    }
    const compareJsonObjects = (obj1, obj2) => {
        console.log(obj1, obj2);
        const newObj1 = {
            customerName: obj1["customerName"] ? obj1["customerName"] : undefined,
            id: obj1["id"] ? obj1["id"] : undefined,
            projects: obj1['projects'].map(el => el.projectName)
        }
        const newObj2 = {
            customerName: obj2["customerName"] ? obj2["customerName"] : undefined,
            id: obj2["id"] ? obj2["id"] : undefined,
            projects: obj2['projects'].map(el => el.projectName)
        }
        console.log(newObj1, newObj2);

        if ((newObj1["customerName"].trim() === newObj2["customerName"].trim()) && ([...new Set(newObj1["projects"])].length === [...new Set(newObj2["projects"])].length)
            && ([...new Set(newObj1["projects"])].every(el => [...new Set(newObj2["projects"])].includes(el)))
        ) {
            console.log("1st if");
            return true;
        } else {
            console.log("2nd else");
            return false
        }
    };
    const handleUpdateProjectData = async () => {
        const isValid = validateForm();
        console.log("isValid out", isValid, formData);
        if (isValid)
            try {
                if (formData.customerName === "") {
                    ErrorMessage(Project_Toaster.Project_Name_Cant_Be_Empty)
                    return
                }
                const tempData = {
                    id: formData.id,
                    customerName: formData.customerName,
                    projects: tasks.map(el => ({ ...el, customerId: formData.id })),
                }
                console.log(tempData);
                const obj1 = tempEditFormData;
                const obj2 = tempData;
                const isNoChanges = compareJsonObjects(obj1, obj2)
                console.log("isNoChanges ", isNoChanges);
                if (isNoChanges) {
                    ErrorMessage(BPMN_Editor_Toaster.No_Changes_Detected)
                    return
                }

                openSpinnerRedux();
                const response = await ProjectService.updateCustomerAPIcall(tempData, formData.id);
                const data = await response?.data;
                console.log(response, data);
                if (response.status === 200 || response.status === 201) {
                    console.log("tempData", tempData);
                    // resetForm();
                    closeDialogBox()
                    getAllProject()
                    closeSpinnerRedux();
                    SuccessMessage(Project_Toaster.Customer_Updated_Successfully)
                    setErrorFlags({
                        customerName: false,
                        projects: false
                    });
                }
            } catch (error) {
                console.error("updateProjectAPIcall", error,);
                closeSpinnerRedux();
                ErrorMessage(error?.response.data)
            }
    }
    const onFilterTextBoxChanged = useCallback(() => {
        setFilterValue(document.getElementById('filter-text-box').value);
    }, []);
    const onGridReady = () => {
        console.log("onGridReady");
    }
    const openSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: true });
    };
    const closeSpinnerRedux = () => {

        dispatch({ type: "SET_SPINNER_LOADING", payload: false });
    };
    return (
        <AuthCommonLayout>
            <div className='flex justify-between bg-white mb-1 px-5 pt-2 pb-4 border-b-[1px] rounded-t-md'>
                <div className='flex items-center space-x-5'>
                    <h1 className='font-semibold text-center text-lg'>{Project_Labels._Customer_TITLE}</h1>
                    <div class="relative flex items-center border-gray-300 border rounded-md h-8 overflow-hidden">
                        <div class="place-items-center grid w-12 h-full text-search-text">
                            <HiOutlineSearch color='#0000004D' size={24} />
                        </div>
                        <input
                            id="filter-text-box"
                            onInput={onFilterTextBoxChanged}
                            class="bg-search-bg pr-2 w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs outline-none peer placeholder-[#0000004D]"
                            type="text"
                            autoComplete='off'
                            placeholder="Search..." />
                    </div>
                </div>
                <div className='flex justify-end space-x-2 p-2 pr-4'>
                    <button onClick={(e) => { addEditProjectOpen(e, "ADD") }} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:ring-0 min-w-[120px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none">
                        <span>
                            <FaProjectDiagram size={16} color="white" />
                        </span>
                        <span>
                            {Project_Labels._ADD__customer_Project_TITLE}
                        </span>
                    </button>
                </div>
            </div>
            <div id='CustomAgGrid'>
                <CustomAgGrid
                    ref={gridRef}
                    rowData={roleData}
                    columnDefs={userColumnDef}
                    onGridReady={onGridReady}
                    filterValue={filterValue}
                    OnCheckBoxSelection={() => { console.log("onCheckBoxSelection clicked"); }}
                />
            </div>
            {
                (isAddEnable || isEditEnable) ?
                    <AddEditProjectForm
                        closeDialogBox={closeDialogBox}
                        isAddEnable={isAddEnable}
                        handleOnChange={handleOnChange}
                        formData={formData}
                        handleAddProjectData={handleAddProjectData}
                        handleUpdateProjectData={handleUpdateProjectData}
                        handleKeyDown={handleKeyDown}
                        handleDeleteTask={handleDeleteTask}
                        handleAddTask={handleAddTask}
                        tasks={tasks}
                        inputValue={inputValue}
                        handleInputChange={handleInputChange}
                        handleToggleEdit={handleToggleEdit}
                        handleEditKeyDown={handleEditKeyDown}
                        handleUpdateTask={handleUpdateTask}
                        handleEditChange={handleEditChange}
                        errorFlags={errorFlags}
                    /> : null
            }
            {isdelete ?
                <ReactDialogBox
                    closeBox={closeDialogBox}
                    modalWidth={localControlsConstant.Model.modalWidth}
                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                    headerTextColor={localControlsConstant.Model.bodybg}
                    headerHeight={localControlsConstant.Model.headerheight}
                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                    headerText={localControlsConstant.Model.modelConfirm}
                >
                    <div>
                        <div class='flex items-center pl-7 max-lg:pl-2 h-16 max-lg:h-8'>
                            <h1>{Project_Labels._ARE_YOU_SURE_YOU_WANT_TO_DELETE}<span className='text-blue-500'>{deleteRoleData?.firstname} {deleteRoleData?.lastname} </span>?</h1>
                        </div>
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={deleteRoleOnClick}>{Project_Labels._YES_BTN}</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={closeDialogBox}>{Project_Labels._CANCEL_BTN}
                            </button>
                        </div>
                    </div>
                </ReactDialogBox>
                : null}
        </AuthCommonLayout>
    )
}
export default Project;