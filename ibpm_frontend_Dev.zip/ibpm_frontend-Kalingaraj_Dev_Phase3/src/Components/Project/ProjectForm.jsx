import React from 'react';
import { BsPencil, BsTrash2 } from 'react-icons/bs';
import { FaRegSave } from 'react-icons/fa';
import { Project_Labels } from '../../Constants/COMMON_LABELS';
import { Users_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';

export const AddEditProjectForm = (props) => {
    return (
        <div>
            <div id="authentication-modal" className=" overflow-y-auto overflow-x-hidden fixed flex bg-black bg-opacity-10 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
                <div className="relative p-4 w-full max-w-md max-h-full">
                    <div className="relative bg-white rounded-lg shadow">
                        <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t ">
                            <h3 className="text-xl font-semibold text-gray-900">
                                <h3 className="text-xl font-semibold text-gray-900">
                                    {props.isAddEnable ? Project_Labels._ADD_CUSTOMER_TITLE : Project_Labels._EDIT_Customer_TITLE}
                                </h3>
                            </h3>
                            <button onClick={props.closeDialogBox} type="button" className="end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center " data-modal-hide="authentication-modal">
                                <svg className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                </svg>
                                <span className="sr-only">{Project_Labels._CLOSE_MODAL}</span>
                            </button>
                        </div>
                        <div className="p-4 md:p-5">
                            <div className="space-y-4" action="#">
                                <div>
                                    <label htmlFor="customerName" className="block mb-2 text-sm font-medium text-gray-900 ">{Project_Labels._Customer_NAME}</label>
                                    <input
                                        className="bg-gray-50 outline-none border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 "
                                        type="text"
                                        id="customerName"
                                        name="customerName"
                                        autoComplete='off'
                                        placeholder={Project_Labels._Customer_NAME_PLACEHOLDER}
                                        required
                                        onChange={props.handleOnChange}
                                        value={props.formData.customerName}
                                    />

                                </div>
                                {props.errorFlags.customerName ? (
                                    <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                        {Users_Toaster.Customers_Is_Mandatory}
                                    </div>
                                ) : null}
                                <div className={`space-y-4 ${props.tasks.length > 0 ? '' : 'space-y-0'}`} action="#">
                                    <label htmlFor="customerName" className="block mb-2 text-sm font-medium text-gray-900">
                                        {Project_Labels._ADD_PROJECT_TITLE}
                                    </label>
                                    <div className="flex mb-4">
                                        <input
                                            type="text"
                                            placeholder={Project_Labels._MODULE_NAME_PLACEHOLDER}
                                            className="bg-gray-50 outline-none border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                                            value={props.inputValue}
                                            onChange={props.handleInputChange}
                                            onKeyDown={props.handleKeyDown}
                                        />
                                        <button
                                            className="px-2 rounded-r-lg bg-blue-500 text-white font-semibold py-2 hover:bg-blue-600"
                                            onClick={props.handleAddTask}
                                        >
                                            Add
                                        </button>
                                    </div>
                                    {(props.errorFlags.projects && props.tasks.length === 0) ? (
                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                            {Users_Toaster.Project_Is_Mandatory}
                                        </div>
                                    ) : null}
                                    <div className='h-[70px] overflow-y-auto z-50'>
                                        <ul id="taskList" className="divide-y divide-gray-200">
                                            {props.tasks.map((task, index) => (
                                                <li key={index} className="flex items-center py-1 px-1 border-b border-gray-200">
                                                    {task.editing ? (
                                                        <input
                                                            type="text"
                                                            className="flex-1 bg-gray-50 outline-none border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5"
                                                            value={task.projectName}
                                                            onChange={(e) => props.handleEditChange(e.target.value, index)}
                                                            onKeyDown={(e) => props.handleEditKeyDown(e, index)}
                                                            autoFocus
                                                        />
                                                    ) : (
                                                        <span className="flex-1">{task.projectName}</span>
                                                    )}
                                                    <div>

                                                        {task.editing ? (
                                                            <button
                                                                className="text-green-500 hover:text-green-600 focus:outline-none mr-2"
                                                                onClick={() => props.handleUpdateTask(index)}
                                                            >
                                                                <FaRegSave />
                                                            </button>
                                                        ) : (
                                                            <button
                                                                className="text-blue-500 hover:text-blue-600 focus:outline-none mr-2"
                                                                onClick={() => props.handleToggleEdit(index)}
                                                            >
                                                                <BsPencil />
                                                            </button>
                                                        )}
                                                        <button
                                                            className="text-red-500 hover:text-red-600 focus:outline-none"
                                                            onClick={() => props.handleDeleteTask(index)}
                                                        >
                                                            <BsTrash2 />
                                                        </button>
                                                    </div>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>

                                <div className='flex space-x-2'>
                                    {props.isAddEnable ?
                                        <button onClick={props.handleAddProjectData} className="w-full   bg-white border border-blue-400 hover:bg-black hover:bg-opacity-5  focus:ring-4 focus:outline-none  focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center text-blue-500">{Project_Labels._CREATE_BTN}</button>
                                        :
                                        <button onClick={props.handleUpdateProjectData} className="w-full   bg-white border border-blue-400 hover:bg-black hover:bg-opacity-5  focus:ring-4 focus:outline-none  focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center text-blue-500">{Project_Labels._EDIT_BTN}</button>
                                    }
                                    <button onClick={props.closeDialogBox} className="w-full   bg-white border border-blue-400 hover:bg-black hover:bg-opacity-5  focus:ring-4 focus:outline-none  focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center text-blue-500">{Project_Labels._CANCEL_BTN}</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}