import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from "bpmn-js-properties-panel";
import "bpmn-js-properties-panel/dist/assets/properties-panel.css";
import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";
import "bpmn-js/dist/assets/bpmn-js.css";
import "bpmn-js/dist/assets/diagram-js.css";
import BpmnModeler from "bpmn-js/lib/Modeler";
import React, { useEffect, useRef, useState } from 'react';
import { MdOutlineClose } from 'react-icons/md';
import { useDispatch } from 'react-redux';
import { isValidValue } from "../../CommonUtils/ComponentUtil";
import { ErrorMessage } from "../../CommonUtils/CustomToast";
import { AsIsToBe_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import BPMNService from "../../Services/BPMNService";
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';

const AsIsToBe = () => {
  const dispatch = useDispatch();
  const [suggestionData, setSuggestionData] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState({});
  const [openComparedMaps, setOpenComparedMaps] = useState(false);
  const [asIsSearchText, setAsIsSearchText] = useState('');
  const [toBeSearchText, setToBeSearchText] = useState('');
  const [asIsFilteredSuggestions, setAsIsFilteredSuggestions] = useState([]);
  const [toBeFilteredSuggestions, setToBeFilteredSuggestions] = useState([]);
  const [asIsActive, setAsIsActive] = useState(false);
  const [toBeActive, setToBeActive] = useState(false);
  const [leftData, setLeftData] = useState(null);
  const [rightData, setRightData] = useState(null);
  const [isComparisonTriggered, setIsComparisonTriggered] = useState(false);
  const [leftSelectedItem, setleftSelectedItem] = useState({});
  const [rightSelectedItem, setrightSelectedItem] = useState({});
  const [isGridVisible, setIsGridVisible] = useState(false);
  const [leftFilterSearch, setLeftFilterSearch] = useState('');
  const [filteredSuggestionsData, setFilteredSuggestionsData] = useState([]);
  const [bothInitialArray, setBothInitialArray] = useState({});
  const [rightFilterSearch, setRightFilterSearch] = useState('');
  const [leftDiagramId, setLeftDiagramId] = useState([]);
  const [rightDiagramId, setRightDiagramId] = useState([]);

  useEffect(() => {
    moduleSelectChange();
    // eslint-disable-next-line
  }, []);

  const moduleSelectChange = async () => {
    const isUserLogin = window.localStorage.getItem("userRole");
    const getBPMNData = async (apiCall, dataMapper) => {
      try {
        openSpinnerRedux();
        const response = await apiCall();

        if (response.status === 200 || response.status === 201) {
          const data = response.data;
          const alteredData = data.map(dataMapper);
          console.log("🚀 ~ alteredData:", alteredData);
          setSuggestionData(alteredData);
        }
      } catch (error) {
        console.error(error);
      } finally {
        closeSpinnerRedux();
      }
    };

    if (isUserLogin !== "Viewer") {
      await getBPMNData(
        BPMNService.getBPMNDiagramsByUserIdAPICALL,
        (item) => ({
          field1: item.diagramName,
          field2: item.mapPrivacyType,
          id: item.id,
          diagramXmlIds: item.diagramXmlIds.Draft.diagramXmlId,
        })
      );
    } else {
      await getBPMNData(
        BPMNService.getBPMNServicedata,
        (item) => ({
          field1: item.diagramName,
          field2: item.diagramLevel,
          taskConnectionIds: item.taskConnectionId,
          diagramXmlIds: item.diagramXmlId,
        })
      );
    }
  };
  const handleAsIsInputChange = (e) => {
    const searchTxt = e.target.value;
    setAsIsSearchText(searchTxt);
    filterSuggestions(searchTxt, setAsIsFilteredSuggestions, setAsIsActive);
    // reset to initialState
    if (searchTxt === '') {
      setLeftData(null);
      setLeftFilterSearch('');
      setleftSelectedItem('');
    }
  };

  const handleToBeInputChange = (e) => {
    const searchTxt = e.target.value;
    setToBeSearchText(searchTxt);
    filterSuggestions(searchTxt, setToBeFilteredSuggestions, setToBeActive);
    // reset to initialState
    if (searchTxt === '') {
      setRightData(null);
      setRightFilterSearch('')
      setrightSelectedItem('')
    }
  };

  const filterSuggestions = (searchTxt, setFilteredSuggestions, setActive) => {
    if (searchTxt) {
      console.log("🚀 ~ searchTxt:", searchTxt);
      const filteredArray = suggestionData.filter((data) =>
        data.field1.toLowerCase().includes(searchTxt.toLowerCase()) ||
        data.field2.toLowerCase().includes(searchTxt.toLowerCase())
      );
      setFilteredSuggestions(filteredArray);
      setActive(true);
    }
    else {
      setFilteredSuggestions([]);
      setActive(false);
    }
  };

  const handleSuggestSelect = (suggestion, type) => {
    setSelectedRecord(suggestion);
    if (type === "FirstObj") {
      setAsIsActive(false);
      setAsIsSearchText(suggestion.field1);
      searchSubmitOnClick(suggestion, "FirstObj");
    } else if (type === "SecondObj") {
      setToBeActive(false);
      setToBeSearchText(suggestion.field1);
      searchSubmitOnClick(suggestion, "SecondObj");
    }
  };

  const adjacentToPlainArray = async (arr) => {
    let resultArray = [];
    console.log("arr ", arr);

    const getCurrDiagramXmlById = async (arr) => {
      for (let i = 0; i < arr.length; i++) {
        resultArray.push(arr[i])
        if (arr[i].children?.length === 0) {
          continue;
        }
        await getCurrDiagramXmlById(arr[i].children);
      }
      return arr;
    }
    await getCurrDiagramXmlById(arr)
    setFilteredSuggestionsData(resultArray)
    return resultArray;
  }

  const searchSubmitOnClick = async (datas, type) => {
    const isUserLogin = window.localStorage.getItem("userRole");
    let response, result;

    const processDiagramData = async (xmlData, id, type, bothInitialData) => {
      if (!xmlData) {
        ErrorMessage("XML Datas are not available");
        closeSpinnerRedux();
        return;
      }

      const parsedData = await adjacentToPlainArray(JSON.parse(xmlData));
      if (type === "FirstObj") {
        console.log("🚀 ~ Left Array:", parsedData);
        setLeftDiagramId(id);
        setLeftData(parsedData);
        bothInitialData.leftArray = parsedData;
      } else if (type === "SecondObj") {
        console.log("🚀 ~ Right Array:", parsedData);
        setRightDiagramId(id);
        setRightData(parsedData);
        bothInitialData.rightArray = parsedData;
      }
      setBothInitialArray(bothInitialData);
    };

    try {
      openSpinnerRedux();

      if (isUserLogin !== "Viewer") {
        await BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(datas.diagramXmlIds, 'checkOut');
        response = await BPMNService.getLastSavedXmlAPICALL(datas.diagramXmlIds);
      } else {
        response = await BPMNService.getSavedXmlAPICALL(datas.taskConnectionIds);
      }

      if (response.status === 200 || response.status === 201) {
        result = response.data;
        console.log("API Result:", result);

        const xmlData = isUserLogin !== "Viewer" ? result.xmlData : result.bpmnXml;
        const id = isUserLogin !== "Viewer" ? result.diagramXmlId : result.taskConnectionId;

        const bothInitialData = bothInitialArray;
        await processDiagramData(xmlData, id, type, bothInitialData);
      }
    } catch (error) {
      console.error("Error:", error);
      if (error?.response?.status === 406) {
        return error.response?.status;
      } else {
        ErrorMessage(error.message);
      }
    } finally {
      closeSpinnerRedux();
    }
  };

  const openSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: true });
  };

  const closeSpinnerRedux = () => {
    dispatch({ type: "SET_SPINNER_LOADING", payload: false });
  };

  const closeDialogPopupBox = () => {
    setOpenComparedMaps(false);
  };

  const comparedMapsbtnOnClick = () => {
    if (isValidValue(leftSelectedItem.id) && isValidValue(rightSelectedItem.id)) {
      setOpenComparedMaps(true);
    } else {
      ErrorMessage("Please select one row from each map")
    }
  }
  const leftandRightSideMaps = () => {
    if (leftData && rightData) {
      if (leftDiagramId !== rightDiagramId) {
        setIsComparisonTriggered(true);
        setIsGridVisible(true);
      } else {
        ErrorMessage("Please select different map name")
      }
    }
    else {
      ErrorMessage("Please select both map names to compare");
    }
  }

  const mapViewOnChange = (e, from, obj) => {
    console.log(e.target.checked, from, obj);
    if (from === "left") {
      setleftSelectedItem(e.target.checked ? obj : {})
    } else {
      setrightSelectedItem(e.target.checked ? obj : {})
    }
  }

  const bothRecordFilterOnChange = (e, fromParent) => {
    const filterTxt = e.target.value;
    const tempBothArray = bothInitialArray;
    if (fromParent === "LEFT") {
      setLeftFilterSearch(filterTxt);
      const resultArray = tempBothArray.leftArray.filter(item => item.meta.label?.toLowerCase().includes(filterTxt.toLowerCase()))
      setLeftData(resultArray);
    } else {
      setRightFilterSearch(filterTxt);
      const resultArray = tempBothArray.rightArray.filter(item => item.meta.label?.toLowerCase().includes(filterTxt.toLowerCase()))
      setRightData(resultArray)
    }
  }


  return (
    <AuthCommonLayout>
      <div className='flex items-center space-x-4 bg-white mt-4 mb-3 w-full min-w-full h-10'>
        <LeftInputSearchBar
          suggestionData={suggestionData}
          selectedRecord={selectedRecord}
          asIsActive={asIsActive}
          handleSuggestSelect={(suggestion) => handleSuggestSelect(suggestion, "FirstObj")}
          handleAsIsInputChange={handleAsIsInputChange}
          asIsSearchText={asIsSearchText}
          asIsFilteredSuggestions={asIsFilteredSuggestions}
        />
        <RightInputSearchBar
          suggestionData={suggestionData}
          selectedRecord={selectedRecord}
          toBeActive={toBeActive}
          handleSuggestSelect={(suggestion) => handleSuggestSelect(suggestion, "SecondObj")}
          handleToBeInputChange={handleToBeInputChange}
          toBeSearchText={toBeSearchText}
          toBeFilteredSuggestions={toBeFilteredSuggestions}
        />

        <button
          type="button"
          onClick={leftandRightSideMaps}
          className={ControlsConstants.Responsive.btnResponsive.btn_white + " px-8"}
        >
          {AsIsToBe_Labels._COMPARE_BTN}
        </button>
      </div>
      {isGridVisible ?
        <DisplaySelectedMapsToCompare
          leftData={isComparisonTriggered ? leftData : null}
          rightData={isComparisonTriggered ? rightData : null}
          openComparedMaps={openComparedMaps}
          leftSelectedItem={leftSelectedItem}
          rightSelectedItem={rightSelectedItem}
          comparedMapsbtnOnClick={comparedMapsbtnOnClick}
          mapViewOnChange={mapViewOnChange}
          closeDialogPopupBox={closeDialogPopupBox}
          // filter both map names
          leftFilterSearch={leftFilterSearch}
          rightFilterSearch={rightFilterSearch}
          filteredSuggestionsData={filteredSuggestionsData}
          bothRecordFilterOnChange={bothRecordFilterOnChange}
        />
        : <div></div>}
    </AuthCommonLayout>
  )
};
export default AsIsToBe;

const LeftInputSearchBar = (props) => {
  return (
    <div className="mx-3 w-1/3 h-[40px]">
      <div className={`relative bg-white shadow-sm rounded-lg h-full border border-black border-opacity-30`}>
        <input
          type="search"
          className="shadow-sm px-5 rounded-lg w-full h-full placeholder:font-normal text-sm placeholder:text-sm focus:outline-none"
          placeholder={AsIsToBe_Labels._FIRST_PLACEHOLDER}
          value={props.asIsSearchText}
          onChange={props.handleAsIsInputChange}
        />
        {props.asIsActive && (
          <ul className="right-0 left-0 z-10 absolute bg-white shadow-2xl mt-2 rounded-lg max-h-72 overflow-y-auto">
            {props.asIsFilteredSuggestions.length > 0 ? (
              props.asIsFilteredSuggestions.map((suggestion, index) =>
                <li
                  key={index}
                  className="flex justify-between items-center hover:bg-gray-100 px-4 py-2 cursor-pointer"
                  onClick={() => props.handleSuggestSelect(suggestion)}
                >
                  <span>{suggestion?.field1}</span>
                  <span className="bg-sky-50 px-[8px] rounded-lg text-[13px]">
                    {suggestion?.field2}
                  </span>
                </li>
              )
            ) : (
              <li className="px-4 py-2">{AsIsToBe_Labels._NO_SUGGESTIONS_AVAILABLE}</li>
            )}
          </ul>
        )}
      </div>
    </div>

  );
};

const RightInputSearchBar = (props) => {

  return (
    <div className="mx-3 w-1/3 h-[40px]">
      <div className={`relative bg-white shadow-sm rounded-lg h-full border border-black border-opacity-30`}>
        <input
          type="search"
          className="shadow-sm px-5 rounded-lg w-full h-full placeholder:font-normal text-sm placeholder:text-sm focus:outline-none"
          placeholder={AsIsToBe_Labels._SECOND_PLACEHOLDER}
          value={props.toBeSearchText}
          onChange={props.handleToBeInputChange}
        />
        {props.toBeActive && (
          <ul className="right-0 left-0 z-10 absolute bg-white shadow-2xl mt-2 rounded-lg max-h-72 overflow-y-auto">
            {props.toBeFilteredSuggestions.length > 0 ? (
              props.toBeFilteredSuggestions.map((suggestion, index) =>
                <li
                  key={index}
                  className="flex justify-between items-center hover:bg-gray-100 px-4 py-2 cursor-pointer"
                  onClick={() => props.handleSuggestSelect(suggestion)}
                >
                  <span>{suggestion?.field1}</span>
                  <span className="bg-sky-50 px-[8px] rounded-lg text-[13px]">
                    {suggestion?.field2}
                  </span>
                </li>
              )
            ) : (
              <li className="px-4 py-2">{AsIsToBe_Labels._NO_SUGGESTIONS_AVAILABLE}</li>
            )}
          </ul>
        )}
      </div>
    </div>

  );
};

const DisplaySelectedMapsToCompare = (props) => {
  const { leftData, rightData } = props
  console.log("proops ", props);

  return (
    <div className="mx-4 mt-5">
      <div className="border-2 border-neutral-300 rounded-md w-[70%]">
        <div className="flex flex-col h-[80vh]">
          <div className="flex flex-row flex-1 overflow-y-hidden">
            <div className="flex flex-col flex-1">
              <header className="bg-gray-100 p-2 rounded-tl">
                <div className="flex items-center">
                  <div>{AsIsToBe_Labels._FIRST_MAP_DIAGRAM_LIST}</div>
                  <div className="px-3 w-3/5 h-[35px]">
                    <div className={`relative bg-white shadow-sm rounded-lg h-full border border-black border-opacity-30`}>
                      <input type="search"
                        className="shadow-sm p-2 pr-8 rounded-lg w-full h-full placeholder:font-normal text-sm placeholder:text-sm focus:outline-none"
                        placeholder={AsIsToBe_Labels._FILTER_SEARCH} value={props.leftFilterSearch}
                        onChange={(e) => { props.bothRecordFilterOnChange(e, "LEFT") }} />
                    </div>
                  </div>
                </div>
              </header>

              <main className="flex-1 p-2 overflow-y-auto">
                <div className="flex flex-col">
                  {leftData && Array.isArray(leftData) && leftData.length > 0 ? (
                    leftData.map((item, index) => (
                      <div key={index} className="border-gray-300 mb-2 pb-2 border-b">
                        <input
                          className="border-gray-300 bg-gray-100 focus:ring-blue-500 w-4 h-4 text-blue-600"
                          type="checkbox"
                          id={item.id}
                          name={item.id}
                          checked={item.id === props.leftSelectedItem?.id}
                          onChange={(e) => { props.mapViewOnChange(e, "left", item) }}
                        />
                        <label htmlFor={`processMapNameList-${index}`} className="ml-4 font-medium text-gray-900 text-sm">
                          {item.meta.label}
                        </label>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500">{AsIsToBe_Labels._NO_AVAILABLE_DATA}</p>
                  )}
                </div>
              </main>

            </div>
            <div className="border-slate-400 border-r"></div>
            <div className="flex flex-col flex-1">
              <header className="bg-gray-100 p-2 rounded-tr">
                <div className="flex items-center">
                  <div>{AsIsToBe_Labels._SECOND_MAP_DIAGRAM_LIST}</div>
                  <div className="px-3 w-3/5 h-[35px]">
                    <div className={`relative bg-white shadow-sm rounded-lg h-full border border-black border-opacity-30`}>
                      <input type="search"
                        className="shadow-sm pr-8 pl-2 rounded-lg w-full h-full placeholder:font-normal text-sm placeholder:text-sm focus:outline-none"
                        placeholder={AsIsToBe_Labels._FILTER_SEARCH} value={props.rightFilterSearch}
                        onChange={(e) => { props.bothRecordFilterOnChange(e, "RIGHT") }} />
                    </div>
                  </div>
                </div>
              </header>
              <main className="flex-1 p-2 overflow-y-auto">
                <div className="flex flex-col">
                  {rightData && Array.isArray(rightData) && rightData.length > 0 ? (
                    rightData.map((item, index) => (
                      <div key={index} className="border-gray-300 mb-2 pb-2 border-b">
                        <input
                          className="border-gray-300 bg-gray-100 focus:ring-blue-500 w-4 h-4 text-blue-600"
                          type="checkbox"
                          id={item.id}
                          name={item.id}
                          checked={item.id === props.rightSelectedItem?.id}
                          onChange={(e) => { props.mapViewOnChange(e, "right", item) }}
                        />
                        <label htmlFor={`processMapNameList-${index}`} className="ml-4 font-medium text-gray-900 text-sm">
                          {item.meta.label}
                        </label>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500">{AsIsToBe_Labels._NO_AVAILABLE_DATA}</p>
                  )}
                </div>
              </main>
            </div>
          </div>
          <footer className="bg-gray-100 p-2 rounded-b">
            <div className="flex justify-center">
              <button className={ControlsConstants.Responsive.btnResponsive.btn_white + " px-8"}
                onClick={props.comparedMapsbtnOnClick}>
                {AsIsToBe_Labels._VIEW_MAPS}
              </button>
            </div>
            {
              props?.openComparedMaps ?
                <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                  <div className="flex justify-center items-center w-full h-full">
                    <div className="w-[95vw]">
                      <div className="box-border bg-white rounded-md font-sans text-gray-900">
                        <div className="flex justify-center mx-auto w-full">
                          <div className="flex flex-col justify-center items-center bg-white rounded-md w-full">
                            <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-opacity-30 w-full cursor-pointer">
                              <span className="font-semibold text-lg">{AsIsToBe_Labels._COMPARED_MAPS}</span>
                              <span className="hover:bg-gray-200 p-[2px] rounded" onClick={props.closeDialogPopupBox}>
                                <MdOutlineClose size={22} />
                              </span>
                            </div>
                            <div className="flex w-full h-[80vh]">
                              <div className="flex-1">
                                <LeftSideResults
                                  diagramXML={isValidValue(props.leftSelectedItem.diagramXML) ? props.leftSelectedItem.diagramXML : ""}
                                  leftSelectedItem={props.leftSelectedItem}
                                />
                              </div>
                              <div className='border-r-2'></div>
                              <div className="flex-1">
                                <RightSideResults
                                  diagramXML={isValidValue(props.rightSelectedItem.diagramXML) ? props.rightSelectedItem.diagramXML : "No Maps Available"}
                                  rightSelectedItem={props.rightSelectedItem}
                                />
                              </div>
                            </div>
                            <div className="flex justify-end max-lg:justify-center items-center border-footer-border py-2 border-t rounded-b-md w-full">
                              <div className="flex space-x-4 mr-8">
                                <button className={`${ControlsConstants.Responsive.btnResponsive.btn_success} px-8`} onClick={props.closeDialogPopupBox}>
                                  {AsIsToBe_Labels._BACK_BTN}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                :
                null
            }
          </footer>
        </div>
      </div>
    </div>
  )
};

const LeftSideResults = (props) => {
  console.log("🚀 ~ LeftSideResults:", props);
  const [count, setCount] = useState(0);
  const containerRef = useRef(null);
  const modelerRef = useRef(null);
  const eventBusRef = useRef(null);

  useEffect(() => {
    const initializeModeler = async () => {
      setCount(0);
      try {
        const container = document.getElementById('viewonlyflowline');
        modelerRef.current = new BpmnModeler({
          container,
          keyboard: { bindTo: null },
          additionalModules: [
            BpmnPropertiesProviderModule,
            BpmnPropertiesPanelModule,
            {
              __init__: ['labelEditingProvider'],
              labelEditingProvider: ['value', null],
            },
            {
              dragging: ['value', { init: function () { } }],
            },
          ],
        });
        await modelerRef.current.importXML(props.diagramXML);
        await modelerRef.current.get('canvas').zoom('fit-viewport', 'auto');
        eventBusRef.current = modelerRef.current.get('eventBus');
      } catch (error) {
        console.error(error);
      }
    };

    initializeModeler();

    return () => {
      try {
        modelerRef.current?.destroy();
      } catch (error) {
        console.error(error);
      }
    };
  }, [count, props]);
  return (
    <>
      <h1 className="flex justify-center bg-indigo-50 p-1">{props.leftSelectedItem.name}</h1>
      <div id="viewonlyflowline" className='w-full h-[92%]' ref={containerRef}></div>
    </>
  );
};

const RightSideResults = (props) => {
  console.log(props);
  const [count, setCount] = useState(0);
  const containerRef = useRef(null);
  const modelerRef = useRef(null);
  const eventBusRef = useRef(null);
  useEffect(() => {
    const initializeModeler = async () => {
      setCount(0);
      try {
        const container = document.getElementById('viewonly--flowline-two');
        modelerRef.current = new BpmnModeler({
          container,
          keyboard: { bindTo: null },
          additionalModules: [
            BpmnPropertiesProviderModule,
            BpmnPropertiesPanelModule,
            {
              __init__: ['labelEditingProvider'],
              labelEditingProvider: ['value', null],
            },
            {
              dragging: ['value', { init: function () { } }],
            },
          ],
        });
        await modelerRef.current.importXML(props.diagramXML);
        await modelerRef.current.get('canvas').zoom('fit-viewport', 'auto');
        eventBusRef.current = modelerRef.current.get('eventBus');
      } catch (error) {
        console.error(error);
      }
      console.log("🚀 ~ props.diagramXML:", props.diagramXML);
    };

    initializeModeler();

    return () => {
      try {
        modelerRef.current?.destroy();
      } catch (error) {
        console.error(error);
      }
    };
  }, [count, props]);
  return (
    <>
      <h1 className="flex justify-center bg-orange-50 p-1">{props.rightSelectedItem.name}</h1>
      <div id="viewonly--flowline-two" className='w-full h-[92%]' ref={containerRef}></div>
    </>
  );
};