import React, { useState } from 'react';
import Select from 'react-select';
import { ErrorMessage } from '../../CommonUtils/CustomToast';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import allLanguages from './transLanguages.json';
const TestTranslator = () => {
    const [transWord, setTransWord] = useState('');
    const [fromLanguage, setFromLanguage] = useState({ label: 'English', value: 'en' });
    const [toLanguage, setToLanguage] = useState('');
    const [resultText, setResultText] = useState('');


    const handleOnChange = (e) => {
        setTransWord(e.target.value)
    }
    const handleSelectOnChange = (e, obj) => {
        console.log(e, obj);
        const name = obj.name;
        if (name === "fromLanguage") {
            setFromLanguage(e)
        } else {
            setToLanguage(e)
        }

    }

    const handleOnTranslateSubmit = () => {
        const toValue = toLanguage.value;
        console.log(toValue);
        if (toValue === undefined || toValue === null) {
            ErrorMessage("Please select To language!")
        }
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage.value}&tl=${toValue}&dt=t&q=${encodeURI(
            transWord
        )}`;
        console.log(transWord, fromLanguage.value, toValue);
        console.log(url);
        fetch(url)
            .then((response) => response.json())
            .then((data) => {
                console.log(data);
                setResultText(data[0][0][0]);
            })
            .catch((error) => {
                console.error('Error translating text:', error.message);
            });
    }

    return (
        <>
            <div className='flex items-center justify-center gap-5 mt-5'>
                <div className='w-1/5'>
                    <div className='mb-5'>
                        <Select
                            styles={ControlsConstants.Select.dropDownStyles}
                            name='fromLanguage'
                            placeholder={<div className="select-placeholder-text">Select Language</div>}
                            options={allLanguages}
                            onChange={handleSelectOnChange}
                            value={fromLanguage}
                        />
                    </div>
                    <div>
                        <textarea onChange={handleOnChange} className='w-full p-3 h-[200px] border-2' />
                    </div>
                </div>
                <div className='w-1/5'>
                    <div className='mb-5'>
                        <Select
                            styles={ControlsConstants.Select.dropDownStyles}
                            name='toLanguage'
                            placeholder={<div className="select-placeholder-text">Select Language</div>}
                            options={allLanguages}
                            onChange={handleSelectOnChange}
                        />
                    </div>
                    <div>
                        <textarea onChange={handleOnChange} value={resultText} className='w-full h-[200px] border-2' />
                    </div>
                </div>
            </div>
            <div className='flex items-center justify-center mt-5'>
                <button onClick={handleOnTranslateSubmit} className=' px-5 py-3 w-[150px] rounded-sm bg-slate-400' >Translate</button>
            </div>
        </>
    )
}

export default TestTranslator
