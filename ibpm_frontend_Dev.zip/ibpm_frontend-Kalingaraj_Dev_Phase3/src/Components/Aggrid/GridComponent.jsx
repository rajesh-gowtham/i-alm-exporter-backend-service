import React, { Component } from 'react';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import { GridConstants } from '../../Constants/GridConstants';
export class AGPagninationComponents extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            gridApi: "",
        };
        this.gridRef = React.createRef();
    }
    onGridReady = (params) => {
        this.gridApi = params.api;
        this.columnApi = params.columnApi;
        this.setState({
            gridApi: params.api,
        });
    };
    defaultColumnDefsResize = {
        resizable: true,
    };
    componentDidUpdate(prevProps, prevState) {
        const { props, state } = this;
        if (props.filterValue !== prevProps.filterValue) {
            this.onFilterTextBoxChanged(props.filterValue);
        }
        try {
            // PrintCostomArguments('did',this.props.rowData)
            if (this?.gridApi !== undefined) {
                this?.gridApi?.setRowData(this?.props?.rowData);
            }
            // this.gridApi.refreshCells({ force: true });
        } catch (error) {
            // PrintCostomArguments("ERR502 ", error);
            console.error(error);
            throw error;
        }
    }

    onFilterTextBoxChanged = (filterValue) => {
        this.gridRef.current.api.setQuickFilter(
            filterValue
        );
        let rowData = [];
        // this.state.gridApi.forEachNodeAfterFilter(node => {
        //     rowData.push(node.data);
        // });
        // this.props.getFilteredRowData(rowData)
    };

    render() {
        let gridheight =
            this.props?.rowData?.length !== 0 && this.props?.rowData !== undefined
                ? `${this.props?.rowData?.length * 50 + 30 > 400
                    ? 430
                    : this.props?.rowData?.length * 50 + 30
                }`
                : 400;
        // PrintCostomArguments("gridheight :", gridheight)
        gridheight = Number(gridheight) + 13;
        let gheight = '350px';
        gheight = "350px";
        // PrintCostomArguments("Actual gheight", gheight)
        return (
            <>
                <div className=" w-full">
                    <div
                        className="ag-theme-alpine px-1 pt-1 pb-2 rounded" id="roleGrid"
                        style={{ height: 250, width: "100%" }}
                    >
                        <AgGridReact
                            ref={this.gridRef}
                            animateRows={true}
                            columnDefs={this.props.columnDefs}
                            defaultColDef={this.defaultColumnDefsResize}
                            rowData={this.props?.rowData || []}
                            cacheQuickFilter={true}
                            enableColResize={true}
                            headerHeight={35}
                            rowHeight={30}
                            gridOptions={GridConstants.AGGrid.gridOptions}
                            suppressRowClickSelection={true}
                            suppressMovableColumns={true}
                            suppressRowHoverHighlight={true}
                            onGridReady={this.props.onGridReady}
                            pagination={true}
                            paginationPageSize='10'
                            rowSelection='multiple'
                            onRowSelected={this.props.rowSelected}
                            // suppressPaginationPanel={true}
                            // onFirstDataRendered={() => {
                            //     // After the grid is rendered for the first time, call the refresh method to re-render cells
                            //     this.gridApi.refreshCells({ force: true });
                            // }}
                            overlayNoRowsTemplate={
                                '<span class="ag-overlay-loading-center">No Records Found !</span>'
                            }
                            overlayLoadingTemplate={
                                '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                            }
                        />
                    </div>
                </div>
            </>
        );
    }
}