import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FaFileUpload, FaRegEdit } from "react-icons/fa";
import { HiOutlineSearch } from 'react-icons/hi';
import { IoCloseCircleOutline, IoPersonAddOutline, IoTrashOutline } from 'react-icons/io5';
import { RiArrowGoBackFill } from "react-icons/ri";
import { ReactDialogBox } from 'react-js-dialog-box';
import { useDispatch } from 'react-redux';
import { convertFileToBase64, validateFileOnChange } from '../../CommonUtils/ComponentUtil';
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { Users_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { BPMN_Editor_Toaster, Users_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import ProjectClientService from '../../Services/ClientprojectsService';
import LoginService from '../../Services/LoginService';
import RolesService from '../../Services/RolesService';
import UserService from '../../Services/UserService';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import AddEditUserForm from './AddUser';

const localControlsConstant = ControlsConstants;
const Users = () => {
    const dispatch = useDispatch();
    const gridRef = useRef();
    const [fileName, setFileName] = useState('');

    const [userData, setUserData] = useState([]);
    const [isdelete, setdelete] = useState(false);
    const [isLicenseModalVisible, setIsLicenseModalVisible] = useState(false)
    const [deleteUserData, setdeleteUserData] = useState();
    const [isEditData, setIsEditData] = useState(false);
    const [isGridVisible, setGridVisible] = useState(true);
    const [roleData, setRoleData] = useState([])
    const [filterValue, setFilterValue] = useState('')
    const [formData, setFormData] = useState({
        organization: localStorage.getItem('organization'),
        firstname: "",
        lastname: "",
        email: "",
        mobileno: "",
        role: null,
        userimage: {
            imgname: "",
            imgcontent: "",
        },
        customerIds: [],
        projectIds: [],
        customers: [],
        projects: []
    });
    const [errorFlags, setErrorFlags] = useState({
        organization: false,
        firstname: false,
        email: false,
        role: false,
        customers: false,
    });
    const [projectsData, setProjectsData] = useState([]);
    const [clientProjectsData, setclientProjectsData] = useState([]);
    const [clienId, setCliendId] = useState();
    const [projectSelected, setprojectSelected] = useState([])
    const [ModuleData, setModuleData] = useState([])
    const [index, setIndex] = useState([])
    const [tempEditFormData, settempEditFormData] = useState([])
    const [fileContent, setFileContent] = useState('');
    const org = localStorage.getItem("organization")?.trim() === 'iGO Solutions';
    const userColumnDef = [
        {
            field: 'firstname', headerName: 'User Name', flex: 1, sortable: true, suppressMovable: true,
            cellRenderer: (params) => (
                params?.data?.firstname + " " + params?.data?.lastname
            ),
        },
        { field: 'email', headerName: 'Email', flex: 1, sortable: true, suppressMovable: true, },
        { field: 'organization', headerName: 'Organization', flex: 1, sortable: true, suppressMovable: true, },
        {
            headerName: localStorage.getItem('organization') === 'iGO Solutions' ? 'Customer Name' : 'Project Name',
            field: "customers", sortable: true, suppressMovable: true, flex: 1,
            cellRendererFramework: localStorage.getItem('organization') === 'iGO Solutions' ? (params) => {
                const customers = params.data?.customers || [];
                if (customers.length === 0) {
                    return <div className='flex items-center space-x-4 w-full h-full'></div>;
                }
                const customerNames = customers.map(customer => customer.customerName).filter(name => name).join(',')
                return (
                    <div className='flex items-center space-x-4 w-full h-full text-orange-600'>
                        {customerNames || ''}
                    </div>
                );
            } :
                (params) => {
                    const customers = params.data?.customers || [];
                    if (customers.length === 0) {
                        return <div className='flex items-center space-x-4 w-full h-full'></div>;
                    }
                    const customerNames = customers[0]?.projects?.map(customer => customer.projectName).filter(name => name).join(',')
                    return (
                        <div className='flex items-center space-x-4 w-full h-full text-orange-600'>
                            {customerNames || ''}
                        </div>
                    );

                },
        },

        { field: 'role', headerName: 'Role', flex: 1, sortable: true, suppressMovable: true, },
        {
            headerName: "Action", field: "Action", suppressMovable: true, width: 120,
            cellRendererFramework: (params) =>
                <div class='flex items-center space-x-4 w-full h-full'>
                    <button onClick={(e) => editUserOpen(params.data)}><FaRegEdit color='blue' /></button>
                    {!(params.data.role === 'Admin') && <button onClick={(e) => deleteUserOpen(params.data)} ><IoTrashOutline color='red' /></button>}
                </div>
        }
    ];
    const editUserOpen = (data) => {
        console.log(data);
        setIsEditData(true);
        setGridVisible(false);
        setIndex([])
        const tempEditData = {
            organization: data.organization,
            firstname: data.firstname,
            lastname: data.lastname,
            email: data.email,
            mobileno: data.mobileno,
            role: data.role,
            userimage: data.userimage,
            userid: data.userid,
            customers: data?.customers,
            projects: data?.customers[0]?.projects
        };
        const tempEditData1 = {
            organization: data.organization,
            firstname: data.firstname,
            lastname: data.lastname,
            email: data.email,
            mobileno: data.mobileno,
            role: data.role,
            userimage: data.userimage,
            userid: data.userid,
            customers: data?.customers.map(el => parseInt(el.customerId)),
            projects: data?.customers.flatMap(el =>
                el.id ? [parseInt(el.id)] : el.projects.map(ele => parseInt(ele.id))
            ) || []
        };
        console.log("tempEditData", tempEditData1);
        setFormData(tempEditData);
        settempEditFormData(tempEditData1)
        setErrorFlags({ ...errorFlags, customers: false })
    }
    const getAllusers = async () => {
        try {
            const response = await UserService.getAllUsersAPIcall();
            console.log(response);
            const data = await response?.data;
            if (response?.status === 200 || response?.status === 201) {
                setUserData(data);
                // closeSpinnerRedux();
            }
        } catch (error) {
            closeSpinnerRedux()
            console.error("getAllUsersAPIcall", error)
            ErrorMessage(error?.response?.data)
        }
    }

    const getAllRoles = async () => {
        try {
            const response = await RolesService.getAllRolesAPIcall();
            const data = await response?.data;
            if (response?.status === 200 || response?.status === 201) {
                const mappedData = data.map(role => ({ label: role.roleName, value: role.roleName }));
                console.log("mapped Data", mappedData);
                setRoleData(mappedData);
                // closeSpinnerRedux();
                // data.map((data)=>{setRoleData({label:data.roleName, value: data.roleName})})
            }

        } catch (error) {
            closeSpinnerRedux();
            console.error("getAllRolesAPIcall", error)
            ErrorMessage(error?.response?.data)
        }
    }

    useEffect(() => {

        async function getInitialAPICALLS() {
            try {
                openSpinnerRedux();
                await getAllusers();
                await getAllRoles();
                closeSpinnerRedux();
            } catch (error) {
                console.error(error);
                closeSpinnerRedux();
            }
        }
        getInitialAPICALLS();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const addUserForm = async () => {
        setGridVisible(false);
        setIsEditData(false)
        setIndex([])
        if (localStorage.getItem.organization === 'iGO Solutions') {
            setFormData(
                {
                    organization: localStorage.getItem('organization'),
                    firstname: "",
                    lastname: "",
                    email: "",
                    mobileno: "",
                    role: null,
                    // password: "",
                    // confirmPassword: "",
                    userimage: {
                        imgname: "",
                        imgcontent: "",
                    },
                    project: [],
                    module: [],
                    customers: []
                }
            );
        }
        else {
            setFormData(
                {
                    organization: localStorage.getItem('organization'),
                    firstname: "",
                    lastname: "",
                    email: "",
                    mobileno: "",
                    role: null,
                    // password: "",
                    // confirmPassword: "",
                    userimage: {
                        imgname: "",
                        imgcontent: "",
                    },

                }
            );
        }

    }
    const handleUpdateLicense = () => {
        console.log('handleUpdateLicense');
        setIsLicenseModalVisible(true);
    }
    const handleActivationSubmit = async (e) => {
        e.preventDefault();
        if (!fileName.endsWith('.txt')) {
            ErrorMessage("Please upload a .txt file");
            return;
        }
        const formData = new FormData();
        const file = new Blob([fileContent], { type: 'text/plain' });
        formData.append('file', file);

        try {
            openSpinnerRedux();
            const response = await LoginService.uploadUpdateActivationFile(formData);
            const data = await response.data;
            if (response.status === 200) {
                SuccessMessage("Activation successful!");
                setIsLicenseModalVisible(false)
                setRoleData(['Admin']);
                // setOrganization(data.organization);
                console.log('organization', data.organization)


            }
            else if (response.status === 201) {
                console.log("when Update :" + response.data.message)
                SuccessMessage(response.data.message);
            }
            else {
                ErrorMessage("Activation failed!");
            }
            closeSpinnerRedux();
        } catch (error) {
            console.error("Activation API call error", error);
            // console.log('organization', error.response.data.organization)
            if (error.response && error.response.status === 406) {

                // data = response.data;

                ErrorMessage("User creation pending");
                setRoleData(['Admin']);
                // setOrganization(error.response.data.organization);
                // console.log('organization', data.organization)

                setFileName('');
                closeSpinnerRedux();
                setIsLicenseModalVisible(false)
            }
            else {
                ErrorMessage(error.response.data.message);
                closeSpinnerRedux();
                setFileName('');
                setIsLicenseModalVisible(false)
            }
        }
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file && file.name.endsWith('.txt')) {
            setFileName(file.name);
            const reader = new FileReader();
            reader.onload = (e) => {
                setFileContent(e.target.result);
            };
            reader.readAsText(file);
        } else {
            setFileName('');
            setFileContent('');
            ErrorMessage("Please upload a .txt file");
        }
    };
    const setBackButtonOnClick = () => {
        setIsLicenseModalVisible(false)
        setFileName('');
    }

    // Add user 

    const resetForm = () => {
        setFormData(
            {
                organization: null,
                firstname: "",
                lastname: "",
                email: "",
                mobileno: "",
                role: null,
                userimage: {
                    imgname: "",
                    imgcontent: "",
                },
                customers: []
            }
        );
        setErrorFlags({
            organization: false,
            firstname: false,
            email: false,
            role: false,
            customers: false,
        })
        setIndex([])
    }

    const handleOnChange = async (e, obj) => {
        let value = "";
        let name = "";
        console.log(e, obj);
        if (e.target === undefined) {
            name = obj.name;
            value = e.value;
        }
        // else if (e.target.type === "text" || e.target.type === "password") {
        else if (e.target.type === "text") {
            name = e.target.name;
            value = e.target.value;
            if (name === "firstname" || name === "lastname") {
                value = e.target.value.replace(/[^a-zA-Z\s.]/g, '')
            }
        } else if (e.target.type === "tel") {
            name = e.target.name;
            const tempValue = e.target.value.replace(/\D/g, "");
            value = tempValue.length > 20 ? tempValue?.substring(0, 20) : tempValue;
        } else if (e.target.type === "file") {
            const currFile = e.target.files[0];
            const isImageValid = await validateFileOnChange(e);
            console.log("isImageValid", isImageValid);
            if (!isImageValid) {
                return;
            }
            name = e.target.name;
            const tempImgContent = await convertFileToBase64(currFile);
            console.log('value', value);
            console.log('e.target.files', value.name);
            value = {
                imgname: currFile.name,
                imgcontent: tempImgContent
            }
        }
        console.log(name, value);
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));
        console.log(name, value);

        // Update error flag for the current field
        setErrorFlags((prevErrorFlags) => ({
            ...prevErrorFlags,
            [name]: value === "" || value === null,
        }));
    }

    const validateForm = () => {
        console.log(formData);
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

        const org = localStorage.getItem("organization");
        const { firstname, email, role, customers = [] } = formData;
        const isValidOrganization = org === 'iGO Solutions';
        const isEmailValid = emailRegex.test(email);
        let isValid = false;
        if (org === 'iGO Solutions') {
            const isFormDataValid = Object.values({ firstname, email, role })
                .every(value => value !== "" && value !== null && value !== undefined);
            const hasProjectsAndModules = Array.isArray(customers) && customers.length > 0
            isValid = isFormDataValid && isEmailValid && (isValidOrganization ? hasProjectsAndModules : true);
        }
        else {
            const isFormValid = Object.values({ firstname, email, role }).every(value => value !== "")
            const hasProjectsAndModules = Array.isArray(formData.projects) && formData.projects.length > 0
            console.log(hasProjectsAndModules);
            isValid = isFormValid && isEmailValid && (hasProjectsAndModules ? true : false);
        }
        setErrorFlags({
            firstname: firstname === "",
            email: email === "" ? true : !isEmailValid,
            role: role === null,
            customers: customers.length === 0 ? true : false,
        });
        return isValid;
    };
    const validateFormforUpdate = () => {
        const { firstname, role, customers = [] } = formData;
        let isValid = false;
        const org = localStorage.getItem("organization");
        // const userRole = localStorage.getItem("userRole");
        console.log(formData);
        const validateData = {
            // "organization": formData.organization,
            "firstname": firstname,
            "role": role,
        }
        if (org === 'iGO Solutions') {
            const isFormValid = Object.values(validateData).every(value => value !== "")
            const hasProjectsAndModules = Array.isArray(customers) && customers.length > 0
            isValid = isFormValid && (role === 'Admin' ? true : hasProjectsAndModules ? true : false);
        }
        else {
            const isFormValid = Object.values(validateData).every(value => value !== "")
            const hasProjectsAndModules = Array.isArray(formData.projects) && formData.projects.length > 0
            isValid = isFormValid && (role === 'Admin' ? true : hasProjectsAndModules ? true : false);
        }

        setErrorFlags({
            organization: formData.organization === null,
            firstname: formData.firstname === "",
            role: formData.role === null,
            customers: formData.customers === null || formData.customers.length === 0
        });
        return isValid
    };
    //    {working code}

    const handleChildChange = (parentIndex, childIndex, isChecked) => {
        console.log(index);
        let updatedIndex = [...index];
        const indexToUpdate = updatedIndex.findIndex(pair => pair[0] === parentIndex && pair[1] === childIndex)
        if (isChecked) {
            setErrorFlags({ ...errorFlags, customers: false })
            if (indexToUpdate === -1) {
                updatedIndex.push([parentIndex, childIndex, true]);
            } else {
                updatedIndex[indexToUpdate] = [parentIndex, childIndex, true];
            }
        } else {
            if (indexToUpdate !== -1) {
                updatedIndex = updatedIndex.filter(pair => !(pair[0] === parentIndex && pair[1] === childIndex));
            }
        }
        setIndex(updatedIndex);
        const filterAndExtract = (obj, indexPairs) => {
            const result = [];
            const customersMap = new Map();
            indexPairs.forEach(pair => {
                const customerIndex = pair[0];
                const projectIndex = pair[1];

                if (pair[2]) {
                    const customer = obj[customerIndex];

                    if (!customersMap.has(customer.id)) {
                        customersMap.set(customer.id, {
                            id: customer.id,
                            customerName: customer.customerName,
                            projects: []
                        });
                    }
                    customersMap.get(customer.id).projects.push(customer.projects[projectIndex]);
                }
            });
            result.push(...customersMap.values());
            return result;
        };
        const filteredData = filterAndExtract(projectsData, updatedIndex);
        console.log(filteredData);

        setFormData(prevFormData => {
            console.log(formData.customers);
            formData.customers = formData.customers || [];
            filteredData.forEach(filteredItem => {
                if (filteredItem && filteredItem.id && filteredItem.projects) {
                    let matchingCustomer = formData.customers.find(customer => customer.customerId === filteredItem.id);
                    if (matchingCustomer) {
                        console.log("inside matching customer");
                        filteredItem.projects.forEach(project => {
                            const existingProjectIndex = matchingCustomer.projects.findIndex(existingProject => existingProject.id === project.id && existingProject.projectName === project.projectName)
                            if (existingProjectIndex === -1) {
                                matchingCustomer.projects.push({
                                    id: project.id,
                                    projectName: project.projectName,
                                    customerId: filteredItem.id
                                });
                                console.log(formData.customers);
                            } else {
                                console.log("inside else matching customer");
                            }
                        });
                    } else {
                        formData.customers.push({
                            customerId: filteredItem.id,
                            customerName: filteredItem.customerName,
                            projects: filteredItem.projects.map(project => ({
                                id: project.id,
                                projectName: project.projectName,
                                customerId: filteredItem.id
                            }))
                        });

                    }
                    formData.customers.forEach(customer => {
                        customer.projects = customer.projects || [];
                        const uniqueProjects = {};
                        customer.projects = customer.projects.filter(project => {
                            const key = `${project.id}-${project.projectName}`;
                            if (!uniqueProjects[key]) {
                                uniqueProjects[key] = true;
                                return true;
                            }
                            return false;
                        });
                    });
                } else {

                }
            });

            formData.customers.forEach(customer => {
                const uniqueProjects = {};
                customer.projects = customer.projects.filter(project => {
                    const key = `${project.id}-${project.projectName}`;
                    if (!uniqueProjects[key]) {
                        uniqueProjects[key] = true;
                        return true;
                    }
                    return false;
                });
            });

            console.log('After removing duplicates:');
            console.log(formData.customers);
            return {
                ...prevFormData,
                customers: formData.customers
            };
        });
    };

    const handleOnchangeDropdown = (obj) => {
        return (
            setFormData({
                ...formData,
                customers: obj
            })
        )
    }
    const handleOnSubmit = async (e) => {
        const isValid = validateForm();
        console.log("result========>", isValid);
        console.log("isValid out", isValid, formData);
        if (isValid) {
            console.log("isValid", isValid);
            let tempFormData = {
                organization: localStorage.getItem('organization'),
                firstname: formData.firstname,
                lastname: formData.lastname,
                email: formData.email,
                mobileno: formData.mobileno,
                role: formData.role,
                userimage: formData.userimage,
                customerIds: !org ? [clienId] : formData.customers.map(el => el.customerId),
                projectIds: !org ? formData.customers.map(el => el.id) : formData.customers.map(el => el.id)
            }
            console.log(tempFormData);
            try {
                openSpinnerRedux();
                const response = await UserService.createNewUserAPIcall(tempFormData);
                if (response.status === 200 || response.status === 201) {
                    console.log("formData", formData, validateForm);
                    setGridVisible(true);
                    getAllusers();
                    resetForm();
                    closeSpinnerRedux();
                    SuccessMessage(Users_Toaster.User_Added_Successfully);
                }
                closeSpinnerRedux();
            } catch (error) {
                closeSpinnerRedux();
                console.error("createNewUserAPIcall", error,);
                ErrorMessage(error?.response?.data)
            }
        }
    };

    const onReceiveProjectData = async () => {
        try {

            const res = await LoginService.onReceiveProjectsData();
            const data = await res.data;
            if (res.status === 200 || res.status === 201) {
                setProjectsData(data)
            }
        } catch (error) {
            console.error(error);
            ErrorMessage(error.message)
        }
    };
    const onReceiveClientProjectData = async () => {
        try {

            const res = await ProjectClientService.getCustomerDetails(localStorage.getItem('organization'));
            const data = await res.data;
            if (res.status === 200 || res.status === 201) {
                setclientProjectsData(data.projects)
                setCliendId(data.id)
            }
        } catch (error) {
            console.error(error);
            ErrorMessage(error.message)
        }
    };
    const onhandleChangeProject = (e, obj) => {
        console.log("triggered ", e, obj);
        setErrorFlags((prevErrorFlags) => ({
            ...prevErrorFlags,
            project: e === "" || e === null || e.length === 0,
        }));
        setModuleData([])
        const findObjectsInproject = (a, b) => a.map(({ id }) => b.find(obj => obj.id === id));
        const results = findObjectsInproject(e, projectsData);
        setprojectSelected(results.filter(Boolean))
        setFormData({ ...formData, project: e })
        // const moduleDataIndex = projectsData.find(el => el.projectName === value)
        // console.log(moduleDataIndex);
        // setModuleData(moduleDataIndex.modules)
    }
    const onhandleChangeProjects = (e) => {
        console.log(e);

        setErrorFlags((prevErrorFlags) => ({
            ...prevErrorFlags,
            module: e === "" || e === null || e.length === 0,
        }));
        setFormData({ ...formData, projects: e, customers: e })
    }
    const compareJsonObjects = (obj1, obj2) => {
        console.log(obj1, obj2);
        const newObj1 = {
            firstname: obj1["firstname"] ? obj1["firstname"] : undefined,
            lastname: obj1["lastname"] ? obj1["lastname"] : undefined,
            email: obj1["email"],
            mobileno: obj1["mobileno"],
            role: obj1["role"],
            customers: obj1["customers"],
            projects: obj1['projects'],
            userimage: obj1['userimage']['imgname']
        }
        const newObj2 = {
            firstname: obj2["firstname"] ? obj2["firstname"] : undefined,
            lastname: obj2["lastname"] ? obj2["lastname"] : undefined,
            email: obj2["email"],
            mobileno: obj2["mobileno"],
            role: obj2["role"],
            customers: obj2["customerIds"],
            projects: obj2['projectIds'],
            userimage: obj2['userimage']['imgname']
        }
        console.log(newObj1, newObj2);

        if ((newObj1["firstname"] === newObj2["firstname"]) && (newObj1["lastname"] === newObj2["lastname"]) && (newObj1["email"] === newObj2["email"]) && (newObj1["mobileno"] === newObj2["mobileno"] && (((newObj1["userimage"] === null && newObj2["userimage"] === null) ? true : (obj1["userimage"] === obj2["userimage"]) ? true : false)))
            && (newObj1["role"] === newObj2["role"]) && ([...new Set(newObj1["customers"])].length === [...new Set(newObj2["customers"])].length) && ([...new Set(newObj1["customers"])].every(el => [...new Set(newObj2["customers"])].includes(parseInt(el))))
            && ([...new Set(newObj1["projects"])].length === [...new Set(newObj2["projects"])].length)
            && ([...new Set(newObj1["projects"])].every(el => [...new Set(newObj2["projects"])].includes(parseInt(el))))
        ) {
            console.log("1st if");
            return true;
        } else {
            console.log("2nd else");
            return false
        }
    };

    const handleOnUpdate = async () => {
        const isValid = validateFormforUpdate();
        console.log(isValid);

        if (isValid) {
            console.log(formData);
            const { role } = formData;
            let tempFormData = {
                organization: localStorage.getItem('organization'),
                firstname: formData.firstname,
                lastname: formData.lastname,
                email: formData.email,
                mobileno: formData.mobileno,
                role: formData.role,
                userimage: formData.userimage,
                userid: formData.userid,
                customerIds: !org ? role === 'Admin' ? [] : [clienId] : formData?.customers?.map(el => el.customerId),
                projectIds: !org ? role === 'Admin' ? [] : formData?.projects?.map(el => el.id) : formData?.customers?.flatMap(el =>
                    el?.id ? [parseInt(el.id)] : el?.projects?.map(ele => parseInt(ele.id))
                ) || []
            }
            console.log(tempFormData);

            const obj1 = tempEditFormData;
            const obj2 = tempFormData;
            const isNoChanges = compareJsonObjects(obj1, obj2)

            console.log("isNoChanges ", isNoChanges);

            if (isNoChanges) {
                ErrorMessage(BPMN_Editor_Toaster.No_Changes_Detected)
                return
            }

            else {
                try {
                    openSpinnerRedux();
                    const response = await UserService.updateUserAPIcall(tempFormData, formData.userid);
                    console.log(response);
                    if (response.status === 200 || response.status === 201) {
                        // console.log("formData", formData, validateForm);
                        await getAllusers();
                        closeSpinnerRedux();
                        SuccessMessage(Users_Toaster.User_Updated_Successfully);
                        setGridVisible(true);
                    }
                } catch (error) {
                    closeSpinnerRedux();
                    console.error("createNewUserAPIcall", error);
                    ErrorMessage(error?.response?.data)
                }
            }
        }
    }

    const onFilterTextBoxChanged = useCallback(() => {
        setFilterValue(document.getElementById('filter-text-box').value);
    }, []);
    const userBackOnClick = () => {
        setGridVisible(true);
        setIsEditData(false);
        getAllusers();
    };
    const deleteUserOpen = (deleteData) => {
        setdelete(true);
        console.log(deleteData);
        setdeleteUserData(deleteData);
    }
    const handleClose = () => {
        setdelete(false);
        setdeleteUserData(null);
    }
    const deleteUserOnClick = async () => {
        console.log(deleteUserData);
        try {
            openSpinnerRedux();
            const response = await UserService.deleteUsersAPIcall(deleteUserData?.userid);
            console.log(response);
            if (response?.status === 200 || response?.status === 201 || response?.status === 204) {
                getAllusers();
                setdelete(false);
                closeSpinnerRedux();
                SuccessMessage(Users_Toaster.User_Deleted_Successfully);
            }
        } catch (error) {
            closeSpinnerRedux();
            console.error("getAllUsersAPIcall", error)
            ErrorMessage(error?.response?.data)
            setdelete(false);
        }
        setdeleteUserData(null);
    };

    const onGridReady = () => {
        console.log("onGridReady");
    }

    const openSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: true });
    };
    const closeSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: false });
    };

    return (

        <AuthCommonLayout>
            {isGridVisible ?
                <div>
                    <div className='flex justify-between bg-white mb-1 px-5 pt-2 pb-4 border-b-[1px] rounded-t-md'>
                        <div className='flex items-center space-x-5'>
                            <h1 className='font-semibold text-lg text-center'>{Users_Labels._USERS_TITLE}</h1>
                            <div class="relative flex items-center border border-gray-300 rounded-md h-8 overflow-hidden">
                                <div class="place-items-center grid w-12 h-full text-search-text">
                                    <HiOutlineSearch color='#0000004D' size={24} />
                                </div>
                                <input
                                    id="filter-text-box"
                                    onInput={onFilterTextBoxChanged}
                                    class="peer bg-search-bg pr-2 outline-none w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs placeholder-[#0000004D]"
                                    type="text"
                                    autoComplete='off'
                                    placeholder="Search..." />
                            </div>
                        </div>
                        <div className='flex items-center space-x-4'>
                            <button onClick={addUserForm} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:outline-none focus:ring-0 min-w-[120px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm">
                                <span>
                                    <IoPersonAddOutline size={16} color="white" />
                                </span>
                                <span>
                                    {Users_Labels._ADD_USER_TITLE}
                                </span>
                            </button>
                            <button onClick={handleUpdateLicense} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:outline-none focus:ring-0 min-w-[120px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm">
                                <span>
                                    <FaFileUpload size={16} color="white" />
                                </span>
                                <span>
                                    {Users_Labels._UPDATE_LICENSE_TITLE}
                                </span>
                            </button>
                        </div>
                    </div>

                    <div id='CustomAgGrid'>
                        <CustomAgGrid
                            ref={gridRef}
                            rowData={userData}
                            columnDefs={userColumnDef}
                            onGridReady={onGridReady}
                            filterValue={filterValue}
                            OnCheckBoxSelection={() => { console.log("onCheckBoxSelection clicked"); }}
                        />
                    </div>
                </div>
                :
                <div className='relative'>
                    <div className='-top-2 z-40 sticky flex justify-between bg-white px-5 pt-2 pb-5 rounded-md'>
                        <div>
                            <div onClick={userBackOnClick} className='flex justify-center items-center bg-[#089de3] hover:bg-blue-700 mr-5 rounded-full w-[30px] h-[30px] transition-all duration-200 ease-in-out cursor-pointer'>
                                <RiArrowGoBackFill size={20} color='white' />
                            </div>
                        </div>
                        <h1 className='font-semibold text-lg text-center'>{isEditData ? Users_Labels._EDIT_USER_TITLE : Users_Labels._ADD_USER_TITLE}</h1>
                        <div>

                        </div>
                    </div>
                    {/* <div className=''> */}
                    < AddEditUserForm
                        formData={formData}
                        isEditData={isEditData}
                        errorFlags={errorFlags}
                        roleData={roleData}
                        resetForm={resetForm}
                        handleOnChange={handleOnChange}
                        handleOnSubmit={handleOnSubmit}
                        handleOnUpdate={handleOnUpdate}
                        cancel={userBackOnClick}
                        projectsData={projectsData}
                        ModuleData={ModuleData}
                        onReceiveProjectData={onReceiveProjectData}
                        onhandleChangeProject={onhandleChangeProject}
                        onhandleChangeProjects={onhandleChangeProjects}
                        projectSelected={projectSelected}
                        handleChildChange={handleChildChange}
                        onReceiveClientProjectData={onReceiveClientProjectData}
                        clientProjectsData={clientProjectsData}
                        handleOnchangeDropdown={handleOnchangeDropdown}
                    />
                    {/* </div> */}
                </div>
            }

            {isLicenseModalVisible ?
                <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                    <div className="flex justify-center items-center w-full h-full">
                        <div className="w-[25vw]">
                            <div className="bg-white shadow-xl rounded-lg sm:max-w-lg overflow-hidden text-left transition-all transform">
                                <div className="bg-white w-full">
                                    <span className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-opacity-30">
                                        <span className="font-medium text-base">Update License</span>
                                        <span className="cursor-pointer"><IoCloseCircleOutline size={28} onClick={setBackButtonOnClick} /></span>
                                    </span>
                                    <div className="flex justify-center items-center drop-shadow-lg my-2 px-2 w-full h-full">
                                        <div className="w-64 max-w-sm">
                                            <div className="mb-4">
                                                <div className="relative">
                                                    <input
                                                        className="absolute inset-0 opacity-0 focus:shadow-outline focus:outline-none w-full h-full text-gray-700 leading-tight cursor-pointer"
                                                        onChange={handleFileChange}
                                                        id="activationFile"
                                                        name="activationFile"
                                                        type="file"
                                                        onClick={(e) => { e.target.value = null }}
                                                    />
                                                    <div className="flex justify-center items-center shadow px-3 py-2 border rounded-full focus:shadow-outline focus:outline-none w-full text-gray-700 leading-tight appearance-none">
                                                        <span className="font-normal text-black text-base text-opacity-50 leading-tight tracking-tight">
                                                            Choose File
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="mt-2 font-normal text-black text-base text-opacity-50 leading-tight tracking-tight">
                                                    {fileName || "No file chosen"}
                                                </div>
                                            </div>
                                            <div className="font-normal text-black text-sm text-opacity-30 leading-tight tracking-tight">
                                                Below: 5 MB | Types: .txt
                                            </div>
                                            <div className="flex justify-center items-center mt-4" >
                                                <button
                                                    type="submit"
                                                    className="bg-blue-700 hover:bg-[#40A2E3] px-4 py-2 rounded-full focus:shadow-outline focus:outline-none font-bold hover:font-bold text-white hover:scale-110 transition hover:-translate-y-1 duration-300 ease-in-out delay-150"
                                                    onClick={handleActivationSubmit}
                                                >
                                                    Validate
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                : null}
            {isdelete ?
                <ReactDialogBox
                    closeBox={handleClose}
                    modalWidth={localControlsConstant.Model.modalWidth}
                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                    headerTextColor={localControlsConstant.Model.bodybg}
                    headerHeight={localControlsConstant.Model.headerheight}
                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                    headerText={localControlsConstant.Model.modelConfirm}
                >
                    <div>
                        <div class='flex items-center pl-7 max-lg:pl-2 h-16 max-lg:h-8'>
                            <h1>{Users_Toaster.Are_You_Sure_You_Want_To_Delete}<span className='text-blue-500'>{deleteUserData?.firstname} {deleteUserData?.lastname} </span>?</h1>
                        </div>
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={deleteUserOnClick} >{Users_Labels._YES_BTN}</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={handleClose}>{Users_Labels._CANCEL_BTN}
                            </button>
                        </div>

                    </div>
                </ReactDialogBox>
                : null}
        </AuthCommonLayout>
    )
}

export default Users;
