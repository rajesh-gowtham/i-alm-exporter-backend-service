import React, { useEffect, useState } from 'react';
import Select, { components } from "react-select";
import { Users_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { Users_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import { FileTypes } from '../../Constants/UtilJSON';
const AddEditUserForm = (props) => {
    console.log(props);
    const org = localStorage.getItem("organization") === 'iGO Solutions';
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    useEffect(() => {
        if (org) {
            if (props?.onReceiveProjectData)
                props?.onReceiveProjectData()
        }
        else {
            if (props.onReceiveClientProjectData)
                props?.onReceiveClientProjectData()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    // {implementation for select dropdown for igo organization}
    const [value, setValue] = useState([]);
    const [projectValue, setProjectValue] = useState([]);
    const transformData = (data) => {
        if (!data) return [];
        return data.map((customer) => ({
            label: customer.customerName,
            options: customer.projects.map((project) => ({
                value: project.projectName,
                label: project.projectName,
                id: project.id,
                projectName: project.projectName,
                customerId: project.customerId,
                customerName: project.customerName,
                parent_id: customer.customerName // For grouping
            }))
        }));
    };
    const options = transformData(props?.projectsData || []);
    // const getParentCheckboxState = (parent_id, options, value) => {
    //     const selectedChildrenCount = value.filter((v) => v.parent_id === parent_id).length;
    //     const totalChildrenCount = options.length;
    //     if (totalChildrenCount === selectedChildrenCount) return "checked";
    //     if (selectedChildrenCount > 0) return "indeterminate";
    //     return "unchecked";
    // };
    const createGroup = (groupName, options) => {
        // const status = getParentCheckboxState(groupName, options, value);
        return {
            label: (
                <div style={{ display: "flex", alignItems: "center" }}>
                    <label style={{ color: 'blue' }}>{groupName}</label>
                </div>
            ),
            options,
        };
    };
    const groupedOptions = options.map((group) =>
        createGroup(group.label, group.options)
    );
    useEffect(() => {
        const autoSelectValues = () => {
            if (props.formData && Array.isArray(props.formData.customers)) {
                const selectedValues = value;
                const projectData = transformData(props?.projectsData || []);
                const flattenedProjects = projectData.flatMap(group => group.options);
                props.formData.customers.forEach(customer => {
                    if (customer.projects && Array.isArray(customer.projects)) {
                        customer.projects.forEach(project => {
                            const matchedProject = flattenedProjects.find(opt => opt.projectName === project.projectName);
                            if (matchedProject) {
                                selectedValues.push(matchedProject);
                            }
                        });
                    }
                });
                setValue(Array.from(new Set(selectedValues.map(JSON.stringify))).map(JSON.parse));
            } else {
                setValue([]);
            }
        };

        autoSelectValues();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.formData.customers, props.projectsData]);
    const handleChange = (selectedOptions) => {
        setValue(selectedOptions || []);
        props.handleOnchangeDropdown(selectedOptions);
    };

    // {implementation for select dropdown for other organization excluded igo}
    const formatOptions = (projects) => {
        return projects?.map(project => ({
            value: project.projectName,
            label: project.projectName,
            id: project.id
        }));
    };

    const getSelectedOptions = (options, selectedProjects) => {
        const selectedNames = selectedProjects.map(project => project.value);
        return options?.filter(option => selectedNames.includes(option.value));
    };
    var customerProjects = props.formData?.projects || [];
    const optionss = formatOptions(props.clientProjectsData)
    const construct = customerProjects?.map(el => ({ value: el.projectName ? el.projectName : el.value, id: el.id, label: el.projectName ? el.projectName : el.value }))
    const selectedOptions = getSelectedOptions(optionss, construct);
    const handleChangeClientProject = (selected) => {
        console.log(selected);
        setProjectValue(selected)
        props.onhandleChangeProjects(selected);
    };
    const customStyles = {
        control: (provided, state) => ({
            ...provided,
            borderColor: state.isFocused ? '#101010' : '#CCCCCC',
            backgroundColor: '#f9fafb',
            boxShadow: state.isFocused ? '0 0 0 1px #101010' : 'none',
            '&:hover': {
                borderColor: '#101010',
            },
            fontSize: '14px',
        }),
        menu: (provided) => ({
            ...provided,
            fontSize: '14px',
        }),
        option: (provided, state) => ({
            ...provided,
            fontSize: '14px',
        }),
    };

    return (
        <form autocomplete="off">
            <section className="bg-white mx-[18rem] p-6">
                <div className="flex flex-wrap -mx-3">
                    <div className="mb-3 px-3 w-1/2">
                        <label for="firstname" className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._FIRSTNAME}</label>
                        <input
                            id="firstname"
                            name="firstname"
                            type="text"
                            value={props.formData.firstname}
                            className={ControlsConstants.Login.input}
                            placeholder={Users_Labels._FIRSTNAME_PLACEHOLDER} onChange={props.handleOnChange} autocomplete="off" autoFocus="on" />
                        {props.errorFlags.firstname &&
                            props.formData.firstname === "" ? (
                            <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                {Users_Toaster.Firstname_Is_Mandatory}
                            </div>
                        ) : null}
                    </div>
                    <div className="mb-3 px-3 w-1/2">
                        <label for="lastname" className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._LASTNAME}</label>
                        <input
                            id="lastname"
                            name="lastname"
                            type="text"
                            value={props.formData.lastname}
                            className={ControlsConstants.Login.input}
                            placeholder={Users_Labels._LASTNAME_PLACEHOLDER} onChange={props.handleOnChange} autocomplete="off" />
                    </div>
                </div>
                <div className="flex flex-wrap -mx-3">
                    <div className="mb-3 px-3 w-1/2">
                        <label for="email" className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._EMAIL}</label>
                        <input
                            id="email"
                            name="email"
                            type="text"
                            className={ControlsConstants.Login.input}
                            placeholder={Users_Labels._EMAIL_PLACEHOLDER} onChange={props.handleOnChange} autocomplete="off" value={props.formData.email} disabled={props.isEditData ? true : false} />
                        {props.errorFlags.email &&
                            props.formData.email === "" ? (
                            <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                {Users_Toaster.Email_Is_Mandatory}
                            </div>
                        ) : null}
                        {props.errorFlags.email &&
                            !emailRegex.test(props.formData.email) && props.formData.email !== "" ? (
                            <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                {Users_Toaster.Email_Is_Not_Valid}
                            </div>
                        ) : null}
                    </div>
                    <div className="mb-3 px-3 w-1/2">
                        <label for="mobileno" className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._MOBILE_NO}</label>
                        <input
                            id="mobileno"
                            name="mobileno"
                            type="tel"
                            value={props.formData.mobileno}
                            className={ControlsConstants.Login.input}
                            placeholder={Users_Labels._MOBILE_NO_PLACEHOLDER} onChange={props.handleOnChange} autocomplete="off" />
                    </div>
                </div>
                <div className="flex flex-wrap -mx-3">
                    {!(props?.formData?.role === 'Admin') &&
                        <div className="mb-3 px-3 w-1/2">
                            <label className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._ROLE}</label>
                            <Select
                                styles={customStyles}
                                placeholder={Users_Labels._ROLE_PLACEHOLDER}
                                className="mb-3"
                                options={props.roleData}
                                onChange={props.handleOnChange}
                                // hideSelectedOptions={false}
                                // closeMenuOnSelect={false}
                                name='role'
                                id='role'
                                components={{
                                    Option: (props) => (
                                        <components.Option {...props}>
                                            <label>{props.label}</label>
                                        </components.Option>
                                    ),
                                }}
                                value={props.roleData.filter(option => option.value === props.formData.role)}
                            />

                            {props.errorFlags.role &&
                                props.formData.role === null ? (
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                    {Users_Toaster.Role_Is_Mandatory}
                                </div>
                            ) : null}
                        </div>}
                    {!(props.isLoginAddUser) && !(props?.formData?.role === 'Admin') && ((localStorage.getItem('organization') === 'iGO Solutions') ?
                        <div className="mb-3 px-3 w-1/2">
                            <label className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._CUSTOMER}</label>
                            <Select
                                styles={customStyles}
                                placeholder={Users_Labels._PROJECT_PLACEHOLDER}
                                className='mb-3'
                                options={groupedOptions}
                                isMulti
                                closeMenuOnSelect={false}
                                onChange={handleChange}

                                hideSelectedOptions={false}
                                components={{
                                    Option: (props) => (
                                        <components.Option {...props}>
                                            <div style={{ display: "flex", alignItems: "center" }}>
                                                <input
                                                    type="checkbox"
                                                    checked={props.isSelected}
                                                    readOnly
                                                    style={{ marginLeft: '20px' }}
                                                />
                                                <label style={{ marginLeft: '8px' }}>{props.label}</label>
                                            </div>
                                        </components.Option>
                                    ),
                                }}
                                value={value}
                            />
                            {(props.errorFlags.customers && value.length === 0) &&
                                (
                                    <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                        {Users_Toaster.Customer_Is_Mandatory}
                                    </div>
                                )}
                        </div>
                        :
                        <div className="mb-3 px-3 w-1/2">
                            <label className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._PROJECT}</label>
                            <Select
                                styles={customStyles}
                                className="mb-3"
                                name='projects'
                                // components={{ DropdownIndicator, IndicatorSeparator: () => null }}
                                components={{
                                    Option: (props) => (
                                        <components.Option {...props}>
                                            <label>{props.label}</label>
                                        </components.Option>
                                    ),
                                }}
                                id='selected_datasource'
                                placeholder={Users_Labels._PROJECT_PLACEHOLDER}
                                options={props?.clientProjectsData?.map(project => ({
                                    value: project.projectName,
                                    label: project.projectName,
                                    id: project.id
                                }))}
                                onChange={handleChangeClientProject}
                                value={selectedOptions}
                                isMulti
                            />
                            {(props.errorFlags.customers && projectValue.length === 0) &&
                                <div className="pt-1 pl-2.5 font-normal text-[#e50000] text-[13px] leading-tight tracking-tight">
                                    {Users_Toaster.Customer_Is_Mandatory}
                                </div>
                            }
                        </div>
                    )}

                </div>
                <div className="flex flex-wrap -mx-3">
                    <div className="mb-3 px-3 w-1/2">
                        <label for="userimage" className="mb-2 font-medium text-gray-900 text-sm">{Users_Labels._PROFILE_IMAGE}</label>
                        <div className="w-full">
                            <div className="flex items-center gap-[15px]">
                                <label className="w-full">
                                    <input type="file" name="userimage" id="userimage" accept={FileTypes._IMAGE}
                                        className="hidden text-sm cursor-pointer" onChange={props.handleOnChange} />
                                    <div
                                        className="flex justify-between items-center gap-2.5 bg-[#f9fafb] focus:bg-orange-100 px-2.5 py-[13px] border border-black border-opacity-30 rounded-lg w-full h-10 placeholder:font-normal text-gray-700 text-text-black placeholder:text-black placeholder:text-sm text-opacity-50 placeholder:text-opacity-30 leading-tight placeholder:leading-snug cursor-pointer appearance-none first-letter focus:outline-none text">
                                        <span className="font-normal text-base text-black text-opacity-50 leading-tight tracking-tight">
                                            {Users_Labels._CHOOSE_FILE}
                                        </span>
                                        <svg xmlns="http: www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
                                            <path fillRule="evenodd" clipRule="evenodd"
                                                d="M11.2929 3.29289C11.6834 2.90237 12.3166 2.90237 12.7071 3.29289L17.7071 8.29289C18.0976 8.68342 18.0976 9.31658 17.7071 9.70711C17.3166 10.0976 16.6834 10.0976 16.2929 9.70711L13 6.41421V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V6.41421L7.70711 9.70711C7.31658 10.0976 6.68342 10.0976 6.29289 9.70711C5.90237 9.31658 5.90237 8.68342 6.29289 8.29289L11.2929 3.29289ZM4 16C4.55228 16 5 16.4477 5 17V19C5 19.2652 5.10536 19.5196 5.29289 19.7071C5.48043 19.8946 5.73478 20 6 20H18C18.2652 20 18.5196 19.8946 18.7071 19.7071C18.8946 19.5196 19 19.2652 19 19V17C19 16.4477 19.4477 16 20 16C20.5523 16 21 16.4477 21 17V19C21 19.7957 20.6839 20.5587 20.1213 21.1213C19.5587 21.6839 18.7957 22 18 22H6C5.20435 22 4.44129 21.6839 3.87868 21.1213C3.31607 20.5587 3 19.7957 3 19V17C3 16.4477 3.44772 16 4 16Z"
                                                fill="black" fill-opacity="0.3" />
                                        </svg>
                                    </div>
                                </label>
                            </div>
                            <div className="mt-2 font-normal text-base text-black text-opacity-30 leading-tight tracking-tight">
                                {props.formData.userimage?.imgname === "" ? (
                                    <span> {Users_Toaster.No_File_Chosen} </span>
                                ) : (
                                    props.formData.userimage?.imgname
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="mt-6 px-3 w-full md:w-1/2">
                        <div className="mt-2">
                            <div className="font-normal text-black text-sm text-opacity-30 leading-tight tracking-tight">
                                {Users_Labels._PREFERRED_IMAGE_RESOLUTION}
                            </div>
                            <div className="font-normal text-black text-sm text-opacity-30 leading-tight tracking-tight">
                                {Users_Labels._PREFERRED_IMAGE_SIZE}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex flex-wrap flex-shrink-0 justify-center items-center space-x-3 border-footer-border p-4 pb-0 border-t rounded-b-md modal-footer">
                    {props.isEditData ?
                        <>
                            <button onClick={props.cancel} type="button" className={ControlsConstants.Buttons.loginbtn} >{Users_Labels._CANCEL_BTN}</button>
                            <button onClick={props.handleOnUpdate} type="button" className={ControlsConstants.Buttons.loginbtn}>{Users_Labels._UPDATE_BTN}</button>
                        </>
                        :
                        <>
                            <button onClick={() => {
                                setValue([])
                                props.resetForm()
                            }} type="button" className={ControlsConstants.Buttons.loginbtn}>{Users_Labels._CLEAR_BTN}</button>
                            <button onClick={props.handleOnSubmit} type="button" className={ControlsConstants.Buttons.loginbtn}>{Users_Labels._SAVE_BTN}</button>
                        </>
                    }

                </div>
            </section>
        </form>
    )
}

export default AddEditUserForm;
