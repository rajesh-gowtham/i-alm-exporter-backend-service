import React, { useEffect, useState } from 'react';
import { ReactDialogBox } from 'react-js-dialog-box';
import Select from 'react-select';
import { ControlsConstants } from "../../Constants/ControlsConstants";
import DataSourceService from '../../Services/DataSourceService';
import { ErrorMessage, SuccessMessage } from "../../CommonUtils/CustomToast";
import { Auth_Common_Toaster, Configuration_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import { Configuration_Labels } from '../../Constants/COMMON_LABELS';
import { isValidValue } from '../../CommonUtils/ComponentUtil';
const dropDownStylesGrey = ControlsConstants.Select.dropDownStyles;
const options = [
  { value: 'ALM', label: 'ALM' },
  // { value: 'ME', label: 'ME' },
  // { value: 'JIRA', label: 'JIRA' },
  { value: 'sharepoint', label: 'sharepoint' },
];
const moduleName = [
  // { label: "Defect", value: 1 },
  { label: "Requirements", value: "Requirements" },
  { label: "Testing", value: "Testing" }

];
function DataSource(props) {
  const [formArray, setFormArray] = useState([1, 2, 3]);
  const [formNo, setFormNo] = useState(formArray[0])
  const [optionsDomains, setoptionsDomains] = useState([])
  const [optionsProjects, setoptionsProjects] = useState([])

  const [btnvalidate, setbtnvalidate] = useState(false)
  const [authenticate, setauthenticate] = useState(false)
  const [spValidated, setSPValidated] = useState(false)
  const [almCookies, setAlmCookies] = useState({})
  const [state, setState] = useState({
    datasourcename: '',
    defectTool: '',
    url: '',
    username: '',
    password: '',
    domainname: '',
    modulename: '',
    projectname: '',
    clientId: '',
    clientSecret: '',
    tenantId: '',
    siteName: '',
    hostName: '',
  })

  useEffect(() => {
    if (props.isEditDataSourceOpen) {
      setState(props.selectedData)
    } else {
      setState({
        datasourcename: '',
        defectTool: '',
        url: '',
        username: '',
        password: '',
        domainname: '',
        modulename: '',
        projectname: '',
        clientId: '',
        clientSecret: '',
        tenantId: '',
        siteName: '',
        hostName: '',
      })
    }
  }, [props.isEditDataSourceOpen])

  const inputHandleDefectToll = async (e, obj) => {
    console.log("e, obj ", e, obj)
    let domainname = state.domainname;
    let modulename = state.modulename;
    let projectname = state.projectname;
    let defectTool = state.defectTool;
    if (obj.name === "defectTool") {
      defectTool = e.value
    }

    if (obj.name === "domainname") {
      try {
        props.openSpinnerRedux()
        domainname = e.label
        const response = await DataSourceService.getAllProject(domainname, almCookies);
        console.log("response ", response)
        const domainData = await response.data;
        props.closeSpinnerRedux()
        const AllProject = domainData.map(item => ({
          value: item,
          label: item
        }))
        setState({
          ...state,
          projectname: "",
        })
        setoptionsProjects(AllProject)
      } catch (error) {
        props.closeSpinnerRedux()
        console.error(error);
        ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
      }

    }
    if (obj.name === "modulename") {
      modulename = e.label
    }
    if (obj.name === "projectname") {
      projectname = e.label
    }
    let json = {
      id: state.id,
      datasourcename: state.datasourcename,
      defectTool: defectTool,
      url: state.url,
      username: state.username,
      password: state.password,
      domainname: domainname,
      modulename: modulename,
      projectname: projectname,
      clientId: state.clientId,
      clientSecret: state.clientSecret,
      tenantId: state.tenantId,
      siteName: state.siteName,
      hostName: state.hostName,
    }
    setState(json)
  }

  const inputHandle = (e) => {
    console.log(e.target.name, e.target.value, state)
    if ((["username", "password", "url"].includes(e.target.name)) && btnvalidate) {
      setbtnvalidate(false);
      setoptionsDomains([]);
      setState({
        ...state,
        domainname: "",
        [e.target.name]: e.target.value
      })
      return
    }
    if (["hostName", "clientId", "clientSecret", "tenantId", "siteName"].includes(e.target.name) && spValidated) {
      setSPValidated(false)
    }
    // else if (["username", "password", "url"].includes(e.target.name)) {

    // }
    setState({
      ...state,
      [e.target.name]: e.target.value
    })
  }
  const next = () => {
    console.log("formNo ", formNo, state)
    if (formNo === 1 && state.defectTool === "sharepoint") {
      setFormArray([1, 2])
    } else {
      setFormArray([1, 2, 3])
    }
    if (formNo === 1 && state.datasourcename && state.defectTool) {
      setFormNo(formNo + 1)
    }
    else if (formNo === 2 && btnvalidate && state.domainname !== '' && state.domainname !== undefined) {
      // else if (formNo === 2 && state.url && state.username && authenticate && state.password && (state.defectTool === "ALM" ? state.domainname : true)) {
      setFormNo(formNo + 1)
    }
    else {
      ErrorMessage(Configuration_Toaster.Please_Fillup_All_Input_Field)
    }
  }

  const Authenticate_Login = () => {
    if (state.url.trim() === "" || state.username.trim() === "" || state.password.trim() === "") {
      ErrorMessage(Configuration_Toaster.Please_Fillup_All_Input_Field)
      return
    }
    const authconfigdata = {
      url: state.url,
      username: state.username,
      password: state.password,
      defectTool: state.defectTool
    };
    console.log(authconfigdata)

    // Authentication For Load Domains
    props.openSpinnerRedux()
    DataSourceService.authentication(authconfigdata)
      .then(
        response => {
          if (state.defectTool === 'ALM') {
            if (response.status === 200 || response.status === 201) {
              // if (response.status === 'OK') {
              props.closeSpinnerRedux()
              SuccessMessage(Configuration_Toaster.Authentication_Success);
              // GET ALL DOMAINS IF Valid Username , Password:
              let resData = response.data;
              resData["almHostedUrl"] = authconfigdata.url;
              setbtnvalidate(true);
              setauthenticate(true);
              setAlmCookies(resData);
              DataSourceService.getDomain(resData).then(
                response => {
                  const optionsDomains = response.data.map(item => ({
                    value: item,
                    label: item
                  }))
                  setoptionsDomains(optionsDomains)
                });

              // IF ALM TRUE  PART END .....

            } else {
              props.closeSpinnerRedux()
              ErrorMessage(response.data);
              return;
            }
          }
          else if (state.defectTool === 'ME') {
            props.closeSpinnerRedux()
            if (response.data === 'Success') {
              SuccessMessage(Configuration_Toaster.Authentication_Success);
            } else {
              ErrorMessage(Configuration_Toaster.Authentication_Failed)
              return;
            }
          }
        }
      ).catch(err => {
        props.closeSpinnerRedux();
        ErrorMessage(err?.response?.data || Auth_Common_Toaster.Something_Went_Wrong)
        console.error(err);
      });
  }
  const authenticateSharePointCreds = async () => {
    try {
      console.log(isValidValue(state.clientId), isValidValue(state.clientSecret), isValidValue(state.tenantId), isValidValue(state.siteName), isValidValue(state.hostName))
      if (!(isValidValue(state.clientId) && isValidValue(state.clientSecret) && isValidValue(state.tenantId) && isValidValue(state.siteName) && isValidValue(state.hostName))) {
        ErrorMessage(Configuration_Toaster.Please_Fillup_All_Input_Field)
        return
      }
      props.openSpinnerRedux()
      const reqPayload = {
        clientId: state.clientId,
        clientSecret: state.clientSecret,
        tenantId: state.tenantId,
        siteName: state.siteName,
        hostName: state.hostName
      }
      const response = await DataSourceService.validateSPCredentials(reqPayload);
      console.log(response);
      if (response.status === 200 || response.status === 201) {
        props.closeSpinnerRedux()
        setSPValidated(true)
        setState({
          ...state,
          modulename: "Storage"
        })
        SuccessMessage(Configuration_Toaster.Sharepoint_Validation_Success)
      }
    } catch (error) {
      props.closeSpinnerRedux()
      console.error(error);
      ErrorMessage("The provided sharePoint credentials are invalid")
    }

  }
  const pre = () => {
    setFormNo(formNo - 1)
    setState({
      ...state,
      domainname: ""
    })
  }
  const finalSubmit = async () => {
    console.log("state ", state)

    const isValidRecord = state.defectTool === "sharepoint" ? (isValidValue(state.clientId) && isValidValue(state.clientSecret) && isValidValue(state.tenantId) && isValidValue(state.siteName) && isValidValue(state.hostName)) : (state.defectTool && state.modulename && state.projectname)
    if (isValidRecord) {
      if (state.defectTool === 'sharepoint' && (!spValidated)) {
        ErrorMessage("Please validate the credentials before submit")
        return
      }
      if (props.isEditDataSourceOpen) {
        try {
          const res = await DataSourceService.updateDataSource(state);
          console.log(res);
          if (res.status === 200 || res.status === 201) {
            SuccessMessage(Configuration_Toaster.Form_Update_Success)
            props.closeDialogPopupBox()
            props.getAllConfigData()
          }
        } catch (error) {
          console.error(error)
          ErrorMessage(error.response.data)
        }

      } else {
        DataSourceService.createNewDataSource(state).then(
          response => {
            if (response.status === 200 || response.status === 201) {
              SuccessMessage(Configuration_Toaster.Form_Submit_Success)
              props.closeDialogPopupBox()
              props.getAllConfigData()
            }

          }).catch((err) => {
            console.error(err)
            ErrorMessage(err.response.data)
          });
      }
      return
    }
    else {
      ErrorMessage(Configuration_Toaster.Please_Fillup_All_Input_Field)
    }
  }
  return (

    <ReactDialogBox
      closeBox={props.closeDialogPopupBox}
      modalWidth='40vw'
      headerBackgroundColor='#fff'
      headerTextColor='black'
      headerHeight='40px'
      closeButtonColor='#000'
      closeButtonSize='20px'
      bodyBackgroundColor='#fffdfc'
      bodyTextColor='black'
      //   bodyHeight='150px'
      headerText={Configuration_Labels.TASK_ELEMENT_TITLE}
    >
      <div>
        <div >
          <div className='flex justify-center items-center'>
            {
              formArray.map((v, i) => <div key={i}><div className={`w-[35px] my-3 text-white rounded-full ${formNo - 1 === i || formNo - 1 === i + 1 || formNo === formArray.length ? 'bg-blue-500' : 'bg-slate-400'} h-[35px] flex justify-center items-center`}>
                {v}
              </div>
                {
                  i !== formArray.length - 1 && <div className={`w-[85px] h-[2px] ${formNo === i + 2 || formNo === formArray.length ? 'bg-blue-500' : 'bg-slate-400'}`}></div>
                }
              </div>)
            }
          </div>
          {
            formNo === 1 && <div className='px-8 pb-6'>
              <div className='flex flex-col mb-2'>
                <label htmlFor="name" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._DATA_SOURCE_NAME}</label>
                <input
                  className={ControlsConstants.TextBox.textBoxDefault}
                  type="text"
                  id='datasourcename'
                  name='datasourcename'
                  placeholder={Configuration_Labels._DATA_SOURCE_NAME_PLACEHOLDER}
                  value={state.datasourcename}
                  onChange={inputHandle}
                  required={true}
                />
              </div>
              <div className='flex flex-col mb-2'>
                <label htmlFor="defectTool" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._DEFECT_TOOL}</label>
                <Select
                  class="block border-grey-light mb-2 p-3 border w-full h-10"
                  styles={dropDownStylesGrey}
                  id='defectTool'
                  type="text"
                  name='defectTool'
                  options={options}
                  placeholder={Configuration_Labels._DEFECT_TOOL_PLACEHOLDER}
                  value={options.find(def => def.value === state.defectTool)}
                  onChange={inputHandleDefectToll}
                  isDisabled={props.isEditDataSourceOpen}
                />
              </div>
              <div className='flex justify-center items-center mt-4'>
                <button onClick={next} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._NEXT_BTN}</button>
              </div>
            </div>
          }

          {
            formNo === 2 ?
              state.defectTool === "sharepoint" ?
                <div className='px-8 pb-6'>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._HOST_NAME}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='hostName'
                      name='hostName'
                      placeholder={Configuration_Labels._HOST_NAME_PLACEHOLDER}
                      value={state.hostName}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._CLIENT_ID}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='clientId'
                      name='clientId'
                      placeholder={Configuration_Labels._CLIENT_ID_PLACEHOLDER}
                      value={state.clientId}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._CLIENT_SECRET}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='clientSecret'
                      name='clientSecret'
                      placeholder={Configuration_Labels._CLIENT_SECRET_PLACEHOLDER}
                      value={state.clientSecret}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._TENANT_ID}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='tenantId'
                      name='tenantId'
                      placeholder={Configuration_Labels._TENANT_ID_PLACEHOLDER}
                      value={state.tenantId}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._SITE_NAME}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='siteName'
                      name='siteName'
                      placeholder={Configuration_Labels._SITE_NAME_PLACEHOLDER}
                      value={state.siteName}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <button
                      className={spValidated ? 'px-1 py-1 text-md rounded-md w-1/3 text-white bg-green-500' : 'px-1 py-1 text-md rounded-md w-1/3 text-white bg-gray-400'}
                      onClick={authenticateSharePointCreds}
                    >
                      {Configuration_Labels._VALIDATE_BTN}
                    </button>
                  </div>
                  <div className='flex justify-center items-center gap-3 mt-4'>
                    <button type='button' onClick={pre} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._PREVIOUS_BTN}</button>
                    {
                      props.isEditDataSourceOpen ?
                        <button type='button' onClick={finalSubmit} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._UPDATE_BTN}</button>
                        :
                        <button type='button' onClick={finalSubmit} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._SUBMIT_BTN}</button>
                    }
                  </div>
                </div>
                :
                <div className='px-8 pb-6'>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="url">{Configuration_Labels._URL}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault} type="text"
                      id='url'
                      name='url'
                      placeholder={Configuration_Labels._URL_PLACEHOLDER}
                      value={state.url}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="username">{Configuration_Labels._USERNAME}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault}
                      id='username'
                      type="text"
                      name='username'
                      placeholder={Configuration_Labels._USERNAME_PLACEHOLDER}
                      value={state.username}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <label class={ControlsConstants.label.labelDefault} htmlFor="password">{Configuration_Labels._PASSWORD}</label>
                    <input
                      className={ControlsConstants.TextBox.textBoxDefault}
                      type="password"
                      name='password'
                      placeholder={Configuration_Labels._PASSWORD_PLACEHOLDER}
                      value={state.password}
                      onChange={inputHandle}
                      required={true}
                    />
                  </div>
                  <div className='flex flex-col mb-2'>
                    <button
                      className={btnvalidate ? 'px-1 py-1 text-md rounded-md w-1/3 text-white bg-green-500' : 'px-1 py-1 text-md rounded-md w-1/3 text-white bg-gray-400'}
                      onClick={Authenticate_Login}
                    >
                      {Configuration_Labels._VALIDATE_BTN}
                    </button>
                  </div>
                  {state.defectTool === "ALM" && authenticate === true ? <div className='flex flex-col mb-2'>
                    <label htmlFor="domainname" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._DOMAIN}</label>
                    <Select
                      styles={dropDownStylesGrey}
                      class="block border-grey-light mb-2 p-3 border w-full h-10"
                      id='domainname'
                      type="text"
                      name='domainname'
                      placeholder={Configuration_Labels._DOMAIN_PLACEHOLDER}
                      options={optionsDomains}
                      value={state.domainname === "" ? null : options.find(opt => opt.value === state.domainname)}
                      // defaultValue={{ label: state.domainname, value: 1 }}
                      onChange={inputHandleDefectToll}
                    />

                  </div>
                    : null}
                  <div className='flex justify-center items-center gap-3 mt-4'>
                    <button onClick={pre} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._PREVIOUS_BTN}</button>
                    <button onClick={next} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._NEXT_BTN}</button>
                  </div>
                </div>
              : null
          }

          {
            formNo === 3 &&
            <div className='px-8 pb-6'>
              <div className='flex flex-col mb-2'>
                <label htmlFor="district" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._DEFECT_TOOL}</label>
                <Select
                  styles={dropDownStylesGrey}
                  class="block border-grey-light mb-2 p-3 border w-full h-10"
                  id='defectTool'
                  type="text"
                  name='defectTool'
                  placeholder={Configuration_Labels._DEFECT_TOOL_PLACEHOLDER}
                  options={options}
                  defaultValue={{ label: state.defectTool, value: 1 }}
                  onChange={inputHandleDefectToll}
                  isDisabled={true}
                />
              </div>

              {state.defectTool === "ALM" ? <div>
                <div className='flex flex-col mb-2'>
                  <label htmlFor="projectname" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._DEFAULT_PROJECT}</label>
                  <Select
                    styles={dropDownStylesGrey}
                    class="block border-grey-light mb-2 p-3 border w-full h-10"
                    type="text"
                    name='projectname'
                    id='projectname'
                    placeholder={Configuration_Labels._DEFAULT_PROJECT_PLACEHOLDER}
                    options={optionsProjects}
                    defaultValue={{ label: state.projectname, value: 1 }}
                    onChange={inputHandleDefectToll}
                    value={state.projectname === "" ? null : optionsProjects.find(opt => opt.value === state.projectname)}
                  />
                </div>
                <div className='flex flex-col mb-2'>
                  <label htmlFor="modulename" class={ControlsConstants.label.labelDefault}>{Configuration_Labels._MODULE_NAME}</label>
                  <Select
                    styles={dropDownStylesGrey}
                    class="block border-grey-light mb-2 p-3 border w-full h-10"
                    type="text"
                    id='modulename'
                    name='modulename'
                    placeholder={Configuration_Labels._MODULE_NAME_PLACEHOLDER}
                    options={moduleName}
                    // defaultValue={{ label: state.modulename, value: 1 }}
                    // defaultValue={moduleName[0]}
                    value={state.modulename === "" ? null : moduleName.find(opt => opt.value === state.modulename)}
                    onChange={inputHandleDefectToll}
                  />
                </div>
              </div> : null}
              <div className='flex justify-center items-center gap-3 mt-4'>
                <button onClick={pre} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._PREVIOUS_BTN}</button>
                <button onClick={finalSubmit} className='bg-blue-500 px-3 py-2 rounded-md w-full text-lg text-white'>{Configuration_Labels._SUBMIT_BTN}</button>
              </div>
            </div>
          }

        </div>
      </div>
    </ReactDialogBox>



  );
}

export default DataSource;