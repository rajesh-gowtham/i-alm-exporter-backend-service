import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS/md';
import React from "react";
import { BsFillPlusCircleFill } from 'react-icons/bs';
import { HiOutlineSearch } from 'react-icons/hi';
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import DataSourceService from '../../Services/DataSourceService';
import AuthCommonLayout from "../CommonLayout/AuthCommonLayout";
import DataSource from "./DataSource";
import { Configuration_Labels } from '../../Constants/COMMON_LABELS';
import { connect } from "react-redux";
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { Auth_Common_Toaster, Configuration_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import { IoTrashOutline } from 'react-icons/io5';
import { DeleteConfirmPOPUP } from '../../CommonUtils/ComponentUtil';
import { FaRegEdit } from 'react-icons/fa';

//SCREEN ID -3000
class Configuration extends React.Component {
  constructor(props) {
    super();
    this.state = {
      CurrentStep: 1,
      adddatasource: false,
      isDeleteOpen: false,
      filterValue: '',
      selectedData: {},
      GridColumn: [
        {
          field: 'datasourcename', flex: 1, sortable: true, suppressMovable: true, headerName: 'DataSource',
          cellRenderer: (params) => {
            return (<div className='flex items-center h-full text-xs'> <span className='mr-2 font-semibold'>{params.value}</span> </div>)
          }
        },
        { field: 'defectTool', flex: 1, sortable: true, suppressMovable: true, headerName: 'Defect Tool', },
        {
          field: 'modulename', flex: 1, sortable: true, suppressMovable: true, headerName: 'Module Name'
        },
        // { field: 'projectname', flex: 1, sortable: true,suppressMovable: true, headerName: 'Project', filter: true },
        { field: 'projectname', flex: 1, sortable: true, suppressMovable: true, headerName: 'Project' },
        {
          headerName: "Action", width: 140, sortable: true, suppressMovable: true,
          cellRendererFramework: (params) => {
            return <div class='flex items-center space-x-4 w-full h-full'>
              <div class='flex items-center space-x-4 w-full h-full'>
                <div className='flex items-center space-x-2 cursor-pointer' >
                  {params.data.defectTool === "ALM" ? <FaRegEdit onClick={() => this.deleteDataSourceOpen(params, "EDIT")} title='Edit' color='blue' /> : <span></span>}
                  <IoTrashOutline onClick={() => this.deleteDataSourceOpen(params)} title='Delete' color='red' />
                </div>
              </div>
            </div>
          }
        },
      ],
      rowData: [],
    }
    this.gridRef = React.createRef();
  }


  componentDidMount = () => {
    //getDataSourcedata
    this.getAllConfigData();
  }
  getAllConfigData = () => {
    this.openSpinnerRedux()
    DataSourceService.getDataSourcedata().then(
      response => {
        this.setState({
          rowData: response.data
        })
        this.closeSpinnerRedux()
      }).catch(err => {
        this.closeSpinnerRedux()
        console.error(err)
        ErrorMessage(Auth_Common_Toaster.Something_Went_Wrong)
      });
  }
  handleBack = () => {
    this.setState({
      CurrentStep: this.state.CurrentStep - 1
    })
  }
  handleNext = () => {
    this.setState({
      CurrentStep: this.state.CurrentStep + 1
    })
  }
  addDatasouce_Click = () => {
    this.setState({
      adddatasource: true
    })
  }

  closeDialogPopupBox = () => {
    this.setState({
      adddatasource: false,
      isDeleteOpen: false,
      isEditDataSourceOpen: false,
    })
  }
  onFilterTextBoxChanged = () => {
    this.setState({
      filterValue: document.getElementById('filter-text-box').value
    })
  };

  onGridReady = () => {
    console.log("onGridReady");
  }
  openSpinnerRedux = () => {
    this.props.toggleSpinnerFlag(true)
  }
  closeSpinnerRedux = () => {
    this.props.toggleSpinnerFlag(false)
  }
  deleteDataSourceOpen = (param, type) => {
    if (type === "EDIT") {
      this.setState({
        selectedData: param.data,
        isEditDataSourceOpen: true
      })
    } else {
      this.setState({
        selectedData: param.data,
        isDeleteOpen: true
      })
    }
  }
  deleteDataSourceOnClick = async () => {
    try {
      const tempSelectedData = this.state.selectedData
      console.log("tempSelectedData ", tempSelectedData)
      this.openSpinnerRedux()
      const response = await DataSourceService.deleteDataSourceByIdAPICALL(tempSelectedData.id);
      const tempResData = await response.data
      console.log(response);
      if (response.status === 200 || response.status === 201) {
        this.closeSpinnerRedux()
        SuccessMessage(Configuration_Toaster.Configuration_Delete_Succes)
        this.setState({
          selectedData: {},
          isDeleteOpen: false,
          rowData: tempResData
        })
      }
    } catch (error) {
      console.error(error);
      this.closeSpinnerRedux()
      ErrorMessage(error?.response?.data)
      this.closeDialogPopupBox()
    }
  }
  render() {

    return (
      <>
        <AuthCommonLayout>
          {/* {this.state.adddatasource ?
            <div>
              <DataSource
                adddatasource={this.state.adddatasource}
                closeDialogPopupBox={this.closeDialogPopupBox}
              />
            </div> : */}
          <div>
            <div className='flex justify-between bg-white mb-1 px-5 pt-2 pb-4 border-b-[1px] rounded-t-md'>
              <div className='flex items-center space-x-5'>
                <h1 className='font-semibold text-center text-lg'>{Configuration_Labels._CONFIGURATION_TITLE}</h1>
                <div class="relative flex items-center border-gray-300 border rounded-md h-8 overflow-hidden">
                  <div class="place-items-center grid w-12 h-full text-search-text">
                    <HiOutlineSearch color='#0000004D' size={24} />
                  </div>
                  <input
                    id="filter-text-box"
                    onInput={this.onFilterTextBoxChanged}
                    class="bg-search-bg pr-2 w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs outline-none peer placeholder-[#0000004D]"
                    type="text"
                    autoComplete='off'
                    placeholder="Search..." />
                </div>
              </div>
              <div>
                <button onClick={this.addDatasouce_Click} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded min-w-[120px] font-medium text-white max-lg:mob-txt-sm focus:ring-0 text-xs uppercase leading-tight focus:outline-none transition duration-150 ease-in-out">
                  <span>
                    <BsFillPlusCircleFill size={16} color="white" />
                  </span>
                  <span>
                    {Configuration_Labels._ADD_CONFIGURATION_TITLE}
                  </span>
                </button>
              </div>
            </div>
            <div id='CustomAgGrid'>
              <CustomAgGrid
                ref={this.gridRef}
                rowData={this.state.rowData}
                columnDefs={this.state.GridColumn}
                onGridReady={this.onGridReady}
                filterValue={this.state.filterValue}
                OnCheckBoxSelection={() => { console.log("onCheckBoxSelection clicked"); }}
              />
            </div>
            {(this.state.adddatasource || this.state.isEditDataSourceOpen) ?
              <div>
                <DataSource
                  adddatasource={this.state.adddatasource}
                  isEditDataSourceOpen={this.state.isEditDataSourceOpen}
                  selectedData={this.state.selectedData}
                  getAllConfigData={this.getAllConfigData}
                  closeDialogPopupBox={this.closeDialogPopupBox}
                  openSpinnerRedux={this.openSpinnerRedux}
                  closeSpinnerRedux={this.closeSpinnerRedux}
                />
              </div>
              : null}
          </div>
          {/* } */}
          {this.state.isDeleteOpen ? (
            <DeleteConfirmPOPUP
              titleName={Configuration_Labels._DELETE_CONFIG}
              deleteDataName={this.state.selectedData?.datasourcename}
              oKBtnOnClick={this.deleteDataSourceOnClick}
              cancelBtnOnClick={this.closeDialogPopupBox}
            />
          )
            : null}
        </AuthCommonLayout>
      </>
    )
  }
}
const mapStateToProps = (state) => ({
  isSpinnerLoading: state.isSpinnerLoading,
});

const mapDispatchToProps = (dispatch) => ({
  toggleSpinnerFlag: (value) =>
    dispatch({ type: "SET_SPINNER_LOADING", payload: value }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Configuration);
