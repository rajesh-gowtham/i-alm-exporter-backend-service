import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FaRegEdit } from "react-icons/fa";
import { HiOutlineSearch } from 'react-icons/hi';
import { IoArrowBack, IoPersonAddOutline, IoTrashOutline } from 'react-icons/io5';
import { ReactDialogBox } from 'react-js-dialog-box';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import ResourceService from '../../Services/ResourceService';
import CustomAgGridResource from '../Aggrid/CustomAgGrid_Resource';
import { BPMN_Editor_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import { Resource_Label } from '../../Constants/COMMON_LABELS';
const Resource = (props) => {
  const gridRef = useRef();
  const [gridApi, setGridApi] = useState(null);
  const [isAddResource, setAddResource] = useState(true)

  const [isDeleteEnable, setIsDeleteEnable] = useState(false)
  const [deleteResourceData, setDeleteResourceData] = useState()
  const [showEditbutton, setShowedit] = useState(false)
  const [filterValue, setFilterValue] = useState('')
  const [resourceDetails, setResourceDetails] = useState({ resourceName: '', displayName: '', type: "SYSTEM" }) //System // human
  const [resourceEditDetails, setResourceEditDetails] = useState({ resourceName: '', displayName: '', type: "SYSTEM" }) //System // human
  // console.log(props);
  const [rowData, setRowData] = useState([])
  const [columnDefs] = useState([
    {
      field: "Selected",
      headerCheckboxSelection: true,
      checkboxSelection: true,
      suppressMovable: true,
      width: 50,
    },
    { headerName: 'Resource Name', field: 'resourceName', suppressMovable: true, sortable: true, flex: 1, resizable: true },
    { headerName: 'Display Name', field: 'displayName', suppressMovable: true, sortable: true, flex: 1, resizable: true },
    {
      headerName: "Action", field: "Action", suppressMovable: true, width: 120,
      cellRendererFramework: (params) =>
        <div class='flex items-center space-x-4 w-full h-full'>
          <button onClick={(e) => editData(e, params.data)}><FaRegEdit color='blue' /></button>
          <button onClick={(e) => deleteUserOpen(params.data)} ><IoTrashOutline color='red' /></button>
        </div>
    }
  ]);
  const getAllusers = async (callFrom) => {
    if (callFrom === "FROM_USEEFFECT") {
      console.log(" resssssss ", props.resourceData);
      const updatedData = props.resourceData.map(el => ({ ...el, Selected: false }))
      setRowData(updatedData);
    } else {
      try {
        const response = await ResourceService.getAllResourceAPIcall();
        const data = await response?.data;
        if (response?.status === 200 || response?.status === 201) {
          const updatedData = data.map(el => ({ ...el, Selected: false }))
          setRowData(updatedData);
        }
      } catch (error) {
        console.error("getAllUsersAPIcall", error)
      }
    }
  }

  useEffect(() => {
    getAllusers("FROM_USEEFFECT");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const openAddResource = () => {
    setAddResource(false)
  }
  const onChangeHandler = (e) => {
    const { name, value } = e.target;
    if (e.target.type === "checkbox") {
      setResourceDetails((prevDetails) => ({ ...prevDetails, type: name }));

    } else {
      setResourceDetails((prevDetails) => ({ ...prevDetails, [name]: value }));
    }
    //setRowData((prevDetails)=>({...prevDetails,resourceDetails}))
  }
  const onClickAddResource = async () => {
    let tempFormData = {
      resourceName: resourceDetails.resourceName,
      displayName: resourceDetails.displayName,
      infoField1: "",
      infoField2: "",
      type: resourceDetails.type
    }

    try {
      if (tempFormData.resourceName.trim() === "" || tempFormData.displayName.trim() === "") {
        ErrorMessage(BPMN_Editor_Toaster.Please_Enter_The_Details)
        return;
      }

      const flagResource = rowData.find(el => el.resourceName === tempFormData.resourceName.trim())
      if (flagResource) {

        ErrorMessage(BPMN_Editor_Toaster.The_Entered_Resource_Name_Is_Already_Exists)
        return
      }
      const response = await ResourceService.createNewResourceAPIcall(tempFormData);
      if (response.status === 200 || response.status === 201) {
        setAddResource(true)
        setResourceDetails({ resourceName: '', displayName: '', type: "SYSTEM" })
        setShowedit(false)
        getAllusers();
        props.getAllusers();
        // resetForm();
        SuccessMessage(BPMN_Editor_Toaster.Resource_Added_Successfully)
      }
    } catch (error) {
      console.error("createNewUserAPIcall", error,);
      ErrorMessage(`${error?.response.data}`)
      return;
    }
  }
  const onClickPrev = () => {
    setAddResource(true)
    setResourceDetails({ resourceName: '', displayName: '', type: "SYSTEM" })
    setShowedit(false)

  }

  // const OnchangeRowData = (e) => {
  //   const checked = e.node.selected;
  //   e.data.Selected = checked
  //   // const { name, value } = e.target;
  //   // e.node.setSelected(e.node.data.Selected);
  //   // const checked =e.node.data.Selected;
  //   // e.
  // }
  const selectedData = async () => {
    if (gridApi) {
      const selectedNodes = gridApi.getSelectedNodes();
      const selectedData = selectedNodes.map(node => node.data);
      await props.handleResourcePopup(selectedData)
      // await props.onClickAddResource()

    }
  }

  const onGridReady = (params) => {
    setGridApi(params.api);

  };
  const deleteUserOnClick = async () => {
    try {
      const response = await ResourceService.deleteResourceAPIcall(Number(deleteResourceData.id));
      if (response?.status === 200 || response?.status === 201 || response?.status === 204) {
        getAllusers();
        props.OnDeleteResource(deleteResourceData)
        setIsDeleteEnable(false);
        setDeleteResourceData({});
        // props.deleteResourceForActivity(deletedData)
        // console.log(props.selectedResources);
        // const removeRes = props.selectedResources.filter(el => !((el === deleteData.displayName) || el?.resourceId === deleteData.resourceId));
        // if (removeRes && removeRes.length > 0) {
        //   let result;
        //   if (removeRes[0].resourceId) {
        //     result = removeRes.map(value => value);
        //   } else {
        //     result = removeRes.map(value => ({ displayName: value }));
        //     console.log(result);
        //   }
        //   // await props.handleResourcePopup(result)
        // }
        // await props.onClickAddResource()
      }
      // props.deleteResourceForActivity(deleteResourceData)
      setIsDeleteEnable(false);

    } catch (error) {
      console.error("getAllUsersAPIcall", error)
    }
  };
  const deleteUserOpen = async (deleteData) => {
    setIsDeleteEnable(true);
    setDeleteResourceData(deleteData);
  }

  const editData = (e, data) => {
    setShowedit(true)
    setAddResource(false)
    setResourceDetails({ resourceName: data.resourceName, displayName: data.displayName, id: data.id, type: data.type })
    setResourceEditDetails({ resourceName: data.resourceName, displayName: data.displayName, id: data.id, type: data.type })
  }
  const onEditresource = async () => {

    let tempFormData = {
      id: resourceDetails.id,
      resourceName: resourceDetails.resourceName,
      displayName: resourceDetails.displayName,
      infoField1: "",
      infoField2: "",
      type: resourceDetails.type
    }
    console.log(tempFormData, resourceEditDetails)
    try {
      if (tempFormData.resourceName.trim() === "" || tempFormData.displayName.trim() === "") {
        ErrorMessage(BPMN_Editor_Toaster.Please_Enter_The_Details)
        return;
      }
      if (tempFormData.displayName === resourceEditDetails.displayName && tempFormData.type === resourceEditDetails.type) {
        ErrorMessage("No changes detected")
        return;
      }
      if (tempFormData.displayName !== resourceEditDetails.displayName || tempFormData.type !== resourceEditDetails.type) {
        if (!(window.confirm("Are you sure you want to update this resource? The changes will be applied wherever it is used."))) {
          // console.log("innn");
          return
        }
      }
      const response = await ResourceService.updateResourceAPIcall(tempFormData);
      // console.log(response)
      if (response.status === 200 || response.status === 201) {
        await props.EditResource(response?.data, resourceEditDetails.displayName)
        SuccessMessage(BPMN_Editor_Toaster.Resource_Updated_Successfully)
        await getAllusers();
        setAddResource(true)
        setResourceDetails({ resourceName: '', displayName: '', type: "SYSTEM" })
        setShowedit(false)
      }
    } catch (error) {
      console.error(error);
      ErrorMessage(`${error?.response.data}`)
    }

  }
  const onRowDataChanged = params => {
    console.log(params)
    // console.log(params.api.forEachNode)

    params.api.forEachNode((node) => {
      if (!(props.selectedResources[0]?.resourceId === undefined || props.selectedResources[0]?.resourceId === null)) {
        node.setSelected(props.selectedResources.some(selRes => selRes?.resourceId === node.data.id));
      } else {
        node.setSelected(props.selectedResources.some(selRes => selRes === node.data.displayName));
      }
    })
  }

  const onFilterTextBoxChanged = useCallback(() => {
    setFilterValue(document.getElementById('filter-text-box').value);

  }, []);

  return (


    <div>
      <ReactDialogBox
        closeBox={props.closeDialogPopupBox}
        modalWidth="40vw"
        headerBackgroundColor='#fff'
        headerTextColor='black'
        headerHeight='40px'
        closeButtonColor='#000'
        closeButtonSize='20px'
        bodyBackgroundColor='#fffdfc'
        bodyTextColor='black'
        // bodyHeight='50vh'
        headerText={isAddResource ? Resource_Label._RESOURCE_LIST_TITLE : Resource_Label._ENTER_RESOURCE_NAME}
      >
        {isAddResource ?
          <div className='flex lg:flex-row flex-col gap-3 overflow-y-auto'>

            {/* Ag Grid */}
            <div className="px-4 w-full">
              <div className='flex items-center pt-2 pl-3'>
                <div class="relative flex items-center border-gray-300 border rounded-md h-8 overflow-hidden">
                  <div class="place-items-center grid w-12 h-full text-search-text">
                    <HiOutlineSearch color='#0000004D' size={24} />
                  </div>
                  <input
                    id="filter-text-box"
                    onInput={onFilterTextBoxChanged}
                    class="bg-search-bg pr-2 w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs outline-none peer placeholder-[#0000004D]"
                    type="text"
                    autoFocus={true}
                    autoComplete='off'
                    placeholder="Search..." />
                </div>
              </div>
              
              <CustomAgGridResource
                rowData={rowData}
                columnDefs={columnDefs}
                onGridReady={onGridReady}
                filterValue={filterValue}
                ref={gridRef}
                onRowDataChanged={onRowDataChanged}
              // rowSelected={OnCheckBoxSelection}
              />
              {/* </div> */}
              <div className='flex justify-end space-x-2 pr-1'>
                <button className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:ring-0 min-w-[80px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none" onClick={openAddResource}>
                  <span>
                    <IoPersonAddOutline size={14} color="white" />
                  </span>
                  <span>
                    {Resource_Label._ADD_RESOURCE_BTN}
                  </span>
                </button>
                <button onClick={selectedData} className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:ring-0 min-w-[50px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none" >
                  {/* <span>
                    <IoPersonAddOutline size={16} color="white" />
                  </span> */}
                  <span>
                    {Resource_Label._OK_BTN}
                  </span>
                </button>
              </div>
            </div>
          </div> : <div className='flex flex-col justify-center items-center h-full overflow-y-auto'>
            {/* Input fields */}
            <div className="flex flex-col justify-center items-center p-4 w-full">
              <div className="flex flex-col w-full max-w-md">

                <div className='flex items-center'>
                  <div class="mr-8 mb-2">
                    <input
                      class="border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700 focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2 dark:ring-offset-gray-800 w-4 h-4 text-blue-600"
                      type="checkbox"
                      id="SYSTEM"
                      name="SYSTEM"
                      onChange={onChangeHandler}
                      checked={resourceDetails.type === "SYSTEM"}
                    />
                    <label for="SYSTEM" class="ml-2 font-medium text-gray-900 text-sm">Automated Machine</label>
                  </div>
                  <div class="mb-2">
                    <input
                      class="border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700 focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2 dark:ring-offset-gray-800 w-4 h-4 text-blue-600"
                      type="checkbox"
                      id="HUMAN"
                      name="HUMAN"
                      onChange={onChangeHandler}
                      checked={resourceDetails.type === "HUMAN"}
                    />
                    <label for="HUMAN" class="ml-2 font-medium text-gray-900 text-sm">Full-Time Equivalent</label>
                  </div>
                </div> </div>
              <div className="flex flex-col w-full max-w-md">
                <label htmlFor="resourceName" className="mb-1 text-sm">{Resource_Label._RESOURCE_NAME}</label>
                <input
                  className="bg-gray-200 p-2 rounded w-full"
                  type="text"
                  name="resourceName"
                  id="resourceName"
                  autoComplete='off'
                  placeholder={Resource_Label._RESOURCE_NAME_PLACEHOLDER}
                  value={resourceDetails?.resourceName}
                  onChange={onChangeHandler}
                  disabled={showEditbutton}
                />
              </div>
              <div className="flex flex-col w-full max-w-md">
                <label htmlFor="displayName" className="mb-1 text-sm">{Resource_Label._DISPLAY_NAME}</label>
                <input
                  className="bg-gray-200 p-2 rounded w-full"
                  type="text"
                  id="displayName"
                  name="displayName"
                  autoComplete='off'
                  placeholder={Resource_Label._RESOURCE_NAME_PLACEHOLDER}
                  value={resourceDetails?.displayName}
                  onChange={onChangeHandler}
                />
              </div>
            </div>
            <div className='flex justify-end space-x-2 pr-1'>
              <button className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:ring-0 min-w-[80px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none" onClick={onClickPrev}>
                <span>
                  <IoArrowBack size={14} color="white" />
                </span>
                <span>
                  {Resource_Label._PREV_BTN}
                </span>
              </button>
              <button className="flex items-center space-x-2 bg-blue-400 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2 rounded focus:ring-0 min-w-[80px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none" onClick={showEditbutton ? onEditresource : onClickAddResource}>
                <span>
                  <IoPersonAddOutline size={16} color="white" />
                </span>
                <span>
                  {showEditbutton ? Resource_Label.EDIT_RESOURCE : Resource_Label.ADD_RESOURCE}
                </span>
              </button>
            </div>
          </div>
        }

      </ReactDialogBox>
      {isDeleteEnable ?
        <div className="top-0 right-0 bottom-0 left-0 z-[1100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
          <div className="flex justify-center items-center w-full h-full">
            <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md w-[25vw] h-[100px] font-sans text-gray-900">
              <h1>{Resource_Label._ARE_YOU_SURE_WANT_TO_DELETE}</h1>
              <div class="flex justify-center space-x-2">
                <button
                  class="px-2 py-1 border border-black border-opacity-30 rounded-md w-20 text-blue-600"
                  onClick={() => setIsDeleteEnable(false)}
                >
                  {Resource_Label._CANCEL_BTN}
                </button>
                <button
                  class="bg-blue-500 px-2 py-1 rounded-md w-20 text-white"
                  onClick={deleteUserOnClick}
                >
                  {Resource_Label._OK_BTN}
                </button>

              </div>
            </div>
          </div>
        </div>
        : null}
    </div>
  )
}

export default Resource