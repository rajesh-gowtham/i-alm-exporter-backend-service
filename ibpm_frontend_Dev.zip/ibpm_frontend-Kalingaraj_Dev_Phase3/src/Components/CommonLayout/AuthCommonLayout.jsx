import React, { useState } from "react";
import Header from "../../Header/Header";
import SideBar from "../Sidebar/Sidebar";

//SCREEN ID -3053
function AuthCommonLayout(props) {
    const [toggle, setToggle] = useState(true);
    return (
        <div className="h-screen w-full flex antialiased text-gray-200 bg-white overflow-hidden">
            <div className="flex-1 flex flex-col">
                <main className='flex-grow flex flex-row min-h-0'>
                    <section className="flex flex-col flex-none transition-all duration-300 ease-in-out">
                        <div className="contacts flex-1  max-h-[100vh] z-[100]">
                            <SideBar
                                toggle={toggle} setToggle={setToggle}
                                getIsUnSavedXMLExist={props?.getIsUnSavedXMLExist}
                                isEditorScreenActive={props?.isEditorScreenActive}
                                onDiagramNavOnclick={props?.onDiagramNavOnclick}
                            />
                        </div>
                    </section>
                    <section className="flex flex-col flex-auto">
                        <div className="">
                            <Header
                                isMapLocked={props.isMapLocked}
                                setToggle={setToggle}
                                toggle={toggle}
                                setTemplateBgColor={props?.setTemplateBgColor}
                                editAutoNumflag={props.editAutoNumflag}
                                selectedMapData={props.selectedMapData}
                                // handleReArrange={props.handleReArrange}
                                headerPrimaryBtnOnClick={props.headerPrimaryBtnOnClick}
                                // handleReArrangeCancel={props.handleReArrangeCancel}
                                headerSecondaryBtnOnClick={props.headerSecondaryBtnOnClick}
                                onDiagramNavOnclick={props.onDiagramNavOnclick}
                                isEditorScreenActive={props?.isEditorScreenActive}
                                getIsUnSavedXMLExist={props?.getIsUnSavedXMLExist}
                                openCreateEditTemplate={props.openCreateEditTemplate}
                                closeDialogPopupBox={props.closeDialogPopupBox}
                                openApplyTemplate={props.openApplyTemplate}
                                saveLatestXmlOnclick={props.saveLatestXmlOnclick}
                                openIntegrityCheck={props?.openIntegrityCheck}
                            />
                        </div>
                        <div className="flex-1 overlay max-sm:px-4 xoverflow">
                            <div className='bg-white rounded-md max-sm:px-2'>
                                {props.children}
                            </div>
                        </div>
                    </section>
                </main>
            </div>
        </div>
    )
}
export default AuthCommonLayout;
