export const getXmlDiagram = async (type) => {

  const defaultDiagram =
    `<?xml version="1.0" encoding="UTF-8"?>
  <bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
    xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" id="Definitions_0xcv3nk"
    targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler"
    exporterVersion="3.0.0-dev">
    <bpmn:process id="Process_0tz6k3o" isExecutable="true" />
    <bpmndi:BPMNDiagram id="BPMNDiagram_1">
      <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_0tz6k3o" />
    </bpmndi:BPMNDiagram>
  </bpmn:definitions>`
  const defaultVertical = `<?xml version="1.0" encoding="UTF-8"?>
    <bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:bioc="http://bpmn.io/schema/bpmn/biocolor/1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.6.0-nightly"><bpmn:collaboration id="Collaboration_1t8b7mv"><bpmn:participant id="Participant_0k003o3" processRef="Process_1" /></bpmn:collaboration><bpmn:process id="Process_1" isExecutable="false"><bpmn:startEvent id="StartEvent_1"><bpmn:outgoing>SequenceFlow_1bwgly5</bpmn:outgoing></bpmn:startEvent><bpmn:task id="Task_0swze92" default="SequenceFlow_1fdy5ij"><bpmn:incoming>SequenceFlow_1bwgly5</bpmn:incoming><bpmn:outgoing>SequenceFlow_10271bu</bpmn:outgoing><bpmn:outgoing>SequenceFlow_1fdy5ij</bpmn:outgoing></bpmn:task><bpmn:endEvent id="EndEvent_1277452"><bpmn:incoming>SequenceFlow_10271bu</bpmn:incoming></bpmn:endEvent><bpmn:task id="Task_1cp5scl"><bpmn:incoming>SequenceFlow_1fdy5ij</bpmn:incoming><bpmn:outgoing>SequenceFlow_1yangj7</bpmn:outgoing></bpmn:task><bpmn:exclusiveGateway id="ExclusiveGateway_1fof2od"><bpmn:incoming>SequenceFlow_1yangj7</bpmn:incoming></bpmn:exclusiveGateway><bpmn:sequenceFlow id="SequenceFlow_1bwgly5" sourceRef="StartEvent_1" targetRef="Task_0swze92" /><bpmn:sequenceFlow id="SequenceFlow_10271bu" sourceRef="Task_0swze92" targetRef="EndEvent_1277452" /><bpmn:sequenceFlow id="SequenceFlow_1fdy5ij" sourceRef="Task_0swze92" targetRef="Task_1cp5scl" /><bpmn:sequenceFlow id="SequenceFlow_1yangj7" sourceRef="Task_1cp5scl" targetRef="ExclusiveGateway_1fof2od" /></bpmn:process><bpmndi:BPMNDiagram id="BPMNDiagram_1"><bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1t8b7mv"><bpmndi:BPMNShape id="Participant_0k003o3_di" bpmnElement="Participant_0k003o3" isHorizontal="true"><dc:Bounds x="-30" y="23" width="600" height="300" /></bpmndi:BPMNShape><bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1"><dc:Bounds x="70" y="65" width="36" height="36" /><bpmndi:BPMNLabel><dc:Bounds x="88" y="101" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNShape><bpmndi:BPMNShape id="Task_0swze92_di" bpmnElement="Task_0swze92" bioc:stroke="#1E88E5" bioc:fill="#BBDEFB"><dc:Bounds x="182" y="43" width="100" height="80" /></bpmndi:BPMNShape><bpmndi:BPMNShape id="EndEvent_1277452_di" bpmnElement="EndEvent_1277452" bioc:stroke="#1E88E5" bioc:fill="#BBDEFB"><dc:Bounds x="366" y="65" width="36" height="36" /><bpmndi:BPMNLabel><dc:Bounds x="384" y="101" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNShape><bpmndi:BPMNShape id="Task_1cp5scl_di" bpmnElement="Task_1cp5scl" bioc:stroke="#FB8C00" bioc:fill="#FFE0B2"><dc:Bounds x="182" y="223" width="100" height="80" /></bpmndi:BPMNShape><bpmndi:BPMNShape id="ExclusiveGateway_1fof2od_di" bpmnElement="ExclusiveGateway_1fof2od" isMarkerVisible="true"><dc:Bounds x="359" y="238" width="50" height="50" /><bpmndi:BPMNLabel><dc:Bounds x="384" y="288" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNShape><bpmndi:BPMNEdge id="SequenceFlow_1bwgly5_di" bpmnElement="SequenceFlow_1bwgly5"><di:waypoint x="106" y="83" /><di:waypoint x="182" y="83" /><bpmndi:BPMNLabel><dc:Bounds x="144" y="58" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNEdge><bpmndi:BPMNEdge id="SequenceFlow_10271bu_di" bpmnElement="SequenceFlow_10271bu" bioc:stroke="#1E88E5" bioc:fill="#BBDEFB"><di:waypoint x="282" y="83" /><di:waypoint x="366" y="83" /><bpmndi:BPMNLabel><dc:Bounds x="324" y="58" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNEdge><bpmndi:BPMNEdge id="SequenceFlow_1fdy5ij_di" bpmnElement="SequenceFlow_1fdy5ij" bioc:stroke="#FB8C00" bioc:fill="#FFE0B2"><di:waypoint x="232" y="123" /><di:waypoint x="232" y="223" /><bpmndi:BPMNLabel><dc:Bounds x="247" y="173" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNEdge><bpmndi:BPMNEdge id="SequenceFlow_1yangj7_di" bpmnElement="SequenceFlow_1yangj7"><di:waypoint x="282" y="263" /><di:waypoint x="359" y="263" /><bpmndi:BPMNLabel><dc:Bounds x="321" y="238" width="0" height="0" /></bpmndi:BPMNLabel></bpmndi:BPMNEdge></bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>
    `
  const defaultHorizontal = `<?xml version="1.0" encoding="UTF-8"?>
    <bpmn:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:bioc="http://bpmn.io/schema/bpmn/biocolor/1.0" xmlns:color="http://www.omg.org/spec/BPMN/non-normative/color/1.0" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Definitions_1wveu94" targetNamespace="http://bpmn.io/schema/bpmn" exporter="bpmn-js (https://demo.bpmn.io)" exporterVersion="12.0.0">
      <bpmn:collaboration id="Collaboration_1hju2e4">
        <bpmn:participant id="Participant_01gyvd2" name="Pool 1" processRef="Process_0imf96z" />
        <bpmn:participant id="Participant_15e0hpf" name="Pool 2" processRef="Process_18sn08h" />
        <bpmn:participant id="Participant_162f0h0" name="Pool 3" processRef="Process_1u50srv" />
        <bpmn:messageFlow id="Flow_012u9mc" sourceRef="Participant_01gyvd2" targetRef="Participant_15e0hpf" />
        <bpmn:messageFlow id="Flow_051n1m6" sourceRef="Participant_15e0hpf" targetRef="Participant_162f0h0" />
      </bpmn:collaboration>
      <bpmn:process id="Process_0imf96z" isExecutable="false" />
      <bpmn:process id="Process_18sn08h" isExecutable="false" />
      <bpmn:process id="Process_1u50srv" isExecutable="false" />
      <bpmndi:BPMNDiagram id="BPMNDiagram_1">
        <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1hju2e4">
          <bpmndi:BPMNShape id="Participant_01gyvd2_di" bpmnElement="Participant_01gyvd2" isHorizontal="true" bioc:stroke="#5b176d" bioc:fill="#e1bee7" color:background-color="#e1bee7" color:border-color="#5b176d">
            <dc:Bounds x="166" y="80" width="624" height="140" />
            <bpmndi:BPMNLabel />
          </bpmndi:BPMNShape>
          <bpmndi:BPMNShape id="BPMNShape_0i9ucxk" bpmnElement="Participant_15e0hpf" isHorizontal="true" bioc:stroke="#5b176d" bioc:fill="#e1bee7" color:background-color="#e1bee7" color:border-color="#5b176d">
            <dc:Bounds x="166" y="292" width="624" height="140" />
            <bpmndi:BPMNLabel />
          </bpmndi:BPMNShape>
          <bpmndi:BPMNShape id="BPMNShape_14gw5k7" bpmnElement="Participant_162f0h0" isHorizontal="true" bioc:stroke="#5b176d" bioc:fill="#e1bee7" color:background-color="#e1bee7" color:border-color="#5b176d">
            <dc:Bounds x="160" y="514" width="624" height="140" />
            <bpmndi:BPMNLabel />
          </bpmndi:BPMNShape>
          <bpmndi:BPMNEdge id="Flow_012u9mc_di" bpmnElement="Flow_012u9mc" bioc:stroke="#6b3c00" color:border-color="#6b3c00">
            <di:waypoint x="790" y="140" />
            <di:waypoint x="910" y="140" />
            <di:waypoint x="910" y="382" />
            <di:waypoint x="790" y="382" />
          </bpmndi:BPMNEdge>
          <bpmndi:BPMNEdge id="Flow_051n1m6_di" bpmnElement="Flow_051n1m6" bioc:stroke="#6b3c00" color:border-color="#6b3c00">
            <di:waypoint x="790" y="402" />
            <di:waypoint x="910" y="402" />
            <di:waypoint x="910" y="634" />
            <di:waypoint x="784" y="634" />
          </bpmndi:BPMNEdge>
        </bpmndi:BPMNPlane>
      </bpmndi:BPMNDiagram>
    </bpmn:definitions>
    `

  switch (type) {
    case "default":
      return defaultDiagram

    case "horizontal":
      return defaultHorizontal

    case "vertical":
      return defaultVertical

    default:
      return defaultDiagram

  }

}
