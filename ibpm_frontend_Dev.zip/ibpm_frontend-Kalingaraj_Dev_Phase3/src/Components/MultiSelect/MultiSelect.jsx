import React, { useEffect, useState } from 'react';
import Select from "react-select";
const MultiSelect = (props) => {
    const [selectedOptions, setSelectedOptions] = useState([]);

    const handleChange = (selected) => {
        setSelectedOptions(selected);
        props.onChange(selected)
    }
    useEffect(() => {
        if (props.defaultValue) {
            const defaultValues = props.options.filter(option =>
                props.defaultValue.includes(option.label)
            );
            setSelectedOptions(defaultValues);
        }
    }, [props.defaultValue, props.options]);

    return (
        <Select
            isMulti
            value={selectedOptions}
            onChange={handleChange}
            options={props.options}
        />
    )
}



export default MultiSelect