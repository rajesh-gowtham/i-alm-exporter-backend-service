const defaultXML = `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Definitions_0ex8ya2" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="4.4.0">
  <bpmn:process id="Process_03dsped" isExecutable="true">
    <bpmn:startEvent id="StartEvent_1" name="Want to model BPMN">
      <bpmn:outgoing>Flow_1pi2h9h</bpmn:outgoing>
    </bpmn:startEvent>
    <bpmn:task id="Activity_1jmvmoa" name="Use bpmn-js">
      <bpmn:incoming>Flow_1pi2h9h</bpmn:incoming>
      <bpmn:outgoing>Flow_0nfsrmb</bpmn:outgoing>
    </bpmn:task>
    <bpmn:sequenceFlow id="Flow_1pi2h9h" sourceRef="StartEvent_1" targetRef="Activity_1jmvmoa" />
    <bpmn:endEvent id="Event_1g7g8ak" name="Wow, that was easy!">
      <bpmn:incoming>Flow_0nfsrmb</bpmn:incoming>
    </bpmn:endEvent>
    <bpmn:sequenceFlow id="Flow_0nfsrmb" sourceRef="Activity_1jmvmoa" targetRef="Event_1g7g8ak" />
  </bpmn:process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_03dsped">
      <bpmndi:BPMNEdge id="Flow_1pi2h9h_di" bpmnElement="Flow_1pi2h9h">
        <di:waypoint x="215" y="177" />
        <di:waypoint x="270" y="177" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0nfsrmb_di" bpmnElement="Flow_0nfsrmb">
        <di:waypoint x="370" y="177" />
        <di:waypoint x="432" y="177" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
        <dc:Bounds x="179" y="159" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="162" y="202" width="70" height="27" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1jmvmoa_di" bpmnElement="Activity_1jmvmoa">
        <dc:Bounds x="270" y="137" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_1g7g8ak_di" bpmnElement="Event_1g7g8ak">
        <dc:Bounds x="432" y="159" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="415" y="202" width="71" height="27" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`

export default defaultXML;