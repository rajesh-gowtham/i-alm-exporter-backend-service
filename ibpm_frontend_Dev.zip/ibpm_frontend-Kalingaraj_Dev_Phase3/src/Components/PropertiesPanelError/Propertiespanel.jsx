import React from 'react';




import Modeler from "bpmn-js/lib/Modeler";

import camundaModdlePackage from "camunda-bpmn-moddle/resources/camunda.json";

import {
    BpmnPropertiesPanelModule,
    BpmnPropertiesProviderModule,
    CamundaPlatformPropertiesProviderModule,
    ElementTemplatesPropertiesProviderModule
} from "bpmn-js-properties-panel";

import "bpmn-js-properties-panel/dist/assets/properties-panel.css";

import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";
import "bpmn-js/dist/assets/bpmn-js.css";
import "bpmn-js/dist/assets/diagram-js.css";

import "./properties.css";

import diagram from "./diagram.jsx";



class Propertiespanel extends React.Component {
    async componentDidMount() {
        try {
            const container = document.getElementById("container");

            this.modeler = new Modeler({
                // const modeler = new Modeler({
                container,
                keyboard: {
                    bindTo: document
                },
                additionalModules: [
                    BpmnPropertiesPanelModule,
                    BpmnPropertiesProviderModule,
                    CamundaPlatformPropertiesProviderModule,
                    ElementTemplatesPropertiesProviderModule
                ],
                moddleExtensions: {
                    camunda: camundaModdlePackage
                },
                propertiesPanel: {
                    parent: "#properties-panel-container"
                }
            });
            console.log("modeler ", this.modeler);
            const resData = await this.modeler.importXML(diagram);
            console.log(" resData ", resData);
            const canvas = await this.modeler.get('canvas').zoom('fit-viewport', 'auto');
            console.log("canvas", canvas);
            // canvas.zoom("fit-viewport");

        } catch (error) {
            console.error(error);
        }
    }
    componentWillUnmount() {
        try {
            this.modeler?.destroy();
        } catch (error) {
            console.error(error);
        }
    }
    render() {
        return (
            <div id='parentcontainer'>
                <div
                    id="container"
                    style={{
                        height: "80vh",
                        width: "60vw",
                    }}
                >
                </div>
                {/* <div id="container" ></div> */}
                <div id="properties-panel-container"></div>
            </div >
        )
    }
}

export default Propertiespanel
