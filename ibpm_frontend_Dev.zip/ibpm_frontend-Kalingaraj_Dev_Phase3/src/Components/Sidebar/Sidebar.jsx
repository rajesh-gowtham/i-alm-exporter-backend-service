import React from "react";
import "../../Stylesheets/SideBar.css";
import { NavLink, useNavigate } from "react-router-dom";
import { Menu, MenuItem, ProSidebar, SidebarHeader, SubMenu } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import SideBarItems from './SideBarData';
import ibpmnLogo from "../../Images/main_logo.png";
// import miniLogo from "../../Images/mini_logo.png";
import { PiSquareHalfDuotone } from "react-icons/pi";
import { FaProjectDiagram } from "react-icons/fa";
// import { Image_Base64String } from "../../Constants/UtilJSON";
import IbpmMiniLogo from "../../Images/mini_logo.png";
//SCREEN ID -3069
const Sidebar = (props) => {
  const org = localStorage.getItem('organization') === 'iGO Solutions' ? true : false;

  const navigate = useNavigate();
  const setNavPath = (path) => {
    window.localStorage.setItem("navpath", "path")
  };
  const menuLinkOnClick = async (e, routeItem) => {
    e.preventDefault();
    console.log(routeItem);
    console.log(window.location.pathname);
    const userRole = localStorage.getItem('userRole');
    const isAuthorized = ['Editor', 'Reviewer', 'Admin'].includes(userRole);
    // if (window.location.pathname === "/bpmnEditor" && routeItem.link !== "/bpmnEditor") {
    if (window.location.pathname === "/bpmndiagram" && routeItem.link !== "/bpmndiagram" && props?.isEditorScreenActive) {
      try {
        const isBothXMLSame = await props?.getIsUnSavedXMLExist();
        console.log(isBothXMLSame);
        if (isBothXMLSame) {
          navigate(routeItem.link);
        }
        else if (window.confirm("Changes you made may not be saved.")) {
          navigate(routeItem.link);
        }
        return;
      } catch (error) {
        console.error(error);
      }
    }
    if (window.location.pathname === "/bpmnViewer" && routeItem.link === "/bpmnViewer") {
      window.location.href = "/bpmnViewer"
    }
    if (window.location.pathname === "/bpmndiagram" && routeItem.title === 'Maps' && isAuthorized) {
      props?.onDiagramNavOnclick("BACKTOPARENT")
    }
    navigate(routeItem.link)
  }
  const Role = window.localStorage.getItem("userRole");

  let sidebarItemsBasedonOrg = SideBarItems.MainMenu.SubMenu.map((sub) => {
    return {
      ...sub,
      MenuItem: sub.MenuItem.map((el, index) => {
        if (index === 2) {
          return {
            title: org ? 'Customer' : 'Projects',
            path: org ? '/customer' : '/projects',
            link: org ? '/customer' : '/projects',
            icon: <FaProjectDiagram />
          };
        } else {
          return el;
        }
      })
    };
  });
  if (Role === "Viewer") {
    sidebarItemsBasedonOrg.forEach((sub) => sub.MenuItem = sub.MenuItem.filter(item => item.title !== "Maps"))
    sidebarItemsBasedonOrg = sidebarItemsBasedonOrg.filter((x) => x.title !== "Configuration" && x.title !== "User" && x.title !== "Audit")
  }
  if (Role === "Editor") {
    sidebarItemsBasedonOrg.forEach((sub) => sub.MenuItem = sub.MenuItem.filter(item => item.title !== "Viewer"))
    sidebarItemsBasedonOrg = sidebarItemsBasedonOrg.filter((x) => x.title !== "Configuration" && x.title !== "User")
  }
  if (Role === "Reviewer") {
    sidebarItemsBasedonOrg.forEach((sub) => sub.MenuItem = sub.MenuItem.filter(item => item.title !== "Viewer"))
    console.log("🚀 ~ sidebarItemsBasedonOrg:", sidebarItemsBasedonOrg);
    sidebarItemsBasedonOrg = sidebarItemsBasedonOrg.filter((x) => x.title !== "Configuration" && x.title !== "User" && x.title !== "Audit")
  }

  const onClickMenuIcon = () => {
    props.setToggle(!(props.toggle))
  };

  return (
    <ProSidebar
      collapsed={props.toggle}
      width={180}
      collapsedWidth={60}
      className="shadow-inner border-r" >
      <SidebarHeader className='w-[100%] h-[48px] max-lg:h-8'>
        <div className='flex justify-between items-center h-[100%]'>
          {props.toggle ?
            <div className="flex justify-center items-center w-full">
              <img src={IbpmMiniLogo} alt="IbpmMiniLogo" className="max-lg:w-6 h-10 max-lg:h-8 transition-colors duration-300"></img>
            </div>

            :

            <div className="flex items-center mx-4" role="group">
              <div>
                <img src={ibpmnLogo} alt="ibpmnLogo" className="w-18 max-lg:w-6 h-10 max-lg:h-8 transition-colors duration-300"></img>
              </div>
              <div className="pl-12 duration-300" ><PiSquareHalfDuotone size={24} style={{ cursor: "pointer", color: 'white' }} onClick={onClickMenuIcon} /></div>
            </div>
          }
        </div>
      </SidebarHeader>
      <Menu className="mt-5 pt-10 text-white overflow-y-auto Main-Menu" id='sidebarScroll' >
        {
          sidebarItemsBasedonOrg.map((item) => {
            return (
              <SubMenu key={item.title} className="sub" title={item.title} icon={item.icon} >
                {item.MenuItem.map((menuItem) => {

                  return (
                    <MenuItem title={menuItem.title} key={menuItem.title} icon={menuItem.icon} className='text-white NavSubtxt' onClick={() => setNavPath(menuItem.link)}>{menuItem.title}
                      {/* <Link to={menuItem.link} /> */}
                      <NavLink onClick={(e) => menuLinkOnClick(e, menuItem)} />
                    </MenuItem>
                  )
                })}
              </SubMenu>
            )
          })
        }
      </Menu>
    </ProSidebar>
  )
}
export default Sidebar;