
import { AiOutlineEye } from "react-icons/ai";
import { BsDiagram2, BsPencil } from "react-icons/bs";
import { GoMirror } from "react-icons/go";
import { CgTikcode } from "react-icons/cg";
import { FaProjectDiagram } from "react-icons/fa";
import { IoFileTrayFullOutline, IoPersonAddOutline, IoSettingsOutline } from "react-icons/io5";
const SideBarItems =
{
    Admin: {
        MainMenu: {
            SubMenu: [
                {
                    "title": "BPM",
                    "icon":<CgTikcode size={24} color="white" />,
                    "MenuItem": [

                        {
                            "title": "Viewer",
                            "path": "Security Privileges",
                            "link": "/bpmnViewer",
                            "icon": <AiOutlineEye />
                        },
                        {
                            "title": "Maps",
                            "path": "Security Roles",
                            // "link": "/bpmnEditor",
                            "link": "/bpmndiagram",
                            "icon": <BsPencil />
                        }
                    ]
                },
                {
                    "title": "Configuration",
                    "icon": <IoSettingsOutline size={24} color="white" />,
                    "MenuItem": [
                        {
                            "title": "Configuration",
                            "path": "/Configuration",
                            "link": "/Configuration",
                            "icon": <IoSettingsOutline />
                        }

                    ]
                },
                {
                    "title": "User",
                    "icon": <IoPersonAddOutline size={24} color="white" />,
                    "MenuItem": [
                        {
                            "title": "Users",
                            "path": "/users",
                            "link": "/users",
                            "icon": <IoPersonAddOutline />
                        },
                        {
                            "title": "Roles",
                            "path": "/userRoles",
                            "link": "/userRoles",
                            "icon": <IoPersonAddOutline />
                        },
                        {
                            "title":   'Customer' ,
                            "path":   '/customer' ,
                            "link":   '/customer',
                            "icon": <FaProjectDiagram />
                        }
                    ]
                },
                {
                    "title": "Audit",
                    "icon": <IoFileTrayFullOutline size={24} color="white"/>,
                    "MenuItem":[
                        {
                            "title": "Audit Trail",
                            "path": "/auditTrail",
                            "link": "/auditTrail",
                            "icon": <IoFileTrayFullOutline/>
                        }
                    ]
                },
                {
                    "title": "Compare Maps",
                    "icon": <GoMirror size={24} color="white"/>,
                    "MenuItem":[
                        {
                            "title": "Compare Maps",
                            "path": "/CompareMaps",
                            "link": "/CompareMaps",
                            "icon": <GoMirror/>
                        }
                    ]
                }

            ]
        }
    },
    Viewer: {
        MainMenu: {
            SubMenu: [
                {
                    "title": "BPM",
                    "icon": <BsDiagram2 size={24} color="white" />,
                    "MenuItem": [
                        {
                            "title": "Viewer",
                            "path": "Security Privileges",
                            "link": "/bpmnViewer",
                            "icon": <AiOutlineEye />
                        },
                    ]
                },
                {
                    "title": "Configuration",
                    "icon": <IoSettingsOutline size={24} color="white" />,
                    "MenuItem": [
                        {
                            "title": "Configuration",
                            "path": "/Configuration",
                            "link": "/Configuration",
                            "icon": <IoSettingsOutline />
                        }
                    ]
                },
                {
                    "title": "User",
                    "icon": <IoPersonAddOutline size={24} color="white" />,
                    "MenuItem": [
                        {
                            "title": "Users",
                            "path": "/users",
                            "link": "/users",
                            "icon": <IoPersonAddOutline />
                        }

                    ]
                }
            ]
        }
    }

}
// export default window.localStorage.getItem("RoleName") === "Viewer" ? SideBarItems.Admin : SideBarItems.Viewer;
export default SideBarItems.Admin;




