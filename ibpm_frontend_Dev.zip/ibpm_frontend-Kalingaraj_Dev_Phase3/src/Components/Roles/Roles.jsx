import React, { useCallback, useEffect, useRef, useState } from 'react';
import { HiOutlineSearch } from 'react-icons/hi';
// import { FaRegEdit } from "react-icons/fa";
// import { IoPersonAddOutline, IoTrashOutline } from "react-icons/io5";
import { ReactDialogBox } from 'react-js-dialog-box';
import { useDispatch } from 'react-redux';
import CustomAgGrid from '../../CommonUtils/CustomAgGrid';
import { ErrorMessage, SuccessMessage } from '../../CommonUtils/CustomToast';
import { Roles_Labels } from '../../Constants/COMMON_LABELS';
import { ControlsConstants } from '../../Constants/ControlsConstants';
import { Roles_Toaster } from '../../Constants/TOASTER_MS_TEXT_MSGS';
import RolesService from '../../Services/RolesService';
import AuthCommonLayout from '../CommonLayout/AuthCommonLayout';
import { AddEditRoleForm } from './RoleForm';

const localControlsConstant = ControlsConstants;
const Roles = () => {

    const gridRef = useRef();
    const dispatch = useDispatch();
    const [roleData, setRoleData] = useState([]);
    const [isAddEnable, setIsAddEnable] = useState(false);
    const [isEditEnable, setIsEditEnable] = useState(false);
    const [filterValue, setFilterValue] = useState('')

    const [isdelete, setdelete] = useState(false);
    const [deleteRoleData, setdeleteRoleData] = useState();
    const [formData, setFormData] = useState({
        roleName: "",
        roleDescription: ""
    });
    const userColumnDef = [
        { field: 'roleName', headerName: 'Roles', sortable: true, suppressMovable: true},
        { field: 'limit', headerName: 'Permitted Users', sortable: true, suppressMovable: true,width:150 },
        { field: 'roleDescription', headerName: 'Description', sortable: true, suppressMovable: true, flex: 4, width: 400 },
        // {
        //     headerName: "Action", field: "Action", suppressMovable: true, width: 200,
        //     cellRendererFramework: (params) =>
        //         <div class='flex items-center space-x-4 w-full h-full'>
        //             <button onClick={() => addEditRoleOpen(params, "EDIT")}><FaRegEdit color='blue' /></button>
        //             <button onClick={(e) => deleteRoleOpen(params.data)} ><IoTrashOutline color='red' /></button>
        //         </div>
        // }
    ];
    const getAllRoles = async () => {
        try {
            openSpinnerRedux();
            const response = await RolesService.getAllRolesAPIcall();
            console.log("getAllRolesAPIcall", response);
            const data = await response?.data;
            console.log("getAllRolesAPIcall", data);
            if (response?.status === 200 || response?.status === 201) {
                setRoleData(data);
                closeSpinnerRedux();
            }
        } catch (error) {
            closeSpinnerRedux();
            console.error("getAllRolesAPIcall", error)
        }
    }

    useEffect(() => {
        getAllRoles();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    const handleOnChange = async (e) => {
        const { name, value } = e.target;
        console.log(name, value);
        console.log(name, value);
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));

    }

    // const deleteRoleOpen = (deleteData) => {
    //     setdelete(true);
    //     console.log(deleteData);
    //     setdeleteRoleData(deleteData);
    // }


    // const addEditRoleOpen = (e, type) => {
    //     console.log(e);
    //     if (type === "ADD") {
    //         setIsAddEnable(true);
    //         setIsEditEnable(false);
    //         setFormData({
    //             roleName: "",
    //             roleDescription: ""
    //         })
    //     } else {
    //         setIsAddEnable(false);
    //         setIsEditEnable(true);
    //         setFormData({
    //             roleName: e.data.roleName,
    //             roleDescription: e.data.roleDescription,
    //             id: e.data.id
    //         })
    //     }

    // }
    const closeDialogBox = () => {
        setIsAddEnable(false);
        setIsEditEnable(false);
        setdelete(false);
    }
    const deleteRoleOnClick = async () => {
        console.log(deleteRoleData);
        try {
            openSpinnerRedux();
            const response = await RolesService.deleteRoleAPIcall(deleteRoleData?.id);
            console.log(response);
            if (response?.status === 200 || response?.status === 201 || response?.status === 204) {
                getAllRoles();
                setdelete(false);
                closeSpinnerRedux();
                SuccessMessage(Roles_Toaster.Role_Deleted_Successfully);
            }
        } catch (error) {
            console.error("deleteRoleAPIcall", error)
            closeSpinnerRedux();
            ErrorMessage(error?.response?.data)
        }
        setdeleteRoleData(null);
    };
    const handleAddRoleData = async () => {
        try {
            console.log(formData);
            if (formData.roleName === "" || formData.roleName === undefined) {
                ErrorMessage(Roles_Toaster.Role_Name_Cant_Be_Empty)
                return
            }
            openSpinnerRedux();
            const response = await RolesService.createNewRoleAPICall(formData);
            // const data = await response?.data;
            console.log(response);
            if (response.status === 200 || response.status === 201) {
                console.log("formData", formData);
                // resetForm();
                closeDialogBox()
                getAllRoles()
                SuccessMessage(Roles_Toaster.Role_Created_Successfully)
                closeSpinnerRedux();
            }

        } catch (error) {
            console.error("createNewRoleAPICall", error,);
            ErrorMessage(error?.response.data)
            closeSpinnerRedux();
        }


    }
    const handleUpdateRoleData = async () => {
        try {
            if (formData.roleName === "" || formData.roleName === undefined) {
                ErrorMessage(Roles_Toaster.Role_Name_Cant_Be_Empty)
                return
            }
            console.log(formData);
            openSpinnerRedux();
            const response = await RolesService.updateRoleAPIcall(formData);
            const data = await response?.data;
            console.log("data ", data)
            console.log(response);
            if (response.status === 200 || response.status === 201) {
                console.log("formData", formData);
                // resetForm();
                closeDialogBox()
                getAllRoles()
                closeSpinnerRedux();
                SuccessMessage(Roles_Toaster.Role_Updated_Successfully)
            }
        } catch (error) {
            console.error("createNewRoleAPICall", error,);
            closeSpinnerRedux();
            ErrorMessage(error?.response.data)
        }

    }
    const onFilterTextBoxChanged = useCallback(() => {
        setFilterValue(document.getElementById('filter-text-box').value);
    }, []);

    const onGridReady = () => {
        console.log("onGridReady");
    }

    const openSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: true });
    };
    const closeSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: false });
    };
    return (

        <AuthCommonLayout>
            <div className='flex justify-between bg-white mb-1 px-5 pt-2 pb-4 border-b-[1px] rounded-t-md'>
                <div className='flex items-center space-x-5'>
                    <h1 className='font-semibold text-center text-lg'>{Roles_Labels._ROLES_TITLE}</h1>
                    <div class="relative flex items-center border-gray-300 border rounded-md h-8 overflow-hidden">
                        <div class="place-items-center grid w-12 h-full text-search-text">
                            <HiOutlineSearch color='#0000004D' size={24} />
                        </div>
                        <input
                            id="filter-text-box"
                            onInput={onFilterTextBoxChanged}
                            class="bg-search-bg pr-2 w-full max-sm:w-[100px] h-full placeholder:font-normal text-search-text text-search-text-size placeholder:text-xs outline-none peer placeholder-[#0000004D]"
                            type="text"
                            autoComplete='off'
                            placeholder="Search..." />
                    </div>
                </div>


                {/* <div className='flex justify-end space-x-2 p-2 pr-4'>
                    <button onClick={(e) => { addEditRoleOpen(e, "ADD") }} className="flex items-center space-x-3 bg-blue-700 hover:bg-[#089de3] focus:bg-blue-700 active:bg-blue-800 shadow-md hover:shadow-lg focus:shadow-lg active:shadow-lg px-4 py-2.5 rounded focus:ring-0 min-w-[120px] font-medium text-white text-xs uppercase leading-tight transition duration-150 ease-in-out max-lg:mob-txt-sm focus:outline-none">
                        <span>
                            <IoPersonAddOutline size={16} color="white" />
                        </span>
                        <span>
                            {Roles_Labels._ADD_ROLE_TITLE}
                        </span>
                    </button>
                </div> */}
            </div>

            <div id='CustomAgGrid'>
                <CustomAgGrid
                    ref={gridRef}
                    rowData={roleData}
                    columnDefs={userColumnDef}
                    onGridReady={onGridReady}
                    filterValue={filterValue}
                    OnCheckBoxSelection={() => { console.log("onCheckBoxSelection clicked"); }}
                />
            </div>
            {
                (isAddEnable || isEditEnable) ?
                    <AddEditRoleForm
                        closeDialogBox={closeDialogBox}
                        isAddEnable={isAddEnable}
                        handleOnChange={handleOnChange}
                        formData={formData}
                        handleAddRoleData={handleAddRoleData}
                        handleUpdateRoleData={handleUpdateRoleData}

                    />
                    : null
            }
            {isdelete ?
                <ReactDialogBox
                    closeBox={closeDialogBox}
                    modalWidth={localControlsConstant.Model.modalWidth}
                    headerBackgroundColor={localControlsConstant.Model.headerbg}
                    headerTextColor={localControlsConstant.Model.bodybg}
                    headerHeight={localControlsConstant.Model.headerheight}
                    closeButtonColor={localControlsConstant.Model.closebtncolor}
                    bodyBackgroundColor={localControlsConstant.Model.bodybg}
                    bodyTextColor={localControlsConstant.Model.bodytextcolor}
                    headerText={localControlsConstant.Model.modelConfirm}
                >
                    <div>
                        <div class='flex items-center pl-7 max-lg:pl-2 h-16 max-lg:h-8'>
                            <h1>{Roles_Labels._ARE_YOU_SURE_YOU_WANT_TO_DELETE}<span className='text-blue-500'>{deleteRoleData?.firstname} {deleteRoleData?.lastname} </span>?</h1>
                        </div>
                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                onClick={deleteRoleOnClick}>{Roles_Labels._YES_BTN}</button>
                            <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                onClick={closeDialogBox}>{Roles_Labels._CANCEL_BTN}
                            </button>
                        </div>

                    </div>
                </ReactDialogBox>
                : null}
        </AuthCommonLayout>
    )
}

export default Roles;