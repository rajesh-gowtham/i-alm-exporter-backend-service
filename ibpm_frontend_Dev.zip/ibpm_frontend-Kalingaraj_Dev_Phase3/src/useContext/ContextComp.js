import React, { useState } from 'react';
const MyContext = React.createContext();

const Context = ({ children }) => {
     const [rowData,setRowData]=useState([])
    return <MyContext.Provider value={{rowData,setRowData}}>{children}</MyContext.Provider>;
}
export {Context,MyContext};