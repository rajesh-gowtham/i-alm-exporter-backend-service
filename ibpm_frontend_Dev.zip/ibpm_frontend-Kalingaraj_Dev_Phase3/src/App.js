import React, { Suspense, lazy } from 'react';
import { useSelector } from "react-redux";
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Spinner } from './CommonUtils/ComponentUtil';
import { Toaster } from 'react-hot-toast';
import { privateRouterPaths, publicRouterPaths } from './Constants/UtilJSON';
import PageNotFount404, { PageNotFount401 } from './RouteErrorHandleres.jsx/PageNotFount404';
import { SessionTimeout } from './RouteErrorHandleres.jsx/SessionTimout';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import "bpmn-font/dist/css/bpmn-embedded.css";
import "bpmn-js/dist/assets/diagram-js.css";
import "./Stylesheets/BpmnEditor.css";
import "react-toastify/dist/ReactToastify.css";
import "./Stylesheets/BPMNViwer.css";
import "./Stylesheets/AgGrid.css";
import 'react-js-dialog-box/dist/index.css';

// Lazy loaded components
const BpmnPublishData = lazy(() => import('./Components/BpmnViewer/BpmnPublishData'));
const BpmnViewer = lazy(() => import('./Components/BpmnViewer/BpmnViewer'));
const Configuration = lazy(() => import('./Components/Configuration/Configuration'));
const TestTranslator = lazy(() => import('./Components/GoogleTranstor/TestTranslator'));
const Login = lazy(() => import('./Components/Logins/Login'));
const BpmndiagramGrid = lazy(() => import('./Components/ComundaTool/BpmndiagramGrid'));
const ChangePassword = lazy(() => import('./Components/Logins/ChangePassword'));
const Propertiespanel = lazy(() => import('./Components/PropertiesPanelError/Propertiespanel'));
const Roles = lazy(() => import('./Components/Roles/Roles'));
const Users = lazy(() => import('./Components/Users/Users'));
const Project = lazy(() => import('./Components/Project/Project'));
const Clientproject = lazy(() => import('./Components/ClientProjects/Clientproject'));
const AuditTrail = lazy(() => import('./Components/AuditTrail/AuditTrail'));
const AsIsToBe = lazy(() => import('./Components/AsIsToBe/AsIsToBe'));

const routerWithElements = [
  { path: privateRouterPaths._Bpmndiagram, element: <BpmndiagramGrid /> },
  { path: privateRouterPaths._BPMNViewer, element: <BpmnViewer /> },
  { path: privateRouterPaths._BPMNPublish, element: <BpmnPublishData /> },
  { path: privateRouterPaths._Users, element: <Users /> },
  { path: privateRouterPaths._User_Roles, element: <Roles /> },
  { path: privateRouterPaths._Customer, element: <Project /> },
  { path: privateRouterPaths._Project, element: <Clientproject /> },
  { path: privateRouterPaths._Configuration, element: <Configuration /> },
  { path: privateRouterPaths._Test_Translate, element: <TestTranslator /> },
  { path: privateRouterPaths._Properties_Panel, element: <Propertiespanel /> },
  { path: privateRouterPaths._Audit_Trail, element: <AuditTrail /> },
  { path: privateRouterPaths._As_Is_To_Be, element: <AsIsToBe/> }
];

function App() {
  const isUserLogin = window.localStorage.getItem("userid");
  const isLocStorageAuth = isUserLogin === null || isUserLogin === undefined || isUserLogin === "" ? false : true;

  const isUserAuthenticated = useSelector((state) => state?.isUserAuthenticated);

  console.log("isLocStorageAuth", isLocStorageAuth, "isUserAuthenticated", isUserAuthenticated, (isLocStorageAuth || isUserAuthenticated));
  return (
    <div>
      <BrowserRouter basename={publicRouterPaths._BasePath}>
        <Suspense fallback={<Spinner isCallFrom={"SUSPENSE"} />}>
          <Routes>
            <Route path={publicRouterPaths._Page_Not_Found} element={<PageNotFount404 />} />
            <Route path={publicRouterPaths._InValidPath} element={<Navigate to="/404" />} />
            <Route path={publicRouterPaths._Reset_Password} element={<ChangePassword />} />
            <Route path={publicRouterPaths._Login} element={<Login />} />
            <Route path={publicRouterPaths._BasePath} element={<Login />} />
            {(isLocStorageAuth || isUserAuthenticated) ? (
              routerWithElements.map((routeItem, index) => (
                <Route
                  key={`privateRoute_${index}`}
                  path={routeItem.path}
                  element={routeItem.element}
                />
              ))
            ) : routerWithElements.map((routeItem, index) => (
              <Route
                key={`privateRoute_${index}`}
                path={routeItem.path}
                element={<PageNotFount401 />}
              />
            ))}
          </Routes>
        </Suspense>
        <Spinner />
        <Toaster />
        <SessionTimeout />
      </BrowserRouter>
    </div>
  );
}

export default App;