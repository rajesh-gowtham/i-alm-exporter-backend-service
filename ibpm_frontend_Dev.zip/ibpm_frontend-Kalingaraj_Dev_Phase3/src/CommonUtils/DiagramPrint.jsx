import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from "bpmn-js-properties-panel";
import { isNumber } from "lodash";
import React from 'react';
import { navIcons } from "../CommonUtils/ComponentUtil.jsx";
import CustomBPMNComments from "../CommonUtils/CustomBPMNComments/Index.js";
import CustomBPMNDocuments from "../CommonUtils/CustomBPMNDocumentClip/CustomDocIndex.js";
import CustomBpmnModeler from "../Components/ComundaTool/CustomRenderModules/CustomBpmnModeler.jsx";
import { BPMN_Common_Labels } from "../Constants/COMMON_LABELS.jsx";
import pncLOGO_v1 from "../Images/pncLOGO_v1.png";
import CustomBPMNALMDatasource from "../CommonUtils/CustomBPMN_ALMDatasource/CustomBPMN_ALMIndex.js";
import CustomBPMNProcess from "../CommonUtils/CustomBPMNProcessIndex/CustomBPMNProcessIndex.js";


class ShowDiagramPrint extends React.Component {
  constructor(props) {
    super(props);
    this.state = {}
    this.containerRef = React.createRef();
  }

  async componentDidMount() {
    console.log("componentDidUpdate props ", this.props)
    const { diagramXML } = this.props;
    const container = this.containerRef.current;

    this.bpmnModeler = new CustomBpmnModeler({
      container: container,
      propertiesPanel: {
        parent: "#propview",
        enabled: false
      },
      keyboard: {
        bindTo: null
      },
      additionalModules: [CustomBPMNComments, BpmnPropertiesProviderModule, BpmnPropertiesPanelModule, CustomBPMNDocuments,CustomBPMNALMDatasource,CustomBPMNProcess
        // {,
        //   __init__: ["labelEditingProvider"],
        //   labelEditingProvider: ['value', null],
        // },
        // { moveCanvas: ['value', null] },
        // {
        //   dragging: ["value", { init: function () { } }]
        // }
      ],
      customActions: {}
    });
    this.eventBus = this.bpmnModeler.get("eventBus");
    console.log(this.eventBus);
    this.eventBus.on('import.render.complete', async (event) => {
      const bpmnCanvas = this.bpmnModeler.get('canvas');
      bpmnCanvas.zoom('fit-viewport', 'center');
    });
    if (diagramXML) {
      return this.updateXmlDiagram(diagramXML.diagramXML);
    }

  }



  componentWillUnmount() {
    this.bpmnModeler.destroy();
  }


  async updateXmlDiagram(diagramXML) {
    try {
      console.trace("this.bpmnModeler ", this.bpmnModeler);
      await this.bpmnModeler.importXML(diagramXML);
    } catch (error) {
      console.error(error);
    }
  }


  renderElementsByIconsId = (groupId) => {
    const tempGroupId = isNumber(groupId) ? groupId : parseInt(groupId)
    return navIcons.find(item => item.id === tempGroupId)
  }

  render() {
    console.log(this.props.selectedMapData)
    return (
      <>
        <div
          id="propview"
          style={{
            width: "0%",
            float: "right",
            // maxHeight: "98vh",
            position: "absolute",
            right: '0px',
            zIndex: 20,
            // border: '1px solid #0000004d'
          }}>
        </div>

        <div className="py-2 pr-1">
          <div className={`relative p-2 rounded border-4`}
            style={{
              background: `${this.props.isDefaultTemplateEnable ? `linear-gradient(to bottom, ${this.props.appliedTemplate?.colorCode}, #fff)` : `linear-gradient(to bottom, #fff, #fff)`}` // Adjust as needed
            }}

          >
              <>
                <div class="z-0 relative w-full">
                  <div class="flex justify-between items-center">
                    <div class="flex space-x-4">
                      {/* <div
                        onClick={() => this.props.onDiagramNavOnclick("HOME")}
                        title={BPMN_Common_Labels._HOME_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.homeIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navHomeIcon} />
                        }
                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("UP")}
                        title={BPMN_Common_Labels._UP_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.upIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navUpIcon} />
                        }
                      </div>
                      <div
                        onClick={() => this.props.onDiagramNavOnclick("PREV")}
                        title={BPMN_Common_Labels._PREVIOUS_ICON_TOOLTIP}
                        class="p-1 rounded text-gray-600 hover:text-gray-700 transition-colors duration-300 cursor-pointer"
                      >
                        {this.props.appliedTemplate?.iconSource === Default_Template_Labels._DEFAULT ?
                          this.renderElementsByIconsId(this.props.appliedTemplate?.navHomeIcon)?.previousIcon
                          :
                          <img class="max-w-[28px] max-h-7" src={this.props.appliedTemplate?.navPreviousIcon}></img>
                        }
                      </div> */}
                      <p className="mt-4 text-xs">{this.props.diagramXML.name.includes('-') ? this.props?.diagramXML?.name.substring(1, this.props?.diagramXML.name.length) : this.props?.diagramXML?.name}</p>
                    </div>
                    <div class="flex items-center">
                      <p class="mt-4 pr-4 text-xs">{this.props?.diagramXML.id}</p>
                     {this.props.isDefaultTemplateEnable ? <div class="p-1 w-16">
                        <img src={this.props.isDefaultTemplateEnable ? this.props.appliedTemplate?.companyLogo?.imgcontent : pncLOGO_v1} alt="company_logo" />
                      </div>:null}
                    </div>
                  </div>
                  <p class="top-0 left-1/2 absolute py-2 font-semibold -translate-x-1/2 transform">{this.props.selectedMapData?.diagramName}</p>
                </div>
                <hr class="bg-gray-900 mt-1 border-0 h-px" />
              </>

            <div
              id='viewonly'
              onClick={this.props.CheckElements}
              ref={this.containerRef}
              style={{ height: '78vh', marginTop: "50px", width: "1200px" }}
            >
            </div>

            <>
              <div className="z-50 relative w-full">
                <hr className="bg-gray-900 border-0 h-px" />
                <div className="flex justify-between items-center">
                  <div className="flex space-x-4">
                    <p className="mt-1 text-xs">
                      {BPMN_Common_Labels._AUTHOR_TEMPLATE} : {this.props.selectedMapData?.author}
                    </p>
                  </div>
                  <div className="flex items-center">
                    <p className="mt-1 text-xs">
                      {BPMN_Common_Labels._STATUS_TEMPLATE} :{" "}
                      {this.props?.fromViewer
                        ? this.props.selectedMapData?.status
                        : ["Master", "Archive"].includes(this.props.selectedMapType?.mapLevel)
                          ? this.props.selectedMapType?.mapLevel
                          : this.props.selectedMapData?.diagramXmlIds?.Draft?.status}
                    </p>
                  </div>
                </div>
              </div>

            </>
          </div>

        </div>
      </>
    );
  }
}

export default ShowDiagramPrint

