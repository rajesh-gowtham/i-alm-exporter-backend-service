var $ = require('jquery');
const { isValidValue } = require('../ComponentUtil');

function _interopDefaultLegacy(e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var $__default = /*#__PURE__*/_interopDefaultLegacy($);

function DocumentAttachments(eventBus, overlays, bpmnjs, translate, customActions) {
    // console.log(eventBus, overlays, bpmnjs, translate, customActions);
    function createAttachmentBox(element) {
        
        
        var $overlay = $__default["default"](getOverlayHtml(translate));
        $overlay.click(function (e) {
            console.log(customActions);
            // console.log(customActions);
            const tempBussObj = element.businessObject;
            const tempBussObjAttr = element.businessObject.$attrs;
            customActions.handleElementDblClickByTool(element, "FILE", tempBussObj?.name, tempBussObjAttr);
        });
        let bussObj = element.businessObject;
        let documents = bussObj.get('documentation');
        // console.log("documents ", documents)
        let overlay;
        if (documents.length > 0) {
            overlay = overlays.get({ element: element }).find(overlays => overlays?.type === "comments")
        }
        // console.log("overlay ", overlay)
        let position = { top: 5, right: 40 };
        if (overlay) {
            // let currPosition = overlay.position;
            position.right = 20;
            overlay.position.right = 40;
            // console.log("overlay 1111", overlay)
            overlays._updateOverlay(overlay)
        }
        // console.log("overlays ", overlays)
        // console.log("overlay ", overlay)
        overlays.add(element, 'documents', {
            position: position,
            html: $overlay
        });
    }

    eventBus.on('shape.added', function (event) {
        // console.log("event ", event)
        let element = event.element;
        if (element.labelTarget || !element.businessObject.$instanceOf('bpmn:FlowNode') || !element.id?.includes("Activity")) {
            return;
        }
        defer(function () {
            let bo = element.businessObject;
            let docs = bo.get('documentation');
            const isDocAdded = docs.find((d) => d.textFormat === 'json/file-document');
            // console.log("isDocAdded ", isDocAdded)
            if (isDocAdded && isValidValue(isDocAdded.text)) {
                createAttachmentBox(element);
            }
        });
    });
    this.renderFileDocByElement = function (element) {
        console.log("element ", element)
        let bo = element.businessObject;
        let docs = bo.get('documentation');
        const isDocAdded = docs.find((d) => d.textFormat === 'json/file-document');
        // console.log("isDocAdded ", isDocAdded)
        if (isDocAdded && isValidValue(isDocAdded.text)) {
            createAttachmentBox(element);
        }
        // eventBus.fire('comments.updated', {
        //     comments: comments
        // });
    };
}
DocumentAttachments.$inject = ['eventBus', 'overlays', 'bpmnjs', 'translate', 'customActions'];

function defer(fn) {
    // console.log("defer 999999", fn)
    setTimeout(fn, 0);
}

function getOverlayHtml() {
    return `<div id="document_attachment">
        <svg fill="#26357d" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px" viewBox="0 0 395.45 395.45" xml:space="preserve" stroke="#26357d" transform="matrix(1, 0, 0, 1, 0, 0)rotate(-45)">
            <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
            <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round" stroke="#CCCCCC" strokeWidth="5.5362860000000005"></g>
            <g id="SVGRepo_iconCarrier">
                <g>
                    <g>
                        <path d="M357.744,60.411c-0.01-0.01-0.021-0.021-0.033-0.032c-24.096-24.096-59.338-39.665-89.789-39.666 c-32.213,0-62.475,12.52-85.213,35.255L28.16,210.517C10.004,228.673,0.004,252.832,0,278.551 c0.002,25.71,9.996,49.863,28.146,68.015c0.004,0.005,0.01,0.01,0.014,0.015c18.154,18.149,42.313,28.149,68.029,28.156 c0.018,0,0.037-0.002,0.055,0c25.701-0.012,49.846-10.012,67.988-28.158l137.25-137.243c4.803-4.756,20.479-22.251,20.545-47.657 c0.03-11.833-3.388-29.394-19.849-45.855c-18.477-18.477-37.973-21.26-51.075-20.341c-15.914,1.116-31.23,8.282-43.128,20.18 L96.251,227.384c-7.811,7.812-7.811,20.474,0,28.284c7.811,7.81,20.473,7.811,28.285,0l111.726-111.727 c5.006-5.005,11.437-8.125,17.642-8.562c6.987-0.49,13.715,2.445,19.991,8.724c5.412,5.412,8.15,11.288,8.134,17.467 c-0.025,10.242-7.244,17.907-8.759,19.408L135.945,318.295c-10.588,10.591-24.682,16.429-39.695,16.439 c-0.035-0.002-0.07,0-0.105-0.002c-15.014-0.016-29.111-5.854-39.705-16.443c-0.004-0.004-0.004-0.004-0.008-0.008 C45.836,307.686,40,293.574,40,278.553c0.002-15.031,5.842-29.147,16.445-39.752l154.549-154.55 c15.18-15.179,35.397-23.539,56.928-23.539c19.76,0,45.047,11.493,61.512,27.956c0.007,0.007,0.015,0.015,0.021,0.021 c16.033,16.035,25.994,38.852,25.994,59.549c0,21.53-8.357,41.747-23.539,56.926l-53.988,53.979 c-7.812,7.812-7.813,20.474-0.002,28.284c0,0.001,0,0.001,0.002,0.002c7.81,7.811,20.471,7.812,28.279,0.001l53.992-53.981 c22.735-22.734,35.256-52.997,35.256-85.211C395.449,116.85,381.354,84.02,357.744,60.411z"></path>
                    </g>
                </g>
            </g>
        </svg>
    </div>`
    // <svg height="22px" width="22px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.00 512.00" xml:space="preserve" fill="#000000" stroke="#000000" strokeWidth="0.00512">
    //     <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
    //     <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"></g>
    //     <g id="SVGRepo_iconCarrier">
    //         <path style="fill:#1aa7ff;" d="M353.959,97.959v321.463h-31.347V97.959c0-36.383-29.32-66.038-65.567-66.602 c-0.345-0.01-0.7-0.01-1.045-0.01c-36.728,0-66.612,29.884-66.612,66.612v338.975c0,24.106,19.613,43.719,43.719,43.719 c8.829,0,17.063-2.633,23.939-7.158c11.912-7.816,19.78-21.285,19.78-36.561v-314.42c0-10.961-8.85-19.895-19.78-20.031h-0.24 c-11.045,0-20.031,8.986-20.031,20.031v296.908h-31.347V122.514c0-28.327,23.04-51.378,51.378-51.378h0.24 c28.212,0.125,51.127,23.134,51.127,51.378v314.42c0,33.019-21.431,61.137-51.127,71.158c-7.523,2.529-15.569,3.908-23.939,3.908 c-41.388,0-75.065-33.677-75.065-75.065V97.959C158.041,43.938,201.989,0,256,0c0.345,0,0.7,0,1.045,0.01 C310.575,0.564,353.959,44.283,353.959,97.959z"></path> <g> <path style="fill:#1aa7ff;" d="M308.172,122.514v314.42c0,33.019-21.431,61.137-51.127,71.158v-34.597 c11.912-7.816,19.78-21.285,19.78-36.561v-314.42c0-10.961-8.85-19.895-19.78-20.031V71.137 C285.257,71.262,308.172,94.271,308.172,122.514z"></path> <path style="fill:#1aa7ff;" d="M353.959,97.959v321.463h-31.347V97.959c0-36.383-29.32-66.038-65.567-66.602V0.01 C310.575,0.564,353.959,44.283,353.959,97.959z">
    //         </path>
    //         </g>
    //     </g>
    // </svg>

}

var index = {
    __init__: ['documents'],
    'documents': ['type', DocumentAttachments]
};

module.exports = index;
//# sourceMappingURL=index.js.map
