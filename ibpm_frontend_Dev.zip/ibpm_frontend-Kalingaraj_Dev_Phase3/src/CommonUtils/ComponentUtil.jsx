import { useSelector } from "react-redux";
import { components } from "react-select";
// import { xml2js } from "xml-js";
import { isArray, isEqual, isObject } from "lodash";
import React from "react";
import ReactDOMServer from 'react-dom/server';
import { AiOutlineArrowLeft, AiOutlineArrowUp, AiOutlineHome } from "react-icons/ai";
import { BiCloset, BiHomeCircle, BiLeftArrow, BiUpArrow } from "react-icons/bi";
import { FaChevronLeft, FaChevronUp, FaCircleArrowLeft, FaCircleArrowUp, FaHouseChimneyWindow, FaRegPaste, FaTent } from "react-icons/fa6";
import { FcHome } from "react-icons/fc";
import { FiChevronsLeft, FiChevronsUp, FiHome } from "react-icons/fi";
import { IoCloseCircle, IoCloseCircleOutline, IoCopyOutline } from "react-icons/io5";
import { MdOutlineClose } from "react-icons/md";
import Popup from "reactjs-popup";
import xmljs from 'xml-js';
import { BPMNEditor_Labels } from "../Constants/COMMON_LABELS";
import BPMNService from "../Services/BPMNService";
import { ErrorMessage } from "./CustomToast";

export const DropdownIndicator = (props) => {
    return (
        <components.DropdownIndicator {...props}>
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
            >
                <path d="M12 15L7 10H17L12 15Z" fill="black" />
            </svg>
        </components.DropdownIndicator>
    );
};
export const Spinner = (props) => {
    const storeValue = useSelector((state) => state?.isSpinnerLoading);
    const isVisible = props.isCallFrom === "SUSPENSE" ? true : storeValue;
    return (
        <div>
            {" "}
            {isVisible ? (
                <div className="z-[10000] fixed inset-0 flex justify-center items-center backdrop-blur-md">
                    <div className="flex flex-col justify-center items-center bg-white shadow-lg p-6 rounded-lg">
                        <div className="mb-4 text-gray-600">Please wait, loading...</div>
                        <div className="border-t-4 border-blue-500 border-solid rounded-full w-12 h-12 animate-spin"></div>
                    </div>
                </div>
            ) : null}
        </div>
    );
};

export const ReactSelect = {
    dropDownStylesOrange: {
        control: (base, state) => ({
            ...base,
            // background: "#eeeeee",
            fontSize: "14px",
            borderRadius: "4px",
            border: "1px solid rgba(0, 0, 0, 0.30)",
            "&:hover": { border: "0.5px solid rgba(0, 0, 0, 0.30)" }, // border style on hover
            // default border color
            boxShadow: "none", // no box-shadow
            minHeight: "30px",
            width: "100px",
            height: "30px",
            color: "black",
            // padding: "0 ",
            flexWrap: "nowrap",
            alignItems: "start"
        }),
        menuList: (styles) => ({
            ...styles,
        }),
        option: (provided, state) => ({
            ...provided,
            color: "black",
            height: 30,
            fontSize: "12px",
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: state.data.color,
            fontSize: state.selectProps.myFontSize,
        }),
        menu: (base) => ({
            ...base,
            zIndex: 100,
        }),
        placeholder: (defaultStyles) => ({
            ...defaultStyles,
            fontSize: "12px",
        }),
        valueContainer: (provided, state) => ({
            ...provided,
            height: "30px",
            padding: "0 0 0 4px",
            margin: '0'
        }),
    },
    dropDownStylesOrangeBig: {
        control: (base, state) => ({
            ...base,
            // background: "#eeeeee",
            fontSize: "14px",
            borderRadius: "4px",
            border: "1px solid rgba(0, 0, 0, 0.30)",
            "&:hover": { border: "0.5px solid rgba(0, 0, 0, 0.30)" }, // border style on hover
            // default border color
            boxShadow: "none", // no box-shadow
            minHeight: "30px",
            width: "200px",
            height: "30px",
            color: "black",
            // padding: "0 ",
            flexWrap: "nowrap",
            alignItems: "start"
        }),
        menuList: (styles) => ({
            ...styles,
        }),
        option: (provided, state) => ({
            ...provided,
            color: "black",
            height: 30,
            fontSize: "12px",
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: state.data.color,
            fontSize: state.selectProps.myFontSize,
        }),
        menu: (base) => ({
            ...base,
            zIndex: 100,
        }),
        placeholder: (defaultStyles) => ({
            ...defaultStyles,
            fontSize: "12px",
        }),
        valueContainer: (provided, state) => ({
            ...provided,
            height: "30px",
            padding: "0 0 0 4px",
            margin: '0'
        }),
    },
    dropDownStylesOrangeBigDraft: {
        control: (base, state) => ({
            ...base,
            // background: "#eeeeee",
            fontSize: "14px",
            borderRadius: "4px",
            border: "1px solid rgba(0, 0, 0, 0.30)",
            "&:hover": { border: "0.5px solid rgba(0, 0, 0, 0.30)" }, // border style on hover
            // default border color
            boxShadow: "none", // no box-shadow
            minHeight: "30px",
            width: "auto",
            height: "30px",
            color: "black",
            // padding: "0 ",
            flexWrap: "nowrap",
            alignItems: "start"
        }),
        menuList: (styles) => ({
            ...styles,
        }),
        option: (provided, state) => ({
            ...provided,
            color: "black",
            height: 30,
            fontSize: "12px",
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: state.data.color,
            fontSize: state.selectProps.myFontSize,
        }),
        menu: (base) => ({
            ...base,
            zIndex: 100,
        }),
        placeholder: (defaultStyles) => ({
            ...defaultStyles,
            fontSize: "12px",
        }),
        valueContainer: (provided, state) => ({
            ...provided,
            height: "30px",
            padding: "0 0 0 4px",
            margin: '0'
        }),
    },
    dropDownStylesTransparent: {
        control: (base, state) => ({
            ...base,
            fontSize: "12px",
            borderRadius: "0",
            border: "1px solid rgb(79 70 229)",
            "&:hover": { border: "1px solid rgb(79 70 229)" }, // border style on hover
            // default border color
            boxShadow: "none", // no box-shadow
            minHeight: "5px",
            height: "5px",
            width: "200px",
            color: "black",
        }),
        menuList: (styles) => ({
            ...styles,
        }),
        option: (provided, state) => ({
            ...provided,
            color: "black",
            fontSize: "10px", // Adjust the font size as needed
            minHeight: "10px",
            padding: "1px", // Adjust the padding as needed
            paddingLeft: "10px",
            fontWeight: "normal",
        }),
        indicatorsContainer: (provided, state) => ({
            ...provided,
            // padding:"4px",
            // '&:focus': {
            //     outline: 'none', // Remove the default focus outline
            //     // Add your focused state styles here
            //     padding: '4px', // Add padding when focused
            //     border: '2px solid blue', // Add a border when focused
            //   },
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: state.data.color,
            fontSize: state.selectProps.myFontSize,
        }),
        menu: (base) => ({
            ...base,
            zIndex: 50,
        }),
        placeholder: (defaultStyles) => ({
            ...defaultStyles,
            // color: '#eaf1fa',
            fontSize: "12px",
        }),
        valueContainer: (provided, state) => ({
            ...provided,
            height: "30px",
            padding: "0",
        }),
    },
};

export const validateFileOnChange = async (event, customErrorMessage) => {
    try {
        const file = event.target.files[0];
        console.log(file, event.target?.accept);
        const fileType = file?.type
        const fileType1 = "." + file.name?.split('.')?.pop()
        const sizeInMb = file?.size / (1024 * 1024);
        const acceptedType = event.target?.accept?.split(",");
        console.log(" acceptedType ", acceptedType, " fileType ", fileType);
        const isFileSameType = acceptedType?.includes(fileType);
        const isFileSameType1 = acceptedType?.includes(fileType1);
        console.log(isFileSameType, " file Size ", sizeInMb);
        if (!(isFileSameType || isFileSameType1)) {
            ErrorMessage(customErrorMessage || "File Type Mismatch ! ");
            return false;
        }
        if (sizeInMb > 5) {
            ErrorMessage("Please upload a file smaller than 5 MB",);
            return false;
        }
        return true;
    } catch (error) {
        console.error(error);
        return false;
    }
};

export const convertFileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
        try {
            const reader = new FileReader();
            reader.onload = (e) => {
                const base64Result = e.target.result;
                resolve(base64Result);
            };
            reader.onerror = (error) => {
                reject(error);
            };
            reader.readAsDataURL(file);
        } catch (error) {
            console.error(error);
            reject(error);
        }
    });
};

// export const compareTwoXmlStringSame =  (xmlString1, xmlString2) => {
//     const parsedXML1 = xml2js(xmlString1);
//     const parsedXML2 = xml2js(xmlString2);
//     const isBothXMLSame = JSON.stringify(parsedXML1) === JSON.stringify(parsedXML2);
//     return isBothXMLSame;
// };
export const compareTwoXmlStringSame = (xmlString1, xmlString2) => {
    try {
        // console.log("xmlString1", xmlString1, "xmlString2", xmlString2);
        const normalizeJson = (obj) => {
            if (isArray(obj)) {
                return obj.map(normalizeJson).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
            } else if (isObject(obj)) {
                return Object.keys(obj).sort().reduce((result, key) => {
                    result[key] = normalizeJson(obj[key]);
                    return result;
                }, {});
            } else {
                return obj;
            }
        };

        const xmlToJson = (xmlString) => {
            const json = xmljs.xml2js(xmlString, { compact: true, spaces: 4 });
            return normalizeJson(json);
        };
        const json1 = xmlToJson(xmlString1);
        const json2 = xmlToJson(xmlString2);

        return isEqual(json1, json2);
    } catch (error) {
        console.error(error);
        return false
    }
};
export const getMimeTypeByFileName = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    switch (extension) {
        case 'pdf':
            return 'application/pdf';
        case 'txt':
            return 'text/plain';
        case 'html':
        case 'htm':
            return 'text/html';
        case 'json':
            return 'application/json';
        case 'xml':
            return 'application/xml';
        case 'svg':
            return 'image/svg+xml';
        case 'png':
            return 'image/png';
        case 'jpg':
        case 'jpeg':
            return 'image/jpeg';
        case 'gif':
            return 'image/gif';
        case 'bmp':
            return 'image/bmp';
        case 'ico':
            return 'image/x-icon';
        case 'mp4':
            return 'video/mp4';
        case 'mp3':
            return 'audio/mp3';
        case 'wav':
            return 'audio/wav';
        case 'ogg':
            return 'audio/ogg';
        case 'zip':
            return 'application/zip';
        case 'rar':
            return 'application/x-rar-compressed';
        case 'tar':
            return 'application/x-tar';
        case 'gz':
            return 'application/gzip';
        case 'xls':
            return 'application/vnd.ms-excel';
        case 'xlsx':
            return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        case 'doc':
            return 'application/msword';
        case 'docx':
            return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        case 'ppt':
            return 'application/vnd.ms-powerpoint';
        case 'pptx':
            return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
        default:
            return 'application/octet-stream'; // fallback for unknown types
    }
}
export const convertHtmlIconsToImageString = (IconComponent) => {
    const svgString = ReactDOMServer.renderToStaticMarkup(<IconComponent />);
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svgString);
};
export const navIcons = [
    {
        id: 1,
        homeIcon: <FcHome size={28} />,
        upIcon: (
            <svg
                className="up_icon"
                xmlns="http://www.w3.org/2000/svg"
                width="28"
                height="28"
                viewBox="0 0 48 48"
            >
                <g fill="#F44336">
                    <path d="M46.1 24L33 35V13zM10 20h4v8h-4zm-6 0h4v8H4zm12 0h4v8h-4z" />
                    <path d="M22 20h14v8H22z" />
                </g>
            </svg>
        ),
        previousIcon: (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="28"
                height="28"
                viewBox="0 0 48 48"
            >
                <g fill="#F44336">
                    <path d="m4 24l14-11.7v23.4z" />
                    <path d="M15 20h27v8H15z" />
                </g>
            </svg>
        ),
    },
    {
        id: 2,
        homeIcon: <AiOutlineHome color={'#039BE5'} size={28} />,
        upIcon: <AiOutlineArrowUp color={'#039BE5'} size={28} />,
        previousIcon: <AiOutlineArrowLeft color={'#039BE5'} size={28} />,
    },
    {
        id: 3,
        homeIcon: <BiHomeCircle color={"#FFCA28"} size={28} />,
        upIcon: <BiUpArrow color={"#FFCA28"} size={28} />,
        previousIcon: <BiLeftArrow color={"#FFCA28"} size={28} />,
    },
    {
        id: 4,
        homeIcon: <FiHome color={"#1A237E"} size={28} />,
        upIcon: <FiChevronsUp color={"#1A237E"} size={28} />,
        previousIcon: <FiChevronsLeft color={"#1A237E"} size={28} />,
    },
    {
        id: 5,
        homeIcon: <FaTent color={"#8A2BE2"} size={28} />,
        upIcon: <FaChevronUp color={"#8A2BE2"} size={28} />,
        previousIcon: <FaChevronLeft color={"#8A2BE2"} size={28} />,
    },
    {
        id: 6,
        homeIcon: <FaHouseChimneyWindow color={"#FFA07A"} size={28} />,
        upIcon: <FaCircleArrowUp color={"#FFA07A"} size={28} />,
        previousIcon: <FaCircleArrowLeft color={"#FFA07A"} size={28} />,
    },
];

export const HoverPopup = ({
    content,
    triggerElement,
    position,
    width,
    height,
}) => {
    return (
        <Popup
            trigger={triggerElement}
            position={position}
            on="hover"
            mouseLeaveDelay={0}
            mouseEnterDelay={0}
            contentStyle={{
                padding: "5px 20px",
                // border: "1px solid #45c4dd",
                border: "1px solid rgba(0, 0, 0, 0.1)",
                width: width,
                height: height,
                background: "#fff",
                color: "black",
                fontSize: "12px",
                borderRadius: "4px",
                boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
                zIndex: 100,
            }}
        >
            {content === "" || content === undefined ? <span>No data</span> : content}
        </Popup>
    );
};

export const PopupMenu = ({ position, open, onClose, copySelectOnClick, pasteSelectOnClick, isPasteEnable }) => {
    return (
        <Popup
            open={open}
            onClose={onClose}
            position="top left"
            closeOnDocumentClick
            contentStyle={{ position: 'absolute', top: position.y, left: position.x }}
        >
            <div className="bg-white shadow-md px-2 py-1 border border-black border-opacity-20 rounded">
                <ul>
                    <li onClick={copySelectOnClick} className="flex items-center space-x-2 hover:bg-[#eff2f5] px-2 py-1 rounded text-sm cursor-pointer">
                        <span>
                            <IoCopyOutline size={16} color="#656F7D" />
                        </span>
                        <span>
                            copy <span className="text-xs">(lower levels)</span>
                        </span>
                    </li>
                    {isPasteEnable ?
                        <li onClick={pasteSelectOnClick} className="flex items-center space-x-2 hover:bg-[#eff2f5] px-2 py-1 rounded text-sm cursor-pointer">
                            <span>
                                <FaRegPaste size={16} color="#656F7D" />
                            </span>
                            <span>
                                paste <span className="text-xs">(lower levels)</span>
                            </span>
                        </li>
                        : null}
                </ul>
            </div>
        </Popup>
    );
};


export const createCellStyle = (cell, isHeader = false, isObjectTextColumn = false) => {
    cell.border = {
        top: { style: 'thin', color: { argb: 'FF000000' } },
        left: { style: 'thin', color: { argb: 'FF000000' } },
        bottom: { style: 'thin', color: { argb: 'FF000000' } },
        right: { style: 'thin', color: { argb: 'FF000000' } }
    };
    if (isHeader) {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F81BD' } };
        cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
    } else if (isObjectTextColumn) {
        cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'left' };
    } else {
        cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
    }
};

export const downloadExcel = async (workbook, filename) => {
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

export const dateTime = () => {
    const date = new Date();
    const formattedDate = date.toLocaleDateString('en-GB').replace(/\//g, '_');
    const formattedTime = date.toLocaleTimeString('en-GB').replace(/:/g, '_');
    return { formattedDate, formattedTime };
}
export const isValidValue = (value) => {
    return !(value === null || value === undefined || value === "")
}

export const transformToSingleObject = (data) => {
    const result = {
        type: data.Type
    };
    data.Fields.forEach(item => {
        const key = item.Name;
        const values = item.values;

        // Assign the appropriate value, handling different cases
        if (values.length === 0) {
            result[key] = null; // No values
        } else if (values[0].value !== undefined) {
            result[key] = values[0].value; // Use the 'value' field
        } else {
            result[key] = values[0]; // Use the first element as it is (e.g., an empty object)
        }
    });
    return result;
};

export const buildTreeArrayByFolder = (treeData, testData) => {
    const treeMap = new Map();

    treeData.forEach(tree => {
        treeMap.set(tree.id, {
            ...tree,
            meta: { collapsed: true, label: tree.name },
            children: [],
        });
    });

    testData.forEach(test => {
        const parentId = test["parent-id"];
        const treeObj = {
            ...test,
            meta: { collapsed: true, label: test.name },
            children: [],
        };

        if (treeMap.has(parentId)) {
            // console.log("item", treeObj, treeMap.get(parentId).name);
            treeObj['parent-name'] = treeMap.get(parentId).name;
            treeMap.get(parentId).children.push(treeObj);
        }
    });

    let finalObj = {};
    treeMap.forEach(item => {
        const parentId = item["parent-id"];
        if (parentId === "0" || parentId === null) {
            finalObj = item;
        } else if (treeMap.has(parentId)) {
            // console.log("item", item, treeMap.get(parentId));
            treeMap.get(parentId).children.push(item);
        }
    });

    return finalObj;
}

export const createDynamicReqTreeById = (data) => {
    let mapObj = new Map();
    let sortedData = data.sort((a, b) => a['parent-id'] - b['parent-id']);
    let tempArray = [];
    sortedData.forEach((item, ind) => {
        item = {
            ...item,
            meta: { collapsed: true, label: item.name },
            children: [],
        }
        if (ind === 0) {
            tempArray.push(item);
        }
        const isParentPresent = mapObj.has(item['parent-id']);
        if (isParentPresent) {
            let parentObj = mapObj.get(item['parent-id']);
            parentObj = parentObj.concat(item);
            mapObj.set(item['parent-id'], parentObj);
        } else {
            mapObj.set(item['parent-id'], [item]);
        }
    });

    const recursiveFunc = (dataArr) => {
        return dataArr.map((obj) => {
            const findObj = mapObj.get(obj['id']);
            if (findObj) {
                const final = recursiveFunc([...findObj]);
                obj.children = final;
            }
            return obj;
        });
    };
    const resulArray = recursiveFunc([...tempArray]);
    return resulArray;
};

export const getRequirementTreeArray = async (resData, isFromEditor) => {
    let totalRecords = {};
    resData.forEach((item) => {
        const itemKey = Object.keys(item).at(0);
        totalRecords[itemKey] = item[itemKey].entities;
    })
    const requirementsObjArr = totalRecords.requirements?.map(test => {
        return transformToSingleObject(test);
    });
    console.log(" requirementsObjArr ", requirementsObjArr);
    const treeArray = createDynamicReqTreeById(requirementsObjArr);
    return isFromEditor ? { requirementsObjArr, treeArray } : treeArray;
}

export const getTestCaseTreeArray = async (resData, isFromEditor) => {
    let totalRecords = {};
    resData.forEach((item) => {
        const itemKey = Object.keys(item).at(0);
        totalRecords[itemKey] = item[itemKey].entities;
    })
    const designStepsObjArr = totalRecords.DesignSteps.map(step => transformToSingleObject(step))
    const testCasesDesStepsObjArr = totalRecords.TestCase.map(test => {
        let obj = transformToSingleObject(test);
        obj["designSteps"] = designStepsObjArr.filter(step => step["parent-id"] === obj.id);
        return obj;
    });
    const folderArr = totalRecords.TestFolders.map(folder => transformToSingleObject(folder))
    const treeArray = buildTreeArrayByFolder(folderArr, testCasesDesStepsObjArr);
    return isFromEditor ? { testCasesDesStepsObjArr, treeArray } : [treeArray];
}
export const getAllLowerTestFoldersById = (arr, parentIds, selectedFoldersArr) => {
    for (let i = 0; i < arr.length; i++) {
        if (parentIds.includes(arr[i].id)) {
            // return arr[i];
            selectedFoldersArr.push(arr[i]);
        } else if (arr[i].children.length === 0) {
            continue;
        } else {
            const isObjFinded = getAllLowerTestFoldersById(arr[i].children, parentIds, selectedFoldersArr);
            if (isObjFinded) {
                return isObjFinded;
            }
        }
    }
    return "";
}

export const getAllChildTestsByFolder = async (arr, selTestAndStepsArray) => {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i].type === "test" || arr[i].type === "requirement") {            
            selTestAndStepsArray.add(arr[i]);
        }
        if (arr[i].children.length === 0) {
            continue;
        }
        await getAllChildTestsByFolder(arr[i].children, selTestAndStepsArray);
    }
    return selTestAndStepsArray;
}
export const getALMConnectedTests = async (almConnectId) => {
    try {
        // this.openSpinnerRedux()
        const response = await BPMNService.almConnectTestsByIdAPICALL(almConnectId)
        console.log(response);
        const data = await response.data;
        let treeArray;
        const folder = JSON.parse(data.testIds)
        let flatTestReqArray = [];
        if (data.almDataType === "Testing") {
            const testingResponse = await getTestCaseTreeArray(data.almData, true);
            flatTestReqArray = testingResponse.testCasesDesStepsObjArr;
            treeArray = [testingResponse.treeArray];
        } else {
            const reqResponse = await getRequirementTreeArray(data.almData, true);
            flatTestReqArray = reqResponse.requirementsObjArr;
            treeArray = reqResponse.treeArray;
        }

        let finalResultArray=[];
        console.log(" flatTestReqArray ",flatTestReqArray);
        
        if (data.almDataType === "Testing" && folder.type === "test") {
            // console.log(" if   " ,selectedFoldersArr);
            finalResultArray = [...flatTestReqArray].filter(test => folder.id.includes( test.id) );
        }else{
            console.log(" treeArray ", treeArray);
            console.log(" flatTestReqArray ", flatTestReqArray);
            let selectedFoldersArr = [];
            getAllLowerTestFoldersById(treeArray, folder.id, selectedFoldersArr)
            console.log("selectedFoldersArr", selectedFoldersArr);
            
            let selTestAndStepsArray = new Set();
            console.log(" else   " ,selectedFoldersArr);
            await getAllChildTestsByFolder(selectedFoldersArr, selTestAndStepsArray)
            console.log(selTestAndStepsArray);
            const mappedChildIds = Array.from(selTestAndStepsArray).map(item => item.id);
            console.log("  mappedChildIds = ", mappedChildIds,flatTestReqArray);
             finalResultArray = flatTestReqArray.filter(test => mappedChildIds.includes(test.id))
        }

        console.log("finalResultArray",finalResultArray);
        
        // this.closeSpinnerRedux()
        return finalResultArray;
    } catch (error) {
        ErrorMessage(error.response.data)
        console.error(error);
        throw Error(error)
    }

}
export const DeleteConfirmPOPUP = (props) => {
    return <div className="top-0 right-0 bottom-0 left-0 z-[1100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
        <div className="flex justify-center items-center w-full h-full">
            <div className="top-0 right-0 bottom-0 left-0 z-[100] fixed md:inset-0 bg-[rgba(0,0,0,0.5)] w-full max-h-full overflow-x-hidden overflow-y-auto">
                <div className="flex justify-center items-center w-full h-full">
                    <div className="w-[30vw]">
                        <div class="bg-white border-box rounded-md font-sans text-gray-900">
                            <div class="flex justify-center mx-auto w-full sm:max-w-lg">
                                <div class="flex flex-col justify-center items-center bg-white rounded-md w-full">
                                    <div className="flex justify-between px-2 py-1.5 border-b-2 border-b-black border-black border-opacity-30 w-full cursor-pointer">
                                        <span className="font-semibold text-lg">
                                            {props.titleName}
                                        </span>
                                        <span className="hover:bg-gray-200 p-[2px] rounded"
                                            onClick={props.cancelBtnOnClick}
                                        >
                                            <MdOutlineClose size={22} />
                                        </span>
                                    </div>
                                    <div className="mt-1">
                                        <div className="flex flex-col justify-around bg-white px-4 py-3 border-box rounded-md font-sans text-gray-900">
                                            <h1>{BPMNEditor_Labels._ARE_YOU_SURE_WANT_TO_DELETE} <span className='font-semibold text-blue-500 text-base'>{props?.deleteDataName}</span>?</h1>
                                            <div class="flex justify-center space-x-2 pt-4">
                                                <button
                                                    class="px-2 py-1 border border-black border-opacity-30 rounded-md w-20 text-blue-600"
                                                    onClick={props.cancelBtnOnClick}
                                                >
                                                    {BPMNEditor_Labels._CANCEL_BTN}
                                                </button>
                                                <button
                                                    class="bg-blue-500 px-2 py-1 rounded-md w-20 text-white"
                                                    onClick={props.oKBtnOnClick}
                                                >
                                                    {BPMNEditor_Labels._OK_BTN}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
}



export const ALMReqTestCaseChoose = (props) => {
    return (
        <div className="z-[99999] fixed inset-0 flex justify-center items-center bg-black bg-opacity-60">
            <div className="bg-white shadow-2xl p-3 rounded-xl w-[30vw] scale-100 transition-all transform">
                <h2 className="flex justify-between mb-6 p-2 border-b border-black/30 font-bold text-gray-800 text-xl text-center">
                    Select an ALM Option
                    <IoCloseCircleOutline className="hover:bg-slate-200 rounded-lg hover:scale-105 cursor-pointer" onClick={props.closeDialogPopupBox} size={22} color="black" />
                </h2>

                <div className="flex justify-center items-center space-x-2 w-full h-[12vh]">
                    <button onClick={() => { props.onALMReqOrTestSelectOnClick("TESTCASE") }} class="bg-white hover:bg-gray-100 shadow px-4 py-2 border border-gray-400 rounded font-semibold text-gray-800">
                        TestCase
                    </button>
                    <button onClick={() => { props.onALMReqOrTestSelectOnClick("REQUIREMENT") }} class="bg-white hover:bg-gray-100 shadow px-4 py-2 border border-gray-400 rounded font-semibold text-gray-800">
                        Requirement
                    </button>
                </div>
            </div>
        </div>
    );
};

