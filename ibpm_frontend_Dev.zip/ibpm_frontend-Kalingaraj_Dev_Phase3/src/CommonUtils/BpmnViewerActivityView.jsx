import React from 'react';
import BpmnModeler from "bpmn-js/lib/Modeler";
import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from "bpmn-js-properties-panel";
import "bpmn-js-properties-panel/dist/assets/properties-panel.css";
import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";
import "bpmn-js/dist/assets/bpmn-js.css";
import "bpmn-js/dist/assets/diagram-js.css";
import { ErrorMessage } from './CustomToast';
import { BPMN_Editor_Toaster } from '../Constants/TOASTER_MS_TEXT_MSGS';
const extraActivityElements = ["bpmn:SubProcess", "bpmn:UserTask", "bpmn:ServiceTask", "bpmn:SendTask", "bpmn:ReceiveTask", "bpmn:ManualTask", "bpmn:BusinessRuleTask", "bpmn:ScriptTask", "bpmn:CallActivity", "bpmn:SubProcess"]

class Propertiespanel extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0
        }
        this.containerRef = React.createRef();
    }
    async componentDidMount() {

        this.setState({
            count: 0
        })
        try {
            const container = document.getElementById("viewonlyflowline");
            this.modeler = new BpmnModeler({
                container,
                keyboard: {
                    bindTo: null
                },
                additionalModules: [BpmnPropertiesProviderModule, BpmnPropertiesPanelModule,
                    {
                        __init__: ["labelEditingProvider"],
                        labelEditingProvider: ['value', null],
                    },
                    {
                        dragging: ["value", { init: function () { } }]
                    }
                ],
            });
            console.log("modeler ", this.modeler);
            console.log(this.props.xml);
            await this.modeler.importXML(this.props.xml);
            await this.modeler.get('canvas').zoom('fit-viewport', 'auto');
            this.eventBus = this.modeler.get("eventBus");


            this.eventBus.on("element.click", 1500, async (e) => {
                const currElementId = e.element.id;
                if (!currElementId.includes("Actor")) {
                    let elementid = document.getElementById("bio-properties-panel-id")?.value;
                    console.log("elementid", elementid); const bpmnModeling = this.modeler.get('modeling');
                    await this.props.checkActivity();
                    const activityChecker = this.props.currentMapId.flowlineMap.find(el => {
                        const currentId = this.props?.currentMapDet?.id
                        console.log(el)
                        console.log(e.element.id, this.props.TreeviewId, elementid, currentId);
                        return (el.targetActivityId === e.element.id && el.targetMapId === this.props.TreeviewId && el.parentActivityId === elementid && el.originMapId.includes(currentId))
                    }
                    )
                    console.log(activityChecker);
                    if (activityChecker) {
                        ErrorMessage(BPMN_Editor_Toaster.Activity_Is_Already_Added_So_Please_Try_With_Different_Activity_Box)
                        this.setState({
                            count: 0
                        })
                        return
                    }
                    else {
                        const elementFactory = this.modeler.get('elementFactory');
                        console.log(e);
                        console.log(e.element.id);
                        if ((e.element.type === "bpmn:Task" || extraActivityElements.includes(e.element.type))) {
                            this.setState({
                                count: this.state.count + 1
                            })
                            const parentActivity = e.element
                            const tempBussObjParent_Ids = parentActivity.businessObject.$attrs?.mapped_Child_Ids;
                            const targetResMapIds = await tempBussObjParent_Ids?.split(',')?.filter(item => item.includes("FLS_"))
                            console.log(targetResMapIds.length);
                            if (targetResMapIds.length === 0 && this.state.count === 1) {
                                const newStartEvent = elementFactory.createShape({ type: 'bpmn:StartEvent', width: 20, height: 5 });
                                bpmnModeling.appendShape(parentActivity, newStartEvent, { x: parentActivity.x - 30, y: parentActivity.y + (parentActivity.height * .75) },
                                    parentActivity.parent
                                );
                                // bpmnModeling.appendShape(parentActivityId, newEndEvent, { x: parentActivityId.width + parentActivityId.x + 30, y: parentActivityId.y + (parentActivityId.y * (-.10)) },
                                //     parentActivityId.parent
                                // );
                                bpmnModeling.connect(newStartEvent, parentActivity)
                                bpmnModeling.updateProperties(newStartEvent, {
                                    id: "FLS_" + newStartEvent.id,
                                });
                                const waypoints = [
                                    { x: newStartEvent.x, y: parentActivity.y + (parentActivity.height * .75) },
                                    { x: parentActivity.x, y: parentActivity.y + (parentActivity.height * .75) },
                                ]
                                bpmnModeling.updateWaypoints(newStartEvent.outgoing[0], waypoints);
                                bpmnModeling.layoutConnection(newStartEvent.outgoing[0], {
                                    connectionStart: waypoints[0],
                                    connectionEnd: waypoints[waypoints.length - 1]
                                });
                                newStartEvent.businessObject.$attrs.parentActivityId = parentActivity.id;
                                newStartEvent.businessObject.$attrs.TargetActivityId = elementid;
                                bpmnModeling.setColor(newStartEvent, {
                                    fill: '#44bd32',
                                    stroke: '#dcdde1'
                                }
                                );
                                console.log(elementid);
                                const tempBussObjChild_Ids = parentActivity.businessObject.$attrs?.mapped_Child_Ids;
                                const tempAddedChild_Ids = tempBussObjChild_Ids === "" || tempBussObjChild_Ids === undefined ? newStartEvent : (tempBussObjChild_Ids + "," + newStartEvent.id);
                                parentActivity.businessObject.$attrs.mapped_Child_Ids = tempAddedChild_Ids
                                console.log(tempAddedChild_Ids);
                                // this.setState({
                                //     count: 0
                                // })
                            }
                            if (this.state.count !== 1 && this.state.count > 0) {
                                ErrorMessage(BPMN_Editor_Toaster.Only_One_Activity_Box_Will_Be_Added_At_A_Time)
                                return;
                            }
                        }
                    }
                    console.log(bpmnModeling);
                    const bpmnDigXml = (await this.modeler.saveXML()).xml
                    console.log(bpmnDigXml);
                    if (e.element.businessObject.$attrs.AutoNumCount === undefined) {
                        ErrorMessage(BPMN_Editor_Toaster.Please_Select_The_Proper_Activity_Box_For_Flowlink)
                        return;
                    }
                    this.props.storingActivity(e, bpmnDigXml)
                }
            });


            this.eventBus.on("element.dblclick", 1500, (e) => {
                e.preventDefault();
                e.stopPropagation()
            })

            this.eventBus.on('import.render.complete', (event) => {
                console.log(event);
                const bpmnCanvas = this.bpmnModeler.get('canvas');
                bpmnCanvas.zoom('fit-viewport', "center");
            })
        } catch (error) {
            console.error(error);
        }


    }
    componentWillUnmount() {
        try {
            this.modeler?.destroy();
        } catch (error) {
            console.error(error);
        }
    }
    render() {
        console.log(this.props);
        return (
            // <div id='parentcontainer'>
            <div
                id="viewonlyflowline"
                className='h-full w-full'
            >
            </div>
            // </div >
        )
    }
}

export default Propertiespanel;
