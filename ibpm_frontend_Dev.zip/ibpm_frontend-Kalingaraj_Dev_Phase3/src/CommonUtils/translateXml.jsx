import axios from "axios";
import CommonLanguage from "../Services/CommonLanguage";
export const translateXmlNamesByLanguage = async (bpmnXml, fromLanguage, toLanguage, diagramTitle) => {
    // fromLanguage = "en"
    console.log("trans ", bpmnXml, fromLanguage, toLanguage);
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(`${bpmnXml}`, 'text/xml');
    console.log("xmlDoc ", xmlDoc);
    const taskElements = xmlDoc.querySelectorAll('bpmn\\:[mapped_Child_Ids][id][fullNametxt],[mapped_Child_Ids][id][fullNametxt]');
    const taskElementsNotFullName = xmlDoc.querySelectorAll('bpmn\\:[name][id] , [name][id]');
    const textAnnotation = xmlDoc.getElementsByTagNameNS('http://www.omg.org/spec/BPMN/20100524/MODEL', 'textAnnotation');
    console.log("taskElements ", taskElements);
    console.log("taskElementsNotFullName ", taskElementsNotFullName);
    console.log("textAnnotation ", textAnnotation);

    const oldCommentTexts = Array.from(textAnnotation).map((element) => ({
        id: element.getAttribute('id'),
        nameText: element.childNodes[0].textContent
    }));

    // Extract data from each task element
    let ActivityTexts = [];
    let newCommentTexts = [];
    Array.from(taskElements).forEach((element) => {
        if (element.getAttribute('name') !== "") {
            ActivityTexts.push({
                id: element.getAttribute('id'),
                name: element.getAttribute('name'),
                fullNametxt: element.getAttribute('fullNametxt')
            })
        }
        element?.childNodes?.forEach((child) => {
            if (child.getAttribute("textFormat") === "text/x-comments") {
                newCommentTexts.push({
                    id: element.getAttribute('id'),
                    nameText: child.textContent
                })
            }
        })
    });
    let remainingTexts = [];
    Array.from(taskElementsNotFullName).forEach((element) => {
        console.log(element.getAttribute('fullNametxt'));
        if (!element.getAttribute('fullNametxt') && element.getAttribute('name') !== "") {
            console.log(element);
            remainingTexts.push({
                id: element.getAttribute('id'),
                name: element.getAttribute('name'),
            })
        }
        // if (element.childNodes[0]) {
        //     newCommentTexts.push({
        //         id: element.getAttribute('id'),
        //         nameText: element.childNodes[0].textContent
        //     })
        // }
    });
    newCommentTexts.push({
        id: "diagramTitle",
        nameText: diagramTitle
    })
    const requestPayload = {
        ActivityTexts: ActivityTexts,
        remainingTexts: remainingTexts,
        oldCommentTexts: oldCommentTexts,
        newCommentTexts: newCommentTexts
    }
    console.log("req PL", requestPayload);
    const response = await CommonLanguage.putLanguageAPIcall(fromLanguage, toLanguage, requestPayload)
    const translatedTextResults = await response.data;
    console.log("transResults ", translatedTextResults);
    return settranslatedWordsById(bpmnXml, translatedTextResults)
    // return transResults
}

export const setFullnameTextXML = async (bpmnXml, tasks) => {
    console.log(bpmnXml);
    console.log("TASKS", tasks);

    for (const item of tasks) {
        const targetId = item.id;
        const targetElement = bpmnXml.querySelector(`[id="${targetId}"]`);
        console.log(targetElement);
        if (targetElement) {
            targetElement.setAttribute('fullNametxt', `${item.name}`);
            targetElement.setAttribute('name', item.name)//?.length > 25 ? item.name.substring(0, 25) + "..." : item.name);
            console.log(targetElement);
        }

    }
    const updatedBpmnXmlString = new XMLSerializer().serializeToString(bpmnXml)
    return updatedBpmnXmlString
}

export const handleOnTranslateSubmit = async (tasks, fromLanguage, toLanguage) => {
    console.log(tasks);
    // const [transResults, setTransResults] = useState([])
    let transResults = [];
    for (let i = 0; i < tasks?.length; i++) {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage}&tl=${toLanguage}&dt=t&q=${encodeURI(
            `${tasks[i].fullNametxt}`)}`;
        // const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage}&tl=${toLanguage}&dt=t&q=${encodeURI(
        //     `${tasks[i].name}`)}`;
        try {
            // const response = await axios.get(url);
            const response = await axios.create().get(url, {
                headers: {
                    // no Authorization header
                }
            });
            console.log(response);
            const data = await response.data;
            const translatedTxt = data[0][0][0]
            console.log(translatedTxt, " response ", data);
            transResults.push(
                {
                    id: tasks[i].id,
                    name: translatedTxt,//.length > 25 ? translatedTxt.substring(0, 25) + "..." : translatedTxt,
                    fullNametxt: translatedTxt
                })
        } catch (error) {
            console.error(error);
        }
    }
    return transResults;
}
export const handleOnTranslateNotFullnameSubmit = async (tasks, fromLanguage, toLanguage) => {
    console.log(tasks);
    // const [transResults, setTransResults] = useState([])
    let transResults = [];
    for (let i = 0; i < tasks?.length; i++) {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage}&tl=${toLanguage}&dt=t&q=${encodeURI(
            `${tasks[i].name}`)}`;
        // const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage}&tl=${toLanguage}&dt=t&q=${encodeURI(
        //     `${tasks[i].name}`)}`;
        try {
            // const response = await axios.get(url);
            const response = await axios.create().get(url, {
                headers: {
                    // no Authorization header
                }
            });
            console.log(response);
            const data = await response.data;
            const translatedTxt = data[0][0][0]
            console.log(translatedTxt, " response ", data);
            transResults.push(
                {
                    id: tasks[i].id,
                    name: translatedTxt
                })
        } catch (error) {
            console.error(error);
        }
    }
    return transResults;
}

export const handleTextChange = async (transText, fromLanguage, toLanguage) => {
    let transResultsText = [];
    console.log("transText", transText);
    for (let i = 0; i < transText?.length; i++) {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLanguage}&tl=${toLanguage}&dt=t&q=${encodeURI(
            `${transText[i].nameText}`)}`;
        try {
            const response = await axios.create().get(url);
            console.log(response);
            const data = await response.data;
            console.log(data[0][0][0], " response ", data);
            transResultsText.push({ id: transText[i].id, name: data[0][0][0] })
        } catch (error) {
            console.error(error);
        }
    }
    console.log(transResultsText);
    return transResultsText;
}

const settranslatedWordsById = async (bpmnXml, translatedTextResults) => {
    console.log(bpmnXml);
    let diagramTitleResult = "";
    const transActivityTexts = translatedTextResults.ActivityTexts;
    const transRemainingTexts = translatedTextResults.remainingTexts;
    const transOldCommentTexts = translatedTextResults.oldCommentTexts ? translatedTextResults.oldCommentTexts : [];
    const transNewCommentTexts = translatedTextResults.newCommentTexts ? translatedTextResults.newCommentTexts : [];
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(bpmnXml, 'text/xml');
    for (const item of transActivityTexts) {
        console.log(item);
        const targetId = item.id;
        const targetElement = xmlDoc.querySelector(`[id="${targetId}"]`);
        console.log(targetElement);
        if (targetElement) {
            // const resTextToUpdate = targetId?.split("_").includes("Actor") ? (item.fullNametxt?.length > 12 ? item.fullNametxt.substring(0, 12) + "..." : item.name) : item.name
            const resTextToUpdate = item.fullNametxt
            targetElement.setAttribute('name', `${resTextToUpdate}`);
            targetElement.setAttribute('fullNametxt', `${item.fullNametxt}`);
            console.log(targetElement);
        }
    }
    for (const item of transRemainingTexts) {
        console.log(item);
        const targetId = item.id;
        const targetElement = xmlDoc.querySelector(`[id="${targetId}"]`);
        console.log(targetElement);
        if (targetElement) {
            targetElement.setAttribute('name', `${item.name}`);
            console.log(targetElement);
        }
    }
    for (const item of transOldCommentTexts) {
        console.log(item);
        const targetId = item.id;
        const targetElement = xmlDoc.querySelector(`[id="${targetId}"]`);
        console.log(targetElement.childNodes[0].textContent);
        if (targetElement) {
            targetElement.childNodes[0].textContent = item.nameText
            console.log(targetElement);
        }
    }
    for (const item of transNewCommentTexts) {
        console.log(item);
        const targetId = item.id;
        if (targetId === "diagramTitle") {
            diagramTitleResult = item.nameText
        } else {
            const targetElement = xmlDoc.querySelector(`[id="${targetId}"]`);
            console.log(targetElement.childNodes);
            // if (targetElement) {
            // targetElement.childNodes[0].textContent = item.nameText
            targetElement.childNodes?.forEach((child) => {
                console.log(" isComments ", child.getAttribute("textFormat"));
                if (child.getAttribute("textFormat") === "text/x-comments") {
                    child.textContent = item.nameText
                }
            })
            // }

        }
    }

    const updatedBpmnXmlString = new XMLSerializer().serializeToString(xmlDoc);
    console.log("updatedBpmnXmlString ", updatedBpmnXmlString);
    // const xmlDoc = parser.parseFromString(xmlString, 'application/xml');
    return { xmlResponse: updatedBpmnXmlString, diagramTitleResult: diagramTitleResult }
}
