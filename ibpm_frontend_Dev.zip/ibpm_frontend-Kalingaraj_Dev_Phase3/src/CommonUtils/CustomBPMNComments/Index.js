var $ = require('jquery');

function _interopDefaultLegacy(e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var $__default = /*#__PURE__*/_interopDefaultLegacy($);

function _getCommentsElement(element, create) {
    var bo = element.businessObject;
    var docs = bo.get('documentation');
    var comments;

    // get comments node
    docs.some(function (d) {
        return d.textFormat === 'text/x-comments' && (comments = d);
    });

    // create if not existing
    if (!comments && create) {
        comments = bo.$model.create('bpmn:Documentation', {
            textFormat: 'text/x-comments'
        });
        docs.push(comments);
    }
    return comments;
}
function getComments(element) {
    var doc = _getCommentsElement(element);
    if (!doc || !doc.text) {
        return [];
    } else {
        return doc.text.split(/;\r?\n;/).map(function (str) {
            // return str.split(/:/, 2);
            return str.split(/!/, 2);
        });
    }
}
function setComments(element, comments) {
    var doc = _getCommentsElement(element, true);
    var str = comments.map(function (c) {
        // return c.join(':');
        return c.join('!');
    }).join(';\n;');
    doc.text = str;
}
function addComment(element, author, str) {
    // console.log("author", author);
    var comments = getComments(element);
    comments.push([author, str]);
    setComments(element, comments);
}
function removeComment(element, comment) {
    var comments = getComments(element);
    var idx = -1;
    comments.some(function (c, i) {
        var matches = c[0] === comment[0] && c[1] === comment[1];
        if (matches) {
            idx = i;
        }
        return matches;
    });
    if (idx !== -1) {
        comments.splice(idx, 1);
    }
    setComments(element, comments);
}

var COMMENT_HTML = `<div class="comment"><div data-text></div><a href class="delete icon-delete" data-delete></a></div>`;
function Comments(eventBus, overlays, bpmnjs, translate, customActions) {
    function toggleCollapse(element) {
        console.log("iiiiii", element);

        var o = overlays.get({
            element: element,
            type: 'comments'
        })[0];
        var $overlay = o && o.html;
        if ($overlay) {
            var expanded = $overlay.is('.expanded');
            eventBus.fire('comments.toggle', {
                element: element,
                active: !expanded
            });
            if (expanded) {
                $overlay.removeClass('expanded');
            } else {
                $overlay.addClass('expanded');
                const isMapTotallyLocked = (customActions?.props?.isMapLocked || (!window.location.pathname?.toLowerCase().includes('bpmndiagram')) || localStorage.getItem("userRole") === "Admin" ||
                    (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(customActions?.props?.selectedMapData?.diagramXmlIds?.Draft?.status)) ||
                    (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(customActions?.props?.selectedMapData?.diagramXmlIds?.Draft?.status))
                )
                isMapTotallyLocked
                    ? ($overlay.find('textarea').prop('disabled', true).removeAttr('placeholder'))
                    : $overlay.find('textarea').focus();

            }
        }
    }
    function createCommentBox(element) {
        var $overlay = $__default["default"](getOverlayHtml(translate, customActions));
        $overlay.find('.toggle').click(function (e) {
            toggleCollapse(element);
        });
        // var $commentCount = $overlay.find('[data-comment-count]'),
        var $textarea = $overlay.find('textarea'),
            $comments = $overlay.find('.comments');
        function renderComments() {
            // clear innerHTML
            // console.log(" rendercomment ", $comments);

            $comments.html('');
            var comments = getComments(element);
            comments.forEach(function (val) {
                var $comment = $__default["default"](COMMENT_HTML);
                $comment.find('[data-text]').text(val[1]);
                $comment.find('[data-delete]').click(function (e) {
                    e.preventDefault();
                    removeComment(element, val);
                    renderComments();
                    // $textarea.val(val[1]);
                });
                $comments.append($comment);
            });
            $overlay[comments?.length ? 'addClass' : 'removeClass']('with-comments');
            // $commentCount.text(comments.length ? '(' + comments.length + ')' : '');
            eventBus.fire('comments.updated', {
                comments: comments
            });
        }
        $textarea.on('keydown', function (e) {
            if (e.which === 13 && !e.shiftKey) {
                e.preventDefault();
                var comment = $textarea.val();
                if (comment) {
                    addComment(element, '', comment);
                    $textarea.val('');
                    renderComments();
                }
            }
        });
        const cmntsLength = getComments(element);
        // console.log(cmntsLength);
        // attach an overlay to a node
        // const currPathLocation = window.location.pathname;
        // console.log(currPathLocation);
        if ((window.location.pathname?.toLowerCase().includes('bpmndiagram')) || !(cmntsLength === undefined || cmntsLength?.length === 0)) {

            // console.log("element ", element)
            overlays.add(element, 'comments', {
                position: {
                    top: 5,
                    right: 24
                },
                html: $overlay
            });
        }
        renderComments();
    }
    eventBus.on('shape.added', function (event) {
        var element = event.element;
        if (element.labelTarget || !element.businessObject.$instanceOf('bpmn:FlowNode') || !element.id?.includes("Activity")) {
            return;
        }
        defer(function () {
            createCommentBox(element);
        });
    });
    this.collapseAll = function () {
        overlays.get({
            type: 'comments'
        }).forEach(function (c) {
            var html = c.html;
            if (html.is('.expanded')) {
                toggleCollapse(c.element);
            }
        });
    };
}
Comments.$inject = ['eventBus', 'overlays', 'bpmnjs', 'translate', 'customActions'];

// helpers ///////////////

function defer(fn) {
    setTimeout(fn, 0);
}
function getOverlayHtml(translate, customActions) {
    // console.log(" customActions ", customActions);
    const isMapTotallyLocked = (this.customActions?.props?.isMapLocked || localStorage.getItem("userRole") === "Admin" ||
        (localStorage.getItem("userRole") === "Editor" && ["InReview", "Approved", "Published"].includes(this.customActions?.props?.selectedMapData?.diagramXmlIds?.Draft?.status)) ||
        (localStorage.getItem("userRole") === "Reviewer" && ["InProgress", "Approved", "Published"].includes(this.customActions?.props?.selectedMapData?.diagramXmlIds?.Draft?.status))
    )
    // console.log(" isMapTotallyLocked ", isMapTotallyLocked,(window.location.pathname?.toLowerCase().includes('bpmndiagram'))," final ",(window.location.pathname?.toLowerCase().includes('bpmndiagram') && (!isMapTotallyLocked)) );
    return `<div class="comments-overlay">
            <div class="toggle">
                <span class="icon-comment"></span>
                <span class="comment-count" data-comment-count></span>
            </div>
            <div class="content">
                <div class="comments"></div>
                <div class="edit">
                ${(window.location.pathname?.toLowerCase().includes('bpmndiagram') && (!isMapTotallyLocked)) ?
            ("<textarea tabindex=\"1\" placeholder=\"" + translate(`Add a comment`) + "\"></textarea>")
            :
            `<textarea tabindex="1" disabled class="textarea-small"  ></textarea>`
        }
                </div>
            </div>
        </div>`
}

var index = {
    __init__: ['comments'],
    'comments': ['type', Comments]
};

module.exports = index;
//# sourceMappingURL=index.js.map