var $ = require('jquery');
const { isValidValue } = require('../ComponentUtil');

function _interopDefaultLegacy(e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var $__default = /*#__PURE__*/_interopDefaultLegacy($);

function Attachments(eventBus, overlays, bpmnjs, translate, customActions) {
    console.log(eventBus, overlays, bpmnjs, translate, customActions);
    function createAttachmentBox(element) {


        var $overlay = $__default["default"](getOverlayHtml(translate));
        $overlay.click(function (e) {
            console.log(customActions);
            // console.log(customActions);
            const tempBussObj = element.businessObject;
            const tempBussObjAttr = element.businessObject.$attrs;
            customActions.handleElementDblClickByTool(element, "ALM", tempBussObj?.name, tempBussObjAttr);
        });
        // let bussObj = element.businessObject;
        // let documents = bussObj.get('documentation');
        // let overlay;
        // if (documents.length > 0) {
        //     overlay = overlays.get({ element: element }).find(overlays => overlays?.type === "comments")
        // }
        // // console.log("overlay ", overlay)
        let position = { bottom: 20, left: 10 };
        // if (overlay) {
        //     // let currPosition = overlay.position;
        //     position.right = 20;
        //     overlay.position.right = 40;
        //     // console.log("overlay 1111", overlay)
        //     overlays._updateOverlay(overlay)
        // }
        // // console.log("overlay ", overlay)
        overlays.add(element, 'attachment', {
            position: position,
            html: $overlay
        });
    }

    eventBus.on('shape.added', function (event) {
        let element = event.element;
        if (element.labelTarget || !element.businessObject.$instanceOf('bpmn:FlowNode') || !element.id?.includes("Activity")) {
            return;
        }
        defer(function () {
            let bo = element.businessObject;
            let docs = bo.get('documentation');
            const isDocAdded = docs.find((d) => d.textFormat === 'json/file-ALMConnect');
            if (isDocAdded && isValidValue(isDocAdded.text)) {
                createAttachmentBox(element);
            }
        });
    });
    this.renderALMConnectByElement = function (element) {
        console.log("element ", element)
        let bo = element.businessObject;
        let docs = bo.get('documentation');
        const isDocAdded = docs.find((d) => d.textFormat === 'json/file-ALMConnect');
        if (isDocAdded && isValidValue(isDocAdded.text)) {
            console.log(" inside INDEX create file-doc");
            createAttachmentBox(element);
        }
    };
}
Attachments.$inject = ['eventBus', 'overlays', 'bpmnjs', 'translate', 'customActions'];

function defer(fn) {
    setTimeout(fn, 0);
}

function getOverlayHtml() {
    return `<div id="alm_attachment">
      <svg width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
      <rect width="32" height="32" fill="url(#pattern0_1_2)"/>
      <defs>
      <pattern id="pattern0_1_2" patternContentUnits="objectBoundingBox" width="1" height="1">
      <use xlink:href="#image0_1_2" transform="scale(0.03125)"/>
      </pattern>
      <image id="image0_1_2" width="32" height="32" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAIxElEQVR42mL8//8/w0ACgABioaZhuRYqXrdec0yW5v15UVHgZ1HtgUcPCOkBCCAmajrg8w8mnzNPeRTPPOX1uvOWY1qzrbwEIT0AAcRIrSjINlOxPPmYZ7sc38/Holy/D156yRMD9N1fTaGfq9X4/+SXHb39E5s+gACiyAEpJuq+zz+xtLEw/v/74w8T/5uvLCLhWm9Ny/Y9vlFhrmxx9x1n25U3nFaiHP/eq/D+62JnYJ48/daZP8hmAAQQ2Q4wlTYM+/OXYaY4z693QAf8ufOWU9FZ8eOyqWfvJMDUVBprsH34wep7+z17/b1PrOoSHAxPpNhZGpj+saxc9Xz/L5AagAACO0DMIJuZl/UXLz/bD15Btp//Bdm+MwgBsTD7DxD9X5j9O4Mg2w8QZhJg/fmbj+XXh6CFKktefmENyDB9oXfrDedNJYEfJsp8v64lbHv+Gd2xcUqmnF9/saTd+8xc9vYXg4gsO9tBbga22bs+7FgNEEBgB6iYpmTxs/10E2D7ISHE9uOnENBCYZAj2L8zAvm/QBhoORs/608WoOV8PMy/FwUuUfv1/jtLt7n05wMyvL9Km488vEYo1DiZrRgt+Dj7bnz7ncXOyPzjwY/9/AABBM6GQMtzgBZ8AFo0DWjpT6CvmUC+BvKBDvj+R4Dt5x+gz1l4WX795WH5ncrF9Md2UeDt5I7DMhxbbgl2Oyt8YgMa40rIAd//HvvvKuC5mJ3hXyLDf6a/IDGAAAI7AGjRH2Cwn1q1c8siQoZ8qWFRYGf8Z6LI/4ORkYHhLA/rv7+iHH+PE5NuQCGgycHb+Ps/A7s0K/c0kBhAAIHLAaCvQfHMVRNqxUrAcmGg5cbMDP/ZUzepKAAT3mwdkR+3Gixe1xPjAHMuIcfnv3+6iLFwbxVg5moBiQEEENgBwuAEB0lsuMDXGhZ3oOVLgZbbMfxjvAzM54WnnnGrSnP/2cI/9QM4K8UoGxe4S5ofCZaxaoqWsUMpZV35fFne//lbz8TA9I+HiT1v16cV70HiAAEEVgSOb2jCw2G5Chvj3zJmBoaHDH+Zev//Yb7Ex/Y3wFzym9XRpzxZIUoGhgz/mN9eecfmx83M+PnuL0ZDRQ5mOaBWeJb88pfB+/mf7xZybPxzDn9Z+wwmDhBATDAHgFM9MKthA+yMfyWAlksCLV/P1PZ3N3PXr5d7H12aaSTyy1Wd/88aYD632P+MPVKKg/GmGheLkwALy93H3/97ewp6aYD0O/IEsL37+7uFg4nlCx8zewmy2QABBA8BcD5n/YGrwjgHtHwX0Oft3wu4w37+Ylv3/Qf7pu7zL+4DpZPC5M2WSXEw2P79yzx9+dNDLwx4HFlYGJk+8TNyPwGH4P//YW/+ftdQYRdq2vdpFUowAwQQNBd8ZwBmMwZgPsfugOb/3/6UsTX//sV66edPtmKg5ezffnAcAEqB4zFJjvXGlx+c0l++cyh7C7vxAYNb7Ne/fxxPGH+G2/EErQZa3izIzPFCgoOrE91sgAACO0CQ9ed/oOW/tXvf/8ZZb3f9egtUPO9DooT81x8cal+/cYLz8Q5ba43P3znnAB3A8PUnB78NN//SFz/eBn39/2/K7Z+fpnAwsbZ8//9bWJVTMG7jm6W/0M0FCCBIQQT0ObCQ4XhXxSbGwfT3Hxvjv19M/xm+MLX8/wf0OSPQ59w/frJzAH3+79t3Tk6gT5m+fOcUA1rODrQ8GWj57y8/OJy//WLP+PmbLd2VW37X2R/vfRh/f8l///dHsiArx2kWVoZ12DwGEEBgBwCLVw5u5t/eQMv5gZb/A1r+i+Ef0wyg1NHfv9g0f/xkKwNazvP1O8fXr985TYCW837+xtn1GWTxdw5ToM835d5Z/a9eMvnyz7+sXL8ZmCdoc4jf0+YSZ2Bi+9fEwv53etftGb+wOQAggMAO4Gb5/Y+T8e87oOU3Gf8z/AdanvjvN8stYOI7+uMHmyHQ8jBgsE8FWvzlyzdOJSDNAPT5XaCvf3z5yXH22y+O/SBzgJZfA1re+peBSRmYcv8CLbdi4firxcb5ewmoJMbmAIAAAjsAaPlPoOWHmZv/14D4f0rZf/z6xer7OUPoJjCxRX37zrFBdeW9UpDcNhubv0AHKAF9X5Z8dRNKXd7xasZbILUAxi9XywgGhkcOO/dvNlxpCyCAwOUA0HImoM/Z/1Uyg4tioOWLgHF+D2h5NTDYQRb2w5td3zm5gZaLAUNEilDRC7ScB2g5AwfvT5yNDoAAYoI0CoDEX2CY/YGUnlwTvzwGBns20PJsoOUZhpuunoaXaN85nwODXvfrL/aldRLJkfgcwMHzi4GT9ycDF99PnGoAAghi419mhr+/mYE+Z2OA1UbSC56B8vgRjArpJ8dKYJzf+P6bzfrnP5aaIrHs232vpp7B6gBeoAP4QA74gdMBAAEEdgDMcmBqZ+AmEKz5d1e9BFK7QLhILCfgHwOjNpCN1QEgizn5fzJw8+N2AEAAsUDiHGL59x8cBKvUOokU9Z//WF2Aqd0caPl/Rub/p3Cp5QJaDML4HAAQQOA08OMHOwMwpQPjl7ADgJYHAC2vBlrOC7Q8v//5lOu41HIL/IBi3NU8QACBQ+DbD/b/wALmj8bqO78JOQBoOQ/Q8sOMLP8z+59NeYdPLRf/9z9gB+AJAYAAYoGmbC6gA7j2O5kBi1nO38BsxgRM6aCynQFYvDL8+MMK8jnDHwbmP0DLWYCW/2dm+8daoZHOzMb9m5mdG5TaQQkOFOQ/QRaDLP3LI/CDAxgFHMC0wIjLAQABBHHAN2DW+s5pAczjE4D0d2BKZ4JZDkztDL/+s4AsZwBa/h1ouQfQcmEWzj8tbFx/PgOzGgswn8NTO8i3XBBf/+bi+24GdNBzLt4fX3A5ACCAWKCFy0agxc5A2hhYsfz8+hOYJn4DfY5qOdDv//8xs/8D2vjnJdBybaDl/4CWM4Is50ZKcNAQADmICVgObOfk+fkZlwMAAohxoLvnAAEGAFHIutc2ufPJAAAAAElFTkSuQmCC"/>
      </defs>
      </svg>
      </div>`
}

var index = {
    __init__: ['attachment'],
    'attachment': ['type', Attachments]
};

module.exports = index;
