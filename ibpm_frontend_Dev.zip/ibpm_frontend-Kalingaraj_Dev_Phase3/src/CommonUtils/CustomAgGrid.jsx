import { AgGridReact } from "ag-grid-react";
import { useEffect, useRef, useState } from "react";
import { CgChevronLeft, CgChevronRight, CgPushChevronLeft, CgPushChevronRight } from "react-icons/cg";
import { GridConstants } from "../Constants/GridConstants";

export default function CustomAgGrid(props) {
    const [gridApi, setGridApi] = useState();
    const gridRef = useRef();
    const [pages, setPages] = useState({})
    const [showRowCount, setshowRowCount] = useState()
    const [defaultColDef] = useState({
        resizable: true,
    })

    useEffect(() => {
        if (props.filterValue !== undefined) {
            streamData()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.filterValue])

    const streamData = async () => {
        try {
            gridRef.current.api?.setQuickFilter(
                props.filterValue
            );

            let showRowCount = gridApi?.getDisplayedRowCount()

            setshowRowCount(showRowCount);

            if (showRowCount === 0) {
                gridApi?.showNoRowsOverlay();
                document.querySelector('#noMatchData').innerHTML = 'No matching records found!';
            } else {
                gridApi?.hideOverlay();
            }
        } catch (error) {
            console.error(error)
        }
    }

    const onPaginationChanged = (params) => {
        if (gridApi) {
            setPages({
                currentPage: gridApi.paginationGetCurrentPage() + 1,
                totalPages: gridApi.paginationGetTotalPages(),
                lastDisplayedRow: gridApi.getLastDisplayedRow() + 1,
                firstDisplayedRow: gridApi.getFirstDisplayedRow() + 1
            })
        }
    };

    const handlePagination = (page) => {
        switch (page) {
            case 'First':
                gridApi.paginationGoToFirstPage();
                break;
            case 'Last':
                gridApi.paginationGoToLastPage();
                break;
            case 'Next':
                gridApi.paginationGoToNextPage();
                break;
            case 'Previous':
                gridApi.paginationGoToPreviousPage();
                break;
            default:
                console.log("default");
        }
    };

    const onGridReady = params => {
        setGridApi(params.api);
        props.onGridReady(params);
    }

    const getRowStyle = params => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: 'white' };
        } else {
            // return { background: '#F0F0F0' };
            // return { background: '#fdfdfdc0' };
            return { background: '#fafafa' };
        }
    };

    return (
        <div>
            <div className=" ag-theme-alpine relative px-[15px] py-[20px] max-sm:p-2">
                <AgGridReact
                    ref={gridRef} // Ref for accessing Grid's API
                    rowData={props.rowData} // Row Data for Rows
                    columnDefs={props.columnDefs} // Column Defs for Columns
                    animateRows={true} // Optional - set to 'true' to have rows animate when sorted
                    suppressMenuHide={true}
                    rowSelection='multiple' // Options - allows click selection of rows
                    sideBar={'filters'}
                    pagination={true}
                    rowHeight={GridConstants.AGGrid.RowHeight}
                    cacheQuickFilter={true}
                    headerHeight={50}
                    domLayout='autoHeight'
                    paginationPageSize={GridConstants.AGGrid.paginationPageSize}
                    gridOptions={GridConstants.AGGrid.gridOptions}
                    onRowSelected={props.OnCheckBoxSelection}
                    suppressRowClickSelection={true}
                    suppressRowHoverHighlight={true}
                    suppressPaginationPanel={true}
                    onPaginationChanged={onPaginationChanged}
                    isRowSelectable={props.isRowSelectable}
                    getRowStyle={getRowStyle}
                    onGridReady={onGridReady}
                    enableColResize={true}
                    defaultColDef={defaultColDef}
                    overlayNoRowsTemplate={`<div id="noMatchData" class="ag-overlay-loading-center "> <div> NO RECORDS FOUND! </div> </div>`}
                    overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                />
            </div>

            {props.rowData.length === 0 || showRowCount === 0 ? null :
                <div className='flex items-center justify-between px-7 max-sm:pt-3 space-x-10'>
                    <div className='text-xs text-black text-opacity-50 font-semibold'>
                        Showing {pages.firstDisplayedRow} to {pages.lastDisplayedRow}
                    </div>
                    <div className='flex items-center space-x-2'>
                        <span onClick={() => handlePagination('First')} name='First' className='cursor-pointer'><CgPushChevronLeft color='#082f49' size={20} /> </span>
                        <span onClick={() => handlePagination('Previous')} name='Previous' className='cursor-pointer'><CgChevronLeft color='#082f49' size={20} /></span>
                        <span className='text-black text-sm font-semibold border-2 rounded-md px-2'>
                            {pages.currentPage} - {pages.totalPages}
                        </span>
                        <span onClick={() => handlePagination('Next')} name='Next' className='cursor-pointer'><CgChevronRight color='#082f49' size={20} /></span>
                        <span onClick={() => handlePagination('Last')} name='Last' className='cursor-pointer'><CgPushChevronRight color='#082f49' size={20} /></span>
                    </div>
                    <div className='text-xs text-black text-opacity-50 font-semibold pr-16 max-sm:pr-0'>
                        <span>{props.rowData?.length} Records</span>
                    </div>
                </div>
            }
        </div>
    )
}