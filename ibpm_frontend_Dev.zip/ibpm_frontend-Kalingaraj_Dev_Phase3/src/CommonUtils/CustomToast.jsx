import { toast } from "react-hot-toast";


export const SuccessMessage = (message, style = {}) => {
    toast.success(message, {
        ...style,
        duration: 2000,
        style: {
            ...(style.style || {}),
            fontWeight: "bolder",
            color: '#28B463',
            border: '1px solid #2ECC71',
        },
        // icon: '👍',

    })
}

export const ErrorMessage = (message, style = {}) => {
    toast.error(message, {
        ...style,
        style: {
            ...(style.style || {}),
            color: '#E74C3C',
        }

    })
}

