import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from "react-redux";
import App from './App';
import Store from './Redux/Store';
import './index.css';
import reportWebVitals from './reportWebVitals';
import ErrorBounadary500 from './RouteErrorHandleres.jsx/ErrorBounadary500';

// Disable console logs in production
if (process.env.NODE_ENV === 'production') {
  console.log = () => { };
  console.debug = () => { };
}

const root = ReactDOM.createRoot(document.getElementById('root'));

const render = (Component) => {
  root.render(
    <ErrorBounadary500>
      <Provider store={Store}>
        <Component />
      </Provider>
    </ErrorBounadary500>
  );
};

// Initial render
render(App);

// Enable Hot Module Replacement
if (module.hot) {
  module.hot.accept('./App', () => {
    const NextApp = require('./App').default;
    render(NextApp);
  });
}

reportWebVitals();
