import React from 'react';
import { Common_SystemHandler_Labels } from '../Constants/COMMON_LABELS';
import LoginService from '../Services/LoginService';

class ErrorBounadary500 extends React.Component {

    constructor(props) {
        super(props);
        this.state = { hasError: false, error: '', info: '', stack: '' }
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        this.setState({ error, info: errorInfo, stack: error.stack })
        console.error(error, errorInfo)
        console.error(errorInfo.componentStack)
        LoginService.sendReactErrorToBackenEnd(error);
        LoginService.sendReactErrorToBackenEnd(errorInfo);
    }
    render() {
        if (this.state.hasError) {
            return <div>
                <div>
                    <main class="grid min-h-full place-items-center bg-white px-6 py-24 sm:py-32 lg:px-8">
                        <div class="text-center">
                            <p class="text-9xl font-semibold text-red-600">{Common_SystemHandler_Labels._500_ERROR_CODE}</p>
                            <h1 class="mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-5xl">{Common_SystemHandler_Labels._500_ERROR_TITLE}</h1>
                            <p class="mt-6 text-base leading-7 text-gray-600">{Common_SystemHandler_Labels._500_ERROR_CONTENT_1}</p>
                            <div class="mt-10 flex flex-col  items-center justify-center gap-x-6">
                                <span class="text-lg cursor-pointer hover:underline  font-semibold text-blue-900">{Common_SystemHandler_Labels._CONTACT_SUPPORT}<span aria-hidden="true">&rarr;</span></span>
                            </div>
                        </div>
                    </main>
                </div>
            </div>;
        }

        return this.props.children;
    }
}

export default ErrorBounadary500

