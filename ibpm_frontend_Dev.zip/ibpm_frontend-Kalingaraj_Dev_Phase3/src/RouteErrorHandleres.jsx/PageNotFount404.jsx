import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Common_SystemHandler_Labels } from '../Constants/COMMON_LABELS';

const PageNotFount404 = () => {
    useEffect(() => {
        window.location.href = "/"
    }, [])
    return (
        <div>
            <main class="grid min-h-full place-items-center bg-white px-6 py-24 sm:py-32 lg:px-8">
                <div class="text-center">
                    <p class="text-9xl font-semibold text-red-600">{Common_SystemHandler_Labels._404_ERROR_CODE}</p>
                    <h1 class="mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-5xl">{Common_SystemHandler_Labels._404_ERROR_TITLE}</h1>
                    <p class="mt-6 text-base leading-7 text-gray-600">{Common_SystemHandler_Labels._404_ERROR_CONTENT_1}</p>
                    <div class="mt-4 flex flex-col  items-center justify-center gap-x-6">
                        <span  class="text-sm cursor-pointer hover:underline  font-semibold text-blue-900">{Common_SystemHandler_Labels._CONTACT_SUPPORT} <span aria-hidden="true">&rarr;</span></span>
                        <Link to={"/"} class="mt-8 rounded-md bg-cyan-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-cyan-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">{Common_SystemHandler_Labels._GO_BACK_HOME}</Link>
                    </div>
                </div>
            </main>
        </div>
    )
}
export const PageNotFount401 = () => {
    useEffect(() => {
        window.location.href = "/"
    }, [])
    return (
        <div>
            <main class="grid min-h-full place-items-center bg-white px-6 py-24 sm:py-32 lg:px-8">
                <div class="text-center">
                    <p class="text-9xl font-semibold text-red-600">{Common_SystemHandler_Labels._401_ERROR_CODE}</p>
                    <h1 class="mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-5xl uppercase">{Common_SystemHandler_Labels._401_ERROR_TITLE}</h1>
                    <p class="mt-6 text-base leading-7 text-gray-600">{Common_SystemHandler_Labels._401_ERROR_CONTENT_1}</p>
                    <div class="mt-4 flex flex-col  items-center justify-center gap-x-6">
                        <Link to={"/"} class="mt-8 rounded-md bg-cyan-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-cyan-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">{Common_SystemHandler_Labels._401_RETURN_TO_LOGIN_BTN}</Link>
                    </div>
                </div>
            </main>
        </div>
    )
}
export default PageNotFount404
