import { useEffect, useState } from "react";
import { FcExpired } from "react-icons/fc";
import { useLocation } from "react-router-dom";
import LoginService from "../Services/LoginService";
import { Common_SystemHandler_Labels } from "../Constants/COMMON_LABELS";
export const SessionTimeout = () => {
    const [isSessionExpired, setIsSessionExpired] = useState(false);
    const location = useLocation();
    useEffect(() => {
        const currentPath = location?.pathname;
        console.log(currentPath);
        if (currentPath === "/") {
            console.log(" Un Authenticated Path No session Storage ");
            return;
        }
        let inactivityTimer;
        const TIMEOUT_DURATION = Number(process.env.REACT_APP_SESSION_EXPIRE_TIMEOUT) * 60 * 1000;
        const resetTimer = () => {
            clearTimeout(inactivityTimer);
            inactivityTimer = setTimeout(logoutUser, TIMEOUT_DURATION);
        };
        const logoutUser = () => {
            setIsSessionExpired(true);
        };
        const handleUserActivity = () => {
            resetTimer();
        };
        window.addEventListener("mousemove", handleUserActivity, false);
        window.addEventListener("keypress", handleUserActivity, false);

        resetTimer();

        return () => {
            window.removeEventListener("mousemove", handleUserActivity, false);
            window.removeEventListener("keypress", handleUserActivity, false);
            clearTimeout(inactivityTimer);
        };
    }, [location]);
    const handleLogoutOnClick = async () => {
        try {
            await (LoginService.LogOutSession({ email: window.localStorage.getItem('email') }))
            setIsSessionExpired(false);
            window.location.href = "/";
        } catch (error) {
            window.location.href = "/";
            console.log("error", error)
        }

    }
    console.log("session", isSessionExpired);
    window.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            setIsSessionExpired(false)
        }
    })

    return (
        <>
            {isSessionExpired ? (
                <div class="min-w-screen h-screen animated fadeIn faster  fixed  left-0 top-0 flex justify-center items-center inset-0 z-[1000] outline-none focus:outline-none bg-no-repeat bg-center bg-cover" id="modal-id">
                    <div class="absolute bg-black opacity-80 inset-0 z-0"></div>
                    <div class="w-full  max-w-lg  relative mx-auto my-auto rounded-xl shadow-lg  bg-white ">
                        <div class="">
                            <div className=" border-b border-black border-opacity-30 px-4 py-3 text-lg font-semibold">{Common_SystemHandler_Labels._SESSION_EXPIRED_TITLE}</div>
                            <div className="text-base font-normal flex p-3 ml-12 pt-4">
                                <FcExpired size={62} />
                                <div className="ml-4 flex text-center items-center">{Common_SystemHandler_Labels._SESSION_EXPIRED_CONTENT}</div>
                            </div>

                            <div class="p-4  border-black border-opacity-30 mt-2 text-end space-x-4 md:block">
                                <button onClick={handleLogoutOnClick} class="mb-2 md:mb-0 rounded bg-white px-5 py-2 text-sm shadow-sm font-medium tracking-wider border text-gray-600  hover:shadow-lg hover:bg-gray-100">
                                    {Common_SystemHandler_Labels._SESSION_EXPIRED_LOGOUT_BTN}
                                </button>
                                <button
                                    onClick={() => { setIsSessionExpired(false) }}

                                    class="mb-2 md:mb-0 rounded bg-blue-600 border px-5 py-2 text-sm shadow-sm font-medium tracking-wider text-white hover:shadow-lg hover:bg-blue-800 ">{Common_SystemHandler_Labels._SESSION_EXPIRED_STAY_CONNECTED_BTN}</button>
                            </div>
                        </div>
                    </div>
                </div>
            ) : null}
        </>
    );
};