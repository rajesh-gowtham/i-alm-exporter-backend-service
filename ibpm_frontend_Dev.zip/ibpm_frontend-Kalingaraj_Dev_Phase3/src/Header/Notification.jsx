import React from "react";
import { BsCheckAll } from 'react-icons/bs';

//SCREEN ID -3074
const Notification = () => {
    return (
        <div className="notification-box ">
            <div className="notification-head">
                <span>Notifications</span>
                <span class="flex items-center cursor-pointer"><BsCheckAll color="#a5eb9d" size={18} /><span>Mark all as read</span></span>
            </div>

            <div className="showall">view all notifications</div>
        </div>
    )
}

export default Notification;