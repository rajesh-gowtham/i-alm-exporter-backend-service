import React, { useEffect, useRef, useState } from "react";
import { IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io";
import { LiaEditSolid } from "react-icons/lia";
import { PiDiamondsFour, PiSquareHalfDuotone } from "react-icons/pi";
import { HiOutlineWrenchScrewdriver } from "react-icons/hi2";
import userImg from '../Images/userimg.jpg';
import '../Stylesheets/MainHeader.css';
import Signout from "./Signout";
import { Header_Labels } from "../Constants/COMMON_LABELS";
import { ControlsConstants } from "../Constants/ControlsConstants";
import { ErrorMessage } from "../CommonUtils/CustomToast";
import { BPMN_Editor_Toaster } from "../Constants/TOASTER_MS_TEXT_MSGS";

//SCREEN ID -3073
const Header = (props) => {

    const [isSignout, setIsSignout] = useState(false);
    const ref = useRef(null);
    const [isOpen, setIsOpen] = useState([false, false, false]);
    // const [isSubOpen, setIsSubOpen] = useState(false);
    const toggleDropdown = (index) => {
        const updatedOpenState = isOpen.map((state, i) => (i === index ? !state : false));
        setIsOpen(updatedOpenState);
        // setIsSubOpen(false);
    };
    // const toggleSubmenu = () => {
    // setIsSubOpen(current => !current);
    // };
    const buttons = [
        { icon: <LiaEditSolid className="mr-1" size={20} />, label: Header_Labels._MAP_HEADER },
        { icon: <PiDiamondsFour className="mr-1" size={20} />, label: Header_Labels._VIEW_HEADER },
        { icon: <HiOutlineWrenchScrewdriver className="mr-1" size={20} />, label: Header_Labels._TOOLS_HEADER },
    ];

    const DropdownLink = ({ href, children, isLast }) => (
        <div>
            <p className="block font-bold px-4 py-2 text-sm text-slate-900 hover:bg-[#ffe9c1]">
                {children}
            </p>
            {!isLast && <hr className="border-gray-200" />}
        </div>
    )
    const handleClickOutside = (event) => {
        if (ref.current && !ref.current.contains(event.target)) {
            setIsSignout(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, []);

    const KEY_NAME_ESC = 'Escape';
    const KEY_EVENT_TYPE = 'keyup';

    const handleEscKey = (event) => {
        if (event.key === KEY_NAME_ESC) {
            setIsSignout(false);
            setIsOpen([false, false, false]);
            // setIsSubOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        return () => {
            document.removeEventListener(KEY_EVENT_TYPE, handleEscKey, false);
        };
    }, []);
    // }, [handleEscKey]);

    const onClickMenuIcon = () => {
        props.setToggle(!(props.toggle))
    };

    const HandleSignout = () => {
        setIsSignout(current => !current);
    };

    const loginUserImage = JSON.parse(window.localStorage.getItem("userImage"));
    const profileImage = loginUserImage?.imgcontent === "" || loginUserImage?.imgcontent === undefined || loginUserImage?.imgcontent === null ? userImg : loginUserImage?.imgcontent;

    const mystyle = {
        // background: "rgb(255,252,245)",
        // background: "linear-gradient(90deg, rgba(255,252,245,1) 0%, rgba(255,181,46,1) 70%, rgba(65,105,225,1) 100%)"
        // background: "linear-gradient(90deg, #2E549B 30%, #ba7840 31%)"
        background: "linear-gradient(to right, #1F50A3 30%, #E17E2A 41%, #FF7400 100%)"
    };

    const dynamicButton = {
        "Editor": {
            primaryButton: Header_Labels._SAVE_CHANGES_BTN,
            secondaryButton: Header_Labels._SEND_TO_REVIEWER_BTN
        },
        "Admin": {
            primaryButton: Header_Labels._SAVE_CHANGES_BTN,
            secondaryButton: Header_Labels._PUBLISH_BTN
        },
        "Reviewer": {
            primaryButton: Header_Labels._REVERT_TO_EDITOR_BTN,
            secondaryButton: Header_Labels._SEND_TO_PUBLISH_BTN
        }
    }
    const Role = window.localStorage.getItem("userRole");
    return (
        <div className="px-3 flex justify-between items-center h-[48px] text-sm font-normal border-b-[1px]" style={mystyle}>
            <div>
                {props.toggle ? <PiSquareHalfDuotone size={24} style={{ transform: 'rotate(180deg)', cursor: "pointer",color:'white' }} onClick={onClickMenuIcon} /> : null}
            </div>

            {props.isEditorScreenActive ? (!(window.localStorage.getItem("userRole") === "Viewer") && <div className="relative left-5" onMouseLeave={() => setIsOpen([false, false, false])}>
                {/* {props.isEditorScreenActive ? (!(window.localStorage.getItem("userRole") === "Viewer") && <div className="relative left-5" onMouseLeave={() => setIsOpen([false, false, false]) || setIsSubOpen(false)}> */}
                <div className="flex">
                    {buttons.map((button, index) => (
                        <div key={index} className="mr-4">
                            <button onClick={() => toggleDropdown(index)} className="flex items-center text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline hover:outline hover:outline-2 hover:outline-offset-2">
                                {button.icon}
                                {button.label}
                                {!isOpen[index] ?
                                    <IoMdArrowDropdown className="ml-1" /> : <IoMdArrowDropup className="ml-1" />
                                }
                            </button>
                            {isOpen[index] && (
                                <div className="absolute w-40 bg-[#1A58A8] rounded-md overflow-hidden shadow-xl z-[999]">
                                    {button.label === "File" && (
                                        <>
                                            <DropdownLink href="#">{Header_Labels._FILE_SUBHEADER_NEW}</DropdownLink>
                                            <DropdownLink href="#">{Header_Labels._FILE_SUBHEADER_OPEN}</DropdownLink>
                                            <DropdownLink href="#" isLast={true}>{Header_Labels._FILE_SUBHEADER_CLOSE}</DropdownLink>
                                        </>
                                    )}
                                    {button.label === "Map" && (
                                        <>
                                            <p className={ControlsConstants.Header.menubtn} onClick={() => props.onDiagramNavOnclick("BACKTOPARENT")}
                                                isLast={true}>{Header_Labels._MAP_SUBHEADER_ALL_MAPS}</p>
                                        </>)}
                                    {button.label === "View" && (
                                        <>
                                            {/* {((Role === "Editor" || Role === "Admin") && props.selectedMapData?.diagramXmlIds?.Draft?.status === 'InProgress') ? */}
                                            <>
                                                <p className={ControlsConstants.Header.menubtn} onClick={() => props.openCreateEditTemplate("ADD")}>{Header_Labels._VIEW_SUBHEADER_CREATE_TEMPLATE}</p>
                                                <p className={ControlsConstants.Header.menubtn} onClick={props.openApplyTemplate}>{Header_Labels._VIEW_SUBHEADER_APPLY_TEMPLATE}</p>
                                                <p className={ControlsConstants.Header.menubtn} onClick={() => { props?.setTemplateBgColor('from-[#AAACF7]', "HEADERCLICK") }} >{Header_Labels._VIEW_SUBHEADER_DEFAULT_TEMPLATE}</p>
                                            </>
                                            {/* : null
                                            } */}
                                        </>)}
                                    {button.label === Header_Labels._TOOLS_HEADER && (
                                        <>
                                            <p className={ControlsConstants.Header.menubtn} onClick={() => props.openIntegrityCheck()}>
                                                {Header_Labels._TOOLS_SUBHEADER_INTEGRITY_CHECK}
                                            </p>
                                            {/* <p className={ControlsConstants.Header.menubtn} onClick={toggleSubmenu} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                {Header_Labels._AUDIT_TRAIL}
                                                <IoMdArrowDropright className="ml-1" />
                                            </p> */}
                                        </>
                                    )}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
                {/* AUDIT SUBMENU */}
                {/* {isSubOpen && (
                    <div className="absolute top-[4.5rem] left-[25rem] z-[9999] w-36 bg-[#FFFCF4] rounded-md outline outline-1 outline-offset-1 shadow-lg">
                        <p className={ControlsConstants.Header.menubtn}>{Header_Labels._MAP_AUDIT_TRAIL}</p>
                        <p className={ControlsConstants.Header.menubtn}>{Header_Labels._USER_AUDIT_TRAIL}</p>
                    </div>
                )} */}
            </div>) : null}


            <div className="flex-grow">
            </div>

            <div ref={ref} className="flex items-center">
                {props.isEditorScreenActive && (!(props.isMapLocked)) ?
                    <>
                        <div className="mr-10">
                            <div className='py-4'>
                                {(Role === "Reviewer" && ["InReview"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ?
                                    <button
                                        className="bgcolor cursor-pointer text-center px-2 py-1 mx-2 rounded-full  text-white transition-colors duration-300 textz"
                                        onClick={() => {
                                            if (props.editAutoNumflag) {
                                                ErrorMessage(BPMN_Editor_Toaster.Please_rearrange_the_elements_and_save_the_changes)
                                                return
                                            }
                                            else {
                                                props.saveLatestXmlOnclick()
                                            }
                                        }
                                        }
                                        style={{ backgroundColor: '#0369a1', border: '1px' }}
                                    >
                                        Save Changes
                                    </button>
                                    : null}
                                {(Role === "Editor" && ["InReview", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Admin" && ["Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Reviewer" && ["InProgress", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status))
                                    ? null
                                    :
                                    <button
                                        className="bgcolor cursor-pointer text-center px-2 py-1  rounded-full  text-white transition-colors duration-300 textz"
                                        onClick={() => props.headerPrimaryBtnOnClick(props.editAutoNumflag ? Header_Labels._RE_ARRANGE_BTN : dynamicButton[Role]?.primaryButton)}
                                        style={{ backgroundColor: props.editAutoNumflag ? '#45ccf5' : '#0369a1', border: props.editAutoNumflag ? 'none' : '1px' }}
                                    >
                                        {props.editAutoNumflag ? Header_Labels._RE_ARRANGE_BTN : dynamicButton[Role]?.primaryButton}
                                    </button>
                                }
                                {(Role === "Editor" && ["InReview", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Admin" && ["InProgress", "InReview", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ||
                                    (Role === "Reviewer" && ["InProgress", "Approved", "Published"].includes(props.selectedMapData?.diagramXmlIds.Draft.status)) ?
                                    null
                                    :
                                    <button
                                        className={props.editAutoNumflag ? `hovercolor mx-2 cursor-pointer text-center px-2 py-1 rounded-full text-white transition-colors duration-300 textz bg-[#EC7063] border-none` :
                                            (Role === "Reviewer" || Role === "Editor" || (props.selectedMapData?.diagramXmlIds.Draft.status === "Approved" && Role === "Admin")) ?
                                                `bgcolor mx-2 cursor-pointer text-center px-2 py-1 rounded-full text-white transition-colors duration-300 textz bg-[#0369a1] ` :
                                                `bgcolor mx-2 cursor-not-allowed opacity-50 text-center px-2 py-1 rounded-full text-white transition-colors duration-300 textz bg-[#0369a1]`}
                                        onClick={() => props.headerSecondaryBtnOnClick(props.editAutoNumflag ? Header_Labels._CANCEL_BTN : dynamicButton[Role]?.secondaryButton)}
                                    // style={{ backgroundColor: props.editAutoNumflag ? '' : '', border: props.editAutoNumflag ? 'none' : '' }}
                                    >
                                        {props.editAutoNumflag ? Header_Labels._CANCEL_BTN : dynamicButton[Role]?.secondaryButton}
                                    </button>
                                }
                            </div>
                        </div>

                    </> : null
                }
                <div ref={ref} className="flex items-center max-lg:pr-[20px] md:pr-2">
                    <div onClick={HandleSignout} className="cursor-pointer relative inline-flex items-center justify-center mr-2  max-lg:p-0 max-lg:w-6 max-lg:h-6 w-[28px] h-[28px] overflow-hidden bg-[#ebeef6] rounded-full ring-1 ring-offset-2">
                        <img src={profileImage} alt='user' />
                    </div>
                    <div className="text-[#111212] cursor-pointer  " onClick={HandleSignout}>
                        <span className="text-[14px] font-light leading-tight	text-[#000]" >
                            <strong className="font-semibold">{window.localStorage.getItem("userName")}</strong>
                        </span>
                        <br />
                    </div>
                </div>
                {isSignout &&
                    <div className='DropdownBox z-[100]'>
                        <Signout
                            diagramXmlId={props.selectedMapData?.diagramXmlIds?.Draft?.diagramXmlId}
                            isEditorScreenActive={props.isEditorScreenActive}
                            getIsUnSavedXMLExist={props?.getIsUnSavedXMLExist}
                        />
                    </div>
                }
            </div>
        </div>
    )
}
export default Header;