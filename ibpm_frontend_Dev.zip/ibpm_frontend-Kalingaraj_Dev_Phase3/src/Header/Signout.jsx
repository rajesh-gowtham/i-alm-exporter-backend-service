import React, { useEffect, useState } from "react";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
import { ReactDialogBox } from 'react-js-dialog-box';
import { useDispatch } from "react-redux";
import { ErrorMessage, SuccessMessage } from "../CommonUtils/CustomToast";
import { ForgetPassword_Labels, Header_Labels, Login_Labels } from "../Constants/COMMON_LABELS";
import { ControlsConstants } from "../Constants/ControlsConstants";
import { Users_Toaster } from "../Constants/TOASTER_MS_TEXT_MSGS";
import BPMNService from "../Services/BPMNService";
import LoginService from "../Services/LoginService";
import '../Stylesheets/Model.css';

const localControlsConstant = ControlsConstants;
//SCREEN ID -3075
const Signout = (props) => {

    const [isSIgnout, setIsSignout] = useState(false);
    const dispatch = useDispatch();
    const [showPassword, setShowPassword] = useState({
        newpassword: false,
        confirmPassword: false,
        oldpassword: false
    });

    const [isChangePasswordFlag, setisChangePasswordFlag] = useState(false);
    const [newpassword, setNewPassword] = useState("");
    const [oldpassword, setOldPassword] = useState("");
    const [confirmPassword, setconfirmPassword] = useState("");
    const [errorFlags, setErrorFlags] = useState({
        newpassword: false,
        confirmPassword: false,
        oldpassword: false
    });

    const openSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: true });
    };
    const closeSpinnerRedux = () => {
        dispatch({ type: "SET_SPINNER_LOADING", payload: false });
    };
    useEffect(() => {
        document.addEventListener("keyup", ResetPasswordbtn, false);
        return () => {
            document.removeEventListener("keyup", ResetPasswordbtn, false);
        };
    });
    const ResetPasswordbtn = (event) => {
        if (event.key === "Enter") {
            onSubmitPasswordReset(event);
        }
    }
    const LogOffYes = async () => {
        try {
            if (props.isEditorScreenActive)
                await BPMNService.updateDiagramTimeDiagramXmlIdAPICALL(props.diagramXmlId, 'checkOut')
            await (LoginService.LogOutSession({ email: window.localStorage.getItem('email') }))
            window.location.href = "/";
            setTimeout(() => {
                window.localStorage.removeItem('userid')
                window.localStorage.removeItem('email')
                window.localStorage.removeItem('UserName')
                window.localStorage.removeItem('userRole');
                window.localStorage.removeItem("organization")
                window.localStorage.removeItem("userImage")
                window.localStorage.removeItem("accessToken")
            }, 900)
        } catch (error) {
            window.location.href = "/";
            setTimeout(() => {
                window.localStorage.removeItem('userid')
                window.localStorage.removeItem('email')
                window.localStorage.removeItem('UserName')
                window.localStorage.removeItem('userRole');
                window.localStorage.removeItem("organization")
                window.localStorage.removeItem("userImage")
                window.localStorage.removeItem("accessToken")
            }, 900)
            console.log("error", error)
        }


    }
    const handleSignout = async () => {
        if (props.isEditorScreenActive) {
            console.log("initialized");
            const isBothXMLSame = await props.getIsUnSavedXMLExist()
            console.log(isBothXMLSame);
            if (!isBothXMLSame) {
                if (window.confirm("Changes you made may not be saved?")) {
                    setIsSignout(true);
                } else {
                    window.history.pushState(null, null, window.location.pathname);
                }
            } else
                setIsSignout(true);
        } else
            setIsSignout(true);
    }
    const handleClose = () => {
        setIsSignout(false);
        Object.keys(errorFlags).forEach(el => {
            setErrorFlags(prev =>
            (
                { ...prev, [el]: false }
            )
            )
        })
    }

    const handleChangePasswordFlag = () => {
        setisChangePasswordFlag(prev => !prev)
        Object.keys(errorFlags).forEach(el => {
            setErrorFlags(prev =>
            (
                { ...prev, [el]: false }
            )
            )
        })
    }
    const onChangehandler = (e) => {

        if (e.target.name === "new-password") {
            setNewPassword(e.target.value);
        }
        if (e.target.name === "old-password") {
            setOldPassword(e.target.value);
        }
        if (e.target.name === "confirm-password") {
            setconfirmPassword(e.target.value);
        }
    };
    const passworValiadte = (value) => {
        let passwordError;
        const uppercaseRegExp = /(?=.*?[A-Z])/.test(value);
        const lowercaseRegExp = /(?=.*?[a-z])/.test(value);
        const digitRegExp = /(?=.*?[0-9])/.test(value);
        const splCharRegExp = /(?=.*?[#?!@$%^&*-])/.test(value);
        const lengthRegExp = value.length > 7 && value.length < 16;

        if (
            uppercaseRegExp &&
            lowercaseRegExp &&
            digitRegExp &&
            splCharRegExp &&
            lengthRegExp
        ) {
            passwordError = false;
        } else {
            passwordError = true;
        }
        return passwordError;
    };
    const validateForm = () => {
        const validateData = {
            password: newpassword,
            confirmPassword: confirmPassword,
            oldpassword: oldpassword
        };
        const isValid =
            Object.values(validateData).every(
                (value) => value !== "" && value !== null && value !== undefined
            ) &&
            !passworValiadte(newpassword) &&
            newpassword === confirmPassword && oldpassword !== newpassword;
        setErrorFlags({
            newpassword: passworValiadte(newpassword),
            confirmPassword: confirmPassword === "" ? true : newpassword !== confirmPassword,
            oldpassword: oldpassword === "" || oldpassword === null || oldpassword === undefined ? true : false
        });
        return isValid;
    };
    const onSubmitPasswordReset = async (e) => {
        e.preventDefault();
        const isValid = validateForm();
        if (isValid) {
            const requestData = {
                userId: localStorage.getItem('userid'),
                oldPassword: oldpassword,
                newPassword: newpassword,
            };
            console.log(requestData);
            try {
                openSpinnerRedux();
                const res = await LoginService.changeNewPassword(requestData);
                console.log(res);
                // const data = await res.data;
                if (res.status === 200 || res.status === 201) {
                    closeSpinnerRedux();
                    // navigate('/')
                    await LogOffYes()
                    setisChangePasswordFlag(false)
                    SuccessMessage("Password updated successfully");
                }
            } catch (error) {
                closeSpinnerRedux();
                console.error(error);
                if (error.response.status === 406) {
                    ErrorMessage("Please enter the current password correctly")
                    return
                }
                else {
                    ErrorMessage(error.message)
                }
                // setChangePasswordStatus("LINK_VERIFIED");
            }
        }
    };

    return (
        <div class="absolute z-50 right-[18px] top-[42px] w-[200px] h-[100px] text-black">  {/* TODO: if needed later change w-[auto]  */}
            <div class="bg-white rounded">
                <div>
                    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
                    <div className="rounded border-solid border border-slate-500" >
                        <div class="text-sm py-2 px-2">
                            <div class="relative" >
                                <div class="flex flex-col justify-center cursor-pointer">
                                    <div >
                                        <span className="ml-0 mt-[2px] md:mt-0 text-[14px] text-medium font-medium">
                                            {window.localStorage.getItem("organization")}
                                        </span>
                                        <div className="my-2 text-ellipsis overflow-hidden">
                                            <span className="ml-0 mt-[2px] md:mt-0 text-[14px] text-slate-500">
                                                {window.localStorage.getItem("email")}
                                            </span>
                                        </div>
                                        <div className=" my-2">
                                            <div className="text-medium font-medium">
                                                {Header_Labels._ROLE_PROFILE} :
                                                <span className="ml-2 mt-[2px] md:mt-0 text-[14px] text-slate-500">
                                                    {window.localStorage.getItem("userRole")}
                                                </span>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div >
                                    <ul>
                                        <hr class="dark:border-gray-300" />
                                        <li class="font-sm cursor-pointer" onClick={handleChangePasswordFlag}>
                                            <div class="py-2 flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-red-600 hover:text-red-600 hover:font-medium">
                                                <div class="mr-3 text-red-600">
                                                    <svg class="w-[18px] h-[20px]" stroke="currentColor" fill="currentColor" version="1.1" x="0px" y="0px" viewBox="0 0 122.879 118.662" >
                                                        <g>
                                                            <path fillRule="evenodd" clipRule="evenodd" d="M43.101,54.363h4.138v-8.738c0-4.714,1.93-8.999,5.034-12.105v-0.004 c3.105-3.105,7.392-5.034,12.108-5.034c4.714,0,8.999,1.929,12.104,5.034l0.004,0.004c3.104,3.105,5.034,7.392,5.034,12.104v8.738 l3.297,0.001c0.734,0,1.335,0.601,1.335,1.335v28.203c0,0.734-0.602,1.335-1.336,1.335H43.101c-0.734,0-1.336-0.602-1.336-1.335 V55.698C41.765,54.964,42.366,54.363,43.101,54.363L43.101,54.363z M16.682,22.204c-1.781,2.207-3.426,4.551-5.061,7.457 c-5.987,10.645-8.523,22.731-7.49,34.543c1.01,11.537,5.432,22.827,13.375,32.271c2.853,3.392,5.914,6.382,9.132,8.968 c11.112,8.935,24.276,13.341,37.405,13.216c13.134-0.125,26.209-4.784,37.145-13.981c3.189-2.682,6.179-5.727,8.915-9.13 c6.396-7.957,10.512-17.29,12.071-27.138c1.532-9.672,0.595-19.829-3.069-29.655c-3.487-9.355-8.814-17.685-15.775-24.206 C96.695,8.333,88.593,3.755,79.196,1.483c-2.943-0.712-5.939-1.177-8.991-1.374c-3.062-0.197-6.193-0.131-9.401,0.224 c-2.011,0.222-3.459,2.03-3.238,4.041c0.222,2.01,2.03,3.459,4.04,3.237c2.783-0.308,5.495-0.366,8.141-0.195 c2.654,0.171,5.23,0.568,7.731,1.174c8.106,1.959,15.104,5.914,20.838,11.288c6.138,5.751,10.847,13.125,13.941,21.427 c3.212,8.613,4.035,17.505,2.696,25.959c-1.36,8.589-4.957,16.739-10.553,23.699c-2.469,3.071-5.121,5.78-7.912,8.127 c-9.591,8.067-21.031,12.153-32.502,12.263c-11.473,0.109-23.001-3.762-32.764-11.61c-2.895-2.328-5.621-4.983-8.129-7.966 c-6.917-8.224-10.771-18.092-11.655-28.202c-0.908-10.375,1.317-20.988,6.572-30.331c1.586-2.82,3.211-5.071,5.013-7.241 l0.533,14.696c0.071,2.018,1.765,3.596,3.782,3.524s3.596-1.765,3.524-3.782l-0.85-23.419c-0.071-2.019-1.765-3.596-3.782-3.525 c-0.126,0.005-0.25,0.016-0.372,0.032v-0.003L3.157,16.715c-2.001,0.277-3.399,2.125-3.122,4.126 c0.276,2.002,2.124,3.4,4.126,3.123L16.682,22.204L16.682,22.204L16.682,22.204z M53.899,54.363h20.963v-8.834 c0-2.883-1.18-5.504-3.077-7.403l-0.002,0.001c-1.899-1.899-4.521-3.08-7.402-3.08c-2.883,0-5.504,1.18-7.404,3.078 c-1.898,1.899-3.077,4.521-3.077,7.404V54.363L53.899,54.363L53.899,54.363z M64.465,69.795l2.116,9.764l-5.799,0.024l1.701-9.895 c-1.584-0.509-2.733-1.993-2.733-3.747c0-2.171,1.76-3.931,3.932-3.931c2.17,0,3.931,1.76,3.931,3.931 C67.612,67.845,66.261,69.433,64.465,69.795L64.465,69.795L64.465,69.795z" /></g></svg>
                                                </div>
                                                {Header_Labels._CHANGE_PASSWORD_TITLE}
                                            </div>
                                        </li>
                                    </ul>
                                    <ul>
                                        <hr class="dark:border-gray-300" />
                                        <li class="font-sm cursor-pointer" onClick={handleSignout}>
                                            <div class="py-2 flex items-center transform transition-colors duration-200 border-r-4 border-transparent hover:border-red-600 hover:text-red-600 hover:font-medium">
                                                {/**/}
                                                <div class="mr-3 text-red-600">
                                                    <svg class="w-[20px] h-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                                                </div>
                                                {Header_Labels._LOGOUT_PROFILE}
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    {isSIgnout === true &&
                        <div class="max-lg:p-10">
                            <ReactDialogBox
                                closeBox={handleClose}
                                modalWidth={localControlsConstant.Model.modalWidth}
                                headerBackgroundColor={localControlsConstant.Model.headerbg}
                                headerTextColor={localControlsConstant.Model.bodybg}
                                headerHeight={localControlsConstant.Model.headerheight}
                                closeButtonColor={localControlsConstant.Model.closebtncolor}
                                bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                headerText={localControlsConstant.Model.modelConfirm}
                            >
                                <div>
                                    <div class='flex items-center h-16 pl-7 max-lg:h-8 max-lg:pl-2'>
                                        <h1>{Header_Labels._ARE_YOU_SURE_YOU_WANT_TO_LOGOUT}</h1>
                                    </div>
                                    <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                                        <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                            onClick={LogOffYes} >{Header_Labels._YES_BTN}</button>
                                        <button class={localControlsConstant.Responsive.btnResponsive.btn_warning} type="button"
                                            onClick={handleClose}>{Header_Labels._CANCEL_BTN}
                                        </button>
                                    </div>

                                </div>
                            </ReactDialogBox>
                        </div>
                    }
                   {isChangePasswordFlag === true &&
                        <div class="max-lg:p-10">
                            <ReactDialogBox
                                closeBox={handleChangePasswordFlag}
                                modalWidth={localControlsConstant.Model.modalWidth}
                                headerBackgroundColor={localControlsConstant.Model.headerbg}
                                headerTextColor={localControlsConstant.Model.bodybg}
                                headerHeight={localControlsConstant.Model.headerheight}
                                closeButtonColor={localControlsConstant.Model.closebtncolor}
                                bodyBackgroundColor={localControlsConstant.Model.bodybg}
                                bodyTextColor={localControlsConstant.Model.bodytextcolor}
                                headerText={localControlsConstant.Model.resetpassword}
                            >
                                <div className="relative">
                                    <section className="flex flex-col items-center justify-center px-6 py-8 mx-auto lg:py-0">
                                        <div>
                                            <form >
                                                <div className="relative">
                                                    <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900 ">
                                                        {Login_Labels._OLD_PASSWORD}
                                                    </label>
                                                    <input
                                                        name="old-password"
                                                        id="password"
                                                        placeholder="Enter a old password"
                                                        className="border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-[300px] p-2.5  dark:border-gray-600 dark:placeholder-gray-400  dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                        required
                                                        onChange={onChangehandler}
                                                        type={showPassword.oldpassword ? "text" : "password"}
                                                    />
                                                    <button
                                                        type="button"
                                                        className="absolute inset-y-2 right-0 flex items-center text-gray-700 pr-3 mt-6"
                                                        onClick={() => setShowPassword(prev => {
                                                            return ({ ...prev, oldpassword: !showPassword.oldpassword })
                                                        })}
                                                    >
                                                        {showPassword.oldpassword ? <FaRegEyeSlash /> : <FaRegEye />}
                                                    </button>

                                                    {errorFlags.oldpassword && oldpassword === "" ? (
                                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                            {Users_Toaster.Old_Password_Is_Mandatory}
                                                        </div>
                                                    ) : null}

                                                </div>
                                                <div className="relative">
                                                    <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900">
                                                        {Login_Labels._NEW_PASSWORD}
                                                    </label>
                                                    <div className="relative">
                                                        <input
                                                            type={showPassword.newpassword ? "text" : "password"}
                                                            name="new-password"
                                                            id="password"
                                                            placeholder="Enter a new password"
                                                            className="border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-[300px] p-2.5 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                            required
                                                            onChange={onChangehandler}
                                                        />
                                                        <button
                                                            type="button"
                                                            className="absolute inset-y-0 right-0 flex items-center text-gray-700 pr-3"
                                                            style={{ top: '50%', transform: 'translateY(-50%)' }} // Center vertically
                                                            onClick={() => setShowPassword(prev => ({
                                                                ...prev,
                                                                newpassword: !showPassword.newpassword
                                                            }))}
                                                        >
                                                            {showPassword.newpassword ? <FaRegEyeSlash /> : <FaRegEye />}
                                                        </button>
                                                    </div>

                                                    {errorFlags.newpassword && newpassword === "" ? (
                                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                            {Users_Toaster.Password_Is_Mandatory}
                                                        </div>
                                                    ) : null}

                                                    {newpassword !== "" && passworValiadte(newpassword) ? (
                                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                            Password needs minimum 8 characters,uppercase, <br /> lowercase,special character, and number.
                                                        </div>
                                                    ) : null}
                                                    {

                                                        (oldpassword === newpassword && oldpassword !== "" && newpassword !== "") ? (
                                                            <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                                {Users_Toaster.Old_Password_Differ}
                                                            </div>
                                                        ) : null}
                                                </div>
                                                <div className="py-1 relative">
                                                    <label htmlFor="confirm-password" className="block mb-2  text-sm font-medium text-gray-900 ">
                                                        {Login_Labels._CONFIRM_PASSWORD}
                                                    </label>
                                                    <input
                                                        type={showPassword.confirmPassword ? "text" : "password"}
                                                        name="confirm-password"
                                                        id="confirm-password"
                                                        placeholder="Confirm your new password"
                                                        className=" border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-[300px] p-2.5  dark:border-gray-600 dark:placeholder-gray-400  dark:focus:ring-blue-500 dark:focus:border-blue-500 "
                                                        required
                                                        onChange={onChangehandler}
                                                    />
                                                    <button
                                                        type="button"
                                                        className="absolute inset-y-2 right-0 flex items-center text-gray-700 pr-3 mt-6"
                                                        onClick={() => setShowPassword(prev => {
                                                            return ({ ...prev, confirmPassword: !showPassword.confirmPassword })
                                                        })}
                                                    >
                                                        {showPassword.confirmPassword ? <FaRegEyeSlash /> : <FaRegEye />}
                                                    </button>
                                                    {errorFlags.confirmPassword && confirmPassword === "" ? (
                                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                            {Users_Toaster.Confirm_Password_Is_Mandatory}
                                                        </div>
                                                    ) : null}

                                                    {errorFlags.confirmPassword &&
                                                        confirmPassword !== "" &&
                                                        newpassword !== confirmPassword ? (
                                                        <div className="text-[#e50000] text-[13px] font-normal leading-tight tracking-tight pl-2.5 pt-1">
                                                            {Users_Toaster.Password_And_Confirm_Password_Is_Not_Matched}
                                                        </div>
                                                    ) : null}

                                                </div>
                                            </form>
                                        </div>
                                    </section>
                                    <div className="flex justify-end w-full">
                                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                                onClick={onSubmitPasswordReset} >{ForgetPassword_Labels._RESET_PASSWORD_BTN}</button>
                                        </div>
                                        <div class={localControlsConstant.Responsive.btnResponsive.btn_from_footer}>
                                            <button class={localControlsConstant.Responsive.btnResponsive.btn_success} type="button"
                                                onClick={handleChangePasswordFlag} >{Header_Labels._FILE_SUBHEADER_CLOSE}</button>
                                        </div>
                                    </div>
                                </div>
                            </ReactDialogBox>
                        </div>
                    } 
                </div>
            </div>
        </div>
    )
}

export default Signout;