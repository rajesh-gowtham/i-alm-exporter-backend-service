package com.igo.i_process_360.serviceimpl;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.igo.i_process_360.dto.LicenseRequestDto;
import com.igo.i_process_360.model.Continents;
import com.igo.i_process_360.model.Countries;
import com.igo.i_process_360.model.IComp;
import com.igo.i_process_360.model.IReq;
import com.igo.i_process_360.model.ISop;
import com.igo.i_process_360.model.ITest;
import com.igo.i_process_360.model.Ibpm;
import com.igo.i_process_360.model.Ismile;
import com.igo.i_process_360.model.License;
import com.igo.i_process_360.repository.ContinentRepository;
import com.igo.i_process_360.repository.LicenseRepository;
import com.igo.i_process_360.service.LicenseService;
import com.igo.i_process_360.utils.EncryptDeCrypt;

@Service
public class LicenseServiceImpl implements LicenseService{

	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private LicenseRepository licenseRepository;
	
	@Autowired
	private ContinentRepository continentRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(LicenseServiceImpl.class);

	
	@Override
	public Map<String, String> createLicense(LicenseRequestDto licenseRequest) throws JsonProcessingException {
		
		logger.info("Starting the method license creation for company: {}",licenseRequest.getCompany());
		
    Map<String,String> map = new HashMap<>();
	try {
        License license = new License();
        
        license.setCompany(licenseRequest.getCompany());
        license.setContinental(licenseRequest.getContinental());
        license.setCountry(licenseRequest.getCountry());
        license.setTerminal(licenseRequest.getTerminal());
        license.setRegion(licenseRequest.getRegion());
        license.setStartDate(licenseRequest.getStartDate());
        license.setDueDate(licenseRequest.getDueDate());
        license.setIsActivated(false);
        license.setLicenseType(licenseRequest.getLicenseType());
        if(licenseRequest.getInsertUpdate()!=null)
        license.setInsertUpdate(licenseRequest.getInsertUpdate());
        
        
       if(licenseRequest.getIbpm()!=null) {
    	   
    	   logger.debug("Processing ibpm");
    	   Ibpm ibpm = new Ibpm();
    	   ibpm.setAdmin(licenseRequest.getIbpm().getAdmin());
    	   ibpm.setEditor(licenseRequest.getIbpm().getEditor());
    	   ibpm.setReviwer(licenseRequest.getIbpm().getReviewer());
    	   ibpm.setViewer(licenseRequest.getIbpm().getViewer());
    	   license.setIbpm(ibpm);
    	   ibpm.setLicense(license);
        	
        }
       if(licenseRequest.getIsmile()!=null) {
    	   
    	   logger.debug("Processing ismile");
    	   
    	   Ismile ismile = new Ismile();
    	   ismile.setAdmin(licenseRequest.getIsmile().getAdmin());
    	   ismile.setTechnicalCoOrdinate(licenseRequest.getIsmile().getTechnicalCoOrdinate());
    	   ismile.setTechnicalManager(licenseRequest.getIsmile().getTechnicalManager());
    	   ismile.setUsers(licenseRequest.getIsmile().getUser());
           license.setISmile(ismile);
           ismile.setLicense(license);
        	
        }
       if(licenseRequest.getIcomp()!=null) {
    	   
    	   logger.debug("Processing iComp");
    	   
    	   IComp iComp = new IComp();
    	   iComp.setAdmin(licenseRequest.getIcomp().getAdmin());
    	   iComp.setViewer(licenseRequest.getIcomp().getViewer());
    	   license.setIComp(iComp);
    	   iComp.setLicense(license);
       	
       }
       if(licenseRequest.getIreq()!=null) {
    	   
    	   logger.debug("Processing iReq");
    	   
    	   IReq iReq = new IReq();
    	   iReq.setAdmin(licenseRequest.getIreq().getAdmin());
    	   iReq.setViewer(licenseRequest.getIreq().getViewer());
    	   license.setIReq(iReq);
    	   iReq.setLicense(license);
       	
       }
       if(licenseRequest.getItest()!=null) {
       	
    	   logger.debug("Processing iTest");
    	   
    	   ITest iTest = new ITest();
    	   iTest.setAdmin(licenseRequest.getItest().getAdmin());
    	   iTest.setViewer(licenseRequest.getItest().getViewer());
    	   license.setITest(iTest);
    	   iTest.setLicense(license);
       }
       if(licenseRequest.getIsop()!=null) {
    	   
    	   logger.debug("Processing iSop");
    	   
    	   ISop iSop = new ISop();
    	   iSop.setAdmin(licenseRequest.getIsop().getAdmin());
    	   iSop.setViewer(licenseRequest.getIsop().getViewer());
    	   license.setISop(iSop);
    	   iSop.setLicense(license);
    	      	
       }

        String jason = objectMapper.writeValueAsString(licenseRequest);
        String encryptedLicensekey = EncryptDeCrypt.encrypt(jason);
        license.setLicenskey(encryptedLicensekey);
        
        License genLicense = licenseRepository.save(license);  
           
        map.put("licenseKey", genLicense.getLicenskey());
        map.put("licenseId",String.valueOf(genLicense.getLicenseId()));
        map.put("company",genLicense.getCompany());
        map.put("country", genLicense.getCountry());
        map.put("region", genLicense.getRegion());
        map.put("terminal", genLicense.getTerminal());
	}catch (JsonProcessingException e) {
        // Handle serialization issues
        logger.error("JSON processing error while generating license key", e);
        map.put("error", "Failed to process license data");
    } catch (Exception e) {
        // Catch-all for any unexpected exception
        logger.error("Unexpected error during license creation", e);
        map.put("error", "Internal error occurred while creating license");
    }  
		return map;
	}

	@Override
	public Map<String, Object> getContinentsWithCountries() {
		
		
	        List<Continents> continents = continentRepository.findAll();

	        return continents.stream()
	            .sorted(Comparator.comparing(Continents::getName))
	            .collect(Collectors.toMap(
	                Continents::getName,
	                continent -> continent.getCountries().stream()
	                    .map(Countries::getName)
	                    .sorted()
	                    .collect(Collectors.toList()),
	                (e1, e2) -> e1,
	                LinkedHashMap::new
	            ));
	    }

	@Override
	public List<Map<String, Object>> getAllLicense() {
	    return licenseRepository.findAll()
	        .stream()
	        .map(license -> {
	            Map<String, Object> map = new HashMap<>();
	            map.put("licenseId", license.getLicenseId());
	            map.put("company", license.getCompany());
	            map.put("continental", license.getContinental());
	            map.put("country", license.getCountry());
	            map.put("terminal", license.getTerminal());
	            map.put("region", license.getRegion());
	            map.put("startDate", license.getStartDate());
	            map.put("dueDate", license.getDueDate());
	            map.put("licenseType", license.getLicenseType());
	            return map;
	        })
	        .toList();
	}


}
