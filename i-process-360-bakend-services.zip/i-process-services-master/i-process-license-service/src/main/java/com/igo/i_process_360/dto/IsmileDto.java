package com.igo.i_process_360.dto;
import lombok.Data;

@Data
public class IsmileDto {
	
	private Integer technicalCoOrdinate;
	private Integer technicalManager;
	private Integer admin;
	private Integer user;
	

}
