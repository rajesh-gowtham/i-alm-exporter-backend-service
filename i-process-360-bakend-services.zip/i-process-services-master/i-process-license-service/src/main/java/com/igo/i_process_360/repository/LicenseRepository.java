package com.igo.i_process_360.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.igo.i_process_360.model.License;

@Repository
public interface LicenseRepository extends JpaRepository<License, Long> {

	@Query("SELECT c.company FROM License c")
	List<String> getAllCompanyNames();

}
