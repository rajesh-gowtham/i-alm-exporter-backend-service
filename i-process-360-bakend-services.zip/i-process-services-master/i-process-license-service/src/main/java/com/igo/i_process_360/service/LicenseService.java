package com.igo.i_process_360.service;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.igo.i_process_360.dto.LicenseRequestDto;
import com.igo.i_process_360.model.License;

public interface LicenseService {

	Map<String, String> createLicense(LicenseRequestDto licenseRequestDto) throws JsonProcessingException;

	Map<String, Object> getContinentsWithCountries();

	List<Map<String, Object>> getAllLicense();

	
}
