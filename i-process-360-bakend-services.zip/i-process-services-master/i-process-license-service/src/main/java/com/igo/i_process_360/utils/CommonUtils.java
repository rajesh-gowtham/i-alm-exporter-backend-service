package com.igo.i_process_360.utils;

import java.util.Arrays;
import java.util.Iterator;

public class CommonUtils {
	
	
	public void test() {
	
	int ar[] = {10, 90, 49, 2, 1, 5, 23};
	
	Arrays.sort(ar);
	
	for(int i=0;i<ar.length-1;i+=2) {
		
		swap(ar,i,i+1);		
	}
	
	
	
	}

	private void swap(int[] ar, int i, int j) {
		// TODO Auto-generated method stub
		
		//{1,2,5,10,23,49,90}
		
		int temp = ar[i];
		ar[i] = ar[j];
		ar[j] = temp;
		
		
	}
	
	


	

}
