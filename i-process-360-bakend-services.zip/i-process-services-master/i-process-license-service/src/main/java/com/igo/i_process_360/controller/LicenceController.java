package com.igo.i_process_360.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.igo.i_process_360.dto.LicenseRequestDto;
import com.igo.i_process_360.model.License;
import com.igo.i_process_360.repository.LicenseRepository;
import com.igo.i_process_360.service.LicenseService;

@RestController
@RequestMapping("api/license")
@CrossOrigin("*")
public class LicenceController {
	
	@Autowired
	private LicenseService licenseService;
	@Autowired
	private LicenseRepository licenseRepository;
	
	
	@PostMapping("/createLicense")
	public ResponseEntity<Map<String,String>> createLicense(@RequestBody LicenseRequestDto licenseRequestDto) throws JsonProcessingException{
		
		 Map<String,String> response = licenseService.createLicense(licenseRequestDto);
		
		return new ResponseEntity<Map<String,String>>(response, HttpStatus.OK);
		
	}
	
	@GetMapping("/getContinents")
	public ResponseEntity<Map<String,Object>> getContinents() throws JsonProcessingException{
		
		Map<String,Object> map = licenseService.getContinentsWithCountries();
		
		return new ResponseEntity<>(map, HttpStatus.OK);
		
	}
	
	@GetMapping("/getAllLicense")
	public ResponseEntity<List<Map<String, Object>>> getAllLicense(){
		
		List<Map<String, Object>> licenses=licenseService.getAllLicense();
		return new ResponseEntity<>(licenses, HttpStatus.OK);
				
	}
	
	@GetMapping("/getCompanyNames")
	public ResponseEntity<List<String>> getAllCompanyName(){
		
		List<String> companies = licenseRepository.getAllCompanyNames();
		return new ResponseEntity<List<String>>(companies, HttpStatus.OK);
		
	}
	
	
	@GetMapping("/company-hierarchy")
	public Map<String, Map<String, Map<String, List<String>>>> getCompanyLocationHierarchy() {
	    List<License> licenses = licenseRepository.findAll();

	    Map<String, Map<String, Map<String, List<String>>>> response = new HashMap<>();

	    for (License license : licenses) {
	        String company = license.getCompany();
	        String continent = license.getContinental();
	        String country = license.getCountry();
	        String region = license.getRegion();

	        if (company == null || continent == null || country == null || region == null) continue;

	        response
	            .computeIfAbsent(company, c -> new HashMap<>())
	            .computeIfAbsent(continent, con -> new HashMap<>())
	            .computeIfAbsent(country, cou -> new ArrayList<>())
	            .add(region);
	    }

	    // Remove duplicate regions
	    response.forEach((company, continents) -> 
	        continents.forEach((continent, countries) -> 
	            countries.forEach((country, regions) -> {
	                List<String> uniqueRegions = regions.stream().distinct().collect(Collectors.toList());
	                countries.put(country, uniqueRegions);
	            })
	        )
	    );

	    return response;
	}
    
	@PostMapping("/createSuperAdmin")
	public ResponseEntity<Map<String,String>> createSuperAdmin(@RequestBody Map<String,Object> request){

		   
		
		return null;
		
	}

}
