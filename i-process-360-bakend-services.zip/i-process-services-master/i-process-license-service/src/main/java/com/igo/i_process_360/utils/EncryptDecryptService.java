package com.igo.i_process_360.utils;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.PBEKeySpec;
import java.security.spec.KeySpec;
import org.springframework.stereotype.Service;

@Service
public class EncryptDecryptService {

	private static final String ALGORITHM_NAME = "AES";
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final int IV_LENGTH_BYTE = 16;
    private static final String SECRET_KEY = "wsKHurP#or12nMJuerL_urhTHjiKwq_urTJHfIW";

    public String finalEncrypt(String data) throws Exception {
        byte[] iv = new byte[IV_LENGTH_BYTE];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(iv);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        
        System.out.println("dataaaaaaaaaaaaaa"+data);

        SecretKeySpec secretKey = generateSecretKey(SECRET_KEY, 3000, 256);
        System.out.println("Derived SecretKey: " + Base64.getEncoder().encodeToString(secretKey.getEncoded()));
        System.out.println("Started Encrypting");

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        byte[] encryptedIVAndText = new byte[IV_LENGTH_BYTE + encryptedBytes.length];
        System.arraycopy(iv, 0, encryptedIVAndText, 0, IV_LENGTH_BYTE);
        System.arraycopy(encryptedBytes, 0, encryptedIVAndText, IV_LENGTH_BYTE, encryptedBytes.length);
        return Base64.getEncoder().encodeToString(encryptedIVAndText);
    }
    
    public String finalDecrypt(String encryptedData) throws Exception {
        byte[] encryptedIVAndText = Base64.getDecoder().decode(encryptedData);
        byte[] iv = new byte[IV_LENGTH_BYTE];
        System.arraycopy(encryptedIVAndText, 0, iv, 0, IV_LENGTH_BYTE);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        byte[] encryptedBytes = new byte[encryptedIVAndText.length - IV_LENGTH_BYTE];
        System.arraycopy(encryptedIVAndText, IV_LENGTH_BYTE, encryptedBytes, 0, encryptedBytes.length);

        SecretKeySpec secretKey = generateSecretKey(SECRET_KEY, 3000, 256);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }

    private SecretKeySpec generateSecretKey(String secretKey, int iterations, int keyLength) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
        KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), secretKey.getBytes(StandardCharsets.UTF_8), iterations, keyLength);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), ALGORITHM_NAME);
    }

	 
}


