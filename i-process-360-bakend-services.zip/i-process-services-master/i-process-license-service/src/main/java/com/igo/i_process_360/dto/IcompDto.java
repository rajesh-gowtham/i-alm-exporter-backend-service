package com.igo.i_process_360.dto;

import lombok.Data;

@Data
public class IcompDto {
	
	private Integer admin;
	private Integer viewer;

}
