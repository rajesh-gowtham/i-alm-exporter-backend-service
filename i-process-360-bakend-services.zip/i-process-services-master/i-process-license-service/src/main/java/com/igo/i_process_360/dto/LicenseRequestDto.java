package com.igo.i_process_360.dto;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class LicenseRequestDto {

    private String company;
    private String continental;
    private String country;
    private String terminal;
    private String region;
    private String licenseType;
    private String insertUpdate;
    private LocalDate startDate;
    private LocalDate dueDate;
    @JsonProperty("ibpm")
    private IbpmDto ibpm;
    @JsonProperty("iSmile")
    private IsmileDto ismile;
    @JsonProperty("iComp")
    private IcompDto icomp;
    @JsonProperty("iTest")
    private ItestDto itest;
    @JsonProperty("iReq")
    private IreqDto ireq;
    @JsonProperty("iSop")
    private IsopDto isop;

}
