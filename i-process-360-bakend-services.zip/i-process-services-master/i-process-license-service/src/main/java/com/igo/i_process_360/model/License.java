package com.igo.i_process_360.model;
import java.time.LocalDate;
import java.util.List;

import jakarta.annotation.Nullable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "license")
public class License {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long licenseId;
	private String company;
	private String continental;
	private String country;
	private String terminal;
	private String region;
	private LocalDate startDate;
	private LocalDate dueDate;
	private String licenseType;
	private String insertUpdate;  
	@Column(nullable = false)
	@Lob
	private String licenskey;
	private Boolean isActivated;
	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private Ibpm ibpm;

	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private Ismile iSmile;

	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private IComp iComp;

	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private ITest iTest;

	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private IReq iReq;

	@OneToOne(mappedBy = "license", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private ISop iSop;
	

}
