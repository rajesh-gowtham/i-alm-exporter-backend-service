package com.igo.i_process_360.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.igo.i_process_360.model.Continents;

public interface ContinentRepository extends JpaRepository<Continents, Long> {

}
