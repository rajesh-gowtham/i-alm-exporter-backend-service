package com.igosolutions.uniSync.constants;

public final class UtilsConstants {
	
	public final class CommentsConstants{
		public static final String INREVIEW ="InReview";
		public static final String INPROGRESS = "InProgress";
		public static final String APPROVED = "Approved";
		public static final String PUBLISHED ="Published";
	}
	
	public final class RoleConstants{
		public static final String REVIEWER ="Reviewer";
		public static final String ADMIN = "Admin";
		public static final String VIEWER = "Viewer";
		public static final String EDITOR = "Editor";
	}

	public final class LicenceConstants{
		public static final String ACTIVE = "Active";
		public static final String INACTIVE = "Inactive";
		public static final String PENDING = "Pending";
		public static final String UPDATE = "Update";
	}
	
	public final class MapPrivacy{
		public static final String PUBLIC = "public";
		public static final String PRIVATE = "private";
		public static final String SPECIFIC = "specific";
	}
	
	public final class Check{
		
		public static final String CHECKIN = "checkIn";
		public static final String CHECKOUT ="checkOut";
	}
	
	public final class DiagramLevel{
		
		public static final String DRAFT= "Draft";
		public static final String MASTER ="Master";
		public static final String ARCHIVE ="Archive";

		
	}
	
   public final class DiagramEditStatus{
		
		public static final String LOCKED= "Locked";
		public static final String UNLOCKED ="Unlocked";

		
	}
   
   public final class AuditConstants{
		public static final String INSERT= "Insert";
		public static final String UPDATE ="Update";
		public static final String DELETE ="Delete";
	}
   
   public final class MailContents{
	   
	   public static final String SPECIFIC_USER_ADDED_IN_MAP_SUBJECT ="Access granted to specific map";
	   public static final String PUBLIC_USER_ADDED_IN_MAP_SUBJECT ="Added as editor for public map";
	   public static final String MAP_CREATED ="created";
	   public static final String SEND_REVIEW ="sendReview";
	   public static final String REVERT_DRAFT ="revertDraft";
	   public static final String PUBLISHED ="Published";
	   public static final String APPROVED ="approved";
	   public static final String REQUEST_FOR_REVIEW_SUBJECT = "Request for map review";
	   public static final String REVERT_DRAFT_SUBJECT ="Comments Added: Please review and update";
	   public static final String APPROVED_SUBJECT = "Map approved";
	   public static final String MAP_UPDATED = "Map updated";
	 }

	  public final class OrganizationConstants{
		public static final String IGO_ORGANIZATION = "iGO Solutions"; 
	 }

	 public final class DefectToolConstants{
		public static final String ALM_DEFECT_TOOL = "ALM";
		public static final String JIRA_DEFECT_TOOL = "JIRA";
		public static final String ME_DEFECT_TOOL = "ME";
	 }
	
	
	
}
