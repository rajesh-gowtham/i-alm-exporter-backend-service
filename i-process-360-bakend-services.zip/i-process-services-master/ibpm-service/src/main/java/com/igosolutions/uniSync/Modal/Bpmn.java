package com.igosolutions.uniSync.Modal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Bpmn")
public class Bpmn {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long  taskConnectionId;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "bpmn_xml_id", referencedColumnName = "id")
	private BpmnXml bpmnXml;
	@Column(name = "diagramname")
	private String diagramName;
	@Column(name = "diagram_xml_id")
	private String diagramXmlId;
	@Column(name = "language_code")
	private String languageCode;
	@Column(name = "language_name")
	private String languageName;
	@Column(name = "published_by")
	private String publishedBy;
	@Column(name = "template")
	private String template;
	@Column(name = "organization")
	private String organization;
	@Column(name = "version")
    private Double diagramVersion;
	@Column(name = "map_id")
	private Long   mapId;
	@Column(name = "author")
	private String   author;
	@Column(name = "diagram_level")
	private String diagramLevel;
	@Column(name = "project_id")
	private Long   projectId;
	

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDiagramName() {
		return diagramName;
	}

	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}

	public String getDiagramXmlId() {
		return diagramXmlId;
	}

	public void setDiagramXmlId(String diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}



	public String getLanguageCode() {
		return languageCode;
	}



	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}



	public String getLanguageName() {
		return languageName;
	}



	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}



	public String getPublishedBy() {
		return publishedBy;
	}



	public void setPublishedBy(String publishedBy) {
		this.publishedBy = publishedBy;
	}



	public Long getTaskConnectionId() {
		return taskConnectionId;
	} 
	
	public void setTaskConnectionId(Long TaskConnectionId_) {
		this.taskConnectionId = TaskConnectionId_;
	}
	
	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}
	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public Double getDiagramVersion() {
		return diagramVersion;
	}

	public void setDiagramVersion(Double diagramVersion) {
		this.diagramVersion = diagramVersion;
	}

	public Long getMapId() {
		return mapId;
	}

	public void setMapId(Long mapId) {
		this.mapId = mapId;
	}

	public String getDiagramLevel() {
		return diagramLevel;
	}

	public void setDiagramLevel(String diagramLevel) {
		this.diagramLevel = diagramLevel;
	}

	public BpmnXml getBpmnXml() {
		return bpmnXml;
	}

	public void setBpmnXml(BpmnXml bpmnXml) {
		this.bpmnXml = bpmnXml;
	}


}
