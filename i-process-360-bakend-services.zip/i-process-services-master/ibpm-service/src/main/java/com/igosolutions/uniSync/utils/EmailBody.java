package com.igosolutions.uniSync.utils;

import javax.validation.constraints.NotBlank;

public class EmailBody {
	
	public Long commentedUserId;
	@NotBlank(message = "Username should not be blank")
	public String userName;
	@NotBlank(message = "Comment Message should not be blank")
	public String commentMessage;
	@NotBlank(message = "Time Stamp should not be blank")
	public String timeStamp;
	
	public Long getCommentedUserId() {
		return commentedUserId;
	}
	public void setCommentedUserId(Long commentedUserId) {
		this.commentedUserId = commentedUserId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCommentMessage() {
		return commentMessage;
	}
	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "EmailBody [commentedUserId=" + commentedUserId + ", userName=" + userName + ", commentMessage="
				+ commentMessage + ", timeStamp=" + timeStamp + "]";
	}
	
	

}
