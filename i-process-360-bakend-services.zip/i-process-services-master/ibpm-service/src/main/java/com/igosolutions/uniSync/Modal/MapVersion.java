package com.igosolutions.uniSync.Modal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Audited
@Table(name = "map_version")
public class MapVersion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "diagram_xml_id")
    private int diagramXmlId;

    @Column(name = "diagram_level")
    private String diagramLevel;

    @Column(name = "diagram_name")
    private String diagramName;

    @Column(name = "diagram_version")
    private Double diagramVersion;
    
    @Column(name = "diagram_edit_status")
    private String diagramEditStatus;
    
    @Column(name = "published_by")
    private Long publishedBy;
    
    @ManyToOne()
    @JoinColumn(name = "map_id", nullable = false)
    private ReviewDiagramme reviewDiagramme;
    

    public ReviewDiagramme getReviewDiagramme() {
		return reviewDiagramme;
	}

	public void setReviewDiagramme(ReviewDiagramme reviewDiagramme) {
		this.reviewDiagramme = reviewDiagramme;
	}

	public String getDiagramEditStatus() {
		return diagramEditStatus;
	}

	public void setDiagramEditStatus(String diagramEditStatus) {
		this.diagramEditStatus = diagramEditStatus;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getDiagramXmlId() {
        return diagramXmlId;
    }

    public void setDiagramXmlId(Integer diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }

    public String getDiagramLevel() {
        return diagramLevel;
    }

    public void setDiagramLevel(String diagramLevel) {
        this.diagramLevel = diagramLevel;
    }

    public String getDiagramName() {
        return diagramName;
    }

    public void setDiagramName(String diagramName) {
        this.diagramName = diagramName;
    }

    public Double getDiagramVersion() {
        return diagramVersion;
    }

    public void setDiagramVersion(Double diagramVersion) {
        this.diagramVersion = diagramVersion;
    }

	public Long getPublishedBy() {
		return publishedBy;
	}

	public void setPublishedBy(Long publishedBy) {
		this.publishedBy = publishedBy;
	}

	@Override
	public String toString() {
		return "MapVersion [id=" + id + ", diagramXmlId=" + diagramXmlId + ", diagramLevel=" + diagramLevel
				+ ", diagramName=" + diagramName + ", diagramVersion=" + diagramVersion + ", diagramEditStatus="
				+ diagramEditStatus + ", publishedBy=" + publishedBy + ", reviewDiagramme=" + reviewDiagramme + "]";
	}
	

}
