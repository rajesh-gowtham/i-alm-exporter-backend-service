package com.igosolutions.uniSync.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.AuditTrail;
import com.igosolutions.uniSync.Respository.AuditTrailRepository;

@Service
public class AuditTrailService {

    @Autowired
    private AuditTrailRepository auditTrailRepository;

    public List<AuditTrail> getAuditTrails(String entityId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        return auditTrailRepository.findByEntityIdAndDateRange(entityId, startDateTime, endDateTime);
    }
    
}
