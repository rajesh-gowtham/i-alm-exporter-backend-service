package com.igosolutions.uniSync.Modal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "alm_connect")
public class ALMConnect {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alm_connect_id")
    private Long almConnectId;
    
    @Column(name = "map_id")
    private Long mapId;

    @Column(name = "diagram_xml_id")
    private Integer diagramXmlId;

    @Column(name = "activity_id")
    private String activityId;

    @Column(name = "curr_level_id")
    private String currLevelId;

    @ManyToOne
    @JoinColumn(name = "datasource_id")
    private DataSource dataSource; 

    @Column(name = "test_ids")
    private String testIds;
    
    @Column(name = "alm_module_type")
    private String almModuleType;

    public String getAlmModuleType() {
		return almModuleType;
	}

	public void setAlmModuleType(String almModuleType) {
		this.almModuleType = almModuleType;
	}

	public Long getAlmConnectId() {
        return almConnectId;
    }

    public void setAlmConnectId(Long almConnectId) {
        this.almConnectId = almConnectId;
    }

    public Long getMapId() {
        return mapId;
    }

    public void setMapId(Long mapId) {
        this.mapId = mapId;
    }

    public Integer getDiagramXmlId() {
        return diagramXmlId;
    }

    public void setDiagramXmlId(Integer diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getTestIds() {
        return testIds;
    }

    public void setTestIds(String testIds) {
        this.testIds = testIds;
    }

    public String getCurrLevelId() {
        return currLevelId;
    }

    public void setCurrLevelId(String currLevelId) {
        this.currLevelId = currLevelId;
    }
    
    

}
