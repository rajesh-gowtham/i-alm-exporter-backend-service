package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.igosolutions.uniSync.Modal.PerformanceMonitorDTO;

public interface PerformanceMonitorRepo extends JpaRepository<PerformanceMonitorDTO, Long>{

}
