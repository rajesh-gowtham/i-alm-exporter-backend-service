package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;
import com.igosolutions.uniSync.Modal.Resource;

public interface ResourceService {

	public Map<String, String> addResource(Resource resource, Long userId, String organization) throws Exception;
	
	public List<Object> getAllResource(String org) throws Exception;
	
	public Map<String, String> addEditUsers(Resource resource, String org) throws Exception;

	public Resource deleteUser(Long id) throws Exception;
}
