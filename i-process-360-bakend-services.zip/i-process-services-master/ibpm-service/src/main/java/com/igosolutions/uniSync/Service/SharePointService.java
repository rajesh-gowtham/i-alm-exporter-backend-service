package com.igosolutions.uniSync.Service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.SharepointAccessDTO;

public interface SharePointService {

	String uploadDocument(MultipartFile file, String configId) throws Exception;
	
//	,String clientId,String clientSecret,String tenantId,String siteName
	
	byte[] getFile(String documentId, String file_name) throws Exception;

	Object deleteDocument(String diagram_xml_id, String current_xml_id, String activity_id, String file_name, String configId) throws Exception;

	String uploadDocumentsDb(MultipartFile file) throws Exception;

	ResponseEntity<?> validateCredentials(SharepointAccessDTO SharepointAccessDTO);
	

}