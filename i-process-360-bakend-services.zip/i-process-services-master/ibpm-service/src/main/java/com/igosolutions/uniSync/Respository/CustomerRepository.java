package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>{

    Customer findByCustomerName(String customerName);

    List<Customer> findByIdIn(List<Long> customerIds);

    List<Customer> findAllByOrganization(String organization);

}
