package com.igosolutions.uniSync.ServiceImpl;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserLoginDto;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.CustomerDTO;
import com.igosolutions.uniSync.Modal.LicenseValidation;
import com.igosolutions.uniSync.Modal.MapAccess;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.Role;
import com.igosolutions.uniSync.Modal.RoleResponseDTO;
import com.igosolutions.uniSync.Modal.UserCustomerProjectDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.CustomerRepository;
import com.igosolutions.uniSync.Respository.DataSourceRepository;
import com.igosolutions.uniSync.Respository.LicenseValidationRepository;
import com.igosolutions.uniSync.Respository.MapAccessRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.Respository.RoleRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.BpmnUserService;
import com.igosolutions.uniSync.audit.AuditEvent;
import com.igosolutions.uniSync.audit.AuditEventListener;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.constants.UtilsConstants.AuditConstants;
import com.igosolutions.uniSync.controller.EncryptDecrypt;
import com.igosolutions.uniSync.utils.AsyncEmailService;
import com.igosolutions.uniSync.utils.TemporaryPasswordGenerator;

@Service
public class BpmnUserServiceImpl implements BpmnUserService {

	@Autowired
	private BpmnUserRepository bpmnUserRepository;

	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;

	@Autowired
	SharePointRepository sharePointRepository;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	public DataSourceRepository repo;

	@Autowired
	MapReviewRepository mapReviewRepository;

	@Autowired
	MapAccessRepository mapAccessRepository;

	@Autowired
	private AsyncEmailService asyncEmailService;
	
	@SuppressWarnings("unused")
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	LicenseValidationRepository licenseValidationRepository;

	@Autowired
	EntityManager entityManager;

	@Autowired
	private TemporaryPasswordGenerator temporaryPasswordGenerator;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private AuditEventListener auditEventListener;


	private static final String AES_KEY = "ThisIsASecretKey";

	Logger log = LoggerFactory.getLogger(BpmnUserServiceImpl.class);

	@Value("${sharepoint.clientId}")
	private String clientId; // Your client ID

	@Value("${sharepoint.clientSecret}")
	private String clientSecret; // Your client secret

	@Value("${user.session.timeout.minutes}")
	private long sessionMinutes;

	public boolean smtpStatus = true;

	// Need to UnComment when the licence Validation is added
	// @Override
	// public Map<String, Object> addEditUsers(BpmnUserRequest bpmnUserRequest,
	// String createUpdate) throws Exception {
	// BpmnUser response = new BpmnUser();
	// Map<String, Object> userResponse = new HashMap<>();
	// try {
	// BpmnUser bpmnUser = new BpmnUser(
	// bpmnUserRequest.getUserid(),
	// bpmnUserRequest.getOrganization(),
	// bpmnUserRequest.getFirstname(),
	// bpmnUserRequest.getLastname(),
	// bpmnUserRequest.getEmail(),
	// bpmnUserRequest.getMobileno(),
	// bpmnUserRequest.getRole(),
	// bpmnUserRequest.getPassword(),
	// bpmnUserRequest.getUserimage().getImgname(),
	// bpmnUserRequest.getUserimage().getImgcontent());

	// BpmnUser userEmail = bpmnUserRepository.findByEmail(bpmnUser.getEmail());
	// BpmnUser userId = bpmnUserRepository.findByUserId(bpmnUser.getUserid());
	// License licenseData =
	// licenseRepository.findbyName(bpmnUserRequest.getOrganization());

	// if (licenseData != null) {
	// int currentUsersCount =
	// bpmnUserRepository.countByOrganization(bpmnUserRequest.getOrganization());
	// int currentAdminsCount = bpmnUserRepository
	// .countAdminsByOrganization(bpmnUserRequest.getOrganization());

	// // Check limits
	// if ("CREATE".equals(createUpdate)) {
	// if (userEmail != null) {
	// throw new Exception("Email already exists");
	// }
	// if (bpmnUser.getRole().equalsIgnoreCase(UserRole.ADMIN.getRole())
	// && currentAdminsCount >= licenseData.getAdmins()) {
	// throw new Exception("Maximum number of admins reached");
	// }
	// if (currentUsersCount > licenseData.getUsers()) {
	// throw new Exception("Maximum number of users reached");
	// }
	// } else if ("UPDATE".equals(createUpdate)) {
	// if (userId == null) {
	// throw new Exception("User does not exist");
	// }
	// if (!userId.getEmail().equals(bpmnUser.getEmail())) {
	// throw new Exception("Email does not exist");
	// }
	// }

	// // Proceed with user creation or update
	// if (userId != null && "UPDATE".equals(createUpdate)) {
	// bpmnUserRepository.updateUser(
	// bpmnUser.getUserid(),
	// bpmnUser.getFirstname(),
	// bpmnUser.getLastname(),
	// bpmnUser.getEmail(),
	// bpmnUser.getRole(),
	// bpmnUser.getMobileno(),
	// bpmnUser.getImgname(),
	// bpmnUser.getImgcontent(),
	// bpmnUser.getOrganization());
	// response = bpmnUserRepository.findByUserId(bpmnUser.getUserid());
	// }

	// if ("CREATE".equals(createUpdate)) {
	// bpmnUser.setPassword(encryptPassword(bpmnUser.getPassword()));
	// // Need to save the login Status as InActive
	// BpmnUser user = bpmnUserRepository.save(bpmnUser);
	// response = bpmnUserRepository.findByUserId(user.getUserid());
	// }

	// if (response != null) {
	// userResponse.put("userid", String.valueOf(response.getUserid()));
	// userResponse.put("firstname", response.getFirstname());
	// userResponse.put("lastname", response.getLastname());
	// userResponse.put("email", response.getEmail());
	// userResponse.put("role", response.getRole());
	// userResponse.put("mobileno", response.getMobileno());
	// userResponse.put("organization", response.getOrganization());
	// Map<String, String> userImageMap = new HashMap<>();
	// userImageMap.put("imgname", response.getImgname());
	// userImageMap.put("imgcontent", response.getImgcontent());
	// userResponse.put("userimage", userImageMap);
	// }
	// } else {
	// throw new Exception("Organization not found");
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// System.out.println("The exception came into catch");
	// throw new Exception(e.getMessage());
	// }

	// return userResponse;
	// }

	@SuppressWarnings("null")
	@Override
	@Transactional
	public Map<String, Object> addEditUsers(BpmnUserRequest bpmnUserRequest, String createUpdate) throws Exception {
		String temporary_password = null;
		BpmnUser response = new BpmnUser();
		String subject = null;
		String text = null;
		Map<String, Object> UserResponse = new HashMap<>();
		try {
			List<Long> projectIds = bpmnUserRequest.getProjectIds();

			List<Long> customerIds = bpmnUserRequest.getCustomerIds();

			// Fetch the managed Project entities from the database
			List<Customer> managedCustomers = customerRepository.findByIdIn(customerIds);
			List<Project> managedProjects = projectRepository.findAllById(projectIds);

			// Check if all projectIds and moduleIds were found in the database
			if (managedProjects.size() != projectIds.size() || managedCustomers.size() != managedCustomers.size()) {
				throw new Exception("Some projectIds or moduleIds were not found in the database");
			}
			// Verify if the Modules belong to the assigned Projects
			for (Project project : managedProjects) {
				boolean projectBelongsToCustomer = false;
				for (Customer customer : managedCustomers) {
					if (customer.getProjects().contains(project)) {
						projectBelongsToCustomer = true;
						break;
					}
				}
				if (!projectBelongsToCustomer) {
					throw new Exception("One or more Projects do not belong to the assigned Customers");
				}
			}
			BpmnUser bpmnUser = new BpmnUser(bpmnUserRequest.getUserid(),
					bpmnUserRequest.getOrganization(),
					bpmnUserRequest.getFirstname(),
					bpmnUserRequest.getLastname(),
					bpmnUserRequest.getEmail(),
					bpmnUserRequest.getMobileno(),
					bpmnUserRequest.getRole(),
					bpmnUserRequest.getPassword(),
					bpmnUserRequest.getUserimage().getImgname(),
					bpmnUserRequest.getUserimage().getImgcontent(),
					managedProjects,
					managedCustomers);

			BpmnUser userEmail = bpmnUserRepository.findByEmail(bpmnUser.getEmail());
			BpmnUser userId = bpmnUserRepository.findByUserId(bpmnUser.getUserid());
			if (userId != null) {
				String role = userId.getRole();
				if (role.equals(UtilsConstants.RoleConstants.REVIEWER) && createUpdate.equals("UPDATE")) {
					// List<ReviewDiagramme> map = mapReviewRepository.getByAssignedUserIdUserId(userId.intValue());
					List<ReviewDiagramme> maps = mapReviewRepository.findByAssignedUserId(userId.getUserid().intValue());
					//The request will have the changed role
					if (!bpmnUserRequest.getRole().equals(UtilsConstants.RoleConstants.REVIEWER)) {
						if (maps.size() > 0) {
							throw new Exception(
									"User data already exists. Please complete the current process or delete existing data before attempting to update the user account");
						}
					}
					String updatedName = bpmnUserRequest.getFirstname() + " " + bpmnUserRequest.getLastname();
					maps.forEach(map -> {
						map.getAssignedUsers().forEach(assignedUser ->{
							if(assignedUser.getAssignedUserId() == userId.getUserid().intValue()){
								assignedUser.setAssignedUser(updatedName);
							}
						});
					});
					mapReviewRepository.saveAll(maps);

				}
				if (role.equals(UtilsConstants.RoleConstants.EDITOR) && createUpdate.equals("UPDATE")) {
					// List<ReviewDiagramme> maps = mapReviewRepository.getByAuthorUserIdAndAssignedUserId(userId.getUserid().toString(), 0);
					List<ReviewDiagramme> maps = mapReviewRepository.getByAuthorUserId(userId.getUserid().toString());
					List<MapAccess> mapAccessList = mapAccessRepository.findbySpecificUserId(userId.getUserid().intValue());
					
					if (!bpmnUserRequest.getRole().equals(UtilsConstants.RoleConstants.EDITOR)) {
						if (maps.size() > 0 || mapAccessList.size() > 0) {
							throw new Exception(
									"User data already exists. Please complete the current process or delete existing data before attempting to update the user account");
						}
					}
					// Update all records using the JPQL query
					mapReviewRepository.updateAuthorByAuthorUserId(
							bpmnUserRequest.getFirstname() + " " + bpmnUserRequest.getLastname(),
							userId.getUserid().toString());
				}
			}
			if (userEmail != null && createUpdate.equals("CREATE")) {
				throw new Exception("Email already exist");
			}

			if (userId == null && createUpdate.equals("UPDATE")) {
				throw new Exception("User not exist");
			}

			if (userId != null && createUpdate.equals("UPDATE")) {
				if (userId.getEmail().equals(bpmnUser.getEmail())) {
					List<Project> newProjects = null;
					List<Customer> newCustomers = null;

					// Update Customers
					if (bpmnUserRequest.getCustomerIds() != null) {
						newCustomers = new ArrayList<>(customerRepository.findAllById(bpmnUserRequest.getCustomerIds()));
						bpmnUser.setCustomers(newCustomers);
					}
					if (bpmnUserRequest.getProjectIds() != null) {
						// Fetch the new projects based on the new project IDs
						newProjects = new ArrayList<>(projectRepository.findAllById(bpmnUserRequest.getProjectIds()));
					
						// Fetch the old project IDs associated with the user
						List<Long> oldProjectIds = userId.getProjects().stream()
														   .map(Project::getId)
														   .collect(Collectors.toList());							   
					
						// Find the old project IDs that are not in the new project IDs
						List<Long> projectIdsToDelete = oldProjectIds.stream()
																	 .filter(oldId -> !projectIds.contains(oldId))
																	 .collect(Collectors.toList());											 
					
						// Delete the maps associated with the project IDs to delete
						if (!projectIdsToDelete.isEmpty()) {
							List<ReviewDiagramme> mapsToDelete = mapReviewRepository.findByProjectIdInAndAuthorUserId(projectIdsToDelete, bpmnUser.getUserid().toString());
							if (userId.getRole().equals(UtilsConstants.RoleConstants.REVIEWER)) {
								// List<ReviewDiagramme> map = mapReviewRepository.getByAssignedUserIdUserId(userId.intValue());
								List<ReviewDiagramme> maps = mapReviewRepository.findByAssignedUserId(userId.getUserid().intValue());
								// List<ReviewDiagramme> map2 = mapReviewRepository.getByAssignedUserIdAndStatus(userId.intValue(),UtilsConstants.CommentsConstants.APPROVED);
								if (maps.size() > 0) {
									UserResponse.put("errorMessage","Please delete the maps associated with the projects you are trying to remove or update, and then update the projects accordingly");
									return UserResponse;
								}
							}
							if (!mapsToDelete.isEmpty()) {
								UserResponse.put("errorMessage","Please delete the maps associated with the projects you are trying to remove or update, and then update the projects accordingly");
								return UserResponse;
								// mapReviewRepository.deleteAll(mapsToDelete);
							}
							List<MapAccess> mapAccessList = mapAccessRepository.findbySpecificUserId(bpmnUser.getUserid().intValue());
							if (!mapAccessList.isEmpty()) {
                                mapAccessList.stream().map(MapAccess::getReviewDiagramme).forEach(reviewMap ->{
									projectIdsToDelete.forEach(deleteMapId -> {
										ReviewDiagramme deleteMapByProjectId = mapReviewRepository.findByProjectIdAndMapId(deleteMapId,reviewMap.getId());
										
											if(reviewMap.getProject()!= null && deleteMapByProjectId != null && deleteMapByProjectId.getProject()!=null){
												if(reviewMap.getProject().getId().equals(deleteMapByProjectId.getProject().getId())) {
													UserResponse.put("errorMessage","Please delete the maps associated with the projects you are trying to remove or update, and then update the projects accordingly");
													return ;
													// mapAccessRepository.deleteByMapIdAndSpecificUserId(deleteMapByProjectId.getId(),bpmnUser.getUserid().intValue());
													// mapReviewRepository.delete(deleteMapByProjectId);
												}
											}
										
										
									});
								});
                            }
							if(UserResponse.containsKey("errorMessage")) {
								return UserResponse;
							}
						}
					
						// Update the user's projects to the new projects
						bpmnUser.setProjects(newProjects);
					}

					bpmnUserRepository.updateUser(bpmnUser.getUserid(),
							bpmnUser.getFirstname(),
							bpmnUser.getLastname(),
							bpmnUser.getEmail(),
							bpmnUser.getRole(),
							bpmnUser.getMobileno(),
							bpmnUser.getImgname(),
							bpmnUser.getImgcontent(),
							bpmnUser.getOrganization());

					bpmnUserRepository.flush();
					entityManager.clear();		

					// Update customers and projects separately
					BpmnUser updatedUser = bpmnUserRepository.findByUserId(bpmnUser.getUserid());
					updatedUser.setProjects(newProjects);
					updatedUser.setCustomers(newCustomers);

					bpmnUserRepository.save(updatedUser);

					response = bpmnUserRepository.findByUserId(bpmnUser.getUserid());

				} else {
					throw new Exception("Email not exist");
				}
			}

			if (createUpdate.equals("CREATE")) {

				temporary_password = temporaryPasswordGenerator.generateTemporaryPassword();
				bpmnUser.setPassword(encryptPassword(temporary_password));
				bpmnUser.setFirstLogin(true);
				bpmnUser.setIsLogin(false);
				log.info("Temporary password: " + temporary_password);
				BpmnUser user = bpmnUserRepository.save(bpmnUser);
				response = bpmnUserRepository.findByUserId(user.getUserid());

				if (response != null) {

					UserResponse.put("userid", String.valueOf(response.getUserid()));
				}

			}
			if (createUpdate.equals("UPDATE"))
				UserResponse.put("userid", String.valueOf(response.getUserid()));
			UserResponse.put("firstname", response.getFirstname());
			UserResponse.put("lastname", response.getLastname());
			UserResponse.put("email", response.getEmail());
			UserResponse.put("role", response.getRole());
			UserResponse.put("mobileno", response.getMobileno());
			UserResponse.put("organization", response.getOrganization());
			Map<String, String> userImageMap = new HashMap<>();
			userImageMap.put("imgname", response.getImgname());
			userImageMap.put("imgcontent", response.getImgcontent());
			UserResponse.put("userimage", userImageMap);
			System.out.println("*******************************" + response.isFirstLogin());
			UserResponse.put("isFirstLogin", response.isFirstLogin());
			List<Project> projects = response.getProjects();
			List<ProjectDTO> projectDtoList = new ArrayList<>();
			
			for (Project project : projects) {
				ProjectDTO projectDto = new ProjectDTO();
				projectDto.setId(project.getId());
				projectDto.setProjectName(project.getProjectName());
				projectDto.setCustomerId(project.getCustomer().getId());
				projectDto.setCustomerName(project.getCustomer().getCustomerName());
				projectDtoList.add(projectDto);
			}

			UserResponse.put("project", projectDtoList);

			subject = "USER CREATED";
			text = "Dear " + response.getFirstname() + " " + response.getLastname() + ",\n\n" +
					"Your account has been successfully created. You can now log in and start using our services with below credentials.\n\n\n"
					+
					"User name : " + response.getEmail() + "\n" +
					"\n" +
					"Password : " + temporary_password + "\n" +
					"\n" +
					"Thanks,\n" +
					"IGO Admin";

			try {
				if (createUpdate.equals("CREATE")) {
					asyncEmailService.sendMail(response.getEmail(), subject, text);
				}

			} catch (Exception e) {
				e.printStackTrace();
				smtpStatus = false;
				log.info("SMTP SERVER HAS BEEN INACTIVE, MAIL WAS NOT TRIGGERED");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return UserResponse;
	}

	@Override
	public List<Object> getAllUsersWithoutPassword(String organization) throws Exception {
		List<BpmnUser> bpmnUsers = bpmnUserRepository.getAllUsersWithoutPassword(organization);
		List<Object> allUsers = bpmnUsers.stream().map(user -> {
			// Fetch customers and projects assigned to the user
			List<CustomerDTO> customers = getAssignedCustomersForUser(user.getUserid());
			List<ProjectDTO> projects = getAssignedProjectsForUser(user.getUserid());

			// Create a map to store customer id and their projects
			Map<Long, List<ProjectDTO>> customerProjectsMap = new HashMap<>();
			for (CustomerDTO customer : customers) {
				customerProjectsMap.put(customer.getId(), new ArrayList<>());
			}

			// Populate the customerProjectsMap with the projects assigned to the user
			for (ProjectDTO project : projects) {
				for (CustomerDTO customer : customers) {
					if (project.getCustomerId().equals(customer.getId())) {
						customerProjectsMap.get(customer.getId()).add(project);
					}
				}
			}

			// Build user response
			Map<String, Object> userResponse = new HashMap<>();
			userResponse.put("userid", String.valueOf(user.getUserid()));
			userResponse.put("firstname", user.getFirstname());
			userResponse.put("lastname", user.getLastname());
			userResponse.put("email", user.getEmail());
			userResponse.put("role", user.getRole());
			userResponse.put("mobileno", user.getMobileno());
			userResponse.put("organization", user.getOrganization());

			// Map user image
			Map<String, String> userImageMap = new HashMap<>();
			userImageMap.put("imgname", user.getImgname());
			userImageMap.put("imgcontent", user.getImgcontent());
			userResponse.put("userimage", userImageMap);

			// Convert customers to suitable format with correct projects
			List<Map<String, Object>> customerList = customers.stream().map(customer -> {
				Map<String, Object> customerMap = new HashMap<>();
				customerMap.put("customerId", customer.getId());
				customerMap.put("customerName", customer.getCustomerName());
				customerMap.put("projects", customerProjectsMap.get(customer.getId()));
				return customerMap;
			}).collect(Collectors.toList());
			userResponse.put("customers", customerList);

			return userResponse;
		}).collect(Collectors.toList());
		return allUsers;
	}

	@Override
	public ResponseEntity<Map<String, Object>> checkEmailPassword(BpmnUserLoginDto bpmnUser) throws Exception {

	    Map<String, Object> responsePayload = new HashMap<>();

	    try {
	        BpmnUser user = bpmnUserRepository.findByEmail(bpmnUser.getEmail());

	        if (user != null) {

	            LicenseValidation licenseValidation = licenseValidationRepository.findByOrganization(user.getOrganization());
	            
	            String validTo = null;
	            if(!decryptData(licenseValidation.getValidTo(), LicenseServiceImpl.VALID_TO).equals("null") ) {
	            	System.out.println("Inside validTo");
	            	validTo = decryptData(licenseValidation.getValidTo(), LicenseServiceImpl.VALID_TO);
	            }else {
	            	validTo=null;
	            }
	            
	            if (licenseValidation != null && validTo != null) {
	                try {
	                	// System.out.println(licenseValidation.getValidFrom() + "licenseValidation");
	                	// System.out.println(licenseValidation.getValidTo() + "licenseValidation");
	                	// System.out.println(decryptData(licenseValidation.getValidTo(), LicenseServiceImpl.VALID_TO)+"decryptData(licenseValidation.getValidTo(), LicenseServiceImpl.VALID_TO)");
//	                    validTo = decryptData(licenseValidation.getValidTo(), LicenseServiceImpl.VALID_TO);
	                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");

	                    Date validDate = simpleDateFormat.parse(validTo);
	                    Date currentDate = new Date();
	                    String currenDateString = simpleDateFormat.format(currentDate);

	                    if (currentDate.after(validDate) && !currenDateString.equals(validTo)) {
	                        return ResponseEntity.status(HttpStatus.FORBIDDEN)
	                                .body(Collections.singletonMap("message", "Your iBPM license has been expired,please update the license to continue."));
	                    }
	                } catch (ParseException e) {
	                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                            .body(Collections.singletonMap("message", "Error parsing the valid date"));
	                }
	            }

	            if (bpmnUser.getPassword().equals(decryptPassword(user.getPassword()))) {

	                try {
	                    LicenseValidation licenceDetails = licenseValidationRepository.findByOrganization(user.getOrganization());

	                    String adminCount = decryptData(licenceDetails.getAdmins(), LicenseServiceImpl.AES_ADMIN);
	                    String editorCount = decryptData(licenceDetails.getEditors(), LicenseServiceImpl.AES_EDITOR);
	                    String viewerCount = decryptData(licenceDetails.getViewers(), LicenseServiceImpl.AES_VIEWER);
	                    String reviewerCount = decryptData(licenceDetails.getReviewers(), LicenseServiceImpl.AES_REVIEWER);

	                    String userName = bpmnUser.getEmail();
	                    String token = jwtTokenUtil.generateToken(userName);
	                    String encryptedtoken = EncryptDecrypt.encrypt(token);
	                    String deviceId = bpmnUser.getDeviceId();

	                    List<BpmnUser> loggedInUsers = bpmnUserRepository.getByRoleAndOrganizationAndIsLogin(user.getRole(), user.getOrganization());

	                    int loggedInCount = loggedInUsers.size();

	                    boolean isValid = false;
	                    switch (user.getRole()) {
	                        case UtilsConstants.RoleConstants.ADMIN:
	                            isValid = loggedInCount >= Integer.parseInt(adminCount);
	                            break;
	                        case UtilsConstants.RoleConstants.EDITOR:
	                            isValid = loggedInCount >= Integer.parseInt(editorCount);
	                            break;
	                        case UtilsConstants.RoleConstants.VIEWER:
	                            isValid = loggedInCount >= Integer.parseInt(viewerCount);
	                            break;
	                        case UtilsConstants.RoleConstants.REVIEWER:
	                            isValid = loggedInCount >= Integer.parseInt(reviewerCount);
	                            break;
	                        default:
	                            break;
	                    }

	                    if (user.getDeviceId() != null && !user.getDeviceId().equals(deviceId)) {
	                        if (isSessionActive(user)) {
	                            return ResponseEntity.status(HttpStatus.CONFLICT)
	                                    .body(Collections.singletonMap("message", "Already logged in on another device"));
	                        } else {
	                            user.setDeviceId(null); // Expire previous session
	                        }
	                    }

	                    if (isValid) {
	                        int activeCount = 0;
	                        for (BpmnUser bpmUser : loggedInUsers) {
	                            if (isSessionActive(bpmUser) && !bpmUser.getEmail().equals(bpmnUser.getEmail())) {
	                                activeCount++;
	                            } else {
	                                log.info("User is logged in but inactive: " + bpmUser.getEmail());
	                            }
	                        }
	                        if (activeCount >= loggedInCount) {
	                            return ResponseEntity.status(HttpStatus.CONFLICT)
	                                    .body(Collections.singletonMap("message", user.getRole() + " License Exceeded"));
	                        }
	                    }

	                    bpmnUserRepository.updateIsLogin(user.getUserid());
	                    bpmnUserRepository.flush();
	                    entityManager.clear();

						if(!user.isFirstLogin()){
	                   		jwtTokenUtil.storeToken(userName, token, deviceId);
						}

	                    responsePayload.put("firstname", user.getFirstname());
	                    responsePayload.put("lastname", user.getLastname());
	                    responsePayload.put("userid", String.valueOf(user.getUserid()));
	                    responsePayload.put("role", user.getRole());
	                    responsePayload.put("organization", user.getOrganization());
	                    Map<String, String> userImageMap = new HashMap<>();
	                    userImageMap.put("imgname", user.getImgname());
	                    userImageMap.put("imgcontent", user.getImgcontent());
	                    responsePayload.put("userimage", userImageMap);
	                    responsePayload.put("accestoken", encryptedtoken);
	                    
	                    responsePayload.put("deviceId", user.getDeviceId());
	                    responsePayload.put("isFirstLogin", user.isFirstLogin());
	                } catch (Exception e) {
	                	e.printStackTrace();
	                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                            .body(Collections.singletonMap("message", "An error occurred while processing the license validation."));
	                }
	            } else {
	                return ResponseEntity.status(HttpStatus.FORBIDDEN)
	                        .body(Collections.singletonMap("message", "Incorrect Password"));
	            }

	        } else {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN)
	                    .body(Collections.singletonMap("message", "Email-Id not exists"));
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body(Collections.singletonMap("message", "An unexpected error occurred"));
	    }

	    return ResponseEntity.status(HttpStatus.OK).body(responsePayload);
	}


	private boolean isSessionActive(BpmnUser user) {
		if (user.getLastActive() == null) {
			return false;
		}
		Duration sessionTimeout = Duration.ofMinutes(sessionMinutes); // Set your session timeout duration
		LocalDateTime now = LocalDateTime.now();
		return user.getLastActive().plus(sessionTimeout).isAfter(now);
	}
    
	@Override
	public BpmnUser getUserByEmail(String email) throws Exception {
		return bpmnUserRepository.findByEmail(email);
	}

	// @Transactional
	// @Override
	// public BpmnUser deleteUser(Long userid, List<BpnmUserDiagramme>
	// diagrammeByUserId) throws Exception {

	// try {
	// if (bpmnUserRepository.findByUserId(userid) != null) {

	// for (int i = 0; i < diagrammeByUserId.size(); i++) {
	// if (diagrammeByUserId.get(i).getStorageType() != null
	// && diagrammeByUserId.get(i).getStorageType().equalsIgnoreCase("SharePoint"))
	// {
	// if (sharePointRepository
	// .existsByDiagramXmlId(Integer.toString(diagrammeByUserId.get(i).getDiagramXmlId())))
	// {
	// System.out.println("TEST");
	// DataSource source = repo
	// .findByDatasourceId(Long.parseLong(diagrammeByUserId.get(i).getConfigId()));
	// SharePointClient sharePointClient = new
	// SharePointClient(source.getClientId(),
	// source.getClientSecret(), source.getSiteName(), source.getTenantId());
	// sharePointClient
	// .deleteFolderByName(Integer.toString(diagrammeByUserId.get(i).getDiagramXmlId()));
	// sharePointRepository
	// .deleteByDiagramId(Integer.toString(diagrammeByUserId.get(i).getDiagramXmlId()));
	// }
	// mapReviewRepository.deleteByDiagramXmlId(diagrammeByUserId.get(i).getDiagramXmlId());
	// bpnmUserDiagrammeRepository.deleteById(diagrammeByUserId.get(i).getDiagramXmlId());
	// } else {
	// mapReviewRepository.deleteByDiagramXmlId(diagrammeByUserId.get(i).getDiagramXmlId());
	// fileRepository.deletebydiagramXmlId(diagrammeByUserId.get(i).getDiagramXmlId());
	// bpnmUserDiagrammeRepository.deleteById(diagrammeByUserId.get(i).getDiagramXmlId());

	// }
	// }
	// bpmnUserRepository.deleteByUserId(userid);
	// }

	// else
	// throw new Exception("User not exist");

	// } catch (Exception e) {
	// if (e.getMessage().equals("User not exist"))
	// throw new Exception("User not exist");
	// else
	// e.printStackTrace();
	// throw new Exception("An error occured during delete the user");
	// }
	// BpmnUser responseUserId = bpmnUserRepository.findByUserId(userid);

	// return responseUserId;
	// }

//	@Override
//	@Transactional
//	public BpmnUser deleteUserByRoleCheck(Long userId, List<BpnmUserDiagramme> diagrammeByUserId) throws Exception {
//	    try {
//	        BpmnUser user = bpmnUserRepository.findByUserId(userId);
//	        if (user == null) {
//	            throw new Exception("User does not exist");
//	        }
//	        
//	        String role = user.getRole();
//	        
//	        if (role.equals(UtilsConstants.RoleConstants.EDITOR)) {
//	            List<ReviewDiagramme> map = mapReviewRepository.getByAuthorUserId(String.valueOf(userId));
//	            
//	            // Check if user is actively assigned to any maps
//	            for (ReviewDiagramme reviewDiagramme : map) {
//	                if (reviewDiagramme.getAssignedUser() != null && reviewDiagramme.getAssignedUserId() != 0) {
//	                    throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
//	                }
//	            }
//	            
//	            // Process diagrams associated with the user
//	            for (BpnmUserDiagramme diagram : diagrammeByUserId) {
//	                Integer diagramXmlId = diagram.getDiagramXmlId();
//	                String storageType = diagram.getStorageType();
//	                
//	                if ("SharePoint".equalsIgnoreCase(storageType)) {
//	                    if (sharePointRepository.existsByDiagramXmlId(Integer.toString(diagramXmlId))) {
//	                        DataSource source = repo.findByDatasourceId(Long.parseLong(diagram.getConfigId()));
//	                        SharePointClient sharePointClient = new SharePointClient(
//	                            source.getClientId(), source.getClientSecret(), source.getSiteName(), source.getTenantId()
//	                        );
//	                        sharePointClient.deleteFolderByName(Integer.toString(diagramXmlId));
//	                        sharePointRepository.deleteByDiagramId(Integer.toString(diagramXmlId));
//	                    }
//	                }
//	                
//	                // Delete related records in the correct order
//	                mapReviewRepository.deleteByDiagramXmlId(diagramXmlId);
//	                fileRepository.deleteByDiagramXmlId(diagramXmlId);
//	                bpnmUserDiagrammeRepository.deleteByDiagramXmlId(diagramXmlId);
//	            }
//	            
//	            // Finally, delete the user
//	            bpmnUserRepository.deleteByUserId(userId);
//	        } else if (role.equals(UtilsConstants.RoleConstants.REVIEWER)) {
//	            List<ReviewDiagramme> map = mapReviewRepository.getByAssignedUserIdUserId(userId.intValue());
//	            if (!map.isEmpty()) {
//	                throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
//	            }
//	            deleteUserById(userId);
//	        } else {
//	            deleteUserById(userId);
//	        }
//	        
//	        return null; // Or return appropriate response after successful deletion
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	        throw e;
//	    }
//	}
@Override
@Transactional
public BpmnUser deleteUserByRoleCheck(Long userId, List<ReviewDiagramme> diagrammeByUserId) throws Exception {
	try {
		BpmnUser user = bpmnUserRepository.findByUserId(userId);
		if (user == null) {
			throw new Exception("User not exist");
		}
		String role = user.getRole();

		if (role.equals(UtilsConstants.RoleConstants.EDITOR)) {
			List<ReviewDiagramme> map = mapReviewRepository.getByAuthorUserId(String.valueOf(userId));
			List<ReviewDiagramme> mapDataByAuthorAndStatus = mapReviewRepository.getByAuthorUserIdAndNotStatus(String.valueOf(userId), UtilsConstants.CommentsConstants.APPROVED);

			if (map.size() > 0 && mapDataByAuthorAndStatus.size() > 0) {
				throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
			}
			for (ReviewDiagramme reviewDiagramme : map) {
				// if (reviewDiagramme.getAssignedUser() != null && reviewDiagramme.getAssignedUserId() != 0) {
				// 	throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
				// }
				if (reviewDiagramme!=null) {
					throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
				}
			}
			
			List<MapAccess> specificUserList = mapAccessRepository.findbySpecificUserId(userId.intValue());
			
			if(specificUserList!=null) {
				for(MapAccess mapAccess : specificUserList) {
					List<MapAccess> specificMapList = mapAccessRepository.findByReviewDiagrammeId(mapAccess.getReviewDiagramme().getId());
					if(specificMapList.size() == 1) {
						throw new Exception("User actively assigned to specific maps. Therefore, the user cannot be removed.");
					}
				}
				mapAccessRepository.deleteBySpecificUserId(userId.intValue());
			}
			List<BpnmUserDiagramme> byUserId = bpnmUserDiagrammeRepository.findByUserId(userId);
			if(byUserId.size() > 0) {
				bpnmUserDiagrammeRepository.deleteAll(byUserId);
				bpnmUserDiagrammeRepository.flush();
				entityManager.clear();
			}
			
			
			deleteUserById(userId);
		} else if (role.equals(UtilsConstants.RoleConstants.REVIEWER)) {
			// List<ReviewDiagramme> map = mapReviewRepository.getByAssignedUserIdUserId(userId.intValue());
			List<ReviewDiagramme> maps = mapReviewRepository.findByAssignedUserId(userId.intValue());
			// List<ReviewDiagramme> map2 = mapReviewRepository.getByAssignedUserIdAndStatus(userId.intValue(),UtilsConstants.CommentsConstants.APPROVED);
			if (maps.size() > 0) {
				throw new Exception("User actively assigned to maps. Therefore, the user cannot be removed.");
			}
			deleteUserById(userId);
		} else {
			deleteUserById(userId);
		}
		return null; // Or return appropriate response after successful deletion
	} catch (Exception e) {
		log.info("error in deleteUserByRoleCheck", e.getMessage());
		throw e;
	}
}

	
	
	 

	@Transactional
	@Override
	public BpmnUser deleteUserById(Long userid) throws Exception {
		try {
			if (bpmnUserRepository.findByUserId(userid) != null) {

				bpmnUserRepository.deleteByUserId(userid);
				BpmnUser bpmnUser = new BpmnUser();
				bpmnUser.setUserid(userid);
				auditEventListener.handleAfterCommitAuditEvent(new AuditEvent(bpmnUser, AuditConstants.DELETE));
			} else
				throw new Exception("User not exist");
		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().equals("User not exist"))
				throw new Exception("User not exist");
			else
			throw new Exception("An error occured during delete the user");
		}
		BpmnUser responseUserId = bpmnUserRepository.findByUserId(userid);

		return responseUserId;
	}

	public void generateResetToken(String email, HttpServletRequest request) throws Exception {
		BpmnUser user = bpmnUserRepository.findByEmail(email);
		if (user != null) {
			String resetToken = generateRandomToken();
			System.out.println("Reset Token "+resetToken);
			user.setResettoken(resetToken);
			bpmnUserRepository.save(user);
			try {
				sendResetTokenEmail(user.getFirstname(), user.getEmail(), resetToken, request);
			} catch (Exception e) {
				throw new Exception("Error sending link");
			}
		} else {
			throw new Exception("Invalid user");
		}
	}

	public void resetPassword(String email, String newPassword, String resetToken) throws Exception {

		BpmnUser user = bpmnUserRepository.findByEmail(email);

		String decryptedResetToken = decryptOTPToken(resetToken);

		if (user != null) {
			if (user.getResettoken() != null && user.getResettoken().equals(decryptedResetToken)) {
				user.setPassword(encryptPassword(newPassword));
				user.setResettoken(null);
				bpmnUserRepository.save(user);
			} else {
				throw new Exception("Reset token mismatched");
			}
		} else {
			throw new Exception("Invalid user");
		}
	}

	public boolean verifyCode(String resetToken) throws Exception {
		BpmnUser user = bpmnUserRepository.findByResettoken(resetToken);
		if (user != null) {
			user.setResettoken("verified");
			bpmnUserRepository.save(user);
			return true;
		} else {
			return false;
		}
	}

	public void sendResetTokenEmail(String userName, String userEmail, String resetToken, HttpServletRequest request)
			throws Exception {
		String resetUrl = request.getRequestURL().toString().replace(request.getRequestURI(), "") + "/";
		String encryptedResetToken = encryptOtp(resetToken);

		// Construct the reset URL
		String originHeader = request.getHeader("Origin");
		if (originHeader != null && !originHeader.isEmpty()) {
			resetUrl = originHeader;
		} else {
			// If Origin header is not present, construct the URL using scheme, server name,
			// and port
			String scheme = request.getScheme();
			String serverName = request.getServerName();
			int port = request.getServerPort();

			// Construct the reset URL
			resetUrl = scheme + "://" + serverName + (port != 80 && port != 443 ? ":" + port : "");
		}

		resetUrl += "/resetPassword" + "/" + userEmail + "/" + encryptedResetToken;

		String emailContent = "Hi " + userName + ",<br><br>"
				+ "A password change has been requested for your account. If this was you, please use the link below <br>"
				+ "to reset your password.<br>"
				+ "<a href=\"" + resetUrl + "\">ResetPassword</a><br><br>"
				+ "Thanks,<br>"
				+ "IGO Admin";
		System.out.println("Resest Url" + resetUrl);		

		asyncEmailService.sendMailLink(userEmail, "Password reset link", emailContent);
	}

	private String generateRandomToken() {
		int min = 100000;
		int max = 999999;
		Random random = new Random();

		return String.valueOf(random.nextInt(max - min + 1) + min);
	}

	public static String decryptPassword(String encryptedPassword) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public static String decryptOTPToken(String resetToken) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getUrlDecoder().decode(resetToken));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public String decryptData(String encryptedPassword, String AES_KEY) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

	public static String encryptPassword(String token) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);

	}

	public static String encryptOtp(String token) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getUrlEncoder().encodeToString(encryptedBytes);
	}

	@Override
	public String verifyResetToken(String email, String resetToken) throws Exception {
		try {
			BpmnUser user = bpmnUserRepository.findByEmail(email);
			if (user != null) {
				String decryptedResetToken = decryptOTPToken(resetToken);

				if (decryptedResetToken.equals(user.getResettoken())) {

					return "Reset code verified";

				} else {
					throw new Exception("Reset Token mismatched");
				}
			} else {
				throw new Exception("Invalid user");
			}
		} catch (Exception e) {
			throw new Exception("Reset  link expired while reset password");
		}
	}

	@Transactional
	public void updateUserInfo(Long userId, String firstname, String lastname, String role, String mobileno,
			String imgname, String imgcontent, String organization) {
		BpmnUser bpmnUser = bpmnUserRepository.findById(userId)
				.orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));
		bpmnUser.setFirstname(firstname);
		bpmnUser.setLastname(lastname);
		bpmnUser.setRole(role);
		bpmnUser.setMobileno(mobileno);
		bpmnUser.setImgname(imgname);
		bpmnUser.setImgcontent(imgcontent);
		bpmnUser.setOrganization(organization);

		bpmnUserRepository.save(bpmnUser);
	}

	@Override
	public Role createRole(Role role) throws Exception {
		log.debug("BpmnUserServiceImpl::createRole::Request {}", role);
		Role existrole = roleRepository.findByRole(role.getRoleName());
		Role responseRole = null;
		try {
			if (existrole == null)
				responseRole = roleRepository.save(role);
			else
				throw new Exception("Role already exist");
		} catch (Exception e) {
			throw new RuntimeException("Failed to create role: " + e.getMessage());
		}
		return responseRole;
	}

	@Override
	public List<RoleResponseDTO> getAllRolesByOrganization(String organization) {
		try {
			LicenseValidation licenceDetails = licenseValidationRepository.findByOrganization(organization);
			// List<RoleJoinQueryDTO> object =
			// roleRepository.findAllByOrganizationAndLicense(organization);
			String editorCount = decryptData(licenceDetails.getEditors(), LicenseServiceImpl.AES_EDITOR);
			String viewerCount = decryptData(licenceDetails.getViewers(), LicenseServiceImpl.AES_VIEWER);
			String reviewerCount = decryptData(licenceDetails.getReviewers(), LicenseServiceImpl.AES_REVIEWER);

			List<Role> data = roleRepository.findAll();

			List<RoleResponseDTO> response = new ArrayList<>();

			for (Role body : data) {
				switch (body.getRoleName()) {
					case UtilsConstants.RoleConstants.EDITOR:
						response.add(mapToDto(body, editorCount));
						break;
					case UtilsConstants.RoleConstants.VIEWER:
						response.add(mapToDto(body, viewerCount));
						break;
					case UtilsConstants.RoleConstants.REVIEWER:
						response.add(mapToDto(body, reviewerCount));
						break;
					default:
						break;
				}
			}
			return response;
			// return roleRepository.findAll();
		} catch (Exception e) {
			throw new RuntimeException("Failed to retrieve roles from the database", e);
		}
	}

	@Transactional
	@Override
	public Role deleteRole(Long id) throws Exception {
		try {
			Optional<Role> roleOptional = roleRepository.findById(id);
			if (roleOptional.isPresent()) {
				Role role = roleOptional.get();
				roleRepository.delete(role);

				if (roleRepository.existsById(id)) {
					throw new Exception("Role with ID " + id + " still exists in the database after deletion");
				}

				return null;
			} else {
				throw new Exception("Role with ID " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> UpdateRole(Role role) throws Exception {

		Map<String, Object> UpdatedResponse = new HashMap<>();

		Role roles = roleRepository.getById(role.getId());
		try {
			if (roles != null) {

				Role saveUpdate = roleRepository.save(role);
				UpdatedResponse.put("id", saveUpdate.getId());
				UpdatedResponse.put("rolename", saveUpdate.getRoleName());
				UpdatedResponse.put("description", saveUpdate.getRoleDescription());
			} else
				throw new Exception("Role Id not found");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return UpdatedResponse;
	}

	public RoleResponseDTO mapToDto(Role role, String value) {

		RoleResponseDTO dto = new RoleResponseDTO();
		dto.setId(role.getId());
		dto.setRoleName(role.getRoleName());
		dto.setRoleDescription(role.getRoleDescription());
		dto.setOrganization(role.getOrganization());
		dto.setLimit(value);
		return dto;
	}

	@Override
	@Transactional
	public void changeTemporaryPassword(Map<String, String> requestPayload) {
		Long userId = Long.parseLong(requestPayload.get("userId").toString());
		String newPassWord = requestPayload.get("newPassword");
		BpmnUser bpmnUser = bpmnUserRepository.findByUserId(userId);
		if (bpmnUser != null) {
			try {
				String decrpytTempPassword = decryptPassword(bpmnUser.getPassword());
				if (decrpytTempPassword.equals(requestPayload.get("tempPassword"))) {
					String updatePassword = encryptPassword(newPassWord);
					bpmnUser.setPassword(updatePassword);
					bpmnUser.setFirstLogin(false);
					bpmnUser.setIsLogin(false);
					bpmnUserRepository.saveAndFlush(bpmnUser);
				}
				else{
					throw new Exception("Entered temporary password is wrong");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println("Error updating password for user ID: " + userId);
			}
		} else {
			System.err.println("User not found with ID: " + userId);
		}
	}

	@Override
	public void changeNewPassword(Map<String, String> requestPayload) throws Exception {
		Long userId = Long.parseLong(requestPayload.get("userId").toString());
		String oldPassword = requestPayload.get("oldPassword").toString();
		String newPassWord = requestPayload.get("newPassword");
		BpmnUser bpmnUser = bpmnUserRepository.findByUserId(userId);
		if (bpmnUser != null) {
			try {

				String decryptOldPassword = decryptPassword(bpmnUser.getPassword());
				if (decryptOldPassword.equals(oldPassword)) {
					String updateNewPassword = encryptPassword(newPassWord);
					bpmnUserRepository.updateNewPassWord(userId, updateNewPassword);
				} else {
					throw new Exception("Entered current password is wrong");
				}

			} catch (Exception e) {
				System.err.println("Error updating password for user ID: " + userId);
				throw new Exception(e.getMessage());
			}
		} else {
			System.err.println("User not found with ID: " + userId);
		}
	}

	@Override
	public ResponseEntity<?> getUserCustomersAndProjects(Long userId) {
		try {
			Optional<BpmnUser> userData = bpmnUserRepository.findById(userId);
			if (!userData.isPresent()) {
				return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
			}
			BpmnUser user = userData.get();

			UserCustomerProjectDTO dto = new UserCustomerProjectDTO();
			dto.setUserId(user.getUserid());
			dto.setUsername(user.getFirstname() + " " + user.getLastname());
			List<ProjectDTO> projectDTOs = user.getProjects().stream()
					.map(project -> {
						ProjectDTO projectDTO = new ProjectDTO();
						projectDTO.setId(project.getId());
						projectDTO.setProjectName(project.getProjectName());
						return projectDTO;
					})
					.collect(Collectors.toList());
			dto.setProjects(projectDTOs);

			List<CustomerDTO> customerDTOs = user.getCustomers().stream()
					.map(customer -> {
						CustomerDTO customerDTO = new CustomerDTO();
						customerDTO.setId(customer.getId());
						customerDTO.setCustomerName(customer.getCustomerName());
						return customerDTO;
					})
					.collect(Collectors.toList());
			dto.setCustomers(customerDTOs);

			return new ResponseEntity<>(dto, HttpStatus.OK);
		} catch (Exception e) {
			log.info("error in getUserCustomersAndProjects", e.getMessage());
			return null;

		}
	}

	public List<ProjectDTO> getAssignedProjectsForUser(Long userId) {
		try {
			BpmnUser user = bpmnUserRepository.findById(userId)
					.orElseThrow(() -> new Exception("User not found with id: " + userId));
			return user.getProjects().stream()
					.map(project -> {
						ProjectDTO dto = new ProjectDTO();
						dto.setId(project.getId());
						dto.setProjectName(project.getProjectName());
						dto.setCustomerId(project.getCustomer().getId());
						dto.setCustomerName(project.getCustomer().getCustomerName());
						return dto;
					})
					.collect(Collectors.toList());
		} catch (Exception e) {
			log.info("error in getAssignedProjectsForUser", e.getMessage());
			return null;
		}

	}

	public List<CustomerDTO> getAssignedCustomersForUser(Long userId) {
		try {
			BpmnUser user = bpmnUserRepository.findById(userId)
					.orElseThrow(() -> new Exception("User not found with id: " + userId));

			return user.getCustomers().stream().map(customer -> {
				CustomerDTO dto = new CustomerDTO();
				dto.setId(customer.getId());
				dto.setCustomerName(customer.getCustomerName());
				return dto;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.info("error in getAssignedCustomersForUser", e.getMessage());
			return null;
		}

	}

	@Override
	public Map<String, String> findUserDetails(Long userId) throws Exception {
		
		Map<String,String> response = new HashMap<String, String>();
		try {
			BpmnUser bpmnUser = bpmnUserRepository.findByUserId(userId);
		if(bpmnUser!= null) {
		
		
		response.put("userId", String.valueOf(bpmnUser.getUserid()));
		response.put("firstName",bpmnUser.getFirstname());
		response.put("lastName", bpmnUser.getLastname());
		response.put("email", bpmnUser.getEmail());
		response.put("organization", bpmnUser.getOrganization());
		}
		else 
			throw new Exception("User not found with Id: "+userId);
		}catch(Exception e) {
			
			throw new Exception(e.getMessage());
		}
		
		return response;
	}
}
