package com.igosolutions.uniSync.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.igosolutions.uniSync.Modal.AssignedUser;
import com.igosolutions.uniSync.Modal.ProjectDTO;

public class ReviewDiagrammeResponse {

	private Long id;
	private Map<String, Object> diagramXmlIds = new HashMap<>();
	private List<AssignedUser> assignedUsers;
	private String author;
	private String authorUserId;
	private String diagramName;
	private String mapPrivacyType;
	private String organization;
	private List<MapAuthorizedUser> mapAuthorizedUsers;
	private ProjectDTO project;
	private String docStorageType;
	private String configName;
	private String configId;
	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	// Nested class to hold version and diagramXmlId information
	public static class DiagramXmlIdInfo {
		private Double version;
		private int diagramXmlId;
		private String status; 

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		// Getters and Setters
		public Double getVersion() {
			return version;
		}

		public void setVersion(Double version) {
			this.version = version;
		}

		public int getDiagramXmlId() {
			return diagramXmlId;
		}

		public void setDiagramXmlId(int diagramXmlId) {
			this.diagramXmlId = diagramXmlId;
		}
	}

	// Nested class to hold authorized user details
	public static class MapAuthorizedUser {
		private int userId;
		private String email;
		private String name;

		// Constructor
		public MapAuthorizedUser(int userId, String email, String name) {
			this.userId = userId;
			this.email = email;
			this.name = name;
		}

		// Getters and Setters
		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}

	public String getDocStorageType() {
		return docStorageType;
	}

	public void setDocStorageType(String docStorageType) {
		this.docStorageType = docStorageType;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

	// Getters and Setters for ReviewDiagrammeResponse class fields
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Map<String, Object> getDiagramXmlIds() {
		return diagramXmlIds;
	}

	public void setDiagramXmlIds(Map<String, Object> diagramXmlIdsMap) {
		this.diagramXmlIds = diagramXmlIdsMap;
	}


	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthorUserId() {
		return authorUserId;
	}

	public void setAuthorUserId(String authorUserId) {
		this.authorUserId = authorUserId;
	}

	public String getDiagramName() {
		return diagramName;
	}

	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}

	public String getMapPrivacyType() {
		return mapPrivacyType;
	}

	public void setMapPrivacyType(String mapPrivacyType) {
		this.mapPrivacyType = mapPrivacyType;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public List<MapAuthorizedUser> getMapAuthorizedUsers() {
		return mapAuthorizedUsers;
	}

	public void setMapAuthorizedUsers(List<MapAuthorizedUser> mapAuthorizedUsers) {
		this.mapAuthorizedUsers = mapAuthorizedUsers;
	}

	public ProjectDTO getProject() {
		return project;
	}

	public void setProject(ProjectDTO project) {
		this.project = project;
	}

	public List<AssignedUser> getAssignedUsers() {
		return assignedUsers;
	}

	public void setAssignedUsers(List<AssignedUser> assignedUsers) {
		this.assignedUsers = assignedUsers;
	}

	@Override
	public String toString() {
		return "ReviewDiagrammeResponse [id=" + id + ", diagramXmlIds=" + diagramXmlIds + ", assignedUsers="
				+ assignedUsers + ", author=" + author + ", authorUserId=" + authorUserId + ", diagramName="
				+ diagramName + ", mapPrivacyType=" + mapPrivacyType + ", organization=" + organization
				+ ", mapAuthorizedUsers=" + mapAuthorizedUsers + ", project=" + project + ", docStorageType="
				+ docStorageType + ", configName=" + configName + ", configId=" + configId + ", errorMessage="
				+ errorMessage + "]";
	}
	
	
	

}
