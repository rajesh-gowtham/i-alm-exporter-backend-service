package com.igosolutions.uniSync.constants;

public enum UserRole {
    REVIEWER("Reviewer"),
    ADMIN("Admin"),
    VIEWER("Viewer"),
    EDITOR("Editor");

    private final String role;

    UserRole(String role){
        this.role = role;
    }

    public String getRole(){
        return role;
    }
}
