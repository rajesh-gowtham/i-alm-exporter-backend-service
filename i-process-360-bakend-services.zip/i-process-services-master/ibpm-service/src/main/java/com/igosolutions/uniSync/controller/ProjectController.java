package com.igosolutions.uniSync.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Respository.BPMNRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.Service.ProjectService;
import com.igosolutions.uniSync.exceptions.ProjectAssignedToUserException;
import com.igosolutions.uniSync.exceptions.UserNotFoundException;

@RestController
@RequestMapping("/projects")
public class ProjectController {
    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private BPMNRepository bpmnRepository;

    @GetMapping("/getAllProjects")
    public ResponseEntity<?> getAllProjects() {
        try {
            List<Project> allProjects = projectRepository.findAll();
            List<ProjectDTO> projectDTOs = new ArrayList<ProjectDTO>();
            for (Project project : allProjects) {
                ProjectDTO projectDto = new ProjectDTO();
                projectDto.setId(project.getId());
                projectDto.setProjectName(project.getProjectName());
                projectDto.setCustomerId(project.getCustomer().getId());
                projectDto.setCustomerName(project.getCustomer().getCustomerName());
                projectDTOs.add(projectDto);
            }
            return ResponseEntity.ok(projectDTOs);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while fetching all projects.");
        }

    }

    @GetMapping("/getProjectById/{id}")
    public ResponseEntity<?> getProjectById(@PathVariable Long id) {
        try {
            ProjectDTO projectDto = new ProjectDTO();
            Optional<Project> projectOptional = projectRepository.findById(id);
            Project project;
            if (projectOptional.isPresent()) {
                project = projectOptional.get();
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found");
            }
            projectDto.setId(project.getId());
            projectDto.setProjectName(project.getProjectName());
            projectDto.setCustomerId(project.getCustomer().getId());
            projectDto.setCustomerName(project.getCustomer().getCustomerName());
            return ResponseEntity.ok(projectDto);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while fetching the projects.");
        }
    }

    @PostMapping("/createProject")
    public ResponseEntity<?> createProject(@RequestBody ProjectDTO projectDTO) {
        return projectService.createProject(projectDTO);
    }

    @PutMapping("/updateProject/{id}")
    public ResponseEntity<?> updateProject(@PathVariable Long id, @RequestBody ProjectDTO projectDTO) {
        try {
            return projectRepository.findById(id)
                    .map(existingProject -> {
                        // if (existingProject.getBpmnUsers() != null &&
                        // !existingProject.getBpmnUsers().isEmpty()) {
                        // throw new ProjectAssignedToUserException(
                        // "Project with name " + existingProject.getProjectName()
                        // + " is assigned to a user and cannot be updated.");
                        // }
                        existingProject.setProjectName(projectDTO.getProjectName());
                        // Assuming Customer has already been set in the ProjectDTO
                        existingProject.getCustomer().setId(projectDTO.getCustomerId());

                        Project updatedProject = projectRepository.save(existingProject);
                        ProjectDTO projectDto = new ProjectDTO();
                        projectDto.setId(updatedProject.getId());
                        projectDto.setProjectName(updatedProject.getProjectName());
                        projectDto.setCustomerId(updatedProject.getCustomer().getId());
                        projectDto.setCustomerName(updatedProject.getCustomer().getCustomerName());
                        return ResponseEntity.ok(projectDto);
                    })
                    .orElse(ResponseEntity.notFound().build());
        } catch (ProjectAssignedToUserException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while updating the project.");
        }
    }

    @DeleteMapping("/deleteProject/{id}")
    public ResponseEntity<?> deleteProject(@PathVariable Long id) {
        try {
            return projectRepository.findById(id)
                    .map(existingProject -> {
                        if (existingProject.getBpmnUsers() != null && !existingProject.getBpmnUsers().isEmpty()) {
                            throw new ProjectAssignedToUserException(
                                    "Project with name " + existingProject.getProjectName()
                                            + " is assigned to a user and cannot be deleted.");
                        }
                        List<Bpmn> bpmnData = bpmnRepository.findByProjectId(existingProject.getId());
                        if(!bpmnData.isEmpty()) {
                            throw new ProjectAssignedToUserException(
                                    "Project with name " + existingProject.getProjectName()
                                            + " is having Published Maps so it cannot be deleted.");
                        }

                        projectRepository.delete(existingProject);
                        return ResponseEntity.noContent().build();
                    })
                    .orElse(ResponseEntity.notFound().build());
        } catch (ProjectAssignedToUserException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while deleting the project.");
        }

    }

    @GetMapping("/getProjectsByUserId/{userId}")
    public ResponseEntity<?> getProjectsByUserId(@PathVariable Long userId) {
        try {
            return projectService.getProjectsByUserId(userId);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while retrieving the project for users.");
        }

    }

    @GetMapping("/getUsersByProjectId/{projectId}")
    public ResponseEntity<?> getUsersByProjectId(@PathVariable Long projectId) {
        return projectService.getUsersByProjectId(projectId);
    }

}
