package com.igosolutions.uniSync.Modal;

import java.util.List;

public class MapDiagramRequestDTO {
	    private String diagramName;
	    private int diagramXmlId;
	    private String docStorageType;
	    private String configName;
	    private String configId;
	    private String mapPrivacyType;
	    private String template;
		private String languageName;
		private String languageCode;
	    
	    private String xmlData;
	    private List<MapAuthorizedUser> mapAuthorizedUsers;
		private ProjectDTO project;

	    public String getTemplate() {
			return template;
		}

		public void setTemplate(String template) {
			this.template = template;
		}

		public String getLanguageName() {
			return languageName;
		}

		public void setLanguageName(String languageName) {
			this.languageName = languageName;
		}

		public String getLanguageCode() {
			return languageCode;
		}

		public void setLanguageCode(String languageCode) {
			this.languageCode = languageCode;
		}

		// Getters and setters
	    public String getDiagramName() {
	        return diagramName;
	    }

	    public void setDiagramName(String diagramName) {
	        this.diagramName = diagramName;
	    }

	    
	    public int getDiagramXmlId() {
			return diagramXmlId;
		}

		public void setDiagramXmlId(int diagramXmlId) {
			this.diagramXmlId = diagramXmlId;
		}

		public String getDocStorageType() {
	        return docStorageType;
	    }

	    public void setDocStorageType(String docStorageType) {
	        this.docStorageType = docStorageType;
	    }

	    public String getConfigName() {
	        return configName;
	    }

	    public void setConfigName(String configName) {
	        this.configName = configName;
	    }

	    public String getConfigId() {
	        return configId;
	    }

	    public void setConfigId(String configId) {
	        this.configId = configId;
	    }

	    public String getMapPrivacyType() {
	        return mapPrivacyType;
	    }

	    public void setMapPrivacyType(String mapPrivacyType) {
	        this.mapPrivacyType = mapPrivacyType;
	    }

	    public String getXmlData() {
			return xmlData;
		}

		public void setXmlData(String xmlData) {
			this.xmlData = xmlData;
		}

		public List<MapAuthorizedUser> getMapAuthorizedUsers() {
	        return mapAuthorizedUsers;
	    }

	    public void setMapAuthorizedUsers(List<MapAuthorizedUser> mapAuthorizedUsers) {
	        this.mapAuthorizedUsers = mapAuthorizedUsers;
	    }
		

	    // Inner class for MapAuthorizedUser
	    public static class MapAuthorizedUser {
	        private int userId;

	        public int getUserId() {
	            return userId;
	        }

	        public void setUserId(int userId) {
	            this.userId = userId;
	        }
	    }


		public ProjectDTO getProject() {
			return project;
		}

		public void setProject(ProjectDTO project) {
			this.project = project;
		}

}
