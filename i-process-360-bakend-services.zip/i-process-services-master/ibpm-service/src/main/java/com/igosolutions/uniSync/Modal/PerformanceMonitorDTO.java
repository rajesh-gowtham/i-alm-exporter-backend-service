package com.igosolutions.uniSync.Modal;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "performanceMonitor")
public class PerformanceMonitorDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "monitor_id")
	private Long monitorId;
	
	@Column(name = "api_name")
	private String apiName;
	
	@Column(name = "time_taken")
	private long timeTaken;
	
	@Column(name = "timestamp")
	private LocalDateTime timestamp;

	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public long getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(long timeTaken) {
		this.timeTaken = timeTaken;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	
}
