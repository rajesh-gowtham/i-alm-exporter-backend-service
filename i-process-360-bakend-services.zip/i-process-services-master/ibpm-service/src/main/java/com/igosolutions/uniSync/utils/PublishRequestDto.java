package com.igosolutions.uniSync.utils;

public class PublishRequestDto {
	
	private Long mapId;
	private Long diagramXmlId;
	private String diagramName;
    private String assignedUser;
    private int assignedUserId;
    private String status;
    private String reviewXmlData;
    private String author;
    private String authorUserId;
    private String languageCode;
    private String languageName;
    private Long publishedBy;
	public Long getMapId() {
		return mapId;
	}
	public void setMapId(Long mapId) {
		this.mapId = mapId;
	}
	public Long getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(Long diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	public String getAssignedUser() {
		return assignedUser;
	}
	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}
	public int getAssignedUserId() {
		return assignedUserId;
	}
	public void setAssignedUserId(int assignedUserId) {
		this.assignedUserId = assignedUserId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReviewXmlData() {
		return reviewXmlData;
	}
	public void setReviewXmlData(String reviewXmlData) {
		this.reviewXmlData = reviewXmlData;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthorUserId() {
		return authorUserId;
	}
	public void setAuthorUserId(String authorUserId) {
		this.authorUserId = authorUserId;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	public Long getPublishedBy() {
		return publishedBy;
	}
	public void setPublishedBy(Long publishedBy) {
		this.publishedBy = publishedBy;
	}
    
    
}
