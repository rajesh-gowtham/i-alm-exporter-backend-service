package com.igosolutions.uniSync.utils;

import java.util.List;

public class SaveReviewerRequestDto {
	
	private int diagramXmlId;
	private String status;
    private List<Integer> assignedUserIds;
    private String diagramName;
    private String authorUserId;
    
//    private String assignedUser;
//    private String author;
//    private String languageName;
//    private String languageCode;
//    private String mapPrivacyType;
//    private String organization;
//    private String timeStamp;
//    private String reviewXmlData;
    
    
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public String getAuthorUserId() {
		return authorUserId;
	}
	public void setAuthorUserId(String authorUserId) {
		this.authorUserId = authorUserId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	public List<Integer> getAssignedUserIds() {
		return assignedUserIds;
	}
	public void setAssignedUserIds(List<Integer> assignedUserIds) {
		this.assignedUserIds = assignedUserIds;
	}
	@Override
	public String toString() {
		return "SaveReviewerRequestDto [diagramXmlId=" + diagramXmlId + ", status=" + status + ", assignedUserIds="
				+ assignedUserIds + ", diagramName=" + diagramName + ", authorUserId=" + authorUserId + "]";
	}
	
	

}
