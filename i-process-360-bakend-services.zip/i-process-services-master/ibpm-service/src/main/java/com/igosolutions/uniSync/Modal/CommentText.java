package com.igosolutions.uniSync.Modal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CommentText {
    private String id;
    @JsonProperty("nameText")
    private String nameText;

    // Getters and setters

    public String getId() {
        return id;
    }

	public void setId(String id) {
        this.id = id;
    }

    public String getNameText() {
        return nameText;
    }

    public void setNameText(String nameText) {
        this.nameText = nameText;
    }
}
