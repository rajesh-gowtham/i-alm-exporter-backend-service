package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.ReviewComments;

public interface CommentsRepository extends JpaRepository<ReviewComments, Long> {

	@Query("SELECT rc FROM ReviewComments rc WHERE rc.diagramXmlId = :diagramXmlId ORDER BY rc.timeStamp ASC")
	List<ReviewComments> findByDiagramXmlIdOrderByTimeStampAscWithRole(@Param("diagramXmlId")int diagramXmlId);
	
	@Query("SELECT rc FROM ReviewComments rc WHERE rc.diagramXmlId = :diagramXmlId ORDER BY rc.timeStamp ASC")
	List<ReviewComments> findByDiagramXmlIdOrderByTimeStampAsc(@Param("diagramXmlId")int diagramXmlId);

	@Query("SELECT dc FROM ReviewComments dc WHERE dc.diagramXmlId = :diagramXmlId ORDER BY dc.timeStamp DESC")
	List<ReviewComments> findByDiagramXmlIdOrderByTimeStampDesc(int diagramXmlId);  
	
	@Transactional
    @Modifying
    @Query("update ReviewComments s set s.mapDiagramStatus = :mapDiagramStatus where s.diagramXmlId = :diagramXmlId")
    void updateStatus(@Param("diagramXmlId") int diagramXmlId,@Param("mapDiagramStatus") String mapDiagramStatus);
	
	@Query("SELECT dc FROM ReviewComments dc WHERE dc.commentId = :commentId")
	ReviewComments findByCommentId(@Param("commentId") Long commentId);

	//deleting all comments by diagramXmlIds
	@Transactional
	@Modifying
	@Query("DELETE FROM ReviewComments b WHERE b.diagramXmlId IN :diagramXmlIds")
	void deleteByDiagramXmlIds(@Param("diagramXmlIds") List<Integer> diagramXmlIds);

	@org.springframework.transaction.annotation.Transactional
	@Modifying
    void deleteByDiagramXmlIdIn(List<Integer> diagramXmlIds);

	@Transactional
	@Modifying
	@Query("DELETE FROM ReviewComments d WHERE d.diagramXmlId IN :diagramXmlId AND d.commentedUserId IN :commentedUserId")
	void deleteByDiagramXmlIdAndUserId(@Param("diagramXmlId")Integer diagramXmlId, @Param("commentedUserId")Long commentedUserId);


	

	
	
}
