package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTO;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTOResponse;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.ReviewDiagrammeDTO;
import com.igosolutions.uniSync.utils.ReviewDiagrammeResponse;
import com.igosolutions.uniSync.utils.SaveReviewerRequestDto;
import com.igosolutions.uniSync.utils.PublishRequestDto;

public interface BpmnMapReviewService {


	public MapDiagramRequestDTOResponse createMapResponse(BpnmUserDiagramme response, ReviewDiagramme reviewDiagramme);

	public ReviewDiagramme createInitiaDraft(Long userId, int diagramXmlId, String status, String author, MapDiagramRequestDTO mapDiagramRequestDTO);

	public List<ReviewDiagrammeResponse> getBpmnDiagrmByUserId(String userId, Map<String, String> headers);


	public ReviewDiagrammeResponse saveReviewerData(SaveReviewerRequestDto saveReviewerRequestDto);

	
	List<Map<String, Object>> getAllPublishedDiagrams(String organization);
	
	public void deleteMapDiagrams(Long userId, List<ReviewDiagrammeDTO> requestPayload);
	
	void publishedDiagram(PublishRequestDto publishRequestDto, String organization) throws Exception;
	
	ResponseEntity<?> revokeToDraftDiagram(long mapId, int diagramXmlId, String xmlData);

    public ResponseEntity<?> deleteUnlockedDraft(long mapId);
}
