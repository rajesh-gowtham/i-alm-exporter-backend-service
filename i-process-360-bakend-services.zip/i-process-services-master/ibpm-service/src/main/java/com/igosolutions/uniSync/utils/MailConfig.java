package com.igosolutions.uniSync.utils;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class MailConfig {

    @Bean
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
       // mailSender.setHost("igosolutions-eu.mail.protection.outlook.com");
        //d327716.o.ess.de.barracudanetworks.com
        mailSender.setHost("d327716.o.ess.de.barracudanetworks.com");
        mailSender.setPort(587);
//        mailSender.setUsername("selvakumar.r@igosolutions.eu");
//        mailSender.setPassword("selva@1209igo");
        
        mailSender.setUsername("donotreply-IGOIBPM@igosolutions.eu");
        mailSender.setPassword("no@need");
        
        
        
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true"); // Enable authentication
        props.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
        props.put("mail.smtp.starttls.required", "true"); // Enforce STARTTLS
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        props.put("mail.debug", "true");
        props.put("mail.smtp.connectiontimeout", "60000");
        props.put("mail.smtp.timeout", "60000");
        props.put("mail.smtp.writetimeout", "60000");

        return mailSender;
    }
   
}
