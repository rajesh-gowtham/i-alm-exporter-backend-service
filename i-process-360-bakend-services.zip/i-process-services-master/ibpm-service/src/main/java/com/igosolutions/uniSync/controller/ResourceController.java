package com.igosolutions.uniSync.controller;

import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Resource;
import com.igosolutions.uniSync.Service.ResourceService;
import com.igosolutions.uniSync.utils.HeaderUtil;
@RestController
public class ResourceController {

	@Autowired
	public ResourceService  resourceService;
	
    Logger log = LoggerFactory.getLogger(ResourceController.class);
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/createResource",method = RequestMethod.POST) 
	public ResponseEntity<Object> createUser(@RequestBody Resource resource, @RequestHeader Map<String,String> headers) {
		log.debug("Request {}", resource);
		try {
			String userId = HeaderUtil.getUserId(headers);
			String organization = HeaderUtil.getOrganization(headers);
			Map<String, String> addResource = resourceService.addResource(resource,Long.parseLong(userId),organization);
            log.debug("Response {}",addResource);
			return new ResponseEntity<>(addResource, HttpStatus.CREATED);

		} catch (Exception e) {

			if("Resource name already exist".equals(e.getMessage()) || "User not exist".equals(e.getMessage())) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/resources/viewResourceDetails", method = RequestMethod.GET)
	public ResponseEntity<List<Object>> getAllUsers(@RequestHeader Map<String,String> headers) {
        log.debug("Request {}");
		try {
			String org = HeaderUtil.getOrganization(headers);
			List<Object> allResource = resourceService.getAllResource(org);
			// log.debug("Response {}",allResource);
			return new ResponseEntity<>(allResource,HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/deleteResource/{id}",method = RequestMethod.DELETE) 
	public ResponseEntity<Object> deleteUser(@PathVariable Long id) {
		log.debug("Request {}", id);
		try {
			Resource deletedUser = resourceService.deleteUser(id);
			if (deletedUser == null) {
				log.debug("Response {}","Resource deleted successfully");
				return new ResponseEntity<>("Resource deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","Resource not found");
				return new ResponseEntity<>("Resource not found", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			if(e.getMessage().equals("Resource not exist")){
				return new ResponseEntity<>("Resource not found", HttpStatus.NOT_FOUND);
			}
			else {
				e.printStackTrace();
				return new ResponseEntity<>("An error occurred during delete the Resource: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/resources/editResource",method = RequestMethod.POST) 
	public ResponseEntity<Object> updateUser(@RequestBody Resource resource, @RequestHeader Map<String, String> headers) {
		log.debug("Request {}", resource);
		
		String org = HeaderUtil.getOrganization(headers);
		try {
			Map<String,String> editResource = resourceService.addEditUsers(resource,org);
			log.debug("Response {}",editResource);
			return new ResponseEntity<>(editResource,HttpStatus.OK);

		} catch (Exception e) {
			if(e.getMessage().equals("Resource not exist")) {
				e.printStackTrace();
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
	
}
