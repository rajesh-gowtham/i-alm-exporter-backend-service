package com.igosolutions.uniSync.audit;

import com.igosolutions.uniSync.Modal.AuditModel;

public interface Auditable {

	AuditModel getAudit();

	void setAudit(AuditModel audit);

}
