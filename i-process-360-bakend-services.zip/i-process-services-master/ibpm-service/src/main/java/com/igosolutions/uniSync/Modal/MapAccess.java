package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Audited
@Table(name ="map_access")
public class MapAccess {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="specified_user")
	private int specificUser;
	
	@Column(name = "diagram_xml_id")
	private int diagramXmlId;
	
	@ManyToOne
	@JoinColumn(name ="map_id", nullable = true)
	private ReviewDiagramme reviewDiagramme;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public ReviewDiagramme getReviewDiagramme() {
		return reviewDiagramme;
	}
	public void setReviewDiagramme(ReviewDiagramme reviewDiagramme) {
		this.reviewDiagramme = reviewDiagramme;
	}
	public int getSpecificUser() {
		return specificUser;
	}
	public void setSpecificUser(int specificUser) {
		this.specificUser = specificUser;
	}
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	@Override
	public String toString() {
		return "MapAccess [id=" + id + ", specificUser=" + specificUser + ", diagramXmlId=" + diagramXmlId
				+ ", reviewDiagramme=" + reviewDiagramme + "]";
	}
	
	

}
