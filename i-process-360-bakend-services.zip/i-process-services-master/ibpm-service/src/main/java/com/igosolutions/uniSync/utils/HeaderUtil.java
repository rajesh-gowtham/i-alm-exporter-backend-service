package com.igosolutions.uniSync.utils;

import java.util.Map;

public class HeaderUtil {
    private HeaderUtil(){

    }
    public static String getOrganization(Map<String, String> headers){
        return headers.get("organization");
    }
    public static String getUserId(Map<String, String> headers){
        return headers.get("userid");
    }
    public static String getLwssoCookie(Map<String, String> headers){
        return headers.get("lwssocookie");
    }
    public static String getXsrfHeaderValue(Map<String, String> headers){
        return headers.get("xsrfheadervalue");
    }
    public static String getAlmHostedUrl(Map<String, String> headers){
        return headers.get("almhostedurl");
    }
    public static String getCookies(Map<String, String> headers){
        return headers.get("cookies");
    }
}
