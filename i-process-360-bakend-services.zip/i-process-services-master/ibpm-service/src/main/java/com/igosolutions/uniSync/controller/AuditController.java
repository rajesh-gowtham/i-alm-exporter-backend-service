package com.igosolutions.uniSync.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.AuditTrail;
import com.igosolutions.uniSync.Modal.AuditTrailDetail;
import com.igosolutions.uniSync.Modal.AuditTrailDetailDTO;
import com.igosolutions.uniSync.Modal.AuditTrailRequest;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.AuditTrailRepository;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Service.AuditTrailService;
import com.igosolutions.uniSync.utils.HeaderUtil;

@RestController
@RequestMapping("/api")
 public class AuditController {
   
    @Autowired
    AuditTrailRepository auditTrailRepository;

    @Autowired
	BpmnUserRepository bpmnUserRepository;
    
    @Autowired
    private AuditTrailService auditTrailService;
    
    // Method to retrieve audit trail records
    // @RequestMapping(value = "/auditTrail", method = RequestMethod.GET)
    // public List<AuditTrail> getAllAuditTrail() {
    //     return auditTrailRepository.findAll();
    // }

    @RequestMapping(value = "/auditTrail/{userId}", method = RequestMethod.GET)
    public List<AuditTrail> getAuditTrailForUserById(@PathVariable String userId) {
        return auditTrailRepository.findByEntityId(userId);
    }

    @RequestMapping(value = "/auditTrail", method = RequestMethod.POST)
    public ResponseEntity<List<AuditTrail>> getAuditTrails(@RequestBody AuditTrailRequest auditTrailRequest) {

        List<AuditTrail> auditTrails = auditTrailService.getAuditTrails(auditTrailRequest.getEntityId(), auditTrailRequest.getStartDate(), auditTrailRequest.getEndDate());
        return ResponseEntity.ok(auditTrails);
    }
    
    @RequestMapping(value = "/auditTrail/setAuditinsideMap/{mapId}", method = RequestMethod.POST)
    public ResponseEntity<?> getAuditTrails(@PathVariable String mapId, @RequestBody List<AuditTrailDetailDTO> auditTrailDetailDTO, @RequestHeader Map<String, String> headers) {
//    	
    	String org = HeaderUtil.getOrganization(headers);
    	String userId = HeaderUtil.getUserId(headers);
    	BpmnUser user = bpmnUserRepository.getById(Long.valueOf(userId));
    	
    	AuditTrail auditTrail = new AuditTrail();
    	auditTrail.setChangedAt(LocalDateTime.now());
    	auditTrail.setChangedBy(user.getFirstname()+" "+user.getLastname());
    	
    	auditTrail.setEntityId(mapId);
    	auditTrail.setEntityName("InsideDaigram");
    	auditTrail.setModificationType("Update");
    	auditTrail.setOrganization(org);
    	
    	List<AuditTrailDetail> auditTrailDetails = new ArrayList<>();
    	for(AuditTrailDetailDTO auditTrailDetail  : auditTrailDetailDTO) {
    		AuditTrailDetail obj = new AuditTrailDetail();
    		obj.setFieldName(auditTrailDetail.getField());
    		obj.setNewValue(auditTrailDetail.getNewValue());
    		obj.setOldValue(auditTrailDetail.getOldValue());
    		obj.setAuditTrail(auditTrail);
    		
    		auditTrailDetails.add(obj);
    	}
    	
    	auditTrail.setDetails(auditTrailDetails);
    	
    	auditTrailRepository.save(auditTrail);
    	
    	return new ResponseEntity<>(HttpStatus.OK);
    }
 }
