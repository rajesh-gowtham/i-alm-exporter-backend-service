package com.igosolutions.uniSync.ServiceImpl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.Resource;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.ResourceRepository;
import com.igosolutions.uniSync.Service.ResourceService;

@Service
public class ResourceServiceImpl implements ResourceService {

	@Autowired
    private ResourceRepository resourceRepository;
	
	@Autowired
    private BpmnUserRepository bpmnUserRepository;

	@Override
	public Map<String, String> addResource(Resource resource, Long userId ,String organization) throws Exception {
		Resource findByName = resourceRepository.findByName(resource.getResourceName(),organization);
		Optional<BpmnUser> bpmnUser = bpmnUserRepository.findById(userId);
		if(bpmnUser.isPresent()){
			Map<String, String> response = new LinkedHashMap<>();
			if(findByName == null) {
				resource.setOrganization(bpmnUser.get().getOrganization());
				Resource newResource = resourceRepository.save(resource);
				
				response.put("id", String.valueOf(newResource.getId()));
				response.put("resourceName", newResource.getResourceName());
				response.put("displayName", newResource.getDisplayName());
				response.put("infoField1", newResource.getInfoField1());
				response.put("infoField2", newResource.getInfoField2());
				response.put("type", newResource.getType());
				response.put("organization", newResource.getOrganization());
				response.put("resourceColor", newResource.getResourceColor());
				return response;
			}
			else {
				throw new Exception("Resource name already exist");
			}
		}
		else{
			throw new Exception("User not exist");
		}
	}

	@Override
	public List<Object> getAllResource(String org) throws Exception {
		
		List<Resource> bpmnResource = resourceRepository.getAllResource(org);
		List<Object> allUsers = bpmnResource.stream().map(user -> {
		    Map<String, String> userResponse = new HashMap<>();
		    userResponse.put("id", String.valueOf(user.getId()));
		    userResponse.put("resourceName", user.getResourceName());
		    userResponse.put("displayName", user.getDisplayName());
		    userResponse.put("infoField1", user.getInfoField1());
		    userResponse.put("infoField2", user.getInfoField2());
		    userResponse.put("type", user.getType());
			userResponse.put("resourceColor", user.getResourceColor());
		    return userResponse;
		}).collect(Collectors.toList());
		
		return allUsers;
	}
	
	@Transactional
	@Override
	public Resource deleteUser(Long id) throws Exception {
		try {
			if(resourceRepository.findByResourceId(id) != null) {
				resourceRepository.deleteByResourceId(id);
			}
			else 
				throw new Exception("User not exist");
		}
		catch(Exception e) {
			e.printStackTrace();
			if(e.getMessage().equals("User not exist"))
				throw new Exception("User not exist");
			else
				throw new Exception("An error occured during delete the user");
		}
		Resource response = resourceRepository.findByResourceId(id);

		return response;
	}

	@Override
	public Map<String, String> addEditUsers(Resource resource, String org) throws Exception {
		Resource findByIdAndOrganization = resourceRepository.findByIdAndOrganization(resource.getId(),org);
		
		if(findByIdAndOrganization!=null) {
			Map<String, String> response = new LinkedHashMap<>();
				String organization = findByIdAndOrganization.getOrganization();
				resource.setOrganization(organization);
				Resource newResource = resourceRepository.save(resource);
				
				response.put("id", String.valueOf(newResource.getId()));
				response.put("resourceName", newResource.getResourceName());
				response.put("displayName", newResource.getDisplayName());
				response.put("infoField1", newResource.getInfoField1());
				response.put("infoField2", newResource.getInfoField2());
				response.put("type", newResource.getType());
				response.put("organization", newResource.getOrganization());
				response.put("resourceColor", newResource.getResourceColor());
				return response;
		}else {
			throw new Exception("Resource not exist");
		}
		
	}
	
}
