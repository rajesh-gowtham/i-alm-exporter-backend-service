package com.igosolutions.uniSync.Respository;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.LicenseValidation;

@Repository
public interface LicenseValidationRepository extends JpaRepository<LicenseValidation, Long> {

	@Query("select s from LicenseValidation s where s.organization = :organization")
    LicenseValidation findByOrganization(String organization);

    @Modifying
    @Transactional
    @Query("UPDATE LicenseValidation lv SET lv.admins = ?2, lv.editors = ?3, lv.reviewers = ?4, lv.viewers = ?5, lv.status = ?6,lv.validFrom = ?7,lv.validTo = ?8 WHERE lv.organization = ?1")
    void updateByOrganization(String organization, String admins, String editors, String reviewers, String viewers, String status, String validFrom, String validTo);
    
    @Modifying
    @Transactional
    @Query("delete LicenseValidation  WHERE organization = :organization")
    void deleteLicense(String organization);
;}
