package com.igosolutions.uniSync.Modal;

public class ALMConnectDto {
   
    public String getAlmModuleType() {
		return almModuleType;
	}
	public void setAlmModuleType(String almModuleType) {
		this.almModuleType = almModuleType;
	}
	private Long almConnectId;
    private Long mapId;
    private Integer diagramXmlId;
    private String activityId;
    private Long dataSourceId; 
    private String testIds;
    private String currLevelId;
    private String almModuleType;
    
    public Long getAlmConnectId() {
        return almConnectId;
    }
    public void setAlmConnectId(Long almConnectId) {
        this.almConnectId = almConnectId;
    }
    public Long getMapId() {
        return mapId;
    }
    public void setMapId(Long mapId) {
        this.mapId = mapId;
    }
    public Integer getDiagramXmlId() {
        return diagramXmlId;
    }
    public void setDiagramXmlId(Integer diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }
    public Long getDataSourceId() {
        return dataSourceId;
    }
    public void setDataSourceId(Long dataSourceId) {
        this.dataSourceId = dataSourceId;
    }
    public String getTestIds() {
        return testIds;
    }
    public void setTestIds(String testIds) {
        this.testIds = testIds;
    }
    public String getActivityId() {
        return activityId;
    }
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }
    public String getCurrLevelId() {
        return currLevelId;
    }
    public void setCurrLevelId(String currLevelId) {
        this.currLevelId = currLevelId;
    }
    
}
