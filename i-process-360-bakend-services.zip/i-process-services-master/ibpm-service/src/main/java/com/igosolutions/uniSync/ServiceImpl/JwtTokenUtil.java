package com.igosolutions.uniSync.ServiceImpl;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.function.Function;
import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.utils.LoggedInUserUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
@Component
public class JwtTokenUtil {

	@Value("${jwt.expiration}")
    private long expirationTime;

    private final SecretKey secretKey;

	@Autowired
	BpmnUserRepository bpmnUserRepository;

    public JwtTokenUtil() {
        this.secretKey = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    }
	public String generateToken(String userName) {
		Date now = new Date();
		Date expiryDate = new Date(now.getTime() + expirationTime);
		return Jwts.builder()
				.setSubject(userName)
				.setIssuedAt(now)
				.setExpiration(expiryDate)
				.signWith(secretKey, SignatureAlgorithm.HS256)
				.compact();
	}

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public Date extractExpirationDate(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	
	  private Claims extractAllClaims(String token) { 
		  return Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(token).
	  getBody(); 
		  }
	  
	  public Boolean isTokenExpired(String token) { 
		  return extractExpirationDate(token).before(new Date()); 
		  }
	public Boolean validateToken(String token, String userName) {
		BpmnUser user = bpmnUserRepository.findByEmail(userName);
		
		LoggedInUserUtils.setLoggedInUsername(user.getFirstname()+" "+user.getLastname());
		
		final String storedToken = getStoredToken(userName);
		return (storedToken != null && storedToken.equals(token) && !isTokenExpired(token));
	}

	
	private String getStoredToken(String userName) {
		BpmnUser user = bpmnUserRepository.findByEmail(userName);
        return (user != null) ? user.getAccesstoken() : null;
	}
	public String resolveToken(HttpServletRequest request) {
		String bearerToken = request.getHeader("Authorization");
		if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7);
		}
		return null;
	}
	public void storeToken(String userName, String token, String deviceId) {
		BpmnUser user = bpmnUserRepository.findByEmail(userName);
		if(user != null){
			user.setAccesstoken(token);
			user.setDeviceId(deviceId);
			user.setLastActive(LocalDateTime.now());
            bpmnUserRepository.save(user);
		}
	}

	
	
}
