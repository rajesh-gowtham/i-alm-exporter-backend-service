package com.igosolutions.uniSync.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.igosolutions.uniSync.Modal.FilesData;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.SharePointDetails;
import com.igosolutions.uniSync.Modal.SharepointAccessDTO;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.FileRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.DocumentService;
import com.igosolutions.uniSync.Service.SharePointService;
import com.igosolutions.uniSync.constants.StorageType;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SharePointController {

	    Logger log = LoggerFactory.getLogger(SharePointController.class);
	    
	    @Autowired
	    BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
	    
	    @Autowired
	    private SharePointService sharePointService;
	    
	    @Autowired
	    private SharePointRepository sharePointRepository;
	    
	    @Autowired
	    private DocumentService documentService;
	    
	    @Autowired
		private FileRepository fileRepository;

	    @Autowired
	    private MapReviewRepository mapReviewRepository;
	    
	    @SuppressWarnings("null")
		@CrossOrigin(origins = "*", allowedHeaders = "*")
	    @RequestMapping(value = "/doc/upload/{userId}/{mapId}", method = RequestMethod.POST)
	    public ResponseEntity<?> uploadDocuments(@RequestParam("files") MultipartFile[] files, @PathVariable("mapId") Long mapId, @PathVariable("userId") String userId) {
	        log.info("UploadDocuments Request {}");
	        if (files == null || files.length == 0) {
	            return ResponseEntity.badRequest().body("No files provided");
	        }
	        String storageType = null;
//			Map<String,String> documentsIds = new HashMap<String,String>();
	        List<Map<String, String>> documentsList = new ArrayList<>();
	        //BpnmUserDiagramme existingData = bpnmUserDiagrammeRepository.findbyDiagramXmlId(Integer.parseInt(diagram_xml_id));
           ReviewDiagramme existingData = mapReviewRepository.getByMapId(mapId);
	        if(existingData!=null) {
            	storageType = existingData.getStorageType();
            }
            String file_Name = null;
	        if(storageType.equalsIgnoreCase(StorageType.SHAREPOINT.getStorageType())) {
	        	try {         
		        	synchronized (this) {             
		                 for (MultipartFile file : files) {
		                	 
		                	 String fileName =file.getOriginalFilename();
		     		        
		     		         String[] parts = fileName.split("/");

		     		        if (parts.length == 4) {
		     		             file_Name = parts[3];
		     		        }
		     		        
		                         String documentId = sharePointService.uploadDocument(file, existingData.getConfigId());
		                         Map<String, String> fileDetails = new HashMap<>();
		                         fileDetails.put("documentId", documentId);
		                         fileDetails.put("fileName", file_Name);
		                         documentsList.add(fileDetails);
		                     
		                     
		                 }        
		        	}         
		        	return ResponseEntity.ok(documentsList);    
		        } catch (Exception e) {
		            e.printStackTrace();
		            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
		                    .body("Failed to upload documents to SharePoint: " + e.getMessage());
		        }
	        }
	        else {
	        	try {         
	        		synchronized (this) {             
	        			for (MultipartFile file : files) {                
	        					
	        					String fileName =file.getOriginalFilename();
			     		        
			     		         String[] parts = fileName.split("/");

			     		        if (parts.length == 4) {
			     		             file_Name = parts[3];
			     		        }
	        					String documentId = sharePointService.uploadDocumentsDb(file); 
	        					 Map<String, String> fileDetails = new HashMap<>();
	        					fileDetails.put("documentId", documentId);
		                         fileDetails.put("fileName", file_Name);
		                         documentsList.add(fileDetails);
	        			}         
	        		}         
	        		return ResponseEntity.ok(documentsList);    
	        	} catch (Exception e) {
	        		e.printStackTrace();
	        		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	        				.body("Failed to upload documents to SharePoint: " + e.getMessage());
	        	}

	        }


	    }
	    
//	    @CrossOrigin(origins = "*", allowedHeaders = "*")
//        @RequestMapping(value = "/doc/getDoc/{diagram_xml_id}/{current_xml_id}/{activity_id}/{file_name}", method = RequestMethod.GET)
//        public ResponseEntity<byte[]> downloadDocument(@PathVariable("diagram_xml_id") String diagram_xml_id,
//                                                       @PathVariable("current_xml_id") String current_xml_id,
//                                                       @PathVariable("activity_id") String activity_id,
//                                                       @PathVariable("file_name") String file_name) {
//            log.info("The doc retreiving starting from controller {}", file_name);
//            
//            String storageType = null;
//	        BpnmUserDiagramme existingData = bpnmUserDiagrammeRepository.findbyDiagramXmlId(Integer.parseInt(diagram_xml_id));
//            if(existingData!=null) {
//            	storageType = existingData.getStorageType();
//            }
//	        if(storageType=="SharePoint" || storageType.equalsIgnoreCase("SharePoint")) {            
//             try {
//                 byte[] fileContent = sharePointService.getFile(diagram_xml_id,current_xml_id,
//                                                                activity_id,file_name,existingData.getConfigId());
//                 HttpHeaders headers = new HttpHeaders();
//                 headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//                 headers.setContentDispositionFormData("attachment", file_name);
//                 log.info("The doc retreiving completed in controller {}", file_name);
//                 return ResponseEntity.ok().headers(headers).body(fileContent);
//             } catch (Exception e) {
//                 
//                 e.printStackTrace();
//                 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                         .body(("Failed to download document from SharePoint: " + e.getMessage()).getBytes());
//        
//             }
//	        }
//	        
//	        
//	        
//	        else {
//	        	try {
//	                byte[] fileContent = documentService.getDocument(diagram_xml_id, current_xml_id, activity_id, file_name);
//	                if (fileContent != null) {
//	                    HttpHeaders headers = new HttpHeaders();
//	                    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//	                    headers.setContentDispositionFormData("attachment", file_name);
//	                    log.info("The doc retrieving completed in controller {}", file_name);
//	                    return ResponseEntity.ok().headers(headers).body(fileContent);
//	                } else {
//	                    return ResponseEntity.status(HttpStatus.NOT_FOUND)
//	                            .body(("Document not found for id: " + diagram_xml_id).getBytes());
//	                }
//	            } catch (Exception e) {
//	                e.printStackTrace();
//	                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//	                        .body(("Failed to download document: " + e.getMessage()).getBytes());
//	            }
//	        }
//	        
//			
//        }
	    @CrossOrigin(origins = "*", allowedHeaders = "*")
        @RequestMapping(value = "/doc/getDoc/{file_name}/{documentId}", method = RequestMethod.GET)
        public ResponseEntity<?> downloadDocument(@PathVariable("file_name") String file_name, @PathVariable("documentId") String documentId) {
            log.info("The doc retreiving starting from controller {}");
            
            SharePointDetails details = sharePointRepository.findByDocumentId(documentId);
            if (details == null) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(("Document Not Found: "));
			}
            
	        if(details.getStorageType().equalsIgnoreCase(StorageType.SHAREPOINT.getStorageType())) {            
             try {
                 byte[] fileContent = sharePointService.getFile(documentId, file_name);
                 HttpHeaders headers = new HttpHeaders();
                 headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                 headers.setContentDispositionFormData("attachment", file_name);
                 log.info("The doc retreiving completed in controller {}", file_name);
                 return ResponseEntity.ok().headers(headers).body(fileContent);
             } catch (Exception e) {
                 e.printStackTrace();
                 return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                         .body(("Failed to download document from SharePoint: " + e.getMessage()));
             }
	        }
	        
	        else {
	        	FilesData data =fileRepository.findByFileId(Long.parseLong(documentId));
	        	try {  //String diagram_xml_id, String current_xml_id, String activity_id, String file_name
	                byte[] fileContent = documentService.getDocument(data.getDiagramXmlId(),data.getCurrentXmlId(),data.getActivityId(),data.getFileName());
	                if (fileContent != null) {
	                    HttpHeaders headers = new HttpHeaders();
	                    headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	                    headers.setContentDispositionFormData("attachment", file_name);
	                    log.info("The doc retrieving completed in controller {}", fileContent);
	                    return ResponseEntity.ok().headers(headers).body(fileContent);
	                } else {
	                    return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                            .body(("Document not found" ).getBytes());
	                }
	            } catch (Exception e) {
	                e.printStackTrace();
	                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                        .body(("Failed to download document : " + e.getMessage()).getBytes());
	            }
	        }
			
        }
	    

	    
        //This API is used to delete multiple files from the sharepoint
        @CrossOrigin(origins = "*" , allowedHeaders = "*")
        @RequestMapping(value = "/doc/deleteDoc" , method = RequestMethod.DELETE)
        public ResponseEntity<String>deleteDocument(@RequestBody List<SharePointDetails> sharePointDetails){

        	boolean allDeletedSuccessfully = true;

        	for(SharePointDetails data : sharePointDetails) {
        		SharePointDetails details = sharePointRepository.findByDocumentId(data.getDocumentId());

        		if(details.getStorageType().equalsIgnoreCase(StorageType.SHAREPOINT.getStorageType())) {
//        			for(SharePointDetails sharePointDetail: sharePointDetails) {
        				try {
        					System.out.println(details.getConfigId()+"\n\n");
        					sharePointService.deleteDocument(details.getDiagramXmlId(),details.getCurrentXmlId(),details.getActivityId(),details.getFileName(), details.getConfigId());
        				}catch(Exception e) {
        					e.printStackTrace();
        					allDeletedSuccessfully = false;
        					return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        				}
//        			}
        		}
        		else {
        			synchronized (this) {   
        					try {
        						documentService.deleteDocument(data.getDocumentId());
        					}catch(Exception e) {
        						e.printStackTrace();
        						allDeletedSuccessfully = false;
        						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        					}
        			}
        		}
        	}
        	if (allDeletedSuccessfully) {
				return ResponseEntity.ok().body("Document deleted Successfully");
			} else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body("Failed to delete one or more documents");
			}

        }

		//UnUsed Controller for deleting the folder in the sharepoint folder
		@CrossOrigin(origins = "*" , allowedHeaders = "*")
	    @RequestMapping(value = "/doc/deleteFolder/{diagram_xml_id}" , method = RequestMethod.DELETE)
	    public ResponseEntity<String>sharePointFolderDelete(@PathVariable("diagram_xml_id") String diagram_xml_id){
			return null;
//	    	System.out.println(diagram_xml_id);
//	    	
//	    	try {
//	    		SharePointClient sharePointClient = new SharePointClient(clientId,clientSecret,); 
//				sharePointClient.deleteFolderByName(diagram_xml_id);
//	    		return ResponseEntity.ok().body("Sharepoint Folder deleted Successfully");
//	    		
//	    	}catch(Exception e) {
//	    		e.printStackTrace();
//	    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(("Failed to delete the document :  "+ e.getMessage()));
//	    	}
	    	
	    }
		@RequestMapping(value = "/sharepoint/validateAccess" , method = RequestMethod.POST)
		public ResponseEntity<?> validateSharpointCredentials(@RequestBody SharepointAccessDTO SharepointAccessDTO) {
			return sharePointService.validateCredentials(SharepointAccessDTO);
		}
	    
	    
}
