package com.igosolutions.uniSync.Modal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ActivityText {
    private String id;
    private String name;
    @JsonProperty("fullNametxt")
    private String fullNameTxt;

    // Getters and setters (or lombok annotations for automatic generation)

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFullNameTxt() {
        return fullNameTxt;
    }

    public void setFullNameTxt(String fullNameTxt) {
        this.fullNameTxt = fullNameTxt;
    }
}







