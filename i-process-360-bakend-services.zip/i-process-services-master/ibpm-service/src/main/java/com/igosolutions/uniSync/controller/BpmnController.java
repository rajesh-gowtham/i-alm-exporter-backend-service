package com.igosolutions.uniSync.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.BpmnDto;
import com.igosolutions.uniSync.Modal.BpmnXmlDto;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Modal.PublishBpmn;
import com.igosolutions.uniSync.Respository.BPMNRepository;
import com.igosolutions.uniSync.Service.BPMNService;
import com.igosolutions.uniSync.utils.HeaderUtil;

@RestController
//@CrossOrigin(origins = "http://localhost:7676/")
public class BpmnController {
	@Autowired
	public BPMNService bpmnService;

	@Autowired
	public BPMNRepository bpmnRepository;

	Logger log = LoggerFactory.getLogger(BpmnController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public", method = RequestMethod.GET)
	public String getApplicationStart() {
		// log.debug("i-BPMN Running SuccesFully");
		try {
			return "i-BPMN Running SuccesFully";
		} catch (Exception e) {
			return "Error " + e.toString();
		}
	}

	@RequestMapping(value = "/public/healthCheck", method = RequestMethod.GET)
	public String getApplicationStart1() {
		try {
			return "i-BPMN Running SuccesFully with dev v 3.0.1-140325-SNAPSHOT";
		} catch (Exception e) {
			return "Error " + e.toString();
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/createBPMN", method = RequestMethod.POST)
	public ResponseEntity<Object> saveBpmn(@RequestBody Bpmn bpmn, @RequestHeader Map<String, String> headers) {
		log.debug("Request {}", bpmn);
		try {
			String org = HeaderUtil.getOrganization(headers);
			bpmn.setOrganization(org);
			bpmnService.saveTaskConnectionBulk(bpmn, org);
			log.debug("Response {}", HttpStatus.CREATED);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/publishBPMN", method = RequestMethod.POST)
	public ResponseEntity<Object> publishBPMN(@RequestParam(name = "diagramname", required = false) String diagramname,
			@RequestParam(name = "publishurl", required = false) String publishurl) throws Exception {
		log.debug("Request {}", diagramname, publishurl);
		try {
			
			LogFile.LogWrite("BPMN Controller - drname<><> :" + diagramname);
			LogFile.LogWrite("BPMN Controller - publishurl<><> :" + publishurl);
			PublishBpmn publishBpmn = new PublishBpmn();
			publishBpmn.setdiagramname(diagramname);
			publishBpmn.seturl(publishurl);
			LogFile.LogWrite("BPMN Controller - publishBpmn<><> 2 :" + publishBpmn);
			bpmnService.savePublishBpmn(publishBpmn);
			log.debug("Response {}", HttpStatus.CREATED);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			if (e.getMessage().equals("Diagram name already exist")) {
				return new ResponseEntity<>("Diagram name already exist", HttpStatus.CONFLICT);
			} else {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getpublishBPMN", method = RequestMethod.GET)
	public List<Bpmn> getpublishBPMN(@RequestParam(name = "diagramname", required = false) String diagramname)
			throws IOException {
		log.debug("Request {}", diagramname);
		LogFile.LogWrite("BPMN Controller - diagramname<><> :" + diagramname);
		List<Bpmn> bpmndata = bpmnService.BpmnByDiagramname(diagramname);
		log.debug("Response {}", bpmndata);
		return bpmndata;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/updateBPMN", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateDataSource(@RequestBody DataSource datasource) {
		log.debug("Request {}", datasource);
		try {
			log.debug("Response {}", HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/deleteBPMN", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteDataSource(
			@RequestParam(name = "datasourcename", required = false) String datasourcename) {
		log.debug("Request {}", datasourcename);
		try {
			log.debug("Response {}", HttpStatus.OK);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// LogFile.LogWrite("Data Source Controller - Delete datasourcename is #101" +
		// datasourcename);
		// datasourceservice.deleteDataSource(datasourcename);
		// LogFile.LogWrite("Data Source Controller - Delete datasourcename is #102" +
		// datasourcename);

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBPMN", method = RequestMethod.GET)
	public ResponseEntity<?> getAllDataSource(@RequestHeader Map<String, String> headers) {
		String organization = HeaderUtil.getOrganization(headers);
		String userId = HeaderUtil.getUserId(headers);
		if (organization == null || organization.trim().isEmpty()) {
			String errorMessage = "Organization parameter is missing or empty";
			log.error(errorMessage);
			return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
		}

		try {
			log.debug("Request received for organization: {}", organization);
			List<BpmnDto> bpmnData = bpmnService.getAllDataSource(organization, Long.parseLong(userId));

			if (bpmnData.isEmpty()) {
				String errorMessage = "No Published diagrams are available for organization: " + organization;
				log.warn(errorMessage);
				return new ResponseEntity<>(bpmnData, HttpStatus.NO_CONTENT);
			}

			log.debug("Response data: {}");
			return new ResponseEntity<>(bpmnData, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			String errorMessage = "An error occurred while retrieving BPMN data: " + e.getMessage();
			log.error(errorMessage, e);
			return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/deletePublishedDiagram/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deletePublishedDiagram(@PathVariable("id") Long id) {
		log.debug("Request {}");
		try {
			Bpmn byId = bpmnRepository.findByMapId(id);
			if (byId != null) {
				bpmnService.deletePublishedDiagram(byId.getTaskConnectionId());
			} else {
				return new ResponseEntity<>("Map Not Found", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<>("Map Deleted Successfully", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>("Error in the Server", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getpublishBPMN/{mapId}", method = RequestMethod.GET)
	public Bpmn getSingleBPMN(@PathVariable("mapId") Long mapId) {
		// log.debug("Request {}", diagramname);
		// LogFile.LogWrite("BPMN Controller - diagramname<><> :" + diagramname);

		Bpmn bpmndata = bpmnService.getSingleBPMN(mapId);
		log.debug("Response {}", bpmndata);
		return bpmndata;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping("/api/pingApi")
	public String pingApi() {

		return "Ok";

	}

	@GetMapping("/getBpmnXml/{taskConnectionId}")
	public BpmnXmlDto getBpmnXml(@PathVariable("taskConnectionId") Long taskConnectionId) {
		BpmnXmlDto bpmnXmlDto = bpmnService.getBpmnXml(taskConnectionId);
		return bpmnXmlDto;
	}

}
