package com.igosolutions.uniSync.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FrontEndLogController {

    // Custom logger for API logs
    private static final Logger apiLogger = LoggerFactory.getLogger("com.igosolutions.uniSync.FrontEndLogController");

    @PostMapping("/public/logContent")
    public String logContent(@RequestBody Map<String,String> content,  @RequestHeader Map<String, String> headers) {
        // Log to the API log file
        apiLogger.info("Logged in user "+ headers.get("userid") +"\nPOST API Content: {}", content);

        // Standard application log
        Logger appLogger = LoggerFactory.getLogger(FrontEndLogController.class);
        appLogger.info("Handled POST request with content");

        return "Content logged successfully!";
    }
}