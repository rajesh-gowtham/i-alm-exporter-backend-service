package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserLoginDto;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.Role;
import com.igosolutions.uniSync.Modal.RoleResponseDTO;


public interface BpmnUserService {
	
	public Map<String, Object> addEditUsers(BpmnUserRequest bpmnUserRequest, String user) throws Exception;
	
    public List<Object> getAllUsersWithoutPassword(String organization) throws Exception;

	BpmnUser getUserByEmail(String email) throws Exception;

	public ResponseEntity<Map<String, Object>> checkEmailPassword(BpmnUserLoginDto bpmnUser)throws Exception;

	public BpmnUser deleteUserByRoleCheck(Long userid, List<ReviewDiagramme> diagrammeByUserId) throws Exception;
	
	public BpmnUser deleteUserById(Long userid) throws Exception;
	
	public void sendResetTokenEmail(String userName, String userEmail, String resetToken , HttpServletRequest request) throws Exception;
	
	public void resetPassword(String email, String newPassword, String resetToken) throws Exception;
	
	public boolean verifyCode(String resetToken) throws Exception;
	
	public void generateResetToken(String email, HttpServletRequest request) throws Exception;

	public String verifyResetToken(String email, String resetToken) throws Exception;

	public Role createRole(Role role) throws Exception;

	public List<RoleResponseDTO> getAllRolesByOrganization(String organization) throws Exception;

	public Role deleteRole(Long id) throws Exception;

	public Map<String, Object> UpdateRole(Role role) throws Exception;

	public void changeTemporaryPassword(Map<String, String> requestPayload);

	public void changeNewPassword(Map<String, String> requestPayload) throws Exception;

    public ResponseEntity<?> getUserCustomersAndProjects(Long userId);

	public Map<String, String> findUserDetails(Long userId) throws Exception ;
	
}