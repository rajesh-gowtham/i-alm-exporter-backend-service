package com.igosolutions.uniSync.utils;

import java.util.List;

public class CommentsMentionDto {
	
	public List<Recipients> recipients;
	public Long senderUserId;
	public String emailBody;
	public String diagramName;
	
	
	public List<Recipients> getRecipients() {
		return recipients;
	}
	public void setRecipients(List<Recipients> recipients) {
		this.recipients = recipients;
	}
	
	
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public String getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}
	
	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	@Override
	public String toString() {
		return "CommentsMentionDto [recipients=" + recipients + ", senderUserId=" + senderUserId + ", emailBody="
				+ emailBody + ", diagramName=" + diagramName + "]";
	}
	
	
	
	
    
}
