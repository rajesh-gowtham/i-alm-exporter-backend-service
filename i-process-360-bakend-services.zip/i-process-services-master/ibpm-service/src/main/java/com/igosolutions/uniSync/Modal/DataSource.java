package com.igosolutions.uniSync.Modal;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "DataSource")
public class DataSource {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String url;
	private String username;
	private String password;
	private String domainname;
	private String projectname;
	private String datasourcename;
	private String defectTool;
	private String modulename;
	private String techniciankey;
	@Column(name = "client_id")
	private String clientId;
	@Column(name = "client_secret")
	private String clientSecret;
	@Column(name = "tenant_id")
	private String tenantId;
	@Column(name = "site_name")
	private String siteName;
	@Column(name = "organization")
	private String organization;	
	@OneToMany(mappedBy = "dataSource", cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.PERSIST}, fetch = FetchType.EAGER)
	private List<ALMConnect> almConnect;
	
    
	public DataSource() {
		
	}
	
	@Override
	public String toString() {
		return "DataSource [id=" + id + ", url=" + url + ", username=" + username + ", password=" + password
				+ ", domainname=" + domainname + ", projectname=" + projectname + ", datasourcename=" + datasourcename
				+ ", defectTool=" + defectTool + ", modulename=" + modulename + ", techniciankey=" + techniciankey
				+ ", clientId=" + clientId + ", clientSecret=" + clientSecret + ", tenantId=" + tenantId + ", siteName="
				+ siteName + ", organization=" + organization + "]";
	}

	public String getModulename() {
		return modulename;
	}
	public void setModulename(String modulename) {
		this.modulename = modulename;
	}
	public String getDatasourcename() {
		return datasourcename;
	}

	public void setDatasourcename(String datasourcename) {
		this.datasourcename = datasourcename;
	}

	public String getDefectTool() {
		return defectTool;
	}

	public void setDefectTool(String defectTool) {
		this.defectTool = defectTool;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDomainname() {
		return domainname;
	}

	public void setDomainname(String domainname) {
		this.domainname = domainname;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}


	public String getTechniciankey() {
		return techniciankey;
	}


	public void setTechniciankey(String techniciankey) {
		this.techniciankey = techniciankey;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}
	
	
}
