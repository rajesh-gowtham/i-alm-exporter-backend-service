package com.igosolutions.uniSync.utils;

import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

@Component
public class SessionRegistry {
    private ConcurrentHashMap<String, String> activeSessions = new ConcurrentHashMap<>();

    public void registerSession(String username, String sessionId) {
        activeSessions.put(username, sessionId);
    }

    public String getSessionId(String username) {
        return activeSessions.get(username);
    }

    public void removeSession(String username) {
        activeSessions.remove(username);
    }

    public boolean isSessionActive(String username, String sessionId) {
        return sessionId.equals(activeSessions.get(username));
    }
}
