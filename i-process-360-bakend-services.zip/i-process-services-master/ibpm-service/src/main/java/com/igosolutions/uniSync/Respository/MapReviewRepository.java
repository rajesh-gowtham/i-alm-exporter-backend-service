package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.ReviewDiagramme;

@Repository
public interface MapReviewRepository extends JpaRepository<ReviewDiagramme,Long>{

//    @Modifying
//    @Transactional
//    @Query("INSERT INTO review_map (diagram_xml_id, author_user_id, status) VALUES (:diagramXmlId, :authorUserId, :status)")
//    void save(@Param("authorUserId") Long authorUserId, @Param("diagramXmlId") int diagramXmlId, @Param("status") String status);
    
 //  @Transactional
  //  @Modifying
//    @Query("update ReviewDiagramme s set s.authorUserId = :authorUserId, s.status =:status, s.diagramName = :diagram_name where s.diagramXmlId = :diagramXmlId")
 //   void updateReviewTable(@Param("authorUserId") String authorUserId, @Param("diagramXmlId") int diagramXmlId,@Param("status") String status, @Param("diagram_name") String diagramName);
    
 //   @Transactional
 //   @Modifying
 //   @Query("update ReviewDiagramme s set s.authorUserId = :authorUserId, s.status =:status, s.diagramName = :diagram_name,s.mapPrivacyType= :privacyType where s.diagramXmlId = :diagramXmlId")
 //   void updateReviewTable(@Param("authorUserId") String authorUserId, @Param("diagramXmlId") int diagramXmlId,@Param("status") String status, @Param("diagram_name") String diagramName,@Param("privacyType")String privacyType);
    
    
   // @Transactional
   // @Modifying
   // @Query("update ReviewDiagramme s set  s.diagramName = :diagram_name where s.diagramXmlId = :diagramXmlId")
   // void updateReviewTable( @Param("diagramXmlId") int diagramXmlId, @Param("diagram_name") String diagramName);
    
//     @Transactional
//     @Modifying
//     @Query("update ReviewDiagramme s set s.assignedUser = :assignedUser, s.assignedUserId = :assignedUserId,s.status =:status, s.diagramName = :diagramName where s.diagramXmlId = :diagramXmlId")
//     void update(@Param("diagramXmlId") int diagramXmlId,@Param("assignedUser") String assignedUser, @Param("assignedUserId") int assignedUserId,@Param("status") String status, @Param("diagramName") String diagramName);
//    
	//@Transactional
	//@Query(value="SELECT b FROM ReviewDiagramme b WHERE b.diagramXmlId = :diagramXmlId")
	//public ReviewDiagramme getByDiagramXmlId(@Param("diagramXmlId")int diagramXmlId);
   

     @Transactional
     @Query("SELECT r FROM ReviewDiagramme r WHERE r.authorUserId = :authorUserId")
     List<ReviewDiagramme> getByAuthorUserId(@Param("authorUserId") String authorUserId);
    
    //  @Transactional
    //  @Query("SELECT r FROM ReviewDiagramme r WHERE r.assignedUserId = :assignedUserId")
    //  List<ReviewDiagramme> getByAssignedUserIdUserId(@Param("assignedUserId") int assignedUserId);

    //@Transactional
	//@Modifying
	//@Query("DELETE FROM ReviewDiagramme b WHERE b.diagramXmlId = :diagramXmlId")
	//void deleteByDiagramXmlId(@Param("diagramXmlId") int diagramXmlId);
    
   // @Transactional
   // @Query("SELECT r FROM ReviewDiagramme r WHERE r.authorUserId = :authorUserId AND r.diagramXmlId = :diagramXmlId")
	//ReviewDiagramme findbyauthorUserIdAndDiagramXmlId(@Param("diagramXmlId") int diagramXmlId, @Param("authorUserId") String authorUserId);
    
   // @Transactional
   	//@Modifying
   	//@Query("UPDATE ReviewDiagramme b SET b.status=:status WHERE b.diagramXmlId = :diagramXmlId")
	//void updateStatus(@Param("diagramXmlId")int diagramXmlId, @Param("status")String status);

    
    @Query("SELECT r FROM ReviewDiagramme r JOIN r.assignedUsers u WHERE r.authorUserId = :authorUserId AND u.assignedUserId = :assignedUserId")
    List<ReviewDiagramme> getByAuthorUserIdAndAssignedUserId(@Param("authorUserId") String authorUserId, @Param("assignedUserId") int assignedUserId);
    
    // @Query("SELECT r FROM ReviewDiagramme r JOIN r.assignedUsers u WHERE u.assignedUserId = :assignedUserId")
    // List<ReviewDiagramme> findByAssignedUserId(@Param("assignedUserId") int assignedUserId);
    @Query("SELECT r FROM ReviewDiagramme r WHERE r.authorUserId = :authorUserId AND r.status <> :status")
    List<ReviewDiagramme> getByAuthorUserIdAndNotStatus(@Param("authorUserId") String authorUserId, @Param("status") String status);

    @Modifying
    @Transactional
    @Query("UPDATE ReviewDiagramme r SET r.author = :newAuthor WHERE r.authorUserId = :authorUserId")
    int updateAuthorByAuthorUserId(@Param("newAuthor") String newAuthor, @Param("authorUserId") String authorUserId);


    //@Transactional
    //List<ReviewDiagramme> findAllByOrganization(String organization);

   // @Query("SELECT m FROM ReviewDiagramme m WHERE m.diagramXmlId IN :diagramXmlIds")
	//List<ReviewDiagramme> findByDiagramXmlIds(@Param("diagramXmlIds")List<Integer> diagramXmlIds);


	/*
	 * @Query("SELECT m.diagramXmlId FROM ReviewDiagramme m WHERE m.authorUserId IN :userId AND m.mapPrivacyType = :mapPrivacyType"
	 * ) List<Integer> findByAuthorUserIdByPrivate(@Param("userId")String
	 * userId,@Param("mapPrivacyType") String
	 * mapPrivacyType,@Param("mapPrivacyType") String mapPrivacyTypeSpeci);
	 */
	/*
	 * @Query("SELECT m.diagramXmlId FROM ReviewDiagramme m WHERE m.authorUserId IN :userId AND m.mapPrivacyType IN (:mapPrivacyType, :mapPrivacyTypePublic, :mapPrivacyTypeSpecific) AND m.organization = :organization"
	 * ) List<Integer> findByAuthorUserIdByPrivateSpecificPublic(
	 * 
	 * @Param("userId") String userId,
	 * 
	 * @Param("mapPrivacyType") String mapPrivacyType,
	 * 
	 * @Param("organization") String organization,
	 * 
	 * @Param("mapPrivacyTypePublic") String mapPrivacyTypePublic,
	 * 
	 * @Param("mapPrivacyTypeSpecific") String mapPrivacyTypeSpecific );
	 */
    
   // @Query("SELECT m.diagramXmlId FROM ReviewDiagramme m WHERE m.organization IN :organization AND m.mapPrivacyType = :mapPrivacyType")
   // List<Integer> getByOrganization(@Param("organization") String organization, @Param("mapPrivacyType") String mapPrivacyType);

   
    
    @Query("SELECT r FROM ReviewDiagramme r WHERE r.organization = :organization")
	List<ReviewDiagramme> findAllByOrganization(@Param("organization")String organization);
    
//    AND r.status NOT IN ('Approved', 'Published')
    
    // @Transactional
    // @Query("SELECT r FROM ReviewDiagramme r WHERE r.assignedUserId = :assignedUserId ")
    // List<ReviewDiagramme> findByAssignedUserIdExcludingApprovedAndPublished(@Param("assignedUserId") int assignedUserId);
    @Query("SELECT r FROM ReviewDiagramme r JOIN r.assignedUsers u WHERE u.assignedUserId = :assignedUserId")
    List<ReviewDiagramme> findByAssignedUserId(@Param("assignedUserId") int assignedUserId);

   // @Query("SELECT m FROM ReviewDiagramme m WHERE m.authorUserId IN :userId AND m.mapPrivacyType = :mapPrivacyType AND m.organization = :organization AND m.mapPrivacyType = :mapPrivacyTypePublic")
  
   // @Query("SELECT m FROM ReviewDiagramme m WHERE (m.authorUserId = :userId AND m.mapPrivacyType IN (:mapPrivacyTypePrivate, :mapPrivacyTypeSpecific)) AND m.organization = :organization OR m.mapPrivacyType IN (:mapPrivacyTypePublic)")
    @Query("SELECT m FROM ReviewDiagramme m WHERE (m.authorUserId = :userId AND m.mapPrivacyType IN (:mapPrivacyTypePrivate, :mapPrivacyTypeSpecific)) OR (m.organization = :organization AND m.mapPrivacyType = :mapPrivacyTypePublic)")
    List<ReviewDiagramme> findByAuthorUserIdByPrivateSpecificPublic(
        @Param("userId") String userId,
        @Param("mapPrivacyTypePrivate") String mapPrivacyTypePrivate,
        @Param("organization") String organization,
        @Param("mapPrivacyTypePublic") String mapPrivacyTypePublic,
        @Param("mapPrivacyTypeSpecific")String mapPrivacyTypeSpecific
    );

    //@Query("SELECT m FROM ReviewDiagramme m JOIN m.mapVersions v WHERE v.diagramXmlId IN :diagramXmlIds")
    @Query("SELECT DISTINCT m FROM ReviewDiagramme m JOIN m.mapVersions v WHERE v.diagramXmlId IN :diagramXmlIds")
    List<ReviewDiagramme> findByDiagramXmlIds(@Param("diagramXmlIds") List<Integer> diagramXmlIds);

    @Query("SELECT r FROM ReviewDiagramme r WHERE r.id = :id")
	ReviewDiagramme getByMapId(@Param("id")Long id);

    @Transactional
   	@Modifying
   	@Query("UPDATE ReviewDiagramme b SET b.status=:status WHERE b.id = :id")
	void updateStatus(@Param("id")Long id, @Param("status")String status);

    // @Query("SELECT r FROM ReviewDiagramme r WHERE r.assignedUserId = :assignedUserId AND r.status = :status")
    // List<ReviewDiagramme> getByAssignedUserIdAndStatus(@Param("assignedUserId")int assignedUserId, @Param("status")String status);

    @Query("SELECT r FROM ReviewDiagramme r WHERE r.project.id = :projectId AND r.authorUserId = :authorUserId")
    List<ReviewDiagramme> findByProjectIdAndAuthorUserId(@Param("projectId") Long projectId, @Param("authorUserId") String authorUserId);

    @Query("SELECT r FROM ReviewDiagramme r WHERE r.project.id IN :projectIds AND r.authorUserId = :authorUserId")
    List<ReviewDiagramme> findByProjectIdInAndAuthorUserId(@Param("projectIds") List<Long> projectIds, @Param("authorUserId") String authorUserId);

    @Query("SELECT r FROM ReviewDiagramme r WHERE r.project.id = :projectId AND r.id = :id")
    ReviewDiagramme findByProjectIdAndMapId(@Param("projectId") Long projectId, @Param("id") Long id);
    
    @Query("SELECT r FROM ReviewDiagramme r WHERE r.id = :id")
    ReviewDiagramme findByMapId(@Param("id") Long id);
    
    @Query("SELECT e.id FROM ReviewDiagramme e WHERE e.id=:userId")
	List<Long> getIdByAuthorUserId(@Param("userId")Long userId);

    List<ReviewDiagramme> findByConfigId(String configId);

    // @Query("SELECT r FROM ReviewDiagramme r WHERE r.authorUserId = :authorUserId AND r.status <> :status")
    // List<ReviewDiagramme> getByAuthorUserIdAndNotStatus(@Param("authorUserId") String authorUserId, @Param("status") String status);
   
    // @Query("SELECT r FROM ReviewDiagramme r WHERE r.assignedUserId = :assignedUserId AND r.status = :status")
    // List<ReviewDiagramme> getByAssignedUserIdAndStatus(@Param("assignedUserId")int assignedUserId, @Param("status")String status);
}

