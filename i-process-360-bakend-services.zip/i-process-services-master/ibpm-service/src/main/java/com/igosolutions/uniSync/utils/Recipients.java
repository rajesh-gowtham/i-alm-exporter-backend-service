package com.igosolutions.uniSync.utils;

public class Recipients {
	
	public Long userId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Recipients [userId=" + userId + "]";
	}
	

}
