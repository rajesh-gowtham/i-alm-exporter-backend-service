package com.igosolutions.uniSync.Modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Notification {
    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @ElementCollection
    @CollectionTable(name = "notification_user_read_status", joinColumns = @JoinColumn(name = "notification_id"))
    private List<UserReadStatus> userReadStatuses = new ArrayList<>();

    @Column(name = "diagram_xml_id")
    private Integer diagramXmlId;

    @Column(name = "user_role")
    private String userRole;

    @Column(name = "comment_id")
    private Long commentId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getDiagramXmlId() {
        return diagramXmlId;
    }

    public void setDiagramXmlId(Integer diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }

    public List<UserReadStatus> getUserReadStatuses() {
        return userReadStatuses;
    }

    public void setUserReadStatuses(List<UserReadStatus> userReadStatuses) {
        this.userReadStatuses = userReadStatuses;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }
    
    

}
