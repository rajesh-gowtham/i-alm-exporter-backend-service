package com.igosolutions.uniSync.ServiceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.AssignedUser;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.MapAccess;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTO;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTOResponse;
import com.igosolutions.uniSync.Modal.MapVersion;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.FileRepository;
import com.igosolutions.uniSync.Respository.MapAccessRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.MapVersionRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;
import com.igosolutions.uniSync.constants.UserRole;
import com.igosolutions.uniSync.constants.UtilsConstants.Check;
import com.igosolutions.uniSync.constants.UtilsConstants.DiagramEditStatus;
import com.igosolutions.uniSync.constants.UtilsConstants.DiagramLevel;
import com.igosolutions.uniSync.constants.UtilsConstants.MailContents;
import com.igosolutions.uniSync.constants.UtilsConstants.MapPrivacy;
import com.igosolutions.uniSync.exceptions.ProjectNotBelongToAssignedCustomerException;
import com.igosolutions.uniSync.utils.AsyncEmailService;
import com.igosolutions.uniSync.utils.TimeStampUpdation;

@Service
public class BpmnUserDiagrammeServiceImpl implements BpnmUserDiagrammeService {

	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;

	@Autowired
	MapReviewRepository mapReviewRepository;

	@Autowired
	SharePointRepository sharePointRepository;

	@Autowired
	FileRepository fileRepository;
	
	@Autowired
	MapAccessRepository mapAccessRepository;
	
	@Autowired
	MapVersionRepository mapVersionRepository;
	
	@Autowired
	BpmnUserRepository bpmnUserRepository;
	
	@Autowired
	AsyncEmailService asyncEmailService;
	
	@Autowired
	private MailContentServiceImpl mailContentServiceImpl;
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private TimeStampUpdation timeStampUpdation;
	
	public boolean smtpStatus= true;
	
	private String subject = null;

	private String text = null;
	

	@Autowired 
	ProjectRepository projectRepository;
	
	Logger log = LoggerFactory.getLogger(BpmnMapReviewServiceImpl.class);
	
	private static final long ONE_MINUTES_IN_MILLIS = 1 * 60 * 1000;


	@Override
	public Map<String, String>  saveOrUpdateXmlData(BpnmUserDiagramme bpnmUserDiagramme) {
		Map<String,String> response = new HashMap<>();
		
		try {
			
			
			BpnmUserDiagramme existingData = bpnmUserDiagrammeRepository
					.getById(Integer.valueOf(bpnmUserDiagramme.getDiagramXmlId()));
			
			String languageName = existingData.getLanguageName();

			if (existingData != null) {

				existingData
						.setDiagramXmlId(bpnmUserDiagramme.getDiagramXmlId() != 0 ? bpnmUserDiagramme.getDiagramXmlId()
								: existingData.getDiagramXmlId());
				existingData.setXmlData(bpnmUserDiagramme.getXmlData() != null ? bpnmUserDiagramme.getXmlData()
						: existingData.getXmlData());
				existingData.setLanguageCode(
						bpnmUserDiagramme.getLanguageCode() != null ? bpnmUserDiagramme.getLanguageCode()
								: existingData.getLanguageCode());
				existingData.setLanguageName(
						bpnmUserDiagramme.getLanguageName() != null ? bpnmUserDiagramme.getLanguageName()
								: existingData.getLanguageName());
				existingData
						.setDiagramName(bpnmUserDiagramme.getDiagramName() != null ? bpnmUserDiagramme.getDiagramName()
								: existingData.getDiagramName());
				bpnmUserDiagrammeRepository.update(existingData.getUserid(), existingData.getXmlData(),
						existingData.getLanguageCode(), existingData.getLanguageName(), existingData.getDiagramName(),
						existingData.getDiagramXmlId());
				
				
				MapVersion mapVersion = mapVersionRepository.findByDiaramXmlId(existingData.getDiagramXmlId());
				ReviewDiagramme reviewDiagramme = mapReviewRepository.getByMapId(mapVersion.getReviewDiagramme().getId());
                
				if(languageName != null ) { 
					
					System.out.println("Firssssssssst");
					if(!languageName.equals(bpnmUserDiagramme.getLanguageName())) {
						System.out.println("seccccccccccccccccccccc");
					reviewDiagramme.setLanguageName(bpnmUserDiagramme.getLanguageName());
					mapReviewRepository.save(reviewDiagramme);
					mapReviewRepository.flush();
					entityManager.clear();
					}
					
				}
				
				
				BpnmUserDiagramme savedOrUpdateDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(existingData.getDiagramXmlId());
				
				
				
				
				
				if(savedOrUpdateDiagramme != null) {

					response.put("diagramXmlId",  String.valueOf(savedOrUpdateDiagramme.getDiagramXmlId()));
					response.put("xmlData", savedOrUpdateDiagramme.getXmlData());
					response.put("languageName", savedOrUpdateDiagramme.getLanguageName());
					response.put("languageCode", savedOrUpdateDiagramme.getLanguageCode());
					response.put("diagramName", savedOrUpdateDiagramme.getDiagramName());
					response.put("docStorageType", reviewDiagramme.getStorageType());
					response.put("configId", reviewDiagramme.getConfigId());
					response.put("configName", reviewDiagramme.getConfigName());
				}
				
     		}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	@Override
	public List<BpnmUserDiagramme> getDiagrammeByUserId(Long userId) {
		return bpnmUserDiagrammeRepository.findByUserId(userId);
	}

	@Override
	public void saveStorageType(int diagramXmlId, String storageType, String configName, String configId) {

		//bpnmUserDiagrammeRepository.updateStorageType(diagramXmlId, storageType, configName, configId);

	}

	@Override
	@Transactional
	public BpnmUserDiagramme createNewDiagrams(Long userId,  MapDiagramRequestDTO mapDiagramRequestDTO) {
		 BpnmUserDiagramme save  = new BpnmUserDiagramme();
		try {
			BpnmUserDiagramme bpnmUserDiagramme = new BpnmUserDiagramme();
			bpnmUserDiagramme.setDiagramName(mapDiagramRequestDTO.getDiagramName());
			//bpnmUserDiagramme.setStorageType(mapDiagramRequestDTO.getDocStorageType());
			bpnmUserDiagramme.setXmlData(mapDiagramRequestDTO.getXmlData());
			//bpnmUserDiagramme.setConfigName(mapDiagramRequestDTO.getConfigName());
			bpnmUserDiagramme.setUserid(userId);
			bpnmUserDiagramme.setTemplate(mapDiagramRequestDTO.getTemplate());
			if(mapDiagramRequestDTO.getLanguageCode() == null) {
				bpnmUserDiagramme.setLanguageCode("en");
			}else {
			bpnmUserDiagramme.setLanguageCode(mapDiagramRequestDTO.getLanguageCode());
			}
			if(mapDiagramRequestDTO.getLanguageName() == null) {
			bpnmUserDiagramme.setLanguageName("English");
			}
			else {
				bpnmUserDiagramme.setLanguageName(mapDiagramRequestDTO.getLanguageName());
			}
			
			save  = bpnmUserDiagrammeRepository.save(bpnmUserDiagramme);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return save;

	}

//	@Override
//	public List<Map<String, Object>> getDiagrams(Long userId) {
//		try {
//			List<BpnmUserDiagramme> diagrams = bpnmUserDiagrammeRepository.findByUserId(userId);
//
//			if (!diagrams.isEmpty()) {
//
//				return diagrams.stream().map(diagram -> {
//					Map<String, Object> map = new HashMap<>();
//					map.put("diagramXmlId", diagram.getDiagramXmlId());
//					map.put("diagramName", diagram.getDiagramName());
//					map.put("docStorageType", diagram.getStorageType());
//					map.put("configName", diagram.getConfigName());
//					map.put("configId", diagram.getConfigId());
//					map.put("userid", diagram.getUserid());
//					map.put("xmlData", diagram.getXmlData());
//					map.put("languageName", diagram.getLanguageName());
//					map.put("languageCode", diagram.getLanguageCode());
//					return map;
//				}).collect(Collectors.toList());
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return new ArrayList<>();
//	}

	@Override
	public BpnmUserDiagramme getDiagrammeByUserId(Long UserId, int diagramXmlId) {
		return bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramXmlId);
	}

//	@Override
//	public void deleteMapDiagrams(Long userId, List<BpnmUserDiagramme> requestPayload) {
//		
//		
//
//		for (BpnmUserDiagramme bpnmUserDiagramme : requestPayload) {
//			    int diagramXmlId = bpnmUserDiagramme.getDiagramXmlId();
//			    
//			    
//	///// Here the changes made for delete the diagram by xmlId directly with out checking the below condition
//			//ReviewDiagramme findbyUserIdAndDiagramXmlId = mapReviewRepository.findbyauthorUserIdAndDiagramXmlId(diagramXmlId,Long.toString(userId));
//			
//			//if (findbyUserIdAndDiagramXmlId != null) {
//				//mapReviewRepository.deleteByDiagramXmlId(diagramXmlId);
//				
//				if(sharePointRepository.findByDiagramXmlId(Integer.toString(diagramXmlId)).size()> 0){
//					sharePointRepository.deleteByDiagramId(Integer.toString(diagramXmlId));
//				}
//				if(fileRepository.findByDiagramXmlId(diagramXmlId).size()> 0){
//					fileRepository.deleteByDiagramXmlId(diagramXmlId);
//				}
//				bpnmUserDiagrammeRepository.deleteById(diagramXmlId);
//				
//				
//			//}
//			
//			mapAccessRepository.deleteBydiagramXmlId(diagramXmlId);
//		}
//	}

	@Override
	public MapDiagramRequestDTOResponse updateMapDigram(String userId, Long mapId,MapDiagramRequestDTOResponse mapDiagramRequestDTO) {
		 
		BpmnUser bpmnUser = bpmnUserRepository.findByUserId(Long.parseLong(userId));
	       
		ReviewDiagramme reviewDiagramme = mapReviewRepository.findById(mapId)
	            .orElseThrow(() -> new RuntimeException("Diagram not found"));

				Hibernate.initialize(reviewDiagramme.getMapAccess());
				Hibernate.initialize(reviewDiagramme.getAssignedUsers());

	        // Fetch all diagramXmlId connected with the given diagramId
	        List<Integer> connectedDiagramXmlIds = mapVersionRepository.findAllDiagramXmlIdsByMapId(reviewDiagramme.getId());

	         // Extract data from request DTO
	    String newDiagramName = mapDiagramRequestDTO.getDiagramName();
	    String newMapPrivacyType = mapDiagramRequestDTO.getMapPrivacyType();

	        // Update all connected diagramXmlIds in BpnmUserDiagramme
			bpnmUserDiagrammeRepository.updateDiagrams(newDiagramName, connectedDiagramXmlIds);
	        bpnmUserDiagrammeRepository.flush();
	        entityManager.clear();

		// Store old values for comparison
		String oldDiagramName = reviewDiagramme.getDiagramName();
		String oldMapPrivacyType = reviewDiagramme.getMapPrivacyType();
		List<MapAccess> oldMapAccessList = new ArrayList<>(reviewDiagramme.getMapAccess());

		// Update ReviewDiagramme
		boolean diagramUpdated = false;
		if (bpmnUser != null && (bpmnUser.getRole().equals(UserRole.EDITOR.getRole())
			|| bpmnUser.getRole().equals(UserRole.REVIEWER.getRole())
			|| bpmnUser.getRole().equals(UserRole.ADMIN.getRole()))) {

			reviewDiagramme = updateReviewDiagramme(reviewDiagramme, mapDiagramRequestDTO);
			reviewDiagramme = mapReviewRepository.save(reviewDiagramme);

			// Check if any update happened
			if (!oldDiagramName.equals(newDiagramName) || !oldMapPrivacyType.equals(newMapPrivacyType)
				|| !oldMapAccessList.equals(reviewDiagramme.getMapAccess())) {
				diagramUpdated = true;
			}
		}

		if (diagramUpdated) {
			notifyUsersOfChanges(reviewDiagramme, oldDiagramName, oldMapPrivacyType, oldMapAccessList, mapDiagramRequestDTO);
		}

		BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.getByDiagramXmlId(mapDiagramRequestDTO.getDiagramXmlId());
		MapDiagramRequestDTOResponse mapDiagramRequestDTOResponse = buildMapDiagramRequestDTOResponse(bpnmUserDiagramme, reviewDiagramme);
		return mapDiagramRequestDTOResponse;
	}
	private void notifyUsersOfChanges(ReviewDiagramme reviewDiagramme, String oldDiagramName, String oldMapPrivacyType, List<MapAccess> oldMapAccessList, MapDiagramRequestDTOResponse mapDiagramRequestDTO) {
	    List<String> recipients = new ArrayList<>();
	   

	    if (!oldDiagramName.equals(reviewDiagramme.getDiagramName()) || !oldMapPrivacyType.equals(reviewDiagramme.getMapPrivacyType())
		        || !oldMapAccessList.equals(reviewDiagramme.getMapAccess())) {
	        if (MapPrivacy.SPECIFIC.equals(reviewDiagramme.getMapPrivacyType())) {
	            recipients.addAll(reviewDiagramme.getMapAccess().stream()
	                .map(MapAccess::getSpecificUser)
	                .map(userId -> bpmnUserRepository.findByUserId(userId.longValue()))
	                .filter(Objects::nonNull)
	                .map(BpmnUser::getEmail)
	                .collect(Collectors.toList()));
	            recipients.add(bpmnUserRepository.findByAuthorUserId(Long.parseLong(reviewDiagramme.getAuthorUserId())));
	           
	        } else if (MapPrivacy.PUBLIC.equals(reviewDiagramme.getMapPrivacyType())) {
	            recipients.addAll(bpmnUserRepository.findByRoleAndOrgainzation(reviewDiagramme.getOrganization(), UserRole.EDITOR.getRole(),reviewDiagramme.getProject().getId()));
	        }
	        else {
	        	recipients.add(bpmnUserRepository.findByAuthorUserId(Long.parseLong(reviewDiagramme.getAuthorUserId())));	        	
	        }	        
	    }
	    if(reviewDiagramme.getAssignedUsers().size() != 0) {
			for(AssignedUser assignedUser:reviewDiagramme.getAssignedUsers()){
	    		recipients.add(bpmnUserRepository.findByAuthorUserId(Long.valueOf(String.valueOf(assignedUser.getAssignedUserId()))));
			}
	    }
	    recipients.addAll(bpmnUserRepository.findByRoleAndOrgainzation(reviewDiagramme.getOrganization(), UserRole.ADMIN.getRole()));    
	    subject = MailContents.MAP_UPDATED;
	    text = mailContentServiceImpl.mapUpdatedMail(recipients,reviewDiagramme.getDiagramName());
	    
		try {
			asyncEmailService.sendMail(recipients, subject, text);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("SMTP SERVER HAS BEEN INACTIVE");
			smtpStatus = false;
			log.info("SMTP SERVER HAS BEEN INACTIVE, MAIL WAS NOT TRIGGERED");
		}
        
	}
	
	private ReviewDiagramme updateReviewDiagramme(ReviewDiagramme reviewDiagramme, MapDiagramRequestDTOResponse mapDiagramRequestDTO) {
	    // Update diagram name and privacy type
	    reviewDiagramme.setDiagramName(mapDiagramRequestDTO.getDiagramName());
	    reviewDiagramme.setMapPrivacyType(mapDiagramRequestDTO.getMapPrivacyType());
	    reviewDiagramme.setConfigId(mapDiagramRequestDTO.getConfigId());
	    reviewDiagramme.setConfigName(mapDiagramRequestDTO.getConfigName());
	    reviewDiagramme.setStorageType(mapDiagramRequestDTO.getDocStorageType());
	    
	   
 		ProjectDTO projectDto = mapDiagramRequestDTO.getProject();
		Optional<Project> existingProject = projectRepository.findById(projectDto.getId());
		if(existingProject.isPresent()){
			if (!existingProject.get().getCustomer().getId().equals(projectDto.getCustomerId())) {
				throw new ProjectNotBelongToAssignedCustomerException("Project does not belong to the assigned customer");
			}
            reviewDiagramme.setProject(projectRepository.findById(projectDto.getId()).orElse(null));
        }

	    List<MapVersion> allVersions = reviewDiagramme.getMapVersions();
	    allVersions.forEach(mapVersion -> {
	        mapVersion.setDiagramName(mapDiagramRequestDTO.getDiagramName());
	    });
        reviewDiagramme.setMapVersions(allVersions);
        
	    if (MapPrivacy.SPECIFIC.equals(mapDiagramRequestDTO.getMapPrivacyType())) {
	        List<MapAccess> mapAccessList = new ArrayList<>();
 
 
	            for (MapDiagramRequestDTOResponse.MapAuthorizedUser user : mapDiagramRequestDTO.getMapAuthorizedUsers()) {
	                MapAccess mapAccess = new MapAccess();
	                mapAccess.setSpecificUser(user.getUserId().intValue());
	                mapAccess.setReviewDiagramme(reviewDiagramme);
	                mapAccessList.add(mapAccess);
	            }
	        mapAccessRepository.deleteByMapId(reviewDiagramme.getId());
 
	        reviewDiagramme.setMapAccess(mapAccessList);
	    } else {
	    	mapAccessRepository.deleteByMapId(reviewDiagramme.getId());
	        reviewDiagramme.setMapAccess(Collections.emptyList());
			mapAccessRepository.deleteByMapId(reviewDiagramme.getId());
	    }
 
	    return reviewDiagramme;
	}
 
 
	private MapDiagramRequestDTOResponse buildMapDiagramRequestDTOResponse(
			BpnmUserDiagramme diagramme, ReviewDiagramme reviewDiagramme) {

			// here the digrammme variable will be always null
			MapDiagramRequestDTOResponse response = new MapDiagramRequestDTOResponse();
			response.setId(reviewDiagramme.getId());

			// Add null checks using Optional
			Optional.ofNullable(reviewDiagramme.getConfigId())
			.ifPresent(response::setConfigId);

			Optional.ofNullable(reviewDiagramme.getConfigName())
			.ifPresent(response::setConfigName);

			response.setDiagramName(reviewDiagramme.getDiagramName());
//	        response.setDiagramXmlId(diagramme.getDiagramXmlId());
//	        response.setLanguageCode(diagramme.getLanguageCode());
			response.setAuthorUserId(Long.parseLong(reviewDiagramme.getAuthorUserId()));
			response.setMapPrivacyType(reviewDiagramme.getMapPrivacyType());
//	        response.setLanguageName(diagramme.getLanguageName());
			if (reviewDiagramme.getStorageType() != null) response.setDocStorageType(reviewDiagramme.getStorageType());
			if(reviewDiagramme.getProject() != null){
				ProjectDTO projectDto = new ProjectDTO();
				projectDto.setId(reviewDiagramme.getProject().getId());
				projectDto.setCustomerId(reviewDiagramme.getProject().getCustomer().getId());
				projectDto.setProjectName(reviewDiagramme.getProject().getProjectName());
				projectDto.setCustomerName(reviewDiagramme.getProject().getCustomer().getCustomerName());
				response.setProject(projectDto);	
			}
			


//			List<Long> masterDiagramIds = mapVersionRepository
//					.findByDiagramLevelForId(UtilsConstants.DiagramLevel.MASTER);
//			ReviewDiagramme map = mapReviewRepository.getById(reviewDiagramme.getId());
			// List<MapVersion> mapVersions = mapVersionRepository.findByMapId(reviewDiagramme.getId());

			// Map<String, Object> diagramXmlIdsMap = new HashMap<>();

			// // Initialize the map with the keys for Master, Archives, and Draft
			// diagramXmlIdsMap.put("Master", null);
			// diagramXmlIdsMap.put("Archives", new ArrayList<Map<String, Object>>());
			// diagramXmlIdsMap.put("Draft", null);

			// for (MapVersion mapVersion : mapVersions) {
			//     Long mapId = mapVersion.getReviewDiagramme().getId();
			//     ReviewDiagramme map = mapReviewRepository.getById(mapId);

			//     if (DiagramLevel.ARCHIVE.equalsIgnoreCase(mapVersion.getDiagramLevel())) {
			//         Map<String, Object> archiveMap = new HashMap<>();
			//         archiveMap.put("version", mapVersion.getDiagramVersion());
			//         archiveMap.put("diagramXmlId", mapVersion.getDiagramXmlId());
			//         archiveMap.put("status", map.getStatus());
			//         List<Map<String, Object>> archivesList = (List<Map<String, Object>>) diagramXmlIdsMap.get("Archives");
			//         archivesList.add(archiveMap);
			//     } else if (DiagramLevel.MASTER.equalsIgnoreCase(mapVersion.getDiagramLevel())) {
			//         if (diagramXmlIdsMap.get("Master") == null) {
			//             Map<String, Object> masterMap = new HashMap<>();
			//             masterMap.put("status", map.getStatus());
			//             masterMap.put("version", mapVersion.getDiagramVersion());
			//             masterMap.put("diagramXmlId", mapVersion.getDiagramXmlId());
			//             diagramXmlIdsMap.put("Master", masterMap);
			//         }
			//     } else if (DiagramLevel.DRAFT.equalsIgnoreCase(mapVersion.getDiagramLevel())) {
			//         if (diagramXmlIdsMap.get("Draft") == null) {
			//             Map<String, Object> draftMap = new HashMap<>();
			//             draftMap.put("status", map.getStatus());
			//             draftMap.put("version", mapVersion.getDiagramVersion());
			//             draftMap.put("diagramXmlId", mapVersion.getDiagramXmlId());
			//             diagramXmlIdsMap.put("Draft", draftMap);
			//         }
			//     }
			// }
			
			// response.setDiagramXmlIds(diagramXmlIdsMap);
			// Fetch the relevant MapVersion entity
			// MapVersion mapVersion = reviewDiagramme.getMapVersions().stream()
			// 		.filter(version -> version.getDiagramXmlId().equals(diagram.getDiagramXmlId())).findFirst()
			// 		.orElse(null);

			// if (mapVersion != null) {
			// 	 response.setDiagramLevel(mapVersion.getDiagramLevel());
			// }

			if (MapPrivacy.SPECIFIC.equals(reviewDiagramme.getMapPrivacyType())) {
				List<MapDiagramRequestDTOResponse.MapAuthorizedUser> authorizedUserDetails = reviewDiagramme
						.getMapAccess().stream().map(MapAccess::getSpecificUser)
						.map(userId -> bpmnUserRepository.findByUserId(userId.longValue())).filter(Objects::nonNull)
						.map(user -> new MapDiagramRequestDTOResponse.MapAuthorizedUser(user.getUserid(),
								user.getEmail(), user.getFirstname() + " " + user.getLastname()))
						.collect(Collectors.toList());
				response.setMapAuthorizedUsers(authorizedUserDetails);
			} else {
				response.setMapAuthorizedUsers(Collections.emptyList());
			}
 
			return response;
	}

	
	@Override
	public Map<String, Object> getLastSavedXml(Map<String, String> headers, int diagramXmlId) throws Exception{
		 
		//String userId = HeaderUtil.getUserId(headers);
		
		BpnmUserDiagramme diagrammeByXmlId = bpnmUserDiagrammeRepository.getByDiagramXmlId(diagramXmlId);
		MapVersion mapVersion = mapVersionRepository.findByDiaramXmlId(diagramXmlId);
	    Map<String, Object> responseMap = new HashMap<>();
		
	       
		try {
		
		   if (diagrammeByXmlId == null) {
	            throw new RuntimeException("Diagram not found");
	        }
		   if(mapVersion.getDiagramLevel().equals(DiagramLevel.DRAFT) && 
				   mapVersion.getDiagramEditStatus().equals(DiagramEditStatus.UNLOCKED)) {
			   
	        if (diagrammeByXmlId.getTimeStamp() != null  ) {
	            String createdTimestamp = diagrammeByXmlId.getTimeStamp();
	            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	            Date orderDate = simpleDateFormat.parse(createdTimestamp);
	            Date currentDate = new Date();

	            long differenceInMillis = currentDate.getTime() - orderDate.getTime();
	            boolean isRecentlyOpened = differenceInMillis <= ONE_MINUTES_IN_MILLIS;

	            if (isRecentlyOpened) {
	                log.debug("Diagram is currently opened by another editor.");
	                throw new Exception("The map was already opened by another editor, please try again later");
	            }
	        }
	        
		  }
		   ReviewDiagramme reviewDiagramme = mapReviewRepository.getByMapId(mapVersion.getReviewDiagramme().getId());
	            
		   responseMap.put("diagramXmlId", diagrammeByXmlId.getDiagramXmlId());
	            responseMap.put("diagramName", diagrammeByXmlId.getDiagramName());
	            responseMap.put("docStorageType", reviewDiagramme.getStorageType());
	            responseMap.put("configName", reviewDiagramme.getConfigName());
	            responseMap.put("configId", reviewDiagramme.getConfigId());
	            responseMap.put("languageCode", diagrammeByXmlId.getLanguageCode());
	            responseMap.put("languageName", diagrammeByXmlId.getLanguageName());
	            responseMap.put("xmlData", diagrammeByXmlId.getXmlData());
	            responseMap.put("template", diagrammeByXmlId.getTemplate());
	            responseMap.put("diagramEditStatus", mapVersion.getDiagramEditStatus());
	            responseMap.put("version", mapVersion.getDiagramVersion());
	            responseMap.put("diagramLevel", mapVersion.getDiagramLevel());
	           
	            responseMap.put("diagramStatus", reviewDiagramme.getStatus());
	            
//	            responseMap.put("mapPrivacyType", reviewDiagramme.getMapPrivacyType());
//
//	            if (MapPrivacy.SPECIFIC.equals(reviewDiagramme.getMapPrivacyType())) {
//	                List<MapDiagramRequestDTOResponse.MapAuthorizedUser> authorizedUserDetails = mapAccessRepository
//	                    .findByDiagramXmlId(diagramXmlId).stream()
//	                    .map(MapAccess::getSpecificUser)
//	                    .map(user -> bpmnUserRepository.findByUserId(user.longValue()))
//	                    .filter(Objects::nonNull)
//	                    .map(user -> new MapDiagramRequestDTOResponse.MapAuthorizedUser(
//	                        user.getUserid(), 
//	                        user.getEmail(), 
//	                        user.getFirstname() + " " + user.getLastname()
//	                    ))
//	                    .collect(Collectors.toList());
//
//	                responseMap.put("mapAuthorizedUsers", authorizedUserDetails);
//	            } else {
//	                responseMap.put("mapAuthorizedUsers", Collections.emptyList());
//	            }

	            bpnmUserDiagrammeRepository.updateTimeStamp(diagramXmlId, timeStampUpdation.getTimeStamp());

	      
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
    return responseMap;
		
	}

	@Override
	public void updateOrderTimestamp(int diagramXmlId, String checkType){
		
		String currentTimestamp= timeStampUpdation.getTimeStamp();
		
	    	if(checkType.equals(Check.CHECKIN.toString())) {
	    		bpnmUserDiagrammeRepository.updateTimeStamp(diagramXmlId,currentTimestamp);
	    		bpnmUserDiagrammeRepository.flush();
	    		entityManager.clear();
	    	}
	    	else {
	    		bpnmUserDiagrammeRepository.updateTimeStamp(diagramXmlId,null);
	    		bpnmUserDiagrammeRepository.flush();
	    		entityManager.clear();
	    	}
	}

}
