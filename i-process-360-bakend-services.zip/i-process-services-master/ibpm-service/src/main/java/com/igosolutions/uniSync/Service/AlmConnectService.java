package com.igosolutions.uniSync.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.ALMConnect;
import com.igosolutions.uniSync.Modal.ALMConnectDto;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Respository.AlmConnectRepository;
import com.igosolutions.uniSync.Respository.DataSourceRepository;

@Service
public class AlmConnectService {

    @Autowired
    AlmConnectRepository almConnectRepository;

    @Autowired
    DataSourceRepository dataSourceRepository;

    @Autowired
    DataSourceService dataSourceService;
    
    @Autowired
    EntityManager entityManger;
    
    public ResponseEntity<?> connectAlmActivity(ALMConnectDto almConnectDto) {
        try {

            Optional<DataSource> dataSourceOpt = dataSourceRepository.findById(almConnectDto.getDataSourceId());
            if (dataSourceOpt.isPresent()) {
                ALMConnect almConnectExistingData = almConnectRepository
                        .findByMapIdAndDiagramXmlIdAndActivityIdAndCurreLevelId(almConnectDto.getMapId(),
                                almConnectDto.getDiagramXmlId(), almConnectDto.getActivityId(),
                                almConnectDto.getCurrLevelId(),almConnectDto.getAlmModuleType());
                if (almConnectExistingData != null) {
                    almConnectExistingData.setTestIds(almConnectDto.getTestIds());
                    almConnectExistingData.setDataSource(dataSourceOpt.get());
                    ALMConnect almConnectData = almConnectRepository.save(almConnectExistingData);
                    return new ResponseEntity<>(almConnectData, HttpStatus.OK); // Updated status to OK
                }
                ALMConnect almConnect = mapToEntity(almConnectDto);
                almConnect.setDataSource(dataSourceOpt.get());
                ALMConnect almConnectData = almConnectRepository.save(almConnect);

                return new ResponseEntity<>(almConnectData, HttpStatus.CREATED);// Updated status to CREATED
            } else {
                return new ResponseEntity<>("Data Source not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    private ALMConnect mapToEntity(ALMConnectDto almConnectDto) {
        ALMConnect almConnect = new ALMConnect();
        almConnect.setMapId(almConnectDto.getMapId());
        almConnect.setDiagramXmlId(almConnectDto.getDiagramXmlId());
        almConnect.setActivityId(almConnectDto.getActivityId());
        almConnect.setTestIds(almConnectDto.getTestIds());
        almConnect.setCurrLevelId(almConnectDto.getCurrLevelId());
        return almConnect;
    }

    public ResponseEntity<?> getActivityALMConnect(Long almConnectId) {
       try {
        Map<String, Object> response = new HashMap<String, Object>();
        
        Optional<ALMConnect> almConnectDataOpt = almConnectRepository.findById(almConnectId);
        if (almConnectDataOpt.isPresent()) {
            ALMConnect almConnectData = almConnectDataOpt.get();
            List<Map<String, Object>> fetchResponse =null;
            if(almConnectData.getDataSource().getModulename().equals("Testing")){
                fetchResponse = dataSourceService.fetchTestFoldersTestCaseDesignSteps(almConnectData.getDataSource());
            }
            else
            {
                    fetchResponse = dataSourceService.fetchALMRequirementsData(almConnectData.getDataSource());
            }
            response.put("testIds", almConnectData.getTestIds());
            response.put("almData", fetchResponse);
            response.put("almDataType", almConnectData.getDataSource().getModulename());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>("Data Source not found for the almConnect", HttpStatus.NOT_FOUND);
        }
        
        
       } catch (Exception e) {
        e.printStackTrace();
        return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
       }
    
    }

    public ResponseEntity<?> deleteActivityALMConnect(Long almConnectId) {
        try {
        	  
        	almConnectRepository.deleteByAlmId(almConnectId);
          //  entityManger.flush();
            return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
