package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Connection")
public class Connection {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long   connectionId;
	private String connectionName;
	private String masterDatasourceId;
	private String targetDatasourceId;
    private String masterprojectname;
	private String targetprojectname;
	private String connectionCreationDate;
	private String createdBy;
	private String masterdatasource;
	private String targetdatasource;
	private String connectionUpdateDate;
	private String updateBy;
	private String mappingField;
	private String masterCondition;
	private String userDefinevalues;
	private String connectionstatus;
	private String onoff;
	private String switchONtime;
	private String switchOFFtime;
	private String switchfalg;
	
	@Override
	public String toString() {
	/*	return "Connection [connectionId=" + connectionId + ", connectionName=" + connectionName
				+ ", masterDatasourceId=" + masterDatasourceId + ", targetDatasourceId=" + targetDatasourceId
				+ ", masterprojectname=" + masterprojectname + ", targetprojectname=" + targetprojectname
				+ ", connectionCreationDate=" + connectionCreationDate + ", createdBy=" + createdBy
				+ ", masterdatasource=" + masterdatasource + ", targetdatasource=" + targetdatasource
				+ ", connectionUpdateDate=" + connectionUpdateDate + ", updateBy=" + updateBy + ", mappingField="
				+ mappingField + ", masterCondition=" + masterCondition + ", userDefinevalues=" + userDefinevalues
				+ ", connectionstatus=" + connectionstatus + "]";
				
				*/
		
		return "Connection [connectionId=" + connectionId + ", connectionName=" + connectionName
				+ ", masterDatasourceId=" + masterDatasourceId + ", targetDatasourceId=" + targetDatasourceId
				+ ", masterprojectname=" + masterprojectname + ", targetprojectname=" + targetprojectname
				+ ", connectionCreationDate=" + connectionCreationDate + ", createdBy=" + createdBy
				+ ", masterdatasource=" + masterdatasource + ", targetdatasource=" + targetdatasource
				+ ", connectionUpdateDate=" + connectionUpdateDate + ", updateBy=" + updateBy + ", mappingField="
				+ mappingField + ", masterCondition=" + masterCondition + ", userDefinevalues=" + userDefinevalues
				+ ", connectionstatus=" + connectionstatus + ",onoff=" + onoff+ "]";
		
	}
	
	
	
	public String getswitchfalg() {
		return switchfalg;
	} 
	
	public void setswitchfalg(String switchfalg) {
		this.switchfalg = switchfalg;
	}
	
	public String getONTime() {
		return switchONtime;
	} 
	
	public void setONTime(String switchONtime) {
		this.switchONtime = switchONtime;
	}
	
	public String getOFFTime() {
		return switchOFFtime;
	} 
	
	public void setOFFTime(String switchOFFtime) {
		this.switchOFFtime = switchOFFtime;
	}
	
	public String getConnectionstatusONOF() {
		return onoff;
	}
	
	public void setConnectionstatusONOF(String ISON) {
		this.onoff = ISON;
	}
	
	public String getConnectionstatus() {
		return connectionstatus;
	}
	
	public void setConnectionstatus(String connectionstatus) {
		this.connectionstatus = connectionstatus;
	}
	
	public Long getConnectionId() {
		return connectionId;
	}
	public void setConnectionId(Long connectionId) {
		this.connectionId = connectionId;
	}
	public String getConnectionName() {
		return connectionName;
	}
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}
	public String getMasterDatasourceId() {
		return masterDatasourceId;
	}
	public void setMasterDatasourceId(String masterDatasourceId) {
		this.masterDatasourceId = masterDatasourceId;
	}
	public String getTargetDatasourceId() {
		return targetDatasourceId;
	}
	public void setTargetDatasourceId(String targetDatasourceId) {
		this.targetDatasourceId = targetDatasourceId;
	}
	public String getMasterprojectname() {
		return masterprojectname;
	}
	public void setMasterprojectname(String masterprojectname) {
		this.masterprojectname = masterprojectname;
	}
	public String getTargetprojectname() {
		return targetprojectname;
	}
	public void setTargetprojectname(String targetprojectname) {
		this.targetprojectname = targetprojectname;
	}
	public String getConnectionCreationDate() {
		return connectionCreationDate;
	}
	public void setConnectionCreationDate(String connectionCreationDate) {
		this.connectionCreationDate = connectionCreationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getMasterdatasource() {
		return masterdatasource;
	}
	public void setMasterdatasource(String masterdatasource) {
		this.masterdatasource = masterdatasource;
	}
	public String getTargetdatasource() {
		return targetdatasource;
	}
	public void setTargetdatasource(String targetdatasource) {
		this.targetdatasource = targetdatasource;
	}
	public String getConnectionUpdateDate() {
		return connectionUpdateDate;
	}
	public void setConnectionUpdateDate(String connectionUpdateDate) {
		this.connectionUpdateDate = connectionUpdateDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getMappingField() {
		return mappingField;
	}
	public void setMappingField(String mappingField) {
		this.mappingField = mappingField;
	}
	public String getMasterCondition() {
		return masterCondition;
	}
	public void setMasterCondition(String masterCondition) {
		this.masterCondition = masterCondition;
	}
	public String getUserDefinevalues() {
		return userDefinevalues;
	}
	public void setUserDefinevalues(String userDefinevalues) {
		this.userDefinevalues = userDefinevalues;
	}





	
}
