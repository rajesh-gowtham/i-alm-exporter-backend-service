package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "resource")
public class Resource {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	@Column(name = "resourcename")
    private String resourceName;
	@Column(name = "displayname")
    private String displayName;
	@Column(name = "infofield1")
    private String infoField1;
	@Column(name = "infofield2")
    private String infoField2;
	@Column(name = "type")
    private String type;
	@Column(name = "organization")
    private String organization;
	@Column(name = "resource_color")
	private String resourceColor;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getInfoField1() {
		return infoField1;
	}
	public void setInfoField1(String infoField1) {
		this.infoField1 = infoField1;
	}
	public String getInfoField2() {
		return infoField2;
	}
	public void setInfoField2(String infoField2) {
		this.infoField2 = infoField2;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getResourceColor() {
		return resourceColor;
	}
	public void setResourceColor(String resourceColor) {
		this.resourceColor = resourceColor;
	}
	@Override
	public String toString() {
		return "Resource [id=" + id + ", resourceName=" + resourceName + ", displayName=" + displayName
				+ ", infoField1=" + infoField1 + ", infoField2=" + infoField2 + ", type=" + type + ", organization="
				+ organization + ", resourceColor=" + resourceColor + "]";
	}
	
	
	
    
	
}
