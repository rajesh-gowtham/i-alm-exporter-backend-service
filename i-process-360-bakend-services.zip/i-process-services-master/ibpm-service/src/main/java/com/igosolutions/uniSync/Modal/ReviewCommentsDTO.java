package com.igosolutions.uniSync.Modal;

import java.util.Date;

public class ReviewCommentsDTO {

    private Long commentId;
	
    private Integer diagramXmlId;

    private String currentXmlId;

    private String commentMessage;

    private Date timeStamp;

    private Long commentedUserId;

    private String mapDiagramStatus;
    
    private String userName;
    
    private int versionName;

	private String activityId;
	private int activityNum;
	private String role;
    private Boolean flagToggleActivity;
	public Long getCommentId() {
		return commentId;
	}
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}
	public Integer getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(Integer diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public String getCurrentXmlId() {
		return currentXmlId;
	}
	public void setCurrentXmlId(String currentXmlId) {
		this.currentXmlId = currentXmlId;
	}
	public String getCommentMessage() {
		return commentMessage;
	}
	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	public Long getCommentedUserId() {
		return commentedUserId;
	}
	public void setCommentedUserId(Long commentedUserId) {
		this.commentedUserId = commentedUserId;
	}
	public String getMapDiagramStatus() {
		return mapDiagramStatus;
	}
	public void setMapDiagramStatus(String mapDiagramStatus) {
		this.mapDiagramStatus = mapDiagramStatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getVersionName() {
		return versionName;
	}
	public void setVersionName(int versionName) {
		this.versionName = versionName;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public int getActivityNum() {
		return activityNum;
	}
	public void setActivityNum(int activityNum) {
		this.activityNum = activityNum;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Boolean getFlagToggleActivity() {
		return flagToggleActivity;
	}
	public void setFlagToggleActivity(Boolean flagToggleActivity) {
		this.flagToggleActivity = flagToggleActivity;
	}
    
    
}
