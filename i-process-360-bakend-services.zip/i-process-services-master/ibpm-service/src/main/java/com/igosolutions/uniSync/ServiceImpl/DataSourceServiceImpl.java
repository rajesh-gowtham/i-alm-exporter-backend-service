package com.igosolutions.uniSync.ServiceImpl;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.igosolutions.uniSync.Modal.ALMConnect;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Respository.AlmConnectRepository;
import com.igosolutions.uniSync.Respository.DataSourceRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Service.DataSourceService;
import com.igosolutions.uniSync.exceptions.ALMServerException;
import com.igosolutions.uniSync.utils.HeaderUtil;

@Service
public class DataSourceServiceImpl implements DataSourceService {

	@Autowired
	public DataSourceRepository repo;

	@Autowired
	EntityManager entityManager;

	@Autowired
	private MapReviewRepository mapReviewRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private AlmConnectRepository almConnectRepository;

	Logger logger = LoggerFactory.getLogger(DataSourceServiceImpl.class);

	@Override
	public void saveDataSource(DataSource datasource) throws Exception {
		try {
		
		DataSource isExist = repo.findByDataSourceNameAndOrganization(datasource.getDatasourcename(),datasource.getOrganization());
		if(isExist != null) {
			
			throw new Exception("DataSource name already exist.");
		}
		else
		  repo.save(datasource);
		}catch(Exception e) {
			
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public List<DataSource> getAllDataSource(String organization) {

		List<DataSource> dataSourceData = (List<DataSource>) repo.findAllByOrganization(organization);
		System.out.println("the data source data items isssss" + dataSourceData);
		return dataSourceData;
	}

	@Override
	public boolean findDataSouceName(String datasourcename) {
		DataSource source = repo.existsByDatasourcename(datasourcename);
		if (source == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public DataSource getDataSource(String datasourcename) {
		DataSource source = repo.existsByDatasourcename(datasourcename);
		System.out.println("the source name is" + source);
		return source;
	}

	@Override
	public void updateDataSource(DataSource datasource,Long id) throws Exception {
		try {
		
			DataSource source = repo.findById(id)
					
                    .orElseThrow(() -> new Exception("DataSource not found with id: " + id));

		
		if(source.getModulename().equals(datasource.getModulename()) 
				&& source.getDomainname().equals(datasource.getDomainname())
				&& source.getProjectname().equals(datasource.getProjectname())) {
			
			source.setUrl(datasource.getUrl());
	        source.setUsername(datasource.getUsername());
	        source.setPassword(datasource.getPassword());
	        source.setDatasourcename(datasource.getDatasourcename());
	        source.setDefectTool(datasource.getDefectTool());
	        source.setTechniciankey(datasource.getTechniciankey());
	        source.setClientId(datasource.getClientId());
	        source.setClientSecret(datasource.getClientSecret());
	        source.setTenantId(datasource.getTenantId());
	        source.setSiteName(datasource.getSiteName());
		 
			repo.save(source);
			
		}
	
		else {
			
			throw new Exception("Not Accepted");
		}
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		
	}
	
	@Override
	public DataSource selectDomanin(String targetdatasource) {
		System.out.println("INFO 3344 targetdatasource"+targetdatasource);
		DataSource source=	repo.selectDomanin(targetdatasource);
		return source;
	}
	
	
	@Override
	@Transactional
	public ResponseEntity<?> deleteDataSource(Long id, String organization) {
		try {
			Optional<DataSource> byId = repo.findById(id);
			if (byId.isPresent()) {
				List<ReviewDiagramme> maps = mapReviewRepository.findByConfigId(id.toString());
				List<ALMConnect> almConnectData = almConnectRepository.findByDataSourceId(id);
				if (!almConnectData.isEmpty()) {
					return new ResponseEntity<>("Cannot delete data source as it is associated with ALM Connection", HttpStatus.BAD_REQUEST);
				}
				if (!maps.isEmpty()) {
					return new ResponseEntity<>("Cannot delete data source as it is associated with Maps", HttpStatus.BAD_REQUEST);
				}
				repo.deleteById(id);
				repo.flush();
				entityManager.clear();
				return new ResponseEntity<>(repo.findAllByOrganization(organization), HttpStatus.OK);
			}
			else{
				return new ResponseEntity<>("Data Source not found", HttpStatus.NOT_FOUND);
			}
			
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@Override
	public Map<String, String> defectToolAuthentication(DataSource authmodal) throws Exception {
		// Call the isValidUser method to authenticate the user and get the response headers
        ResponseEntity<String> responseEntity = isValidUser(authmodal);

        // Extract necessary headers (XSRF-TOKEN, cookies, etc.)
        HttpHeaders headers = responseEntity.getHeaders();
        String lwssoCookie = getCookie(headers, "LWSSO_COOKIE_KEY"); // Extract LWSSO cookie


        if (responseEntity.getStatusCode().is2xxSuccessful()) {
			 // Now call generateXSRFTOKEN to fetch the XSRF token and session-related cookies
			 Map<String, String> tokenData = generateXSRFTOKEN(lwssoCookie, authmodal.getUrl());

			 // Extract XSRF token and other cookies
			 String xsrfHeaderValue = tokenData.get("xsrfHeaderValue");
			 String cookies = tokenData.get("cookies");
            // Construct the authentication response map
            Map<String, String> authResponse = new HashMap<>();
            authResponse.put("xsrfHeaderValue", xsrfHeaderValue);
            authResponse.put("lwssoCookie", lwssoCookie);
            authResponse.put("responseMessage", responseEntity.getStatusCode().toString());
            authResponse.put("cookies", cookies);
            return authResponse;
        } else {
        	
            throw new Exception("Authentication failed: " + responseEntity.getStatusCode());
        }
	}

	public ResponseEntity<String> isValidUser(DataSource authmodal) throws Exception {
        String authEndPoint = authmodal.getUrl() + "/qcbin/authentication-point/alm-authenticate";
        String authBody = "<alm-authentication><user>" + authmodal.getUsername() + "</user><password>"
                + authmodal.getPassword() + "</password></alm-authentication>";

        try {
            // Prepare headers and request body
            HttpHeaders headers = new HttpHeaders();
            headers.set("Content-Type", "application/xml");
            HttpEntity<String> requestEntity = new HttpEntity<>(authBody, headers);
            // Perform POST request and return response entity
			return restTemplate.exchange(authEndPoint, HttpMethod.POST, requestEntity, String.class);
        } catch (HttpClientErrorException ex) {
			ex.printStackTrace();
            throw new ALMServerException("Authentication failed: " + ex.getStatusCode() + " - " + ex.getResponseBodyAsString());
        }catch(Exception e) {
        	
        	logger.info("getting info message "+e.getMessage());
        	logger.error("getting error message"+e.getMessage());
        	System.out.println("Alm auth failed trace");
        
        	e.printStackTrace();
            throw new Exception(e.getMessage());

        }
		
    }
	private String getCookie(HttpHeaders headers, String cookieName) {
        List<String> cookies = headers.get(HttpHeaders.SET_COOKIE);
        if (cookies != null) {
            for (String cookie : cookies) {
                if (cookie.contains(cookieName)) {
                    return cookie;
                }
            }
        }
        return null;
    }
	private String getXsrfTokenFromCookies(HttpHeaders headers) {
		List<String> cookies = headers.get(HttpHeaders.SET_COOKIE);
		if (cookies != null) {
			for (String cookie : cookies) {
				String content = cookie.split(";")[0];

				String[] nameValue = content.split("=");
				String name = nameValue[0];
				String value = nameValue[1];
				if (name.equalsIgnoreCase("XSRF-TOKEN")) {
					return value;
				}
			}
		}
		

		return null; // Return null if no XSRF-TOKEN found
	}
	private String getCookiesAsStringWithoutXsrf(HttpHeaders responseHeaders) {
		List<String> cookies = responseHeaders.get(HttpHeaders.SET_COOKIE);
		StringBuilder cookieString = new StringBuilder();
		
		if (cookies != null) {
			for (String cookie : cookies) {
				String content = cookie.split(";")[0]; // Get only the name=value part of each cookie
				cookieString.append(content).append(";"); // Append to the final cookie string
			}
		}
		
		return cookieString.toString();
	}
	public Map<String, String> generateXSRFTOKEN(String lwssoCookie, String almURL) throws MalformedURLException, ALMServerException {
        String qcSessionEndPoint = almURL + "/qcbin/rest/site-session";
        HttpHeaders headers = new HttpHeaders();
        headers.add("Cookie", lwssoCookie);
        headers.add("Content-Type", "application/json");

        HttpEntity<String> requestEntity = new HttpEntity<>(null, headers);

        try {
            // Send POST request to create a session and retrieve the headers
            ResponseEntity<String> responseEntity = restTemplate.exchange(qcSessionEndPoint, HttpMethod.POST, requestEntity, String.class);
			logger.info("Response Status Code for generateXSRFTOKEN: " + responseEntity.getStatusCode());
            // Check the response code for success (should be HTTP 201 Created)
            if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                throw new ALMServerException("Failed to create session: HTTP code " + responseEntity.getStatusCode());
            }

            // Extract headers and cookies
            HttpHeaders responseHeaders = responseEntity.getHeaders();
            String xsrfHeaderValue = getXsrfTokenFromCookies(responseHeaders);
            String allCookies = getCookiesAsStringWithoutXsrf(responseHeaders);

            // Prepare the result map
            Map<String, String> resultMap = new HashMap<>();
            resultMap.put("lwssoCookie", lwssoCookie);
            resultMap.put("xsrfHeaderValue", xsrfHeaderValue);
            resultMap.put("cookies", allCookies);

            return resultMap;

        } catch (HttpClientErrorException ex) {
            throw new ALMServerException("Failed to create session: " + ex.getStatusCode() + " - " + ex.getResponseBodyAsString());
        }
    }

	@Override
	public List<String> getAllDomain(Map<String, String> tokens) throws Exception {
		String lwssoCookie = tokens.get("lwssoCookie");
		String xsrfHeaderValue = tokens.get("xsrfHeaderValue");
		String almHostedUrl = tokens.get("almHostedUrl");
		String cookies = tokens.get("cookies");
		String listAllDomainURL = almHostedUrl + "/qcbin/api/domains";

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.add("Cookie", cookies + lwssoCookie);
		requestHeaders.add("X-XSRF-TOKEN", xsrfHeaderValue);
		requestHeaders.add("Content-Type", "application/JSON");
		requestHeaders.add("Accept", "application/JSON");

		HttpEntity<String> entity = new HttpEntity<>(null, requestHeaders);

		try {
			ResponseEntity<String> response = restTemplate.exchange(listAllDomainURL, HttpMethod.GET, entity,
					String.class);
			logger.info("Response Status Code for getAllDomain: " + response.getStatusCode());
			String body = response.getBody();
			// Parse the response JSON and extract 'name' fields
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode root = objectMapper.readTree(body);
			List<String> domainNames = new ArrayList<>();

			for (JsonNode result : root.path("results")) {
				String name = result.path("name").asText();
				domainNames.add(name);
			}

			return domainNames;
		} catch (HttpClientErrorException e) {
			throw new ALMServerException(
					"Failed to Retrieve Domain: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
		}
	}
	@Override
	public List<Object> getAllProjectsForDomain(String domainname, Map<String, String> tokens) throws Exception {

		String lwssoCookie = tokens.get("lwssoCookie");
		String xsrfHeaderValue = tokens.get("xsrfHeaderValue");
		String almURL = tokens.get("almHostedUrl");
		String cookies = tokens.get("cookies");
		String listAllProjectsInDomain = almURL + "/qcbin/api/domains/" + domainname + "/projects";
		// Getting the Access Data through headers

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set(HttpHeaders.COOKIE, cookies + lwssoCookie);
		requestHeaders.set("X-XSRF-TOKEN", xsrfHeaderValue);
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(requestHeaders);

		try {

			ResponseEntity<String> responseEntity = restTemplate.exchange(listAllProjectsInDomain, HttpMethod.GET,
					entity, String.class);
			logger.info("Response Status Code for getAllProjectsForDomain: " + responseEntity.getStatusCode());		
			String body = responseEntity.getBody();

			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode root = objectMapper.readTree(body);
			List<Object> projects = new ArrayList<>();
			for (JsonNode result : root.path("results")) {
				projects.add(result.path("name").asText());
			}
			return projects;

		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().is4xxClientError()) {
				throw new ALMServerException("Failed to Retrieve Projects: 403 : Forbidden");
			}
			throw new ALMServerException(
					"Failed to Retrieve Projects: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
		}

	}
	
	@Override
	public List<Map<String, Object>> fetchTestFolders(DataSource datasource)
			throws ALMServerException, Exception {
		try {
			Map<String, String> tokens = defectToolAuthentication(datasource);
			String lwssoCookie = tokens.get("lwssoCookie");
			String xsrfHeaderValue = tokens.get("xsrfHeaderValue");
			// String almHostedUrl = tokens.get("almHostedUrl");
			String cookies = tokens.get("cookies");
			String almUrl = datasource.getUrl() + "/qcbin";
			String testUrl = almUrl + "/rest/domains/" + datasource.getDomainname() + "/projects/"
					+ datasource.getProjectname() + "/tests?page-size=max";

			logger.info("Constructed URLs: testUrl = {}", testUrl);
			if (datasource.getDefectTool().equals("ALM")) {
				if (datasource.getModulename().equals("Testing")) {
					CompletableFuture<Map<String, Object>> testResponseFuture = CompletableFuture.supplyAsync(() -> {
						try {
							return callAlmApi(testUrl, xsrfHeaderValue, lwssoCookie, cookies);
						} catch (Exception e) {
							throw new ALMServerException(e.getMessage());
						}
					});
					CompletableFuture<Map<String, Object>> designStepsFuture = CompletableFuture.supplyAsync(() -> {
						try {
							return getDesignStepsMap(datasource.getUrl(), datasource.getDomainname(),
									datasource.getProjectname(), xsrfHeaderValue, lwssoCookie, cookies);
						} catch (Exception e) {
							throw new ALMServerException(e.getMessage());
						}
					});

					// Wait for all the responses
					CompletableFuture.allOf(testResponseFuture, designStepsFuture).join();

					// Collecting results
					Map<String, Object> designStepsResponse = designStepsFuture.get();
					Map<String, Object> testResponse = testResponseFuture.get();

					List<Map<String, Object>> response = new ArrayList<>();

					Map<String, Object> map2 = new HashMap<>();
					map2.put("TestCase", testResponse);
					response.add(map2);

					Map<String, Object> map3 = new HashMap<>();
					map3.put("DesignSteps", designStepsResponse);
					response.add(map3);

					return response;
				} else {
					throw new ALMServerException("Module not supported");
				}
			} else {
				throw new ALMServerException("Defect Tool not supported");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	@SuppressWarnings("unchecked")
	public Map<String, Object> callAlmApi(String apiUrl, String xsrfHeaderValue, String lwssoCookie, String cookies)
			throws ALMServerException, Exception {
		
			HttpHeaders headers = new HttpHeaders();
			headers.set(HttpHeaders.COOKIE, cookies + lwssoCookie);
			headers.set(HttpHeaders.ACCEPT, "application/json");
			headers.set(HttpHeaders.CONTENT_TYPE, "application/json");
			headers.set("X-XSRF-TOKEN", xsrfHeaderValue);

			HttpEntity<String> request = new HttpEntity<>(headers);

			try {
				ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.GET, request, String.class);
				logger.info("Response Status Code for callAlmApi: " + response.getStatusCode());
				if (response.getStatusCode().is2xxSuccessful()) {
					ObjectMapper objectMapper = new ObjectMapper();
					return (Map<String, Object>) objectMapper.readValue(response.getBody(), Map.class);
                } else {
					if (response.getStatusCode().is4xxClientError()) {
						throw new ALMServerException("API call failed: 403 : Forbidden" );
					}
					throw new ALMServerException("API call failed: " + response.getStatusCode());
				}
                    
					
			} catch (HttpClientErrorException e) {
				if (e.getStatusCode().is4xxClientError()) {
					throw new ALMServerException("API call failed: 403 : Forbidden" );
				}
				throw new ALMServerException("API call failed: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
			}
			catch (Exception e) {
				throw e;
			}
	}
	public Map<String, Object> getDesignStepsMap(String url, String domainname, String projectname,
			String xsrfHeaderValue, String lwssoCookie, String cookies) throws Exception {

		int totalResults = 0;
		int pageSize = 2000;
		int startIndex = 1;
		Map<String, Object> finalResult = new HashMap<>();
		List<Map<String, Object>> allEntities = new ArrayList<>();
		RestTemplate restTemplate = new RestTemplate(); // Ensure RestTemplate is initialized
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			do {
				// Create headers for the request
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-XSRF-TOKEN", xsrfHeaderValue);
				headers.set(HttpHeaders.COOKIE, cookies + lwssoCookie);
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

				HttpEntity<String> request = new HttpEntity<>(headers);

				// Perform the API request using RestTemplate
				ResponseEntity<String> response = restTemplate.exchange(
						url + "/qcbin/rest/domains/" + domainname + "/projects/" + projectname
								+ "/design-steps?page-size=" + pageSize + "&start-index=" + startIndex,
						HttpMethod.GET, request, String.class);

				// Ensure the response is successful
				logger.info("Response Status Code for getDesignStepsMap: " + response.getStatusCode());
				if (!response.getStatusCode().is2xxSuccessful()) {
					logger.error("Failed to fetch data: HTTP code " + response.getStatusCode());
					if (response.getStatusCode().is4xxClientError()) {
						throw new ALMServerException("Failed to fetch data: HTTP code : 403 : Forbidden");
					}

					throw new ALMServerException("Failed to fetch data: HTTP code " + response.getStatusCode());
				}

				// Parse the response body as JSON
				String responseBody = response.getBody();
				@SuppressWarnings("unchecked")
				Map<String, Object> responseMap = objectMapper.readValue(responseBody, Map.class);

				// Extract "entities" and append them to allEntities list
				@SuppressWarnings("unchecked")
				List<Map<String, Object>> entities = (List<Map<String, Object>>) responseMap.get("entities");
				if (entities != null) {
					allEntities.addAll(entities);
				}

				// Extract the totalResults to determine whether we need more requests
				totalResults = (int) responseMap.get("TotalResults");
				logger.info("Total Results: " + totalResults);
				logger.info("Current Fetched Entities: " + allEntities.size());

				// Increment startIndex for the next page of results
				startIndex += pageSize;

			} while (allEntities.size() < totalResults); // Continue until all entities are fetched

			// Add all entities to the final result map
			finalResult.put("entities", allEntities);
			finalResult.put("TotalResults", totalResults);

			return finalResult;

		} catch (HttpClientErrorException ex) {
			logger.error("HTTP Client Error: " + ex.getStatusCode() + " - " + ex.getResponseBodyAsString());
			if (ex.getStatusCode().is4xxClientError()) {
				throw new ALMServerException("Failed to fetch data: HTTP code : 403 : Forbidden");
			}
			throw new ALMServerException(
					"Failed to fetch data: HTTP code " + ex.getStatusCode() + " - " + ex.getResponseBodyAsString());
		} catch (Exception e) {
			logger.error("Exception occurred while fetching design steps: " + e.getMessage(), e);
			throw e;
		}
	}
	@Override
	public List<Map<String, Object>> fetchTestFoldersTestCaseDesignSteps(DataSource dataSource)
			throws ALMServerException, Exception {
		try {
			Map<String, String> tokens = defectToolAuthentication(dataSource);
			String lwssoCookie = tokens.get("lwssoCookie");
			String xsrfHeaderValue = tokens.get("xsrfHeaderValue");
			String almHostedUrl = dataSource.getUrl();
			String cookies = tokens.get("cookies");
			String almUrl = almHostedUrl + "/qcbin";
			String folderUrl = almUrl + "/rest/domains/" + dataSource.getDomainname() + "/projects/" + dataSource.getProjectname()
					+ "/test-folders?page-size=max";
			String testUrl = almUrl + "/rest/domains/" + dataSource.getDomainname() + "/projects/" + dataSource.getProjectname() + "/tests?page-size=max";

			logger.info("Constructed URLs: folderUrl = {}, testUrl = {}", folderUrl, testUrl);
			// Completable future for paralle api Calls
			CompletableFuture<Map<String, Object>> folderResponseFuture = CompletableFuture.supplyAsync(() -> {
				try {
					return callAlmApi(folderUrl, xsrfHeaderValue, lwssoCookie, cookies);
				} catch (Exception e) {
					throw new ALMServerException(e.getMessage());
				}
			});

			CompletableFuture<Map<String, Object>> testResponseFuture = CompletableFuture.supplyAsync(() -> {
				try {
					return callAlmApi(testUrl, xsrfHeaderValue, lwssoCookie, cookies);
				} catch (Exception e) {
					throw new ALMServerException(e.getMessage());
				}
			});
			CompletableFuture<Map<String,Object>> designStepsFuture = CompletableFuture.supplyAsync(() -> {
				try {
					return getDesignStepsMap(almHostedUrl, dataSource.getDomainname(), dataSource.getProjectname(), xsrfHeaderValue, lwssoCookie, cookies);
				} catch (Exception e) {
					throw new ALMServerException(e.getMessage());
				}
			});

			// Wait for all the responses
			CompletableFuture.allOf(folderResponseFuture, testResponseFuture, designStepsFuture).join();

			//Collecting results
			Map<String, Object> folderResponse = folderResponseFuture.get();
			Map<String, Object> designStepsResponse = designStepsFuture.get();
			Map<String, Object> testResponse = testResponseFuture.get();

			List<Map<String, Object>> response = new ArrayList<>();
			Map<String, Object> map1 = new HashMap<>();
			map1.put("TestFolders", folderResponse);
			response.add(map1);

			Map<String, Object> map2 = new HashMap<>();
			map2.put("TestCase", testResponse);
			response.add(map2);

			Map<String, Object> map3 = new HashMap<>();
			map3.put("DesignSteps", designStepsResponse);
			response.add(map3);

			return response;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	@Override
	public List<Map<String, Object>> fetchALMRequirementsData(DataSource dataSource)
			throws ALMServerException, Exception {
		try {
			Map<String, String> tokens = defectToolAuthentication(dataSource);
			String lwssoCookie = tokens.get("lwssoCookie");
			String xsrfHeaderValue = tokens.get("xsrfHeaderValue");
			String almHostedUrl = dataSource.getUrl();
			String cookies = tokens.get("cookies");
			String almUrl = almHostedUrl + "/qcbin";
			String requirementUrl = almUrl + "/rest/domains/" + dataSource.getDomainname() + "/projects/"
					+ dataSource.getProjectname() + "/requirements?fields=*&page-size=max";

		    logger.info("requirementUrl ", "---- ", requirementUrl);

			CompletableFuture<Map<String, Object>> requirementResponse = CompletableFuture.supplyAsync(() -> {
				try {
					return callAlmApi(requirementUrl, xsrfHeaderValue, lwssoCookie, cookies);
				} catch (Exception e) {
					throw new ALMServerException(e.getMessage());
				}
			});
			CompletableFuture.allOf(requirementResponse).join();

			Map<String, Object> requirementMap = requirementResponse.get();
			List<Map<String, Object>> response = new ArrayList<>();

			Map<String, Object> map = new HashMap<>();
			map.put("requirements", requirementMap);
			response.add(map);

			return response;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
}
