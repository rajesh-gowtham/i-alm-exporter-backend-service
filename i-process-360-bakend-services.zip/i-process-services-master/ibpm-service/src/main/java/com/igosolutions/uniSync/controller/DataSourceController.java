package com.igosolutions.uniSync.controller;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Respository.DataSourceRepository;
import com.igosolutions.uniSync.Service.DataSourceService;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.utils.HeaderUtil;

import net.minidev.json.parser.ParseException;

@RestController
// @CrossOrigin(origins = "http://localhost:7676/")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DataSourceController {
	@Autowired
	public DataSourceService datasourceservice;
	@Autowired
	public DataSourceRepository repo;
	


	private DataSource source;
	Logger log = LoggerFactory.getLogger(DataSourceController.class);

	public String almURL;
	public static String lwssoCookie = "";
	public static String cookies;
	public List domaindata = new LinkedList();
	public static String xsrfHeaderValue = "";
	public List projectData = new LinkedList();
	public Map map = new HashMap();

	public static String baseMEURl;
	public static String getFieldURL;
	public static String getSubfield_KeyValue_ME = "{\"requesttype\": \"name\", \"status\": \"statusname\" , \"mode\": \"modename\" ,\"level\": \"levelname\", \"priority\": \"priorityname\" , \"impact\": \"name\",\"urgency\": \"name\",\"replytemplate\": \"templatename\" ,\"resolutiontemplate\": \"templatename\" }";;
	public static String techniciankey = "";
	public static String Client_ALM_URL = null;
	public static String Client_ALM_USERNAME = null;
	public static String Client_ALM_PASSWORD = null;
	public static String Client_ALM_dataSourceName = null;
	public static String Client_ALM_orgName = null;
	public static String Client_ALM_Modulename = null;
	public static String Client_ALM_Domainname = null;
	public static String Client_ALM_Projectname = null;

	public static Map<Object, Object> mappingUserdefinedfields_ALM = new HashMap<Object, Object>();

	public static void ALMRe_authConnection() {
		String responseBody = "";

		try {
			if (!lwssoCookie.isEmpty()) {
				lwssoCookie = "";
				cookies = "";
				xsrfHeaderValue = "";
			}

			String almURL_ = Client_ALM_URL + "/qcbin";
			String authEndPoint = almURL_ + "/authentication-point/alm-authenticate";
			URL authUrl = new URL(authEndPoint);
			HttpURLConnection authConnection_ = (HttpURLConnection) authUrl.openConnection();

			try {

				authConnection_.setRequestMethod("POST");
				authConnection_.setRequestProperty("Content-Type", "application/xml");
				authConnection_.setDoOutput(true);
				OutputStream os = authConnection_.getOutputStream();
				try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
					osw.write("<alm-authentication><user>" + Client_ALM_USERNAME + "</user><password>"
							+ Client_ALM_PASSWORD + "</password></alm-authentication>");
				}
				authConnection_.connect();

			} catch (Exception ex) {
				LogFile.LogWrite("Data Source Controller - Error ALMRe_authConnection isValidUser func:" + ex);
				authConnection_.disconnect();

			}

			String qcSessionEndPoint = almURL_ + "/rest/site-session";
			lwssoCookie = authConnection_.getHeaderField("Set-Cookie").split(";")[0];
			LogFile.LogWrite("Data Source Controller - the lwss cokkies ALMRe_authConnection " + lwssoCookie);
			/* create session begin */
			HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
			createSession.setRequestProperty("Cookie", lwssoCookie);
			createSession.setRequestProperty("Content-Type", "application/json");
			createSession.setRequestMethod("POST");
			createSession.connect();
			Map<String, List<String>> values = createSession.getHeaderFields();
			xsrfHeaderValue = "";

			for (String cookie : values.get("Set-Cookie")) {
				String content = cookie.split(";")[0];
				cookies = cookies + content + ";";
				String[] nameValue = content.split("=");
				String name = nameValue[0];
				String value = nameValue[1];
				if (name.equalsIgnoreCase("XSRF-TOKEN")) {
					xsrfHeaderValue = value;
				}
			}
			LogFile.LogWrite("Data Source Controller - the header ALMRe_authConnection  value is" + xsrfHeaderValue);
			createSession.disconnect();
			;

			HttpURLConnection authConnection = authConnection_;
			responseBody = authConnection.getResponseMessage();
			if (authConnection.getResponseCode() == 200) {
				String token = xsrfHeaderValue;
				// getAllDomain(token);
				responseBody = authConnection.getResponseMessage();
			} else if (authConnection.getResponseCode() == 400) {
				InputStream in = new BufferedInputStream(authConnection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}
			}
			LogFile.LogWrite("Data Source Controller - the ALMRe_authConnection respone body data is" + responseBody);
			// return responseBody;
		} catch (MalformedURLException e) {

		} catch (ProtocolException e) {

			// return e.getMessage();
		} catch (IOException e) {

			// return e.getLocalizedMessage();
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getMappingField", method = RequestMethod.POST)
	public ResponseEntity<List<Map<String, Object>>> fetchTestFolders(@RequestBody DataSource dataSource)
		throws Exception {
	DataSource DataSourcedata = datasourceservice.getDataSource(dataSource.getDatasourcename());
	List<Map<String, Object>> response = datasourceservice.fetchTestFolders(DataSourcedata);
	log.info("Response received successfully from ALM API.");
	return ResponseEntity.ok(response);
}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/authentication", method = RequestMethod.POST)
	public ResponseEntity<?> defectToolAuthentication(@RequestBody DataSource authmodal) throws IOException {

		LogFile.LogWrite("Data Source Controller - the respone body data is" + authmodal.getUrl());
		Map<String, String> responseBody;

		if (authmodal.getDefectTool().equals(UtilsConstants.DefectToolConstants.ALM_DEFECT_TOOL)) {
			try {
				log.info("Starting ALM authentication for URL: {}", authmodal.getUrl());
				responseBody = datasourceservice.defectToolAuthentication(authmodal);
				return ResponseEntity.ok(responseBody);
			} catch (Exception e) {
				if (e.getLocalizedMessage().contains("ConnectException") || e.getLocalizedMessage().contains("Authentication failed"))
					return ResponseEntity.badRequest().body("Error in ALM authentication: Connection refused Check the URL and credentials");
				else {
					log.info(e.getMessage());
					log.info(e.getLocalizedMessage());
					e.getStackTrace();
					
					return ResponseEntity.badRequest().body("Error in ALM authentication: " + e.getLocalizedMessage());
				}
			}
		} else if (authmodal.getDefectTool().equals(UtilsConstants.DefectToolConstants.ME_DEFECT_TOOL)) {
			try {

				baseMEURl = authmodal.getUrl() + "/sdpapi/auth?username=" + authmodal.getUsername() + "&password="
						+ authmodal.getPassword() + "&format=json";
				LogFile.LogWrite("Data Source Controller - the base me url is" + baseMEURl);
				HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
				authConnection.setRequestProperty("Accept", "application/json");
				authConnection.setRequestMethod("GET");
				authConnection.setDoOutput(true);
				authConnection.connect();

				InputStream in = new BufferedInputStream(authConnection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				try {
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
				} catch (Exception ex) {
					LogFile.LogWrite("Data Source Controller -ERROR 56985 the respone body data is");
					authConnection.disconnect();
					throw ex;
				}
				authConnection.disconnect();
				String response = result.toString();
				JSONObject obj = new JSONObject(response);
				JSONObject operationObj = obj.getJSONObject("operation");
				JSONObject resultObj = (JSONObject) operationObj.get("result");
				JSONObject detailsObj = (JSONObject) operationObj.get("details");

				String responseBodyMe = resultObj.getString("status");
				techniciankey = detailsObj.getString("techniciankey");
				LogFile.LogWrite("Data Source Controller - the respone body data is" + responseBodyMe);
				return ResponseEntity.ok(responseBodyMe);
			} catch (Exception e) {
				return ResponseEntity.badRequest().body(e.getMessage());
			}

		}
		return ResponseEntity.badRequest().body("Invalid defect tool");
	}
	@RequestMapping(value = "/getDomainData", method = RequestMethod.POST)
    public List<String> getDomainData(@RequestBody Map<String, String> tokens)
            throws Exception {
        return datasourceservice.getAllDomain(tokens);
    }

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/createNewDataSource", method = RequestMethod.POST)
	public ResponseEntity<?> saveDataSource(@RequestBody DataSource datasource, @RequestHeader Map<String, String> headers) {

		try {
		
			String organization = HeaderUtil.getOrganization(headers);
			datasource.setOrganization(organization);
			datasource.setTechniciankey(techniciankey);
			datasourceservice.saveDataSource(datasource);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			if(e.getMessage().equals("DataSource name already exist.")) {
				return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}else {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/updateDataSource/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateDataSource(@PathVariable Long id ,@RequestBody DataSource datasource,@RequestHeader Map<String, String> headers) {

		try {
			
			String organization = HeaderUtil.getOrganization(headers);
			
			System.out.println("organiiiii"+organization);

		     datasourceservice.updateDataSource(datasource,id);
			
			return new ResponseEntity<>(HttpStatus.OK);
			
		} catch (Exception e) {
			if(e.getMessage().equals("Not Accepted")) {
			return new ResponseEntity<>("Module,Domain and Project name changes are not accepted",HttpStatus.NOT_ACCEPTABLE);
			}
			else {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getAccountsME", method = RequestMethod.GET)
	public List get_ME_Account(@RequestParam(name = "datasourcename", required = false) String datasourcename)
			throws MalformedURLException, IOException {

		List me_accountList = new LinkedList();
		DataSource source = datasourceservice.getDataSource(datasourcename);
		String newtechkey = manageEngineLogin(source);

		String accountURL = source.getUrl() + "/sdpapi/admin/account?&AUTHTOKEN=" + newtechkey + "&format=json";
		HttpURLConnection connection = (HttpURLConnection) new URL(accountURL).openConnection();
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		String jsonstring = result.toString();
		JSONObject mainObject = new JSONObject(jsonstring);

		JSONObject resultObject = mainObject.getJSONObject("operation");
		LogFile.LogWrite("Data Source Controller - the operation json object is" + resultObject);
		JSONArray detailsObject = resultObject.getJSONArray("details");
		LogFile.LogWrite("Data Source Controller - the detailsObject json object is" + detailsObject);

		for (int i = 0; i < detailsObject.length(); i++) {
			JSONObject object = detailsObject.getJSONObject(i);
			me_accountList.add(object.get("AccountName"));
		}

		// LIST to String:
		if (me_accountList.size() > 0) {
			String delim = "-";
			StringBuilder sb = new StringBuilder();
			int i = 0;
			while (i < me_accountList.size() - 1) {
				sb.append(me_accountList.get(i));
				sb.append(delim);
				i++;
			}
			sb.append(me_accountList.get(i));

			String res = sb.toString();
			// END
			LogFile.LogWrite("me_accountList is " + res);
		} else {
			LogFile.LogWrite("me_accountList IS NULL");
		}

		return me_accountList;

	}

	public String manageEngineLogin(DataSource authmodal) {

		try {
			baseMEURl = authmodal.getUrl() + "/sdpapi/auth?username=" + authmodal.getUsername() + "&password="
					+ authmodal.getPassword() + "&format=json";
			HttpURLConnection authConnection = (HttpURLConnection) new URL(baseMEURl).openConnection();
			authConnection.setRequestProperty("Accept", "application/json");
			authConnection.setRequestMethod("GET");
			authConnection.setDoOutput(true);
			authConnection.connect();

			InputStream in = new BufferedInputStream(authConnection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}

			String response = result.toString();
			JSONObject obj = new JSONObject(response);
			JSONObject operationObj = obj.getJSONObject("operation");
			JSONObject resultObj = (JSONObject) operationObj.get("result");
			JSONObject detailsObj = (JSONObject) operationObj.get("details");

			String newtechniciankey = detailsObj.getString("techniciankey");

			LogFile.LogWrite("Data Source Controller - the technician key value is" + newtechniciankey);
			return newtechniciankey;
		} catch (MalformedURLException e) {
			return e.getMessage();
		} catch (ProtocolException e) {
			return e.getMessage();
		} catch (IOException e) {
			return e.getMessage();
		}

		// return almURL;

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getFields/", method = RequestMethod.GET)
	public List<String> getFieldsForDataSource(
			@RequestParam(name = "datasourcename", required = false) String datasourcename,
			@RequestParam(name = "orgName", required = false) String orgName) throws IOException, ParseException {

		List<String> fieldsList = new ArrayList<String>();

		LogFile.LogWrite("Data Source Controller - Server Side Parameter # 1020   " + "datasourcename    :"
				+ datasourcename + "    orgName  :" + orgName);

		try {

			DataSource source = datasourceservice.getDataSource(datasourcename);
			if (source.getDefectTool().equals("ME")) {

				String uri = "http://localhost:7373/getRequestIDByOrgName?orgName=" + orgName + "";
				RestTemplate restTemplate = new RestTemplate();
				List returnids = restTemplate.getForObject(uri, List.class);
				Object object = returnids.get(0);
				Gson gson = new Gson();
				String json = gson.toJson(object);
				JSONObject obj1 = new JSONObject(json);

				int requestID = obj1.getInt("WORKORDERID");

				String newtechkey = manageEngineLogin(source);
				getFieldURL = source.getUrl() + "/sdpapi/request/" + requestID + "?&AUTHTOKEN=" + newtechkey
						+ "&format=json";
				// getFieldURL = "
				// http://172.22.6.21:7171/sdpapi/request/?&TECHNICIAN_KEY=B3F0CAC7-167C-4A26-AE4C-EFF5368A71DA&format=json";
				// source.getUrl()+"/sdpapi/request/account?&AUTHTOKEN="+source.getTechniciankey()+"&format=json";
				HttpURLConnection connection = (HttpURLConnection) new URL(getFieldURL).openConnection();
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Accept", "application/json");
				connection.setRequestMethod("GET");
				connection.connect();
				InputStream in = new BufferedInputStream(connection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}

				String jsonstring = result.toString();
				JSONObject mainObject = new JSONObject(jsonstring);

				JSONObject resultObject = mainObject.getJSONObject("operation");
				JSONObject detailsObject = resultObject.getJSONObject("details");

				Iterator<String> keys = detailsObject.keys();
				while (keys.hasNext()) {
					fieldsList.add(keys.next());
				}

				// LIST to String:
				if (fieldsList.size() > 0) {
					StringBuilder sb = new StringBuilder();
					int i = 0;
					String delim = "-";
					while (i < fieldsList.size() - 1) {
						sb.append(fieldsList.get(i));
						sb.append(delim);
						i++;
					}
					sb.append(fieldsList.get(i));
					String res = sb.toString();
					LogFile.LogWrite("Data Source Controller - INFO 2021 fieldsList IS" + res);
				} else {
					LogFile.LogWrite("Data Source Controller - INFO 2021 fieldsList IS NULL");
				}

				// END

			} else if (source.getDefectTool().equals("ALM")) {
				if (source.getModulename().equals("Defect")) {
					source.setModulename("defects");
				} else {
					source.setModulename("requirements");
				}
				// getFieldURL =source.getUrl() + "/qcbin/api/domains/"+ source.getDomainname()
				// +"/projects/"+ source.getProjectname()
				// +"/"+source.getModulename()+"/$metadata/fields";
				// getFieldURL = source.getUrl() + "/qcbin/rest/domains/" +
				// source.getDomainname() + "/projects/"
				// + source.getProjectname() + "/"+source.getModulename();

				String getsubfieldURL = source.getUrl() + "/qcbin/api/domains/" + source.getDomainname() + "/projects/"
						+ source.getProjectname() + "/" + source.getModulename() + "/$metadata/fields";
				Client_ALM_Modulename = source.getModulename();
				Client_ALM_Domainname = source.getDomainname();
				Client_ALM_Projectname = source.getProjectname();

				LogFile.LogWrite("Data Source Controller - Get Fields URL #1010 " + "Client_ALM_Modulename :"
						+ Client_ALM_Modulename + "Client_ALM_Domainname :" + Client_ALM_Domainname
						+ "Client_ALM_Projectname :" + Client_ALM_Projectname);
				LogFile.LogWrite("Data Source Controller - Get Fields URL #1012 " + getsubfieldURL);
				LogFile.LogWrite("Data Source Controller - the get subfields url isss" + getsubfieldURL);
				HttpURLConnection connection1 = isValidUser(source);

				String token = generateXSRFTOKEN(connection1);

				LogFile.LogWrite("Data Source Controller - 34565 the token" + token);

				HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();
				try {
					connection.setRequestProperty("Cookie", cookies + lwssoCookie);
					connection.setRequestProperty("X-XSRF-TOKEN", token);
					connection.setRequestProperty("Content-Type", "application/json");
					connection.setRequestProperty("Accept", "application/json");
					connection.setRequestMethod("GET");
					connection.connect();

				} catch (Exception ex) {
					connection.disconnect();
					LogFile.LogWrite("Data Source Controller - ERROR 25258 the connection" + ex.getMessage());
					throw ex;
				}

				InputStream in = new BufferedInputStream(connection.getInputStream());
				BufferedReader reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder result = new StringBuilder();
				String line;
				fieldsList = new ArrayList<String>();
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}

				connection.disconnect();
				if (!lwssoCookie.isEmpty()) {
					lwssoCookie = "";
					cookies = "";
					xsrfHeaderValue = "";
				}

				String jsonstring = result.toString();

				String repaceString = jsonstring.replaceAll("\"type\":\"field\",", " ");

				JSONObject mainObject = new JSONObject(repaceString);

				JSONArray dataArrayObject = mainObject.getJSONArray("data");
				mappingUserdefinedfields_ALM = new HashMap<Object, Object>();
				JSONObject singleObject = new JSONObject();

				for (int i = 0; i < dataArrayObject.length(); i++) {
					JSONObject objects1 = dataArrayObject.getJSONObject(i);
					Set<String> key = objects1.keySet();
					for (String element : key) {

						if (element.equals("name")) {
							singleObject.put("name", objects1.get(element));
						} else if ((element.equals("label"))) {

							fieldsList.add((String) objects1.get(element));
							singleObject.put("label", objects1.get(element));
						}

					}
					Object labelkey = objects1.get("label");
					Object nameValue = objects1.get("name");
					mappingUserdefinedfields_ALM.put(labelkey, nameValue);
				}
				LogFile.LogWrite("Data Source Controller - the mapping fields is " + mappingUserdefinedfields_ALM);

			}

		} catch (Exception ex) {
			LogFile.LogWrite("Data Source Controller - Error 2001 " + ex);
		}

		return fieldsList;

	}

	public JSONObject getJSONObject(String key) throws JSONException, IOException {

		LogFile.LogWrite("Data Source Controller - the key value is" + key);
		Object object = this.get(key);
		LogFile.LogWrite("Data Source Controller - the object value is" + object);
		if (object instanceof JSONObject) {
			return (JSONObject) object;
		} else {
			return null;
		}
	}

	public Object get(String key) throws JSONException, IOException {
		if (key == null) {
			throw new JSONException("Null key.");
		}
		if (key.equals("type")) {
			LogFile.LogWrite("Data Source Controller - duplicate key");
		} else {
			Object object = this.opt(key);
			return object;
		}
		return key;
	}

	public Object opt(String key) throws IOException {
		LogFile.LogWrite("Data Source Controller - the opt key value issss" + key);
		return key == null ? null : this.map.get(key);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSubFields", method = RequestMethod.GET)
	public List getSubFieldsForME(@RequestParam(name = "fieldName", required = false) String fieldName)
			throws MalformedURLException, IOException, JSONException {

		String subFieldURL = "http://172.22.6.21:7171/sdpapi/admin/" + fieldName
				+ "/?&AUTHTOKEN=5VJolQMMWirDxvIxHdRTLQ==&format=json";
		HttpURLConnection connection = (HttpURLConnection) new URL(subFieldURL).openConnection();

		try {
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestMethod("GET");
			connection.connect();
		} catch (Exception ex) {
			connection.disconnect();
			throw ex;
		}

		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;

		try {
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}
			connection.disconnect();
		} catch (Exception ex) {
			connection.disconnect();
			throw ex;
		}

		LogFile.LogWrite("Data Source Controller - the response is <><><" + connection.getResponseMessage());
		String jsonstring = result.toString();
		JSONObject keyObject = new JSONObject(getSubfield_KeyValue_ME);
		String keyvalue = keyObject.getString(fieldName);

		JSONObject mainObject = new JSONObject(jsonstring);
		JSONObject operationObject = mainObject.getJSONObject("operation");
		JSONArray details_array = operationObject.getJSONArray("details");
		List subField = new LinkedList();
		try {

			for (int i = 0; i < details_array.length(); i++) {
				JSONObject objects = details_array.getJSONObject(i);
				subField.add(objects.get(keyvalue));
				// LogFile.LogWrite(objects.get(keyvalue));
			}
		} catch (Exception ex) {
			throw ex;
		}

		LogFile.LogWrite("Data Source Controller - the subField value is" + subField);
		return subField;

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/isExist_Datasource/", method = RequestMethod.GET)
	public boolean isExistNewDatasource(
			@RequestParam(name = "datasourcename", required = false) String datasourcename) {
		boolean return1 = datasourceservice.findDataSouceName(datasourcename);
		return return1;
	}

	public DataSource selectDomanin(String targetdatasource) {
		DataSource source = datasourceservice.selectDomanin(targetdatasource);
		// String DomainIS=source.getDomainname();
		return source;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getDataSourcedata", method = RequestMethod.GET)
	public List<DataSource> getAllDataSource(@RequestHeader Map<String, String> headers) {
		String organization = HeaderUtil.getOrganization(headers);
		List<DataSource> dataSourceData = datasourceservice.getAllDataSource(organization);
		return dataSourceData;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/domain/getProject/{domainname}", method = RequestMethod.POST)
	public List<Object> getAllProject(@PathVariable(name = "domainname", required = false) String domainname,
			@RequestBody Map<String, String> tokens)
			throws Exception {
		return datasourceservice.getAllProjectsForDomain(domainname, tokens);
}

	public HttpURLConnection isValidUser(DataSource authmodal) throws IOException {

		almURL = authmodal.getUrl() + "/qcbin";
		String authEndPoint = almURL + "/authentication-point/alm-authenticate";
		URL authUrl = new URL(authEndPoint);
		HttpURLConnection authConnection = (HttpURLConnection) authUrl.openConnection();

		try {

			authConnection.setRequestMethod("POST");
			authConnection.setRequestProperty("Content-Type", "application/xml");
			authConnection.setDoOutput(true);
			OutputStream os = authConnection.getOutputStream();
			try (OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8")) {
				osw.write("<alm-authentication><user>" + authmodal.getUsername() + "</user><password>"
						+ authmodal.getPassword() + "</password></alm-authentication>");
			}
			authConnection.connect();
			Client_ALM_URL = authmodal.getUrl();
			Client_ALM_USERNAME = authmodal.getUsername();
			Client_ALM_PASSWORD = authmodal.getPassword();

		} catch (Exception ex) {
			LogFile.LogWrite("Data Source Controller - Error isValidUser func:" + ex);
			authConnection.disconnect();

		}

		return authConnection;
	}

	public String generateXSRFTOKEN(HttpURLConnection authConnection) throws MalformedURLException, IOException {
		String qcSessionEndPoint = almURL + "/rest/site-session";
		lwssoCookie = authConnection.getHeaderField("Set-Cookie").split(";")[0];
		LogFile.LogWrite("Data Source Controller - the lwss cokkies" + lwssoCookie);
		/* create session begin */
		HttpURLConnection createSession = (HttpURLConnection) new URL(qcSessionEndPoint).openConnection();
		createSession.setRequestProperty("Cookie", lwssoCookie);
		createSession.setRequestProperty("Content-Type", "application/json");
		createSession.setRequestMethod("POST");
		createSession.connect();
		Map<String, List<String>> values = createSession.getHeaderFields();
		xsrfHeaderValue = "";

		for (String cookie : values.get("Set-Cookie")) {
			String content = cookie.split(";")[0];
			cookies = cookies + content + ";";
			String[] nameValue = content.split("=");
			String name = nameValue[0];
			String value = nameValue[1];
			if (name.equalsIgnoreCase("XSRF-TOKEN")) {
				xsrfHeaderValue = value;
			}
		}
		LogFile.LogWrite("Data Source Controller - the header value is" + xsrfHeaderValue);
		createSession.disconnect();
		;
		return xsrfHeaderValue;
	}

	public void getAllDomain(String token) throws MalformedURLException, IOException {
		String listAllDomainURL = almURL + "/api/domains";
		HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllDomainURL).openConnection();
		createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession1.setRequestProperty("X-XSRF-TOKEN", token);
		createSession1.setRequestProperty("Content-Type", "application/json");
		createSession1.setRequestProperty("Accept", "application/json");
		createSession1.setRequestMethod("GET");
		createSession1.connect();
		InputStream in = new BufferedInputStream(createSession1.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		createSession1.disconnect();
		if (!lwssoCookie.isEmpty()) {
			// lwssoCookie = "";
			// cookies = "";
			// xsrfHeaderValue = "";
		}
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String jsonstring = result.toString();
		domaindata = new LinkedList();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			domaindata.add(objects.get("name"));
		}
	}

	public List<String> getAllProjects(String token, String domainname) throws MalformedURLException, IOException {
		String listAllProjectsInDomain = almURL + "/api/domains/" + domainname + "/projects";
		HttpURLConnection createSession1 = (HttpURLConnection) new URL(listAllProjectsInDomain).openConnection();
		createSession1.setRequestProperty("Cookie", cookies + lwssoCookie);
		createSession1.setRequestProperty("X-XSRF-TOKEN", token);
		createSession1.setRequestProperty("Content-Type", "application/json");
		createSession1.setRequestProperty("Accept", "application/json");
		createSession1.setRequestMethod("GET");
		createSession1.connect();
		InputStream in = new BufferedInputStream(createSession1.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		createSession1.disconnect();
		if (!lwssoCookie.isEmpty()) {
			lwssoCookie = "";
			cookies = "";
			xsrfHeaderValue = "";
		}
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String jsonstring = result.toString();
		projectData = new LinkedList();
		JSONObject jsonobject = new JSONObject(jsonstring);
		JSONArray jsarray = jsonobject.getJSONArray("results");
		// JSONObject data=(object)result;
		for (int i = 0; i < jsarray.length(); i++) {
			JSONObject objects = jsarray.getJSONObject(i);
			domaindata.add(objects.get("name"));
		}
		return projectData;
	}

	public Map<Object, Object> getALMFields(DataSource source) throws IOException, InterruptedException {

		try {

			LogFile.LogWrite("Data Source Controller - the data source name is" + source);

			try {

				// source.getModulename()
				// LogFile.LogWrite("Data Source Controller - source.getModulename() #1011 :" +
				// source.getModulename());
				if (source.getModulename().equalsIgnoreCase("Defects")
						|| source.getModulename().equalsIgnoreCase("Defect")) { // Changed
					source.setModulename("defects");
				} else {
					source.setModulename("requirements");
				}

			} catch (Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1212 getALMFields  " + ex.getMessage());
			}

			// getFieldURL =source.getUrl() + "/qcbin/api/domains/"+ source.getDomainname()
			// +"/projects/"+ source.getProjectname()
			// +"/"+source.getModulename()+"/$metadata/fields";
			// getFieldURL = source.getUrl() + "/qcbin/rest/domains/" +
			// source.getDomainname() + "/projects/"
			// + source.getProjectname() + "/"+source.getModulename();
			List<String> fieldsList = new ArrayList<String>();
			String getsubfieldURL = source.getUrl() + "/qcbin/api/domains/" + source.getDomainname() + "/projects/"
					+ source.getProjectname() + "/" + source.getModulename() + "/$metadata/fields";

			// http://172.22.6.7:8080/qcbin/api/domains/AVLINO/projects/Jira_Test/requirements/$metadata/fields
			Client_ALM_Modulename = source.getModulename();
			Client_ALM_Domainname = source.getDomainname();
			Client_ALM_Projectname = source.getProjectname();

			LogFile.LogWrite("Data Source Controller - Get Fields URL #1013 " + "Client_ALM_Modulename :  "
					+ Client_ALM_Modulename + "Client_ALM_Domainname    :" + Client_ALM_Domainname
					+ "Client_ALM_Projectname     :" + Client_ALM_Projectname);
			LogFile.LogWrite("Data Source Controller - getsubfieldURL #1011   :" + getsubfieldURL);

			HttpURLConnection connection1 = isValidUser(source);
			LogFile.LogWrite("Data Source Controller - getsubfieldURL #7878   connection1 :" + connection1);

			String token = generateXSRFTOKEN(connection1);
			LogFile.LogWrite("Data Source Controller - getsubfieldURL #7878  token :" + token);
			HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();

			try {
				connection.setRequestProperty("Cookie", cookies + lwssoCookie);
				connection.setRequestProperty("X-XSRF-TOKEN", token);
				connection.setRequestProperty("Content-Type", "application/json");
				connection.setRequestProperty("Accept", "application/json");
				connection.setRequestMethod("GET");
				connection.connect();

			} catch (Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1213 getALMFields CONNECT " + ex.getMessage());
				connection.disconnect();

				throw ex;
			}

			InputStream in = new BufferedInputStream(connection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			StringBuilder result = new StringBuilder();
			String line;
			fieldsList = new ArrayList<String>();
			try {
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}
				connection.disconnect();

			} catch (Exception ex) {
				LogFile.LogWrite("Data Source Controller - ERROR #1215 getALMFields CONNECT " + ex.getMessage());
				connection.disconnect();
				ALMRe_authConnection();// RE AUTHENTICATION
				throw ex;
			}

			String jsonstring = result.toString();

			String repaceString = jsonstring.replaceAll("\"type\":\"field\",", " ");

			JSONObject mainObject = new JSONObject(repaceString);

			JSONArray dataArrayObject = mainObject.getJSONArray("data");
			mappingUserdefinedfields_ALM = new HashMap<Object, Object>();
			JSONObject singleObject = new JSONObject();

			for (int i = 0; i < dataArrayObject.length(); i++) {

				try {

					JSONObject objects1 = dataArrayObject.getJSONObject(i);
					Set<String> key = objects1.keySet();
					for (String element : key) {

						if (element.equals("name")) {
							singleObject.put("name", objects1.get(element));
						} else if ((element.equals("label"))) {

							fieldsList.add((String) objects1.get(element));
							singleObject.put("label", objects1.get(element));
						}

					}
					Object labelkey = objects1.get("label");
					Object nameValue = objects1.get("name");

					try {
						mappingUserdefinedfields_ALM.put(labelkey, nameValue);

					} catch (Exception ex) {
						LogFile.LogWrite("Data Source Controller - ERROR #1215 mappingUserdefinedfields_ALM PUT:  "
								+ ex.getMessage());
						ALMRe_authConnection();// RE AUTHENTICATION
						throw ex;
					}
				} catch (Exception ex) {
					LogFile.LogWrite(
							"Data Source Controller - ERROR #1214 dataArrayObject FORLOOP:  " + ex.getMessage());
					ALMRe_authConnection();// RE AUTHENTICATION
					throw ex;
				}

			}
			LogFile.LogWrite("Data Source Controller - the mapping fields is " + mappingUserdefinedfields_ALM);

		} catch (Exception ex) {

			LogFile.LogWrite("Data Source Controller - ERROR #1215 mapping fields is " + mappingUserdefinedfields_ALM);

			LogFile.LogWrite("Data Source Controller - ERROR #1216 " + ex.getMessage());
			ALMRe_authConnection();// RE AUTHENTICATION
			throw ex;
		}

		return mappingUserdefinedfields_ALM;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getDefectstatusINALM/", method = RequestMethod.GET)
	public List<String> getstatusvalue(
			@RequestParam(name = "dataSourcename", required = false) String datasourcename,
			@RequestParam(name = "fieldName", required = false) String fieldName) throws IOException {
		String FieldNametemp = "";
		fieldName = fieldName.trim();
		if (fieldName.equals("Status")) {
			FieldNametemp = "Bug Status";
		} else if (fieldName.equals("Severity")) {
			FieldNametemp = "Severity";
		} else {
		}

		LogFile.LogWrite("Data Source Controller - fieldName ** is" + fieldName);

		List defectStatusValue = new LinkedList();
		LogFile.LogWrite("Data Source Controller - the target data source is" + datasourcename);
		DataSource source = datasourceservice.getDataSource(datasourcename);
		String getsubfieldURL = "http://172.22.6.7:8080/qcbin/rest/domains/" + source.getDomainname() + "/projects/"
				+ source.getProjectname() + "/customization/entities/defect/lists";
		// String getsubfieldURL=
		// "http://172.22.6.7:8080/qcbin/rest/domains/INTERTEK/projects/Evo2_Prod_Support/customization/entities/defect/lists";
		//
		// String getsubfieldURL=
		// "http://172.22.6.7:8080/qcbin/api/domains/AVLINO/projects/Jira_Test/defects/$metadata/fields";

		HttpURLConnection connection1 = isValidUser(source);
		String token = generateXSRFTOKEN(connection1);
		HttpURLConnection connection = (HttpURLConnection) new URL(getsubfieldURL).openConnection();
		connection.setRequestProperty("Cookie", cookies + lwssoCookie);
		connection.setRequestProperty("X-XSRF-TOKEN", token);
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestMethod("GET");
		connection.connect();

		InputStream in = new BufferedInputStream(connection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		StringBuilder result = new StringBuilder();
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				result.append(line);
			}

		} catch (Exception ex) {
			LogFile.LogWrite("Data Source Controller - ERROR 25856 the  string builder is" + result.toString());
			connection.disconnect();
			throw ex;
		}

		connection.disconnect();
		LogFile.LogWrite("Data Source Controller - the  string builder is" + result.toString());
		String retrunstring = result.toString();
		JSONObject listobject = new JSONObject(retrunstring);
		JSONArray listarrayObject = listobject.getJSONArray("lists");
		LogFile.LogWrite("Data Source Controller - listarrayObject ******  " + listarrayObject.toString());
		for (int i = 0; i < listarrayObject.length(); i++) {

			JSONObject nameObject = listarrayObject.getJSONObject(i);

			if (nameObject.getString("Name").equals(FieldNametemp)) {

				JSONArray itemsarrayobject = nameObject.getJSONArray("Items");

				for (int j = 0; j < itemsarrayobject.length(); j++) {

					JSONObject valueobject = itemsarrayobject.getJSONObject(j);

					defectStatusValue.add(valueobject.get("value"));

				}
			}
		}
		LogFile.LogWrite("Data Source Controller - the list value is" + defectStatusValue);
		return defectStatusValue;
	}

	

	@RequestMapping(value = "/getConfigDataByType/{defectType}", method = RequestMethod.GET)
	public ResponseEntity<?> getConfigData(@RequestHeader Map<String, String> headers,@PathVariable String defectType) {
		try {
			String organization = HeaderUtil.getOrganization(headers);
			return new ResponseEntity<>(repo.getDefectToolByOrganization(defectType,organization), HttpStatus.OK);
		} catch (Exception e) {

			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@RequestMapping(value = "dataSource/deleteDataSource/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteDataSource(@PathVariable Long id, @RequestHeader Map<String, String> headers) {
		String organization = HeaderUtil.getOrganization(headers);
		return datasourceservice.deleteDataSource(id,organization);
	}
	@GetMapping("/alm/fetchTestFolders/{dataSourceId}")
    public ResponseEntity<List<Map<String, Object>>> fetchTestFoldersTestCaseDesignSteps(@PathVariable Long dataSourceId )throws Exception {
		Optional<DataSource> DataSourcedata = repo.findById(dataSourceId);
		if (DataSourcedata.isPresent()) {
			List<Map<String, Object>> response = null;
			if(DataSourcedata.get().getModulename().equals( "Testing")){
			 response = datasourceservice.fetchTestFoldersTestCaseDesignSteps(DataSourcedata.get());
			}else{
				response = datasourceservice.fetchALMRequirementsData(DataSourcedata.get());
			}
			return ResponseEntity.ok(response);
		}else{
			return ResponseEntity.notFound().build();
		}
		
    }
	
}
