package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PublishBpmn")
public class PublishBpmn {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String url;
	private String diagramname;
	
	
	@Override
	public String toString() {
		
		return "Bpmn [url=" + url + ", diagramname=" + diagramname
				+"]";
		
	}
	
	public String getdiagramname() {
		return diagramname;
	} 
	
	public void setdiagramname(String diagramname_) {
		this.diagramname = diagramname_;
	}
	
	
	public String geturl() {
		return url;
	} 
	
	public void seturl(String url_) {
		this.url = url_;
	}
	
	
	
	
	



	
}
