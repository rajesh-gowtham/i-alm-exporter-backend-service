package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.MapVersion;
@Repository
public interface MapVersionRepository extends JpaRepository<MapVersion, Long>{
	
	
	    @Transactional
		@Query("SELECT b FROM MapVersion b WHERE b.diagramLevel = :diagramLevel AND b.reviewDiagramme.id = :mapId")
		public MapVersion findByDiagramLevelAndMapId(@Param("diagramLevel") String diagramLevel, @Param("mapId") Long mapId);
	    
	    @Transactional
		@Query("SELECT b.reviewDiagramme.id FROM MapVersion b WHERE b.diagramLevel = :diagramLevel")
		public List<Long> findByDiagramLevelForId(@Param("diagramLevel") String diagramLevel);
	    
	    @Query("SELECT mv.diagramXmlId FROM MapVersion mv WHERE mv.reviewDiagramme.id = :mapId")
	    List<Integer> findAllDiagramXmlIdsByMapId(@Param("mapId") Long mapId);
	    
	    @Query("SELECT mv.diagramXmlId FROM MapVersion mv WHERE mv.reviewDiagramme.id = :mapId")
	    Integer findDiagramXmlId(@Param("mapId") Long mapId);
 
	    @Query("SELECT mv FROM MapVersion mv WHERE mv.diagramXmlId= :diagramXmlId")
		MapVersion findByDiaramXmlId(@Param("diagramXmlId")int diagramXmlId);

		@Query("SELECT u FROM MapVersion u WHERE u.reviewDiagramme.id IN :mapIds")
		List<MapVersion> findByIds(@Param("mapIds") List<Long> mapIds);
		
		@Transactional
		@Modifying
		@Query("DELETE FROM MapVersion u WHERE u.diagramXmlId IN :diagramXmlIds")
		void deleteByIds(@Param("diagramXmlIds") List<Integer> diagramXmlIds);
		
		@Query("SELECT u FROM MapVersion u WHERE u.reviewDiagramme.id IN :mapId")
		List<MapVersion> findByMapId(@Param("mapId") Long mapId);
		
		@Query("SELECT u FROM MapVersion u WHERE u.diagramXmlId IN :diagramXmlId")
		MapVersion findByDiagramXmlId(@Param("diagramXmlId") int diagramXmlId);
		
		 @Modifying
		    @Transactional
		    @Query("UPDATE MapVersion b SET b.diagramLevel = :diagramLevel WHERE b.id = :id")
		    void updateDiagramLevel(@Param("id") long id, @Param("diagramLevel") String diagramLevel);
		 @Modifying
		    @Transactional
		    @Query("UPDATE MapVersion b SET b.diagramLevel = :diagramLevel, b.diagramEditStatus= :diagramEditStatus, b.diagramVersion = :diagramVersion WHERE b.id = :id")
		    void updateDiagramLevelAndStatus(@Param("id") long id, @Param("diagramLevel") String diagramLevel,  @Param("diagramEditStatus") String diagramEditStatus,@Param("diagramVersion") double diagramVersion);
		 
		 @Modifying
		    @Transactional
		    @Query("UPDATE MapVersion b SET b.diagramLevel = :diagramLevel, b.diagramEditStatus= :diagramEditStatus, b.diagramVersion = :diagramVersion, b.publishedBy = :publishedBy WHERE b.id = :id")
		    void updateDiagramLevelAndStatusAndPublishedBy(@Param("id") long id, @Param("diagramLevel") String diagramLevel,  @Param("diagramEditStatus") String diagramEditStatus,@Param("diagramVersion") double diagramVersion, @Param("publishedBy") long publishedBy);

		
			@Query("SELECT u.diagramXmlId FROM MapVersion u WHERE u.reviewDiagramme.id IN :mapId")
			public List<Integer> findDiagramXmlIdByMapId(@Param("mapId")List<Long> mapId);

			public void deleteByDiagramXmlId(Long diagramXmlId);

			@Query("SELECT u FROM MapVersion u WHERE u.diagramLevel = :diagramLevel AND u.reviewDiagramme.id = :mapId AND u.diagramEditStatus = :diagramEditStatus")
			public MapVersion findByDiagramLevelAndMapIdAndDiagramEditStatus(@Param("diagramLevel") String diagramLevel, @Param("mapId") long mapId, @Param("diagramEditStatus") String diagramEditStatus);

			
			@Modifying
		    @Transactional
		    @Query("DELETE FROM MapVersion b WHERE b.id = :id")
		    public void deleteByMapVersionId(@Param("id") Long id);


			@Modifying
			@Transactional
			@Query(value = "INSERT INTO map_version (diagram_xml_id, diagram_level, diagram_name, diagram_version, diagram_edit_status, published_by, map_id) "
						 + "VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)", nativeQuery = true)
			void insertMapVersion(int diagramXmlId, String diagramLevel, String diagramName, Double diagramVersion, String diagramEditStatus, Long publishedBy, Long mapId);

			
		 
}
