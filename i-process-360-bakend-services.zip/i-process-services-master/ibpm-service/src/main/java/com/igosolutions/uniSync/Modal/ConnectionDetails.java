package com.igosolutions.uniSync.Modal;

public class ConnectionDetails {

	public static String ALMURL_Deatils="";
	public static String ALMUSERNAME_Deatils="";
	public static String ALMPASSWORD_Deatils="";
	public static DataSource tempauthmodal;
	
}
