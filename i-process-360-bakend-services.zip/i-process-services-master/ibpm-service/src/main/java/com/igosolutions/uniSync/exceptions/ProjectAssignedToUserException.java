package com.igosolutions.uniSync.exceptions;

public class ProjectAssignedToUserException extends RuntimeException{
    public ProjectAssignedToUserException(String message) {
        super(message);
    }
}
