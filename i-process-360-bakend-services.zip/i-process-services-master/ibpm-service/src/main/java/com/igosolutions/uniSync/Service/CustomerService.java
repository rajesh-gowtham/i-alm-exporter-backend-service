package com.igosolutions.uniSync.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.CustomerDTO;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Respository.CustomerRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.exceptions.CustomerDeletionException;
import com.igosolutions.uniSync.exceptions.CustomerNotFoundException;
import com.igosolutions.uniSync.exceptions.ProjectAssignedToUserException;

@Service
public class CustomerService {
    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    private ProjectRepository projectRepository;
    
    public ResponseEntity<?> createCustomer(CustomerDTO customer) {
        try {
            Customer byCustomerName = customerRepository.findByCustomerName(customer.getCustomerName());
            if (byCustomerName != null) {
                return new ResponseEntity<String>("Customer Already Exists", HttpStatus.NOT_ACCEPTABLE);
            }
            Customer customerEntity = new Customer();
            customerEntity.setCustomerName(customer.getCustomerName());
            List<Project> projects = customer.getProjects().stream().map(projectDto -> {
                Project project = new Project();
                project.setProjectName(projectDto.getProjectName());
                return project;
            }).collect(Collectors.toList());
            customerEntity.setOrganization(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION);
            customerEntity.setProjects(projects);
            Customer savedData = customerRepository.save(customerEntity);
            return new ResponseEntity<>(savedData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<?> updateCustomer(Long id, CustomerDTO customerDetails){
        try {
            return customerRepository.findById(id)
                    .map(customer -> {
                        customer.setCustomerName(customerDetails.getCustomerName());

                        List<Project> existingProjects = customer.getProjects();
                        List<Project> retainedProjects = new ArrayList<>();
                        List<Project> projectsToUpdate = new ArrayList<>();
                        List<Project> newProjects = new ArrayList<>();

                        for (ProjectDTO projectDto : customerDetails.getProjects()) {
                            if (projectDto.getId() != null) {
                                Project existingProject = projectRepository.findById(projectDto.getId())
                                        .orElse(null);
                                if (existingProject != null && !existingProject.getBpmnUsers().isEmpty()) {
                                    // If the project is assigned to a BpmnUser, ensure it's not modified
                                    // if (!existingProject.getProjectName().equals(projectDto.getProjectName())) {
                                    //     throw new ProjectAssignedToUserException(
                                    //             "Project with name " + existingProject.getProjectName()
                                    //                     + " is assigned to a user and cannot be updated.");
                                    // }
                                    existingProject.setProjectName(projectDto.getProjectName());
                                    retainedProjects.add(existingProject);
                                } else {
                                    Project project = new Project();
                                    project.setId(projectDto.getId());
                                    project.setProjectName(projectDto.getProjectName());
                                    Customer obj = new Customer();
                                    obj.setOrganization(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION);
                                    obj.setId(projectDto.getCustomerId());
                                    project.setCustomer(obj);
                                    projectsToUpdate.add(project);
                                }
                            } else {
                                Project project = new Project();
                                project.setProjectName(projectDto.getProjectName());
                                Customer obj = new Customer();
                                obj.setOrganization(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION);
                                obj.setId(projectDto.getCustomerId());
                                project.setCustomer(obj);
                                newProjects.add(project);
                            }
                        }

                        // Check for deletions of projects assigned to BpmnUsers
                        List<Project> projectsToDelete = existingProjects.stream()
                                .filter(existingProject -> !retainedProjects.contains(existingProject))
                                .filter(existingProject -> existingProject.getBpmnUsers() != null && !existingProject.getBpmnUsers().isEmpty())
                                .collect(Collectors.toList());

                        if (!projectsToDelete.isEmpty()) {
                            throw new ProjectAssignedToUserException(
                                    "One or more projects assigned to a user cannot be deleted.");
                        }

                        // Clear and update the projects list
                        customer.getProjects().clear();
                        customer.getProjects().addAll(retainedProjects); // Retain existing projects assigned to BpmnUsers
                        customer.getProjects().addAll(projectsToUpdate); // Add/update projects not assigned to BpmnUsers
                        customer.getProjects().addAll(newProjects); // Add new projects

                        Customer updatedCustomer = customerRepository.save(customer);

                        CustomerDTO customerDto = new CustomerDTO();
                        customerDto.setId(updatedCustomer.getId());
                        customerDto.setCustomerName(updatedCustomer.getCustomerName());
                        for(Project project : updatedCustomer.getProjects()){
                            ProjectDTO projectdto = new ProjectDTO();
                            projectdto.setId(project.getId());
                            projectdto.setCustomerId(project.getCustomer().getId());
                            projectdto.setProjectName(project.getProjectName());
                            projectdto.setCustomerName(project.getCustomer().getCustomerName());
                            customerDto.getProjects().add(projectdto);
                        }
                        return ResponseEntity.ok(customerDto);
                    })
                    .orElse(ResponseEntity.notFound().build());
        } catch (ProjectAssignedToUserException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while updating the customer.");
        }
    }

    public ResponseEntity<?> deleteCustomer(Long id) {
        try {
            return customerRepository.findById(id)
                .map(customer -> {
                    boolean hasAssignedBpmnUsers = customer.getProjects().stream()
                            .anyMatch(project -> !project.getBpmnUsers().isEmpty());

                    if (!customer.getBpmnUsers().isEmpty() || hasAssignedBpmnUsers) {
                        throw new CustomerDeletionException("Customer or its projects are assigned to BpmnUser(s)");
                    }

                    customerRepository.delete(customer);
                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
        }
        catch (CustomerDeletionException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }

         catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while deleting the customer.");
        }
    }

    public ResponseEntity<?> getCustomerByName(String customerName){
        try {
            Customer byCustomerName = customerRepository.findByCustomerName(customerName);
            if(byCustomerName == null){
                throw new CustomerNotFoundException("Customer not found with name " + customerName);
            }
            CustomerDTO customerDto = new CustomerDTO();
            customerDto.setId(byCustomerName.getId());
            customerDto.setCustomerName(byCustomerName.getCustomerName());

            List<ProjectDTO> projectDtos = new ArrayList<>();

            for (Project project : byCustomerName.getProjects()) {
                ProjectDTO projectDto = new ProjectDTO();
                projectDto.setId(project.getId());
                projectDto.setProjectName(project.getProjectName());
                projectDto.setCustomerId(project.getCustomer().getId());
                projectDto.setCustomerName(project.getCustomer().getCustomerName());
                projectDtos.add(projectDto);
            }
            customerDto.setProjects(projectDtos);


           
            return new ResponseEntity<>(customerDto, HttpStatus.OK);
        } catch (CustomerNotFoundException e) {
            // Handle the case when the customer is not found
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            // Handle any internal server error
            return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<CustomerDTO> getCustomerById(Long id) {
        try {
            Optional<Customer> customer = customerRepository.findById(id);
            if (customer.isPresent()) {

                Customer customerDo = customer.get();
                CustomerDTO customerDto = new CustomerDTO();
                List<ProjectDTO> projectDTOs = new ArrayList<ProjectDTO>();
                customerDto.setId(customerDo.getId());
                customerDto.setCustomerName(customerDo.getCustomerName());
                for (Project projectDo : customerDo.getProjects()) {
                    ProjectDTO projectDto = new ProjectDTO();
                    projectDto.setId(projectDo.getId());
                    projectDto.setProjectName(projectDo.getProjectName());
                    projectDto.setCustomerId(projectDo.getCustomer().getId());
                    projectDto.setCustomerName(projectDo.getCustomer().getCustomerName());
                    projectDTOs.add(projectDto);
                }
                customerDto.setProjects(projectDTOs);
                return ResponseEntity.ok(customerDto);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return null;
        }
    }
}
