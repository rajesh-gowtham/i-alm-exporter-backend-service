package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.igosolutions.uniSync.Modal.ConnectionAudits;

public interface ConnectionAuditRepository  extends JpaRepository<ConnectionAudits, Long> {
	
	//@Transactional
	@Query(value="select * from connectionaudit u WHERE u.connectionname= :auditname order by id desc", nativeQuery = true)
	List<ConnectionAudits> getSelectedConnectionaudits(String auditname); 
	
	@Query(value="select * from connectionaudit order by id desc", nativeQuery = true)
	List<ConnectionAudits> getAllAudit(); 
	
	
	
	
	@Query(value="select * from connectionaudit u WHERE u.connectionname= :auditname AND  (auditdatetime BETWEEN :startdate AND :enddate)", nativeQuery = true)
	List<ConnectionAudits> getFilterConnectionaudits(String auditname,String startdate,StringBuilder enddate); 
	
	
	//SELECT TOP 20 * FROM connectionaudit
	@Query(value="SELECT TOP 20 * FROM connectionaudit ORDER BY id DESC", nativeQuery = true)
	List<ConnectionAudits> getCurrentMonthConnectionaudits(); 
	
	
	
	//from connectionaudit t where yourDate BETWEEN :startDate AND :endDate
	
	//value = "select * from connectionaudit u WHERE u.connectionname= :auditname and  auditdatetime BETWEEN :startdate AND :enddate"
	//select e from connectionaudit e where year(e.auditdatetime) = year(current_date) and  month(e.auditdatetime) = month(current_date)
	
	//SELECT * FROM USERS u WHERE u.status
	
}


