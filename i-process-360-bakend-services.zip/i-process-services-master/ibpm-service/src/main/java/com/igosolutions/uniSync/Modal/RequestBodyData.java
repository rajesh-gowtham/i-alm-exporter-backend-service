package com.igosolutions.uniSync.Modal;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestBodyData {
    @JsonProperty("ActivityTexts")
    private List<ActivityText> activityTexts;

    @JsonProperty("remainingTexts")
    private List<RemainingText> remainingTexts;

    @JsonProperty("oldCommentTexts")
    private List<CommentText> oldCommentTexts;
    
	@JsonProperty("newCommentTexts")
    private List<CommentText> newCommentTexts;
    
    public List<ActivityText> getActivityTexts() {
		return activityTexts;
	}

	public void setActivityTexts(List<ActivityText> activityTexts) {
		this.activityTexts = activityTexts;
	}

	public List<RemainingText> getRemainingTexts() {
		return remainingTexts;
	}

	public void setRemainingTexts(List<RemainingText> remainingTexts) {
		this.remainingTexts = remainingTexts;
	}

	public List<CommentText> getOldCommentTexts() {
		return oldCommentTexts;
	}

	public void setOldCommentTexts(List<CommentText> oldCommentTexts) {
		this.oldCommentTexts = oldCommentTexts;
	}

	public List<CommentText> getNewCommentTexts() {
		return newCommentTexts;
	}

	public void setNewCommentTexts(List<CommentText> newCommentTexts) {
		this.newCommentTexts = newCommentTexts;
	}

}