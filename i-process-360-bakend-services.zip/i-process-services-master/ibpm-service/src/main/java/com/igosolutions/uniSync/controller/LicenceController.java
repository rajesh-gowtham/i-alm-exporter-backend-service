package com.igosolutions.uniSync.controller;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Service.LicenseService;
import com.igosolutions.uniSync.utils.HeaderUtil;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LicenceController {

    Logger log = LoggerFactory.getLogger(LicenceController.class);
    @Autowired
    LicenseService licenseService;
    @PostMapping("public/licence/uploadFile")
    public ResponseEntity<?> postDecryptedFile(@RequestParam("file") MultipartFile file) {
        log.info("UploadDocuments Request");
        Map<String, String> responseBody = new HashMap<String, String>();
        if (file == null || file.isEmpty()) {
            responseBody.put("message", "Please upload the valid file");
            return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
        }
    
        try {
            // Get the file content as bytes and convert to String
            String fileContent = new String(file.getBytes(), StandardCharsets.UTF_8);
            log.info("File content: {}", fileContent);
            ResponseEntity<?> responseMessage = licenseService.processEncryptedLicenceData(fileContent, file.getOriginalFilename());
            return responseMessage;
        } catch (Exception e) {
            log.error("Error while processing file content", e);
            responseBody.put("message", "Error processing file");
            return new ResponseEntity<>(responseBody, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/licence/update/uploadFile")
    public ResponseEntity<?> updateLicenceFile(@RequestParam("file") MultipartFile file, @RequestHeader Map<String, String> headers) {
        log.info("UploadDocuments Request");
    
        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body("No files provided");
        }
    
        try {
            // Get the file content as bytes and convert to String
            String fileContent = new String(file.getBytes(), StandardCharsets.UTF_8);
    
            log.info("File content: {}", fileContent);
            String org = HeaderUtil.getOrganization(headers);
    
            ResponseEntity<?> responseMessage = licenseService.processEncryptedUpdatedLicense(fileContent, file.getOriginalFilename(), org);
            
            // Return a successful response
            return responseMessage;
    
        } catch (Exception e) {
            log.error("Error while processing file content", e);
            Map<String, String> responseBody = new HashMap<String, String>();
            responseBody.put("message", "Error processing file");
            return new ResponseEntity<>(responseBody, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("public/licence/createAdmin")
    public ResponseEntity<?> createAdminUser(@RequestBody BpmnUserRequest adminUser){
        ResponseEntity<?> responseData = licenseService.createAdminUser(adminUser);
        return responseData;
    }
    
    @DeleteMapping("licence/deleteLicense")
    @ResponseStatus(HttpStatus.OK)
    public String deleteLicense(@RequestBody BpmnUserRequest request){
        String responseData = licenseService.deleteLicense(request);
        return responseData;
    }
    

}
