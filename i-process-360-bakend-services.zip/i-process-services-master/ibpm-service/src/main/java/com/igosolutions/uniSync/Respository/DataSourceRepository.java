package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.DataSource;

public interface DataSourceRepository extends JpaRepository<DataSource, Long> {
    
	@Query("select s from DataSource s where s.datasourcename = :datasourcename")
	DataSource existsByDatasourcename(String datasourcename);
	
	@Query("select s from DataSource s where s.datasourcename = :datasourcename")
	DataSource findByDatasourcename(String datasourcename);
	
	@Query("select s from DataSource s where s.id = :configId")
	DataSource findByDatasourceId(Long configId);
	
	@Query("select s from DataSource s where s.defectTool = :tool")
	DataSource findByTool(String tool);
	
	@Query("select s from DataSource s")
	List<DataSource> findAll();

	@Modifying
	@Query("delete from DataSource s where s.datasourcename = :datasourcename")
	void deleteByDataSource(String datasourcename);
	
//  select domainname from data_source where datasourcename='Dummy Project'
	@Query("select s from DataSource s where s.datasourcename = :targetdatasource")
	DataSource selectDomanin(String targetdatasource);

	  @Query("SELECT d FROM DataSource d WHERE d.defectTool = :defectTool")
    List<DataSource> getSharepointTool(@Param("defectTool") String defectTool);

    List<DataSource> findAllByOrganization(String organization);

	@Query("SELECT d FROM DataSource d WHERE LOWER(d.defectTool) = LOWER(:defectTool) AND d.organization = :organization")
	List<DataSource> getDefectToolByOrganization(@Param("defectTool")String defectTool, @Param("organization")String organization);

	@Query("select s from DataSource s where s.datasourcename = :datasourcename AND s.organization = :organization")
	DataSource findByDataSourceNameAndOrganization(String datasourcename, String organization);
	

}
