package com.igosolutions.uniSync.Modal;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.igosolutions.uniSync.audit.AuditListener;

@Entity
@Audited
@EntityListeners(AuditListener.class)
@Table(name = "review_map")
public class ReviewDiagramme {
    
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
    private Long id;
    
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "review_diagramme_id")
	@Column(name = "assigned_users")
    private List<AssignedUser> assignedUsers;

    @Column(name = "author")
    private String author;
    
    @Column(name = "author_user_id")
    private String authorUserId;

    @Column(name = "status")
    private String status;

    @Column(name = "diagram_name")
    private String diagramName;
    
    @Column(name = "language_name")
	private String languageName;
    
	@Column(name = "language_code")
	private String languageCode;
	 
	@Column(name ="access_rights")
	private String mapPrivacyType;
	
	@Column(name ="organization")
	private String organization;
	
	@Column(name ="time_stamp")
	private String timeStamp;
	
	@Column(name = "storage_type")
	private String storageType;
	
	@Column(name = "config_name")
	private String configName;
	
	@Column(name = "config_id")
	private String configId;
	
	@OneToMany(mappedBy = "reviewDiagramme", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<MapVersion> mapVersions;
	
	@OneToMany(mappedBy = "reviewDiagramme", cascade = CascadeType.ALL)
    private List<MapAccess> mapAccess;

	@ManyToOne()
    @JoinColumn(name = "project_id")
    @JsonBackReference
    private Project project;

	@Transient
	private String errorMessage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthorUserId() {
		return authorUserId;
	}

	public void setAuthorUserId(String authorUserId) {
		this.authorUserId = authorUserId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDiagramName() {
		return diagramName;
	}

	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}

	public String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getMapPrivacyType() {
		return mapPrivacyType;
	}

	public void setMapPrivacyType(String mapPrivacyType) {
		this.mapPrivacyType = mapPrivacyType;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getStorageType() {
		return storageType;
	}

	public void setStorageType(String storageType) {
		this.storageType = storageType;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

	public List<MapVersion> getMapVersions() {
		return mapVersions;
	}

	public void setMapVersions(List<MapVersion> mapVersions) {
		this.mapVersions = mapVersions;
	}

	public List<MapAccess> getMapAccess() {
		return mapAccess;
	}

	public void setMapAccess(List<MapAccess> mapAccess) {
		this.mapAccess = mapAccess;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<AssignedUser> getAssignedUsers() {
		return assignedUsers;
	}

	public void setAssignedUsers(List<AssignedUser> assignedUsers) {
		this.assignedUsers = assignedUsers;
	}

	@Override
	public String toString() {
		return "ReviewDiagramme [id=" + id + ", assignedUsers=" + assignedUsers + ", author=" + author
				+ ", authorUserId=" + authorUserId + ", status=" + status + ", diagramName=" + diagramName
				+ ", languageName=" + languageName + ", languageCode=" + languageCode + ", mapPrivacyType="
				+ mapPrivacyType + ", organization=" + organization + ", timeStamp=" + timeStamp + ", storageType="
				+ storageType + ", configName=" + configName + ", configId=" + configId + ", mapVersions=" + mapVersions
				+ ", mapAccess=" + mapAccess + ", project=" + project + ", errorMessage=" + errorMessage + "]";
	}
	

	
	

	
	
	
	
	

}
