package com.igosolutions.uniSync.Modal;

public class BpmnXmlDto {
    private String bpmnXml;
    private Long taskConnectionId;
    public String getBpmnXml() {
        return bpmnXml;
    }
    public void setBpmnXml(String bpmnXml) {
        this.bpmnXml = bpmnXml;
    }
    public Long getTaskConnectionId() {
        return taskConnectionId;
    }
    public void setTaskConnectionId(Long taskConnectionId) {
        this.taskConnectionId = taskConnectionId;
    }

    
}
