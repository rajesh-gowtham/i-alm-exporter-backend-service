package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.PublishBpmn;

public interface PublishBpmnRepository extends JpaRepository<PublishBpmn, Long> {

	 @Transactional
	    @Modifying
	    @Query(value = "insert into publish_bpmn (url,diagramname) VALUES (:url,:diagramname)", nativeQuery = true)
	    void savedetails(String url,String diagramname);
	
	    
}
