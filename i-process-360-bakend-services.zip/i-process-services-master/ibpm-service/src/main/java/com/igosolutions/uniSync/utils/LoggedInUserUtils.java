package com.igosolutions.uniSync.utils;

public class LoggedInUserUtils {

		private static String loggedInUsername=null;
		private static String loggedInUserType=null;

		/*
	     Retrieve the username of the logged in user.
		 */
		public static String getLoggedInUsername() {
			return loggedInUsername;
		}

		/*
		 * set the username of the logged in user.
		 */
		public static void setLoggedInUsername(String logInUsername) {
			loggedInUsername=logInUsername;
		}

		public static void clearLoggedInUserName() {
			loggedInUsername = null;
		}
		
		/*
		 * set the username of the logged in user.
		 */
		public static void setLoggedInUserType(String logInUserType) {
			loggedInUserType=logInUserType;
		}
		
		/*
	    Retrieve the username of the logged in user.
		 */
		public static String getLoggedInUserType() {
			return loggedInUserType;
		}
	
}
