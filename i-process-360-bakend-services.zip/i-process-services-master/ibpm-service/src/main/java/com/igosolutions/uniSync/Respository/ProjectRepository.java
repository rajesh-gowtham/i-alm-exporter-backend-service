package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {

    boolean existsByProjectNameAndCustomer(String projectName, Customer customer);
    
    @Query("select s from Project s where s.id = :id")
    Project findByProjectId(Long id);
    
}
