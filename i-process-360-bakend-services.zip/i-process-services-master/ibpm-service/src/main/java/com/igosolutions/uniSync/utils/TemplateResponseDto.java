package com.igosolutions.uniSync.utils;

public class TemplateResponseDto {
	
	private Long id;
	private String templateName;
	private String companyName;
	private CompanyLogo companyLogo;
	private String colorCode;
	private String navUpIcon;
	private String navPreviousIcon;
	private String navHomeIcon;
	private String iconSource;
	private String navUpImg;
	private String navPreviousImg;
	private String navHomeImg;
	
	
	

	public String getTemplateName() {
		return templateName;
	}


	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public CompanyLogo getCompanyLogo() {
		return companyLogo;
	}


	public void setCompanyLogo(CompanyLogo companyLogo) {
		this.companyLogo = companyLogo;
	}


	public String getColorCode() {
		return colorCode;
	}


	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}


	public String getNavUpIcon() {
		return navUpIcon;
	}


	public void setNavUpIcon(String navUpIcon) {
		this.navUpIcon = navUpIcon;
	}


	public String getNavPreviousIcon() {
		return navPreviousIcon;
	}


	public void setNavPreviousIcon(String navPreviousIcon) {
		this.navPreviousIcon = navPreviousIcon;
	}


	public String getNavHomeIcon() {
		return navHomeIcon;
	}


	public void setNavHomeIcon(String navHomeIcon) {
		this.navHomeIcon = navHomeIcon;
	}


	public String getIconSource() {
		return iconSource;
	}


	public void setIconSource(String iconSource) {
		this.iconSource = iconSource;
	}


	public String getNavUpImg() {
		return navUpImg;
	}


	public void setNavUpImg(String navUpImg) {
		this.navUpImg = navUpImg;
	}


	public String getNavPreviousImg() {
		return navPreviousImg;
	}


	public void setNavPreviousImg(String navPreviousImg) {
		this.navPreviousImg = navPreviousImg;
	}


	public String getNavHomeImg() {
		return navHomeImg;
	}


	public void setNavHomeImg(String navHomeImg) {
		this.navHomeImg = navHomeImg;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "TemplateResponseDto [id=" + id + ", templateName=" + templateName + ", companyName=" + companyName
				+ ", companyLogo=" + companyLogo + ", colorCode=" + colorCode + ", navUpIcon=" + navUpIcon
				+ ", navPreviousIcon=" + navPreviousIcon + ", navHomeIcon=" + navHomeIcon + ", iconSource=" + iconSource
				+ ", navUpImg=" + navUpImg + ", navPreviousImg=" + navPreviousImg + ", navHomeImg=" + navHomeImg + "]";
	}


}
