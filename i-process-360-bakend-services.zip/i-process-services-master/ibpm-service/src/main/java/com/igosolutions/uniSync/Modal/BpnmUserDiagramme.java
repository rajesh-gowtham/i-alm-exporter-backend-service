package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ibpmn_user_diagramme")
public class BpnmUserDiagramme {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "diagram_xml_id")
	private int diagramXmlId;
	@Column(name = "userid")
	private Long userid;
	@Column(name = "xml_data")
	private String xmlData;
    @Column(name = "language_name")
	private String languageName;
	@Column(name = "language_code")
	private String languageCode;
//	@Column(name = "storage_type")
//	private String storageType;
//	@Column(name = "config_name")
//	private String configName;
//	@Column(name = "config_id")
//	private String configId;
	@Column(name = "diagram_name")
    private String diagramName;
	@Column(name = "template")
    private String template;
	@Column(name = "time_stamp")
	private String timeStamp;
   


	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getXmlData() {
		return xmlData;
	}
	public void setXmlData(String xmlData) {
		this.xmlData = xmlData;
	}
	
//	public String getStorageType() {
//		return storageType;
//	}
//	public void setStorageType(String storageType) {
//		this.storageType = storageType;
//	}
//	public String getConfigName() {
//		return configName;
//	}
//	public void setConfigName(String configName) {
//		this.configName = configName;
//	}
//	public String getConfigId() {
//		return configId;
//	}
//	public void setConfigId(String configId) {
//		this.configId = configId;
//	}
	
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "BpnmUserDiagramme [diagramXmlId=" + diagramXmlId + ", userid=" + userid + ", xmlData=" + xmlData
				+ ", languageName=" + languageName + ", languageCode=" + languageCode + ", diagramName=" + diagramName
				+ ", template=" + template + ", timeStamp=" + timeStamp + "]";
	}
	
}