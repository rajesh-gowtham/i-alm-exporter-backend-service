package com.igosolutions.uniSync.ServiceImpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.ReviewComments;
import com.igosolutions.uniSync.Modal.ReviewCommentsDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.CommentsRepository;
import com.igosolutions.uniSync.Respository.NotificationRepository;
import com.igosolutions.uniSync.Service.CommentsService;
import com.igosolutions.uniSync.Service.NotificationService;
import com.igosolutions.uniSync.constants.UtilsConstants.CommentsConstants;
import com.igosolutions.uniSync.utils.AsyncEmailService;
import com.igosolutions.uniSync.utils.CommentsMentionDto;
import com.igosolutions.uniSync.utils.EmailBody;
import com.igosolutions.uniSync.utils.PdfPageNumberHandler;
import com.igosolutions.uniSync.utils.Recipients;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class CommentsServiceImpl implements CommentsService{

	@Autowired
	CommentsRepository commentsRepository;
	
	@Autowired
	BpmnUserRepository bpmnUserRepository;

	@Autowired
	EntityManager entityManager;

	@Autowired
	NotificationService notificationService;

	@Autowired
    BpnmUserDiagrammeRepository bpmnDiagrammeRepository;

	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	MailContentServiceImpl mailContentServiceImpl;
	
	@Autowired
	AsyncEmailService asyncEmailService;
	
	Logger log = LoggerFactory.getLogger(CommentsServiceImpl.class);
	

	@Override
	public List<ReviewCommentsDTO> saveComments(int diagramXmlId, String currentXmlId,List<ReviewComments> reviewComments) throws Exception {
		List<ReviewComments> retrivedComments = null;
		List<ReviewComments> responseComments = null;
		Long commentId;
		final int versionNum;
		
		try {
			
		
			log.info("Comment to be added with diagramXmlId was Processing  :: ",diagramXmlId);
			log.info("Comment to be added was Processing   ::   ",reviewComments.get(0).getCommentMessage());

			retrivedComments = commentsRepository.findByDiagramXmlIdOrderByTimeStampDesc(diagramXmlId);
			if(retrivedComments.size() == 0) 
                versionNum = 1; 
				 
			else {
				
				if(!retrivedComments.get(0).getMapDiagramStatus().equalsIgnoreCase(CommentsConstants.INREVIEW))
				    versionNum = retrivedComments.get(0).getVersionName()+1;
                else 
					versionNum = retrivedComments.get(0).getVersionName();
			}
			
			    List<ReviewComments> transformComments = reviewComments.stream().map(comment ->{
            	
            	BpmnUser bpmnUser = bpmnUserRepository.findByUserId(comment.getCommentedUserId());
            	comment.setDiagramXmlId(diagramXmlId);
            	comment.setCurrentXmlId(currentXmlId);
            	comment.setVersionName(versionNum);
            	comment.setUserName(bpmnUser.getFirstname()+" "+bpmnUser.getLastname());
				
            	
            	return comment;
            
            }).collect(Collectors.toList()); 
			    
			responseComments = commentsRepository.saveAll(transformComments);
			commentId = responseComments.get(0).getCommentId();
			responseComments= commentsRepository.findByDiagramXmlIdOrderByTimeStampAsc(diagramXmlId);
			  
		   }catch(Exception e) {
			  
			 throw new Exception("Unable to add comments due to server issues. Please try again later");

		}
		
		List<ReviewCommentsDTO> reviewCommentsDTOList = new ArrayList<>();
        for(ReviewComments reviewComment : responseComments) {
        	BpmnUser bpmUser = bpmnUserRepository.findByUserId(reviewComment.getCommentedUserId());
			ReviewCommentsDTO reviewCommentsDTO = new ReviewCommentsDTO();

			
			
		    reviewCommentsDTO.setCommentId(reviewComment.getCommentId());
		    reviewCommentsDTO.setDiagramXmlId(reviewComment.getDiagramXmlId());
		    reviewCommentsDTO.setCurrentXmlId(reviewComment.getCurrentXmlId());
		    reviewCommentsDTO.setCommentMessage(reviewComment.getCommentMessage());
		    reviewCommentsDTO.setTimeStamp(reviewComment.getTimeStamp());
		    reviewCommentsDTO.setCommentedUserId(reviewComment.getCommentedUserId());
		    reviewCommentsDTO.setMapDiagramStatus(reviewComment.getMapDiagramStatus());
		    reviewCommentsDTO.setUserName(reviewComment.getUserName());  // Assuming BpmnUser has a userName field
		    reviewCommentsDTO.setVersionName(reviewComment.getVersionName());
		    reviewCommentsDTO.setActivityId(reviewComment.getActivityId());
		    reviewCommentsDTO.setActivityNum(reviewComment.getActivityNum());
		    reviewCommentsDTO.setRole(bpmUser.getRole());  // Set the role from BpmnUser
		    reviewCommentsDTO.setFlagToggleActivity(reviewComment.getFlagToggleActivity());

		    // Add the DTO to the list
		    reviewCommentsDTOList.add(reviewCommentsDTO);
        }
		//Creating Notification for the Comments
		bpmnDiagrammeRepository.findById(diagramXmlId).ifPresent(diagramme -> {
			BpmnUser bpmnUser = bpmnUserRepository.findByUserId(reviewComments.get(0).getCommentedUserId());
			notificationService.createNotification(diagramme.getUserid(), diagramXmlId, bpmnUser.getRole(), commentId);
		});
		
		return reviewCommentsDTOList;
	}
	
	@Override
	public void updateComments(Long commentId, Boolean flagToggleActivity) throws Exception{
		ReviewComments reviewComments = commentsRepository.findByCommentId(commentId);
		reviewComments.setFlagToggleActivity(flagToggleActivity);
		commentsRepository.save(reviewComments);
	}

	@Override
	public List<ReviewCommentsDTO> getCommentsByDiagramXmlId(int diagramXmlId) throws Exception {
		try {
			List<ReviewComments> comments = commentsRepository.findByDiagramXmlIdOrderByTimeStampAscWithRole(diagramXmlId);
			List<ReviewCommentsDTO> reviewCommentsDTOList = new ArrayList<>();
			for(ReviewComments reviewComments: comments) {
				BpmnUser bpmUser = bpmnUserRepository.findByUserId(reviewComments.getCommentedUserId());
				ReviewCommentsDTO reviewCommentsDTO = new ReviewCommentsDTO();
				
			    reviewCommentsDTO.setCommentId(reviewComments.getCommentId());
			    reviewCommentsDTO.setDiagramXmlId(reviewComments.getDiagramXmlId());
			    reviewCommentsDTO.setCurrentXmlId(reviewComments.getCurrentXmlId());
			    reviewCommentsDTO.setCommentMessage(reviewComments.getCommentMessage());
			    reviewCommentsDTO.setTimeStamp(reviewComments.getTimeStamp());
			    reviewCommentsDTO.setCommentedUserId(reviewComments.getCommentedUserId());
			    reviewCommentsDTO.setMapDiagramStatus(reviewComments.getMapDiagramStatus());
			    reviewCommentsDTO.setUserName(reviewComments.getUserName());  // Assuming BpmnUser has a userName field
			    reviewCommentsDTO.setVersionName(reviewComments.getVersionName());
			    reviewCommentsDTO.setActivityId(reviewComments.getActivityId());
			    reviewCommentsDTO.setActivityNum(reviewComments.getActivityNum());
			    reviewCommentsDTO.setRole(bpmUser.getRole());  // Set the role from BpmnUser
			    reviewCommentsDTO.setFlagToggleActivity(reviewComments.getFlagToggleActivity());

			    // Add the DTO to the list
			    reviewCommentsDTOList.add(reviewCommentsDTO);
			}
		return reviewCommentsDTOList;
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to view comments due to server issues. Please try again later");
		}
	}
	@Override
	public void deleteComments(Long commentId) {
		try {
			commentsRepository.deleteById(commentId);
			notificationRepository.deleteByCommentId(commentId);
		} catch (Exception e) {
			e.printStackTrace();
            log.error("Unable to delete comment with id :: "+commentId+" due to server issues. Please try again later");
		}
	}

	@Override
	public ResponseEntity<?> editComments(Long commentId, ReviewComments reviewComments) {
		try {
			ReviewComments byCommentId = commentsRepository.findByCommentId(commentId);
			if (byCommentId != null) {
				byCommentId.setCommentMessage(reviewComments.getCommentMessage());
				ReviewComments updatedComment = commentsRepository.save(byCommentId);
				BpmnUser bpmUser = bpmnUserRepository.findByUserId(byCommentId.getCommentedUserId());
                ReviewCommentsDTO reviewCommentsDTO = new ReviewCommentsDTO();
				
			    reviewCommentsDTO.setCommentId(updatedComment.getCommentId());
			    reviewCommentsDTO.setDiagramXmlId(updatedComment.getDiagramXmlId());
			    reviewCommentsDTO.setCurrentXmlId(updatedComment.getCurrentXmlId());
			    reviewCommentsDTO.setCommentMessage(updatedComment.getCommentMessage());
			    reviewCommentsDTO.setTimeStamp(updatedComment.getTimeStamp());
			    reviewCommentsDTO.setCommentedUserId(updatedComment.getCommentedUserId());
			    reviewCommentsDTO.setMapDiagramStatus(updatedComment.getMapDiagramStatus());
			    reviewCommentsDTO.setUserName(updatedComment.getUserName());  // Assuming BpmnUser has a userName field
			    reviewCommentsDTO.setVersionName(updatedComment.getVersionName());
			    reviewCommentsDTO.setActivityId(updatedComment.getActivityId());
			    reviewCommentsDTO.setActivityNum(updatedComment.getActivityNum());
			    reviewCommentsDTO.setRole(bpmUser.getRole());  // Set the role from BpmnUser
			    reviewCommentsDTO.setFlagToggleActivity(updatedComment.getFlagToggleActivity());
			    
				return new ResponseEntity<>(reviewCommentsDTO, HttpStatus.OK);
			}
			else{
				log.error("No comment found with id :: "+commentId);
                return new ResponseEntity<>("No comment found with id :: "+commentId, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			e.printStackTrace();
            log.error("Unable to update comment with id :: "+commentId+" due to server issues. Please try again later");
			return new ResponseEntity<>("Unable to update comment due to server issues. Please try again later", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void updateAllComments(List<ReviewCommentsDTO> reviewCommentsDTOs) throws Exception {
		for(ReviewCommentsDTO reviewCommentsDTO: reviewCommentsDTOs) {
			ReviewComments reviewComments = commentsRepository.findByCommentId(reviewCommentsDTO.getCommentId());
			if(reviewComments == null) {
				throw new Exception("No comment found with id :: "+reviewCommentsDTO.getCommentId());
			}
			reviewComments.setDiagramXmlId(reviewCommentsDTO.getDiagramXmlId());
			reviewComments.setCommentMessage(reviewCommentsDTO.getCommentMessage());
			reviewComments.setMapDiagramStatus(reviewCommentsDTO.getMapDiagramStatus());
			reviewComments.setUserName(reviewCommentsDTO.getUserName());
			reviewComments.setVersionName(reviewCommentsDTO.getVersionName());
			reviewComments.setActivityId(reviewCommentsDTO.getActivityId());
			reviewComments.setActivityNum(reviewCommentsDTO.getActivityNum());
			reviewComments.setCommentedUserId(reviewCommentsDTO.getCommentedUserId());
			reviewComments.setFlagToggleActivity(reviewCommentsDTO.getFlagToggleActivity());
			reviewComments.setTimeStamp(reviewCommentsDTO.getTimeStamp());
			reviewComments.setCurrentXmlId(reviewCommentsDTO.getCurrentXmlId());
			reviewComments.setDiagramXmlId(reviewCommentsDTO.getDiagramXmlId());

			commentsRepository.save(reviewComments);
		}
			
	}

	@Override
	public ResponseEntity<?> resequenceUpdates(List<ReviewCommentsDTO> reviewCommentsDtos, int diagramXmlId) {

		List<ReviewComments> retrievedComments = null;
		final int[] versionNum = { 0 }; // Wrap in an array to allow modification

		try {
			log.info("Comment to be added with diagramXmlId was Processing  :: {}", diagramXmlId);

			// Retrieve existing comments
			retrievedComments = commentsRepository.findByDiagramXmlIdOrderByTimeStampDesc(diagramXmlId);

			if (retrievedComments.size() == 0) {
				versionNum[0] = 1; // Modify array value
			} else {
				// Check the status and set version number accordingly
				if (!retrievedComments.get(0).getMapDiagramStatus().equalsIgnoreCase(CommentsConstants.INREVIEW)) {
					versionNum[0] = retrievedComments.get(0).getVersionName() + 1;
				} else {
					versionNum[0] = retrievedComments.get(0).getVersionName();
				}
			}

			// Transform incoming comments
			List<ReviewComments> transformedComments = reviewCommentsDtos.stream().map(reviewCommentsDTO -> {
				BpmnUser byUserId = bpmnUserRepository.findByUserId(reviewCommentsDTO.getCommentedUserId());
				ReviewComments reviewComments = new ReviewComments();
				reviewComments.setDiagramXmlId(diagramXmlId);
				reviewComments.setCommentMessage(reviewCommentsDTO.getCommentMessage());
				reviewComments.setMapDiagramStatus(reviewCommentsDTO.getMapDiagramStatus());
				reviewComments.setUserName(byUserId.getFirstname() + " " + byUserId.getLastname());
				reviewComments.setVersionName(reviewCommentsDTO.getVersionName());
				reviewComments.setActivityId(reviewCommentsDTO.getActivityId());
				reviewComments.setActivityNum(reviewCommentsDTO.getActivityNum());
				reviewComments.setCommentedUserId(reviewCommentsDTO.getCommentedUserId());
				reviewComments.setFlagToggleActivity(reviewCommentsDTO.getFlagToggleActivity());
				reviewComments.setCurrentXmlId(reviewCommentsDTO.getCurrentXmlId());

				return reviewComments;
			}).collect(Collectors.toList());

			// Delete existing comments from the database
			commentsRepository.deleteAll(retrievedComments);
			commentsRepository.flush();

			// Insert transformed comments into the database
			List<ReviewComments> reqSequencedComments = commentsRepository.saveAll(transformedComments);

			List<ReviewCommentsDTO> reviewCommentsDTOList = new ArrayList<>();
        	for (ReviewComments reviewComment : reqSequencedComments) {
				BpmnUser bpmUser = bpmnUserRepository.findByUserId(reviewComment.getCommentedUserId());
				ReviewCommentsDTO reviewCommentsDTO = new ReviewCommentsDTO();

				reviewCommentsDTO.setCommentId(reviewComment.getCommentId());
				reviewCommentsDTO.setDiagramXmlId(reviewComment.getDiagramXmlId());
				reviewCommentsDTO.setCurrentXmlId(reviewComment.getCurrentXmlId());
				reviewCommentsDTO.setCommentMessage(reviewComment.getCommentMessage());
				reviewCommentsDTO.setTimeStamp(reviewComment.getTimeStamp());
				reviewCommentsDTO.setCommentedUserId(reviewComment.getCommentedUserId());
				reviewCommentsDTO.setMapDiagramStatus(reviewComment.getMapDiagramStatus());
				reviewCommentsDTO.setUserName(reviewComment.getUserName()); // Assuming BpmnUser has a userName field
				reviewCommentsDTO.setVersionName(reviewComment.getVersionName());
				reviewCommentsDTO.setActivityId(reviewComment.getActivityId());
				reviewCommentsDTO.setActivityNum(reviewComment.getActivityNum());
				reviewCommentsDTO.setRole(bpmUser.getRole()); // Set the role from BpmnUser
				reviewCommentsDTO.setFlagToggleActivity(reviewComment.getFlagToggleActivity());

				// Add the DTO to the list
				reviewCommentsDTOList.add(reviewCommentsDTO);
			}
			//Creating Notification for the Comments
//			if (!reqSequencedComments.isEmpty()) {
//				bpmnDiagrammeRepository.findById(diagramXmlId).ifPresent(diagramme -> {
//					BpmnUser bpmnUser = bpmnUserRepository
//							.findByUserId(reqSequencedComments.get(reqSequencedComments.size()-1).getCommentedUserId());
//					notificationService.createNotification(diagramme.getUserid(), diagramXmlId, bpmnUser.getRole(),
//					reqSequencedComments.get(reqSequencedComments.size()-1).getCommentedUserId());
//				});
//			}

			return new ResponseEntity<>(reviewCommentsDTOList,HttpStatus.OK);

		} catch (Exception e) {
			log.error("Error occurred while resequencing comments", e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void sendMentionedComment(CommentsMentionDto commentsMentionDto) throws Exception {
		
		try {
			
			List<Long> userIds = commentsMentionDto.recipients.stream()
                    .map(Recipients::getUserId)
                    .collect(Collectors.toList());
			
			List<String>recipientsEmails = bpmnUserRepository.findByUserId(userIds);
			
			BpmnUser sender = bpmnUserRepository.findByUserId(commentsMentionDto.getSenderUserId());
			
			String senderName = sender.getFirstname()+" "+sender.getLastname();
			
			String content = mailContentServiceImpl.mentionCommentsMap(recipientsEmails,senderName,commentsMentionDto.getEmailBody(),commentsMentionDto.diagramName);
			asyncEmailService.sendCommentsMentionMail(recipientsEmails,content,commentsMentionDto.diagramName);
		}catch(Exception e) {
			
			e.printStackTrace();
			
			throw new Exception(e.getMessage());
			
		}
		
	}

	@Override
	public ByteArrayOutputStream generatePdf(List<EmailBody> comments,String diagramName) throws Exception {
       		
		 try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
		        // Create document and writer
		        Document document = new Document();
		        PdfWriter writer = PdfWriter.getInstance(document, out);

		        // Add page event for page numbering
		        writer.setPageEvent(new PdfPageNumberHandler() {
		            @Override
		            public void onEndPage(PdfWriter writer, Document document) {
		                ColumnText.showTextAligned(
		                        writer.getDirectContent(),
		                        Element.ALIGN_CENTER,
		                        new Phrase(String.format("Page %d", writer.getPageNumber()), FontFactory.getFont(FontFactory.HELVETICA, 12)),
		                        (document.right() - document.left()) / 2 + document.leftMargin(),
		                        document.bottom() - 10,
		                        0
		                );
		            }
		        });

		        // Open document for writing
		        document.open();

		        // Define fonts
		        Font userNameFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
		        Font messageFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11);
		        Font timeStampFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
		        Font messageContentFont = FontFactory.getFont(FontFactory.HELVETICA, 11);

		        // Add title to the document
		        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
		        Paragraph title = new Paragraph("Comments report - "+diagramName, titleFont);
		        title.setAlignment(Element.ALIGN_CENTER);
		        document.add(title);
		        document.add(Chunk.NEWLINE); // Add space after title

		        // Loop through comments and format them
		        for (EmailBody comment : comments) {
		            // User name (bold)
		            Chunk userNameChunk = new Chunk(comment.userName + " ", userNameFont);

		            // TimeStamp (regular)
		            Chunk timeStampChunk = new Chunk(comment.timeStamp + "\n", timeStampFont);

		            // Message (bold for "Message:" and regular for content)
		            Chunk messageLabelChunk = new Chunk("Message: ", messageFont);
		            Chunk messageContentChunk = new Chunk(comment.commentMessage + "\n\n", messageContentFont);

		            // Combine and add to the document
		            Paragraph paragraph = new Paragraph();
		            paragraph.add(userNameChunk);
		            paragraph.add(timeStampChunk);
		            paragraph.add(messageLabelChunk);
		            paragraph.add(messageContentChunk);

		            document.add(paragraph);
		        }

		        // Close the document
		        document.close();

		        return out;

		    } catch (Exception e) {
		        e.printStackTrace();
		        throw new Exception(e.getMessage());
		    }
    }

	@Override
	public void sendEmailWithPdf(List<Recipients> recipients, MultipartFile pdfMultipartFile,String originalFileName, String diagramName,String userName) throws Exception {
		// TODO Auto-generated method stub
		try {
		
		List<Long> userIds = recipients.stream()
                .map(Recipients::getUserId)
                .collect(Collectors.toList());
		
		List<String>recipientsEmails = bpmnUserRepository.findByUserId(userIds);
		
		String content = mailContentServiceImpl.mapGroupContent(recipientsEmails,diagramName,userName);
		
		asyncEmailService.sendMailWithPdf(recipientsEmails,pdfMultipartFile,originalFileName,diagramName,content);
		}catch(Exception e) {
			
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		
		
		
		
	}

	@Override
	 public MultipartFile convertByteArrayToMultipartFile(byte[] byteArray, String fileName) {
        return new MultipartFile() {
            @Override
            public String getName() {
                return fileName;
            }

            @Override
            public String getOriginalFilename() {
                return fileName;
            }

            @Override
            public String getContentType() {
                return "application/pdf";
            }

            @Override
            public boolean isEmpty() {
                return byteArray.length == 0;
            }

            @Override
            public long getSize() {
                return byteArray.length;
            }

            @Override
            public byte[] getBytes() throws IOException {
                return byteArray;
            }

            @Override
            public InputStream getInputStream() throws IOException {
                return new ByteArrayInputStream(byteArray);
            }
            
            
            @Override
            public void transferTo(File dest) throws IOException, IllegalStateException {
                try (FileOutputStream fos = new FileOutputStream(dest)) {
                    fos.write(byteArray); 
                }
            }

			
        };
    }

	

}
