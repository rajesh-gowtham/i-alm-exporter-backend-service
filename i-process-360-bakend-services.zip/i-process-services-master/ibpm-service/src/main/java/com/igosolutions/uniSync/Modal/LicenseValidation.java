package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name= "license_validation")
public class LicenseValidation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "custom-id")
    @GenericGenerator(name= "custom-id", strategy = "com.igosolutions.uniSync.Modal.CustomIdGenerator")
    @Column(name = "license_id")
    Long licenseId;
    
    String organization;
    String admins;
    String editors;
    String reviewers;
    String viewers;
    String status;
    @Column(name = "valid_from")
    String validFrom;
    @Column(name = "valid_to")
    String validTo;

    public Long getLicenseId() {
        return licenseId;
    }
    public void setLicenseId(Long licenseId) {
        this.licenseId = licenseId;
    }
    public String getOrganization() {
        return organization;
    }
    public void setOrganization(String organization) {
        this.organization = organization;
    }
    
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getAdmins() {
        return admins;
    }
    public void setAdmins(String admins) {
        this.admins = admins;
    }
    public String getEditors() {
        return editors;
    }
    public void setEditors(String editors) {
        this.editors = editors;
    }
    public String getReviewers() {
        return reviewers;
    }
    public void setReviewers(String reviewers) {
        this.reviewers = reviewers;
    }
    public String getViewers() {
        return viewers;
    }
    public void setViewers(String viewers) {
        this.viewers = viewers;
    }
    
    public String getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}
	public String getValidTo() {
		return validTo;
	}
	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	@Override
	public String toString() {
		return "LicenseValidation [licenseId=" + licenseId + ", organization=" + organization + ", admins=" + admins
				+ ", editors=" + editors + ", reviewers=" + reviewers + ", viewers=" + viewers + ", status=" + status
				+ ", validFrom=" + validFrom + ", validTo=" + validTo + "]";
	}

}