package com.igosolutions.uniSync.controller;
import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.CustomerDTO;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Respository.CustomerRepository;
import com.igosolutions.uniSync.Service.CustomerService;
import com.igosolutions.uniSync.constants.UtilsConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CustomerService customerService;

    

    @GetMapping("getAllCustomers")
    public List<CustomerDTO> getAllCustomer() {
         List<Customer> allCustomers = customerRepository.findAllByOrganization(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION);
         List<CustomerDTO> allCustomersDTO = new ArrayList<>();
         for (Customer customer : allCustomers) {
            CustomerDTO customerDTO = new CustomerDTO();
            List<ProjectDTO> projectDtos = new ArrayList<>();
            customerDTO.setId(customer.getId());
            customerDTO.setCustomerName(customer.getCustomerName());

            for (Project project : customer.getProjects()) {
                ProjectDTO projectDto = new ProjectDTO();
                projectDto.setId(project.getId());
                projectDto.setProjectName(project.getProjectName());
                projectDto.setCustomerId(project.getCustomer().getId());
                projectDto.setCustomerName(project.getCustomer().getCustomerName());
                projectDtos.add(projectDto);
            }
            customerDTO.setProjects(projectDtos);

            allCustomersDTO.add(customerDTO);
            
         }
         return allCustomersDTO;
    }

    @GetMapping("getCustomerById/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        return customerService.getCustomerById(id);
    }
    @RequestMapping(value = "/getCustomerByName/{customerName}", method = RequestMethod.GET)
    public ResponseEntity<?> getCustomerByName(@PathVariable String customerName) {
        System.out.println("Customer Name: " + customerName);
        return customerService.getCustomerByName(customerName);
    }

    @PostMapping("/createCustomer")
    public ResponseEntity<?> createCustomer(@RequestBody CustomerDTO customer) {
        return customerService.createCustomer(customer);
    }

    @PutMapping("/updateCustomer/{id}")
    public ResponseEntity<?> updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDetails) {
        return customerService.updateCustomer(id, customerDetails);
    }

    @DeleteMapping("/deleteCustomer/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable Long id) {
        return customerService.deleteCustomer(id);
   
    }
}
