package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.controller.EncryptDecrypt;
import com.igosolutions.uniSync.exceptions.InvalidTokenException;

import io.jsonwebtoken.ExpiredJwtException;



@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private CustomUserDetailsService service;

	@Autowired
	BpmnUserRepository bpmnUserRepository;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		try {
			
            String authorizationHeader = request.getHeader("Authorization");
			
            String token = null;
			String userName = null;
			String dycryptedtoken = null;


			
			if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
				token = authorizationHeader.substring(7);
				dycryptedtoken = EncryptDecrypt.decrypt(token);
				if(dycryptedtoken != null) {
					try {
						userName = jwtTokenUtil.extractUsername(dycryptedtoken);
					}catch(Exception ex) {
						log.error("Error processing JWT token: {}", ex.getMessage());
						response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						ex.printStackTrace();
						response.getWriter().write("Session expired please login again to continue");
						return;
					}
				}
				
				else {
					throw new InvalidTokenException("Unauthorized, please login again to continue  ");
				}
			}

			if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {
				UserDetails userDetails = service.loadUserByUsername(userName);

				if (jwtTokenUtil.validateToken(dycryptedtoken, userName)) {
					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
							new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
					usernamePasswordAuthenticationToken
					.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
					BpmnUser user = bpmnUserRepository.findByEmail(userName);
					if (user != null) {
						user.setLastActive(LocalDateTime.now());
						bpmnUserRepository.save(user);
					}
				}
				else{
					throw new InvalidTokenException("Unauthorized, please login again to continue becuase session is active on other device");
				}
			}
			filterChain.doFilter(request, response);

		} catch (InvalidTokenException ex) {
			log.error("Error processing JWT token: {}", ex.getMessage());
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.getWriter().write(ex.getMessage());
		}

		catch(ExpiredJwtException ex) {
			log.error("Error processing JWT token: {}", ex.getMessage());
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.getWriter().write("Session expired please login again to continue");
		}

		catch (Exception ex) {
			ex.printStackTrace();
			log.error("Error processing JWT token: {}", ex.getMessage());
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write("Internal server error : Please try again later");

		}
	}
	
	
}








