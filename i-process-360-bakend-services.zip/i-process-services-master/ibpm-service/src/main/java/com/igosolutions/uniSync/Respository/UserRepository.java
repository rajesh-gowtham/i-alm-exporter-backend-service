package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Users;


public interface UserRepository extends JpaRepository<Users, Long> {

	
    @Query("select u from Users u WHERE u.username= :username and u.password= :password")
	Users logins(String username,String password);
    
    @Query("select u from Users u WHERE u.username= :username")
	Users GetMeKey(String username);
    
    
    @Transactional
    @Modifying
    @Query("delete from Users s where s.username = :username")
   	void deleteUser(String username);
    
    @Transactional
    @Modifying
    @Query(value = "insert into Users (username,password,email,mekey,usercreateon) VALUES (:username,:password,:email,:Me_Key,:Time)", nativeQuery = true)
    void savedetails(String username,String password,String email,String Me_Key,String Time);
    
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE  Users SET password = :password,email = :email, userupdateon= :Time  WHERE username =:username", nativeQuery = true)
    void updateuserdetails(String username,String password,String email,String Time);
    
    
    
}
