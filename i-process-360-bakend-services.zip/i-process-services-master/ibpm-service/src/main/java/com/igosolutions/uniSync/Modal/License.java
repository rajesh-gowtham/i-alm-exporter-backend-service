package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "license")
public class License {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "organization_id")
	private Long organizationId;
	
	@Column(name = "organization_name")
	private String organizationName;
	
	@Column(name = "admins")
	private int admins;
	
	@Column(name = "users")
	private int users;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "pre_encrypted_key")
	private String encryptedKey;
	
	@Column(name = "final_encrypted_key")
	private String finalEncryptedKey;

	
	
	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public int getAdmins() {
		return admins;
	}

	public void setAdmins(int admins) {
		this.admins = admins;
	}

	public int getUsers() {
		return users;
	}

	public void setUsers(int users) {
		this.users = users;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

	public String getEncryptedKey() {
		return encryptedKey;
	}

	public void setEncryptedKey(String encryptedKey) {
		this.encryptedKey = encryptedKey;
	}
	
	public String getFinalEncryptedKey() {
		return finalEncryptedKey;
	}

	public void setFinalEncryptedKey(String finalEncryptedKey) {
		this.finalEncryptedKey = finalEncryptedKey;
	}

	@Override
	public String toString() {
		return "License [organizationId=" + organizationId + ", organizationName=" + organizationName + ", admins="
				+ admins + ", users=" + users + ", status=" + status + ", encryptedKey=" + encryptedKey
				+ ", finalEncryptedKey=" + finalEncryptedKey + "]";
	}

}
