package com.igosolutions.uniSync.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Templates;
import com.igosolutions.uniSync.Service.TemplateService;
import com.igosolutions.uniSync.utils.HeaderUtil;
import com.igosolutions.uniSync.utils.TemplateRequestDto;
import com.igosolutions.uniSync.utils.TemplateResponseDto;


@RestController
public class TemplateController {
	
	@Autowired
	private TemplateService templateService;
	
	@CrossOrigin(origins = "*",allowedHeaders = "*")
	@PostMapping("/api/createTemplate")
	public ResponseEntity<?> createTemplate(@RequestBody TemplateRequestDto templateRequestDto,@RequestHeader Map<String, String> headers) {
		try {
			String organization = HeaderUtil.getOrganization(headers);
			templateService.createTemplates(templateRequestDto, organization);
		}catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
		}
	   
		return new ResponseEntity<String>("Template created sucessfully", HttpStatus.OK);
		
	}
	@CrossOrigin(origins = "*",allowedHeaders = "*")
	@GetMapping("/api/getAllTemplates")
	public List<TemplateResponseDto> getAllTemplates(@RequestHeader Map<String, String> headers) throws Exception{
		String organization = HeaderUtil.getOrganization(headers);
		List<TemplateResponseDto> templates = templateService.getAllTemplatesByOrganization(organization);
		
		return templates;
		
	}
	
	@CrossOrigin(origins = "*",allowedHeaders = "*")
	@PutMapping("/api/updateTemplate")
	public ResponseEntity<?> updateTemplate(@RequestBody TemplateRequestDto templateRequestDto,@RequestHeader Map<String, String> headers) {
		TemplateResponseDto templateResponseDto = new TemplateResponseDto();
		String organization = HeaderUtil.getOrganization(headers);
		try {
			
			templateResponseDto = templateService.updateTemplates(templateRequestDto, organization);
		
		}catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
		}
	   
		return new ResponseEntity<>(templateResponseDto, HttpStatus.OK);
		
	}
	
	
	@CrossOrigin(origins = "*",allowedHeaders = "*")
	@DeleteMapping("/api/deleteTemplateByIds")
	public ResponseEntity<?>deleteTemplates(@RequestBody List<Templates>templateIds) throws Exception{
		
		List<Long> templateId = templateIds.stream().map(template ->
		template.getTemplateId()).collect(Collectors.toList());
		
		try {
			String templates = templateService.deleteTemplates(templateId);
			if(templates == null) {
				return new ResponseEntity<String>("Deleted sucessfully", HttpStatus.NO_CONTENT);
			}
			else {
				return new ResponseEntity<String>("Error while deleting the templates", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	  
	@CrossOrigin(origins = "*",allowedHeaders = "*")
	@GetMapping("/api/getTemplates/{templateId}")
	public ResponseEntity<?> getTemplate(@PathVariable("templateId") Long templateId) throws Exception{
		 
		TemplateResponseDto templates = templateService.getTemplate(templateId);
		   if(templates != null) {
			  return new ResponseEntity<>(templates, HttpStatus.OK);
		  }
		  else {
			  return new ResponseEntity<>("Template Not found", HttpStatus.NOT_FOUND);
		  }
		  
	  }
	 
	 

}
