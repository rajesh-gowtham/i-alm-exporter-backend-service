package com.igosolutions.uniSync.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserLoginDto;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.Role;
import com.igosolutions.uniSync.Modal.RoleResponseDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Service.BpmnUserService;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;
import com.igosolutions.uniSync.utils.HeaderUtil;

@RestController
//@RequestMapping("/users")
public class BpmnUserController {
	

	@Autowired
	BpmnUserService bpmnUserService;
	
	@Autowired
    BpnmUserDiagrammeService bpnmUserDiagrammeService;

	@Autowired
	BpmnUserRepository bpmnUserRepository;

	@Autowired
	MapReviewRepository mapReviewRepository;

	Logger log = LoggerFactory.getLogger(BpmnUserController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/createUser",method = RequestMethod.POST) 
	public ResponseEntity<Object> createUser(@RequestBody BpmnUserRequest bpmnUserRequest) {
		log.debug("Request {}");
		String create_User = "CREATE";
		try {
			Map<String,Object> addBpmnUser = bpmnUserService.addEditUsers(bpmnUserRequest,create_User);
			log.debug("Response {}",addBpmnUser);
			return new ResponseEntity<>(addBpmnUser, HttpStatus.CREATED);

		} catch (Exception e) {

			if("Email already exist".equals(e.getMessage()) || "Maximum number of admins reached".equals(e.getMessage()) || "Maximum number of users reached".equals(e.getMessage()) || "User not exist".equals(e.getMessage()) || e.getMessage().equals("Some projectIds or moduleIds were not found in the database") || e.getMessage().equals("One or more Modules do not belong to the assigned Projects")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
//				e.printStackTrace();
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}

    @CrossOrigin(origins = "*", allowedHeaders = "*")	
	@RequestMapping(value = "public/users/loginAuthentication", method = RequestMethod.POST)
	public ResponseEntity<?> loginAuthentication(@RequestBody BpmnUserLoginDto bpmnUser) {
    	log.debug("Request {}");
		try {
			ResponseEntity<Map<String, Object>> loginAuthentication  = bpmnUserService.checkEmailPassword(bpmnUser);
			return loginAuthentication;

		} catch (Exception e) {
			if(e.getMessage().equals("Incorrect email") || 
					e.getMessage().equals("Incorrect password") ||
					e.getMessage().equals("Email ID does not exist")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}
    @CrossOrigin(origins = "*", allowedHeaders = "*")	
	@RequestMapping(value = "public/users/logout", method = RequestMethod.POST)
	public ResponseEntity<?> logout(@RequestBody BpmnUserRequest logoutRequest) {
		BpmnUser user = bpmnUserRepository.findByEmail(logoutRequest.getEmail());
		user.setDeviceId(null);
		user.setAccesstoken(null);
		user.setLastActive(null);
		user.setIsLogin(false);
		bpmnUserRepository.save(user);
	
		return ResponseEntity.ok("Logged out successfully");
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")	
	@RequestMapping(value = "public/users/logout/{userEmail}", method = RequestMethod.GET)
	public ResponseEntity<?> logout(@PathVariable String userEmail) {
		BpmnUser user = bpmnUserRepository.findByEmail(userEmail);
		user.setDeviceId(null);
		user.setAccesstoken(null);
		user.setLastActive(null);
		user.setIsLogin(false);
		bpmnUserRepository.save(user);
	
		return ResponseEntity.ok("Logged out successfully");
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/viewUserDetails", method = RequestMethod.GET)
	public ResponseEntity<List<Object>> getAllUsers(@RequestHeader Map<String, String> headers) {
		log.debug("Request {}");
		try {
			String org = HeaderUtil.getOrganization(headers);
			List<Object> allUsers = bpmnUserService.getAllUsersWithoutPassword(org);
			return new ResponseEntity<>(allUsers,HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/editUser",method = RequestMethod.POST) 
	public ResponseEntity<Object> updateUser(@RequestBody BpmnUserRequest bpmnUserRequest) {
		log.debug("Request {}", bpmnUserRequest);
		String update_User = "UPDATE";
		try {
			Map<String,Object> updatedBpmnUser = bpmnUserService.addEditUsers(bpmnUserRequest,update_User);
			if(updatedBpmnUser.containsKey("errorMessage")) {
				log.error((String)updatedBpmnUser.get("errorMessage"));
				return new ResponseEntity<>(updatedBpmnUser.get("errorMessage"),HttpStatus.NOT_ACCEPTABLE);
			}
			log.debug("Response {}",updatedBpmnUser);
			return new ResponseEntity<>(updatedBpmnUser,HttpStatus.OK);

		} catch (Exception e) {
			if(e.getMessage().equals("Email not exist") || e.getMessage().equals("User not exist") || e.getMessage().equals("Some projectIds or moduleIds were not found in the database") || e.getMessage().equals("One or more Modules do not belong to the assigned Projects")) {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} 
	}

//	Need to delete in reviewer table 
//	HttpStatus.NOT_FOUND need to change status for reviewer or editor with existing diagram
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/deleteUser/{userId}",method = RequestMethod.DELETE) 
	public ResponseEntity<Object> deleteUser(@PathVariable Long userId,@RequestHeader Map<String,String> headers) {
		log.debug("Request {}", userId);
		try {
			String headerUserId = HeaderUtil.getUserId(headers);
			BpmnUser deletedUser= null;
			if(userId == Integer.parseInt(headerUserId)){
				return new ResponseEntity<>("Current User cannot be deleted. You are attempting to delete your own account, which is not allowed.", HttpStatus.NOT_ACCEPTABLE);

			}
			//For viewer Role the diagramXMLID is null so the below implementation
			List<ReviewDiagramme> diagrammeByUserId = mapReviewRepository.getByAuthorUserId(userId.toString());
			
			
			deletedUser = bpmnUserService.deleteUserByRoleCheck(userId, diagrammeByUserId);
			

			if (deletedUser == null) {
				log.debug("Response {}","User deleted successfully");
				return new ResponseEntity<>("User deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","User not found");
				return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
	        if ("User not exist".equals(e.getMessage())) {
	            return new ResponseEntity<>("User not exist", HttpStatus.NOT_FOUND);
	        } else if ("User actively assigned to maps. Therefore, the user cannot be removed.".equals(e.getMessage())) {
	            return new ResponseEntity<>("User actively assigned to maps. Therefore, the user cannot be removed.", HttpStatus.NOT_FOUND);
	        } else if ("User actively assigned to specific maps. Therefore, the user cannot be removed.".equals(e.getMessage())) {
	            return new ResponseEntity<>("User actively assigned to specific maps. Therefore, the user cannot be removed.", HttpStatus.NOT_FOUND);
	        }else {
	            return new ResponseEntity<>("An error occurred during delete the user: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	        }
		}
	}


	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/generateResetPassword/request/{email}",method = RequestMethod.GET) 
	public ResponseEntity<String> requestReset(@PathVariable String email ,HttpServletRequest request) {
		log.debug("Request {}", email);
		try {
			bpmnUserService.generateResetToken(email , request);
			log.debug("Response {}","Reset link sent successfully");
			return ResponseEntity.ok("Reset link sent successfully");
		}
		catch(Exception e) {
			if(e.getMessage().equals("Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}
			else if(e.getMessage().equals("Error sending link")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Error sending code", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/verifyResetPassword", method = RequestMethod.GET) 
	public ResponseEntity<Object> verifyResetToken(@RequestParam String userEmail,@RequestParam String resetToken,HttpServletRequest request) {
		log.debug("Request {}", userEmail, resetToken);
		try {

			String response = bpmnUserService.verifyResetToken(userEmail, resetToken);
			log.debug("Response {}", response);
			return new ResponseEntity<>(response,HttpStatus.OK);

		} catch(Exception e) {
			if(e.getMessage().equals("An error occurred while verifying reset token:  Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}  else {
				log.error(e.getMessage());
				return new ResponseEntity<>("Reset code mismatched", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/public/users/confirmPassword", method = RequestMethod.POST) 
	public ResponseEntity<Object> confirmResetPassword(@RequestBody Map<String, String> requestPayload) {
		log.debug("Request {}", requestPayload);
		try {
			String email = requestPayload.get("userEmail");
			String newPassword = requestPayload.get("newPassword");
			String resetToken = requestPayload.get("resetToken");

			bpmnUserService.resetPassword(email, newPassword ,resetToken);
			log.debug("Response {}", "Password reset successful");
			return ResponseEntity.ok("Password reset successful");
		}
		catch(Exception e) {
			if(e.getMessage().equals("Invalid user")) {
				log.error(e.getMessage());
				return new ResponseEntity<>("Invalid user", HttpStatus.NOT_FOUND);
			}
			else {
				log.error(e.getMessage());
				return new ResponseEntity<>("Reset link expired while reset password", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/users/addRole",method = RequestMethod.POST) 
	public ResponseEntity<Object> addRole(@RequestBody Role role,@RequestHeader Map<String, String> headers) {
		log.debug("BpmnUserController::addRole::Request {}", role);
		try {
			String organization = HeaderUtil.getOrganization(headers);
			role.setOrganization(organization);
			Role createdRole = bpmnUserService.createRole(role);

			log.debug("BpmnUserController::addRole::Response {}", createdRole);
			return new ResponseEntity<>(createdRole, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("BpmnUserController::addRole::Exception {}", e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/getRole", method = RequestMethod.GET)
	public ResponseEntity<List<RoleResponseDTO>> getAllRoles(@RequestHeader Map<String, String> headers) {
		try {
			log.debug("BpmnUserController::getAllRoles::Request {}");
			String organization = HeaderUtil.getOrganization(headers);
			List<RoleResponseDTO> roles = bpmnUserService.getAllRolesByOrganization(organization);
			return new ResponseEntity<>(roles, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/deleteRole/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteRole(@PathVariable Long id) {
		log.debug("Request {}", id);
		try {
			Role deletedRole = bpmnUserService.deleteRole(id);
			if (deletedRole == null) {
				log.debug("Response {}","Role deleted successfully");
				return new ResponseEntity<>("Role deleted successfully", HttpStatus.NO_CONTENT);

			} else {
				log.debug("Response {}","User not found");
				return new ResponseEntity<>("Role not found with Role Id", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>("An error occurred during delete the Role: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")      
	@RequestMapping(value = "/users/editRole", method = RequestMethod.POST)
	public ResponseEntity<Object> editRole(@RequestBody Role role) {
		
		log.debug("BpmnUserController::editRole::Request {}", role);
		
		try {
		
		Map<String,Object> UpdatedRole = bpmnUserService.UpdateRole(role);
			log.debug("BpmnUserController::editRole::Response {}", UpdatedRole);
			return new ResponseEntity<>(UpdatedRole, HttpStatus.OK);
		} 
		catch (Exception e) {
			log.error("BpmnUserController::editRole::Exception {}", e.getMessage());
			return new ResponseEntity<>("Role Id not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@CrossOrigin(origins ="*",allowedHeaders = "*")
	@PostMapping("/public/users/changeTempPassword")
	public ResponseEntity<Object>chanageTemporaryPassword(@RequestBody Map<String,String> requestPayload){
		
		try {
			bpmnUserService.changeTemporaryPassword(requestPayload);
			
		}catch(Exception e) {
			return new ResponseEntity<>("Password change failed",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<>("Password changed sucessfully", HttpStatus.OK);
		
	}
	
	@CrossOrigin(origins ="*",allowedHeaders = "*")
	@PostMapping("/users/changeNewPassword")
	public ResponseEntity<Object>chanageNewPassword(@RequestBody Map<String,String> requestPayload){
		
		try {
		bpmnUserService.changeNewPassword(requestPayload);
			
		}catch(Exception e) {
			return new ResponseEntity<>("Please enter the current password correctly.",HttpStatus.NOT_ACCEPTABLE);
		}
		
		return new ResponseEntity<>("Password changed sucessfully", HttpStatus.OK);
		
	}
	
	 @GetMapping("/users/getProjectsAndModulesByUserId/{userId}")
    public ResponseEntity<?> getUserCustomersAndProjects(@PathVariable Long userId) {
        ResponseEntity<?> user = bpmnUserService.getUserCustomersAndProjects(userId);
        return ResponseEntity.ok(user);
    }
	 
	
	 @GetMapping("/users/specificUserDetails/{userId}")
	public ResponseEntity<Object> getUserDetails(@PathVariable Long userId){
		 try {
			 Map<String,String> response = bpmnUserService.findUserDetails(userId);
			 return new ResponseEntity<>(response, HttpStatus.OK);
		 }catch(Exception e){
			 
			 return new ResponseEntity<Object>(e.getMessage(), HttpStatus.NO_CONTENT);
		 }
		
		
	}
	 
	 
    

}





