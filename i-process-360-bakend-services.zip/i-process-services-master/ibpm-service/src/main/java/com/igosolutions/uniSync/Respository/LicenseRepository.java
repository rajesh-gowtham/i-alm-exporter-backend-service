package com.igosolutions.uniSync.Respository;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.igosolutions.uniSync.Modal.License;




public interface LicenseRepository extends JpaRepository<License,Long> {

	@Query("SELECT li FROM License li WHERE li.organizationName =:organizationName")
	License findbyName(@Param("organizationName") String organizationName);

	@Transactional
	@Modifying
	@Query("UPDATE License l SET l.admins = :admins, l.users = :users, l.status = :status, l.encryptedKey = :preEncryptedKey, l.finalEncryptedKey = :finalEncryptedKey WHERE l.organizationName = :organizationName")
	void updateByName(@Param("organizationName") String organizationName, @Param("admins") int admins, 
	                  @Param("users") int users, @Param("status") String status, 
	                  @Param("preEncryptedKey") String preEncryptedKey,
	                  @Param("finalEncryptedKey") String finalEncryptedKey);

	
 }
