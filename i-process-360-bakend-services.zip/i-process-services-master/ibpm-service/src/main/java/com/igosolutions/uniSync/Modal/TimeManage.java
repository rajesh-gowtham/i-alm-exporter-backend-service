package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="time_manage")
public class TimeManage {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name ="diagram_xml_id")
	private int diagramXmlId;
	@Column(name ="created_timestamp")
	private String createdTimeStamp;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public String getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	public void setCreatedTimeStamp(String createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	@Override
	public String toString() {
		return "TimeManage [id=" + id + ", diagramXmlId=" + diagramXmlId + ", createdTimeStamp=" + createdTimeStamp
				+ "]";
	}
	
	
	

}
