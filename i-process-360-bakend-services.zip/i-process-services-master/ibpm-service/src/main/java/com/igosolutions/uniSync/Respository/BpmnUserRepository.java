package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.BpmnUser;

@Repository
public interface BpmnUserRepository extends JpaRepository<BpmnUser, Long>{

	@Query("select s from BpmnUser s where s.email = :email")
	BpmnUser findByEmail(String email);
	
	BpmnUser findByResettoken(String resettoken);
	
	@Transactional
	@Query(value="SELECT b FROM BpmnUser b WHERE b.userid = :userid")
	public BpmnUser findByUserId(@Param("userid")Long userid);
	
	@Transactional
	@Modifying
	@Query("UPDATE BpmnUser b SET b.firstname = :firstname, b.lastname = :lastname, b.email = :email, b.role = :role, b.mobileno = :mobileno, b.imgname = :imgname, b.imgcontent = :imgcontent, b.organization = :organization WHERE b.userid = :userid")
	public void updateUser(@Param("userid") long userid, @Param("firstname") String firstname, @Param("lastname") String lastname, @Param("email") String email, @Param("role") String role, @Param("mobileno") String mobileno, @Param("imgname") String imgname, @Param("imgcontent") String imgcontent, @Param("organization") String organization);
	
	@Transactional
	// @Query(value = "SELECT new com.igosolutions.uniSync.Modal.BpmnUser(user.userid, user.firstname, user.lastname, user.email, user.role, user.mobileno, user.imgname, user.imgcontent, user.organization) FROM BpmnUser user ORDER BY user.firstname")
	@Query(value = "SELECT new com.igosolutions.uniSync.Modal.BpmnUser(user.userid, user.firstname, user.lastname, user.email, user.role, user.mobileno, user.imgname, user.imgcontent, user.organization) FROM BpmnUser user WHERE user.organization = :organization ORDER BY user.firstname")
	List<BpmnUser> getAllUsersWithoutPassword(@Param("organization") String organization);

    
	/*
	 * @Modifying
	 * 
	 * @Transactional
	 * 
	 * @Query("DELETE FROM BpmnUser u WHERE u.userid = :userid") void
	 * deleteBpmnUsersByUserId(Long userid);
	 */
	
    @Transactional
    @Modifying
    @Query("DELETE FROM BpmnUser u WHERE u.userid = :userid")
	void deleteByUserId(Long userid);

	@Transactional
    @Query("SELECT u FROM BpmnUser u WHERE u.role = :role AND u.organization = :organization")
    List<BpmnUser> getByRoleAndOrganization(@Param("role") String role, @Param("organization") String organization);

	@Transactional
    @Query("SELECT COUNT(u) FROM BpmnUser u WHERE u.organization = :organization")
    int countByOrganization(@Param("organization") String organization);

	@Transactional
    @Query("SELECT COUNT(u) FROM BpmnUser u WHERE u.organization = :organization AND u.role = 'Admin'")
    int countAdminsByOrganization(@Param("organization") String organization);
	
	@Transactional
	@Modifying
	@Query("UPDATE BpmnUser b SET b.isLogin = true WHERE b.userid = :userid")
	public void updateIsLogin(@Param("userid") long userid);
	
	@Transactional
    @Query("SELECT u FROM BpmnUser u WHERE u.role = :role AND u.organization = :organization AND u.isLogin = 'true'")
    List<BpmnUser> getByRoleAndOrganizationAndIsLogin(@Param("role") String role, @Param("organization") String organization);

	@Transactional
	@Modifying
	@Query("UPDATE BpmnUser b SET b.password = :updatePassword,b.isFirstLogin = :isFirstLoginFalse, isLogin = :isLogin WHERE b.userid = :userId")
	void updateTemporaryPassWord(@Param("userId") Long userId, @Param("updatePassword")String updatePassword,@Param("isFirstLoginFalse") boolean isFirstLoginFalse, @Param("isLogin") boolean isLogin);

	@Transactional
	@Modifying
	@Query("UPDATE BpmnUser b SET b.password = :updatePassword WHERE b.userid = :userId")
    void updateNewPassWord(@Param("userId") Long userId, @Param("updatePassword")String updatePassword);
	@Query("SELECT e.email FROM BpmnUser e WHERE e.organization=:organization AND e.role=:role")
	List<String> findByRoleAndOrgainzation(@Param("organization")String organization,@Param("role") String role);
	
	@Query("SELECT u.email FROM BpmnUser u JOIN u.projects p WHERE u.role = :role AND u.organization = :organization AND p.id = :projectId")
	List<String> findByRoleAndOrgainzation(@Param("organization")String organization,@Param("role") String role,@Param("projectId") Long id);

	@Query("SELECT e.email FROM BpmnUser e WHERE e.userid IN :users")
	List<String> findByUserId(@Param("users")List <Long> users);
	
	@Query("SELECT e.email FROM BpmnUser e WHERE e.userid =:userId")
	String findByAuthorUserId(@Param("userId") Long userId);  
	
	@Query("SELECT e FROM BpmnUser e WHERE e.email IN :emails")
	List<BpmnUser> findByEmail(@Param("emails") List<String> emails);
	@Transactional
	@Query("SELECT u FROM BpmnUser u WHERE u.role = :admin AND u.organization = :organization")
	List<BpmnUser> findAllByRoleAndOrganization(@Param("admin")String admin, @Param("organization")String organization);

	
	@Transactional
	@Query("SELECT e FROM BpmnUser e WHERE e.userid IN :userId")
	List<BpmnUser> authorAndPublished(@Param("userId")List<Long> userId);

    @Transactional
	@Query("SELECT u FROM BpmnUser u JOIN u.projects p WHERE u.role = :role AND u.organization = :organization AND p.id = :projectId")
	List<BpmnUser> getByRoleAndOrganizationAndProjectId(@Param("role") String role, @Param("organization") String organization, @Param("projectId") Long projectId);
    
    @Transactional
    @Query("SELECT o FROM BpmnUser o WHERE o.organization = :organization")
	List<BpmnUser> findByOrganization(@Param("organization")String organization);
    
   
	

}
