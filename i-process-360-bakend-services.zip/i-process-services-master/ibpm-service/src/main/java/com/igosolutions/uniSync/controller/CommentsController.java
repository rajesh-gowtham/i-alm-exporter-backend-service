package com.igosolutions.uniSync.controller;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.ReviewComments;
import com.igosolutions.uniSync.Modal.ReviewCommentsDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.CommentsRepository;
import com.igosolutions.uniSync.Service.CommentsService;
import com.igosolutions.uniSync.utils.CommentsMentionDto;
import com.igosolutions.uniSync.utils.GroupCommentsDto;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CommentsController {
	
	@Autowired
	CommentsService commentsService;
	
	
	@Autowired
	BpmnUserRepository bpmnUserRepository;
	
	@Autowired
	CommentsRepository commentsRepository;
	
	Logger log = LoggerFactory.getLogger(CommentsController.class);
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value ="/addComments/{diagramXmlId}/{currentDiagramId}" , method = RequestMethod.POST)
	public ResponseEntity<Object> addComments(@PathVariable int diagramXmlId,
			                                  @PathVariable String currentDiagramId,
			                                  @RequestBody List<ReviewComments> reviewComments ){
		try {
			log.info("Comment to be added with diagramXmlId was recived  :: ",diagramXmlId);
			log.info("Comment to be added   ::   ",reviewComments.get(0).getCommentMessage());
		     
			List<ReviewCommentsDTO> commentsResponse = commentsService.saveComments(diagramXmlId,currentDiagramId,reviewComments); 
			
			log.info("Comment added sucessfully with diagramXmlId  :: ",diagramXmlId);
			log.info("Added comments Sucessfully  :: ",commentsResponse.get(commentsResponse.size()-1).getCommentMessage());
			
			return new ResponseEntity<Object>(commentsResponse,HttpStatus.OK);
		
		}catch(Exception e) {
			return new ResponseEntity<Object>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
     }
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value ="/updateComments/{commentId}/{flagToggleActivity}" , method = RequestMethod.POST)
	public ResponseEntity<Object> addComments(@PathVariable Long commentId,
			                                  @PathVariable Boolean flagToggleActivity ){
		try {
			commentsService.updateComments(commentId,flagToggleActivity); 
			return new ResponseEntity<Object>("Updated successfully",HttpStatus.OK);
		
		}catch(Exception e) {
			return new ResponseEntity<Object>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
     }
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value ="/updateAllComments" , method = RequestMethod.POST)
    public ResponseEntity<Object> updateAllComments(@RequestBody List<ReviewCommentsDTO> reviewComments) {
        try {
        	//This method is used to update comments when re numbering activity box
        	commentsService.updateAllComments(reviewComments); 
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
			e.printStackTrace();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value ="/getComments/{diagramXmlId}" , method = RequestMethod.GET)
    public ResponseEntity<Object> getCommentsByDiagramXmlId(@PathVariable int diagramXmlId) {
        try {
            List<ReviewCommentsDTO> comments = commentsService.getCommentsByDiagramXmlId(diagramXmlId);
            return new ResponseEntity<>(comments, HttpStatus.OK);
        } catch (Exception e) {
			e.printStackTrace();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@RequestMapping(value ="/deleteComments/{commentId}" , method = RequestMethod.DELETE)
	public ResponseEntity<Object> deleteComments(@PathVariable Long commentId) {
		try {
			commentsService.deleteComments(commentId);
			return new ResponseEntity<>("Deleted successfully",HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@RequestMapping(value ="/deleteAllComments/{diagramXmlId}/{commentedUserId}" , method = RequestMethod.DELETE)
	public ResponseEntity<Object>deleteAllComments(@PathVariable Integer diagramXmlId,@PathVariable Long commentedUserId){
		
		try {
			
			commentsRepository.deleteByDiagramXmlIdAndUserId(diagramXmlId,commentedUserId);
			return new ResponseEntity<>("Deleted successfully",HttpStatus.OK);
			
		}catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@RequestMapping(value ="/editComments/{commentId}" , method = RequestMethod.PUT)
	public ResponseEntity<?> editComments(@PathVariable Long commentId,
			                                   @RequestBody ReviewComments reviewComments){
		try {
			return commentsService.editComments(commentId,reviewComments);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@RequestMapping(value ="/resequenceUpdates/{diagramXmlId}" , method = RequestMethod.POST)
	public ResponseEntity<?> resequenceUpdates(@RequestBody List<ReviewCommentsDTO> reviewComments, @PathVariable int diagramXmlId) {
		try {
			return commentsService.resequenceUpdates(reviewComments , diagramXmlId);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value ="/mention/Comments",method = RequestMethod.POST)
	public ResponseEntity<?>mentionComments(@RequestBody CommentsMentionDto commentsMentionDto){
		try {
			
		commentsService.sendMentionedComment(commentsMentionDto);
		return new ResponseEntity<>("Mail triggered succesfully",HttpStatus.OK);
			
		}catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	
	
	    @PostMapping(value = "/groupCommentsPdf")
	    public ResponseEntity<?> generateAndSendPdf(@RequestBody GroupCommentsDto commentsDto) throws Exception {
	        try {
	           ByteArrayOutputStream pdfOutput = commentsService.generatePdf(commentsDto.getEmailBody(),commentsDto.diagramName);
	            
	           System.out.println("sizeeeeeeeeeeeeeeeee"+pdfOutput.toByteArray().length);
	          
	           MultipartFile pdfMultipartFile = commentsService.convertByteArrayToMultipartFile(pdfOutput.toByteArray(), commentsDto.diagramName + ".pdf");
	           
	           BpmnUser bpmnUser = bpmnUserRepository.findByUserId(commentsDto.getSenderUserId());
	           
	           String userName = bpmnUser.getFirstname()+" "+bpmnUser.getLastname();
	           
	           commentsService.sendEmailWithPdf(commentsDto.getRecipients(), pdfMultipartFile,pdfMultipartFile.getOriginalFilename(),commentsDto.diagramName,userName);
	           
	           return ResponseEntity.status(HttpStatus.OK).body("Email sent successfully!");
	            
	        } catch (MessagingException e) {
	            e.printStackTrace();
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email.");
	        }catch(Exception e) {
	        	e.printStackTrace();
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email.");
	        	
	        }
	    }
	 	
}
