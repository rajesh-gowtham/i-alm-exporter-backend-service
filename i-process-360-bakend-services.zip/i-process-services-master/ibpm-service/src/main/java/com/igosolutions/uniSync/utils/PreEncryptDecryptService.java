package com.igosolutions.uniSync.utils;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Service;

@Service
public class PreEncryptDecryptService {

    private static final String ALGORITHM_NAME = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int SALT_LENGTH_BYTE = 16; 

    private static final String SECRET_KEY = "uetPoHJweBNh_PLwdYTVwmwq_urTJHfI"; 

    public String encrypt(String data) throws Exception {
        System.out.println("Encryption process started");

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        byte[] iv = new byte[IV_LENGTH_BYTE];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(iv);

        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);

        byte[] salt = new byte[SALT_LENGTH_BYTE];
        secureRandom.nextBytes(salt);
        SecretKeySpec secretKey = generateSecretKey(SECRET_KEY, salt, 3000, 256);

        cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmParameterSpec);
        byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        byte[] encryptedIVAndText = new byte[IV_LENGTH_BYTE + encryptedBytes.length];
        System.arraycopy(iv, 0, encryptedIVAndText, 0, IV_LENGTH_BYTE);
        System.arraycopy(encryptedBytes, 0, encryptedIVAndText, IV_LENGTH_BYTE, encryptedBytes.length);

        byte[] finalEncryptedData = new byte[salt.length + encryptedIVAndText.length];
        System.arraycopy(salt, 0, finalEncryptedData, 0, salt.length);
        System.arraycopy(encryptedIVAndText, 0, finalEncryptedData, salt.length, encryptedIVAndText.length);

        System.out.println("Encryption process completed");
        return Base64.getEncoder().encodeToString(finalEncryptedData);
    }

    public String decrypt(String encryptedData) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        byte[] encryptedIvTextBytes = Base64.getDecoder().decode(encryptedData);

        byte[] salt = new byte[SALT_LENGTH_BYTE];
        System.arraycopy(encryptedIvTextBytes, 0, salt, 0, salt.length);
        byte[] iv = new byte[IV_LENGTH_BYTE];
        System.arraycopy(encryptedIvTextBytes, salt.length, iv, 0, iv.length);

        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
        SecretKeySpec secretKey = generateSecretKey(SECRET_KEY, salt, 3000, 256);

        cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmParameterSpec);
        byte[] encryptedBytes = new byte[encryptedIvTextBytes.length - salt.length - IV_LENGTH_BYTE];
        System.arraycopy(encryptedIvTextBytes, salt.length + IV_LENGTH_BYTE, encryptedBytes, 0, encryptedBytes.length);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }

    private SecretKeySpec generateSecretKey(String secretKey, byte[] salt, int iterations, int keyLength) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt, iterations, keyLength);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), ALGORITHM_NAME);
    }

}
