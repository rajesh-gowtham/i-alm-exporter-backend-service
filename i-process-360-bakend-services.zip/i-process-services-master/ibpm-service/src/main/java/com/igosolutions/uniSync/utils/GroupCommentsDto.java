package com.igosolutions.uniSync.utils;

import java.util.List;

public class GroupCommentsDto {
	
	public List<Recipients> recipients;
	public Long senderUserId;
	public List<EmailBody> emailBody;
	public String diagramName;
	
	
	public List<Recipients> getRecipients() {
		return recipients;
	}
	public void setRecipients(List<Recipients> recipients) {
		this.recipients = recipients;
	}
	public Long getSenderUserId() {
		return senderUserId;
	}
	public void setSenderUserId(Long senderUserId) {
		this.senderUserId = senderUserId;
	}
	public List<EmailBody> getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(List<EmailBody> emailBody) {
		this.emailBody = emailBody;
	}
	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	@Override
	public String toString() {
		return "GroupCommentsDto [recipients=" + recipients + ", senderUserId=" + senderUserId + ", emailBody="
				+ emailBody + ", diagramName=" + diagramName + "]";
	}
	
	
}
