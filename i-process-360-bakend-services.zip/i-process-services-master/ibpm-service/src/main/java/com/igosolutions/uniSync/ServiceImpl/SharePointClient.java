package com.igosolutions.uniSync.ServiceImpl;
import java.io.IOException;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.exceptions.ClientAuthenticationException;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.igosolutions.uniSync.Respository.SharePointRepository;

public class SharePointClient {
	
	/*
	 * @Autowired private SharePointRepository sharePointRepository;
	 */

	Logger log = LoggerFactory.getLogger(SharePointClient.class);

	private String clientId;
	private String clientSecret;
	private String siteName;
	private String tenantId;

	public SharePointClient(String clientId, String clientSecret, String siteName, String tenantId) {
		this.clientId = clientId;
		this.clientSecret = clientSecret;
		this.siteName = siteName;
		this.tenantId = tenantId;
	}
//	private String siteId = "igosolutionschn.sharepoint.com,f0d7f7fd-6bd4-4757-ae20-06c4b0ed4506,254f80a3-b3e0-4276-9a88-2678bc272866";

	public String uploadFile(byte[] fileContent, String diagramXml_Id, String current_Xml_Id, String uploaded_File_Name) throws IOException, ClientAuthenticationException {


		log.info("UploadFile  {}",uploaded_File_Name);
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		
		String accessToken = getAccessToken();
        log.info("Retrieved access token {}",accessToken);

		String siteId = getSiteId(siteName,accessToken);
        log.info("Retrieved Site information {}",siteId);
		

		headers.set("Authorization", "Bearer " + accessToken);

		ByteArrayResource resource = new ByteArrayResource(fileContent) {
			@Override
			public String getFilename() {
				return uploaded_File_Name;
			}
		};

		HttpEntity<ByteArrayResource> requestEntity = new HttpEntity<>(resource, headers);


	    //String uploadUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/root:/IBPMN/" + uploaded_File_Name + ":/content?overwrite=true";
		String uploadUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/root:/IBPMN/"+diagramXml_Id+"/"+current_Xml_Id+"/"+ uploaded_File_Name + ":/content?overwrite=true";

		ResponseEntity<String> responseEntity = restTemplate.exchange(
				uploadUrl,
				HttpMethod.PUT,
				requestEntity,
				String.class);
		
		String documentId = getDocumentId(uploaded_File_Name, siteId, accessToken,diagramXml_Id,current_Xml_Id);
		log.info("Document Id  : "+documentId);

		if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
			return documentId; 
		} else { 
			throw new RuntimeException("Error uploading file to SharePoint"); 
		}
	}

	public byte[] getFile(String diagram_xml_id,String current_xml_id, String activity_id, String file_name) throws IOException, ClientAuthenticationException {

		log.info("Started getting file from the share point");
		String uploadedFileName = activity_id+"_"+file_name;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		String accessToken = getAccessToken();

		String siteId = getSiteId(siteName, accessToken);

		headers.set("Authorization", "Bearer " + accessToken);
		

	    String fileUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/root:/IBPMN/"+diagram_xml_id+"/"+current_xml_id+"/"+ uploadedFileName + ":/content";
	   
	    ResponseEntity<byte[]> responseEntity = restTemplate.exchange(
				fileUrl,
				HttpMethod.GET,
				new HttpEntity<>(headers),
				byte[].class);

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			
			log.info("Document reteievd successfully  {} ",uploadedFileName);
			return responseEntity.getBody(); 
		
		} else {
			throw new RuntimeException("Error retrieving file from SharePoint: " + uploadedFileName);
		}
	}
	public Object deleteDocument(SharePointRepository sharePointRepository, String documentId, Long id) {
		System.out.println("This is id in deleteDocument "+id);
		String accessToken = getAccessToken();
		log.info("Token : {}" ,accessToken);
		String siteId = getSiteId(siteName, accessToken);
		log.info("Site id  :  {}"+siteId);
		
		//String deleteUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/items/" + fileName;
  
		String deleteUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/items/" + documentId;
		System.out.println("deleted URLLLLLLLLLLLLLL"+deleteUrl);
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        System.out.println("");
		ResponseEntity<String> responseEntity = restTemplate.exchange(
				deleteUrl,
				HttpMethod.DELETE,
				requestEntity,
				String.class);

		if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {
			log.info("Document deleted sucsessfully in sharepoint{}  ",documentId);
			  System.out.println(id);
			 //sharePointRepository.deleteById(id);
			  System.out.println("Document idddddddddddddddd  "+documentId);
			  System.out.println("sharePointRepository     :"+sharePointRepository);
			  if(sharePointRepository != null) {
			    sharePointRepository.deleteBydocumentId(documentId);
			  }
		} else {
			throw new RuntimeException("Error deleting document from SharePoint: " + responseEntity.getBody());
		}
		return responseEntity;
	}



	private String getAccessToken() {

		log.info("Retrieving Access token in getAccessToken()");

		String tokenUrl = "https://login.microsoftonline.com/"+tenantId+"/oauth2/token"; 


		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
		requestBody.add("client_id", clientId);
		requestBody.add("client_secret", clientSecret);
		requestBody.add("grant_type", "client_credentials");
		requestBody.add("resource", "https://graph.microsoft.com/");

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(requestBody, headers);

		ParameterizedTypeReference<Map<String, Object>> responseType = new ParameterizedTypeReference<Map<String, Object>>() {};
		ResponseEntity<Map<String, Object>> response = restTemplate.exchange(tokenUrl, HttpMethod.POST, request, responseType);
		if (response.getStatusCode() == HttpStatus.OK) {
			Map<String, Object> responseBody = response.getBody();
			if (responseBody != null) {
				String accessToken = responseBody.get("access_token").toString();
				return accessToken;
			} else {
				throw new RuntimeException("Response body is null");
			}
		} else {
			throw new RuntimeException("Failed to obtain access token. Status code: " + response.getStatusCode());
		}
	}

	private String getSiteId(String siteName, String accessToken) {

		log.info("Retrieving site id by getSiteId()");

		String graphApiUrl = "https://graph.microsoft.com/v1.0/sites?search=" + siteName;

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<String> response = restTemplate.exchange(
				graphApiUrl,
				HttpMethod.GET,
				requestEntity,
				String.class);

		if (response.getStatusCode() == HttpStatus.OK) {
			String responseBody = response.getBody();
			System.out.println("Response body: " + responseBody);

			// Parse JSON response manually
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				JsonNode jsonNode = objectMapper.readTree(responseBody);
				JsonNode valueNode = jsonNode.get("value");
				if (valueNode != null && valueNode.isArray() && valueNode.size() > 0) {
					JsonNode siteNode = valueNode.get(0);
					return siteNode.get("id").asText();
				} else {
					throw new RuntimeException("No site found with the specified name: " + siteName);
				}
			} catch (IOException e) {
				throw new RuntimeException("Error parsing JSON response: " + e.getMessage());
			}
		} else {
			throw new RuntimeException("Failed to retrieve site information. Status code: " + response.getStatusCode());
		}


	}


	private String getDocumentId(String uploaded_File_Name, String siteId, String accessToken, String diagramXml_Id, String current_Xml_Id) {
		String graphApiUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/root:/IBPMN/" +diagramXml_Id+"/"+current_Xml_Id+"/"+ uploaded_File_Name;
		 
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<String> responseEntity = restTemplate.exchange(
				graphApiUrl,
				HttpMethod.GET,
				requestEntity,
				String.class);

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			try {
				ObjectMapper objectMapper = new ObjectMapper();
				JsonNode jsonNode = objectMapper.readTree(responseEntity.getBody());
				return jsonNode.get("id").asText();
			} catch (IOException e) {
				throw new RuntimeException("Error parsing JSON response: " + e.getMessage());
			}
		} else {
			throw new RuntimeException("Failed to retrieve document ID. Status code: " + responseEntity.getStatusCode());
		}
	}
	public Object deleteFolderByName(String folderName) {
		String accessToken = getAccessToken();
		log.info("Token: {}", accessToken);
	
		// Get siteId
		 String siteId = getSiteId(siteName, accessToken);
		log.info("Site id: {}", siteId);
	
		// Get folderId by folder name
		String folderId = getFolderIdByName(folderName, siteId, accessToken);
	
		if (folderId == null) {
			throw new RuntimeException("Folder not found in SharePoint: " + folderName);
		}

		System.out.println("folderId: " + folderId);
	
		String deleteUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/items/" + folderId;
		log.info("Delete URL: {}", deleteUrl);
	
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
	
		ResponseEntity<String> responseEntity = restTemplate.exchange(
				deleteUrl,
				HttpMethod.DELETE,
				requestEntity,
				String.class);
	
		if (responseEntity.getStatusCode() == HttpStatus.NO_CONTENT) {
			log.info("Folder deleted successfully in SharePoint: {}", folderName);
		} else {
			throw new RuntimeException("Error deleting folder from SharePoint: " + responseEntity.getBody());
		}
		return responseEntity;
	}
	
	private String getFolderIdByName(String folderName, String siteId, String accessToken) {
    RestTemplate restTemplate = new RestTemplate();
    HttpHeaders headers = new HttpHeaders();
    headers.set("Authorization", "Bearer " + accessToken);
    HttpEntity<String> requestEntity = new HttpEntity<>(headers);

    // Construct the URL to list items in the drive
    String listItemsUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/drive/root:/IBPMN:/children?filter=name eq '" + folderName + "'";

	// GET GET https://graph.microsoft.com/v1.0/sites/{site-id}/drive/root:/{path-to-folder}:/children?$filter=name eq '{folder-name}'

    ResponseEntity<String> responseEntity = restTemplate.exchange(
            listItemsUrl,
            HttpMethod.GET,
            requestEntity,
            String.class);

			System.out.println("Response Body " +responseEntity.getBody());

    if (responseEntity.getStatusCode() == HttpStatus.OK) {
        // Parse the response to extract folderId
        JsonObject responseObject = JsonParser.parseString(responseEntity.getBody()).getAsJsonObject();


        JsonArray items = responseObject.getAsJsonArray("value");

		log.info("JsonArray items: {}", items);
        if (items.size() > 0) {
            JsonObject folder = items.get(0).getAsJsonObject();
            return folder.get("id").getAsString();
        } else {
            return null; // Folder not found
        }
    } else {
        throw new RuntimeException("Error retrieving folder ID from SharePoint: " + responseEntity.getBody());
    }
}

	
}
