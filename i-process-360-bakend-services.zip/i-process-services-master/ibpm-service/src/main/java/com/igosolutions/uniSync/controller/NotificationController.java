package com.igosolutions.uniSync.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Notification;
import com.igosolutions.uniSync.Service.NotificationService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;
    
    @GetMapping("/unread/{diagramXmlId}/{userId}")
    public ResponseEntity<List<Notification>> getUnreadNotifications(@PathVariable Integer diagramXmlId,@PathVariable Long userId) {
        List<Notification> notifications = notificationService.getUnreadNotifications(diagramXmlId,userId);
        return ResponseEntity.ok(notifications);
    }

    @PutMapping("/markAsRead/{userId}")
    public ResponseEntity<?> markAsRead(@RequestBody List<Long> notificationIds,@PathVariable Long userId) {
        notificationService.markAsReadForUser(notificationIds, userId);
        return ResponseEntity.ok("Notification marked as read");
    }

}
