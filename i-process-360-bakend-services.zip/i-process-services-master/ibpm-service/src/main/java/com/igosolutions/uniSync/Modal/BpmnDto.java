package com.igosolutions.uniSync.Modal;


public class BpmnDto {
    private Long taskConnectionId;
    private String diagramName;
    private String diagramXmlId;
    private String languageCode;
    private String languageName;
    private String publishedBy;
    private String template;
    private String organization;
	private Double diagramVersion;
	private Long mapId;
	private String author;
	private String diagramLevel;
    private String project;
    private String bpmnXml;
    public Long getTaskConnectionId() {
        return taskConnectionId;
    }
    public void setTaskConnectionId(Long taskConnectionId) {
        this.taskConnectionId = taskConnectionId;
    }
    public String getDiagramName() {
        return diagramName;
    }
    public void setDiagramName(String diagramName) {
        this.diagramName = diagramName;
    }
    public String getDiagramXmlId() {
        return diagramXmlId;
    }
    public void setDiagramXmlId(String diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }
    public String getLanguageCode() {
        return languageCode;
    }
    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
    public String getLanguageName() {
        return languageName;
    }
    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }
    public String getPublishedBy() {
        return publishedBy;
    }
    public void setPublishedBy(String publishedBy) {
        this.publishedBy = publishedBy;
    }
    public String getTemplate() {
        return template;
    }
    public void setTemplate(String template) {
        this.template = template;
    }
    public String getOrganization() {
        return organization;
    }
    public void setOrganization(String organization) {
        this.organization = organization;
    }
    public Double getDiagramVersion() {
        return diagramVersion;
    }
    public void setDiagramVersion(Double diagramVersion) {
        this.diagramVersion = diagramVersion;
    }
    public Long getMapId() {
        return mapId;
    }
    public void setMapId(Long mapId) {
        this.mapId = mapId;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getDiagramLevel() {
        return diagramLevel;
    }
    public void setDiagramLevel(String diagramLevel) {
        this.diagramLevel = diagramLevel;
    }
    public String getProject() {
        return project;
    }
    public void setProject(String project) {
        this.project = project;
    }
    public String getBpmnXml() {
        return bpmnXml;
    }
    public void setBpmnXml(String bpmnXml) {
        this.bpmnXml = bpmnXml;
    }
    

    

}
