package com.igosolutions.uniSync.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.ReviewDiagrammeDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.MapAccessRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Service.BpmnMapReviewService;
import com.igosolutions.uniSync.utils.HeaderUtil;
import com.igosolutions.uniSync.utils.PublishRequestDto;
import com.igosolutions.uniSync.utils.ReviewDiagrammeResponse;
import com.igosolutions.uniSync.utils.SaveReviewerRequestDto;

@RestController
public class BpmnMapReviewController {

    @Autowired
	BpmnMapReviewService bpmnMapReviewService;

    @Autowired
	BpmnUserRepository bpmnUserRepository;

	@Autowired
	MapReviewRepository mapReviewRepository;
	
	@Autowired
	MapAccessRepository mapAccessRepository;

    Logger log = LoggerFactory.getLogger(BpmnMapReviewController.class);
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/review/saveReviewerData/{mapId}", method = RequestMethod.POST)
    public ResponseEntity<?> saveReviewerData(@RequestBody SaveReviewerRequestDto saveReviewerRequestDto, @PathVariable("mapId") Long mapId) {
        try {
           
            ReviewDiagrammeResponse savedData = bpmnMapReviewService.saveReviewerData(saveReviewerRequestDto);
			if (savedData.getErrorMessage() != null) {
				return new ResponseEntity<>(savedData.getErrorMessage(), HttpStatus.NOT_ACCEPTABLE);
			}
            return new ResponseEntity<>(savedData, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Error while processing data", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/users/getUsersByRoleName/{roleName}/{projectId}", method = RequestMethod.GET)
    public ResponseEntity<?> getReviewers(@RequestHeader Map<String, String> headers,@PathVariable("roleName") String roleName,@PathVariable Long projectId) 
    
    {
        String organization = HeaderUtil.getOrganization(headers);
        List<BpmnUser> bpmnUserList = bpmnUserRepository.getByRoleAndOrganizationAndProjectId(roleName, organization, projectId);

        List<Map<String, Object>> reviewerList = bpmnUserList.stream()
            .map(user -> {
                Map<String, Object> valueMap = new HashMap<>();
                valueMap.put("userName", user.getFirstname() + " " + user.getLastname());
                valueMap.put("userId", user.getUserid());
                valueMap.put("userEmail", user.getEmail());
                return valueMap;
            })
            .collect(Collectors.toList());

        return ResponseEntity.ok(reviewerList);
    }

	 
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnUserData/getBpmnDiagramByUserId", method = RequestMethod.GET)
    public ResponseEntity<?> getEditorData(@RequestHeader Map<String, String> headers){
		log.debug("headers {}", headers);
    	String userId = HeaderUtil.getUserId(headers);
    	List<ReviewDiagrammeResponse> responses = new ArrayList<ReviewDiagrammeResponse>();
    	try {
    	     responses = bpmnMapReviewService.getBpmnDiagrmByUserId(userId,headers);    	 
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	 return new ResponseEntity<>(responses, HttpStatus.OK);
					
    }
    
//    private Map<String, ReviewDiagrammeResponse.DiagramXmlIdInfo> processMapVersions(List<MapVersion> mapVersions) {
//        Map<String, ReviewDiagrammeResponse.DiagramXmlIdInfo> diagramXmlIdsMap = new HashMap<>();
//        Map<String, List<MapVersion>> groupedVersions = mapVersions.stream().collect(Collectors.groupingBy(MapVersion::getDiagramLevel));
//        groupedVersions.forEach((level, versions) -> {
//            if ("Draft".equalsIgnoreCase(level) || "Master".equalsIgnoreCase(level)) {
//                ReviewDiagrammeResponse.DiagramXmlIdInfo versionInfo = new ReviewDiagrammeResponse.DiagramXmlIdInfo();
//                versionInfo.setVersion((double) versions.size());
//                versionInfo.setDiagramXmlId(versions.get(0).getDiagramXmlId());
//                diagramXmlIdsMap.put(level, versionInfo);
//            } else if ("Archieves".equalsIgnoreCase(level)) {
//                versions.forEach(version -> {
//                    ReviewDiagrammeResponse.DiagramXmlIdInfo versionInfo = new ReviewDiagrammeResponse.DiagramXmlIdInfo();
//                    versionInfo.setVersion((version.getDiagramVersion()));
//                    versionInfo.setDiagramXmlId(version.getDiagramXmlId());
//                    diagramXmlIdsMap.put(level, versionInfo);
//                });
//            }
//        });
//        return diagramXmlIdsMap;
//    }
//
//    private List<ReviewDiagrammeResponse.MapAuthorizedUser> getAuthorizedUsers(Long diagramId) {
//        return mapAccessRepository.findByReviewDiagrammeId(diagramId).stream()
//            .map(MapAccess::getSpecificUser)
//            .map(userId -> bpmnUserRepository.findByUserId(userId.longValue()))
//            .filter(Objects::nonNull)
//            .map(user -> new ReviewDiagrammeResponse.MapAuthorizedUser(user.getUserid().intValue(), user.getEmail(), user.getFirstname() + " " + user.getLastname()))
//            .collect(Collectors.toList());
//    }
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getAllPublishedDiagrams",method = RequestMethod.GET) 
	public ResponseEntity<?> getAllPublishedDiagrams(@RequestHeader Map<String, String> headers) {
		try {
			String organization  = HeaderUtil.getOrganization(headers);
	        if (organization == null || organization.trim().isEmpty()) {
	            String errorMessage = "Organization parameter is missing or empty";
	            log.error(errorMessage);
	            return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	        }
	        
	        log.debug("Request received for organization: {}", organization);
            List<Map<String, Object>> reviewDiagramme = bpmnMapReviewService.getAllPublishedDiagrams(organization);

            if (reviewDiagramme == null) {
                String errorMessage = "No Published diagrams are available for organization: " + organization;
                log.warn(errorMessage);
                return new ResponseEntity<>(errorMessage, HttpStatus.NO_CONTENT);
            }

            log.debug("Response data: {}");
            return new ResponseEntity<>(reviewDiagramme, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/publishBpmDiagram/{mapId}",method = RequestMethod.POST) 
	public ResponseEntity<?> publishBpmDiagram(@RequestHeader Map<String, String> headers,@RequestBody PublishRequestDto publishDto,@PathVariable long mapId) {
		try {
			String organization = HeaderUtil.getOrganization(headers);
			bpmnMapReviewService.publishedDiagram(publishDto,organization);
            log.debug("Response data: {}");
            return new ResponseEntity<>( "Diagram published successfully", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
   	@RequestMapping(value = "/revokeToDraft/{mapId}/{diagramXmlId}",method = RequestMethod.POST) 
   	public ResponseEntity<?> revokeToDraft(@RequestHeader Map<String, String> headers,@PathVariable long mapId,@PathVariable int diagramXmlId, @RequestBody Map<String, String> requestPayload) {
   		try {
			  log.debug("Response data: {}");
			  log.debug(requestPayload.get("xmlData"));
   			  return bpmnMapReviewService.revokeToDraftDiagram(mapId, diagramXmlId, requestPayload.get("xmlData"));
   		} catch (Exception e) {
   			e.printStackTrace();
   			return new ResponseEntity<>("Error while revoke map",HttpStatus.INTERNAL_SERVER_ERROR);
   		}
   		
   	}
    
    @CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "bpmnDiagram/deleteMapDiagrams",method = RequestMethod.DELETE) 
	public ResponseEntity<?> deleteMapDiagrams(@RequestHeader Map<String, String> headers,@RequestBody List<ReviewDiagrammeDTO> requestPayload) {
		String userId = HeaderUtil.getUserId(headers);
		try {
			bpmnMapReviewService.deleteMapDiagrams(Long.parseLong(userId), requestPayload);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		return null;															
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
   	@RequestMapping(value = "/deleteUnlockedDraft/{mapId}",method = RequestMethod.DELETE) 
   	public ResponseEntity<?> deleteUnlockedDraft(@PathVariable long mapId) {
   		try {
			  log.debug("Response data: {}");
   			  return bpmnMapReviewService.deleteUnlockedDraft(mapId);
   		} catch (Exception e) {
   			e.printStackTrace();
   			return new ResponseEntity<>("Error while deleting draft map",HttpStatus.INTERNAL_SERVER_ERROR);
   		}
   		
   	}
}