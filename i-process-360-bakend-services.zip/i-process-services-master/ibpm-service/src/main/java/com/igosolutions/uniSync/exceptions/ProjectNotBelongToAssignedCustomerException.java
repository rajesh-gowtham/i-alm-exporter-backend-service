package com.igosolutions.uniSync.exceptions;

public class ProjectNotBelongToAssignedCustomerException extends RuntimeException {
    public ProjectNotBelongToAssignedCustomerException(String message) {
        super(message);
    }
}
