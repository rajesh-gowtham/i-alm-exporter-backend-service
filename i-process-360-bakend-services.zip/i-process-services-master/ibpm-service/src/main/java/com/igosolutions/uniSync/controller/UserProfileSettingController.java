package com.igosolutions.uniSync.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.igosolutions.uniSync.Modal.Users;
import com.igosolutions.uniSync.Service.UserServices;

@RestController
public class UserProfileSettingController {

	@Autowired
	private UserServices userprofileservice;

	// Load UserNames
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getUsernames", method = RequestMethod.GET)
	public List<Users> getAllUsers() throws IOException {
		List<Users> users = null;
		try {
			users = userprofileservice.getAllUsers();
			LogFile.LogWrite("UserProfileSetting Controller - the getUsernames modal data is " + users);

		}catch(Exception ex) {
			LogFile.LogWrite("UserProfileSetting Controller - Error 1212 getUsernames modal data is:  " +ex.getMessage());	
		}

		return users;

	}




	//Save New User Deatils
	@SuppressWarnings("rawtypes")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/updateuserdetails", method = RequestMethod.POST)
	public ResponseEntity Updateuserdetails(@RequestParam(name = "username", required = false) String username
			,@RequestParam(name = "email", required = false) String email,@RequestParam(name = "password", required = false) String password )throws IOException {
		try {

			LogFile.LogWrite("UserProfileSetting Controller - the update modal data is " + username);				 
			//String EncryptPassword=EncryptDecrypt.encrypt(password.trim());
			LogFile.LogWrite("UserProfileSetting Controller - the EncryptPassword  data is " + password);	
			userprofileservice.updateuserdetails(username.trim(),password,email);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			LogFile.LogWrite("UserProfileSetting Controller -  ERROR 3001  internal Server Error :"+e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	//Save New User Deatils
	@SuppressWarnings("rawtypes")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/SaveUserDetails", method = RequestMethod.POST)
	public ResponseEntity savenewUser(@RequestParam(name = "username", required = false) String username,
			@RequestParam(name = "password", required = false) String password,@RequestParam(name = "email", required = false) String email,@RequestParam(name = "mekey", required = false) String meKEY) throws IOException {
		try {

			LogFile.LogWrite("UserProfileSetting Controller - the saveNewUser modal data is " + email);				 
			//String EncryptPassword=EncryptDecrypt.encrypt(password.trim());
			LogFile.LogWrite("UserProfileSetting Controller - the EncryptPassword  data is " + password);	
			userprofileservice.savenewUser(username.trim(),password,email,meKEY);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			LogFile.LogWrite("UserProfileSetting Controller -  ERROR 3001  internal Server Error :"+e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}




	// React Auth Start

	public String GetMeKey() throws IOException {	
		String MEKEYIs=null;
		try {	
			//String EncryptPassword=EncryptDecrypt.encrypt("igo@12345");
			Users user=userprofileservice.GetMeKey("administrator");
			if(user!=null) {
				MEKEYIs=user.getMe_Key();	
				LogFile.LogWrite("UserProfileSetting Controller - #3019 MEKEYIs: "+MEKEYIs);
				return MEKEYIs;
			}else {
				LogFile.LogWrite("UserProfileSetting Controller - #3019  KEY NOT FOUND administator user: "+user);
				return null;
			}		

		} catch (Exception e) {
			LogFile.LogWrite("UserProfileSetting Controller - Error # 3020 MEKEYIs : " + e.getMessage());

		}
		return MEKEYIs;
	}	


	// Delete User
	@SuppressWarnings("rawtypes")
	//React Auth Start
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/deleteuser", method = RequestMethod.DELETE)
	public ResponseEntity  deleteUser(
			@RequestParam(name = "username", required = false) String username) throws IOException{	

		try {
			LogFile.LogWrite("UserProfileSetting Controller - #3019 Real deleteUser:"+username.trim());
			userprofileservice.deleteUser(username.trim());			
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			LogFile.LogWrite("UserProfileSetting Controller - Error # 3020 deleteUser : " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	//Delete user End


	// React Auth Start
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/reactlogin", method = RequestMethod.GET)
	public String  ReactLogins(
			@RequestParam(name = "username", required = false) String username,
			@RequestParam(name = "password", required = false) String password) throws IOException {	

		try {
			LogFile.LogWrite("UserProfileSetting Controller - #3019 Real Password:"+password.trim());

			//	String EncryptPassword=EncryptDecrypt.encrypt(password.trim());

			Users user=userprofileservice.logins(username.trim(), password);			
			LogFile.LogWrite("UserProfileSetting Controller - #3019 PasswordEncript: "+password);
			LogFile.LogWrite("UserProfileSetting Controller - #3020 Select reactlogin : " + password + " status :" + password +"user is "+ user);		

			if(user!=null) {
				LogFile.LogWrite("UserProfileSetting Controller - #3019 User Available: ");
				return "success";
			}else {
				LogFile.LogWrite("UserProfileSetting Controller - #3019 User NOT  Available: ");
				return "Failure";
			}
		} catch (Exception e) {
			LogFile.LogWrite("UserProfileSetting Controller - Error # 3020 reactlogin : " + e.getMessage());
			return "Failure";

		}
	}	
	// React Auth End
}
