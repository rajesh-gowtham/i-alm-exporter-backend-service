package com.igosolutions.uniSync.audit;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;


import java.time.LocalDateTime;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.igosolutions.uniSync.Modal.AssignedUser;
import com.igosolutions.uniSync.Modal.AuditTrail;
import com.igosolutions.uniSync.Modal.AuditTrailDetail;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.MapAccess;
import com.igosolutions.uniSync.Modal.MapVersion;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Respository.AuditTrailRepository;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.MapVersionRepository;
import com.igosolutions.uniSync.constants.UtilsConstants.AuditConstants;
import com.igosolutions.uniSync.utils.LoggedInUserUtils;

@Component
public class AuditEventListener {

    @Autowired
    private AuditTrailRepository auditTrailRepository;
    
    @Autowired
    private BpmnUserRepository bpmnUserRepository;
    
    @Autowired
    private MapReviewRepository mapReviewRepository;
    
    @Autowired
    private MapVersionRepository mapVersionRepository;

    @Autowired
    private EntityManager entityManager;
    private static final Logger logger = LoggerFactory.getLogger(AuditEventListener.class);

    @Transactional
    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void handleBeforeCommitAuditEvent(AuditEvent auditEvent) {
        logger.info("Inside method handleBeforeCommitAuditEvent");
        Object entity = auditEvent.getEntity();
        String modificationType = auditEvent.getModificationType();
        if(auditEvent.getModificationType().equals(AuditConstants.INSERT)) {
            if (entity instanceof ReviewDiagramme) {
                auditNewMap((ReviewDiagramme) entity, modificationType);
            }
            if (entity instanceof BpmnUser) {
                auditNewUser((BpmnUser) entity, modificationType);
            }
        }
        else if(auditEvent.getModificationType().equals(AuditConstants.UPDATE)){
            if (entity instanceof BpmnUser) {
                auditUpdateUser((BpmnUser) entity, modificationType);
            }
            if (entity instanceof ReviewDiagramme) {
                auditUpdateMap((ReviewDiagramme) entity, modificationType);
            }

        }
        else{
            if (entity instanceof ReviewDiagramme) {
                auditDeleteMap((ReviewDiagramme) entity, modificationType);
            }
        }


    }

	private void auditNewMap(ReviewDiagramme newMap, String modificationType) {
        logger.info("Auditing new ReviewMap: {}", modificationType);

        // Perform auditing logic, such as logging the creation event or storing audit
        // details
        compareAndAuditMapFields(null, newMap, "ReviewMap", modificationType);
    }

    @Transactional
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleAfterCommitAuditEvent(AuditEvent auditEvent) {
        logger.info("Inside method handleAfterCommitAuditEvent");
        Object entity = auditEvent.getEntity();
        String modificationType = auditEvent.getModificationType();
        
        if(auditEvent.getModificationType().equals(AuditConstants.DELETE) ) {
            if (entity instanceof BpmnUser) {
                logger.info("Inside method handleAfterCommitAuditEvent Delete BpmnUser");
                auditDeleteUser((BpmnUser) entity, modificationType);
            }
            
        }
        else if(auditEvent.getModificationType().equals(AuditConstants.UPDATE)){
           
        	if (entity instanceof ReviewDiagramme) {
                logger.info("Inside method handleAfterCommitAuditEvent Update ReviewMap ");
                auditUpdateMapAfterCommit((ReviewDiagramme) entity, modificationType);
                }
            }
            
        }
    
    
        private void auditUpdateMapAfterCommit(ReviewDiagramme newMap, String modificationType) {
            logger.info("Auditing Update ReviewMap: {}", modificationType);
        // ReviewDiagramme oldMap = AuditContextHolder.getOldMap();
        AuditReader auditReader = AuditReaderFactory.get(entityManager);
        List<Number> revisions = auditReader.getRevisions(ReviewDiagramme.class, newMap.getId())
                                      .stream().map(Number::intValue) // Convert Number to Integer
                                      .sorted(Comparator.reverseOrder())
                                      .collect(Collectors.toList());
        if (revisions.size() > 0) {
            Number lastButOneRevision = revisions.get(1);
            ReviewDiagramme oldMap = auditReader.find(ReviewDiagramme.class, newMap.getId(), lastButOneRevision);
            compareAndAuditMapFields(oldMap, newMap, "ReviewMap", modificationType);
        }else {
            logger.warn("No previous version found for entity with ID: {}", newMap.getId());
            compareAndAuditMapFields(null, newMap, "ReviewMap", modificationType);
        }
    }

        
    
        private void auditDeleteUser(BpmnUser newUser, String modificationType) {
        logger.info("Auditing Delete BpmnUser: {}", modificationType);
        AuditReader auditReader = AuditReaderFactory.get(entityManager);
        List<Number> revisions = auditReader.getRevisions(BpmnUser.class, newUser.getUserid())
                                      .stream().map(Number::intValue) // Convert Number to Integer
                                      .sorted(Comparator.reverseOrder())
                                      .collect(Collectors.toList());
        if (revisions.size() > 0) {
            Number lastButOneRevision = revisions.get(0);
            BpmnUser oldUser = auditReader.find(BpmnUser.class, newUser.getUserid(), lastButOneRevision);
            compareAndAuditBpmnUserFields(oldUser, null, "BpmnUser", modificationType);
        }
    }

    private void auditUpdateUser(BpmnUser newUser, String modificationType) {
        logger.info("Auditing Update BpmnUser: {}", modificationType);
        AuditReader auditReader = AuditReaderFactory.get(entityManager);
        List<Number> revisions = auditReader.getRevisions(BpmnUser.class, newUser.getUserid())
                                      .stream().map(Number::intValue) // Convert Number to Integer
                                      .sorted(Comparator.reverseOrder())
                                      .collect(Collectors.toList());
        if (revisions.size() > 0) {
            Number lastButOneRevision = revisions.get(0);
            BpmnUser oldUser = auditReader.find(BpmnUser.class, newUser.getUserid(), lastButOneRevision);
            compareAndAuditBpmnUserFields(oldUser, newUser, "BpmnUser", modificationType);
        }else {
            logger.warn("No previous version found for entity with ID: {}", newUser.getUserid());
            compareAndAuditBpmnUserFields(null, newUser, "BpmnUser", modificationType);
        }
    }

    private void auditUpdateMap(ReviewDiagramme newMap, String modificationType) {
        logger.info("Auditing Update ReviewMap: {}", modificationType);
        // ReviewDiagramme oldMap = AuditContextHolder.getOldMap();
        AuditReader auditReader = AuditReaderFactory.get(entityManager);
        List<Number> revisions = auditReader.getRevisions(ReviewDiagramme.class, newMap.getId())
                                      .stream().map(Number::intValue) // Convert Number to Integer
                                      .sorted(Comparator.reverseOrder())
                                      .collect(Collectors.toList());
        if (revisions.size() > 0) {
        	System.out.println("Inside if");
            Number lastButOneRevision = revisions.get(0);
            ReviewDiagramme oldMap = auditReader.find(ReviewDiagramme.class, newMap.getId(), lastButOneRevision);
            compareAndAuditMapFields(oldMap, newMap, "ReviewMap", modificationType);
        }else {
        	System.out.println("Inside else");
            logger.warn("No previous version found for entity with ID: {}", newMap.getId());
            compareAndAuditMapFields(null, newMap, "ReviewMap", modificationType);
        }
    }

    private void auditNewUser(BpmnUser newUser, String modificationType) {
        logger.info("Auditing NewBpmnUser: {} - {}", modificationType, newUser.getFirstname() + " " + newUser.getLastname());
        compareAndAuditBpmnUserFields(null, newUser, "BpmnUser", modificationType);
    }

    private void auditDeleteMap(ReviewDiagramme newMap, String modificationType) {
        logger.info("Auditing Delete ReviewMap: {}", modificationType);
        logger.info("New Map: {}", newMap.getId());
        // ReviewDiagramme oldMap = AuditContextHolder.getOldMap();
        AuditReader auditReader = AuditReaderFactory.get(entityManager);
        List<Number> lastRevisions = auditReader.getRevisions(ReviewDiagramme.class, newMap.getId())
                                      .stream().map(Number::intValue) // Convert Number to Integer
                                      .sorted(Comparator.reverseOrder())
                                      .collect(Collectors.toList());
        if (lastRevisions.size() > 0) {
        Number lastButOneRevision = lastRevisions.get(0);
        ReviewDiagramme oldMap = auditReader.find(ReviewDiagramme.class, newMap.getId(), lastButOneRevision);
        compareAndAuditMapFields(oldMap, null, "ReviewMap", modificationType);
    } else {
        logger.warn("No previous version found for entity with ID: {}", newMap.getId());
    
    }
        
    }

    @Transactional
    private void compareAndAuditMapFields(ReviewDiagramme oldMap, ReviewDiagramme newMap, String entityName,
            String modificationType) {
        try {
            // If both maps are null, there's nothing to compare or audit.
            if (oldMap == null && newMap == null) {
                return;
            }

            // Get organization safely from newMap if it's not null
            String organization = (newMap != null) ? newMap.getOrganization()
                    : (oldMap != null) ? oldMap.getOrganization()
                            : null;

            AuditTrail audit = new AuditTrail();
            audit.setEntityName(entityName);
            audit.setEntityId((newMap != null) ? newMap.getId().toString()
                    : (oldMap != null) ? oldMap.getId().toString() : "N/A");
            audit.setChangedBy(LoggedInUserUtils.getLoggedInUsername());
            audit.setChangedAt(LocalDateTime.now());
            audit.setModificationType(modificationType);
            audit.setOrganization(organization);

            // Perform null-safe field comparisons
            checkFieldChange("author", (oldMap != null) ? oldMap.getAuthor() : null,
                    (newMap != null) ? newMap.getAuthor() : null, audit);
            checkFieldChange("status", (oldMap != null) ? oldMap.getStatus() : null,
                    (newMap != null) ? newMap.getStatus() : null, audit);
            checkFieldChange("diagramName", (oldMap != null) ? oldMap.getDiagramName() : null,
                    (newMap != null) ? newMap.getDiagramName() : null, audit);
            checkFieldChange("mapPrivacyType", (oldMap != null) ? oldMap.getMapPrivacyType() : null,
                    (newMap != null) ? newMap.getMapPrivacyType() : null, audit);
            checkFieldChange("storageType", (oldMap != null) ? oldMap.getStorageType() : null,
                    (newMap != null) ? newMap.getStorageType() : null, audit);
            checkFieldChange("project", (oldMap != null) ? oldMap.getProject().getProjectName() : null,
                    (newMap != null) ? newMap.getProject().getProjectName() : null, audit);
            checkFieldChange("languageName", (oldMap != null) ? oldMap.getLanguageName() : null,
                    (newMap != null) ? newMap.getLanguageName() : null, audit);
                      
           // MapVersion mapVersion = mapVersionRepository.findDiagramXmlId();

            compareAndAuditCollection("mapVersions", (oldMap != null) ? oldMap.getMapVersions() : null,
                    (newMap != null) ? newMap.getMapVersions() : null, audit);
            
            // compareAndAuditCollection("mapAccess", oldMap != null ? oldMap.getMapAccess()
            // : null, newMap != null ? newMap.getMapAccess() : null, audit);
            compareAndAuditCollection("assignedUsers", (oldMap != null) ? oldMap.getAssignedUsers() : null,
                    (newMap != null) ? newMap.getAssignedUsers() : null, audit);
            // Save the audit if there are any changes
            if (!audit.getDetails().isEmpty()) {
                auditTrailRepository.save(audit);  
                auditTrailRepository.flush();
                }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Transactional
    private void compareAndAuditBpmnUserFields(BpmnUser oldUser, BpmnUser newUser, String entityName, String modificationType) {
        // If both users are null, there's nothing to compare or audit
        if (oldUser == null && newUser == null) {
            return;
        }

        // Get organization safely from newUser, fallback to oldUser if newUser is null
        String organization = (newUser != null) ? newUser.getOrganization() 
                            : (oldUser != null) ? oldUser.getOrganization() 
                            : null;

        // Create a single AuditTrail entity
        AuditTrail audit = new AuditTrail();
        audit.setEntityName(entityName);
        audit.setEntityId((newUser != null) ? newUser.getUserid().toString() : (oldUser != null) ? oldUser.getUserid().toString() : "N/A");
        
        List<BpmnUser> bpmnUsers = bpmnUserRepository.findByOrganization(organization);
        
        if(bpmnUsers.size() ==1) {
        	
        	audit.setChangedBy(bpmnUsers.get(0).getFirstname()+" "+bpmnUsers.get(0).getLastname());
        	
        }
        else {
        
        	audit.setChangedBy(LoggedInUserUtils.getLoggedInUsername()); // Fetch current user
        }
        audit.setChangedAt(LocalDateTime.now());
        audit.setModificationType(modificationType);
        audit.setOrganization(organization);

        // Perform null-safe field comparisons
        checkFieldChange("firstname", (oldUser != null) ? oldUser.getFirstname() : null, 
                                (newUser != null) ? newUser.getFirstname() : null, audit);
        checkFieldChange("lastname", (oldUser != null) ? oldUser.getLastname() : null, 
                                (newUser != null) ? newUser.getLastname() : null, audit);
        checkFieldChange("email", (oldUser != null) ? oldUser.getEmail() : null, 
                            (newUser != null) ? newUser.getEmail() : null, audit);
        checkFieldChange("role", (oldUser != null) ? oldUser.getRole() : null, 
                            (newUser != null) ? newUser.getRole() : null, audit);
        checkFieldChange("mobileno", (oldUser != null) ? oldUser.getMobileno() : null, 
                                (newUser != null) ? newUser.getMobileno() : null, audit);
        // checkFieldChange("password", (oldUser != null) ? oldUser.getPassword() : null, 
        //                         (newUser != null) ? newUser.getPassword() : null, audit);
        checkFieldChange("organization", (oldUser != null) ? oldUser.getOrganization() : null, 
                                    (newUser != null) ? newUser.getOrganization() : null, audit);
        checkFieldChange("imgname", (oldUser != null) ? oldUser.getImgname() : null, 
                                (newUser != null) ? newUser.getImgname() : null, audit);
        if(!modificationType.equals(AuditConstants.UPDATE))
            compareAndAuditCollection("customers", oldUser != null ? oldUser.getCustomers() : null,newUser != null ? newUser.getCustomers() : null, audit);
        compareAndAuditCollection("projects", oldUser != null ? oldUser.getProjects() : null,newUser != null ? newUser.getProjects() : null, audit);                         

        // Save the audit with all the details at once
        if (!audit.getDetails().isEmpty()) {
            auditTrailRepository.save(audit);
            auditTrailRepository.flush();
        }
    }

    
    private <T> void compareAndAuditCollection(String fieldName, List<T> oldList, List<T> newList, AuditTrail audit) {
        if (oldList == null) oldList = new ArrayList<>();
        if (newList == null) newList = new ArrayList<>();
    
        StringBuilder addedItems = new StringBuilder();
        StringBuilder removedItems = new StringBuilder();
        StringBuilder modifiedItems = new StringBuilder();
        StringBuilder oldValues = new StringBuilder();
        StringBuilder newValues = new StringBuilder();
        
        Set<String> uniqueOldValues = new HashSet<>(); // Set to store unique old values
        Set<String> uniqueNewValues = new HashSet<>(); // Set to store unique new values
    
        // Detect removed items (present in oldList but not in newList)
            List<T> removed = new ArrayList<>(oldList);
            removed.removeAll(newList);
            for (T item : removed) {
                String oldValueStr = itemToString(item);
                if (!uniqueOldValues.contains(oldValueStr)) {
                    uniqueOldValues.add(oldValueStr);
                    if (removedItems.length() > 0) removedItems.append(", ");
                                                      
                    removedItems.append(oldValueStr);
    
                    // Append removed items to oldValues
                    if (oldValues.length() > 0) oldValues.append(", ");
                                                   
                    oldValues.append(oldValueStr);
                }
            }
    
            // Detect added items (present in newList but not in oldList)
            List<T> added = new ArrayList<>(newList);
            added.removeAll(oldList);
            for (T item : added) {
                String newValueStr = itemToString(item);
                if (!uniqueNewValues.contains(newValueStr)) {
                    uniqueNewValues.add(newValueStr);
                    if (addedItems.length() > 0) addedItems.append(", ");
                                                    
                    addedItems.append(newValueStr);
    
                    // Append added items to newValues
                    if (newValues.length() > 0) newValues.append(", ");
                                                   
                    newValues.append(newValueStr);
                     
                }
            }
        
    
        // Detect modified items (comparing old and new values)
        for (T oldItem : oldList) {
            for (T newItem : newList) {
                if (oldItem.equals(newItem)) {
                    continue; // Skip if items are the same
                }
                                                                                   
                // Add unique old values
                String oldValueStr = itemToString(oldItem);
                String newValueStr = itemToString(newItem);
                                                             
                // If oldValue and newValue are different, mark as modified
                if (!oldValueStr.equals(newValueStr)) {
                    if (modifiedItems.length() > 0) modifiedItems.append(", ");
                    modifiedItems.append("Old: ").append(oldValueStr).append(" -> New: ").append(newValueStr);
    
                    // Add old value if it's unique
                    if (!uniqueOldValues.contains(oldValueStr)) {
                        uniqueOldValues.add(oldValueStr);
                        if (oldValues.length() > 0) oldValues.append(", ");
                        oldValues.append(oldValueStr);
                                                          
                         
                    }
    
                    // Add new value if it's unique
                    if (!uniqueNewValues.contains(newValueStr)) {
                        uniqueNewValues.add(newValueStr);
                        if (newValues.length() > 0) newValues.append(", ");
                        newValues.append(newValueStr);
                    }
                }
            }
        }
    
        // Only add details if there are actual changes
        if (addedItems.length() > 0 || removedItems.length() > 0 || modifiedItems.length() > 0) {
            AuditTrailDetail detail = new AuditTrailDetail();
            detail.setFieldName(fieldName);
    
            // Set old and new values in a single record
            if (!oldValues.toString().equals(newValues.toString())) {
                detail.setOldValue(oldValues.length() > 0 ? oldValues.toString() : null);
                detail.setNewValue(newValues.length() > 0 ? newValues.toString() : null);

                // Add the detail to the audit
                audit.addDetail(detail);
            }
                 
        }
    }

    private void checkFieldChange(String fieldName, Object oldValue, Object newValue, AuditTrail audit) {
        // logger.info("Field {} changed for {} - {}: Old: {}, New: {}", fieldName, audit.getEntityName(), audit.getEntityId(), oldValue, newValue);
        if ((oldValue != null && !oldValue.equals(newValue)) || (oldValue == null && newValue != null)
                || audit.getModificationType().equals(AuditConstants.INSERT)) {
            // Create AuditTrailDetail for each field change
        	System.out.println("Comming inside auditTrail deatils to add");
        	
            AuditTrailDetail detail = new AuditTrailDetail();
            detail.setFieldName(fieldName);
            detail.setOldValue(oldValue != null ? oldValue.toString() : null);
            detail.setNewValue(newValue != null ? newValue.toString() : null);

            // Add the detail to the audit
            audit.addDetail(detail);
        }
    }
        
    private <T> String itemToString(T item) {
        if (item instanceof Customer) {
            Customer customer = (Customer) item;
            return "Customer{name=" + customer.getCustomerName() + "}";
        } else if (item instanceof Project) {
            Project project = (Project) item;
            return "Project{name=" + project.getProjectName() + "}";
        } else if (item instanceof MapVersion) {
            MapVersion mapVersion = (MapVersion) item;
            return "MapVersion{version=" + mapVersion.getDiagramVersion() + "}";
        } else if (item instanceof MapAccess) {
            MapAccess mapAccess = (MapAccess) item;
            return "MapAccess{user=" + mapAccess.getSpecificUser() + "}";
        } else if (item instanceof AssignedUser) {
            AssignedUser assignedUser = (AssignedUser) item;
            return "AssignedUser{user=" + assignedUser.getAssignedUser() + "}";
        }

        return item != null ? item.toString() : "null";
    }

}