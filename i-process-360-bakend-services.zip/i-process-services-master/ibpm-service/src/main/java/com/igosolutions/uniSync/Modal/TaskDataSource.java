package com.igosolutions.uniSync.Modal;

public class TaskDataSource {
	private String   taskid;
	private String datasourcenametype;
	private String datasourcename;
	
	
	public String gettaskid() {
		return taskid;
	} 
	
	public void settaskid(String taskid) {
		this.taskid = taskid;
	}
	
	public String getdatasourcenametype() {
		return datasourcenametype;
	} 
	
	public void setdatasourcenametype(String datasourcenametype_) {
		this.datasourcenametype = datasourcenametype_;
	}
	
	public String getdatasourcename() {
		return datasourcename;
	} 
	
	public void setdatasourcename(String datasourcename_) {
		this.datasourcename = datasourcename_;
	}
}
