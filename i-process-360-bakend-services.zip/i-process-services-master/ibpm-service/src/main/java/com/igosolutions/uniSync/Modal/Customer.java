package com.igosolutions.uniSync.Modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Audited
public class Customer {

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String customerName;
    
    @OneToMany(cascade = CascadeType.ALL , orphanRemoval = true)
    @JoinColumn(name = "customer_id")
    @JsonManagedReference
    private List<Project> projects = new ArrayList<>();

    @ManyToMany(mappedBy = "customers")
    @JsonBackReference
    private List<BpmnUser> bpmnUsers;
    @Column(name="organization")
    private String organization;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public List<BpmnUser> getBpmnUsers() {
        return bpmnUsers;
    }

    public void setBpmnUsers(List<BpmnUser> bpmnUsers) {
        this.bpmnUsers = bpmnUsers;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    @Override
    public String toString() {
        return "Customer [id=" + id + ", customerName=" + customerName + ", projects=" + projects + ", bpmnUsers="
                + bpmnUsers + ", organization=" + organization + "]";
    }
    
}
