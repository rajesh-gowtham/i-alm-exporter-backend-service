package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.BpmnDto;
import com.igosolutions.uniSync.Modal.BpmnXmlDto;
import com.igosolutions.uniSync.Modal.PublishBpmn;


public interface BPMNService {

	public void saveTaskConnectionBulk(Bpmn bpmndata, String org);
	
	public List<Bpmn> BpmnByDiagramname(String Diagramname);
	
	public List<BpmnDto> getAllDataSource(String organization, Long userId);
		
	public void savePublishBpmn(PublishBpmn publishBpmn) throws Exception;

	public void deletePublishedDiagram(Long bpmnTaskId);

	public Bpmn getSingleBPMN(Long mapId);

	public BpmnXmlDto getBpmnXml(Long taskConnectionId);
}
