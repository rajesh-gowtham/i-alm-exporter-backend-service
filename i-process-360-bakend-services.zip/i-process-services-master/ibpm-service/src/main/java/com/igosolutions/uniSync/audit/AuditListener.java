package com.igosolutions.uniSync.audit;


import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import com.igosolutions.uniSync.constants.UtilsConstants.AuditConstants;


@Component
public class AuditListener {

	Logger log = LoggerFactory.getLogger(AuditListener.class);

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @PrePersist
    public void beforeInsert(Object entity) {
        log.info("Inside method beforeInsert");
        eventPublisher.publishEvent(new AuditEvent(entity, AuditConstants.INSERT));
    }
    @PreUpdate
    public void beforeUpdate(Object entity) {
        log.info("Inside method beforeUpdate");
        eventPublisher.publishEvent(new AuditEvent(entity, AuditConstants.UPDATE));
    }
    @PreRemove
    public void beforeDelete(Object entity) {
        log.info("Inside method beforeDelete");
        eventPublisher.publishEvent(new AuditEvent(entity, AuditConstants.DELETE));
    }
    

}