package com.igosolutions.uniSync.Modal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class MapDiagramRequestDTOResponse {
	
	    private Long id;
	    private String diagramName;
		private int diagramXmlId;
	    private String docStorageType;
	    private String mapPrivacyType;
	    private List<MapAuthorizedUser> mapAuthorizedUsers;
	    private Map<String, Object> diagramXmlIds = new HashMap<>();
		private Long authorUserId;
		private String configName;
		private String configId;
	    // private String diagramLevel;
		private ProjectDTO project;
//	    private String diagramEditStatus;
//	    private Double diagramVersion;
	    

	    // Getters and setters
	    
	

		// Inner class for MapAuthorizedUser
	    public static class MapAuthorizedUser {
	        private Long userId;
	        private String userEmail;
	        private String userName;
		
			public MapAuthorizedUser(long userId, String userEmail, String userName) {
				this.userId = userId;
				this.userEmail = userEmail;
				this.userName = userName;
			}
			public String getUserEmail() {
				return userEmail;
			}
			public void setUserEmail(String userEmail) {
				this.userEmail = userEmail;
			}
			public String getUserName() {
				return userName;
			}
			public void setUserName(String userName) {
				this.userName = userName;
			}
			public Long getUserId() {
				return userId;
			}
			public void setUserId(Long userId) {
				this.userId = userId;
			}
	    }


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getDiagramName() {
			return diagramName;
		}


		public void setDiagramName(String diagramName) {
			this.diagramName = diagramName;
		}


		public int getDiagramXmlId() {
			return diagramXmlId;
		}


		public void setDiagramXmlId(int diagramXmlId) {
			this.diagramXmlId = diagramXmlId;
		}


		public String getDocStorageType() {
			return docStorageType;
		}


		public void setDocStorageType(String docStorageType) {
			this.docStorageType = docStorageType;
		}


		public String getMapPrivacyType() {
			return mapPrivacyType;
		}


		public void setMapPrivacyType(String mapPrivacyType) {
			this.mapPrivacyType = mapPrivacyType;
		}


		public List<MapAuthorizedUser> getMapAuthorizedUsers() {
			return mapAuthorizedUsers;
		}


		public void setMapAuthorizedUsers(List<MapAuthorizedUser> mapAuthorizedUsers) {
			this.mapAuthorizedUsers = mapAuthorizedUsers;
		}


		public Map<String, Object> getDiagramXmlIds() {
			return diagramXmlIds;
		}


		public void setDiagramXmlIds(Map<String, Object> diagramXmlIds) {
			this.diagramXmlIds = diagramXmlIds;
		}


		public Long getAuthorUserId() {
			return authorUserId;
		}


		public void setAuthorUserId(Long authorUserId) {
			this.authorUserId = authorUserId;
		}


		public String getConfigName() {
			return configName;
		}


		public void setConfigName(String configName) {
			this.configName = configName;
		}


		public String getConfigId() {
			return configId;
		}


		public void setConfigId(String configId) {
			this.configId = configId;
		}


		public ProjectDTO getProject() {
			return project;
		}


		public void setProject(ProjectDTO project) {
			this.project = project;
		}


		@Override
		public String toString() {
			return "MapDiagramRequestDTOResponse [id=" + id + ", diagramName=" + diagramName + ", diagramXmlId="
					+ diagramXmlId + ", docStorageType=" + docStorageType + ", mapPrivacyType=" + mapPrivacyType
					+ ", mapAuthorizedUsers=" + mapAuthorizedUsers + ", diagramXmlIds=" + diagramXmlIds
					+ ", authorUserId=" + authorUserId + ", configName=" + configName + ", configId=" + configId
					+ ", project=" + project + "]";
		}
		

		
		
}
