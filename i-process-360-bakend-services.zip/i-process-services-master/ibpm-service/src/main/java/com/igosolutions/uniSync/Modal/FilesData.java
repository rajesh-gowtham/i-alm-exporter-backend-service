package com.igosolutions.uniSync.Modal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "files_data")
public class FilesData {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "diagram_xml_id")
    private int diagramXmlId;
    @Column(name = "file_name")
    private String fileName;
    @Column(name = "file_content", columnDefinition = "varbinary(max)")
    private byte[] fileContent;
    @Column(name = "current_xml_id")
    private String currentXmlId;
    @Column(name = "activity_id")
    private String activityId;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public int getDiagramXmlId() {
        return diagramXmlId;
    }
    public void setDiagramXmlId(int diagramXmlId) {
        this.diagramXmlId = diagramXmlId;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public byte[] getFileContent() {
        return fileContent;
    }
    public void setFileContent(byte[] fileBytes) {
        this.fileContent = fileBytes;
    }
    public String getCurrentXmlId() {
        return currentXmlId;
    }
    public void setCurrentXmlId(String currentXmlId) {
        this.currentXmlId = currentXmlId;
    }
    public String getActivityId() {
        return activityId;
    }
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }
    @Override
    public String toString() {
        return "FilesData [id=" + id + ", diagramXmlId=" + diagramXmlId + ", fileName=" + fileName + ", fileContent="
                + fileContent + ", currentXmlId=" + currentXmlId + ", activityId=" + activityId + "]";
    }
    
    

}
