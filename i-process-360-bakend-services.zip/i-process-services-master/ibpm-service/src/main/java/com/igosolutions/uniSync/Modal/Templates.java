package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="template")
public class Templates {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="template_id")
	private Long templateId;
	@Column(name ="template_name")
	private String templateName;
	@Column(name ="company_name")
	private String companyName;
	@Column(name ="company_logo")
	private String companyLogo;
	@Column(name ="color_code")
	private String colorCode;
	@Column(name ="nav_up_icon")
	private String navUpIcon;
	@Column(name ="nav_previous_icon")
	private String navPreviousIcon;
	@Column(name ="nav_home_icon")
	private String navHomeIcon;
	@Column(name ="icon_source")
	private String iconSource;
	@Column(name ="nav_up_img")
	private String navUpImg;
	@Column(name ="nav_previous_img")
	private String navPreviousImg;
	@Column(name ="nav_home_img")
	private String navHomeImg;
	@Column(name ="img_name")
	private String imgname;
	@Column(name ="img_content")
	private String imgcontent;
	@Column(name ="organization")
	private String organization;
	
	
	
	public String getIconSource() {
		return iconSource;
	}
	public void setIconSource(String iconSource) {
		this.iconSource = iconSource;
	}
	public Long getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyLogo() {
		return companyLogo;
	}
	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}
	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	public String getNavUpIcon() {
		return navUpIcon;
	}
	public void setNavUpIcon(String navUpIcon) {
		this.navUpIcon = navUpIcon;
	}
	public String getNavPreviousIcon() {
		return navPreviousIcon;
	}
	public void setNavPreviousIcon(String navPreviousIcon) {
		this.navPreviousIcon = navPreviousIcon;
	}
	
	public String getNavHomeIcon() {
		return navHomeIcon;
	}
	public void setNavHomeIcon(String navHomeIcon) {
		this.navHomeIcon = navHomeIcon;
	}
	public String getNavUpImg() {
		return navUpImg;
	}
	public void setNavUpImg(String navUpImg) {
		this.navUpImg = navUpImg;
	}
	public String getNavPreviousImg() {
		return navPreviousImg;
	}
	public void setNavPreviousImg(String navPreviousImg) {
		this.navPreviousImg = navPreviousImg;
	}
	public String getNavHomeImg() {
		return navHomeImg;
	}
	public void setNavHomeImg(String navHomeImg) {
		this.navHomeImg = navHomeImg;
	}
	
	public String getImgname() {
		return imgname;
	}
	public void setImgname(String imgname) {
		this.imgname = imgname;
	}
	public String getImgcontent() {
		return imgcontent;
	}
	public void setImgcontent(String imgcontent) {
		this.imgcontent = imgcontent;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	@Override
	public String toString() {
		return "Templates [templateId=" + templateId + ", templateName=" + templateName + ", companyName=" + companyName
				+ ", companyLogo=" + companyLogo + ", colorCode=" + colorCode + ", navUpIcon=" + navUpIcon
				+ ", navPreviousIcon=" + navPreviousIcon + ", navHomeIcon=" + navHomeIcon + ", iconSource=" + iconSource
				+ ", navUpImg=" + navUpImg + ", navPreviousImg=" + navPreviousImg + ", navHomeImg=" + navHomeImg
				+ ", imgname=" + imgname + ", imgcontent=" + imgcontent + ", organization=" + organization + "]";
	}
	
	
}
