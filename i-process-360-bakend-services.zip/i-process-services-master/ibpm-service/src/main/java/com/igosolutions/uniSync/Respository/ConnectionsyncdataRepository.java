package com.igosolutions.uniSync.Respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Connectionsyncdata;

public interface ConnectionsyncdataRepository extends JpaRepository<Connectionsyncdata, Long>{
	
	
	@Transactional
	@Modifying
	@Query("UPDATE Connectionsyncdata SET meupdateTime = :meupdatetime, almupdateTime = :almupdatetime ,almDomain=:almDomain,almDBName=:almDbName,almDefaultProject=:almtargetProject  WHERE meId = :meId")
   public void updateMEupdatetimeALMupdatetime(String meupdatetime,String almupdatetime,String meId,String almDomain,String almDbName,String almtargetProject);

	@Query("select s from Connectionsyncdata s where s.meId = :meid")
	public Connectionsyncdata findByMeid(String meid);
	
	@Transactional
	@Modifying
	@Query("UPDATE Connectionsyncdata SET almupdateTime = :updatetime, almcopyupdatetime = :updatetime , mecopyupdatetime = :meupdatetime   WHERE meId = :meID")
	public void updateALMUpdateTimeAndALMCopyUpdateTime(String meID, String updatetime, String meupdatetime);
	
	@Transactional
	@Modifying
	@Query("UPDATE Connectionsyncdata SET meupdateTime = :updatetime , mecopyupdatetime = :updatetime,almcopyupdatetime =:almupdtetime  WHERE meId = :meID")
	public void updateMEUpdateTimeAndMECopyUpdateTime(String meID, String updatetime,String almupdtetime);

	@Transactional
	@Modifying
	@Query("UPDATE Connectionsyncdata SET meupdateTime = :meupdatetime, almupdateTime = :almupdatetime   WHERE meId = :meId")
    public void updateMEupdatetimeALMupdatetimeifprojectnull(String meupdatetime,String almupdatetime,String meId);

	@Transactional
	@Modifying
	@Query("UPDATE Connectionsyncdata SET meupdateTime = :updatetime WHERE meId = :meID")
	public void updateMEUpdateTimeAlon(String meID, String updatetime);

	
	
	
}
