package com.igosolutions.uniSync.Respository;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.igosolutions.uniSync.Modal.TimeManage;

public interface TimeManageRepository extends JpaRepository<TimeManage, Long> {
	
	@Modifying
    @Transactional
    @Query("UPDATE TimeManage o SET o.createdTimeStamp = :currentTimestamp WHERE o.diagramXmlId = :diagramXmlId")
	void updateTimestamp(@Param("diagramXmlId")int diagramXmlId,@Param("currentTimestamp") String currentTimestamp);
	
	@Query("SELECT o FROM TimeManage o WHERE o.diagramXmlId = :diagramXmlId")
	TimeManage getBydiagramXmlId(@Param("diagramXmlId")int diagramXmlId);


}
