package com.igosolutions.uniSync.utils;

public class SaveReviewerResponseDto {
	
	private int diagramXmlId;
    private String assignedUser;
    private int assignedUserId;
    private String author;
    private String authorUserId;
    private String status;
    private String diagramName;
    private String languageName;
    private String languageCode;
    private String mapPrivacyType;
    private String organization;
    private String timeStamp;
	public int getDiagramXmlId() {
		return diagramXmlId;
	}
	public void setDiagramXmlId(int diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}
	public String getAssignedUser() {
		return assignedUser;
	}
	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}
	public int getAssignedUserId() {
		return assignedUserId;
	}
	public void setAssignedUserId(int assignedUserId) {
		this.assignedUserId = assignedUserId;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthorUserId() {
		return authorUserId;
	}
	public void setAuthorUserId(String authorUserId) {
		this.authorUserId = authorUserId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDiagramName() {
		return diagramName;
	}
	public void setDiagramName(String diagramName) {
		this.diagramName = diagramName;
	}
	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public String getMapPrivacyType() {
		return mapPrivacyType;
	}
	public void setMapPrivacyType(String mapPrivacyType) {
		this.mapPrivacyType = mapPrivacyType;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "SaveReviewerResponseDto [diagramXmlId=" + diagramXmlId + ", assignedUser=" + assignedUser
				+ ", assignedUserId=" + assignedUserId + ", author=" + author + ", authorUserId=" + authorUserId
				+ ", status=" + status + ", diagramName=" + diagramName + ", languageName=" + languageName
				+ ", languageCode=" + languageCode + ", mapPrivacyType=" + mapPrivacyType + ", organization="
				+ organization + ", timeStamp=" + timeStamp + "]";
	}
    
    

}
