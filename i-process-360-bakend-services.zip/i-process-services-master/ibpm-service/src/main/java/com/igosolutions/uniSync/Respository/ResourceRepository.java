package com.igosolutions.uniSync.Respository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.Resource;

public interface ResourceRepository extends JpaRepository<Resource, Long>{

	@Query("select s from Resource s where s.resourceName = :resourceName AND s.organization = :organization")
	Resource findByName(String resourceName, String organization);
	
	@Query("select s from Resource s where s.id = :id AND s.organization = :organization")
	Resource findByIdAndOrganization(Long id, String organization);
	
	@Transactional
	@Query(value="select s from Resource s where s.id = :id")
	public Resource findByResourceId(@Param("id") Long id);
	
	@Query(value = "SELECT r FROM Resource r WHERE r.organization = :org ORDER BY r.resourceName")
	List<Resource> getAllResource(@Param("org") String organization);

	
	 @Transactional
	    @Modifying
	    @Query("DELETE FROM Resource u WHERE u.id = :id")
		void deleteByResourceId(Long id);
	
}
