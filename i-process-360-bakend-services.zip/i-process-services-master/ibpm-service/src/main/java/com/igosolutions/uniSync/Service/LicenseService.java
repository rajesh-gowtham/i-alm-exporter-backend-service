package com.igosolutions.uniSync.Service;

import org.springframework.http.ResponseEntity;

import com.igosolutions.uniSync.Modal.BpmnUserRequest;

public interface LicenseService {

    public ResponseEntity<?> processEncryptedLicenceData(String fileContent, String fileName) throws Exception;

    public ResponseEntity<?> createAdminUser(BpmnUserRequest adminUser);

    public ResponseEntity<?> processEncryptedUpdatedLicense(String fileContent, String originalFilename, String org);
    
    public  String decryptData(String encryptedPassword, String AES_KEY) throws Exception;
    
    String deleteLicense(BpmnUserRequest adminUser);
}

