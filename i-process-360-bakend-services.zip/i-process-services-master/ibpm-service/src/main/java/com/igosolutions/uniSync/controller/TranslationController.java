package com.igosolutions.uniSync.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.igosolutions.uniSync.Modal.RequestBodyData;
import com.igosolutions.uniSync.Service.TranslationService;

@RestController
public class TranslationController {
	
	@Autowired
	TranslationService translationService;

    @PostMapping("/translateTexts/{fromLanguage}/{toLanguage}")
    public ResponseEntity<Object> translateText(@PathVariable("fromLanguage") String fromLanguage, @PathVariable("toLanguage") String toLanguage, @RequestBody RequestBodyData requestBodyData) {
    	
    	ResponseEntity<Object> response = translationService.processRequestData(fromLanguage, toLanguage, requestBodyData);

        System.out.println(response);
        return response;
    }
    
}
