package com.igosolutions.uniSync.ServiceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.ALMConnect;
import com.igosolutions.uniSync.Modal.AssignedUser;
import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnXml;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.MapAccess;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTO;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTOResponse;
import com.igosolutions.uniSync.Modal.MapVersion;
import com.igosolutions.uniSync.Modal.Notification;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Modal.ReviewDiagrammeDTO;
import com.igosolutions.uniSync.Respository.AlmConnectRepository;
import com.igosolutions.uniSync.Respository.BPMNRepository;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.CommentsRepository;
import com.igosolutions.uniSync.Respository.MapAccessRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.MapVersionRepository;
import com.igosolutions.uniSync.Respository.NotificationRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.Service.BPMNService;
import com.igosolutions.uniSync.Service.BpmnMapReviewService;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;
import com.igosolutions.uniSync.constants.UserRole;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.constants.UtilsConstants.CommentsConstants;
import com.igosolutions.uniSync.constants.UtilsConstants.DiagramEditStatus;
import com.igosolutions.uniSync.constants.UtilsConstants.DiagramLevel;
import com.igosolutions.uniSync.constants.UtilsConstants.MailContents;
import com.igosolutions.uniSync.constants.UtilsConstants.MapPrivacy;
import com.igosolutions.uniSync.exceptions.ProjectNotBelongToAssignedCustomerException;
import com.igosolutions.uniSync.exceptions.ProjectNotFoundException;
import com.igosolutions.uniSync.utils.AsyncEmailService;
import com.igosolutions.uniSync.utils.HeaderUtil;
import com.igosolutions.uniSync.utils.PublishRequestDto;
import com.igosolutions.uniSync.utils.ReviewDiagrammeResponse;
import com.igosolutions.uniSync.utils.SaveReviewerRequestDto;

@Service
public class BpmnMapReviewServiceImpl implements BpmnMapReviewService{

	@Autowired
	MapReviewRepository mapReviewRepository;
	
	@Autowired
	CommentsRepository commentsRepository;
	
	@Autowired
	private BpmnUserRepository bpmnUserRepository;
	
	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
	
	@Autowired
    private AsyncEmailService asyncEmailService;
	
	@Autowired
    BpnmUserDiagrammeService bpnmUserDiagrammeService;
	
	@Autowired
	MapVersionRepository mapVersionRepository;
	
	@Autowired
	private MapAccessRepository mapAccessRepository;
	
	@Autowired
	public BPMNService  bpmnService;
	
	@Autowired
	private MailContentServiceImpl mailContentServiceImpl;

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	BPMNRepository bpmnRepository;

	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	private AlmConnectRepository almConnectRepository;
	
	
	@Autowired 
	EntityManager entityManager;

	public boolean smtpStatus= true;

	Logger log = LoggerFactory.getLogger(BpmnMapReviewServiceImpl.class);

	private String subject = null;

	private String text = null;
	
//	private  List<Integer> users = new ArrayList<Integer>();
//	private  List<String> emails = new ArrayList<String>();
//	private  List<Long> userIds = new ArrayList<Long>();
//	private  List<String> admins = new ArrayList<String>();
	

	@Override
	@Transactional
	public ReviewDiagramme createInitiaDraft(Long userId, int diagramXmlId, String status,String author,MapDiagramRequestDTO mapDiagramRequestDTO) {
			ReviewDiagramme saveData = new ReviewDiagramme();
		try {
			BpmnUser organization = bpmnUserRepository.findByUserId(userId);
			ProjectDTO projectDto = mapDiagramRequestDTO.getProject();
			Optional<Project> existingProject = projectRepository.findById(projectDto.getId());
			if (existingProject.isPresent()) {
				if (!existingProject.get().getCustomer().getId().equals(projectDto.getCustomerId())) {
					throw new ProjectNotBelongToAssignedCustomerException("Project does not belong to the assigned customer");
				}
				saveData.setAuthorUserId(Long.toString(userId));
				saveData.setStatus(status);
				saveData.setAuthor(author);
				saveData.setDiagramName(mapDiagramRequestDTO.getDiagramName());
				saveData.setMapPrivacyType(mapDiagramRequestDTO.getMapPrivacyType());
				saveData.setOrganization(organization.getOrganization());
				saveData.setProject(existingProject.get());
				saveData.setConfigName(mapDiagramRequestDTO.getConfigName());
				saveData.setConfigId(mapDiagramRequestDTO.getConfigId());
				saveData.setStorageType(mapDiagramRequestDTO.getDocStorageType());
				saveData.setLanguageName("English");
			} else {
				throw new ProjectNotFoundException("Project not found");
			}
			

			MapVersion mapVersion = new MapVersion();
			mapVersion.setDiagramEditStatus(DiagramEditStatus.UNLOCKED);
			mapVersion.setDiagramLevel(DiagramLevel.DRAFT);
			mapVersion.setDiagramName(mapDiagramRequestDTO.getDiagramName());
			mapVersion.setDiagramXmlId(diagramXmlId);
			mapVersion.setReviewDiagramme(saveData);

			List<MapVersion> mapVersions = new ArrayList<>();
			mapVersions.add(mapVersion);
			saveData.setMapVersions(mapVersions);

	    if (MapPrivacy.SPECIFIC.equals(mapDiagramRequestDTO.getMapPrivacyType()) || MapPrivacy.PRIVATE.equals(mapDiagramRequestDTO.getMapPrivacyType())) {
	        //int authorUserId = userId.intValue();
	        
	        
	        //boolean authorExists = specificUsers.stream()
	               // .anyMatch(user -> user.getUserId() == authorUserId);

				// if (!authorExists) {
				// MapAuthorizedUser authorUser = new MapAuthorizedUser();
				// authorUser.setUserId(authorUserId);
				// specificUsers.add(authorUser);
				// }

				if (MapPrivacy.SPECIFIC.equals(mapDiagramRequestDTO.getMapPrivacyType())) {
					List<MapAccess> mapAccessList = mapDiagramRequestDTO.getMapAuthorizedUsers().stream()
							.map(user -> {
								MapAccess mapAccess = new MapAccess();
								// mapAccess.setDiagramXmlId(diagramXmlId);
								mapAccess.setSpecificUser(user.getUserId());
								mapAccess.setReviewDiagramme(saveData);
								return mapAccess;
							})
							.collect(Collectors.toList());
					saveData.setMapAccess(mapAccessList);
				}
			}
			ReviewDiagramme save = mapReviewRepository.save(saveData);
			mapReviewRepository.flush();
			entityManager.clear();
			return save;
		} 
		catch (Exception e) {
			e.printStackTrace();
			saveData.setErrorMessage(e.getMessage());
			return saveData;
		}

	}
	
	@Override
	public MapDiagramRequestDTOResponse createMapResponse(BpnmUserDiagramme response, ReviewDiagramme reviewDiagramme) {
		
		MapDiagramRequestDTOResponse mapDiagramRequestDTOResponse = new MapDiagramRequestDTOResponse();
		
		List<String> emails ;
		
		 mapDiagramRequestDTOResponse.setId(reviewDiagramme.getId());
   	     mapDiagramRequestDTOResponse.setConfigId(reviewDiagramme.getConfigId());
    	 mapDiagramRequestDTOResponse.setConfigName(reviewDiagramme.getConfigName());
    	 mapDiagramRequestDTOResponse.setDiagramName(reviewDiagramme.getDiagramName());
//    	 mapDiagramRequestDTOResponse.setDiagramXmlId(response.getDiagramXmlId());
//    	 mapDiagramRequestDTOResponse.setLanguageCode(response.getLanguageCode());
    	 mapDiagramRequestDTOResponse.setAuthorUserId(response.getUserid());
    	 mapDiagramRequestDTOResponse.setMapPrivacyType(reviewDiagramme.getMapPrivacyType());
//    	 mapDiagramRequestDTOResponse.setXmlData(response.getXmlData());
    	 mapDiagramRequestDTOResponse.setDocStorageType(reviewDiagramme.getStorageType());
  //  	 mapDiagramRequestDTOResponse.setTemplate(response.getTemplate());
//    	 mapDiagramRequestDTOResponse.setLanguageName(response.getLanguageName());
//    	 mapDiagramRequestDTOResponse.setDiagramLevel(reviewDiagramme.getMapVersions().get(0).getDiagramLevel());
//    	 mapDiagramRequestDTOResponse.setDiagramEditStatus(reviewDiagramme.getMapVersions().get(0).getDiagramEditStatus());
		ProjectDTO projectDto = new ProjectDTO();
		projectDto.setId(reviewDiagramme.getProject().getId());
		projectDto.setCustomerId(reviewDiagramme.getProject().getCustomer().getId());
		projectDto.setProjectName(reviewDiagramme.getProject().getProjectName());
		projectDto.setCustomerName(reviewDiagramme.getProject().getCustomer().getCustomerName());
		mapDiagramRequestDTOResponse.setProject(projectDto);
		
        // Create the DiagramXmlIdInfo for draft
        Map<String, Object> draftInfo = new HashMap<>();
        draftInfo.put("version", null);
        draftInfo.put("diagramXmlId", response.getDiagramXmlId());
        draftInfo.put("status", CommentsConstants.INPROGRESS);
        
        //while creating a map initially master and archive will be null
        Map<String, Object> diagramXmlIds = new HashMap<>();
        diagramXmlIds.put("Master", null);
        diagramXmlIds.put("Draft", draftInfo);
        diagramXmlIds.put("Archive", new ArrayList<>()); // Empty list for Archive
        
        mapDiagramRequestDTOResponse.setDiagramXmlIds(diagramXmlIds);
        
    	 if (MapPrivacy.SPECIFIC.equals(reviewDiagramme.getMapPrivacyType())) {
    		    List<MapDiagramRequestDTOResponse.MapAuthorizedUser> authorizedUserDetails = mapAccessRepository.findByReviewDiagrammeId(reviewDiagramme.getId()).stream()
    		            .map(MapAccess::getSpecificUser)
    		            .map(user -> bpmnUserRepository.findByUserId(user.longValue()))
    		            .filter(Objects::nonNull)
    		            .map(user -> new MapDiagramRequestDTOResponse.MapAuthorizedUser(user.getUserid(), user.getEmail(), user.getFirstname() + " " + user.getLastname()))
    		            .collect(Collectors.toList());
    		    mapDiagramRequestDTOResponse.setMapAuthorizedUsers(authorizedUserDetails);
    		    
    // For mail purpose 
    		    
    		    emails = authorizedUserDetails.stream().
    		    		map(emailId ->emailId.getUserEmail()).collect(Collectors.toList());
   		        text = mailContentServiceImpl.createMapMail(emails,response.getDiagramName());
    		    asyncEmailService.sendMail(emails, MailContents.SPECIFIC_USER_ADDED_IN_MAP_SUBJECT,text); 
    		}
    	 
    	 else {
    		    mapDiagramRequestDTOResponse.setMapAuthorizedUsers(Collections.emptyList());
    		    if(MapPrivacy.PUBLIC.equals(reviewDiagramme.getMapPrivacyType())) {
    		    	emails = bpmnUserRepository.findByRoleAndOrgainzation(reviewDiagramme.getOrganization(),UserRole.EDITOR.getRole(),reviewDiagramme.getProject().getId());
    		    	text = mailContentServiceImpl.createMapMail(emails,response.getDiagramName());
    		    	asyncEmailService.sendMail(emails, MailContents.PUBLIC_USER_ADDED_IN_MAP_SUBJECT,text);
    		    }
    		}
    	 
		return mapDiagramRequestDTOResponse;
	}
	
	

	public List<ReviewDiagrammeResponse> getBpmnDiagrmByUserId(String userId, Map<String, String> headers) {
	    BpmnUser bpmnUser = bpmnUserRepository.findByUserId(Long.parseLong(userId));
		List<Project> projects = bpmnUser.getProjects();
	    List<ReviewDiagrammeResponse> responses = new ArrayList<>();

	    String organization = HeaderUtil.getOrganization(headers);
	    List<ReviewDiagramme> data = new ArrayList<>();

	    try {
	        if (bpmnUser.getRole().equalsIgnoreCase(UserRole.EDITOR.getRole())) {
	            try {
	                List<ReviewDiagramme> findByPrivateAuthor = mapReviewRepository.findByAuthorUserIdByPrivateSpecificPublic(
	                        userId,
	                        MapPrivacy.PRIVATE.toString(),
	                        bpmnUser.getOrganization(),
	                        MapPrivacy.PUBLIC.toString(),
	                        MapPrivacy.SPECIFIC.toString()
	                );

	                List<MapAccess> mapAccesses = mapAccessRepository.findbySpecificUserId(Integer.parseInt(userId));
	                Set<Integer> diagramXmlIdSet = new HashSet<>();
	             //   mapAccesses.forEach(access -> diagramXmlIdSet.add(access.getDiagramXmlId()));
	                mapAccesses.forEach(diagram -> diagram.getReviewDiagramme().getMapVersions().forEach(version ->diagramXmlIdSet.add(version.getDiagramXmlId())));

	                findByPrivateAuthor.forEach(diagram -> diagram.getMapVersions().forEach(version -> diagramXmlIdSet.add(version.getDiagramXmlId())));

	                data = mapReviewRepository.findByDiagramXmlIds(new ArrayList<>(diagramXmlIdSet));

	                responses = data.stream().filter(reviewMap -> reviewMap.getProject() != null && projects.contains(reviewMap.getProject())).map(diagram -> {
	                    ReviewDiagrammeResponse responseObj = new ReviewDiagrammeResponse();
						Hibernate.initialize(diagram.getAssignedUsers());
	                    responseObj.setId(diagram.getId());
	                    responseObj.setAssignedUsers(diagram.getAssignedUsers());
	                    responseObj.setAuthor(diagram.getAuthor());
	                    responseObj.setAuthorUserId(diagram.getAuthorUserId());
	                    responseObj.setDiagramName(diagram.getDiagramName());
	                    responseObj.setMapPrivacyType(diagram.getMapPrivacyType());
	                    responseObj.setOrganization(diagram.getOrganization());
	                    responseObj.setDocStorageType(diagram.getStorageType());
	                    responseObj.setConfigId(diagram.getConfigId());
	                    responseObj.setConfigName(diagram.getConfigName());
						
						if (diagram.getProject() != null) {
							Project projectDo = diagram.getProject();

							ProjectDTO projectDto = new ProjectDTO();
							projectDto.setId(projectDo.getId());
							projectDto.setProjectName(projectDo.getProjectName());
							projectDto.setCustomerName(projectDo.getCustomer().getCustomerName());
							projectDto.setCustomerId(projectDo.getCustomer().getId());
							responseObj.setProject(projectDto);
						}

	                    Map<String, Object> diagramXmlIdsMap = processMapVersions(diagram.getMapVersions(),diagram);
	                    responseObj.setDiagramXmlIds(diagramXmlIdsMap);

	                    if (MapPrivacy.SPECIFIC.equals(diagram.getMapPrivacyType())) {
	                        List<ReviewDiagrammeResponse.MapAuthorizedUser> authorizedUserDetails = getAuthorizedUsers(diagram.getId());
	                        responseObj.setMapAuthorizedUsers(authorizedUserDetails);
	                    } else {
	                        responseObj.setMapAuthorizedUsers(Collections.emptyList());
	                    }

	                    return responseObj;
	                }).collect(Collectors.toList());

	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        } else if (bpmnUser.getRole().equalsIgnoreCase(UserRole.ADMIN.getRole())) {
	            try {
	                data = mapReviewRepository.findAllByOrganization(organization);
	                responses = data.stream().map(diagram -> {
	                    ReviewDiagrammeResponse responseObj = new ReviewDiagrammeResponse();
						Hibernate.initialize(diagram.getAssignedUsers());
	                    responseObj.setId(diagram.getId());
	                    responseObj.setAssignedUsers(diagram.getAssignedUsers());
	                    responseObj.setAuthor(diagram.getAuthor());
	                    responseObj.setAuthorUserId(diagram.getAuthorUserId());
	                    responseObj.setDiagramName(diagram.getDiagramName());
	                    responseObj.setMapPrivacyType(diagram.getMapPrivacyType());
	                    responseObj.setOrganization(diagram.getOrganization());
	                    responseObj.setDocStorageType(diagram.getStorageType());
	                    responseObj.setConfigId(diagram.getConfigId());
	                    responseObj.setConfigName(diagram.getConfigName());
	                    
	                    Map<String, Object> diagramXmlIdsMap = processMapVersions(diagram.getMapVersions(),diagram);
	                    responseObj.setDiagramXmlIds(diagramXmlIdsMap);

	                    if (MapPrivacy.SPECIFIC.equals(diagram.getMapPrivacyType())) {
	                        List<ReviewDiagrammeResponse.MapAuthorizedUser> authorizedUserDetails = getAuthorizedUsers(diagram.getId());
	                        responseObj.setMapAuthorizedUsers(authorizedUserDetails);
	                    } else {
	                        responseObj.setMapAuthorizedUsers(Collections.emptyList());
	                    }
						if (diagram.getProject() != null) {
							Project projectDo = diagram.getProject();

							ProjectDTO projectDto = new ProjectDTO();
							projectDto.setId(projectDo.getId());
							projectDto.setProjectName(projectDo.getProjectName());
							projectDto.setCustomerName(projectDo.getCustomer().getCustomerName());
							projectDto.setCustomerId(projectDo.getCustomer().getId());
							responseObj.setProject(projectDto);
						}

	                    return responseObj;
	                }).collect(Collectors.toList());
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        } else if (bpmnUser.getRole().equalsIgnoreCase(UserRole.REVIEWER.getRole())) {
	            try {
	                data = mapReviewRepository.findByAssignedUserId(Integer.parseInt(userId));
	                responses = data.stream().filter(reviewMap -> reviewMap.getProject() != null && projects.contains(reviewMap.getProject()))
					.map(diagram -> {
	                    ReviewDiagrammeResponse responseObj = new ReviewDiagrammeResponse();
						Hibernate.initialize(diagram.getAssignedUsers());
	                    responseObj.setId(diagram.getId());
	                    responseObj.setAssignedUsers(diagram.getAssignedUsers());
	                    responseObj.setAuthor(diagram.getAuthor());
	                    responseObj.setAuthorUserId(diagram.getAuthorUserId());
	                    responseObj.setDiagramName(diagram.getDiagramName());
	                    responseObj.setMapPrivacyType(diagram.getMapPrivacyType());
	                    responseObj.setOrganization(diagram.getOrganization());
	                    responseObj.setDocStorageType(diagram.getStorageType());
	                    responseObj.setConfigId(diagram.getConfigId());
	                    responseObj.setConfigName(diagram.getConfigName());
	                    
	                    Map<String, Object> diagramXmlIdsMap = processMapVersions(diagram.getMapVersions(),diagram);
	                    responseObj.setDiagramXmlIds(diagramXmlIdsMap);

	                    if (MapPrivacy.SPECIFIC.equals(diagram.getMapPrivacyType())) {
	                        List<ReviewDiagrammeResponse.MapAuthorizedUser> authorizedUserDetails = getAuthorizedUsers(diagram.getId());
	                        responseObj.setMapAuthorizedUsers(authorizedUserDetails);
	                    } else {
	                        responseObj.setMapAuthorizedUsers(Collections.emptyList());
	                    }
						if (diagram.getProject() != null) {
							Project projectDo = diagram.getProject();

							ProjectDTO projectDto = new ProjectDTO();
							projectDto.setId(projectDo.getId());
							projectDto.setProjectName(projectDo.getProjectName());
							projectDto.setCustomerName(projectDo.getCustomer().getCustomerName());
							projectDto.setCustomerId(projectDo.getCustomer().getId());
							responseObj.setProject(projectDto);
						}

	                    return responseObj;
	                }).collect(Collectors.toList());
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return responses;
	}
	
	private Map<String, Object> processMapVersions(List<MapVersion> mapVersions, ReviewDiagramme diagram) {
	    Map<String, Object> diagramXmlIdsMap = new HashMap<>();

	    // Initialize the map with null for "Master" and "Draft", and empty list for "Archive"
	    diagramXmlIdsMap.put(DiagramLevel.ARCHIVE, new ArrayList<ReviewDiagrammeResponse.DiagramXmlIdInfo>());
	    diagramXmlIdsMap.put(DiagramLevel.MASTER, null);
	    diagramXmlIdsMap.put(DiagramLevel.DRAFT, null);

	    if (mapVersions == null) {
	        return diagramXmlIdsMap; // Return the initialized map with empty values
	    }

	    Map<String, List<MapVersion>> groupedVersions = mapVersions.stream()
	            .collect(Collectors.groupingBy(MapVersion::getDiagramLevel));

	    groupedVersions.forEach((level, versions) -> {
	        if (DiagramLevel.ARCHIVE.equals(level)) {
	            // For archive, we keep the list of versionInfos
	            List<ReviewDiagrammeResponse.DiagramXmlIdInfo> versionInfos = versions.stream().map(version -> {
	                ReviewDiagrammeResponse.DiagramXmlIdInfo versionInfo = new ReviewDiagrammeResponse.DiagramXmlIdInfo();
	                versionInfo.setVersion(version.getDiagramVersion());
	                versionInfo.setDiagramXmlId(version.getDiagramXmlId());
	                return versionInfo;
	            }).collect(Collectors.toList());
	            diagramXmlIdsMap.put(level, versionInfos);
	        } else {
	            // For master and draft, we store a single versionInfo if versions exist
	            if (!versions.isEmpty()) {
	                MapVersion version = versions.get(0);
	                ReviewDiagrammeResponse.DiagramXmlIdInfo versionInfo = new ReviewDiagrammeResponse.DiagramXmlIdInfo();
	                versionInfo.setVersion(version.getDiagramVersion());
	                versionInfo.setDiagramXmlId(version.getDiagramXmlId());
	                if (DiagramLevel.DRAFT.equals(level)) {
	                    versionInfo.setStatus(diagram.getStatus());
	                }
	                diagramXmlIdsMap.put(level, versionInfo);
	            }
	        }
	    });
	    return diagramXmlIdsMap;
	}



    private List<ReviewDiagrammeResponse.MapAuthorizedUser> getAuthorizedUsers(Long diagramId) {
        return mapAccessRepository.findByReviewDiagrammeId(diagramId).stream()
            .map(MapAccess::getSpecificUser)
            .map(userId -> bpmnUserRepository.findByUserId(userId.longValue()))
            .filter(Objects::nonNull)
            .map(user -> new ReviewDiagrammeResponse.MapAuthorizedUser(user.getUserid().intValue(), user.getEmail(), user.getFirstname() + " " + user.getLastname()))
            .collect(Collectors.toList());
    }


	@SuppressWarnings("null")
	@Override
	public ReviewDiagrammeResponse saveReviewerData(SaveReviewerRequestDto saveReviewerRequestDto) {
		
		List<Integer> users = new ArrayList<>();
		List<String> emails = new ArrayList<>();
		List<Long> userIds = new ArrayList<>();
		List<String> admins = new ArrayList<>();

		
		//SaveReviewerResponseDto saveReviewerResponseDto = new SaveReviewerResponseDto();
		entityManager.clear();
		
		ReviewDiagrammeResponse reviewDiagrammeResponse = new ReviewDiagrammeResponse();
		
		List<Integer> assignedUserIds = saveReviewerRequestDto.getAssignedUserIds();
		int diagramXmlId = saveReviewerRequestDto.getDiagramXmlId();
//		String assignedUser = saveReviewerRequestDto.getAssignedUser();
//        String author = saveReviewerRequestDto.getAuthor();
        String status = saveReviewerRequestDto.getStatus();
        String diagramName = saveReviewerRequestDto.getDiagramName();
//        String languageName = saveReviewerRequestDto.getLanguageName();
//        String languageCode = saveReviewerRequestDto.getLanguageCode();
//        String reviewXmlData = saveReviewerRequestDto.getReviewXmlData();
//        String organization = saveReviewerRequestDto.getOrganization();
        
        MapVersion mapVersion = mapVersionRepository.findByDiaramXmlId(diagramXmlId);
        
        ReviewDiagramme existingData = mapReviewRepository.getById( mapVersion.getReviewDiagramme().getId());
        
        BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramXmlId);
		for (Integer assignedUserId : assignedUserIds) {
			Optional<BpmnUser> bpmUserbyId = bpmnUserRepository.findById((long) assignedUserId);
			if (bpmUserbyId.isPresent()) {
				BpmnUser bpmnUser = bpmUserbyId.get();
				List<Project> projectsForUser = bpmnUser.getProjects();
				Project projectForMap = existingData.getProject();

				if (!projectsForUser.contains(projectForMap)) {
					reviewDiagrammeResponse.setErrorMessage(bpmnUser.getFirstname() + " " + bpmnUser.getLastname()
							+ " is not assigned to " + projectForMap.getProjectName());
					return reviewDiagrammeResponse;
				}
			} else {
				reviewDiagrammeResponse.setErrorMessage("Reviewer not found with id " + assignedUserId);
				return reviewDiagrammeResponse;
			}
		}
		BpmnUser user = new BpmnUser();
		List<BpmnUser> assignedReviewUsers =  new ArrayList<>();
		if (existingData.getStatus().equals(UtilsConstants.CommentsConstants.INPROGRESS) && status.equals(UtilsConstants.CommentsConstants.INREVIEW)) {
		    
			subject = MailContents.REQUEST_FOR_REVIEW_SUBJECT;
			
			// Iterate over assignedUserIds to get the list of assigned users
			for(int assignedUserId : assignedUserIds) {
				user = bpmnUserRepository.findByUserId(Long.parseLong(String.valueOf(assignedUserId)));
				assignedReviewUsers.add(user);
			}
			if (existingData.getMapPrivacyType().equals(MapPrivacy.SPECIFIC)) {
		        users = mapAccessRepository.findUserIdByReviewDiagrammeId(existingData.getId());
		        userIds = users.stream()
		                       .map(Long::valueOf)
		                       .collect(Collectors.toList());
				// Add all assigned users' IDs to the userIds list			   
		        for (BpmnUser assignedUser : assignedReviewUsers) {
					userIds.add(assignedUser.getUserid());
				}
		        userIds.add(Long.parseLong(existingData.getAuthorUserId()));

				// Collect emails from assigned users
				for (BpmnUser assignedUser : assignedReviewUsers) {
					emails.add(assignedUser.getEmail());
				}
		        text = mailContentServiceImpl.sendReviewMail(emails,diagramName);
		        
				emails.addAll(bpmnUserRepository.findByUserId(userIds));
		       

		    } else if (existingData.getMapPrivacyType().equals(MapPrivacy.PUBLIC)) {
		    	
		    	for (BpmnUser assignedUser : assignedReviewUsers) {
					emails.add(assignedUser.getEmail());
				}		       
		        text = mailContentServiceImpl.sendReviewMail(emails,diagramName);
		        emails.addAll(bpmnUserRepository.findByRoleAndOrgainzation(existingData.getOrganization(), UserRole.EDITOR.getRole(),existingData.getProject().getId()));		        
		       
		    }
		    else {
		    	
		    	for (BpmnUser assignedUser : assignedReviewUsers) {
					emails.add(assignedUser.getEmail());
				}	       
		        text = mailContentServiceImpl.sendReviewMail(emails,diagramName);		      
		        user = bpmnUserRepository.findByUserId(Long.parseLong(existingData.getAuthorUserId()));
		        emails.add(user.getEmail());		        
		      		    	
		    }
		    
		} else if (existingData.getStatus().equals(UtilsConstants.CommentsConstants.INREVIEW) && status.equals(UtilsConstants.CommentsConstants.INPROGRESS)) {
		    user = bpmnUserRepository.findByUserId(Long.parseLong(String.valueOf(existingData.getAuthorUserId())));
		    subject = MailContents.REVERT_DRAFT_SUBJECT;

		    if (existingData.getMapPrivacyType().equals(MapPrivacy.SPECIFIC)) {
		        users = mapAccessRepository.findUserIdByReviewDiagrammeId(existingData.getId());
		        userIds = users.stream()
		                       .map(Long::valueOf)
		                       .collect(Collectors.toList());
		        userIds.add(user.getUserid());

		        emails = bpmnUserRepository.findByUserId(userIds);
		        
		        text = mailContentServiceImpl.revertToEditorMail(emails,diagramName);
		        
		       

		    } else if (existingData.getMapPrivacyType().equals(MapPrivacy.PUBLIC)) {
		    	
		        emails = bpmnUserRepository.findByRoleAndOrgainzation(existingData.getOrganization(), UserRole.EDITOR.getRole(),existingData.getProject().getId());
		       
		        text = mailContentServiceImpl.revertToEditorMail(emails,diagramName);
		        
		    }
		    else {
		    	emails.add(user.getEmail());
			    text = mailContentServiceImpl.revertToEditorMail(emails,diagramName);
		    }

		} else if (existingData.getStatus().equals(UtilsConstants.CommentsConstants.INREVIEW) && status.equals(UtilsConstants.CommentsConstants.APPROVED)) {
		    admins = bpmnUserRepository.findByRoleAndOrgainzation(existingData.getOrganization(), UserRole.ADMIN.getRole());
		    user = bpmnUserRepository.findByUserId(Long.parseLong(existingData.getAuthorUserId()));
		    subject = MailContents.APPROVED_SUBJECT;

		    if (existingData.getMapPrivacyType().equals(MapPrivacy.SPECIFIC)) {
		        users = mapAccessRepository.findUserIdByReviewDiagrammeId(existingData.getId());
		       
		        userIds = users.stream()
		                       .map(Long::valueOf)
		                       .collect(Collectors.toList());
		        userIds.add(user.getUserid());
		       
		        text = mailContentServiceImpl.approvedMail(admins,diagramName);
		        emails = bpmnUserRepository.findByUserId(userIds);
		        emails.addAll(admins);
		      		        
		    } 		    
		    else if (existingData.getMapPrivacyType().equals(MapPrivacy.PUBLIC)) {
		    	text = mailContentServiceImpl.approvedMail(admins,diagramName);
		        emails = bpmnUserRepository.findByRoleAndOrgainzation(existingData.getOrganization(), UserRole.EDITOR.getRole(),existingData.getProject().getId());
		        emails.addAll(admins);

		    } else {
		    	text = mailContentServiceImpl.approvedMail(admins,diagramName);
		        user = bpmnUserRepository.findByUserId(Long.parseLong(existingData.getAuthorUserId()));
		        emails.add(user.getEmail());
		        emails.addAll(admins);
		        
		    }

		   
		}
			
			// user = bpmnUserRepository.findByUserId((long) Integer.valueOf(assignedUserIds));
			List<AssignedUser> assignedUsers = new ArrayList<>();
			for(Integer assignedUserId : assignedUserIds) {
				BpmnUser byUserId = bpmnUserRepository.findByUserId((long) assignedUserId);
				if(byUserId != null) {
					AssignedUser assignedUser = new AssignedUser();
					assignedUser.setAssignedUserId(assignedUserId);
					assignedUser.setAssignedUser(byUserId.getFirstname() + " " + byUserId.getLastname());
					assignedUsers.add(assignedUser);
				}

			}
			
			
			
			existingData = mapReviewDiagramme(existingData,status,diagramName);
			existingData.getAssignedUsers().clear();  // Clear the existing list
			existingData.getAssignedUsers().addAll(assignedUsers);
			
			ReviewDiagramme save = mapReviewRepository.saveAndFlush(existingData);
			entityManager.clear();
			
			commentsRepository.updateStatus(diagramXmlId,status);
			commentsRepository.flush();
			
			entityManager.clear();
			
			reviewDiagrammeResponse = mapSaveReviewerResponse(bpnmUserDiagramme,save);
			
			
			
			try {
				asyncEmailService.sendMail(emails, subject, text);
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("SMTP SERVER HAS BEEN INACTIVE");
				smtpStatus = false;
				log.info("SMTP SERVER HAS BEEN INACTIVE, MAIL WAS NOT TRIGGERED");
			}
			return reviewDiagrammeResponse;
	}


	private ReviewDiagramme mapReviewDiagramme(ReviewDiagramme existingData,String status, String diagramName) {
		// existingData.setAssignedUser(assignedUser);
		// existingData.setAssignedUserId(assignedUserId);
		existingData.setStatus(status);
		existingData.setDiagramName(diagramName);
		
		return existingData;
	}
	

	private ReviewDiagrammeResponse mapSaveReviewerResponse(BpnmUserDiagramme mappedBpnmUserDiagramme,
			ReviewDiagramme existingData) {
		
		
//		SaveReviewerResponseDto saveReviewerResponseDto = new SaveReviewerResponseDto();
//		
//		
//		saveReviewerResponseDto.setAssignedUser(existingData.getAssignedUser());
//		saveReviewerResponseDto.setAssignedUserId(existingData.getAssignedUserId());
//		saveReviewerResponseDto.setAuthor(existingData.getAuthor());
//		saveReviewerResponseDto.setAuthorUserId(existingData.getAuthorUserId());
//		saveReviewerResponseDto.setDiagramName(existingData.getDiagramName());
//		saveReviewerResponseDto.setDiagramXmlId(mappedBpnmUserDiagramme.getDiagramXmlId());
//		saveReviewerResponseDto.setLanguageCode(mappedBpnmUserDiagramme.getLanguageCode());
//		saveReviewerResponseDto.setLanguageName(mappedBpnmUserDiagramme.getLanguageName());
//		saveReviewerResponseDto.setMapPrivacyType(existingData.getMapPrivacyType());
//		saveReviewerResponseDto.setOrganization(existingData.getOrganization());
//		saveReviewerResponseDto.setStatus(existingData.getStatus());
//		return saveReviewerResponseDto;
		
		 ReviewDiagrammeResponse responseObj = new ReviewDiagrammeResponse();
		 Hibernate.initialize(existingData.getAssignedUsers());
         responseObj.setId(existingData.getId());
         responseObj.setAssignedUsers(existingData.getAssignedUsers());
         responseObj.setAuthor(existingData.getAuthor());
         responseObj.setAuthorUserId(existingData.getAuthorUserId());
         responseObj.setDiagramName(existingData.getDiagramName());
         responseObj.setMapPrivacyType(existingData.getMapPrivacyType());
         responseObj.setOrganization(existingData.getOrganization());

         Map<String, Object> diagramXmlIdsMap = processMapVersions(existingData.getMapVersions(),existingData);
         responseObj.setDiagramXmlIds(diagramXmlIdsMap);

         if (MapPrivacy.SPECIFIC.equals(existingData.getMapPrivacyType())) {
             List<ReviewDiagrammeResponse.MapAuthorizedUser> authorizedUserDetails = getAuthorizedUsers(existingData.getId());
             responseObj.setMapAuthorizedUsers(authorizedUserDetails);
         } else {
             responseObj.setMapAuthorizedUsers(Collections.emptyList());
         }

         return responseObj;
	}
	
	@Override
	public List<Map<String, Object>> getAllPublishedDiagrams(String organization) {
	    try {
	        List<Long> masterDiagramIds = mapVersionRepository.findByDiagramLevelForId(UtilsConstants.DiagramLevel.MASTER);
	        List<MapVersion> publishedDiagrams = mapVersionRepository.findByIds(masterDiagramIds);

	        
	        
	        Map<Long, Map<String, Object>> existingEntries = new HashMap<>();
	        List<Map<String, Object>> finalDtos = new ArrayList<>();

	        for (MapVersion publishedDiagram : publishedDiagrams) {
	            Long mapId = publishedDiagram.getReviewDiagramme().getId();
				ReviewDiagramme reviewDiagram = publishedDiagram.getReviewDiagramme();
	            Map<String, Object> finalDto;
	            Map<String, Object> diagramXmlIdsMap;

	            if (existingEntries.containsKey(mapId)) {
	                finalDto = existingEntries.get(mapId);
	                diagramXmlIdsMap = (Map<String, Object>) finalDto.get("diagramXmlIds");
	            } else {
	                finalDto = new HashMap<>();
	                
	                diagramXmlIdsMap = new HashMap<>();
	                diagramXmlIdsMap.put("Master", new HashMap<String, Object>());
	                diagramXmlIdsMap.put("Archives", new ArrayList<Map<String, Object>>());
	                
	                finalDto.put("diagramName", publishedDiagram.getDiagramName());
	                finalDto.put("mapId", mapId);
	                finalDto.put("diagramXmlIds", diagramXmlIdsMap);
	                finalDto.put("author", publishedDiagram.getReviewDiagramme().getAuthor());
	                finalDto.put("authorUserId", publishedDiagram.getReviewDiagramme().getAuthorUserId());


					
					ProjectDTO projectDTO = new ProjectDTO();

					Optional.ofNullable(reviewDiagram.getProject())
							.ifPresent(project -> {
								Optional.ofNullable(project.getId()).ifPresent(projectDTO::setId);
								Optional.ofNullable(project.getProjectName()).ifPresent(projectDTO::setProjectName);
							});
					finalDto.put("project", projectDTO);
	                
	                finalDtos.add(finalDto);
	                existingEntries.put(mapId, finalDto);
	            }

	            if (DiagramLevel.MASTER.equalsIgnoreCase(publishedDiagram.getDiagramLevel())) {
	                Map<String, Object> masterMap = (Map<String, Object>) diagramXmlIdsMap.get("Master");
	                masterMap.put("publishedBy", mapUserNameById(publishedDiagram.getPublishedBy()));
	                masterMap.put("version", publishedDiagram.getDiagramVersion());
	                masterMap.put("diagramXmlId", publishedDiagram.getDiagramXmlId());
	            } else if (DiagramLevel.ARCHIVE.equalsIgnoreCase(publishedDiagram.getDiagramLevel())) {
	                Map<String, Object> archiveMap = new HashMap<>();
	                archiveMap.put("version", publishedDiagram.getDiagramVersion());
	                archiveMap.put("diagramXmlId", publishedDiagram.getDiagramXmlId());
	                archiveMap.put("publishedBy", mapUserNameById(publishedDiagram.getPublishedBy()));
	                List<Map<String, Object>> archivesList = (List<Map<String, Object>>) diagramXmlIdsMap.get("Archives");
	                archivesList.add(archiveMap);
	            }
				
	        }
	        return finalDtos;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return Collections.emptyList();
	    }
	}

	private Object mapUserNameById(Long publishedBy) {
		BpmnUser bpmnUser = bpmnUserRepository.findByUserId(publishedBy);
		if(bpmnUser != null) {
			return bpmnUser.getFirstname()+" "+bpmnUser.getLastname();
		}
		else {
			return "";
		}
	}


	@SuppressWarnings("null")
	@Override
	public void publishedDiagram(PublishRequestDto publishRequestDto, String userOrganization) throws Exception {
		List<Integer> users = new ArrayList<>();
		List<String> emails = new ArrayList<>();
		List<Long> userIds = new ArrayList<>();
		List<String> admins = new ArrayList<>();
		

	    try {
	        log.debug("Published by: {}", publishRequestDto.getPublishedBy());
	        List<MapVersion> mapVersions = mapVersionRepository.findByMapId(publishRequestDto.getMapId());
	        if (mapVersions == null || mapVersions.isEmpty()) {
	            throw new Exception("No map versions found for mapId: " + publishRequestDto.getMapId());
	        }
	        Bpmn bpmn = new Bpmn();
	        
	        BpmnUser user = new BpmnUser();
	        
	        
	        ReviewDiagramme userId = mapReviewRepository.getByMapId(publishRequestDto.getMapId());

	        for (MapVersion mapVersion : mapVersions) {
	           BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(mapVersion.getDiagramXmlId());
	            log.debug("Processing mapVersion with ID: {}", mapVersion.getId());

	            if (DiagramLevel.MASTER.equals(mapVersion.getDiagramLevel())) {
					MapVersion mapVersionFetch = mapVersionRepository.findById(mapVersion.getId()).get();
					mapVersionFetch.setDiagramLevel(DiagramLevel.ARCHIVE);
					mapVersionRepository.saveAndFlush(mapVersionFetch);
	                // mapVersionRepository.updateDiagramLevel(mapVersion.getId(), DiagramLevel.ARCHIVE);
	            } else if (DiagramLevel.DRAFT.equals(mapVersion.getDiagramLevel())) {
					MapVersion mapVersionFetch = mapVersionRepository.findById(mapVersion.getId()).get();
					mapVersionFetch.setDiagramLevel(DiagramLevel.MASTER);
					mapVersionFetch.setDiagramEditStatus(DiagramEditStatus.LOCKED);
					mapVersionFetch.setDiagramVersion(checkVersion(mapVersion.getDiagramVersion(), DiagramLevel.MASTER));
					mapVersionFetch.setPublishedBy(publishRequestDto.getPublishedBy());
					mapVersionRepository.saveAndFlush(mapVersionFetch);
	                // mapVersionRepository.updateDiagramLevelAndStatusAndPublishedBy(
	                //     mapVersion.getId(),
	                //     DiagramLevel.MASTER,
	                //     DiagramEditStatus.LOCKED,
	                //     checkVersion(mapVersion.getDiagramVersion(), DiagramLevel.MASTER),
	                //     publishRequestDto.getPublishedBy()
	                // );
					// mapVersionRepository.flush();

	                // Create a new diagram
	                MapDiagramRequestDTO dto = new MapDiagramRequestDTO();
	                String configName = userId.getConfigName();
	                dto.setConfigId(userId.getConfigId());
	                int maxLength = 255; 
	                if (configName != null && configName.length() > maxLength) {
	                    configName = configName.substring(0, maxLength);
	                    dto.setConfigName(configName);
	                }
//	                dto.setConfigName(userId.getConfigName());
	                dto.setDiagramName(userId.getDiagramName());
	                dto.setDocStorageType(userId.getStorageType());
	                dto.setXmlData(bpnmUserDiagramme.getXmlData());
	                dto.setLanguageCode(bpnmUserDiagramme.getLanguageCode());
	                dto.setLanguageName(bpnmUserDiagramme.getLanguageName());
	                dto.setTemplate(bpnmUserDiagramme.getTemplate());

	                BpnmUserDiagramme diagram = bpnmUserDiagrammeService.createNewDiagrams(bpnmUserDiagramme.getUserid(), dto);

	                // Create a draft v2 same as master
	                MapVersion newDiagram = new MapVersion();
	                
	                ReviewDiagramme reviewDiagrammeFetch = mapReviewRepository.findById(mapVersion.getReviewDiagramme().getId()).get();
	                newDiagram.setDiagramEditStatus(DiagramEditStatus.LOCKED);
	                newDiagram.setDiagramLevel(DiagramLevel.DRAFT);
	                newDiagram.setDiagramName(diagram.getDiagramName());
	                newDiagram.setDiagramVersion(checkVersion(mapVersion.getDiagramVersion(), DiagramLevel.DRAFT));
	                newDiagram.setDiagramXmlId(diagram.getDiagramXmlId());
	                newDiagram.setPublishedBy(mapVersion.getPublishedBy());
	                newDiagram.setReviewDiagramme(reviewDiagrammeFetch);
					mapVersionRepository.saveAndFlush(newDiagram);
					// mapVersionRepository.insertMapVersion(
					// 		newDiagram.getDiagramXmlId(),
					// 		newDiagram.getDiagramLevel(),
					// 		newDiagram.getDiagramName(),
					// 		newDiagram.getDiagramVersion(),
					// 		newDiagram.getDiagramEditStatus(),
					// 		newDiagram.getPublishedBy(),
					// 		newDiagram.getReviewDiagramme().getId());
					// mapVersionRepository.flush();		

					
					
					reviewDiagrammeFetch.setStatus(CommentsConstants.PUBLISHED);
					mapReviewRepository.saveAndFlush(reviewDiagrammeFetch);
	                // mapReviewRepository.updateStatus(mapVersion.getReviewDiagramme().getId(), CommentsConstants.PUBLISHED);
	                
	            }
	           
	        }
	        
	        // mapVersionRepository.flush();
	        bpnmUserDiagrammeRepository.flush();
			entityManager.clear();
			
			MapVersion version = mapVersionRepository.findByDiagramLevelAndMapId(DiagramLevel.MASTER,publishRequestDto.getMapId());
			BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.getByDiagramXmlId(publishRequestDto.getDiagramXmlId().intValue());
			
	        bpmn.setDiagramLevel(DiagramLevel.MASTER);
            bpmn.setDiagramVersion(version.getDiagramVersion());
            bpmn.setAuthor(userId.getAuthorUserId());
			BpmnXml bpmnXml = new BpmnXml();
			bpmnXml.setBpmnXml(bpnmUserDiagramme.getXmlData());
			bpmn.setBpmnXml(bpmnXml);
            bpmn.setDiagramName(publishRequestDto.getDiagramName());
            bpmn.setDiagramXmlId(Long.toString(publishRequestDto.getDiagramXmlId()));	 
            bpmn.setLanguageCode(bpnmUserDiagramme.getLanguageCode());
            bpmn.setLanguageName(bpnmUserDiagramme.getLanguageName());
            bpmn.setMapId(publishRequestDto.getMapId());
            bpmn.setOrganization(userOrganization);
            bpmn.setPublishedBy(Long.toString(publishRequestDto.getPublishedBy()));
            bpmn.setTemplate(bpnmUserDiagramme.getTemplate());
            bpmn.setProjectId(userId.getProject().getId());
            
            bpmnService.saveTaskConnectionBulk(bpmn,userOrganization);
            
	        BpmnUser organization = bpmnUserRepository.findByUserId(publishRequestDto.getPublishedBy());
			List<String> viewerEmails = bpmnUserRepository.findByRoleAndOrgainzation( organization.getOrganization(),UserRole.VIEWER.getRole(),userId.getProject().getId());			
			subject = MailContents.PUBLISHED;
			//text = mapMailTextContent(viewerEmails,publishRequestDto.getDiagramName(),MailContents.PUBLISHED,MapPrivacy.PUBLIC);
		    text = mailContentServiceImpl.publishMail(viewerEmails,publishRequestDto.getDiagramName());
		    
		    if (userId.getMapPrivacyType().equals(MapPrivacy.SPECIFIC)) {
		        users = mapAccessRepository.findUserIdByReviewDiagrammeId(userId.getId());
		        userIds = users.stream()
		                       .map(Long::valueOf)
		                       .collect(Collectors.toList());
		        userIds.add(Long.parseLong(userId.getAuthorUserId()));

		      
			    text = mailContentServiceImpl.publishMail(viewerEmails,publishRequestDto.getDiagramName());
		        emails.addAll(bpmnUserRepository.findByUserId(userIds));
		        emails.addAll(viewerEmails);
		       

		    } else if (userId.getMapPrivacyType().equals(MapPrivacy.PUBLIC)) {
		    	
			    text = mailContentServiceImpl.publishMail(viewerEmails,publishRequestDto.getDiagramName());
		        emails.addAll(bpmnUserRepository.findByRoleAndOrgainzation(userId.getOrganization(), UserRole.EDITOR.getRole(),userId.getProject().getId()));		        
		        emails.addAll(viewerEmails);
		    }
		    else {
		    	
			    text = mailContentServiceImpl.publishMail(viewerEmails,publishRequestDto.getDiagramName());
		        user = bpmnUserRepository.findByUserId(Long.parseLong(userId.getAuthorUserId()));
		        emails.add(user.getEmail());
		        emails.addAll(viewerEmails);
		      		    	
		    }
		    
			asyncEmailService.sendMail(emails, subject, text);
	    } catch (Exception e) {
	    	if(e.getMessage().contains("No map versions found for mapId:")) {
	    		 log.error( e.getMessage());
	    		throw new Exception(e.getMessage());
	    	}else {
	    		log.error("Error while publishing diagram", e);
		        throw new Exception("Error while publishing diagram", e);
	    	}
	    }
	}


	
//	List<Map<String, Object>> response = new ArrayList<>();
//  Map<String, Object> responseData = new HashMap<>();
//  responseData.put("mapId", mapVersion.getMapId());
//  responseData.put("diagramXmlId", mapVersion.getDiagramXmlId());
//  responseData.put("diagramName", mapVersion.getDiagramName());
//  responseData.put("assignedUser", mapVersion.getAssignedUser());
//  responseData.put("assignedUserId", mapVersion.getAssignedUserId());
//  responseData.put("status", mapVersion.getStatus());
//  responseData.put("reviewXmlData", mapVersion.getReviewXmlData());
//  responseData.put("author", mapVersion.getAuthor());
//  responseData.put("authorUserId", mapVersion.getAuthorUserId());
//  responseData.put("languageCode", mapVersion.getLanguageCode());
//  responseData.put("languageName", mapVersion.getLanguageName());
//  responseData.put("publishedBy", mapVersion.getPublishedBy());
//  
//  response.add(responseData);
//
//  return response;

@Override
public ResponseEntity<?> revokeToDraftDiagram(long mapId, int diagramXmlId, String xmlData) {
	List<MapVersion> mapVersions = mapVersionRepository.findByMapId(mapId);
	MapVersion diagramVersion = mapVersionRepository.findByDiagramXmlId(diagramXmlId);
	MapVersion draftDiagram = mapVersionRepository.findByDiagramLevelAndMapId(DiagramLevel.DRAFT, mapId);
	BpnmUserDiagramme userDiagram = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramXmlId);

	log.debug("User diagram retrieved for diagramXmlId {}: {}", diagramXmlId, userDiagram);

    if (diagramVersion.getDiagramLevel().equals(DiagramLevel.MASTER) || 
        diagramVersion.getDiagramLevel().equals(DiagramLevel.ARCHIVE)) {
        
    	log.info("Diagram is in MASTER or ARCHIVE state for diagramXmlId: {}", diagramXmlId);

        for (MapVersion mapVersion : mapVersions) {
            if (mapVersion.getDiagramLevel().equals(DiagramLevel.DRAFT)) {
                log.debug("Found draft version for mapId: {}", mapId);
                
                if (mapVersion.getDiagramEditStatus().equals(DiagramEditStatus.LOCKED)) {
                    log.info("Draft version is LOCKED for mapVersionId: {}", mapVersion.getId());
					MapVersion mapVersionFetch = mapVersionRepository.findById(mapVersion.getId()).get();
					mapVersionFetch.setDiagramLevel(DiagramLevel.DRAFT);
					mapVersionFetch.setDiagramEditStatus(DiagramEditStatus.UNLOCKED);
					mapVersionFetch.setDiagramVersion(checkVersion(mapVersion.getDiagramVersion()));
					mapVersionRepository.saveAndFlush(mapVersionFetch);
                    // mapVersionRepository.updateDiagramLevelAndStatus(mapVersion.getId(), 
                    //     DiagramLevel.DRAFT, DiagramEditStatus.UNLOCKED, checkVersion(mapVersion.getDiagramVersion()));
                    log.info("Updated diagram level and status for mapVersionId: {}", mapVersion.getId());
                } else {
                    log.warn("Draft version is UNLOCKED. Cannot revoke to draft.");
                    return new ResponseEntity<>("Remove the existing revoked draft and try again", HttpStatus.NOT_ACCEPTABLE);
                }

                bpnmUserDiagrammeRepository.updateDiagram(userDiagram.getDiagramName(), 
                    userDiagram.getTemplate(), 
                    userDiagram.getLanguageCode(), 
                    userDiagram.getLanguageName(), 
                    xmlData, 
                    draftDiagram.getDiagramXmlId());
                log.info("Updated user diagram for draftDiagramXmlId: {}", draftDiagram.getDiagramXmlId());
				ReviewDiagramme reviewDiagramme = mapReviewRepository.findById(mapVersion.getReviewDiagramme().getId()).get();
				reviewDiagramme.setStatus(CommentsConstants.INPROGRESS);
				mapReviewRepository.saveAndFlush(reviewDiagramme);
                // mapReviewRepository.updateStatus(mapVersion.getReviewDiagramme().getId(), CommentsConstants.INPROGRESS);
                log.info("Updated map review status to INPROGRESS for reviewDiagramId: {}", mapVersion.getReviewDiagramme().getId());
            }
        }
    }

    log.info("Map revoked successfully for mapId: {}", mapId);
    return new ResponseEntity<>("Map Revoked Successfully", HttpStatus.OK);
}


	@SuppressWarnings("null")
	private Double checkVersion(Double double1, String level) {
        if(double1 == null) {
        	return 1.0;
        }
        else if(level.equals(DiagramLevel.DRAFT)) {
        	return double1;
        }
        else if(level.equals(DiagramLevel.MASTER)){
        	if(double1>1.0) {
        		return double1;
        	}
        	else {
        		return double1+1.0;
        	}
        }
        else {
        	return null;
        }
	}
	
	private Double checkVersion(Double double1) {
        if(double1 == null) {
        	return 1.0;
        }
        else {
        	return double1+1.0;
        }
	}
	
	
// 	private String mapMailTextContent(List<String> emails, String diagramName, String mapStatus,
// 			String mapPrivacyType) {
// 		BpmnUser bpmnUser;
// 		if (mapStatus.equals(MailContents.MAP_CREATED)
// 				&& (mapPrivacyType.equals(MapPrivacy.SPECIFIC) || mapPrivacyType.equals(MapPrivacy.PUBLIC))) {

// 			if (emails.size() == 1) {

// 				bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));

// 				text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
// 						+ diagramName + "' has been created. You can now begin editing and adding details.\n\n"
// 						+ "Thanks,\n" + "IGO Admin";
// 			}
// 			if (emails.size() > 1) {

// 				text = "Dear Editors,\n\n" + "The map '" + diagramName
// 						+ "' has been created. You can now begin editing and adding details.\n\n" + "Thanks,\n"
// 						+ "IGO Admin";
// 			}
// 		}
// 		else if (mapStatus.equals(MailContents.REVERT_DRAFT)
// 				&& (mapPrivacyType.equals(MapPrivacy.SPECIFIC) || mapPrivacyType.equals(MapPrivacy.PUBLIC))) {

// 			if (emails.size() == 1) {

// 				bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));

// 				text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
// 						+ diagramName + "' has been reviewed and comments provided.\n\n"
// 						+ "Please go through the comments, make the necessary changes, and resend the map for further review.\n\n"
// 						+ "\n" + "Thanks,\n" + "IGO Admin";
// 				if (emails.size() > 1) {

// 					text = "Dear Editors,\n\n" + "The map '" + diagramName
// 							+ "' has been reviewed and comments provided.\n\n"
// 							+ "Please go through the comments, make the necessary changes, and resend the map for further review.\n\n"
// 							+ "\n" + "Thanks,\n" + "IGO Admin";
// 				}
// 			}
// 		}
// 		else if (mapStatus.equals(MailContents.APPROVED) && mapPrivacyType.equals(UserRole.ADMIN.getRole())) {
// 			if (emails.size() == 1) {
// 				bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));
// 				text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
// 						+ diagramName + "' has been reviewed and approved. You can publish the map.\n\n" + "\n"
// 						+ "Thanks,\n" + "IGO Admin";
// 			}
// 			if (emails.size() > 1) {
// 				text = "Dear Admins,\n\n" + "The map '" + diagramName
// 						+ "' has been reviewed and approved. You can publish the map.\n\n" + "\n" + "Thanks,\n"
// 						+ "IGO Admin";
// 			}
// 		}
// 		else if (mapStatus.equals(MailContents.PUBLISHED) && mapPrivacyType.equals(MapPrivacy.PUBLIC)) {
// 			if (emails.size() == 1) {
// 				bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));

// 				text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
// 						+ diagramName + "' has been reviewed and published. You can view the map.\n\n" + "\n"
// 						+ "Thanks,\n" + "IGO Admin";
// 			}
// 			if (emails.size() > 1) {

// 				text = "Dear Viewers,\n\n" + "The map '" + diagramName
// 						+ "' has been reviewed and published. You can view the map.\n\n" + "\n" + "Thanks,\n"
// 						+ "IGO Admin";
// 			}
// 		}
// 		return text;
// //    text = "Dear "+user.getFirstname()+" "+user.getLastname()+ ",\n\n" +
// //            "The map '" + diagramName + "' has been reviewed and approved. You can publish the map.\n\n" +
// //            "\n"+
// //            "Thanks,\n" +
// //            "IGO Admin";
// 	}
	
	@Transactional
	@Override
	public void deleteMapDiagrams(Long userId, List<ReviewDiagrammeDTO> requestPayload) {
		Long mapId = null;
		

		for (ReviewDiagrammeDTO reviewDiagramme : requestPayload) {
			     mapId = reviewDiagramme.getId();
			    
//				if(sharePointRepository.findByDiagramXmlId(Integer.toString(diagramXmlId)).size()> 0){
//					sharePointRepository.deleteByDiagramId(Integer.toString(diagramXmlId));
//				}
//				if(fileRepository.findByDiagramXmlId(diagramXmlId).size()> 0){
//					fileRepository.deleteByDiagramXmlId(diagramXmlId);
//				}
			    List<Integer> diagramXmlIds =  mapVersionRepository.findAllDiagramXmlIdsByMapId(mapId);

				//deleting Comments and Notification for DiagramXmlIds
				commentsRepository.deleteByDiagramXmlIdIn(diagramXmlIds);
				notificationRepository.deleteByDiagramXmlIdIn(diagramXmlIds);
			    
			    mapAccessRepository.deleteByMapId(mapId);
				bpnmUserDiagrammeRepository.deleteByIds(diagramXmlIds);
				
			    mapVersionRepository.deleteByIds(diagramXmlIds); //diagramXmlIds
				mapReviewRepository.deleteById(mapId);
				
				System.out.println("This is map_id"+ mapId);
				
				List<Long> almConnect = almConnectRepository.findByMapId(mapId);
				
				if(!almConnect.isEmpty()) {
				almConnectRepository.deleteByAlmConnectIds(almConnect);
				}
				
			
				
				
				
		}
		
		// Bpmn byMapId = bpmnRepository.findByMapId(mapId);
		// if(byMapId != null){
		// 	bpmnRepository.delete(byMapId);
		// }

	}

	

	@Override
	@Transactional
	public ResponseEntity<?> deleteUnlockedDraft(long mapId) {
		List<MapVersion> mapVersions = mapVersionRepository.findByMapId(mapId);
		MapVersion draftDiagram =  mapVersionRepository.findByDiagramLevelAndMapIdAndDiagramEditStatus(DiagramLevel.DRAFT,mapId,DiagramEditStatus.UNLOCKED);
		ReviewDiagramme userId = mapReviewRepository.getByMapId(mapId);
		
		if (draftDiagram != null) {
			ReviewDiagramme reviewDiagramme = draftDiagram.getReviewDiagramme();
			reviewDiagramme.getMapVersions().remove(draftDiagram); // Remove reference to MapVersion
			mapReviewRepository.saveAndFlush(reviewDiagramme); // Save to persist the change in references

			mapVersionRepository.delete(draftDiagram); 
			mapVersionRepository.flush();

			entityManager.clear();
		}
		
		
		for (MapVersion mapVersion : mapVersions) {
			BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(mapVersion.getDiagramXmlId());
			if (DiagramLevel.MASTER.equals(mapVersion.getDiagramLevel())) {
				

				// Create a new diagram
				MapDiagramRequestDTO dto = new MapDiagramRequestDTO();
				String configName = userId.getConfigName();
				dto.setConfigId(userId.getConfigId());
				int maxLength = 255; 
				if (configName != null && configName.length() > maxLength) {
					configName = configName.substring(0, maxLength);
					dto.setConfigName(configName);
				}
//	                dto.setConfigName(userId.getConfigName());
				dto.setDiagramName(userId.getDiagramName());
				dto.setDocStorageType(userId.getStorageType());
				dto.setXmlData(bpnmUserDiagramme.getXmlData());
				dto.setLanguageCode(bpnmUserDiagramme.getLanguageCode());
				dto.setLanguageName(bpnmUserDiagramme.getLanguageName());
				dto.setTemplate(bpnmUserDiagramme.getTemplate());

				BpnmUserDiagramme diagram = bpnmUserDiagrammeService.createNewDiagrams(bpnmUserDiagramme.getUserid(), dto);

				// Create a master copy same as draft
				MapVersion newDiagram = new MapVersion();

				ReviewDiagramme reviewDiagrammeFetch = mapReviewRepository
						.findById(mapVersion.getReviewDiagramme().getId()).get();
				newDiagram.setDiagramEditStatus(DiagramEditStatus.LOCKED);
				newDiagram.setDiagramLevel(DiagramLevel.DRAFT);
				newDiagram.setDiagramName(diagram.getDiagramName());
				newDiagram.setDiagramVersion(checkVersion(mapVersion.getDiagramVersion(), DiagramLevel.DRAFT));
				newDiagram.setDiagramXmlId(diagram.getDiagramXmlId());
				newDiagram.setPublishedBy(mapVersion.getPublishedBy());
				newDiagram.setReviewDiagramme(reviewDiagrammeFetch);
				mapVersionRepository.saveAndFlush(newDiagram);
				// mapVersionRepository.insertMapVersion(
				// newDiagram.getDiagramXmlId(),
				// newDiagram.getDiagramLevel(),
				// newDiagram.getDiagramName(),
				// newDiagram.getDiagramVersion(),
				// newDiagram.getDiagramEditStatus(),
				// newDiagram.getPublishedBy(),
				// newDiagram.getReviewDiagramme().getId());
				// mapVersionRepository.flush();

				reviewDiagrammeFetch.setStatus(CommentsConstants.PUBLISHED);
				mapReviewRepository.saveAndFlush(reviewDiagrammeFetch);
				// mapReviewRepository.updateStatus(mapVersion.getReviewDiagramme().getId(),
				// CommentsConstants.PUBLISHED);
			}
		}

		return new ResponseEntity<>("Draft deleted successfully", HttpStatus.OK);

	}
	
}


