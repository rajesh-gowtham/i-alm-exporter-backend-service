package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Bpmn;
import com.igosolutions.uniSync.Modal.BpmnDto;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnXml;
import com.igosolutions.uniSync.Modal.BpmnXmlDto;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.PublishBpmn;
import com.igosolutions.uniSync.Respository.BPMNRepository;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.Respository.PublishBpmnRepository;
import com.igosolutions.uniSync.Service.BPMNService;
import com.igosolutions.uniSync.constants.UserRole;
import com.igosolutions.uniSync.constants.UtilsConstants.CommentsConstants;
import com.igosolutions.uniSync.controller.LogFile;

@Service
public class BPMNServiceImpl implements BPMNService {

	
	@Autowired
	private BPMNRepository bpmnRepository;
	@Autowired
	MapReviewRepository mapReviewRepository;
	@Autowired
	private PublishBpmnRepository publishBpmnRepository;
	@Autowired 
	BpmnUserRepository bpmnUserRepository;
	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	private EntityManager entityManager;

	
	@Override
	public void saveTaskConnectionBulk(Bpmn bpmn, String org) {
		
	 Bpmn bpmnsaveUpdate  = bpmnRepository.findByMapId(bpmn.getMapId());
	 if(bpmnsaveUpdate!= null) {
		 bpmn.setTaskConnectionId(bpmnsaveUpdate.getTaskConnectionId());
		 bpmnRepository.save(bpmn);
	 }
	 
	 else {
		 bpmnRepository.save(bpmn);
		 
	 }
	   
	   
	   
	   
	   mapReviewRepository.updateStatus(Long.parseLong(bpmn.getDiagramXmlId()),CommentsConstants.PUBLISHED);
	//    List<BpmnUser> viewUsers = bpmnUserRepository.findAllByRoleAndOrganization(
	// 							UtilsConstants.RoleConstants.VIEWER, org);

	// 					List<String> adminEmails = viewUsers.stream()
	// 							.map(BpmnUser::getEmail)
	// 							.collect(Collectors.toList());

	// 					// Create a single email content for all admin users
	// 					String adminSubject = "Map Published - "+bpmn.getDiagramName();
	// 					String combinedText = "Dear Viewer Users,\n\n" +
	// 							"The map '" + bpmn.getDiagramName()
	// 							+ "' has been Published. You can view the map.\n\n" +
	// 							"\n" +
	// 							"Thanks,\n" +
	// 							"IGO Admin";

	// 					// Send a single email to all admin users
	// 					try {
	// 						asyncEmailService.sendMail(adminEmails, adminSubject, combinedText);
	// 					} catch (Exception e) {
	// 						e.printStackTrace();
	// 						System.out.println("SMTP SERVER HAS BEEN INACTIVE");
	// 					}
	   
	}
	
	@Override
	public void savePublishBpmn(PublishBpmn publishBpmn) throws Exception {
		System.out.println("publishBpmn ------>"+publishBpmn);
		String currDiagram = publishBpmn.getdiagramname();
		List<PublishBpmn> data = publishBpmnRepository.findAll();
		if(!data.isEmpty()) {
			for(PublishBpmn obj:data) {
				if(obj.getdiagramname().equals(currDiagram)) {
					throw new  Exception("Diagram name already exist");
				}
			}
			
		}
		
		publishBpmnRepository.savedetails(publishBpmn.geturl(), publishBpmn.getdiagramname());
	}
	@Override
	public List<Bpmn> BpmnByDiagramname(String Diagramname) {
		try {
			LogFile.LogWrite("BPMN Controller - BpmnByDiagramname<><> :" + Diagramname);
		} catch (IOException e) {
			e.printStackTrace();
		}
     List<Bpmn> bpmndata = bpmnRepository.BpmnByDiagramname(Diagramname);
	return bpmndata;
	}

//	@Override
//	public List<Bpmn> getAllDataSource(String organization) {
//	List<Bpmn> bpmndata = (List<Bpmn>) bpmnRepository.findAllByOrganization(organization);
//	for(Bpmn bpmn: bpmndata) {
//		
//		bpmn.setBpmnXml(null);
//	}
//	
//    return bpmndata;
//	}
	
// 	@Override
// 	public List<BpmnDto> getAllDataSource(String organization, Long userId) {
// 		// Fetch the user by ID
// 		Optional<BpmnUser> byUserId = bpmnUserRepository.findById(userId);
// 		if(byUserId.isPresent()){

// 			if(byUserId.get().getRole().equals(UserRole.ADMIN.getRole())){
// 				return bpmnRepository.findAllByOrganization(organization).stream()
// 				.map(bpmn -> {
// 					entityManager.detach(bpmn);
// 					// Map author
// 					Optional<BpmnUser> author = bpmnUserRepository.findById(Long.parseLong(bpmn.getAuthor()));
// 					author.ifPresent(user -> bpmn.setAuthor(user.getFirstname()+" "+user.getLastname()));
	
// 					// Map publishedBy
// 					Optional<BpmnUser> publishedBy = bpmnUserRepository.findById(Long.parseLong(bpmn.getPublishedBy()));
// 					publishedBy.ifPresent(user -> bpmn.setPublishedBy(user.getFirstname()+" "+user.getLastname()));
// 					BpmnDto bpmnDto = new BpmnDto();
// //					if(reviewDiagrammeOpt.isPresent()){
// //						ReviewDiagramme reviewDiagramme = reviewDiagrammeOpt.get();
// //						if(reviewDiagramme.getProject()!=null){
// //							Project project = reviewDiagramme.getProject();
// //							ProjectDTO projectDto = new ProjectDTO();
// //							projectDto.setProjectName(project.getProjectName());
// //							projectDto.setId(project.getId());
// //							bpmnDto.setProject(projectDto);
// //						}
// //					}
// 					Project project = projectRepository.findByProjectId(bpmn.getProjectId());
// 					bpmnDto.setProject(project.getProjectName());
// 					bpmnDto.setAuthor(bpmn.getAuthor());
// 					bpmnDto.setPublishedBy(bpmn.getPublishedBy());
// 					bpmnDto.setDiagramName(bpmn.getDiagramName());
// 					bpmnDto.setMapId(bpmn.getMapId());
// 					bpmnDto.setDiagramVersion(bpmn.getDiagramVersion());
// 					bpmnDto.setDiagramLevel(bpmn.getDiagramLevel());
// 					bpmnDto.setTemplate(bpmn.getTemplate());
// 					bpmnDto.setLanguageName(bpmn.getLanguageName());
// 					bpmnDto.setLanguageCode(bpmn.getLanguageCode());
// 					bpmnDto.setOrganization(bpmn.getOrganization());
// 					bpmnDto.setDiagramXmlId(bpmn.getDiagramXmlId());
// 					bpmnDto.setTaskConnectionId(bpmn.getTaskConnectionId());
// 					bpmnDto.setBpmnXml(bpmn.getBpmnXml());
					
	
// 					return bpmnDto;
// 				}).collect(Collectors.toList());
			
// 			}
// 			// Get the user's projects
// 			List<Project> projects = byUserId.get().getProjects();

// 			 // Fetch all Bpmn entries for the organization
// 			return bpmnRepository.findAllByOrganization(organization).stream()
// 			.filter(bpmn ->{
// 				entityManager.detach(bpmn);
// 				// For each Bpmn entry, check if the mapId exists and has a project
// 				return projectRepository.findById(bpmn.getProjectId())// Get the project related to the mapId
// 				.filter(projects::contains)// Check if the project is in the user's project list
// 				.isPresent();// Ensure the project is present
// 			})
// 			.map(bpmn -> {
// 				// Map author
//                 Optional<BpmnUser> author = bpmnUserRepository.findById(Long.parseLong(bpmn.getAuthor()));
//                 author.ifPresent(user -> bpmn.setAuthor(user.getFirstname()));

//                 // Map publishedBy
//                 Optional<BpmnUser> publishedBy = bpmnUserRepository.findById(Long.parseLong(bpmn.getPublishedBy()));
//                 publishedBy.ifPresent(user -> bpmn.setPublishedBy(user.getFirstname()));

// 				BpmnDto bpmnDto = new BpmnDto();
				
// 				Project project = projectRepository.findByProjectId(bpmn.getProjectId());
				
// 				bpmnDto.setAuthor(bpmn.getAuthor());
// 				bpmnDto.setPublishedBy(bpmn.getPublishedBy());
// 				bpmnDto.setDiagramName(bpmn.getDiagramName());
// 				bpmnDto.setMapId(bpmn.getMapId());
// 				bpmnDto.setDiagramVersion(bpmn.getDiagramVersion());
// 				bpmnDto.setDiagramLevel(bpmn.getDiagramLevel());
// 				bpmnDto.setTemplate(bpmn.getTemplate());
// 				bpmnDto.setLanguageName(bpmn.getLanguageName());
// 				bpmnDto.setLanguageCode(bpmn.getLanguageCode());
// 				bpmnDto.setOrganization(bpmn.getOrganization());
// 				bpmnDto.setDiagramXmlId(bpmn.getDiagramXmlId());
// 				bpmnDto.setTaskConnectionId(bpmn.getTaskConnectionId());
// 				bpmnDto.setProject(project.getProjectName());
// 				bpmnDto.setBpmnXml(bpmn.getBpmnXml());

// 				return bpmnDto;
// 			}).collect(Collectors.toList());
// 		}
// 	    return Collections.emptyList();
// 	}
@Override
public List<BpmnDto> getAllDataSource(String organization, Long userId) {
	// Fetch the user by ID
	Optional<BpmnUser> optionalUser = bpmnUserRepository.findById(userId);
	if (optionalUser.isPresent()) {
		BpmnUser currentUser = optionalUser.get();
		List<Bpmn> bpmnList;

		if (currentUser.getRole().equals(UserRole.ADMIN.getRole())) {
			// Admin fetches all
			bpmnList = bpmnRepository.findAllByOrganization(organization);
		} else {
			// Non-admin fetches based on user's projects
			List<Project> userProjects = currentUser.getProjects();
			bpmnList = bpmnRepository.findAllByOrganization(organization).stream()
					.filter(bpmn -> userProjects.stream().anyMatch(project -> project.getId().equals(bpmn.getProjectId())))
					.collect(Collectors.toList());
		}

		if (bpmnList.isEmpty()) {
			return Collections.emptyList();
		}

		// Preload authors and publishedBy in batch
		Set<Long> authorIds = bpmnList.stream()
				.map(bpmn -> Long.parseLong(bpmn.getAuthor()))
				.collect(Collectors.toSet());

		Set<Long> publishedByIds = bpmnList.stream()
				.map(bpmn -> Long.parseLong(bpmn.getPublishedBy()))
				.collect(Collectors.toSet());

		List<BpmnUser> authors = bpmnUserRepository.findAllById(authorIds);
		List<BpmnUser> publishedBys = bpmnUserRepository.findAllById(publishedByIds);
		Map<Long, String> authorMap = authors.stream()
				.collect(Collectors.toMap(BpmnUser::getUserid, user -> user.getFirstname() + " " + user.getLastname()));
		Map<Long, String> publishedByMap = publishedBys.stream()
				.collect(Collectors.toMap(BpmnUser::getUserid, user -> user.getFirstname() + " " + user.getLastname()));

		// Preload projects in batch
		Set<Long> projectIds = bpmnList.stream()
				.map(Bpmn::getProjectId)
				.collect(Collectors.toSet());
		List<Project> projects = projectRepository.findAllById(projectIds);
		Map<Long, String> projectMap = projects.stream()
				.collect(Collectors.toMap(Project::getId, Project::getProjectName));

		// Map Bpmn to BpmnDto
		return bpmnList.stream().map(bpmn -> {
			BpmnDto dto = new BpmnDto();
			dto.setTaskConnectionId(bpmn.getTaskConnectionId());
			dto.setDiagramName(bpmn.getDiagramName());
			dto.setDiagramXmlId(bpmn.getDiagramXmlId());
			dto.setLanguageCode(bpmn.getLanguageCode());
			dto.setLanguageName(bpmn.getLanguageName());
			dto.setPublishedBy(publishedByMap.get(Long.parseLong(bpmn.getPublishedBy())));
			dto.setTemplate(bpmn.getTemplate());
			dto.setOrganization(bpmn.getOrganization());
			dto.setDiagramVersion(bpmn.getDiagramVersion());
			dto.setMapId(bpmn.getMapId());
			dto.setAuthor(authorMap.get(Long.parseLong(bpmn.getAuthor())));
			dto.setDiagramLevel(bpmn.getDiagramLevel());
			dto.setProject(projectMap.get(bpmn.getProjectId()));
			// Exclude bpmnXml for now or load it separately if needed
			// dto.setBpmnXml(bpmn.getBpmnXmlEntity() != null ?
			// bpmn.getBpmnXmlEntity().getBpmnXml() : null);
			return dto;
		}).collect(Collectors.toList());
	}
	return Collections.emptyList();
}




	@Override
	public void deletePublishedDiagram(Long bpmnTaskId) {

		bpmnRepository.deleteById(bpmnTaskId);
		
	}

	@Override
	public Bpmn getSingleBPMN(Long mapId) {
		
		Bpmn bpmn = new Bpmn();
		
		bpmn = bpmnRepository.findByMapId(mapId);
	
		
		BpmnUser author =  bpmnUserRepository.findByUserId(Long.parseLong(bpmn.getAuthor()));
		BpmnUser Published =  bpmnUserRepository.findByUserId(Long.parseLong(bpmn.getPublishedBy()));
		
	
		bpmn.setAuthor(author.getFirstname()+" "+author.getLastname());
		bpmn.setPublishedBy(Published.getFirstname()+" "+Published.getLastname());
				
		return bpmn;
	}

	public BpmnXmlDto getBpmnXml(Long taskConnectionId) {
		Optional<Bpmn> bpmnOpt = bpmnRepository.findById(taskConnectionId);
		if (bpmnOpt.isPresent()) {
			Bpmn bpmn = bpmnOpt.get();
			BpmnXml bpmnXml = bpmn.getBpmnXml();
			if (bpmnXml != null) {
				BpmnXmlDto dto = new BpmnXmlDto();
				dto.setTaskConnectionId(bpmn.getTaskConnectionId());
				dto.setBpmnXml(bpmnXml.getBpmnXml());
				return dto;
			}
		}
		return null;
	}

	
	
}
