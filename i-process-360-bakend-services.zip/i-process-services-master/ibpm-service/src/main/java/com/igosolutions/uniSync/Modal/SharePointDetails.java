package com.igosolutions.uniSync.Modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name ="share_point")
public class SharePointDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	 @Column(name = "document_id")
	private String documentId;
	 @Column(name = "diagram_xml_id")
	private String diagramXmlId;
	
	@Column(name = "current_xml_id")
	private String currentXmlId;
	 @Column(name = "activity_id")
	private String activityId;
	@Column(name = "file_name")
	private String fileName;
	@Column(name = "config_id")
	private String configId;
	@Column(name = "storage_type")
	private String storageType;
	 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	 public String getDocumentId() {
			return documentId;
		}
		public void setDocumentId(String documentId) {
			this.documentId = documentId;
		}
		public String getDiagramXmlId() {
			return diagramXmlId;
		}
		public void setDiagramXmlId(String diagramXmlId) {
			this.diagramXmlId = diagramXmlId;
		}
		
		
		public String getFileName() {
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public String getCurrentXmlId() {
			return currentXmlId;
		}
		public void setCurrentXmlId(String currentXmlId) {
			this.currentXmlId = currentXmlId;
		}
		public String getActivityId() {
			return activityId;
		}
		public void setActivityId(String activityId) {
			this.activityId = activityId;
		}
		
		public String getConfigId() {
			return configId;
		}
		public void setConfigId(String configId) {
			this.configId = configId;
		}
		
		public String getStorageType() {
			return storageType;
		}
		public void setStorageType(String storageType) {
			this.storageType = storageType;
		}
		@Override
		public String toString() {
			return "SharePointDetails [id=" + id + ", documentId=" + documentId + ", diagramXmlId=" + diagramXmlId
					+ ", currentXmlId=" + currentXmlId + ", activityId=" + activityId + ", fileName=" + fileName
					+ ", configId=" + configId + ", storageType=" + storageType + "]";
		}
		
}


