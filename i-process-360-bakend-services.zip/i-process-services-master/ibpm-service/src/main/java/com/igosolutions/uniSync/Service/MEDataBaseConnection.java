package com.igosolutions.uniSync.Service;

import java.sql.SQLException;
import java.util.List;

public interface MEDataBaseConnection {
	
	@SuppressWarnings("rawtypes")
	public List getMEUpdatedRecords(String orgName) throws ClassNotFoundException, SQLException;

}
