package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.igosolutions.uniSync.Modal.FilesData;

public interface FileRepository extends JpaRepository<FilesData, Long> {
	
	@Transactional
    @Query(value="SELECT b FROM FilesData b WHERE b.diagramXmlId = :diagramXmlId")
    List<FilesData> findBydiagramXmlId(int diagramXmlId);

    @Transactional
    @Query(value="SELECT b FROM FilesData b WHERE b.activityId = :activityId")
    FilesData findByActivityId(String activityId);

    @Transactional
    @Query(value="SELECT b FROM FilesData b WHERE b.id = :id")
    FilesData findByFileId(Long id);
    
    @Transactional
    @Query(value="SELECT b FROM FilesData b WHERE b.currentXmlId = :currentXmlId")
    FilesData findByCurrentXmlId(String currentXmlId);

    @Transactional
    @Query("SELECT f FROM FilesData f WHERE f.diagramXmlId = :diagramXmlId AND f.currentXmlId = :currentXmlId AND f.activityId = :activityId AND f.fileName =:uploadedFileName")
    FilesData findByDiagramXmlIdAndCurrentXmlIdAndActivityId(
            @Param("diagramXmlId") int diagramXmlId,
            @Param("currentXmlId") String currentXmlId,
            @Param("activityId") String activityId, 
            @Param("uploadedFileName")String uploadedFileName);
    
    @Transactional
    @Modifying
    @Query("UPDATE FilesData e SET e.fileContent = :fileBytes WHERE e.diagramXmlId = :diagramId AND e.currentXmlId = :currentXmlId AND e.activityId = :activityId AND e.fileName = :uploadedFileName")
    void updateFileContent(@Param("diagramId") int diagramId, 
                         @Param("currentXmlId") String currentXmlId, 
                         @Param("activityId") String activityId, 
                         @Param("uploadedFileName") String uploadedFileName, 
                         @Param("fileBytes") byte[] fileBytes);
    @Transactional
    @Modifying
    @Query("DELETE FROM FilesData a WHERE a.diagramXmlId = :diagramId AND a.currentXmlId = :currentXmlId AND a.activityId = :activityId AND a.fileName = :uploadedFileName")
    void deletebyDiagramXmlCurrentXmlActivityFilname(@Param("diagramId") int diagramId, 
                                                     @Param("currentXmlId") String currentXmlId, 
                                                     @Param("activityId") String activityId, 
                                                     @Param("uploadedFileName") String uploadedFileName);
    @Transactional
    @Modifying
    @Query("DELETE FROM FilesData a WHERE a.diagramXmlId = :diagramXmlId")
    void deletebydiagramXmlId(@Param("diagramXmlId") int diagramXmlId);

    @Transactional
    List<FilesData> findByDiagramXmlId(int diagramXmlId);

    @Transactional
    @Modifying
    void deleteByDiagramXmlId(int diagramXmlId);

}
