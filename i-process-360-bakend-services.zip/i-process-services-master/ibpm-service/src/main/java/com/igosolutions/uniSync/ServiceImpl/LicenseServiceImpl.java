package com.igosolutions.uniSync.ServiceImpl;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpmnUserRequest;
import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.LicenseValidation;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.CustomerRepository;
import com.igosolutions.uniSync.Respository.LicenseValidationRepository;
import com.igosolutions.uniSync.Service.LicenseService;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.utils.AsyncEmailService;
import com.igosolutions.uniSync.utils.EncryptDecryptService;
import com.igosolutions.uniSync.utils.PreEncryptDecryptService;
import com.igosolutions.uniSync.utils.TemporaryPasswordGenerator;

@Service
public class LicenseServiceImpl implements LicenseService {

    @Autowired
    EncryptDecryptService encryptDecryptService;

    @Autowired
    PreEncryptDecryptService preEncryptDecryptService;

    @Autowired
    BpmnUserRepository bpmnUserRepository;

    @Autowired
    BpmnUserServiceImpl bpmnUserServiceImpl;
   
    @Autowired
    LicenseValidationRepository licenseValidationRepository;

    @Autowired
    private AsyncEmailService asyncEmailService;
    
    private static final String AES_KEY = "ThisIsASecretKey";
    
    @Autowired
    private TemporaryPasswordGenerator temporaryPasswordGenerator;

    @Autowired
    CustomerRepository customerRepository;
    
    @Autowired
    EntityManager entityManager;

    Logger log = LoggerFactory.getLogger(LicenseServiceImpl.class);

     public static final String AES_ADMIN = "a1b2c3d4e5f6g7h8";
     public static final String AES_VIEWER = "h7g6f5e4d3c2b1a0";
     public static final String AES_REVIEWER = "1a2b3c4d5e6f7g8h";
     public static final String AES_EDITOR = "8h7g6f5e4d3c2b1a";
     public static final String VALID_FROM = "8t7k5p2m4f5v1k3g";
     public static final String VALID_TO = "9c8x7s6e5f2h1k4h";

    @Override
    public ResponseEntity<?> processEncryptedLicenceData(String fileContent, String fileName) throws Exception {
        // long orgId = Long.parseLong(extractOrganizationId(fileName));

        Map<String, String> responseBody = new HashMap<String, String>();
        try {
            
            String finalDecrypt = encryptDecryptService.finalDecrypt(fileContent);
            String decryptedData = preEncryptDecryptService.decrypt(finalDecrypt);
            log.info("Decrypted Data: {}", decryptedData);

            String[] data = decryptedData.split(",");
            String organization = data[0];
            String admins = data[1];
            String viewers = data[2];
            String reviewers = data[3];
            String editors = data[4];
            String status = data[5];
            String validFrom = data[6];
            String validTo = data[7];
            
            try {
            	if(validTo!=null || !validTo.isEmpty()) {
            		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                     LocalDate validToDate = LocalDate.parse(validTo, formatter);
                     
                     if(validToDate.isBefore(LocalDate.now())) {
                    	 responseBody.put("message", "Your iBPM license has been expired, please update the license to continue.");
                    	return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
                    }

            	}
            } catch (DateTimeParseException e) {
                System.err.println("Error parsing date: " + e.getMessage());
                // Handle the exception
            }
            
            if(status.equals("Update")) {
            	return processEncryptedUpdatedLicense(fileContent, fileName, organization);
            }else {
            	//Adding new License in DB
                LicenseValidation licenceData =  new LicenseValidation();
                licenceData.setOrganization(organization);
                licenceData.setAdmins(encryptData(admins, AES_ADMIN));
                licenceData.setViewers(encryptData(viewers, AES_VIEWER));
                licenceData.setReviewers(encryptData(reviewers, AES_REVIEWER));
                licenceData.setEditors(encryptData(editors, AES_EDITOR));
                licenceData.setValidFrom(encryptData(validFrom,VALID_FROM));
                licenceData.setValidTo(encryptData(validTo,VALID_TO));
                
                licenceData.setStatus(status);
                
                // License dataByOrganization = licenseRepository.findbyName(organization);
                LicenseValidation licenseByValidation =  licenseValidationRepository.findByOrganization(organization);

                if (licenseByValidation == null) {
                    if(UtilsConstants.LicenceConstants.INACTIVE.equalsIgnoreCase(status)){
                        responseBody.put("organization", organization);
                        responseBody.put("message", "Licence activation is in progress");
                        //setting the status as pending
                        licenceData.setStatus(UtilsConstants.LicenceConstants.PENDING);
                        licenseValidationRepository.saveAndFlush(licenceData);
                        
                        entityManager.clear();
                        //Adding the Customer Data for the Organization
                        if(!organization.equalsIgnoreCase("iGO Solutions")){
                            Customer customer = new Customer();
                            customer.setCustomerName(organization);
                            customer.setOrganization(organization);
                            customer.setProjects(new ArrayList<>());
                            customerRepository.saveAndFlush(customer);
                        }
                        return new ResponseEntity<>(responseBody, HttpStatus.NOT_ACCEPTABLE);
                    }
                
                }
                else{
                     if(licenseByValidation.getStatus().equalsIgnoreCase(UtilsConstants.LicenceConstants.ACTIVE) ){
                        responseBody.put("message", "Licence is Already Active");
                        responseBody.put("organization", organization);
                        return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
                    }
                    else{
                        responseBody.put("message", "Licence is in pending state");
                        responseBody.put("organization", organization);
                        return new ResponseEntity<>(responseBody, HttpStatus.NOT_ACCEPTABLE);
                    }
                }
            }
            
            
            return null;
        } catch (Exception e) {

            log.error("Error during decryption and validation", e);
            throw new Exception("The Uploaded file is not valid or may be corrupted");
        }
    }

    @Override
    public ResponseEntity<?> createAdminUser(BpmnUserRequest bpmnUserRequest) {
        try {
            String temporary_password = null;
            BpmnUser bpmnUser = new BpmnUser(
                    bpmnUserRequest.getUserid(),
                    bpmnUserRequest.getFirstname(),
                    bpmnUserRequest.getLastname(),
                    bpmnUserRequest.getEmail(),
                    bpmnUserRequest.getRole(),
                    bpmnUserRequest.getMobileno(),
                    bpmnUserRequest.getUserimage().getImgname(),
                    bpmnUserRequest.getUserimage().getImgcontent(),
                    bpmnUserRequest.getOrganization());

            BpmnUser userEmail = bpmnUserRepository.findByEmail(bpmnUser.getEmail());
            int countByOrganization = bpmnUserRepository.countByOrganization(bpmnUserRequest.getOrganization());
            System.out.println("countByOrg "+countByOrganization);
            // License licenseData = licenseRepository.findbyName(bpmnUserRequest.getOrganization());
            LicenseValidation licenseByValidation =  licenseValidationRepository.findByOrganization(bpmnUserRequest.getOrganization());

            if (licenseByValidation == null || !UtilsConstants.LicenceConstants.PENDING.equalsIgnoreCase(licenseByValidation.getStatus())) {
                return new ResponseEntity<>("No valid pending license data found for the organization", HttpStatus.BAD_REQUEST);
            }
            if (UtilsConstants.LicenceConstants.PENDING.equalsIgnoreCase(licenseByValidation.getStatus())) {
                if (userEmail != null && userEmail.getEmail().equals(bpmnUserRequest.getEmail())) {
                    return new ResponseEntity<>("Email has been registered already",HttpStatus.CONFLICT);
                }
                if (userEmail != null && userEmail.getOrganization().equals(bpmnUserRequest.getOrganization())) {
                    return new ResponseEntity<>("Organization has been registered already", HttpStatus.CONFLICT);
                }
                if (countByOrganization > 0) {
                    return new ResponseEntity<>("Organization has been registered already", HttpStatus.CONFLICT);
                }

                temporary_password = temporaryPasswordGenerator.generateTemporaryPassword();
                bpmnUser.setPassword(encryptPassword(temporary_password));
                bpmnUser.setFirstLogin(true);
                bpmnUser.setIsLogin(false);
                log.info("Temporary Password: {}", temporary_password); 
                
                String subject = "USER CREATED";
                String text = "Dear " + bpmnUserRequest.getFirstname() + " " + bpmnUserRequest.getLastname() + ",\n\n" +
                        "Your account has been successfully created. You can now log in and start using our services with below credentials.\n\n\n"+
                        "User name : "+bpmnUserRequest.getEmail()+"\n"+
                        "\n"+
                        "Password : "+temporary_password+"\n"+
                        "\n"+
                        "Thanks,\n" +
                        "IGO Admin";

                try {
                    asyncEmailService.sendMail(bpmnUserRequest.getEmail(), subject, text);
                    
                } catch (Exception e) {
                    log.info("SMTP SERVER HAS BEEN INACTIVE, MAIL WAS NOT TRIGGERED");
                }
                // license as active after successful user creation
                licenseByValidation.setStatus(UtilsConstants.LicenceConstants.ACTIVE);
                // Saving The user data in Bpmn User Table 
                BpmnUser savedData = bpmnUserRepository.save(bpmnUser);
                Map<String, Object> responsePayload = new HashMap<>();
                responsePayload.put("firstname", savedData.getFirstname());
                responsePayload.put("lastname", savedData.getLastname());
                responsePayload.put("userid", String.valueOf(savedData.getUserid()));
                responsePayload.put("role", savedData.getRole());
                responsePayload.put("organization", savedData.getOrganization());
                Map<String, String> userImageMap = new HashMap<>();
                userImageMap.put("imgname", savedData.getImgname());
                userImageMap.put("imgcontent", savedData.getImgcontent());
                responsePayload.put("userimage", userImageMap);

                return new ResponseEntity<>(responsePayload, HttpStatus.OK);

            } else {
                if (countByOrganization > 0) {
                    return new ResponseEntity<>("Organization has been registered already", HttpStatus.CONFLICT);
                } else {
                    return new ResponseEntity<>("License Has been Activated Already", HttpStatus.CONFLICT);
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public static String encryptPassword(String token) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);

	}

    public static String encryptData(String token, String AES_KEY) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);

	}
    public String decryptData(String encryptedPassword, String AES_KEY) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

    @Override
    public ResponseEntity<?> processEncryptedUpdatedLicense(String fileContent, String originalFilename, String org) {
        Map<String, String> responseBody = new HashMap<String, String>();
       try {
        String finalDecrypt = encryptDecryptService.finalDecrypt(fileContent);
        String decryptedData = preEncryptDecryptService.decrypt(finalDecrypt);
        log.info("Decrypted Data: {}", decryptedData);

        String[] data = decryptedData.split(",");
        String organization = data[0];
        String admins = data[1];
        String viewers = data[2];
        String reviewers = data[3];
        String editors = data[4];
        String status = data[5];
        String validFrom = data[6];
        String validTo = data[7];
        
        if(!org.equalsIgnoreCase(organization)) {
        	responseBody.put("message", "Please upload a valid file");
            responseBody.put("organization", organization);
            return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
        }
        LicenseValidation licenseByValidation =  licenseValidationRepository.findByOrganization(organization);
        if(licenseByValidation != null){
            if(licenseByValidation.getStatus().equalsIgnoreCase(UtilsConstants.LicenceConstants.ACTIVE) && status.equalsIgnoreCase(UtilsConstants.LicenceConstants.UPDATE)){
                // Decrypt the stored data for comparison
                String decryptedAdmins = decryptData(licenseByValidation.getAdmins(), AES_ADMIN);
                String decryptedViewers = decryptData(licenseByValidation.getViewers(), AES_VIEWER);
                String decryptedReviewers = decryptData(licenseByValidation.getReviewers(), AES_REVIEWER);
                String decryptedEditors = decryptData(licenseByValidation.getEditors(), AES_EDITOR);
                String from = decryptData(licenseByValidation.getValidFrom(),VALID_FROM);
                String to = decryptData(licenseByValidation.getValidTo(), VALID_TO);

                // Check if the received data matches the stored data
                if (admins.equals(decryptedAdmins) && viewers.equals(decryptedViewers) && reviewers.equals(decryptedReviewers) && editors.equals(decryptedEditors) && validFrom.equals(from) && validTo.equals(to)) {
                    responseBody.put("message", "Licence has been updated already");
                    responseBody.put("organization", organization);
                    return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
                }
                // Update the Number of Users and setting the status as Active
                licenseValidationRepository.updateByOrganization(organization, encryptData(admins, AES_ADMIN), encryptData(editors, AES_EDITOR), encryptData(reviewers, AES_REVIEWER), encryptData(viewers, AES_VIEWER), UtilsConstants.LicenceConstants.ACTIVE,encryptData(validFrom, VALID_FROM),encryptData(validTo, VALID_TO));
                responseBody.put("message", "Licence has been Updated Successfully");
                responseBody.put("organization", organization);
                return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
            }
            else{
                responseBody.put("message", "License is not for Update Request");
                responseBody.put("organization", organization);
                return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
            }
        }
        else{
            responseBody.put("message", "Licence for this organization is not found");
            responseBody.put("organization", organization);
            return new ResponseEntity<>(responseBody, HttpStatus.CONFLICT);
        }

       } catch (Exception e) {
    	     responseBody.put("message", "Error processing file");
             return new ResponseEntity<>(responseBody, HttpStatus.INTERNAL_SERVER_ERROR);
       }
    }

	@Override
	public String deleteLicense(BpmnUserRequest request) {
		try {
			licenseValidationRepository.deleteLicense(request.getOrganization());
			return "Organization deleted successfully";
		} catch (Exception e) {
			return "Error deleting organization";
		}
	}
}
