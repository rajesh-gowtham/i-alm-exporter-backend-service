package com.igosolutions.uniSync.utils;

public class CompanyLogo {

	private String imgname;
	private String imgcontent;
	
	public CompanyLogo() {
	}
	public String getImgname() {
		return imgname;
	}
	public void setImgname(String imgname) {
		this.imgname = imgname;
	}
	public String getImgcontent() {
		return imgcontent;
	}
	public void setImgcontent(String imgcontent) {
		this.imgcontent = imgcontent;
	}
	
	@Override
	public String toString() {
		return "CompanyLogo [imgname=" + imgname + ", imgcontent=" + imgcontent + "]";
	}
	
}



