package com.igosolutions.uniSync.ServiceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.LicenseValidation;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.LicenseValidationRepository;
import com.igosolutions.uniSync.constants.UserRole;
import com.igosolutions.uniSync.utils.AsyncEmailService;

@Service
public class LicenseCheckScheduler {
	
	@Autowired
    LicenseValidationRepository licenseValidationRepository;
	
	@Autowired
	BpmnUserServiceImpl bpmnUserServiceImpl;
	
	@Autowired
	BpmnUserRepository bpmnUserRepository;	
	
	@Autowired
	AsyncEmailService asyncEmailService;
	
	
	@Scheduled(cron = "0 0 8 * * ?")
	public void licenseScheduler() throws Exception {
		
		List <LicenseValidation> licenseValidation = licenseValidationRepository.findAll();
		
		
		
		for(LicenseValidation licenseValid :licenseValidation ) {
			
			if(licenseValid.getValidTo() != null) {
			
			String validTo =bpmnUserServiceImpl.decryptData(licenseValid.getValidTo(),LicenseServiceImpl.VALID_TO);
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			
			List<String> adminMails = new ArrayList<String>();
			
			Date validDate = simpleDateFormat.parse(validTo);
			
            Calendar validCal = Calendar.getInstance();
            validCal.setTime(validDate);
            validCal.set(Calendar.HOUR_OF_DAY, 23);
            validCal.set(Calendar.MINUTE, 59);
            validCal.set(Calendar.SECOND, 59);
            validCal.set(Calendar.MILLISECOND, 999);
            validDate = validCal.getTime();

            Calendar currentCal = Calendar.getInstance();
            currentCal.set(Calendar.HOUR_OF_DAY, 0);
            currentCal.set(Calendar.MINUTE, 0);
            currentCal.set(Calendar.SECOND, 0);
            currentCal.set(Calendar.MILLISECOND, 0);
            Date currentDate = currentCal.getTime();
			
			
			
			
			long differenceInMilliSeconds = validDate.getTime() - currentDate.getTime();

			long differenceInDays = differenceInMilliSeconds / (1000 * 60 * 60 * 24);
			
			
			if(differenceInDays <=5 && differenceInDays>=0 ) {
				
				adminMails = bpmnUserRepository.findByRoleAndOrgainzation(licenseValid.getOrganization(),UserRole.ADMIN.getRole());
							
		        asyncEmailService.sendLicenseExpiprationEmail(adminMails,differenceInDays,validTo);		
				
			}
			
		}else {
			System.out.println("The license has no valid date");
			
		}
			
		
		
	}
	}
	
}
