package com.igosolutions.uniSync.ServiceImpl;

import java.sql.SQLException;
import java.util.List;

import com.igosolutions.uniSync.Service.MEDataBaseConnection;

public class MEDataBaseConnectionImpl implements MEDataBaseConnection{
	
	
	

	@SuppressWarnings("rawtypes")
	@Override
	public List getMEUpdatedRecords(String orgName) throws ClassNotFoundException, SQLException {
		
//		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//
//		String dbURL = "jdbc:sqlserver://172.22.6.7;databaseName=avlino_jira_test_db;user=suresha;password=MSChangeMe@123";
//		Connection con = DriverManager.getConnection(dbURL);
//		System.out.println("the connection string here");
//		
//		Statement stmt = con.createStatement();
		
		
		return null;
	}

}
