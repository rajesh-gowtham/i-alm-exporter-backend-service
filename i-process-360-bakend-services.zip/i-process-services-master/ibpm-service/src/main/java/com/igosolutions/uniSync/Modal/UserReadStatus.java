package com.igosolutions.uniSync.Modal;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class UserReadStatus implements Serializable {

    private Long userId;
    private Boolean isRead = false;

    public UserReadStatus() {
    }

    public UserReadStatus(Long userId, Boolean isRead) {
        this.userId = userId;
        this.isRead = isRead;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

}
