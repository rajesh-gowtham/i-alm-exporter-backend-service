package com.igosolutions.uniSync.Modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Audited
public class Project {

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String projectName;

    @ManyToMany(mappedBy = "projects")
    @JsonBackReference
    private List<BpmnUser> bpmnUsers;

    @ManyToOne()
    @JoinColumn(name = "customer_id")
    @JsonBackReference
    private Customer customer;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "project_id")
    @JsonManagedReference
    private List<ReviewDiagramme> reviewDiagram = new ArrayList<>();

    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public List<BpmnUser> getBpmnUsers() {
        return bpmnUsers;
    }

    public void setBpmnUsers(List<BpmnUser> bpmnUsers) {
        this.bpmnUsers = bpmnUsers;
    }


    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<ReviewDiagramme> getReviewDiagram() {
        return reviewDiagram;
    }

    public void setReviewDiagram(List<ReviewDiagramme> reviewDiagram) {
        this.reviewDiagram = reviewDiagram;
    }

    @Override
    public String toString() {
        return "Project [id=" + id + ", projectName=" + projectName + ", bpmnUsers=" + bpmnUsers + ", customer="
                + customer + ", reviewDiagram=" + reviewDiagram + "]";
    }
    
    

}
