package com.igosolutions.uniSync.Service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.igosolutions.uniSync.Modal.DataSource;


public interface DataSourceService {

	public void saveDataSource(DataSource datasource) throws Exception;
	
	public List<DataSource> getAllDataSource (String organization);
	
	public boolean findDataSouceName(String datasourcename);

	public DataSource getDataSource(String datasourcename);
	
	public void updateDataSource(DataSource datasource, Long id) throws Exception;
	
	public ResponseEntity<?> deleteDataSource(Long id, String organization);
	
	public DataSource selectDomanin(String targetdatasource);

	public Map<String, String> defectToolAuthentication(DataSource authmodal) throws Exception;

	List<String> getAllDomain( Map<String, String> tokens) throws IOException, Exception;

	List<Object> getAllProjectsForDomain(String domainname, Map<String, String> tokens)throws Exception;

	List<Map<String, Object>> fetchTestFolders(DataSource datasource) throws Exception;
	
	List<Map<String, Object>> fetchTestFoldersTestCaseDesignSteps(DataSource dataSource) throws Exception;

	List<Map<String, Object>> fetchALMRequirementsData(DataSource dataSource) throws Exception;
}
