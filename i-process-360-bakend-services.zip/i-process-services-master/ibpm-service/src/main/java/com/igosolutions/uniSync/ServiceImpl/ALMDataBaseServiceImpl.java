package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Connectionsyncdata;
import com.igosolutions.uniSync.Service.ALMDataBaseService;
import com.igosolutions.uniSync.controller.LogFile;

@Service
public class ALMDataBaseServiceImpl implements ALMDataBaseService {
//almdatabaseImpl
	public void getConnection() {
		try {
			

			System.out.println("the connection string here Hot Code Here...#2121");

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String dbURL = "jdbc:sqlserver://172.22.6.7;databaseName=avlino_jira_test_db;user=suresha;password=MSChangeMe@123";
			Connection con = DriverManager.getConnection(dbURL);
			System.out.println("the connection string here");
			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("Select BG_BUG_ID, BG_VTS ,BG_USER_01 from td.bug where BG_BUG_ID = '103'");
			while (rs.next())
				System.out.println(rs.getString(1));
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void getUpdatetimeRecords() {
		try {
			System.out.println("the connection string here");
			System.out.println("the connection string here Hot Code Here...#2122");


			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			String dbURL = "jdbc:sqlserver://172.22.6.7;databaseName=avlino_jira_test_db;user=suresha;password=MSChangeMe@123";
			Connection con = DriverManager.getConnection(dbURL);
			System.out.println("the connection string here");
			// here sonoo is database name, root is username and password
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("Select *  from td.bug where BG_BUG_ID = '103' ");
			while (rs.next())
				System.out.println(rs.getString(3));
			con.close();
		}
		// }
		catch (

		Exception e) {
			System.out.println(e);
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getAMLRecordsByALMIDs(List<Object> almIDs,String databasename, String domainname, String targetProjectname) throws ClassNotFoundException, SQLException {
		
		
		//,String domainname, Stringdomainname
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		String dbURL = "jdbc:sqlserver://172.22.6.7;databaseName="+databasename+";user=suresha;password=MSChangeMe@123";
		Connection con = DriverManager.getConnection(dbURL);
		System.out.println("the connection string here");
		// here sonoo is database name, root is username and password
		Statement stmt = con.createStatement();
		List<Connectionsyncdata> listconnectionsyncdatas = new LinkedList<Connectionsyncdata>();
		for(int i=0;i<almIDs.size();i++) {
			Connectionsyncdata connectionsyncdata = new Connectionsyncdata();
			String almid=almIDs.get(i).toString();
			
			
			try {
				LogFile.LogWrite("Data Source Controller - dbURL 232m "+ dbURL);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			ResultSet rs = stmt.executeQuery("Select BG_BUG_ID, BG_VTS, BG_USER_01 from td.bug where BG_BUG_ID='"+almid+"' ");
			
			try {
				LogFile.LogWrite("ALM DATABASE the Query IS 3355  : "+ "Select BG_BUG_ID, BG_VTS, BG_USER_01 from td.bug where BG_BUG_ID='"+almid+"' ");
				LogFile.LogWrite("ALM ResultSet data 3344         : "+ rs);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			
			while (rs.next()) {
				connectionsyncdata.setAlmId(rs.getString("BG_BUG_ID"));
				connectionsyncdata.setAlmupdateTime(rs.getString("BG_VTS"));
				connectionsyncdata.setalmDomain(domainname);	
				if(domainname == null || domainname.length() == 0) {
					// do nothing
				}else {
					connectionsyncdata.setalmDefaultProject(targetProjectname);
				}
				
				connectionsyncdata.setalmDBName(databasename);
				
				try {
					LogFile.LogWrite("ALM DATABASE - 26265 "+targetProjectname);
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}
			
			listconnectionsyncdatas.add(connectionsyncdata);
		}
		
		System.out.println("getAMLRecordsByALMIDs :"+listconnectionsyncdatas);
		
		return listconnectionsyncdatas;
	}

	// select wf.WORKORDERID, wf.UDF_Long1 as ALM_ID, wf.UDF_CHAR2 as Severity,
	// acc.ORG_NAME as AccountType from Workorder_Fields as wf
	// inner join WorkOrder as wo on wo.WORKORDERID = wf.WORKORDERID inner join
	// AccountDefinition as acc on wo.SITEID = acc.DEFAULTSITEID
	// where wf.UDF_CHAR7 = 'Assigned' or wf.UDF_CHAR7 ='Resolved' and wf.UDF_CHAR2
	// is not null and wf.UDF_Long1 is null
	//

}
