package com.igosolutions.uniSync.Modal;

public class ReviewDiagrammeDTO {
        private Long id;
        private int diagramXmlId;
        private String assignedUser;
        private int assignedUserId;
        private String author;
        private String authorUserId;
        private String status;
        private String diagramName;
        private String languageName;
        private String languageCode;
        private String organization;
        private String mapPrivacyType;
    
        // Getters and Setters for all properties
        
        
    
        public Long getId() {
            return id;
        }
    
        public String getMapPrivacyType() {
			return mapPrivacyType;
		}

		public void setMapPrivacyType(String mapPrivacyType) {
			this.mapPrivacyType = mapPrivacyType;
		}

		public void setId(Long id) {
            this.id = id;
        }
    
        public int getDiagramXmlId() {
            return diagramXmlId;
        }
    
        public void setDiagramXmlId(int diagramXmlId) {
            this.diagramXmlId = diagramXmlId;
        }
    
        public String getAssignedUser() {
            return assignedUser;
        }
    
        public void setAssignedUser(String assignedUser) {
            this.assignedUser = assignedUser;
        }
    
        public int getAssignedUserId() {
            return assignedUserId;
        }
    
        public void setAssignedUserId(int assignedUserId) {
            this.assignedUserId = assignedUserId;
        }
    
        public String getAuthor() {
            return author;
        }
    
        public void setAuthor(String author) {
            this.author = author;
        }
    
        public String getAuthorUserId() {
            return authorUserId;
        }
    
        public void setAuthorUserId(String authorUserId) {
            this.authorUserId = authorUserId;
        }
    
        public String getStatus() {
            return status;
        }
    
        public void setStatus(String status) {
            this.status = status;
        }
    
        public String getDiagramName() {
            return diagramName;
        }
    
        public void setDiagramName(String diagramName) {
            this.diagramName = diagramName;
        }
    
        public String getLanguageName() {
            return languageName;
        }
    
        public void setLanguageName(String languageName) {
            this.languageName = languageName;
        }
    
        public String getLanguageCode() {
            return languageCode;
        }
    
        public void setLanguageCode(String languageCode) {
            this.languageCode = languageCode;
        }
    
        public String getOrganization() {
            return organization;
        }
    
        public void setOrganization(String organization) {
            this.organization = organization;
        }
    
    
    
}