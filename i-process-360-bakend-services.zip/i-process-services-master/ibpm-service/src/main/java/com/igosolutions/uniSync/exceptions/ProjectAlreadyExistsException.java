package com.igosolutions.uniSync.exceptions;

public class ProjectAlreadyExistsException extends RuntimeException{
    public ProjectAlreadyExistsException(String message){
        super(message);
    }
}
