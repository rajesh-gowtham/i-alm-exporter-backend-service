package com.igosolutions.uniSync.Service;

import java.util.List;

import com.igosolutions.uniSync.utils.TemplateRequestDto;
import com.igosolutions.uniSync.utils.TemplateResponseDto;

public interface TemplateService {

	public void createTemplates(TemplateRequestDto templateRequestDto, String organization) throws Exception;

	public List<TemplateResponseDto> getAllTemplatesByOrganization(String organization) throws Exception;

	public TemplateResponseDto updateTemplates(TemplateRequestDto templateRequestDto, String organization) throws Exception;

	public String deleteTemplates(List<Long> templateId) throws Exception;

	public TemplateResponseDto getTemplate(Long templateId) throws Exception;

}
