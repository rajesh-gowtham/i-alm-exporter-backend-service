package com.igosolutions.uniSync.Modal;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "comments")
public class ReviewComments {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "comment_id")
    private Long commentId;
	
	@Column(name = "diagram_xml_id", nullable = false)
    private Integer diagramXmlId;

    @Column(name = "current_xml_id", length = 50)
    private String currentXmlId;

    @Column(name = "comment_message", columnDefinition = "TEXT")
    private String commentMessage;

    @Column(name = "time_stamp")
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy:MM:dd HH:mm", timezone = "Asia/Kolkata")
    private Date timeStamp;

    @Column(name = "userid")
    private Long commentedUserId;

    @Column(name = "map_diagram_status", length = 50)
    private String mapDiagramStatus;
    
    @Column(name = "user_name", length = 30)
    private String userName;
    
    @Column(name ="version_name")
    private int versionName;

	@Column(name = "activity_id")
	private String activityId;

	@Column(name = "activity_num")
	private int activityNum;
	
	@Column(name = "flag_toggle_activity")
	private Boolean flagToggleActivity;

	public int getVersionName() {
		return versionName;
	}

	public void setVersionName(int versionName) {
		this.versionName = versionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public Integer getDiagramXmlId() {
		return diagramXmlId;	
	}

	public void setDiagramXmlId(Integer diagramXmlId) {
		this.diagramXmlId = diagramXmlId;
	}

	public String getCurrentXmlId() {
		return currentXmlId;
	}

	public void setCurrentXmlId(String currentXmlId) {
		this.currentXmlId = currentXmlId;
	}

	public String getCommentMessage() {
		return commentMessage;
	}

	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public Long getCommentedUserId() {
		return commentedUserId;
	}

	public void setCommentedUserId(Long commentedUserId) {
		this.commentedUserId = commentedUserId;
	}

	public String getMapDiagramStatus() {
		return mapDiagramStatus;
	}

	public void setMapDiagramStatus(String mapDiagramStatus) {
		this.mapDiagramStatus = mapDiagramStatus;
	}
	
	public Boolean getFlagToggleActivity() {
		return flagToggleActivity;
	}

	public void setFlagToggleActivity(Boolean flagToggleActivity) {
		this.flagToggleActivity = flagToggleActivity;
	}

	@PrePersist
    protected void onCreate() {
        if (this.timeStamp == null) {
            this.timeStamp = new Date();
        }
    }

	@Override
	public String toString() {
		return "ReviewComments [commentId=" + commentId + ", diagramXmlId=" + diagramXmlId + ", currentXmlId="
				+ currentXmlId + ", commentMessage=" + commentMessage + ", timeStamp=" + timeStamp
				+ ", commentedUserId=" + commentedUserId + ", mapDiagramStatus=" + mapDiagramStatus + ", userName="
				+ userName + ", versionName=" + versionName + ", activityId=" + activityId + ", activityNum="
				+ activityNum + ", flagToggleActivity=" + flagToggleActivity + "]";
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public int getActivityNum() {
		return activityNum;
	}

	public void setActivityNum(int activityNum) {
		this.activityNum = activityNum;
	}
	

	

	
	

}
