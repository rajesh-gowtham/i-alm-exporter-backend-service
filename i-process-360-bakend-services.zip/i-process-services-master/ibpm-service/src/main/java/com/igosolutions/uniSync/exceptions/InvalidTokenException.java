package com.igosolutions.uniSync.exceptions;

import org.springframework.security.core.AuthenticationException;

@SuppressWarnings("serial")
public class InvalidTokenException extends AuthenticationException {

	public InvalidTokenException(String message) {
        super(message);
    }
}
