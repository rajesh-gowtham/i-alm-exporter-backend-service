package com.igosolutions.uniSync.Modal;

import java.util.List;

public class UserCustomerProjectDTO {
    private Long userId;
    private String username;
    private List<ProjectDTO> projects;
    private List<CustomerDTO> customers;
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public List<ProjectDTO> getProjects() {
        return projects;
    }
    public void setProjects(List<ProjectDTO> projects) {
        this.projects = projects;
    }
    public List<CustomerDTO> getCustomers() {
        return customers;
    }
    public void setCustomers(List<CustomerDTO> customers) {
        this.customers = customers;
    }
    
    
}
