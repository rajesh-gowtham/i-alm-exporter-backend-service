package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;

public interface BpnmUserDiagrammeRepository extends JpaRepository<BpnmUserDiagramme, Integer> {


	@Transactional
	@Modifying
	@Query("update BpnmUserDiagramme s set s.xmlData = :xmlData, s.languageCode =:languageCode, s.languageName = :languageName, s.diagramName = :diagramName where s.userid = :userid and s.diagramXmlId = :diagramXmlId")
	void update(@Param("userid") Long userid, @Param("xmlData") String xmlData,@Param("languageCode") String languageCode,@Param("languageName") String languageName, @Param("diagramName")String diagramName, @Param("diagramXmlId") int diagramXmlId);

	@Transactional
	@Query("SELECT b FROM BpnmUserDiagramme b WHERE b.diagramXmlId = :diagramXmlId")
	public BpnmUserDiagramme getByDiagramXmlId(@Param("diagramXmlId") int diagramXmlId);

	//	@Transactional
	//	@Query(value="SELECT b FROM BpnmUserDiagramme b WHERE b.userid = :userId")
	//	public List<BpnmUserDiagramme> getByuserid(@Param("userId")Long userId);


//	@Transactional
//	@Modifying
//	@Query("update BpnmUserDiagramme s set s.storageType =:storageType, s.configName =:configName, s.configId = :configId where s.diagramXmlId = :diagramXmlId")
//	void updateStorageType(@Param("diagramXmlId") int diagramXmlId,@Param("storageType") String storageType, @Param("configName") String configName,@Param("configId") String configId);


	@Transactional
	@Modifying
	@Query("DELETE FROM BpnmUserDiagramme b WHERE b.userid = :userid")
	void deleteByUserId(Long userid);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM BpnmUserDiagramme u WHERE u.diagramXmlId IN :diagramXmlIds")
	void deleteByIds(@Param("diagramXmlIds") List<Integer> diagramXmlIds);

	
	@Transactional
	@Query(value="SELECT d FROM BpnmUserDiagramme d WHERE d.diagramXmlId =:diagramXml_Id")
	BpnmUserDiagramme findbyDiagramXmlId(@Param("diagramXml_Id")int diagramId);

	@Transactional
	@Query(value="SELECT c FROM BpnmUserDiagramme c WHERE c.userid = :userId")
	List<BpnmUserDiagramme> findByUserId(Long userId);

	@Transactional
	@Query(value="SELECT u FROM BpnmUserDiagramme u WHERE u.userid = :userId AND u.diagramXmlId = :diagrmXmlId ")
	BpnmUserDiagramme findbyUserIdDiagramXmlId( @Param("userId")Long userId,
			@Param("diagrmXmlId")int diagrmXmlId);

//	@Transactional
//	@Modifying
//	@Query("update BpnmUserDiagramme k set k.storageType = :storageType, k.configName = :configName, k.configId = :configId, k.diagramName = :diagramName where k.diagramXmlId = :diagramXmlId ")
//	void updateDiagram(
//			@Param("diagramName") String diagramName,
//			@Param("storageType") String storageType, 
//			@Param("configId") String configId, 
//			@Param("configName") String configName, 
//			@Param("diagramXmlId") int diagramXmlId);

	@Transactional
	@Modifying
	@Query("update BpnmUserDiagramme s set s.template =:template where s.diagramXmlId = :diagramXmlId")
	void updateTemplate(@Param("diagramXmlId") int diagramXmlId,@Param("template") String template);

	//	@Transactional
	//    @Modifying
	//    @Query("update BpnmUserDiagramme s set s.xmlData =:xmlData where s.diagramXmlId = :diagramXmlId")
	//    void updateXmlData(@Param("diagramXmlId") int diagramXmlId,@Param("xmlData") String xmlData);

	@Transactional
	@Modifying
	@Query("update BpnmUserDiagramme s set s.xmlData =:xmlData, s.languageName =:languageName, s.languageCode =:languageCode where s.diagramXmlId = :diagramXmlId")
	void updateXmlDataAndLanguage(@Param("diagramXmlId") int diagramXmlId,@Param("xmlData") String xmlData, @Param("languageName") String languageName, @Param("languageCode") String languageCode);



//	@Transactional
//	@Modifying
//	@Query("update BpnmUserDiagramme k set k.storageType = :storageType, k.configName = :configName, k.configId = :configId, k.diagramName = :diagramName, k.template = :template, k.languageCode = :languageCode, k.languageName = :languageName, k.xmlData = :xmlData where k.diagramXmlId = :diagramXmlId")
//	void updateDiagram(
//	    @Param("diagramName") String diagramName,
//	    @Param("storageType") String storageType, 
//	    @Param("configId") String configId, 
//	    @Param("configName") String configName, 
//	    @Param("template") String template,
//	    @Param("languageCode") String languageCode, 
//	    @Param("languageName") String languageName, 
//	    @Param("xmlData") String xmlData, 
//	    @Param("diagramXmlId") int diagramXmlId);
	
	@Transactional
	@Modifying
	@Query("update BpnmUserDiagramme k set  k.diagramName = :diagramName, k.template = :template, k.languageCode = :languageCode, k.languageName = :languageName, k.xmlData = :xmlData where k.diagramXmlId = :diagramXmlId")
	void updateDiagram(
	    @Param("diagramName") String diagramName,
	    @Param("template") String template,
	    @Param("languageCode") String languageCode, 
	    @Param("languageName") String languageName, 
	    @Param("xmlData") String xmlData, 
	    @Param("diagramXmlId") int diagramXmlId);

	
	@Transactional
	@Modifying
	@Query("DELETE FROM BpnmUserDiagramme b WHERE b.diagramXmlId = :diagramXmlId")
	void deleteByDiagramXmlId(@Param("diagramXmlId")Integer diagramXmlId);

	@Transactional
	@Modifying
	@Query("UPDATE BpnmUserDiagramme b SET b.diagramName = :diagramName WHERE b.diagramXmlId IN :diagramXmlIds")
	int updateDiagrams(@Param("diagramName") String diagramName,
			@Param("diagramXmlIds") List<Integer> diagramXmlIds);

	@Transactional
	@Modifying
	@Query("UPDATE BpnmUserDiagramme b SET b.timeStamp=:currentTimestamp WHERE b.diagramXmlId = :diagramXmlId")
	void updateTimeStamp(@Param("diagramXmlId")int diagramXmlId,@Param("currentTimestamp") String currentTimestamp);
	
	@Transactional
    @Query("SELECT COUNT(u) FROM BpnmUserDiagramme u WHERE u.template IN :templateIds")
    int countByTemplateIds(@Param("templateIds") List<String> templateIds);
	
	@Transactional
	@Query("SELECT DISTINCT u.template FROM BpnmUserDiagramme u WHERE u.template IN :templateIds")
	List<String> findUsedTemplateIds(@Param("templateIds") List<String> templateIds);
	
	
    @Query("SELECT d FROM BpnmUserDiagramme d WHERE d.diagramXmlId IN:diagramXmlIdByMapId")
	List<BpnmUserDiagramme> findbyDiagramXmlId(@Param("diagramXmlIdByMapId") List<Integer> diagramXmlIdByMapId);
	
	/*
	 * @Transactional
	 * 
	 * @Modifying
	 * 
	 * @Query("update BpnmUserDiagramme b set template =:NULL WHERE b.template IN :templateId"
	 * ) void nullTemplateById(@Param("templateId")List<String> templateId);
	 */
}

