package com.igosolutions.uniSync.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.igosolutions.uniSync.Modal.ALMServerErrorResponse;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ProjectNotBelongToAssignedCustomerException.class)
    public ResponseEntity<String> handleProjectNotBelongToAssignedCustomerException(ProjectNotBelongToAssignedCustomerException e) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(ProjectNotFoundException.class)
    public ResponseEntity<String> handleProjectNotFoundException(ProjectNotFoundException e) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(ALMServerException.class)
    public ResponseEntity<ALMServerErrorResponse> handleALMServerException(ALMServerException ex) {
        ex.printStackTrace();
        ALMServerErrorResponse response = new ALMServerErrorResponse();
        if (ex.getMessage().contains("401")) {
            response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            response.setError("Unauthorized");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
        else if (ex.getMessage().contains("403")) {
            response.setStatusCode(HttpStatus.FORBIDDEN.value());
            response.setError("Forbidden");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }
        else {
            response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setError("ALM Server Error");
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
