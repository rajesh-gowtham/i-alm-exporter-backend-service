package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.igosolutions.uniSync.Modal.Templates;

public interface TemplateRepository extends JpaRepository<Templates, Long> {
	

	@Query("SELECT s FROM Templates s WHERE s.templateName = :templateName AND s.organization = :organization")
   	Templates findbyTemplateName(@RequestParam("templateName")String templateName,  @Param("organization")String organization);
      
    
    @Query("SELECT s FROM Templates s WHERE s.templateId=:templateId")
	Templates findByTemplateId(@Param("templateId") Long templateId);

	@Transactional
	@Modifying
	@Query("UPDATE Templates t SET t.templateName = :templateName, t.companyName = :companyName, t.companyLogo = :companyLogo, " +
	           "t.colorCode = :colorCode, t.navUpIcon = :navUpIcon, t.navPreviousIcon = :navPreviousIcon, t.navHomeIcon = :navHomeIcon, " +
	           "t.iconSource = :iconSource, t.navUpImg = :navUpImg, t.navPreviousImg = :navPreviousImg, t.navHomeImg = :navHomeImg, " +
	           "t.imgname = :imgname, t.imgcontent = :imgcontent, t.organization = :organization WHERE t.templateId = :templateId")
	void updateTemplateById(@Param("templateId") Long templateId, 
	                           @Param("templateName") String templateName, 
	                           @Param("companyLogo") String companyLogo, 
	                           @Param("companyName") String companyName, 
	                           @Param("colorCode") String colorCode, 
	                           @Param("navUpIcon") String navUpIcon, 
	                           @Param("navPreviousIcon") String navPreviousIcon, 
	                           @Param("navHomeIcon") String navHomeIcon, 
	                           @Param("iconSource") String iconSource, 
	                           @Param("navUpImg") String navUpImg, 
	                           @Param("navPreviousImg") String navPreviousImg, 
	                           @Param("navHomeImg") String navHomeImg, 
	                           @Param("imgname") String imgname, 
	                           @Param("imgcontent") String imgcontent,
							   @Param("organization") String organization);
	
	/*
	 * @Transactional
	 * 
	 * @Modifying
	 * 
	 * @Query("DELETE m FROM Templates WHERE m.templateId IN :templateId") void
	 * deleteById(List<Long> templateId);
	 */
	
	@Modifying
    @Transactional
    @Query("DELETE FROM Templates t WHERE t.templateId IN :templateIds")
    void deleteByTemplateIds(@Param("templateIds") List<Long> templateIds);

	//@Query("SELECT FROM Templates t WHERE t.organization =:organization")
    List<Templates> findAllByOrganization(@Param("organization")String organization);
   

}
