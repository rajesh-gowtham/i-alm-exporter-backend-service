package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.igosolutions.uniSync.Modal.Notification;
import com.igosolutions.uniSync.Modal.UserReadStatus;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.NotificationRepository;

@Service
public class NotificationService {

    @Autowired
    NotificationRepository notificationRepository;

    @Autowired
    BpmnUserRepository userRepository;

    public List<Notification> getUnreadNotifications(Integer diagramXmlId, Long userId) {
        // Retrieve all notifications by diagramXmlId
        List<Notification> allNotifications = notificationRepository.findAllByDiagramXmlId(diagramXmlId);

        // Iterate through notifications and add userId to UserReadStatus if not already
        // present
        for (Notification notification : allNotifications) {
            boolean userStatusExists = notification.getUserReadStatuses().stream()
                    .anyMatch(status -> status.getUserId().equals(userId));

            // If the user status does not exist, add it with isRead = false
            if (!userStatusExists) {
                notification.getUserReadStatuses().add(new UserReadStatus(userId, false));
                notificationRepository.saveAndFlush(notification); // Save changes to the database
            }
        }

        // After updating, filter and return unread notifications for the user
        return allNotifications.stream()
                .filter(notification -> notification.getUserReadStatuses().stream()
                        .anyMatch(status -> status.getUserId().equals(userId) && !status.getIsRead()))
                .collect(Collectors.toList());
    }


    public void markAsReadForUser(List<Long> notificationIds, Long userId) {
        List<Notification> notifications = notificationRepository.findAllById(notificationIds);
         // Check if all notification IDs were found
        if (notifications.size() != notificationIds.size()) {
            List<Long> foundIds = notifications.stream().map(Notification::getId).collect(Collectors.toList());
            List<Long> missingIds = notificationIds.stream()
                    .filter(id -> !foundIds.contains(id))
                    .collect(Collectors.toList());
            throw new RuntimeException("Notifications not found for IDs: " + missingIds);
        }

        // Find the user status in the list; if not found, add it
        for (Notification notification : notifications) {
            UserReadStatus userReadStatus = notification.getUserReadStatuses().stream()
                    .filter(status -> status.getUserId().equals(userId))
                    .findFirst()
                    .orElse(null);

            if (userReadStatus == null) {
                // UserReadStatus not present, add it with isRead = true
                
                notification.getUserReadStatuses().add(new UserReadStatus(userId, true));
            } else {
                // UserReadStatus found, update isRead to true
                userReadStatus.setIsRead(true);
            }
        }
       

        // Save the updated notification
        notificationRepository.saveAllAndFlush(notifications);
    }


    public void createNotification(Long targetUserId, Integer diagramXmlId, String role,Long commentId) {
        Notification notification = new Notification();
        notification.setDiagramXmlId(diagramXmlId);
        notification.setUserRole(role);
        notification.setCommentId(commentId);
        
        // Create a UserReadStatus entry for the target user with isRead = false
        UserReadStatus userReadStatus = new UserReadStatus(targetUserId, false);
        
        // Add the UserReadStatus to the notification's userReadStatuses list
        notification.getUserReadStatuses().add(userReadStatus);
        
        // Save the notification to the repository
        notificationRepository.save(notification);
    }
}
