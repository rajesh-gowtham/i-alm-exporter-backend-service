package com.igosolutions.uniSync.ServiceImpl;

import java.io.IOException;
import java.util.Map;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.DataSource;
import com.igosolutions.uniSync.Modal.FilesData;
import com.igosolutions.uniSync.Modal.SharePointDetails;
import com.igosolutions.uniSync.Modal.SharepointAccessDTO;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.DataSourceRepository;
import com.igosolutions.uniSync.Respository.FileRepository;
import com.igosolutions.uniSync.Respository.SharePointRepository;
import com.igosolutions.uniSync.Service.SharePointService;

@Service
public class SharePointServiceImpl implements SharePointService{
	

	@Autowired
	public DataSourceRepository repo;
	
    @Autowired
    private SharePointRepository sharePointRepository;
    @Autowired
    BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
    
    @Autowired
    FileRepository fileRepository;
    
    private String document_Id = null;
    private String diagramXml_Id = null; 
    private String current_Xml_Id = null;
    private String activity_Id = null;
    private String file_Name = null;
    
    private static final String CHARACTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int LENGTH = 32;
    
    Logger log = LoggerFactory.getLogger(SharePointServiceImpl.class);

	@Override
	public String uploadDocument(MultipartFile file, String configId) throws Exception{
		
		try {
		        log.info("Upload document Request{}",file);
		        
		        //getting sharepoint credentials from data source db
		        DataSource source = repo.findByDatasourceId(Long.parseLong(configId));
		        byte[] fileBytes = file.getBytes();
		        //This is odd coded Need to remove
		        String fileName =file.getOriginalFilename();
		        
		        System.out.println("This is the requested  file name   :  "+ fileName);
				//filename="1009/1/Activity_0ek6ut5/APMT Progress Report 04 Jan 2024 .pdf
		        String[] parts = fileName.split("/");

		        if (parts.length == 4) {
		        	 diagramXml_Id = parts[0];
		             current_Xml_Id = parts[1];
		             activity_Id = parts[2];
		             file_Name = parts[3];
		        }
		        String uploaded_File_Name = activity_Id+"_"+file_Name;

		        SharePointClient sharePointClient = new SharePointClient(source.getClientId(), source.getClientSecret(), source.getSiteName(), source.getTenantId());
		        
		       System.out.println("This is the uploaded file name  :"+uploaded_File_Name);
		       int diagramId = Integer.parseInt(diagramXml_Id);
		       BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramId); 
              
               
               SharePointDetails sharePointDetailsUpload = new SharePointDetails();
               if(bpnmUserDiagramme != null) {
            	   SharePointDetails SharePointDetails = sharePointRepository.findByDiagramCurrentActivity(diagramXml_Id,current_Xml_Id,activity_Id,file_Name);
               if(SharePointDetails == null) {
            	   document_Id = sharePointClient.uploadFile(fileBytes,diagramXml_Id,current_Xml_Id, uploaded_File_Name);
            	   
                  if(document_Id != null) {
					sharePointDetailsUpload.setDiagramXmlId(diagramXml_Id);
					sharePointDetailsUpload.setCurrentXmlId(current_Xml_Id);
					sharePointDetailsUpload.setActivityId(activity_Id);
					sharePointDetailsUpload.setDocumentId(document_Id);
					sharePointDetailsUpload.setFileName(file_Name);
					sharePointDetailsUpload.setConfigId(configId);
					sharePointDetailsUpload.setStorageType("SharePoint");
					sharePointRepository.save(sharePointDetailsUpload);
            	   }
            	   else {
            		   throw new Exception("Failed to upload document");
            		   }
               }
               else {
            	   sharePointClient.deleteDocument(sharePointRepository,SharePointDetails.getDocumentId(),SharePointDetails.getId());
            	   document_Id = sharePointClient.uploadFile(fileBytes,diagramXml_Id,current_Xml_Id, uploaded_File_Name);
            	   if(document_Id != null) {
            	   sharePointDetailsUpload.setDiagramXmlId(diagramXml_Id);
            	   sharePointDetailsUpload.setCurrentXmlId(current_Xml_Id);
            	   sharePointDetailsUpload.setActivityId(activity_Id);
            	   sharePointDetailsUpload.setDocumentId(document_Id);
            	   sharePointDetailsUpload.setFileName(file_Name);
            	   sharePointDetailsUpload.setConfigId(configId);
            	   sharePointDetailsUpload.setStorageType("SharePoint");
            	   sharePointRepository.save(sharePointDetailsUpload);
            	   }
            	   else {
            		   throw new Exception("Failed to update document");
            	   }
               }
               }
               else {
            	   throw new Exception("The diagram level id not matched");
               }
                
                log.info("Document uploaded here {}",document_Id);
		    } catch (Exception e) {
		        e.printStackTrace();
		        throw new Exception(e.getMessage());
		    }
		return document_Id;
		
	}
	
	@SuppressWarnings("unused")
	@Override
	public byte[] getFile(String documentId, String file_name)
			throws Exception {
				
		try {
			SharePointDetails SharePointDetails = sharePointRepository.findByDocumentId(documentId); 
            DataSource source = repo.findByDatasourceId(Long.parseLong(SharePointDetails.getConfigId()));
			
			SharePointClient sharePointClient = new SharePointClient(source.getClientId(), source.getClientSecret(), source.getSiteName(), source.getTenantId()); 
			log.info("Document retrieved from   SharePointServiceImpl : ",file_name);
			
			if(SharePointDetails != null) {
				log.info("Document retrieved suessfully from SharePointServiceImpl : ",file_name);
				return sharePointClient.getFile(SharePointDetails.getDiagramXmlId(),SharePointDetails.getCurrentXmlId(),SharePointDetails.getActivityId(), file_name); 
			}
			else
			{
				throw new Exception("Failed to get file: Document not exist");
			}
			
		} catch(Exception e) { 
			e.printStackTrace(); 
			throw new IOException("Failed to get file: " + e.getMessage()); }
	}

	
	@Override 
	  public Object deleteDocument(String diagram_xml_id, String current_xml_id, String activity_id, String file_name, String configId) throws Exception {
		
		  DataSource source = repo.findByDatasourceId(Long.parseLong(configId));
		 
		  SharePointClient sharePointClient = new SharePointClient(source.getClientId(), source.getClientSecret(), source.getSiteName(), source.getTenantId()); 
		  
		  SharePointDetails sharePointDetails = sharePointRepository.findByDiagramCurrentActivity(diagram_xml_id,
					current_xml_id, activity_id,file_name); 
		  
		  if(sharePointDetails!=null) {
			  return sharePointClient.deleteDocument(sharePointRepository,sharePointDetails.getDocumentId(),sharePointDetails.getId());
		  }
		  else {
			  throw new Exception("Document not found, It may have been deleted.");  
		  }
		 
	  
	  }

	@Override
	public String uploadDocumentsDb(MultipartFile file) throws Exception {
		try {
			log.info("Upload document Request{}",file);


			byte[] fileBytes = file.getBytes();
			String fileName = file.getOriginalFilename();

			System.out.println("This is the requested  file name   :  "+ fileName);
			String[] parts = fileName.split("/");

			if (parts.length == 4) {
				diagramXml_Id = parts[0];
				current_Xml_Id = parts[1];
				activity_Id = parts[2];
				file_Name = parts[3];
			}
			String uploaded_File_Name = file_Name;
			int diagramId = Integer.parseInt(diagramXml_Id);
			BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramId);
			if(bpnmUserDiagramme != null) {
				FilesData filesData = fileRepository.findByDiagramXmlIdAndCurrentXmlIdAndActivityId(diagramId, current_Xml_Id, activity_Id,uploaded_File_Name);
				if(filesData == null) {
					FilesData fileData = new FilesData();
					fileData.setDiagramXmlId(diagramId);
					fileData.setCurrentXmlId(current_Xml_Id);
					fileData.setActivityId(activity_Id);
					fileData.setFileContent(fileBytes);
					fileData.setFileName(uploaded_File_Name);
					FilesData savedFileData = fileRepository.save(fileData);
					log.info("The document has been uploaded to the DB files_data");
					SharePointDetails sharePointDetailsUpload = new SharePointDetails();
					sharePointDetailsUpload.setDiagramXmlId(String.valueOf(diagramId));
					sharePointDetailsUpload.setCurrentXmlId(current_Xml_Id);
					sharePointDetailsUpload.setActivityId(activity_Id);
					sharePointDetailsUpload.setDocumentId(String.valueOf(savedFileData.getId()));
					sharePointDetailsUpload.setFileName(uploaded_File_Name);
					sharePointDetailsUpload.setConfigId(null);
					sharePointDetailsUpload.setStorageType("Database");
					sharePointRepository.save(sharePointDetailsUpload);

					return String.valueOf(savedFileData.getId());
				}

				else {
					filesData.setFileContent(fileBytes);
					fileRepository.updateFileContent(diagramId,current_Xml_Id,activity_Id,uploaded_File_Name,fileBytes);
					log.info("The document has been updated to the DB files_data");
					return String.valueOf(String.valueOf(filesData.getId()));
				}

			}

			else {
				throw new Exception("The diagram level id not matched");
			}

		}catch(Exception ex) {
			    log.error("An error occurred while uploading the document", ex);
		        throw ex;
		}
	}
	
	 public static String generateRandomString() {
	        Random random = new Random();
	        StringBuilder sb = new StringBuilder(LENGTH);
	        
	        for (int i = 0; i < LENGTH; i++) {
	            int index = random.nextInt(CHARACTERS.length());
	            sb.append(CHARACTERS.charAt(index));
	        }
	        
	        return sb.toString();
	    }

	
	

		@Override
		public ResponseEntity<?> validateCredentials(SharepointAccessDTO sharepointAccessDTO) {
			log.info("Validating client credentials");
		
			// Step 1: Obtain access token
			String tokenUrl = "https://login.microsoftonline.com/" + sharepointAccessDTO.getTenantId() + "/oauth2/token";
			RestTemplate restTemplate = new RestTemplate();
		
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
			MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
			requestBody.add("client_id", sharepointAccessDTO.getClientId());
			requestBody.add("client_secret", sharepointAccessDTO.getClientSecret());
			requestBody.add("grant_type", "client_credentials");
			requestBody.add("resource", "https://graph.microsoft.com/");
		
			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(requestBody, headers);
		
			try {
				// Making the request to obtain the access token
				ParameterizedTypeReference<Map<String, Object>> responseType = new ParameterizedTypeReference<Map<String, Object>>() {};
				ResponseEntity<Map<String, Object>> response = restTemplate.exchange(tokenUrl, HttpMethod.POST, request, responseType);
		
				if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
					// Access token retrieved
					String accessToken = (String) response.getBody().get("access_token");
		
					// Step 2: Validate siteId using the retrieved access token
					String siteId = getSiteIdByName(sharepointAccessDTO.getSiteName(), sharepointAccessDTO, accessToken);
					String siteUrl = "https://graph.microsoft.com/v1.0/sites/" + siteId;
		
					HttpHeaders siteHeaders = new HttpHeaders();
					siteHeaders.setBearerAuth(accessToken); // Set the token in Authorization header
					HttpEntity<Void> siteRequest = new HttpEntity<>(siteHeaders);
		
					try {
						ResponseEntity<Map<String, Object>> siteResponse = restTemplate.exchange(siteUrl, HttpMethod.GET, siteRequest, responseType);
		
						if (siteResponse.getStatusCode() == HttpStatus.OK) {
							return new ResponseEntity<>("Client credentials and siteId are valid", HttpStatus.OK);
						} else {
							log.error("Invalid siteId. Status code: " + siteResponse.getStatusCode());
							return new ResponseEntity<>("Invalid siteId. Status code: " + siteResponse.getStatusCode(), HttpStatus.BAD_REQUEST);
						}
					} catch (HttpClientErrorException e) {
						log.error("Invalid siteId: " + e.getResponseBodyAsString());
						return new ResponseEntity<>("Invalid siteId: " + e.getResponseBodyAsString(), HttpStatus.NOT_ACCEPTABLE);
					}
				} else {
					log.error("Failed to validate client credentials. Status code: " + response.getStatusCode());
					return new ResponseEntity<>("Failed to validate client credentials. Status code: " + response.getStatusCode(), HttpStatus.BAD_REQUEST);
				}
			} catch (HttpClientErrorException e) {
				log.error("Invalid client credentials: " + e.getResponseBodyAsString());
				return new ResponseEntity<>("Invalid client credentials: " + e.getResponseBodyAsString(), HttpStatus.NOT_ACCEPTABLE);
			} catch (Exception e) {
				log.error("An error occurred while validating client credentials", e);
				throw new RuntimeException("An error occurred while validating client credentials", e);
			}
		}

		public String getSiteIdByName(String siteName, SharepointAccessDTO sharepointAccessDTO, String accessToken) {
			// Prepare the API URL
			String hostname = sharepointAccessDTO.getHostName(); // Replace with actual SharePoint domain
			String siteUrl = "https://graph.microsoft.com/v1.0/sites/" + hostname + ":/sites/" + siteName;

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setBearerAuth(accessToken); // Set the access token in the header
			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			try {
				// Make the request to get the site details
				ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
						siteUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Map<String, Object>>() {
						});

				if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
					String siteId = (String) response.getBody().get("id"); // Extract the siteId from the response
					return siteId; // Return the siteId
				} else {
					log.error("Failed to get site details. Status code: " + response.getStatusCode());
					throw new RuntimeException("Failed to get site details.");
				}
			} catch (HttpClientErrorException e) {
				log.error("Error retrieving site by name: " + e.getResponseBodyAsString());
				throw e;
			}
		}


}
