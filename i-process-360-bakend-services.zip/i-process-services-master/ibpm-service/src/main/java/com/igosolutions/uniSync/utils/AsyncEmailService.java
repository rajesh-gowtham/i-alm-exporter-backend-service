package com.igosolutions.uniSync.utils;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.constants.UserRole;
import com.igosolutions.uniSync.constants.UtilsConstants.MailContents;



@Service
public class AsyncEmailService {
	
	//@Value("${email.cc}")
    private List<String> ccMail;
	
	@Value("${smtp.email-username}")
    private String fromMail;

    @Autowired
    private JavaMailSender javaMailSender;
    
    @Autowired
    private BpmnUserRepository bpmnUserRepository;
    
	
	  @Autowired 
	  public AsyncEmailService(JavaMailSender javaMailSender) {
	  this.javaMailSender = javaMailSender;
	  }
	 

    @Async
    public void sendEmail(SimpleMailMessage message) {
        javaMailSender.send(message);
    }
    
    @Async
    public void sendEmail(MimeMessage message) {
        javaMailSender.send(message);
    }
    
    public void sendEmailWithPdf(MimeMessage message) {
        javaMailSender.send(message);
    }
    
    @Async
    public void sendMail(SimpleMailMessage message) {
        javaMailSender.send(message);
    }
    
    
    @Async
    public void sendLicenseExpiprationEmail(SimpleMailMessage message) {
        javaMailSender.send(message);
    }
    
    
    
    
	public void sendMail(String mail, String subject, String text) {
		try {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(mail);
		//message.setCc(ccMail.toArray(new String[0]));
		message.setSubject(subject);
		message.setText(text);
		message.setFrom(fromMail);
        sendEmail(message);
		}catch (Exception e) {
            // Handle the exception properly in your production code
            e.printStackTrace();
        }
	}
	
	 @Bean
	  public TaskExecutor taskExecutor() {
	        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	        executor.setCorePoolSize(10); 
	        executor.setMaxPoolSize(20); 
	        executor.setQueueCapacity(100);
	        executor.setThreadNamePrefix("EmailThread-");
	        executor.initialize();
	        return executor;
	    }

    @Async
	public void sendMailLink(String userEmail, String subject, String text) {
		MimeMessage message = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(userEmail);

			//helper.setCc(ccMail.toArray(new String[0]));

            helper.setSubject(subject);
            helper.setText(text, true);
            helper.setFrom(fromMail);
            sendEmail(message);
        } catch (MessagingException e) {
            // Handle the exception properly in your production code
            e.printStackTrace();
        }
		
	}
	
	
	@Async
	public void sendMail(List<String> emails, String subject, String text) {
		
		List<String> emailAddress = emails;
		
		List<BpmnUser> bpmnUser = new ArrayList<>();
		
		List<String> admins = new ArrayList<>();
	   
		List<String> editors = new ArrayList<>();
		
		List<String> reviewers = new ArrayList<String>();
		
		List<String> cc = new ArrayList<String>();
		
		List<String> viewers = new ArrayList<String>();
		
		SimpleMailMessage message = new SimpleMailMessage();
		
		try {
	    if(subject.equals(MailContents.SPECIFIC_USER_ADDED_IN_MAP_SUBJECT) || subject.equals(MailContents.PUBLIC_USER_ADDED_IN_MAP_SUBJECT)) {
		
			// cc.addAll(ccMail); 
		
				
		}
			
		else if(subject.equals(MailContents.REQUEST_FOR_REVIEW_SUBJECT)) {
			
			bpmnUser = bpmnUserRepository.findByEmail(emailAddress);
			
			for (BpmnUser user : bpmnUser) {
		        if (UserRole.REVIEWER.getRole().equalsIgnoreCase(user.getRole())) {
		        	reviewers.add(user.getEmail());
		           
		        } else if (UserRole.EDITOR.getRole().equalsIgnoreCase(user.getRole())) {
		            editors.add(user.getEmail());
		            
		        }
		    }
			emailAddress = reviewers;
			cc= editors;
			
			// cc.addAll(ccMail); 
		
			
		}
		else if(subject.equals(MailContents.REVERT_DRAFT_SUBJECT)) {
			
         bpmnUser = bpmnUserRepository.findByEmail(emailAddress);
			
			for (BpmnUser user : bpmnUser) {
		        if (UserRole.EDITOR.getRole().equalsIgnoreCase(user.getRole())) {
		        	editors.add(user.getEmail());
		           
		        } else {
					ccMail.add(user.getEmail()); 
					 
		            
		        }
		    }
			emailAddress = editors;			
			
		}
		
		else if(subject.equals(MailContents.APPROVED_SUBJECT)) {
			
			bpmnUser = bpmnUserRepository.findByEmail(emailAddress);
			
			for (BpmnUser user : bpmnUser) {
		        if (UserRole.ADMIN.getRole().equalsIgnoreCase(user.getRole())) {
		            admins.add(user.getEmail());
		           
		        } else if (UserRole.EDITOR.getRole().equalsIgnoreCase(user.getRole())) {
		            editors.add(user.getEmail());
		            
		        }
		    }
			emailAddress = admins;
			cc= editors;
			
			// cc.addAll(ccMail); 
			 
			
		}
		else if(subject.equals(MailContents.PUBLISHED)) {

			bpmnUser = bpmnUserRepository.findByEmail(emailAddress);

			for (BpmnUser user : bpmnUser) {
				if (UserRole.VIEWER.getRole().equalsIgnoreCase(user.getRole())) {
					viewers.add(user.getEmail());

				} else if (UserRole.EDITOR.getRole().equalsIgnoreCase(user.getRole())) {
					editors.add(user.getEmail());

				}
			}
			emailAddress = viewers;
			cc= editors;
			
			 //cc.addAll(ccMail); 
			 

		}
		
		
		
		message.setTo(emailAddress.toArray(new String[0]));
		message.setCc(cc.toArray(new String[0]));
		
		message.setSubject(subject);
		message.setText(text);
		message.setFrom(fromMail);
        sendEmail(message);
		}catch(Exception e) {
			
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

    @Async
	public void sendLicenseExpiprationEmail(List<String> adminMails, long differenceInDays, String validTo) {
      String subject ="License validity reminder";
      String text = null;
		
      try {
			SimpleMailMessage message = new SimpleMailMessage();
			if(differenceInDays == 0) {
				
				message.setTo(adminMails.toArray(new String[0]));
				//message.setCc(ccMail.toArray(new String[0]));
				message.setSubject(subject);
				text = "Dear Admin, \n\n"
					  +"Your iBPM license has been expired, please update the license to contionue \n\n"
					  +"Thanks\n"
					  +"IGO admin";
				message.setText(text);
				message.setFrom(fromMail);
		        sendEmail(message);
			}
			else {
				message.setTo(adminMails.toArray(new String[0]));
				//message.setCc(ccMail.toArray(new String[0]));
				message.setSubject(subject);
				text = "Dear Admin, \n\n"
					  +"Your iBPM license will expire on "+validTo+".\n\n"
					  +"Thanks\n"
					  +"IGO admin";;
				message.setText(text);
				message.setFrom(fromMail);
		        sendEmail(message);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

    @Async
	public void sendCommentsMentionMail(List<String> recipientsEmails, String content, String diagramName) {


		
		List<String> emailAddress = recipientsEmails;
		SimpleMailMessage message = new SimpleMailMessage();
		
		try {
			
		message.setTo(emailAddress.toArray(new String[0]));
		message.setSubject("Update: Your Attention Needed for Comments on "+diagramName);
		message.setText(content);
		message.setFrom(fromMail);
        sendEmail(message);
		}catch(Exception e) {
			
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

    @Async
	public void sendMailWithPdf(List<String> recipientsEmails, MultipartFile pdfMultipartFile, String originalFileName, String diagramName, String content) throws Exception {
		
         System.out.println("********************************");
         System.out.println(pdfMultipartFile);
         //originalFileName,diagramName
		try {
	        if (recipientsEmails == null || recipientsEmails.isEmpty()) {
	            throw new Exception("Recipient email list is empty.");
	        }
	        
	       

	        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
	        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
	        messageHelper.setFrom(fromMail);
	        messageHelper.setTo(recipientsEmails.toArray(new String[0]));
	        messageHelper.setSubject("GroupComments");
	       // messageHelper.setText("Please find attached document for "+diagramName+"."); 
	        messageHelper.setText(content);
	        messageHelper.addAttachment(originalFileName, pdfMultipartFile, "application/pdf");
	        sendEmailWithPdf(mimeMessage);

	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new Exception("Failed to send email: " + e.getMessage());
	    }
	}
}

