package com.igosolutions.uniSync.exceptions;

public class CustomerDeletionException extends RuntimeException{
    public CustomerDeletionException(String message){
        super(message);
    }
}
