 package com.igosolutions.uniSync.Respository;

 import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.AuditTrail;

 @Repository
 public interface AuditTrailRepository extends JpaRepository<AuditTrail, Long> {

    List<AuditTrail> findByEntityId(String userId);

    @Query("SELECT a FROM AuditTrail a WHERE a.entityId = :entityId " +
           "AND (:startDate IS NULL OR a.changedAt >= :startDate) " +
           "AND (:endDate IS NULL OR a.changedAt <= :endDate)")
    List<AuditTrail> findByEntityIdAndDateRange(@Param("entityId") String entityId,
                                                @Param("startDate") LocalDateTime startDate,
                                                @Param("endDate") LocalDateTime endDate);

    
   //  @Modifying
   //  @Query(value = "INSERT INTO audit_trail (entity_name, entity_id, changed_by, organization, changed_at, modification_type) VALUES (:entityName, :entityId, :changedBy, :organization, :changedAt, :modificationType)", nativeQuery = true)
   //  void insertAuditTrail(@Param("entityName") String entityName, @Param("entityId") String entityId, @Param("changedBy") String changedBy, @Param("organization") String organization, @Param("changedAt") LocalDateTime changedAt, @Param("modificationType") String modificationType);
    
    
 }
