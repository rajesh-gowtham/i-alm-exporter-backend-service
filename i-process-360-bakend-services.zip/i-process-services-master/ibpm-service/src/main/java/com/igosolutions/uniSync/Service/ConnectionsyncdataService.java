package com.igosolutions.uniSync.Service;
import java.util.List;

import com.igosolutions.uniSync.Modal.Connectionsyncdata;

public interface ConnectionsyncdataService {

	public void saveConnectionsyncdata(List<Connectionsyncdata> listsyndata);
	
	public List<Connectionsyncdata>  getAllConnectionsyncdata();

	void deleteAllConnectionsyncdata();
	
	public void updateAllMEupdatetimeALMupdatetime(List<Connectionsyncdata> listconnsyncdata);
	
	public void updateALMUpdateTimeandALMCopyUpdateTime(String meID,String updatetime,String meupdatetime);
	
	public void updateMEUpdateTimeAndMECopyUpdateTime(String meID,String updatetime,String almupdtetime);
}
