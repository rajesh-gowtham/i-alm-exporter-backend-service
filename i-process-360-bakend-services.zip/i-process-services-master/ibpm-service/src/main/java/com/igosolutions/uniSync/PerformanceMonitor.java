package com.igosolutions.uniSync;

import java.time.LocalDateTime;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igosolutions.uniSync.Modal.PerformanceMonitorDTO;
import com.igosolutions.uniSync.Respository.PerformanceMonitorRepo;

@Component
@Aspect
public class PerformanceMonitor {

	private static final Logger logger = LoggerFactory.getLogger(PerformanceMonitor.class);
	
	@Around("execution (* com.igosolutions.uniSync.controller..*(..))")
	public Object monitorTime(ProceedingJoinPoint jp) throws Throwable {
		
		long start = System.currentTimeMillis();
		
		LocalDateTime localDateTime = LocalDateTime.now();
		
		Object obj = jp.proceed();
		
		long end = System.currentTimeMillis();
		
		logger.info("Time taken to execute " + jp.getSignature().getName()+ " :"+ (end-start) + "ms");
		
//		performanceMonitorRepo.save(performanceMonitorDTO);
		
		return obj;
		
	}
}
