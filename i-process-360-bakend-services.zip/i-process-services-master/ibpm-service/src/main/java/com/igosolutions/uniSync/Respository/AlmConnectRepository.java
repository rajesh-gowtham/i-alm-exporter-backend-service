package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.igosolutions.uniSync.Modal.ALMConnect;

@Repository
public interface AlmConnectRepository extends JpaRepository<ALMConnect, Long>{

    @Query("SELECT a FROM ALMConnect a WHERE a.mapId = ?1 AND a.diagramXmlId = ?2 AND a.activityId = ?3 AND a.currLevelId = ?4 AND a.almModuleType = ?5")
    ALMConnect findByMapIdAndDiagramXmlIdAndActivityIdAndCurreLevelId(Long mapId, Integer diagramXmlId,
            String activityId, String currLevelId, String almModuleType);

    @Query("SELECT a FROM ALMConnect a WHERE a.dataSource.id = ?1")
    List<ALMConnect> findByDataSourceId(Long id);

    @Query("SELECT a.almConnectId FROM ALMConnect a WHERE a.mapId IN :mapId")
	List<Long> findByMapId(@Param("mapId") Long mapId);
    
    @Modifying
    @Query("DELETE FROM ALMConnect a WHERE a.almConnectId IN :ids")
    void deleteByAlmConnectIds(@Param("ids") List<Long> ids);

    @Modifying
    @Transactional
    @Query("DELETE FROM ALMConnect a WHERE a.almConnectId=:almConnectId")
	void deleteByAlmId(@Param("almConnectId") Long almConnectId);

    
} 