package com.igosolutions.uniSync.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.Customer;
import com.igosolutions.uniSync.Modal.Project;
import com.igosolutions.uniSync.Modal.ProjectDTO;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.CustomerRepository;
import com.igosolutions.uniSync.Respository.ProjectRepository;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.exceptions.CustomerNotFoundException;
import com.igosolutions.uniSync.exceptions.ProjectAlreadyExistsException;
import com.igosolutions.uniSync.exceptions.UserNotFoundException;

@Service
public class ProjectService {

    @Autowired
    ProjectRepository projectRepository;

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    BpmnUserRepository bpmnUserRepository;
    
    public ResponseEntity<?> createProject(ProjectDTO projectDTO) {
        try {
            Customer customer = customerRepository.findById(projectDTO.getCustomerId())
                    .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));

            if (projectRepository.existsByProjectNameAndCustomer(projectDTO.getProjectName(), customer)) {
                throw new ProjectAlreadyExistsException("Project with the same name already exists for this customer");
            }

            Project project = new Project();
            project.setProjectName(projectDTO.getProjectName());
            project.setCustomer(customer);

            Project createdProject = projectRepository.save(project);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdProject);
        } catch (CustomerNotFoundException | ProjectAlreadyExistsException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while creating the project.");
        }
    }
    public ResponseEntity<?> getProjectsByUserId(Long userId) {
        try {
            List<ProjectDTO> assignedProjects =  new ArrayList<ProjectDTO>();
            BpmnUser user = bpmnUserRepository.findById(userId)
					.orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

             if(user.getRole().equalsIgnoreCase(UtilsConstants.RoleConstants.ADMIN) && user.getOrganization() !=null  && user.getOrganization().equalsIgnoreCase(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION)){
                List<Customer> allByOrganization = customerRepository.findAllByOrganization(UtilsConstants.OrganizationConstants.IGO_ORGANIZATION);
                for (Customer customer : allByOrganization) {
                    for (Project project : customer.getProjects()) {
                        ProjectDTO dto = new ProjectDTO();
                            dto.setId(project.getId());
                            dto.setProjectName(project.getProjectName());
                            dto.setCustomerId(project.getCustomer().getId());
                            dto.setCustomerName(project.getCustomer().getCustomerName());
                            assignedProjects.add(dto);
                    }
                }
             }
             else if(user.getRole().equalsIgnoreCase(UtilsConstants.RoleConstants.ADMIN)){
                assignedProjects = user.getCustomers().get(0).getProjects().stream()
                    .map(
                        project -> {
                            ProjectDTO dto = new ProjectDTO();
                            dto.setId(project.getId());
                            dto.setProjectName(project.getProjectName());
                            dto.setCustomerId(project.getCustomer().getId());
                            dto.setCustomerName(project.getCustomer().getCustomerName());
                            return dto;
                        })
					.collect(Collectors.toList());
             }
             else{
                 assignedProjects = user.getProjects().stream()
					.map(project -> {
						ProjectDTO dto = new ProjectDTO();
						dto.setId(project.getId());
						dto.setProjectName(project.getProjectName());
						dto.setCustomerId(project.getCustomer().getId());
                        dto.setCustomerName(project.getCustomer().getCustomerName());
						return dto;
					})
					.collect(Collectors.toList());
                }
            return ResponseEntity.ok(assignedProjects);        
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while retrieving the project for users.");
        }
    }

    public ResponseEntity<?> getUsersByProjectId(Long projectId){
        try {
            Optional<Project> byId = projectRepository.findById(projectId);
            if (byId.isPresent()) {
                List<BpmnUser> users = byId.get().getBpmnUsers();
                List<Map<String, Object>> userList = users.stream().map(user -> {
                    Map<String, Object> userMap = new HashMap<>();
                    userMap.put("userId", user.getUserid());
                    userMap.put("userName", user.getFirstname() + " " + user.getLastname());
                    userMap.put("userEmail", user.getEmail());
                    return userMap;
                }).collect(Collectors.toList());
               
                return ResponseEntity.ok(userList);
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body("An error occurred while retrieving the user for project.");
        }
    }
}
