package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Bpmn;

public interface BPMNRepository extends JpaRepository<Bpmn, Long> {

	@Transactional
	@Query("select s from Bpmn s where s.diagramName = :diagramname")
	List<Bpmn> BpmnByDiagramname(String diagramname);

	@Transactional
    @Query("SELECT b FROM Bpmn b WHERE b.organization = :organization")
    List<Bpmn> findAllByOrganization(@Param("organization") String organization);

	@Transactional
    @Query("SELECT b FROM Bpmn b WHERE b.mapId = :mapId")
	Bpmn findByMapId(@Param("mapId")Long mapId);

	@Query("SELECT b FROM Bpmn b WHERE b.projectId = :projectId")
	List<Bpmn> findByProjectId(Long projectId);
	
}
