package com.igosolutions.uniSync;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectLogging {

	
	private static org.slf4j.Logger log = LoggerFactory.getLogger(AspectLogging.class);
//  execution(* com.igosolutions.uniSync.ServiceImpl..*(..))  
	@Before("execution(* com.igosolutions.uniSync.controller..*(..))")
	void log(JoinPoint jp) {
		log.info("Start method of " + jp.getSignature().getName());
	}
//	execution(* com.igosolutions.uniSync.ServiceImpl..*(..)) || 
	@After("execution(* com.igosolutions.uniSync.controller..*(..))")
	void afterLog(JoinPoint jp) {
		log.info("ending method of " + jp.getSignature().getName());
	}
	
}
