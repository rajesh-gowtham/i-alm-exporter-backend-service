package com.igosolutions.uniSync.constants;

public enum StorageType {

	    SHAREPOINT("SharePoint"),
	    DATABASE("Database");

	    private final String storageType;

	    StorageType(String storageType){
	        this.storageType = storageType;
	    }

		public String getStorageType() {
			return storageType;
		}
}
