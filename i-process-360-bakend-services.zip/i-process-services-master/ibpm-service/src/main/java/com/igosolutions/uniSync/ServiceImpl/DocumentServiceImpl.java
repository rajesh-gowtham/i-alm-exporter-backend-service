package com.igosolutions.uniSync.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.FilesData;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.FileRepository;
import com.igosolutions.uniSync.Service.DocumentService;

@Service
public class DocumentServiceImpl implements DocumentService {
	
	@Autowired
	private FileRepository fileRepository;
	@Autowired
	private BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;

	

	@Override
	public byte[] getDocument(int diagram_xml_id, String current_xml_id, String activity_id, String file_name) throws Exception {
		 FilesData filesData;
		try {
			String uploaded_FileName = file_name;
			int diagramId = diagram_xml_id;
			BpnmUserDiagramme bpnmUserDiagramme = bpnmUserDiagrammeRepository.findbyDiagramXmlId(diagramId); 
			if(bpnmUserDiagramme != null) {
                    System.out.println("bpnmUserDiagramme is not null");
				try {
					 filesData = fileRepository.findByDiagramXmlIdAndCurrentXmlIdAndActivityId(diagramId, current_xml_id, activity_id, uploaded_FileName);
					 System.out.println(diagramId);
					 System.out.println(current_xml_id);
					 System.out.println(activity_id);
					 System.out.println(uploaded_FileName);
					if(filesData != null) {
                     System.out.println("FILE CONTENT IS NOT NULL");
					System.out.println(filesData.getFileContent());
					}
					else {
						throw new Exception("File not found");
					}
				}catch(Exception e) {
					e.printStackTrace();
                   throw new Exception(e.getMessage());

				}
			}
			else
			{
				throw new Exception("Document not found...");
			}

		}catch(Exception e) {
			e.printStackTrace();
           throw new Exception(e.getMessage());
		}
		return filesData.getFileContent();
	}



	@Override
	public void deleteDocument(String documentId) throws Exception {
		try {
			FilesData data =fileRepository.findByFileId(Long.parseLong(documentId));
			if(data!=null) {
				String uploaded_FileName = data.getFileName();
				 FilesData filesData = fileRepository.findByDiagramXmlIdAndCurrentXmlIdAndActivityId(data.getDiagramXmlId(), data.getCurrentXmlId(), data.getActivityId(), uploaded_FileName);
	             System.out.println();
				 if(filesData != null) {
				 fileRepository.deletebyDiagramXmlCurrentXmlActivityFilname(data.getDiagramXmlId(),data.getCurrentXmlId(), data.getActivityId(),uploaded_FileName);
	             }
				 else
	            	 throw new Exception("No document found to delete");
			}else {
				 throw new Exception("Document not found, It may have been deleted.");
			}
			 
            	 
		}catch(Exception e) {
			throw new Exception(e.getMessage());
		}
	}

}
