package com.igosolutions.uniSync.Modal;

import java.util.ArrayList;
import java.util.List;

public class CustomerDTO {
    Long id;
    String customerName;
    List<ProjectDTO> projects = new ArrayList<>();
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
   
   
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public List<ProjectDTO> getProjects() {
        return projects;
    }
    public void setProjects(List<ProjectDTO> projects) {
        this.projects = projects;
    }
    

    
}
