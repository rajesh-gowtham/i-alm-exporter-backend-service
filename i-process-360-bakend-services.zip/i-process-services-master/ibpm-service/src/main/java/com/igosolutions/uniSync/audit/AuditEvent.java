package com.igosolutions.uniSync.audit;

public class AuditEvent {
    private Object entity;
    private String modificationType;

    public AuditEvent(Object entity, String modificationType) {
        this.entity = entity;
        this.modificationType = modificationType;
    }

    public Object getEntity() {
        return entity;
    }

    public String getModificationType() {
        return modificationType;
    }
}
