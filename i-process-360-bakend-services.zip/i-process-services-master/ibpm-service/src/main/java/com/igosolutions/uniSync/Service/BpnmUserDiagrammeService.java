package com.igosolutions.uniSync.Service;

import java.util.List;
import java.util.Map;

import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTO;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTOResponse;


public interface BpnmUserDiagrammeService {

	public Map<String, String> saveOrUpdateXmlData(BpnmUserDiagramme bpnmUserDiagramme);
    
	public BpnmUserDiagramme getDiagrammeByUserId(Long UserId, int diagramXmlId);
	
	public List<BpnmUserDiagramme> getDiagrammeByUserId(Long UserId);

	void saveStorageType(int diagramXmlId, String storageType, String configName, String configId);
	
	public BpnmUserDiagramme createNewDiagrams(Long userId, MapDiagramRequestDTO mapDiagramRequestDTO);
	
	//public List<Map<String, Object>> getDiagrams(Long userId);
    
//	public void deleteMapDiagrams(Long userId, List<BpnmUserDiagramme> requestPayload);
	
	public MapDiagramRequestDTOResponse updateMapDigram(String userId, Long diagramId,
	MapDiagramRequestDTOResponse mapDiagramRequestDTO);
	public void updateOrderTimestamp(int diagramXmlId, String checkType);
	
	public Map<String, Object> getLastSavedXml(Map<String, String> headers, int diagramXmlId) throws Exception;
							
}
