package com.igosolutions.uniSync.ServiceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.igosolutions.uniSync.Modal.ActivityText;
import com.igosolutions.uniSync.Modal.CommentText;
import com.igosolutions.uniSync.Modal.RemainingText;
import com.igosolutions.uniSync.Modal.RequestBodyData;
import com.igosolutions.uniSync.Service.TranslationService;

@Service
public class TranslationServiceImpl implements TranslationService {

    RestTemplate restTemplate = new RestTemplate();
    private static final String TRANSLATION_API_URL = "https://translate.googleapis.com/translate_a/single?client=gtx";

    @Override
    public ResponseEntity<Object> processRequestData(String fromLanguage, String toLanguage, RequestBodyData requestBodyData) {
        String apiUrl = TRANSLATION_API_URL + "&sl=" + fromLanguage + "&tl=" + toLanguage + "&dt=t&q=";

        List<ActivityText> activityTexts = Collections.synchronizedList(new ArrayList<>());
        List<CommentText> oldCommentTexts =  Collections.synchronizedList(new ArrayList<>());
        List<CommentText> newCommentTexts =  Collections.synchronizedList(new ArrayList<>());
        List<RemainingText> remainingTexts = Collections.synchronizedList(new ArrayList<>()) ;
        
        ExecutorService executor = Executors.newFixedThreadPool(10);

        processTextsConcurrently(requestBodyData.getActivityTexts(), apiUrl, activityTexts, this::mapActivityText, executor);
        processTextsConcurrently(requestBodyData.getOldCommentTexts(), apiUrl, oldCommentTexts, this::mapOldCommentTexts, executor);
        processTextsConcurrently(requestBodyData.getNewCommentTexts(), apiUrl, newCommentTexts, this::mapNewCommentTexts, executor);
        processTextsConcurrently(requestBodyData.getRemainingTexts(), apiUrl, remainingTexts, this::mapRemainingText, executor);
        
        executor.shutdown();

        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        RequestBodyData responseBody = new RequestBodyData();
        responseBody.setActivityTexts(activityTexts);
        responseBody.setOldCommentTexts(oldCommentTexts);
        responseBody.setNewCommentTexts(newCommentTexts);
        responseBody.setRemainingTexts(remainingTexts);

        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }

    private <T> void processTextsConcurrently(List<T> texts, String apiUrl, List<T> outputList, TextMapper<T> mapper, ExecutorService executor) {
        int size = texts.size();
        int sixthSize = size / 6;
        int check = size % 6;

        if (size >= 6) {
            List<List<T>> sixths = new ArrayList<>();
            int startIndex = 0;
            for (int i = 0; i < 6; i++) {
                int currentSixthSize = sixthSize + (i < check ? 1 : 0);
                List<T> sixth = texts.subList(startIndex, startIndex + currentSixthSize);
                sixths.add(sixth);
                startIndex += currentSixthSize;
            }

            for (int i = 0; i < 6; i++) {
                int finalI = i;
                executor.execute(() -> {
                    for (T text : sixths.get(finalI)) {
                        T mappedText = mapper.map(apiUrl, text);
                        synchronized (outputList) {
                            outputList.add(mappedText);
                        }
                    }
                });
            }
        } else {
            executor.execute(() -> {
                for (T text : texts) {
                    T mappedText = mapper.map(apiUrl, text);
                    synchronized (outputList) {
                        outputList.add(mappedText);
                    }
                }
            });
        }
    }

    @FunctionalInterface
    private interface TextMapper<T> {
        T map(String apiUrl, T text);
    }

    @SuppressWarnings("unchecked")
    String translateWord(String apiUrl, String value) {
        try {
            if (value.contains("\n")) {
                String[] segments = value.split("\n");
                StringBuilder translatedTextBuilder = new StringBuilder();
    
                for (String segment : segments) {
                    if (!segment.isEmpty()) {
                        String escapedSegment = escapeSpecialCharacters(segment);
                        HttpHeaders headers = new HttpHeaders();
                        headers.add("Content-Type", "application/json; charset=UTF-8");
                        HttpEntity<String> entity = new HttpEntity<>(headers);
    
                        ResponseEntity<Object[]> responseEntity = restTemplate.exchange(apiUrl + escapedSegment, HttpMethod.GET, entity, Object[].class);
                        Object[] responseBody = responseEntity.getBody();
                        List<List<Object>> nestedArrays = (List<List<Object>>) responseBody[0];
                        String translatedSegment = (String) nestedArrays.get(0).get(0);
                        translatedTextBuilder.append(translatedSegment);
                    }
                    translatedTextBuilder.append("\n");
                }
    
                String translatedText = translatedTextBuilder.toString().trim();
                return cleanTranslatedText(translatedText);
            } else {
                String escapedValue = escapeSpecialCharacters(value);
                HttpHeaders headers = new HttpHeaders();
                headers.add("Content-Type", "application/json; charset=UTF-8");
                HttpEntity<String> entity = new HttpEntity<>(headers);
    
                ResponseEntity<Object[]> responseEntity = restTemplate.exchange(apiUrl + escapedValue, HttpMethod.GET, entity, Object[].class);
                Object[] responseBody = responseEntity.getBody();
                List<List<Object>> nestedArrays = (List<List<Object>>) responseBody[0];
                String text = (String)nestedArrays.get(0).get(0);
                return text.replace("%23", "#")
                .replace("%26", "&")
                .replace("%3F", "?");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    // Method to escape only necessary special characters in the string
    private  String escapeSpecialCharacters(String text) {
        return text.replace("#", "%23")
                   .replace("&", "%26")
                   .replace("?", "%3F");
    }
    
    private  String cleanTranslatedText(String translatedText) {
        Pattern pattern = Pattern.compile("%[0-9A-Fa-f]{2}");
        Matcher matcher = pattern.matcher(translatedText);
        StringBuffer cleanedText = new StringBuffer();
    
        while (matcher.find()) {
            matcher.appendReplacement(cleanedText, "");
        }
        matcher.appendTail(cleanedText);
    
        return cleanedText.toString().replace("%23", "#")
                                     .replace("%26", "&")
                                     .replace("%3F", "?");
    }

    ActivityText mapActivityText(String apiUrl, ActivityText activityText) {
        String translatedFullName = translateWord(apiUrl, activityText.getFullNameTxt());
        String truncatedName = translatedFullName.length() <= 25 ? translatedFullName : translatedFullName.substring(0, 25) + "...";
        ActivityText translatedActivity = new ActivityText();
        translatedActivity.setId(activityText.getId());
        translatedActivity.setName(truncatedName);
        translatedActivity.setFullNameTxt(translatedFullName);
        return translatedActivity;
    }

    CommentText mapOldCommentTexts(String apiUrl, CommentText commentText) {
        String originalText = commentText.getNameText();
        String specialChars = "";
        String contentToTranslate = originalText;

        // Extract special characters at the beginning
        if (originalText.startsWith("!")) {
            specialChars += "!";
            contentToTranslate = contentToTranslate.substring(1);
        }

        // Translate the content
        String translatedContent = translateWord(apiUrl, contentToTranslate);

        // Combine special characters and translated content
        String translatedFullName = specialChars + translatedContent;

        CommentText translatedComment = new CommentText();
        translatedComment.setId(commentText.getId());
        translatedComment.setNameText(translatedFullName);
        return translatedComment;
    }
    
    CommentText mapNewCommentTexts(String apiUrl, CommentText commentText) {
        String originalText = commentText.getNameText();
        String specialChars = "";
        String contentToTranslate = originalText;

        // Extract special characters at the beginning
        if (originalText.startsWith("!")) {
            specialChars += "!";
            contentToTranslate = contentToTranslate.substring(1);
        }

        // Translate the content
        String translatedContent = translateWord(apiUrl, contentToTranslate);

        // Combine special characters and translated content
        String translatedFullName = specialChars + translatedContent;

        CommentText translatedComment = new CommentText();
        translatedComment.setId(commentText.getId());
        translatedComment.setNameText(translatedFullName);
        return translatedComment;
    }
    

    RemainingText mapRemainingText(String apiUrl, RemainingText remainingText) {
        String translatedName = translateWord(apiUrl, remainingText.getName());
        RemainingText translatedRemaining = new RemainingText();
        translatedRemaining.setId(remainingText.getId());
        translatedRemaining.setName(translatedName);
        return translatedRemaining;
    }
}