package com.igosolutions.uniSync.ServiceImpl;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.Templates;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.TemplateRepository;
import com.igosolutions.uniSync.Service.TemplateService;
import com.igosolutions.uniSync.utils.CompanyLogo;
import com.igosolutions.uniSync.utils.TemplateRequestDto;
import com.igosolutions.uniSync.utils.TemplateResponseDto;

@Service
public class TemplateServiceImpl implements TemplateService {
	
   @Autowired
   private TemplateRepository templateRepository;
   
	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
	
	@Autowired
	EntityManager entityManager;
	
	@Override
	public void createTemplates(TemplateRequestDto templateRequestDto,String organization) throws Exception {
		try {
		
	    Templates templatesName = templateRepository.findbyTemplateName(templateRequestDto.getTemplateName(),organization);
	    if(templatesName!= null) {
	    	throw new Exception("Template name already exist in your organization");
	    }
	    else {
	    
	    Templates templates = new Templates();
		templates.setTemplateName(templateRequestDto.getTemplateName());
		templates.setColorCode(templateRequestDto.getColorCode());
		templates.setCompanyLogo(null);
		templates.setNavPreviousIcon(templateRequestDto.getNavPreviousIcon());
		templates.setNavUpIcon(templateRequestDto.getNavUpIcon());
		templates.setCompanyName(templateRequestDto.getCompanyName());
		templates.setNavHomeIcon(templateRequestDto.getNavHomeIcon());
		templates.setIconSource(templateRequestDto.getIconSource());
		templates.setNavUpImg(templateRequestDto.getNavUpImg());
		templates.setNavPreviousImg(templateRequestDto.getNavPreviousImg());
		templates.setNavHomeImg(templateRequestDto.getNavHomeImg());
		templates.setImgcontent(templateRequestDto.getCompanyLogo().getImgcontent());
		templates.setImgname(templateRequestDto.getCompanyLogo().getImgname());
		templates.setOrganization(organization);

		templateRepository.save(templates);
	    }
		
	}catch(Exception e) {
		e.printStackTrace();
		throw new Exception(e.getMessage());
	}
	}

	@Override
	public List<TemplateResponseDto> getAllTemplatesByOrganization(String organization) throws Exception {
		
		List<Templates> templates = templateRepository.findAllByOrganization(organization);
		List<TemplateResponseDto> templateDTOs =mapToDTO(templates);
		return templateDTOs;
	}

	@Override
	public TemplateResponseDto updateTemplates(TemplateRequestDto templateRequestDto, String organization) throws Exception {
		
		TemplateResponseDto templateResponseDto = new TemplateResponseDto();
		try {
			
		    Templates templatesName = templateRepository.findByTemplateId(templateRequestDto.getId());
		    
		    if(templatesName== null) {
		    	throw new Exception("Template not exist to update");
		    }
		    
		    System.out.println("com           "+templateRequestDto.getCompanyName());
		    
		    Templates templates = new Templates();
		    templates.setTemplateId(templateRequestDto.getId());
			templates.setTemplateName(templateRequestDto.getTemplateName());
			templates.setColorCode(templateRequestDto.getColorCode());
			templates.setCompanyLogo(null);
			templates.setNavPreviousIcon(templateRequestDto.getNavPreviousIcon());
			templates.setNavUpIcon(templateRequestDto.getNavUpIcon());
			templates.setCompanyName(templateRequestDto.getCompanyName());
			templates.setNavHomeIcon(templateRequestDto.getNavHomeIcon());
			templates.setIconSource(templateRequestDto.getIconSource());
			templates.setNavUpImg(templateRequestDto.getNavUpImg());
			templates.setNavPreviousImg(templateRequestDto.getNavPreviousImg());
			templates.setNavHomeImg(templateRequestDto.getNavHomeImg());
			templates.setImgcontent(templateRequestDto.getCompanyLogo().getImgcontent());
			templates.setImgname(templateRequestDto.getCompanyLogo().getImgname());
			templates.setOrganization(organization);
			
			
			System.out.println("commmmmmmmmmmmmmmmmmmmm "+templates.getCompanyName());

			templateRepository.updateTemplateById(templates.getTemplateId(),templates.getTemplateName(),templates.getCompanyLogo()
					                              ,templates.getCompanyName(),templates.getColorCode(),templates.getNavUpIcon(),
					                               templates.getNavPreviousIcon(),templates.getNavHomeIcon()
					                               ,templates.getIconSource(),templates.getNavPreviousImg(),templates.getNavUpImg(),
		
						                               templates.getNavHomeImg(),templates.getImgname(),templates.getImgcontent(),templates.getOrganization());
			
			templateRepository.flush();
			entityManager.clear();
			
			Templates updatedTemplate = templateRepository.findByTemplateId(templates.getTemplateId());
			
			templateResponseDto =  mapSingleTemplate(updatedTemplate);
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
			}
		return templateResponseDto;
		
		}

	@Override
	public String deleteTemplates(List<Long> templateId) throws Exception {
		try {
			
			List<String> templateIdStrings = convertLongListToStringList(templateId);
			
			 List<String> usedTemplateIds = bpnmUserDiagrammeRepository.findUsedTemplateIds(templateIdStrings);
			    
			 List<Long> unusedTemplateIds = templateIdStrings.stream()
				        .filter(id -> !usedTemplateIds.contains(id))
				        .map(Long::parseLong) 
				        .collect(Collectors.toList());

			    
			    if (!usedTemplateIds.isEmpty()) {
			        throw new Exception("Some templates are actively applied in diagrams: " + usedTemplateIds + ". Deletion aborted.");
			    }
			    
			    if (!unusedTemplateIds.isEmpty()) {
			        templateRepository.deleteByTemplateIds(unusedTemplateIds);
			    }
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception("The template is actively applied in diagrams. Deletion aborted.");
		}
		return null;
	}

	@Override
	public TemplateResponseDto getTemplate(Long templateId) throws Exception {
		
		TemplateResponseDto templateResponseDto = new TemplateResponseDto();
		
		Templates templates = templateRepository.findByTemplateId(templateId);
		
		templateResponseDto = mapSingleTemplate(templates);
		
		
		return templateResponseDto;
	}
	
	public static List<TemplateResponseDto> mapToDTO(List<Templates> templates) {
        return templates.stream()
                .map(TemplateServiceImpl::mapSingleTemplate)
                .collect(Collectors.toList());
    }

    private static TemplateResponseDto mapSingleTemplate(Templates template) {
    	
    	CompanyLogo companyLogo = new CompanyLogo();
    	companyLogo.setImgcontent(template.getImgcontent());
    	companyLogo.setImgname(template.getImgname());
    	
    	TemplateResponseDto dto = new TemplateResponseDto();
        dto.setId(template.getTemplateId());
        dto.setTemplateName(template.getTemplateName());
        dto.setCompanyName(template.getCompanyName());
        dto.setColorCode(template.getColorCode());
        dto.setNavUpIcon(template.getNavUpIcon());
        dto.setNavPreviousIcon(template.getNavPreviousIcon());
        dto.setNavHomeIcon(template.getNavHomeIcon());
        dto.setCompanyLogo(companyLogo);
        dto.setIconSource(template.getIconSource());
        dto.setNavUpImg(template.getNavUpImg());
        dto.setNavPreviousImg(template.getNavPreviousImg());
        dto.setNavHomeImg(template.getNavHomeImg());
        return dto;
    }

    public static List<String> convertLongListToStringList(List<Long> longList) {
        return longList.stream()
                       .map(String::valueOf)
                       .collect(Collectors.toList());
    }
}
