package com.igosolutions.uniSync.Service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.igosolutions.uniSync.Modal.ReviewComments;
import com.igosolutions.uniSync.Modal.ReviewCommentsDTO;
import com.igosolutions.uniSync.utils.CommentsMentionDto;
import com.igosolutions.uniSync.utils.EmailBody;
import com.igosolutions.uniSync.utils.Recipients;

public interface CommentsService {

	List<ReviewCommentsDTO> saveComments(int diagramXmlId, String currentXmlId, List<ReviewComments> reviewComments) throws Exception;

	List<ReviewCommentsDTO> getCommentsByDiagramXmlId(int diagramXmlId) throws Exception;

	void updateComments(Long commentId, Boolean flagToggleActivity) throws Exception;
	
	void updateAllComments(List<ReviewCommentsDTO> reviewComments) throws Exception;

    void deleteComments(Long commentId);

    ResponseEntity<?> editComments(Long commentId, ReviewComments reviewComments);

    ResponseEntity<?> resequenceUpdates(List<ReviewCommentsDTO> reviewComments, int diagramXmlId);

	void sendMentionedComment(CommentsMentionDto commentsMentionDto) throws Exception;

	ByteArrayOutputStream generatePdf(List<EmailBody> emailBody, String diagramName) throws Exception;

	void sendEmailWithPdf(List<Recipients> recipients, MultipartFile pdfMultipartFile, String originalFileName, String diagramName, String userName) throws Exception;

	MultipartFile convertByteArrayToMultipartFile(byte[] byteArray, String fileName);

}
