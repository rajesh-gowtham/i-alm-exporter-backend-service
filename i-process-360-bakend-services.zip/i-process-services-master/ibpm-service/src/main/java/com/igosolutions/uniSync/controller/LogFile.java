package com.igosolutions.uniSync.controller;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


public class LogFile {

	
	public static void   deleteFiles() throws IOException {
		
		    Calendar calendar = Calendar.getInstance();
	        calendar.set(Calendar.HOUR_OF_DAY, 0);
	        calendar.set(Calendar.MINUTE, 0);
	        calendar.set(Calendar.SECOND, 0);
	        calendar.set(Calendar.MILLISECOND, 0);	        
	        
	        String str[]= calendar.getTime().toString().split(" ");
	        if(str[0].equals("Sun")) {
	        	LogFile.clean("C:\\UniSyncSpringBoot\\Jar\\LogFile\\");      	   
	        }else { 	
	        	
	        }	 
	        
	        
	}
	

	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value="/newFile", method=RequestMethod.GET)
    public static void LogWrite(String Message) throws IOException {
        String folder="C:\\i-Bpmn\\Logs\\ComundaLogs";
        CreateFolder(folder);
           String Filename=folder+"\\igo-"+LocalDate.now()+".txt";

            File f = new File(Filename);
            if(!f.exists()){
              f.createNewFile();
            }else{
              
            }
            
            @SuppressWarnings("unused")
			String newLine = System.getProperty("line.separator");
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
            LocalDateTime now = LocalDateTime.now();
            try {
                BufferedWriter writer = new BufferedWriter( new FileWriter( Filename, true ) );    
                writer.append("["+dtf.format(now)+"]"+ " " + Message +"\n");    
                System.out.println("LOG MESSAGE: "+Message);
                writer.flush();
                writer.close();   
            } catch (IOException e) {
                e.printStackTrace();
            }
            deleteFiles();
    }
    
    public static void CreateFolder(String path) throws IOException {
            // Specify the path of the folder you want to create
            String folderPath =path;

            // Create a File object representing the folder
            File folder = new File(folderPath);

            // Check if the folder doesn't exist
            if (!folder.exists()) {
                // Attempt to create the folder and its parent directories
                boolean success = folder.mkdirs();

                if (success) {
                    System.out.println("Folder created successfully.");
                } else {
                    System.err.println("Failed to create the folder.");
                }
            } else {
                System.out.println("Folder already exists.");
            }


    }
	
	
	public static void clean(String folder) throws IOException {

		File file = new File(folder);      
		String[] myFiles;    
		if (file.isDirectory()) {
			
		    myFiles = file.list();
		    for (int i = 0; i < myFiles.length; i++) {
		        File myFile = new File(file, myFiles[i]); 
		        myFile.delete();
		       
		    }
		}
	}
}
