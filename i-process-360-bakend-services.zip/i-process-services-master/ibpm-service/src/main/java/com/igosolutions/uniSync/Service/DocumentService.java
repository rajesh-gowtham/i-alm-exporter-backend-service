package com.igosolutions.uniSync.Service;

public interface DocumentService {
	
	  

	byte[] getDocument(int diagram_xml_id, String current_xml_id, String activity_id, String file_name) throws Exception;

	void deleteDocument(String document_id) throws Exception;

}
