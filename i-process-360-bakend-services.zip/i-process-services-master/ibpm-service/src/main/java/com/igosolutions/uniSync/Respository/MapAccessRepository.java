package com.igosolutions.uniSync.Respository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.igosolutions.uniSync.Modal.MapAccess;

public interface MapAccessRepository extends JpaRepository<MapAccess, Long> {

	@Query("SELECT b FROM MapAccess b where b.specificUser=:userId")
	List<MapAccess> findbySpecificUserId(@Param("userId")int userId);
	
	@Transactional
    @Modifying
    @Query("DELETE FROM MapAccess b WHERE b.diagramXmlId = :diagramXmlId")
	void deleteBydiagramXmlId(@Param("diagramXmlId")int diagramXmlId);
	
	@Transactional
    @Modifying
    @Query("DELETE FROM MapAccess b WHERE b.reviewDiagramme.id = :mapId")
	void deleteByMapId(@Param("mapId")Long mapId);

	@Transactional
	@Query("SELECT b FROM MapAccess b where b.diagramXmlId=:diagramXmlId")
	List<MapAccess> findByDiagramXmlId(@Param("diagramXmlId")int diagramXmlId);

	@Query("SELECT m FROM MapAccess m WHERE m.reviewDiagramme.id = :reviewDiagrammeId")
    List<MapAccess> findByReviewDiagrammeId(@Param("reviewDiagrammeId") Long reviewDiagrammeId);
	
	@Transactional
	@Query("SELECT b.specificUser FROM MapAccess b where b.diagramXmlId=:diagramXmlId")
	List<Integer> findUserIdByDiagramXmlId(@Param("diagramXmlId")int diagramXmlId);
	
	
	@Query("SELECT m.specificUser FROM MapAccess m WHERE m.reviewDiagramme.id = :reviewDiagrammeId")
    List<Integer> findUserIdByReviewDiagrammeId(@Param("reviewDiagrammeId") Long reviewDiagrammeId);

    @Transactional
    @Modifying
    @Query("DELETE FROM MapAccess b WHERE b.reviewDiagramme.id = :mapId AND b.specificUser = :specificUserId")
    void deleteByMapIdAndSpecificUserId(@Param("mapId") Long mapId, @Param("specificUserId") int specificUserId);
    
    @Transactional
    @Modifying
    @Query("DELETE FROM MapAccess b WHERE b.specificUser = :specificUserId")
    void deleteBySpecificUserId(@Param("specificUserId") int specificUserId);
    



}
