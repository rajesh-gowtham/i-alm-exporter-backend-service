package com.igosolutions.uniSync.utils;

public class UserDetailsDTO {
	
	@SuppressWarnings("unused")
	private Long userId;
    @SuppressWarnings("unused")
	private String email;
    @SuppressWarnings("unused")
	private String name;

    public UserDetailsDTO(Long userId, String email, String name) {
        this.userId = userId;
        this.email = email;
        this.name = name;
    }

}
