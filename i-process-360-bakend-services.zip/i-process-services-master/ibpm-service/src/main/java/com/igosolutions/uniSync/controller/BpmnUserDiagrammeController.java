package com.igosolutions.uniSync.controller;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Modal.BpnmUserDiagramme;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTO;
import com.igosolutions.uniSync.Modal.MapDiagramRequestDTOResponse;
import com.igosolutions.uniSync.Modal.ReviewDiagramme;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.Respository.BpnmUserDiagrammeRepository;
import com.igosolutions.uniSync.Respository.MapAccessRepository;
import com.igosolutions.uniSync.Respository.MapReviewRepository;
import com.igosolutions.uniSync.Respository.TimeManageRepository;
import com.igosolutions.uniSync.Service.BpmnMapReviewService;
import com.igosolutions.uniSync.Service.BpnmUserDiagrammeService;
import com.igosolutions.uniSync.constants.UtilsConstants;
import com.igosolutions.uniSync.utils.HeaderUtil;
import com.igosolutions.uniSync.utils.TimeStampUpdation;


@RestController
public class BpmnUserDiagrammeController {
	
	@Autowired
    BpnmUserDiagrammeService bpnmUserDiagrammeService;
	
	@Autowired
	BpmnMapReviewService bpmnMapReviewService;

	@Autowired
	BpmnUserRepository bpmnUserRepository;
	
	@Autowired
	BpnmUserDiagrammeRepository bpnmUserDiagrammeRepository;
	
	@Autowired
	MapReviewRepository mapReviewRepository;
	
	@Autowired
	TimeManageRepository timeManageRepository;
	@Autowired
	MapAccessRepository mapAccessRepository;
	
	@Autowired 
	EntityManager entityManager;
	
	@Autowired
	TimeStampUpdation timeStampUpdation;
 
	Logger log = LoggerFactory.getLogger(BpmnUserDiagrammeController.class);
	
	

	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnXml/getLastSavedXml/{diagramXmlId}", method = RequestMethod.GET)
	public ResponseEntity<?> getDiagrammeByUserId(@RequestHeader Map<String, String> headers, @PathVariable("diagramXmlId") int diagramXmlId) throws Exception {
	    String userId = HeaderUtil.getUserId(headers);
	    log.debug("Request received from user ID: {}", userId);
	    log.debug("Headers: {}", headers);
	    Map<String, Object> responseMap = new HashMap<>();
	   
	    try {
	    	 responseMap = bpnmUserDiagrammeService.getLastSavedXml(headers,diagramXmlId);
	    	 return new ResponseEntity<>(responseMap, HttpStatus.OK);
	       
	    } catch (Exception e) {
	        log.error("Error occurred: {}", e.getMessage(), e);

	        if (e.getMessage().equals("The map was already opened by another editor, please try again later")) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
	        } else if (e.getMessage().equals("Diagram not found")) {
	            return new ResponseEntity<>("DiagramXml ID not found", HttpStatus.NOT_FOUND);
	        } else {
	            return new ResponseEntity<>("Unknown issue", HttpStatus.NOT_ACCEPTABLE);
	        }
	    }
	}



	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnXml/saveLatestXml/{diagramXmlId}",method = RequestMethod.POST) 
	public ResponseEntity<Object> saveLatestXml(@RequestHeader Map<String, String> headers, @PathVariable(name = "diagramXmlId") int diagramXmlId,@RequestBody BpnmUserDiagramme bpnmUserDiagramme){

		
		Map<String,String> response = new HashMap<>();
		
		try {
			String userId = HeaderUtil.getUserId(headers);
			log.debug("Request {}", userId);
			bpnmUserDiagramme.setUserid(Long.parseLong(userId));
			bpnmUserDiagramme.setDiagramXmlId(diagramXmlId);
			response = bpnmUserDiagrammeService.saveOrUpdateXmlData(bpnmUserDiagramme);
			return new ResponseEntity<>(response,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			log.debug("Response {}",HttpStatus.INTERNAL_SERVER_ERROR);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	} 
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnXml/saveDocumentStorageType",method = RequestMethod.POST) 
	public ResponseEntity<String> saveSorageType(@RequestBody Map<String, String> requestPayload){

		log.debug("Request {}", requestPayload.get("diagramXmlId"));
		try {
			bpnmUserDiagrammeService.saveStorageType(Integer.parseInt(requestPayload.get("diagramXmlId")), requestPayload.get("storageType"), requestPayload.get("configName"), requestPayload.get("configId"));
			return new ResponseEntity<>(HttpStatus.OK);
			}
		 catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
   }
	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnDiagram/createMapDiagram",method = RequestMethod.POST) 
	public ResponseEntity<?> createNewDiagrams(@RequestHeader Map<String, String> headers,
			@RequestBody MapDiagramRequestDTO mapDiagramRequestDTO) {
		try {
			String userId = HeaderUtil.getUserId(headers);
			// String organization = HeaderUtil.getOrganization(headers);
			BpmnUser bpmnUser = bpmnUserRepository.findByUserId(Long.parseLong(userId));

			MapDiagramRequestDTOResponse mapDiagramRequestDTOResponse = new MapDiagramRequestDTOResponse();

			BpnmUserDiagramme response = bpnmUserDiagrammeService.createNewDiagrams(Long.parseLong(userId),
					mapDiagramRequestDTO);
			if (bpmnUser != null) {
				String author = bpmnUser.getFirstname() + " " + bpmnUser.getLastname();
				ReviewDiagramme reviewDiagramme = bpmnMapReviewService.createInitiaDraft(Long.parseLong(userId),response.getDiagramXmlId(),UtilsConstants.CommentsConstants.INPROGRESS,author,mapDiagramRequestDTO);

				if(reviewDiagramme.getErrorMessage() != null) {
					return new ResponseEntity<>(reviewDiagramme.getErrorMessage(),HttpStatus.NOT_FOUND);
				}		
				if (reviewDiagramme != null) {
					mapDiagramRequestDTOResponse = bpmnMapReviewService.createMapResponse(response, reviewDiagramme);
				}
			}
			return ResponseEntity.ok(mapDiagramRequestDTOResponse);
		} catch (Exception e) {
			e.printStackTrace();
			Map<String, Object> errorResponse = Collections.singletonMap("error",
					"An error occurred while creating the diagrams: " + e.getMessage());
			return new ResponseEntity<>(Collections.singletonList(errorResponse), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnDiagram/updateMapDiagram/{mapId}", method = RequestMethod.PUT)
	public ResponseEntity<?> editDiagrams(@RequestHeader Map<String, String> headers,@PathVariable("mapId") Long mapId,
	                                      @RequestBody MapDiagramRequestDTOResponse mapDiagramRequestDTO) {
	    try {
	        String userId = HeaderUtil.getUserId(headers);
	        MapDiagramRequestDTOResponse mapDiagramRequestDTOResponse = bpnmUserDiagrammeService.updateMapDigram(userId,mapId,mapDiagramRequestDTO);	        
	        
	        return new ResponseEntity<>(mapDiagramRequestDTOResponse, HttpStatus.OK);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	@RequestMapping(value = "bpmnDiagram/deleteMapDiagrams",method = RequestMethod.DELETE) 
//	public ResponseEntity<?> deleteMapDiagrams(@RequestHeader Map<String, String> headers,@RequestBody List<ReviewDiagramme> requestPayload) {
//		String userId = HeaderUtil.getUserId(headers);
//		try {
//			bpnmUserDiagrammeService.deleteMapDiagrams(Long.parseLong(userId), requestPayload);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		
//		
//		return null;															
//	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/bpmnXml/applyTemplate",method = RequestMethod.POST) 
	public ResponseEntity<String> saveTemplateInfo(@RequestBody Map<String, String> requestPayload){

		log.debug("Request {}", requestPayload.get("diagramXmlId"));
		try {
			String xmlId = requestPayload.get("diagramXmlId");
			String template = requestPayload.get("template");
			bpnmUserDiagrammeRepository.updateTemplate(Integer.parseInt(xmlId),template);
			return new ResponseEntity<>(HttpStatus.OK);
			}
		 catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
   }
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping("/bpmnDiagram/updateDiagramTimeByDiagramXmlId/{diagramXmlId}/{checkType}")
	public String updateOrderTimestamp(@PathVariable int diagramXmlId,@PathVariable("checkType")String checkType) {
		bpnmUserDiagrammeService.updateOrderTimestamp(diagramXmlId,checkType);

		return "Timestamp updated successfully.";
		}	
}
