package com.igosolutions.uniSync.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igosolutions.uniSync.Modal.BpmnUser;
import com.igosolutions.uniSync.Respository.BpmnUserRepository;
import com.igosolutions.uniSync.utils.CommentsMentionDto;
import com.igosolutions.uniSync.utils.Recipients;


@Service
public class MailContentServiceImpl {
	
	@Autowired
	BpmnUserRepository bpmnUserRepository;
	
	private String text;

	BpmnUser bpmnUser = new BpmnUser();
	BpmnUser sender = new BpmnUser();
	
	
	
	public String createMapMail(List<String> emails, String diagramName) {
		

			if (emails.size() == 1) {

				bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));

				text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
						+ diagramName + "' has been created. You can now begin editing and adding details.\n\n"
						+ "Thanks,\n" + "IGO Admin";
			}
			if (emails.size() > 1) {

				text = "Dear Editors,\n\n" + "The map '" + diagramName
						+ "' has been created. You can now begin editing and adding details.\n\n" + "Thanks,\n"
						+ "IGO Admin";
			}
			
			return text;
		}

	public String sendReviewMail(List<String> emails, String diagramName) {
		if (emails.size() == 1) {
		bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));
		 
		return text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" +
		           "The map '" + diagramName + "' has been developed and sent for your review. Please review and provide your comments and approve it.\n\n" +
		           "Thanks,\n" +
		           "IGO Admin";
		}
		else{
			return text = "Dear Reviewers" +",\n\n" +
		           "The map '" + diagramName + "' has been developed and sent for your review. Please review and provide your comments and approve it.\n\n" +
		           "Thanks,\n" +
		           "IGO Admin";
		}
		    
	}

	public String revertToEditorMail(List<String> emails, String diagramName) {
		
		if (emails.size() == 1) {

			bpmnUser = bpmnUserRepository.findByEmail(emails.get(0));

			 text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" +
		               "The map '" + diagramName + "' has been reviewed and comments provided.\n\n" +
		               "Please go through the comments, make the necessary changes, and resend the map for further review.\n\n" +
		               "Thanks,\n" +
		               "IGO Admin";
		}
		if (emails.size() > 1) {


	        text = "Dear Editors" +",\n\n" +
	               "The map '" + diagramName + "' has been reviewed and comments provided.\n\n" +
	               "Please go through the comments, make the necessary changes, and resend the map for further review.\n\n" +
	               "Thanks,\n" +
	               "IGO Admin";
		}
		
	    
		return text;   
	    
	}

	public String approvedMail(List<String> admins, String diagramName) {
		
		if (admins.size() == 1) {
			bpmnUser = bpmnUserRepository.findByEmail(admins.get(0));
			text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
					+ diagramName + "' has been reviewed and approved. You can publish the map.\n\n" + "\n"
					+ "Thanks,\n" + "IGO Admin";
		}
		
		if (admins.size() > 1) {
			text = "Dear Admins,\n\n" + "The map '" + diagramName
					+ "' has been reviewed and approved. You can publish the map.\n\n" + "\n" + "Thanks,\n"
					+ "IGO Admin";
		}


		return text; 
	}

	public String publishMail(List<String> viewerEmails, String diagramName) {
		if (viewerEmails.size() == 0) {

			text = "Dear Viewers,\n\n" + "The map '" + diagramName
					+ "' has been reviewed and published. You can view the map.\n\n" + "\n" + "Thanks,\n"
					+ "IGO Admin";
		}
		if (viewerEmails.size() == 1) {
			bpmnUser = bpmnUserRepository.findByEmail(viewerEmails.get(0));

			text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n" + "The map '"
					+ diagramName + "' has been reviewed and published. You can view the map.\n\n" + "\n"
					+ "Thanks,\n" + "IGO Admin";
		}
		if (viewerEmails.size() > 1) {

			text = "Dear Viewers,\n\n" + "The map '" + diagramName
					+ "' has been reviewed and published. You can view the map.\n\n" + "\n" + "Thanks,\n"
					+ "IGO Admin";
		}
	
	  return text;
	}

	public String mapUpdatedMail(List<String> recipients, String diagramName) {
		return text = "Dear Everyone,\n\n"
                + "The map '" + diagramName 
                + "' has been updated. Please review the changes and provide your feedback.\n\n"
                + "Thank you for your continuous support and effort.\n\n"
                + "Thanks,\n"
                + "IGO Admin";

		
		
	}

	public String mentionCommentsMap(List<String> recipientsEmails, String senderName, String emailBody, String diagramName) {
		// TODO Auto-generated method stub
		
		
		if (recipientsEmails.size() == 1) {
	        bpmnUser = bpmnUserRepository.findByEmail(recipientsEmails.get(0));

	        text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n"
	             + "You have been mentioned by " + senderName + " in the comments to the map " + diagramName + "'.\n\n"
	             + "Comment:\n"
	             + emailBody + "\n\n"
	             + "Please review the details and take any necessary actions.\n\n"
	             + "Thanks,\n"
	             + "IGO Admin";
	    } else if (recipientsEmails.size() > 1) {
	        text = "Dear Everyone,\n\n"
	             + "You have been mentioned by " + senderName + " in the comments to the map " + diagramName + "'.\n\n"
	             + "Comment:\n"
	             + emailBody + "\n\n"
	             + "Please review the details and take any necessary actions.\n\n"
	             + "Thanks,\n"
	             + "IGO Admin";
	    } else {
	        text = "No recipients found.";
	    }

	    return text;

	
	
    }

	public String mapGroupContent(List<String> recipientsEmails, String diagramName, String userName) {
		// TODO Auto-generated method stub
		
		if (recipientsEmails.size() == 1) {
	        bpmnUser = bpmnUserRepository.findByEmail(recipientsEmails.get(0));

	        text = "Dear " + bpmnUser.getFirstname() + " " + bpmnUser.getLastname() + ",\n\n"
	             + userName + " has sent the attached document regarding the map " + diagramName + ".\n\n"
	             + "Please review it and take any necessary actions.\n\n"
	             + "Thanks,\n"
	             + "IGO Admin";
	    } else if (recipientsEmails.size() > 1) {
	        text = "Dear Everyone,\n\n"
	        	 + userName + " has sent the attached document regarding the map " + diagramName + ".\n\n"
		         + "Please review it and take any necessary actions.\n\n"
	             + "Thanks,\n"
	             + "IGO Admin";
	    } else {
	        text = "No recipients found.";
	    }

	    return text;
	}
	
	
}
