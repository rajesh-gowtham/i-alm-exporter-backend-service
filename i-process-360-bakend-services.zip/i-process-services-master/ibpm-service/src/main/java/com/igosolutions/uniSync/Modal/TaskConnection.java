package com.igosolutions.uniSync.Modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TaskConnection")
public class TaskConnection {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long   TaskConnectionId;
	private String SourceType;
	private String datasourcename;
	private String BpmnId;

	
	@Override
	public String toString() {
		
		return "Connection [TaskConnectionId=" + TaskConnectionId + ", SourceType=" + SourceType
				+ ", datasourcename=" + datasourcename + ", BpmnId=" + BpmnId
				 +"]";
		
	}
	
	
	
	public Long getTaskConnectionId() {
		return TaskConnectionId;
	} 
	
	public void setTaskConnectionId(Long TaskConnectionId_) {
		this.TaskConnectionId = TaskConnectionId_;
	}
	
	
	public String getSourceType() {
		return SourceType;
	} 
	
	public void setSourceType(String SourceType_) {
		this.SourceType = SourceType_;
	}
	
	public String getdatasourcename() {
		return datasourcename;
	} 
	
	public void setdatasourcename(String datasourcename_) {
		this.datasourcename = datasourcename_;
	}
	
	public String getBpmnId() {
		return BpmnId;
	} 
	
	public void setBpmnId(String BpmnId_) {
		this.BpmnId = BpmnId_;
	}
	
	





	
}
