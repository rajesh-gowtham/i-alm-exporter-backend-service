package com.igosolutions.uniSync.Respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.igosolutions.uniSync.Modal.Notification;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    // List<Notification> findByUserIdsContainingAndIsReadFalse(Long userId);

     // Find all unread notifications by diagramXmlId
    //  List<Notification> findByDiagramXmlIdAndIsReadFalse(Integer diagramXmlId);

     // Find unread notifications for a specific user in a specific diagram
    //  List<Notification> findByDiagramXmlIdAndUserIdsContainingAndIsReadFalse(Integer diagramXmlId, Long userId);

    List<Notification> findAllByDiagramXmlId(Integer diagramXmlId);

    //delete All Notification objects by diagramXmlIds
    @Transactional
    @Modifying
    void deleteByDiagramXmlIdIn(List<Integer> diagramXmlIds);

    @Transactional
    @Modifying
    void deleteByCommentId(Long commentId);

}
