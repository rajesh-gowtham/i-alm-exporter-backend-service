package com.igosolutions.uniSync.Service;

import java.sql.SQLException;
import java.util.List;

public interface ALMDataBaseService {

	public void getUpdatetimeRecords();
	
	@SuppressWarnings("rawtypes")
	public List getAMLRecordsByALMIDs(List<Object> almIDs,String databasename,String domainname, String targetProjectname) throws ClassNotFoundException, SQLException;
}
