package com.igosolutions.uniSync.ServiceImpl;

import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class LanguageTest {
    static RestTemplate restTemplate = new RestTemplate();
    static String fromLanguage = "en";
    static String toLanguage = "ta";
    public static void main(String[] args) {
        
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx"+ "&sl=" + fromLanguage + "&tl=" + toLanguage + "&dt=t&q=";
        translateWord(url, "Hello, World!");
    }

    @SuppressWarnings("unchecked")
   static String translateWord(String apiUrl, String value) {
        try {
            if (value.contains("\n")) {
                String[] segments = value.split("\n");
                StringBuilder translatedTextBuilder = new StringBuilder();
    
                for (String segment : segments) {
                    if (!segment.isEmpty()) {
                        String escapedSegment = escapeSpecialCharacters(segment);
                        HttpHeaders headers = new HttpHeaders();
                        headers.add("Content-Type", "application/json; charset=UTF-8");
                        HttpEntity<String> entity = new HttpEntity<>(headers);
    
                        ResponseEntity<Object[]> responseEntity = restTemplate.exchange(apiUrl + escapedSegment, HttpMethod.GET, entity, Object[].class);
                        Object[] responseBody = responseEntity.getBody();
                        List<List<Object>> nestedArrays = (List<List<Object>>) responseBody[0];
                        String translatedSegment = (String) nestedArrays.get(0).get(0);
                        translatedTextBuilder.append(translatedSegment);
                    }
                    translatedTextBuilder.append("\n");
                }
    
                String translatedText = translatedTextBuilder.toString().trim();
                return cleanTranslatedText(translatedText);
            } else {
                String escapedValue = escapeSpecialCharacters(value);
                HttpHeaders headers = new HttpHeaders();
                headers.add("Content-Type", "application/json; charset=UTF-8");
                HttpEntity<String> entity = new HttpEntity<>(headers);
    
                ResponseEntity<Object[]> responseEntity = restTemplate.exchange(apiUrl + escapedValue, HttpMethod.GET, entity, Object[].class);
                Object[] responseBody = responseEntity.getBody();
                List<List<Object>> nestedArrays = (List<List<Object>>) responseBody[0];
                String text = (String)nestedArrays.get(0).get(0);
                return text.replace("%23", "#")
                .replace("%26", "&")
                .replace("%3F", "?");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    // Method to escape only necessary special characters in the string
    private static String escapeSpecialCharacters(String text) {
        return text.replace("#", "%23")
                   .replace("&", "%26")
                   .replace("?", "%3F");
    }
    
    private static String cleanTranslatedText(String translatedText) {
        Pattern pattern = Pattern.compile("%[0-9A-Fa-f]{2}");
        Matcher matcher = pattern.matcher(translatedText);
        StringBuffer cleanedText = new StringBuffer();
    
        while (matcher.find()) {
            matcher.appendReplacement(cleanedText, "");
        }
        matcher.appendTail(cleanedText);
    
        return cleanedText.toString().replace("%23", "#")
                                     .replace("%26", "&")
                                     .replace("%3F", "?");
    }
    
}
