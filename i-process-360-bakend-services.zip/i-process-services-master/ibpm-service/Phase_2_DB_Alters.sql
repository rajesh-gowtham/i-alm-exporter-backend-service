
ALTER TABLE ibpmn_user_aud ALTER COLUMN imgcontent NVARCHAR(MAX);
ALTER TABLE ibpmn_user ALTER COLUMN imgcontent NVARCHAR(MAX)

ALTER TABLE ibpmn_user_diagramme ALTER COLUMN xml_data NVARCHAR(MAX)
ALTER TABLE ibpmn_user_diagramme ALTER COLUMN template NVARCHAR(MAX)
ALTER TABLE ibpmn_user_diagramme ALTER COLUMN diagram_name NVARCHAR(512)

ALTER TABLE bpmn ALTER COLUMN bpmn_xml NVARCHAR(MAX);

ALTER TABLE audit_trail_detail ALTER COLUMN old_value NVARCHAR(MAX);
ALTER TABLE audit_trail_detail ALTER COLUMN new_value NVARCHAR(MAX);

ALTER TABLE template ALTER COLUMN company_logo NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_home_icon NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_up_icon NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_previous_icon NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN icon_source NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN img_content NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_home_img NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_previous_img NVARCHAR(MAX);
ALTER TABLE template ALTER COLUMN nav_up_img NVARCHAR(MAX);


INSERT INTO role (id, rolename, description, organization) VALUES (1,'Admin', 'Can View, Delete,and Publish the Diagram', 'iGO Solutions');
INSERT INTO role (id, rolename, description, organization) VALUES (2,'Viewer', 'Can View Maps', 'iGO Solutions');
INSERT INTO role (id, rolename, description, organization) VALUES (3,'Editor', 'Can Edit Maps', 'iGO Solutions');
INSERT INTO role (id, rolename, description, organization) VALUES (4,'Reviewer', 'Can Review and Approve Maps', 'iGO Solutions');

